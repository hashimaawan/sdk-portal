
# Acl Configuration 1

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `S3AclOption` | [`S3AclOption1Enum`](../../doc/models/s3-acl-option-1-enum.md) | Required | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

AclConfiguration1 aclConfiguration1 = new AclConfiguration1
{
    S3AclOption = S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
};
```

