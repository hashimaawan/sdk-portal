# Apps

App Platform is a Platform-as-a-Service (PaaS) offering from DigitalOcean that allows
developers to publish code directly to DigitalOcean servers without worrying about the
underlying infrastructure.

Most API operations are centered around a few core object types. Following are the
definitions of these types. These definitions will be omitted from the operation-specific
documentation.

For documentation on app specifications (`AppSpec` objects), please refer to the
[product documentation](https://docs.digitalocean.com/products/app-platform/reference/app-spec/)).

```php
$appsApi = $client->getAppsApi();
```

## Class Name

`AppsApi`

## Methods

* [Apps List](../../doc/controllers/apps.md#apps-list)
* [Apps Create](../../doc/controllers/apps.md#apps-create)
* [Apps List Metrics Bandwidth Daily](../../doc/controllers/apps.md#apps-list-metrics-bandwidth-daily)
* [Apps Validate App Spec](../../doc/controllers/apps.md#apps-validate-app-spec)
* [Apps List Regions](../../doc/controllers/apps.md#apps-list-regions)
* [Apps List Tiers](../../doc/controllers/apps.md#apps-list-tiers)
* [Apps List Instance Sizes](../../doc/controllers/apps.md#apps-list-instance-sizes)
* [Apps Get Instance Size](../../doc/controllers/apps.md#apps-get-instance-size)
* [Apps Get Tier](../../doc/controllers/apps.md#apps-get-tier)
* [Apps List Alerts](../../doc/controllers/apps.md#apps-list-alerts)
* [Apps Assign Alert Destinations](../../doc/controllers/apps.md#apps-assign-alert-destinations)
* [Apps Get Logs Active Deployment](../../doc/controllers/apps.md#apps-get-logs-active-deployment)
* [Apps List Deployments](../../doc/controllers/apps.md#apps-list-deployments)
* [Apps Create Deployment](../../doc/controllers/apps.md#apps-create-deployment)
* [Apps Get Deployment](../../doc/controllers/apps.md#apps-get-deployment)
* [Apps Cancel Deployment](../../doc/controllers/apps.md#apps-cancel-deployment)
* [Apps Get Logs](../../doc/controllers/apps.md#apps-get-logs)
* [Apps Get Logs Aggregate](../../doc/controllers/apps.md#apps-get-logs-aggregate)
* [Apps Get Logs Active Deployment Aggregate](../../doc/controllers/apps.md#apps-get-logs-active-deployment-aggregate)
* [Apps Get Metrics Bandwidth Daily](../../doc/controllers/apps.md#apps-get-metrics-bandwidth-daily)
* [Apps Create Rollback](../../doc/controllers/apps.md#apps-create-rollback)
* [Apps Commit Rollback](../../doc/controllers/apps.md#apps-commit-rollback)
* [Apps Revert Rollback](../../doc/controllers/apps.md#apps-revert-rollback)
* [Apps Validate Rollback](../../doc/controllers/apps.md#apps-validate-rollback)
* [Apps Delete](../../doc/controllers/apps.md#apps-delete)
* [Apps Get](../../doc/controllers/apps.md#apps-get)
* [Apps Update](../../doc/controllers/apps.md#apps-update)


# Apps List

List all apps on your account. Information about the current active deployment as well as any in progress ones will also be included for each app.

```php
function appsList(?int $page = 1, ?int $perPage = 20, ?bool $withProjects = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `withProjects` | `?bool` | Query, Optional | Whether the project_id of listed apps should be fetched and included. |

## Response Type

**200**: A JSON object with a `apps` key. This is list of object `apps`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsResponse`](../../doc/models/v2-apps-response.md).

## Example Usage

```php
$page = 1;

$perPage = 2;

$withProjects = true;

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsList(
    $page,
    $perPage,
    $withProjects
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "apps": [
    {
      "active_deployment": {
        "created_at": "2020-12-01T00:40:05Z",
        "id": "3aa4d20e-5527-4c00-b496-601fbd22520a",
        "phase_last_updated_at": "2020-12-01T00:42:12Z",
        "services": [
          {
            "name": "sample-php",
            "source_commit_hash": "54d4a727f457231062439895000d45437c7bb405"
          }
        ],
        "spec": {
          "domains": [
            {
              "domain": "sample-php.example.com",
              "minimum_tls_version": "1.3",
              "type": "PRIMARY",
              "zone": "example.com"
            }
          ],
          "name": "sample-php",
          "region": "fra",
          "services": [
            {
              "environment_slug": "php",
              "git": {
                "branch": "main",
                "repo_clone_url": "https://github.com/digitalocean/sample-php.git"
              },
              "http_port": 8080,
              "instance_count": 1,
              "instance_size_slug": "basic-xxs",
              "name": "sample-php",
              "routes": [
                {
                  "path": "/"
                }
              ],
              "run_command": "heroku-php-apache2"
            }
          ]
        },
        "updated_at": "2020-12-01T00:42:12Z"
      },
      "cause": "app spec updated",
      "created_at": "2020-11-19T20:27:18Z",
      "default_ingress": "https://sample-php-iaj87.ondigitalocean.app",
      "domains": [
        {
          "certificate_expires_at": "2024-01-29T23:59:59Z",
          "id": "0831f444-a1a7-11ed-828c-ef59494480b5",
          "phase": "ACTIVE",
          "progress": {
            "steps": [
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "default-ingress-ready",
                "started_at": "2023-01-30T22:15:45.021896292Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "ensure-zone",
                "started_at": "2023-01-30T22:15:45.022017004Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:42:28.50752065Z",
                "name": "ensure-ns-records",
                "started_at": "2023-01-30T22:15:45.025567874Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "verify-nameservers",
                "started_at": "2023-01-30T22:15:45.033591906Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "ensure-record",
                "started_at": "2023-01-30T22:15:45.156750604Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.258626422Z",
                "name": "ensure-alias-record",
                "started_at": "2023-01-30T22:15:45.165933869Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.258808279Z",
                "name": "ensure-wildcard-record",
                "started_at": "2023-01-30T22:15:45.166093422Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "verify-cname",
                "started_at": "2023-01-30T22:15:45.166205559Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.475903785Z",
                "name": "ensure-ssl-txt-record-saved",
                "started_at": "2023-01-30T22:15:45.295237186Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.476017236Z",
                "name": "ensure-ssl-txt-record",
                "started_at": "2023-01-30T22:15:45.295315291Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.476094058Z",
                "name": "ensure-renewal-email",
                "started_at": "2023-01-30T22:15:45.295374087Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "ensure-CA-authorization",
                "started_at": "2023-01-30T22:15:45.295428101Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "ensure-certificate",
                "started_at": "2023-01-30T22:15:45.978756406Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:52.570612857Z",
                "name": "create-deployment",
                "started_at": "0001-01-01T00:00:00Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:31.333582377Z",
                "name": "configuration-alert",
                "started_at": "2023-01-30T22:15:46.278987808Z",
                "status": "SUCCESS"
              }
            ]
          },
          "rotate_validation_records": false,
          "spec": {
            "domain": "sample-php.example.com",
            "minimum_tls_version": "1.3",
            "type": "PRIMARY",
            "zone": "example.com"
          }
        }
      ],
      "id": "4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf",
      "last_deployment_created_at": "2020-12-01T00:40:05Z",
      "live_domain": "sample-php.example.com",
      "live_url": "https://sample-php.example.com",
      "live_url_base": "https://sample-php.example.com",
      "owner_uuid": "ff36cbc6fd350fe12577f5123133bb5ba01a2419",
      "pending_deployment": {
        "created_at": "2020-12-01T00:40:05Z",
        "id": "3aa4d20e-5527-4c00-b496-601fbd22520a",
        "phase_last_updated_at": "2020-12-01T00:42:12Z",
        "services": [
          {
            "name": "sample-php",
            "source_commit_hash": "54d4a727f457231062439895000d45437c7bb405"
          }
        ],
        "spec": {
          "domains": [
            {
              "domain": "sample-php.example.com",
              "minimum_tls_version": "1.3",
              "type": "PRIMARY",
              "zone": "example.com"
            }
          ],
          "name": "sample-php",
          "region": "fra",
          "services": [
            {
              "environment_slug": "php",
              "git": {
                "branch": "main",
                "repo_clone_url": "https://github.com/digitalocean/sample-php.git"
              },
              "http_port": 8080,
              "instance_count": 1,
              "instance_size_slug": "basic-xxs",
              "name": "sample-php",
              "routes": [
                {
                  "path": "/"
                }
              ],
              "run_command": "heroku-php-apache2"
            }
          ]
        },
        "updated_at": "2020-12-01T00:42:12Z"
      },
      "progress": {
        "phase": "ACTIVE",
        "steps": [
          {
            "ended_at": "2020-12-01T00:41:26.653989756Z",
            "name": "build",
            "started_at": "2020-12-01T00:40:11.979257919Z",
            "status": "SUCCESS",
            "steps": [
              {
                "ended_at": "2020-12-01T00:40:12.470972033Z",
                "name": "initialize",
                "started_at": "2020-12-01T00:40:11.979305214Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2020-12-01T00:41:26.180360487Z",
                "name": "components",
                "started_at": "2020-12-01T00:40:12.470996857Z",
                "status": "SUCCESS",
                "steps": [
                  {
                    "component_name": "sample-php",
                    "ended_at": "0001-01-01T00:00:00Z",
                    "message_base": "Building service",
                    "name": "sample-php",
                    "started_at": "0001-01-01T00:00:00Z",
                    "status": "SUCCESS"
                  }
                ]
              }
            ]
          }
        ],
        "success_steps": 6,
        "tier_slug": "basic",
        "total_steps": 6
      },
      "region": {
        "continent": "Europe",
        "data_centers": [
          "fra1"
        ],
        "flag": "germany",
        "label": "Frankfurt",
        "slug": "fra"
      },
      "spec": {
        "domains": [
          {
            "domain": "sample-php.example.com",
            "minimum_tls_version": "1.3",
            "type": "PRIMARY",
            "zone": "example.com"
          }
        ],
        "name": "sample-php",
        "services": [
          {
            "environment_slug": "php",
            "git": {
              "branch": "main",
              "repo_clone_url": "https://github.com/digitalocean/sample-php.git"
            },
            "http_port": 8080,
            "instance_count": 1,
            "instance_size_slug": "basic-xxs",
            "name": "sample-php",
            "routes": [
              {
                "path": "/"
              }
            ],
            "run_command": "heroku-php-apache2"
          }
        ]
      },
      "tier_slug": "basic",
      "updated_at": "2020-12-01T00:42:16Z"
    }
  ],
  "links": {
    "pages": {}
  },
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Create

Create a new app by submitting an app specification. For documentation on app specifications (`AppSpec` objects), please refer to [the product documentation](https://docs.digitalocean.com/products/app-platform/reference/app-spec/).

```php
function appsCreate(V2AppsRequest $body, ?string $accept = null, ?string $contentType = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2AppsRequest`](../../doc/models/v2-apps-request.md) | Body, Required | - |
| `accept` | [`?string(Accept)`](../../doc/models/accept.md) | Header, Optional | The content-type that should be used by the response. By default, the response will be `application/json`. `application/yaml` is also supported. |
| `contentType` | [`?string(ContentType)`](../../doc/models/content-type.md) | Header, Optional | The content-type used for the request. By default, the requests are assumed to use `application/json`. `application/yaml` is also supported. |

## Response Type

**200**: A JSON or YAML of a `spec` object.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsResponse1`](../../doc/models/v2-apps-response-1.md).

## Example Usage

```php
$body = V2AppsRequestBuilder::init(
    AppSpecBuilder::init(
        'web-app'
    )
        ->region(Region1::NYC)
        ->services(
            [
                ServiceBuilder::init(
                    'api'
                )
                    ->environmentSlug('node-js')
                    ->github(
                        GithubBuilder::init()
                            ->branch('main')
                            ->deployOnPush(true)
                            ->repo('digitalocean/sample-golang')
                            ->build()
                    )
                    ->runCommand('bin/api')
                    ->instanceCount(2)
                    ->instanceSizeSlug(InstanceSizeSlug::BASICXXS)
                    ->routes(
                        [
                            ACriterionForRoutingHttpTrafficToAComponentBuilder::init()
                                ->path('/api')
                                ->build()
                        ]
                    )
                    ->build()
            ]
        )
        ->build()
)->build();

$accept = Accept::ENUM_APPLICATIONJSON;

$contentType = ContentType::ENUM_APPLICATIONJSON;

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsCreate(
    $body,
    $accept,
    $contentType
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Metrics Bandwidth Daily

Retrieve daily bandwidth usage metrics for multiple apps.

```php
function appsListMetricsBandwidthDaily(V2AppsMetricsBandwidthDailyRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2AppsMetricsBandwidthDailyRequest`](../../doc/models/v2-apps-metrics-bandwidth-daily-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with a `app_bandwidth_usage` key

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsMetricsBandwidthDailyResponse`](../../doc/models/v2-apps-metrics-bandwidth-daily-response.md).

## Example Usage

```php
$body = V2AppsMetricsBandwidthDailyRequestBuilder::init(
    [
        '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf',
        'c2a93513-8d9b-4223-9d61-5e7272c81cf5'
    ]
)
    ->date(DateTimeHelper::fromRfc3339DateTime('2023-01-17T00:00:00Z'))
    ->build();

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsListMetricsBandwidthDaily($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsMetricsBandwidthDailyResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "app_bandwidth_usage": [
    {
      "app_id": "4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf",
      "bandwidth_bytes": "513668"
    },
    {
      "app_id": "c2a93513-8d9b-4223-9d61-5e7272c81cf5",
      "bandwidth_bytes": "254847"
    }
  ],
  "date": "2023-01-17T00:00:00Z"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Validate App Spec

To propose and validate a spec for a new or existing app, send a POST request to the `/v2/apps/propose` endpoint. The request returns some information about the proposed app, including app cost and upgrade cost. If an existing app ID is specified, the app spec is treated as a proposed update to the existing app.

```php
function appsValidateAppSpec(V2AppsProposeRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2AppsProposeRequest`](../../doc/models/v2-apps-propose-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsProposeResponse`](../../doc/models/v2-apps-propose-response.md).

## Example Usage

```php
$body = V2AppsProposeRequestBuilder::init(
    AppSpecBuilder::init(
        'web-app'
    )
        ->region(Region1::NYC)
        ->services(
            [
                ServiceBuilder::init(
                    'api'
                )
                    ->environmentSlug('node-js')
                    ->github(
                        GithubBuilder::init()
                            ->branch('main')
                            ->deployOnPush(true)
                            ->repo('digitalocean/sample-golang')
                            ->build()
                    )
                    ->runCommand('bin/api')
                    ->instanceCount(2)
                    ->instanceSizeSlug(InstanceSizeSlug::BASICXXS)
                    ->routes(
                        [
                            ACriterionForRoutingHttpTrafficToAComponentBuilder::init()
                                ->path('/api')
                                ->build()
                        ]
                    )
                    ->build()
            ]
        )
        ->build()
)
    ->appId('b6bdf840-2854-4f87-a36c-5f231c617c84')
    ->build();

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsValidateAppSpec($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsProposeResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "app_cost": 5,
  "app_name_available": true,
  "app_tier_upgrade_cost": 17,
  "existing_static_apps": "2",
  "max_free_static_apps": "3",
  "spec": {
    "name": "sample-golang",
    "region": "ams",
    "services": [
      {
        "environment_slug": "go",
        "github": {
          "branch": "branch",
          "repo": "digitalocean/sample-golang"
        },
        "http_port": 8080,
        "instance_count": 1,
        "instance_size_slug": "basic-xxs",
        "name": "web",
        "routes": [
          {
            "path": "/"
          }
        ],
        "run_command": "bin/sample-golang"
      }
    ]
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Regions

List all regions supported by App Platform.

```php
function appsListRegions(): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: A JSON object with key `regions`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsRegionsResponse`](../../doc/models/v2-apps-regions-response.md).

## Example Usage

```php
$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsListRegions();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsRegionsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "regions": [
    {
      "continent": "Europe",
      "data_centers": [
        "ams3"
      ],
      "flag": "netherlands",
      "label": "Amsterdam",
      "slug": "ams"
    },
    {
      "continent": "North America",
      "data_centers": [
        "nyc1",
        "nyc3"
      ],
      "default": true,
      "flag": "usa",
      "label": "New York",
      "slug": "nyc"
    },
    {
      "continent": "Europe",
      "data_centers": [
        "fra1"
      ],
      "flag": "germany",
      "label": "Frankfurt",
      "slug": "fra"
    },
    {
      "continent": "North America",
      "data_centers": [
        "sfo3"
      ],
      "flag": "usa",
      "label": "San Francisco",
      "slug": "sfo"
    },
    {
      "continent": "Asia",
      "data_centers": [
        "sgp1"
      ],
      "flag": "singapore",
      "label": "Singapore",
      "slug": "sgp"
    },
    {
      "continent": "Asia",
      "data_centers": [
        "blr1"
      ],
      "flag": "india",
      "label": "Bangalore",
      "slug": "blr"
    },
    {
      "continent": "North America",
      "data_centers": [
        "tor1"
      ],
      "flag": "canada",
      "label": "Toronto",
      "slug": "tor"
    },
    {
      "continent": "Europe",
      "data_centers": [
        "lon1"
      ],
      "flag": "uk",
      "label": "London",
      "slug": "lon"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Tiers

List all app tiers.

```php
function appsListTiers(): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: A JSON object with a `tiers` key. This will be a list of all app tiers

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsTiersResponse`](../../doc/models/v2-apps-tiers-response.md).

## Example Usage

```php
$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsListTiers();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsTiersResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "tiers": [
    {
      "build_seconds": "6000",
      "egress_bandwidth_bytes": "1073741824",
      "name": "Starter",
      "slug": "starter"
    },
    {
      "build_seconds": "24000",
      "egress_bandwidth_bytes": "42949672960",
      "name": "Basic",
      "slug": "basic"
    },
    {
      "build_seconds": "60000",
      "egress_bandwidth_bytes": "107374182400",
      "name": "Professional",
      "slug": "professional"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Instance Sizes

List all instance sizes for `service`, `worker`, and `job` components.

```php
function appsListInstanceSizes(): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: A JSON with key `instance_sizes`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsTiersInstanceSizesResponse`](../../doc/models/v2-apps-tiers-instance-sizes-response.md).

## Example Usage

```php
$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsListInstanceSizes();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsTiersInstanceSizesResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "instance_sizes": [
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "536870912",
      "name": "Basic XXS",
      "slug": "basic-xxs",
      "tier_slug": "basic",
      "tier_upgrade_to": "professional-xs",
      "usd_per_month": "5.00",
      "usd_per_second": "0.000002066799"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "1073741824",
      "name": "Basic XS",
      "slug": "basic-xs",
      "tier_slug": "basic",
      "tier_upgrade_to": "professional-xs",
      "usd_per_month": "10.00",
      "usd_per_second": "0.000004133598"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "2147483648",
      "name": "Basic S",
      "slug": "basic-s",
      "tier_slug": "basic",
      "tier_upgrade_to": "professional-s",
      "usd_per_month": "20.00",
      "usd_per_second": "0.000008267196"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "2",
      "memory_bytes": "4294967296",
      "name": "Basic M",
      "slug": "basic-m",
      "tier_slug": "basic",
      "tier_upgrade_to": "professional-m",
      "usd_per_month": "40.00",
      "usd_per_second": "0.000016534392"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "1073741824",
      "name": "Professional XS",
      "slug": "professional-xs",
      "tier_downgrade_to": "basic-xs",
      "tier_slug": "professional",
      "usd_per_month": "12.00",
      "usd_per_second": "0.000004960317"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "2147483648",
      "name": "Professional S",
      "slug": "professional-s",
      "tier_downgrade_to": "basic-s",
      "tier_slug": "professional",
      "usd_per_month": "25.00",
      "usd_per_second": "0.000010333995"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "2",
      "memory_bytes": "4294967296",
      "name": "Professional M",
      "slug": "professional-m",
      "tier_downgrade_to": "basic-s",
      "tier_slug": "professional",
      "usd_per_month": "50.00",
      "usd_per_second": "0.000020667989"
    },
    {
      "cpu_type": "DEDICATED",
      "cpus": "1",
      "memory_bytes": "4294967296",
      "name": "Professional 1L",
      "slug": "professional-1l",
      "tier_downgrade_to": "basic-m",
      "tier_slug": "professional",
      "usd_per_month": "75.00",
      "usd_per_second": "0.000031001984"
    },
    {
      "cpu_type": "DEDICATED",
      "cpus": "2",
      "memory_bytes": "8589934592",
      "name": "Professional L",
      "slug": "professional-l",
      "tier_downgrade_to": "basic-s",
      "tier_slug": "professional",
      "usd_per_month": "150.00",
      "usd_per_second": "0.000062003968"
    },
    {
      "cpu_type": "DEDICATED",
      "cpus": "4",
      "memory_bytes": "17179869184",
      "name": "Professional XL",
      "slug": "professional-xl",
      "tier_downgrade_to": "basic-s",
      "tier_slug": "professional",
      "usd_per_month": "300.00",
      "usd_per_second": "0.000124007937"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Instance Size

Retrieve information about a specific instance size for `service`, `worker`, and `job` components.

```php
function appsGetInstanceSize(string $slug): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `string` | Template, Required | The slug of the instance size |

## Response Type

**200**: A JSON with key `instance_size`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsTiersInstanceSizesResponse1`](../../doc/models/v2-apps-tiers-instance-sizes-response-1.md).

## Example Usage

```php
$slug = 'basic-xxs';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGetInstanceSize($slug);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsTiersInstanceSizesResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "instance_size": {
    "cpu_type": "SHARED",
    "cpus": "1",
    "memory_bytes": "536870912",
    "name": "Basic XXS",
    "slug": "basic-xxs",
    "tier_slug": "basic",
    "tier_upgrade_to": "professional-xs",
    "usd_per_month": "5.00",
    "usd_per_second": "0.000002066799"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Tier

Retrieve information about a specific app tier.

```php
function appsGetTier(string $slug): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `string` | Template, Required | The slug of the tier |

## Response Type

**200**: A JSON with the key `tier`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsTiersResponse1`](../../doc/models/v2-apps-tiers-response-1.md).

## Example Usage

```php
$slug = 'basic';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGetTier($slug);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsTiersResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "tier": {
    "build_seconds": "24000",
    "egress_bandwidth_bytes": "42949672960",
    "name": "Basic",
    "slug": "basic"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Alerts

List alerts associated to the app and any components. This includes configuration information about the alerts including emails, slack webhooks, and triggering events or conditions.

```php
function appsListAlerts(string $appId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |

## Response Type

**200**: A JSON object with a `alerts` key. This is list of object `alerts`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsAlertsResponse`](../../doc/models/v2-apps-alerts-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsListAlerts($appId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsAlertsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "alerts": [
    {
      "emails": [
        "sammy@digitalocean.com"
      ],
      "id": "e552e1f9-c1b0-4e6d-8777-ad6f27767306",
      "phase": "ACTIVE",
      "progress": {
        "steps": [
          {
            "ended_at": "2020-07-28T18:00:00Z",
            "name": "alert-configure-insight-alert",
            "started_at": "2020-07-28T18:00:00Z",
            "status": "SUCCESS"
          }
        ]
      },
      "spec": {
        "rule": "DEPLOYMENT_FAILED"
      }
    },
    {
      "emails": [
        "sammy@digitalocean.com"
      ],
      "id": "b58cc9d4-0702-4ffd-ab45-4c2a8d979527",
      "phase": "ACTIVE",
      "progress": {
        "steps": [
          {
            "ended_at": "2020-07-28T18:00:00Z",
            "name": "alert-configure-insight-alert",
            "started_at": "2020-07-28T18:00:00Z",
            "status": "SUCCESS"
          }
        ]
      },
      "spec": {
        "operator": "GREATER_THAN",
        "rule": "CPU_UTILIZATION",
        "value": 85,
        "window": "FIVE_MINUTES"
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Assign Alert Destinations

Updates the emails and slack webhook destinations for app alerts. Emails must be associated to a user with access to the app.

```php
function appsAssignAlertDestinations(
    string $appId,
    string $alertId,
    V2AppsAlertsDestinationsRequest $body
): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `alertId` | `string` | Template, Required | The alert ID |
| `body` | [`V2AppsAlertsDestinationsRequest`](../../doc/models/v2-apps-alerts-destinations-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with an `alert` key. This is an object of type `alert`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsAlertsDestinationsResponse`](../../doc/models/v2-apps-alerts-destinations-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$alertId = '5a624ab5-dd58-4b39-b7dd-8b7c36e8a91d';

$body = V2AppsAlertsDestinationsRequestBuilder::init()
    ->emails(
        [
            'sammy@digitalocean.com'
        ]
    )
    ->build();

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsAssignAlertDestinations(
    $appId,
    $alertId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsAlertsDestinationsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "alert": {
    "emails": [
      "sammy@digitalocean.com"
    ],
    "id": "e552e1f9-c1b0-4e6d-8777-ad6f27767306",
    "phase": "ACTIVE",
    "progress": {
      "steps": [
        {
          "ended_at": "2020-07-28T18:00:00Z",
          "name": "alert-configure-insight-alert",
          "started_at": "2020-07-28T18:00:00Z",
          "status": "SUCCESS"
        }
      ]
    },
    "spec": {
      "rule": "DEPLOYMENT_FAILED"
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Logs Active Deployment

Retrieve the logs of the active deployment if one exists. The response will include links to either real-time logs of an in-progress or active deployment or archived logs of a past deployment. Note log_type=BUILD logs will return logs associated with the current active deployment (being served). To view build logs associated with in-progress build, the query must explicitly reference the deployment id.

```php
function appsGetLogsActiveDeployment(
    string $appId,
    string $componentName,
    string $type,
    ?bool $follow = null,
    ?string $podConnectionTimeout = null
): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `componentName` | `string` | Template, Required | An optional component name. If set, logs will be limited to this component only. |
| `type` | [`string(Type3)`](../../doc/models/type-3.md) | Query, Required | The type of logs to retrieve<br><br>- BUILD: Build-time logs<br>- DEPLOY: Deploy-time logs<br>- RUN: Live run-time logs |
| `follow` | `?bool` | Query, Optional | Whether the logs should follow live updates. |
| `podConnectionTimeout` | `?string` | Query, Optional | An optional time duration to wait if the underlying component instance is not immediately available. Default: `3m`. |

## Response Type

**200**: A JSON object with urls that point to archived logs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsComponentsLogsResponse`](../../doc/models/v2-apps-components-logs-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$componentName = 'component';

$type = Type3::BUILD;

$follow = true;

$podConnectionTimeout = '3m';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGetLogsActiveDeployment(
    $appId,
    $componentName,
    $type,
    $follow,
    $podConnectionTimeout
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsComponentsLogsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "historic_logs": [
    "https://logs-example/archive/build.log"
  ],
  "live_url": "https://logs-example/build.log",
  "url": "https://logs/build.log"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Deployments

List all deployments of an app.

```php
function appsListDeployments(string $appId, ?int $page = 1, ?int $perPage = 20): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |

## Response Type

**200**: A JSON object with a `deployments` key. This will be a list of all app deployments

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsDeploymentsResponse`](../../doc/models/v2-apps-deployments-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$page = 1;

$perPage = 2;

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsListDeployments(
    $appId,
    $page,
    $perPage
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsDeploymentsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "deployments": [
    {
      "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
      "created_at": "2020-07-28T18:00:00Z",
      "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
      "phase": "PENDING_BUILD",
      "phase_last_updated_at": "0001-01-01T00:00:00Z",
      "progress": {
        "pending_steps": 6,
        "steps": [
          {
            "name": "build",
            "status": "PENDING",
            "steps": [
              {
                "name": "initialize",
                "status": "PENDING"
              },
              {
                "name": "components",
                "status": "PENDING",
                "steps": [
                  {
                    "component_name": "web",
                    "message_base": "Building service",
                    "name": "web",
                    "status": "PENDING"
                  }
                ]
              }
            ]
          },
          {
            "name": "deploy",
            "status": "PENDING",
            "steps": [
              {
                "name": "initialize",
                "status": "PENDING"
              },
              {
                "name": "components",
                "status": "PENDING",
                "steps": [
                  {
                    "component_name": "web",
                    "name": "web",
                    "status": "PENDING",
                    "steps": [
                      {
                        "component_name": "web",
                        "message_base": "Deploying service",
                        "name": "deploy",
                        "status": "PENDING"
                      },
                      {
                        "component_name": "web",
                        "message_base": "Waiting for service",
                        "name": "wait",
                        "status": "PENDING"
                      }
                    ]
                  }
                ]
              },
              {
                "name": "finalize",
                "status": "PENDING"
              }
            ]
          }
        ],
        "total_steps": 6
      },
      "services": [
        {
          "name": "web",
          "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
        }
      ],
      "spec": {
        "name": "sample-golang",
        "region": "ams",
        "services": [
          {
            "environment_slug": "go",
            "github": {
              "branch": "branch",
              "repo": "digitalocean/sample-golang"
            },
            "instance_count": 2,
            "instance_size_slug": "basic-xxs",
            "name": "web",
            "routes": [
              {
                "path": "/"
              }
            ],
            "run_command": "bin/sample-golang"
          }
        ]
      },
      "tier_slug": "basic",
      "updated_at": "2020-07-28T18:00:00Z"
    }
  ],
  "links": {
    "pages": {}
  },
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Create Deployment

Creating an app deployment will pull the latest changes from your repository and schedule a new deployment for your app.

```php
function appsCreateDeployment(string $appId, V2AppsDeploymentsRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `body` | [`V2AppsDeploymentsRequest`](../../doc/models/v2-apps-deployments-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with a `deployment` key.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$body = V2AppsDeploymentsRequestBuilder::init()
    ->forceBuild(true)
    ->build();

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsCreateDeployment(
    $appId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsDeploymentsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Deployment

Retrieve information about an app deployment.

```php
function appsGetDeployment(string $appId, string $deploymentId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `deploymentId` | `string` | Template, Required | The deployment ID |

## Response Type

**200**: A JSON of the requested deployment

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$deploymentId = '3aa4d20e-5527-4c00-b496-601fbd22520a';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGetDeployment(
    $appId,
    $deploymentId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsDeploymentsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Cancel Deployment

Immediately cancel an in-progress deployment.

```php
function appsCancelDeployment(string $appId, string $deploymentId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `deploymentId` | `string` | Template, Required | The deployment ID |

## Response Type

**200**: A JSON the `deployment` that was just cancelled.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$deploymentId = '3aa4d20e-5527-4c00-b496-601fbd22520a';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsCancelDeployment(
    $appId,
    $deploymentId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsDeploymentsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Logs

Retrieve the logs of a past, in-progress, or active deployment. The response will include links to either real-time logs of an in-progress or active deployment or archived logs of a past deployment.

```php
function appsGetLogs(
    string $appId,
    string $deploymentId,
    string $componentName,
    string $type,
    ?bool $follow = null,
    ?string $podConnectionTimeout = null
): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `deploymentId` | `string` | Template, Required | The deployment ID |
| `componentName` | `string` | Template, Required | An optional component name. If set, logs will be limited to this component only. |
| `type` | [`string(Type3)`](../../doc/models/type-3.md) | Query, Required | The type of logs to retrieve<br><br>- BUILD: Build-time logs<br>- DEPLOY: Deploy-time logs<br>- RUN: Live run-time logs |
| `follow` | `?bool` | Query, Optional | Whether the logs should follow live updates. |
| `podConnectionTimeout` | `?string` | Query, Optional | An optional time duration to wait if the underlying component instance is not immediately available. Default: `3m`. |

## Response Type

**200**: A JSON object with urls that point to archived logs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsComponentsLogsResponse`](../../doc/models/v2-apps-components-logs-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$deploymentId = '3aa4d20e-5527-4c00-b496-601fbd22520a';

$componentName = 'component';

$type = Type3::BUILD;

$follow = true;

$podConnectionTimeout = '3m';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGetLogs(
    $appId,
    $deploymentId,
    $componentName,
    $type,
    $follow,
    $podConnectionTimeout
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsComponentsLogsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "historic_logs": [
    "https://logs-example/archive/build.log"
  ],
  "live_url": "https://logs-example/build.log",
  "url": "https://logs/build.log"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Logs Aggregate

Retrieve the logs of a past, in-progress, or active deployment. If a component name is specified, the logs will be limited to only that component. The response will include links to either real-time logs of an in-progress or active deployment or archived logs of a past deployment.

```php
function appsGetLogsAggregate(
    string $appId,
    string $deploymentId,
    string $type,
    ?bool $follow = null,
    ?string $podConnectionTimeout = null
): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `deploymentId` | `string` | Template, Required | The deployment ID |
| `type` | [`string(Type3)`](../../doc/models/type-3.md) | Query, Required | The type of logs to retrieve<br><br>- BUILD: Build-time logs<br>- DEPLOY: Deploy-time logs<br>- RUN: Live run-time logs |
| `follow` | `?bool` | Query, Optional | Whether the logs should follow live updates. |
| `podConnectionTimeout` | `?string` | Query, Optional | An optional time duration to wait if the underlying component instance is not immediately available. Default: `3m`. |

## Response Type

**200**: A JSON object with urls that point to archived logs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsComponentsLogsResponse`](../../doc/models/v2-apps-components-logs-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$deploymentId = '3aa4d20e-5527-4c00-b496-601fbd22520a';

$type = Type3::BUILD;

$follow = true;

$podConnectionTimeout = '3m';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGetLogsAggregate(
    $appId,
    $deploymentId,
    $type,
    $follow,
    $podConnectionTimeout
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsComponentsLogsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "historic_logs": [
    "https://logs-example/archive/build.log"
  ],
  "live_url": "https://logs-example/build.log",
  "url": "https://logs/build.log"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Logs Active Deployment Aggregate

Retrieve the logs of the active deployment if one exists. The response will include links to either real-time logs of an in-progress or active deployment or archived logs of a past deployment. Note log_type=BUILD logs will return logs associated with the current active deployment (being served). To view build logs associated with in-progress build, the query must explicitly reference the deployment id.

```php
function appsGetLogsActiveDeploymentAggregate(
    string $appId,
    string $type,
    ?bool $follow = null,
    ?string $podConnectionTimeout = null
): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `type` | [`string(Type3)`](../../doc/models/type-3.md) | Query, Required | The type of logs to retrieve<br><br>- BUILD: Build-time logs<br>- DEPLOY: Deploy-time logs<br>- RUN: Live run-time logs |
| `follow` | `?bool` | Query, Optional | Whether the logs should follow live updates. |
| `podConnectionTimeout` | `?string` | Query, Optional | An optional time duration to wait if the underlying component instance is not immediately available. Default: `3m`. |

## Response Type

**200**: A JSON object with urls that point to archived logs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsComponentsLogsResponse`](../../doc/models/v2-apps-components-logs-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$type = Type3::BUILD;

$follow = true;

$podConnectionTimeout = '3m';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGetLogsActiveDeploymentAggregate(
    $appId,
    $type,
    $follow,
    $podConnectionTimeout
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsComponentsLogsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "historic_logs": [
    "https://logs-example/archive/build.log"
  ],
  "live_url": "https://logs-example/build.log",
  "url": "https://logs/build.log"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Metrics Bandwidth Daily

Retrieve daily bandwidth usage metrics for a single app.

```php
function appsGetMetricsBandwidthDaily(string $appId, ?\DateTime $date = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `date` | `?DateTime` | Query, Optional | Optional day to query. Only the date component of the timestamp will be considered. Default: yesterday. |

## Response Type

**200**: A JSON object with a `app_bandwidth_usage` key

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsMetricsBandwidthDailyResponse`](../../doc/models/v2-apps-metrics-bandwidth-daily-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$date = DateTimeHelper::fromRfc3339DateTime('01/17/2023 00:00:00');

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGetMetricsBandwidthDaily(
    $appId,
    $date
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsMetricsBandwidthDailyResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "app_bandwidth_usage": [
    {
      "app_id": "4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf",
      "bandwidth_bytes": "513668"
    }
  ],
  "date": "2023-01-17T00:00:00Z"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Create Rollback

Rollback an app to a previous deployment. A new deployment will be created to perform the rollback.
The app will be pinned to the rollback deployment preventing any new deployments from being created,
either manually or through Auto Deploy on Push webhooks. To resume deployments, the rollback must be
either committed or reverted.

It is recommended to use the Validate App Rollback endpoint to double check if the rollback is
valid and if there are any warnings.

```php
function appsCreateRollback(string $appId, V2AppsRollbackRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `body` | [`V2AppsRollbackRequest`](../../doc/models/v2-apps-rollback-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with a `deployment` key.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$body = V2AppsRollbackRequestBuilder::init()
    ->deploymentId('3aa4d20e-5527-4c00-b496-601fbd22520a')
    ->skipPin(false)
    ->build();

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsCreateRollback(
    $appId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsDeploymentsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Commit Rollback

Commit an app rollback. This action permanently applies the rollback and unpins the app to resume new deployments.

```php
function appsCommitRollback(string $appId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |

## Response Type

**200**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsCommitRollback($appId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Revert Rollback

Revert an app rollback. This action reverts the active rollback by creating a new deployment from the
latest app spec prior to the rollback and unpins the app to resume new deployments.

```php
function appsRevertRollback(string $appId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |

## Response Type

**200**: A JSON object with a `deployment` key.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsRevertRollback($appId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsDeploymentsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Validate Rollback

Check whether an app can be rolled back to a specific deployment. This endpoint can also be used
to check if there are any warnings or validation conditions that will cause the rollback to proceed
under unideal circumstances. For example, if a component must be rebuilt as part of the rollback
causing it to take longer than usual.

```php
function appsValidateRollback(string $appId, V2AppsRollbackRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string` | Template, Required | The app ID |
| `body` | [`V2AppsRollbackRequest`](../../doc/models/v2-apps-rollback-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with the validation results.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsRollbackValidateResponse`](../../doc/models/v2-apps-rollback-validate-response.md).

## Example Usage

```php
$appId = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$body = V2AppsRollbackRequestBuilder::init()
    ->deploymentId('3aa4d20e-5527-4c00-b496-601fbd22520a')
    ->skipPin(false)
    ->build();

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsValidateRollback(
    $appId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsRollbackValidateResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "code": "incompatible_result",
    "message": "deployment result \"failed\" is unsuitable for rollback"
  },
  "valid": false
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Delete

Delete an existing app. Once deleted, all active deployments will be permanently shut down and the app deleted. If needed, be sure to back up your app specification so that you may re-create it at a later time.

```php
function appsDelete(string $id): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The ID of the app |

## Response Type

**200**: the ID of the app deleted.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsResponse2`](../../doc/models/v2-apps-response-2.md).

## Example Usage

```php
$id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsDelete($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsResponse2:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "id": "b7d64052-3706-4cb7-b21a-c5a2f44e63b3"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get

Retrieve details about an existing app by either its ID or name. To retrieve an app by its name, do not include an ID in the request path. Information about the current active deployment as well as any in progress ones will also be included in the response.

```php
function appsGet(string $id, ?string $name = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The ID of the app |
| `name` | `?string` | Query, Optional | The name of the app to retrieve. |

## Response Type

**200**: A JSON with key `app`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsResponse1`](../../doc/models/v2-apps-response-1.md).

## Example Usage

```php
$id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$name = 'myApp';

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsGet(
    $id,
    $name
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Update

Update an existing app by submitting a new app specification. For documentation on app specifications (`AppSpec` objects), please refer to [the product documentation](https://docs.digitalocean.com/products/app-platform/reference/app-spec/).

```php
function appsUpdate(string $id, V2AppsRequest1 $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The ID of the app |
| `body` | [`V2AppsRequest1`](../../doc/models/v2-apps-request-1.md) | Body, Required | - |

## Response Type

**200**: A JSON object of the updated `app`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AppsResponse1`](../../doc/models/v2-apps-response-1.md).

## Example Usage

```php
$id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf';

$body = V2AppsRequest1Builder::init(
    AppSpecBuilder::init(
        'web-app-01'
    )
        ->region(Region1::NYC)
        ->build()
)->build();

$appsApi = $client->getAppsApi();
$apiResponse = $appsApi->appsUpdate(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AppsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

