
# V2 Databases Resize Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesResizeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `num_nodes` | `Integer` | Required | The number of nodes in the database cluster. Valid values are are 1-3. In addition to the primary node, up to two standby nodes may be added for highly available configurations. |
| `size` | `String` | Required | A slug identifier representing desired the size of the nodes in the database cluster. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_resize_request = V2DatabasesResizeRequest.new(
  num_nodes: 3,
  size: 'db-s-4vcpu-8gb',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

