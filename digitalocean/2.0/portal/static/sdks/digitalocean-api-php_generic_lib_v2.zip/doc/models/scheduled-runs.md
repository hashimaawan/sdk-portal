
# Scheduled Runs

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`ScheduledRuns`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `lastRunAt` | `?string` | Optional | Indicates last run time. null value indicates trigger not run yet. | getLastRunAt(): ?string | setLastRunAt(?string lastRunAt): void |
| `nextRunAt` | `?string` | Optional | Indicates next run time. null value indicates trigger will not run. | getNextRunAt(): ?string | setNextRunAt(?string nextRunAt): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\ScheduledRunsBuilder;
use DigitalOceanApiLib\ApiHelper;

$scheduledRuns = ScheduledRunsBuilder::init()
    ->lastRunAt('2022-11-11T04:16:45Z')
    ->nextRunAt('2022-11-11T04:16:45Z')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

