
# X Amz Target 56 Enum

## Enumeration

`XAmzTarget56Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNotebook` |

## Example

```ts
import { XAmzTarget56Enum } from 'amazon-athenalib';

const xAmzTarget56 = XAmzTarget56Enum.EnumAmazonAthenaUpdateNotebook;
```

