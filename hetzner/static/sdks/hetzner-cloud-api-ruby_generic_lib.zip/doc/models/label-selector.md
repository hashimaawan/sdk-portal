
# Label Selector

## Structure

`LabelSelector`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `String` | Required | Label selector |

## Example

```ruby
label_selector = LabelSelector.new(
  'env=prod'
)
```

