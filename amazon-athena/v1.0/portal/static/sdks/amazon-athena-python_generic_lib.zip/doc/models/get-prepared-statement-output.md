
# Get Prepared Statement Output

## Structure

`GetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prepared_statement` | [`PreparedStatement1`](../../doc/models/prepared-statement-1.md) | Optional | - |

## Example

```python
import dateutil.parser

from amazonathena.models.get_prepared_statement_output import GetPreparedStatementOutput
from amazonathena.models.prepared_statement_1 import PreparedStatement1

get_prepared_statement_output = GetPreparedStatementOutput(
    prepared_statement=PreparedStatement1(
        statement_name='StatementName4',
        query_statement='QueryStatement8',
        work_group_name='WorkGroupName8',
        description='Description0',
        last_modified_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z')
    )
)
```

