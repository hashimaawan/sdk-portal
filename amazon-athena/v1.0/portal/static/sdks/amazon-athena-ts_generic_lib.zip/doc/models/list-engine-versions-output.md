
# List Engine Versions Output

## Structure

`ListEngineVersionsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `engineVersions` | [`EngineVersion[] \| undefined`](../../doc/models/engine-version.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListEngineVersionsOutput } from 'amazon-athenalib';

const listEngineVersionsOutput: ListEngineVersionsOutput = {
  engineVersions: [
    {
      selectedEngineVersion: 'SelectedEngineVersion2',
      effectiveEngineVersion: 'EffectiveEngineVersion2',
    }
  ],
  nextToken: 'NextToken0',
};
```

