
# Meta

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination` | [`Pagination`](../../doc/models/pagination.md) | Required | - |

## Example

```ruby
meta = Meta.new(
  Pagination.new(
    4,
    4,
    3,
    25,
    2,
    100
  )
)
```

