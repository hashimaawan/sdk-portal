
# Data Catalog Type

## Enumeration

`DataCatalogType`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```php
use AmazonAthenaLib\Models\DataCatalogType;

$dataCatalogType = DataCatalogType::HIVE;
```

