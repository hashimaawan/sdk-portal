
# Get Database Output

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | [`Database2`](../../doc/models/database-2.md) | Optional | - |

## Example

```python
from amazonathena.models.database_2 import Database2
from amazonathena.models.get_database_output import GetDatabaseOutput
from amazonathena.models.parameters import Parameters

get_database_output = GetDatabaseOutput(
    database=Database2(
        name='Name2',
        description='Description8',
        parameters=Parameters()
    )
)
```

