
# Get Session Status Request

## Structure

`GetSessionStatusRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SessionId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getSessionId() | setSessionId(String sessionId) |

## Example

```java
import com.amazonaws.useast1.athena.models.GetSessionStatusRequest;

GetSessionStatusRequest getSessionStatusRequest = new GetSessionStatusRequest.Builder(
    "SessionId6"
)
.build();
```

