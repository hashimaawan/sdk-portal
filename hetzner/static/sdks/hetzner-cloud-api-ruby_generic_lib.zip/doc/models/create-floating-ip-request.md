
# Create Floating IP Request

## Structure

`CreateFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `String` | Optional | - |
| `home_location` | `String` | Optional | Home Location (routing is optimized for that Location). Only optional if Server argument is passed. |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | - |
| `server` | `Integer` | Optional | Server to assign the Floating IP to |
| `type` | [`Type17Enum`](../../doc/models/type-17-enum.md) | Required | Floating IP type |

## Example

```ruby
create_floating_ip_request = CreateFloatingIPRequest.new(
  Type17Enum::IPV4,
  'Web Frontend',
  'fsn1',
  { 'labelkey' => 'value' },
  'Web Frontend',
  42
)
```

