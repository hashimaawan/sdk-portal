
# Statistics 1

## Structure

`Statistics1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DpuExecutionInMillis` | `*int` | Optional | - |
| `Progress` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    statistics1 := models.Statistics1{
        DpuExecutionInMillis: models.ToPointer(148),
        Progress:             models.ToPointer("Progress4"),
    }

}
```

