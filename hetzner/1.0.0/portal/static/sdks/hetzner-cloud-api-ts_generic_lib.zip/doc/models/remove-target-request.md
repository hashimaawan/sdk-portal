
# Remove Target Request

*This model accepts additional fields of type unknown.*

## Structure

`RemoveTargetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip` | [`Ip \| undefined`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. |
| `labelSelector` | [`LabelSelector12 \| undefined`](../../doc/models/label-selector-12.md) | Optional | Configuration for label selector targets, required if type is `label_selector` |
| `server` | [`Server16 \| undefined`](../../doc/models/server-16.md) | Optional | Configuration for type Server, required if type is `server` |
| `type` | [`Type29`](../../doc/models/type-29.md) | Required | Type of the resource |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { RemoveTargetRequest, Type29 } from 'hetzner-cloud-apilib';

const removeTargetRequest: RemoveTargetRequest = {
  type: Type29.Ip,
  ip: {
    ip: 'ip8',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  labelSelector: {
    selector: 'selector8',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  server: {
    id: 217.74,
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

