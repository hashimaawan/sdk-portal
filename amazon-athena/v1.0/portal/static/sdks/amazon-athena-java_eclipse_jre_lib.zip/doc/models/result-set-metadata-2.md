
# Result Set Metadata 2

*This model accepts additional fields of type Object.*

## Structure

`ResultSetMetadata2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ColumnInfo` | [`List<ColumnInfo>`](../../doc/models/column-info.md) | Optional | - | List<ColumnInfo> getColumnInfo() | setColumnInfo(List<ColumnInfo> columnInfo) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.models.ColumnInfo;
import com.amazonaws.useast1.athena.models.ResultSetMetadata2;
import java.io.IOException;
import java.util.Arrays;

ResultSetMetadata2 resultSetMetadata2 = new ResultSetMetadata2.Builder()
    .columnInfo(Arrays.asList(
        new ColumnInfo.Builder(
            "Name6",
            "Type6"
        )
        .catalogName("CatalogName0")
        .schemaName("SchemaName0")
        .tableName("TableName2")
        .label("Label4")
        .precision(48)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
        new ColumnInfo.Builder(
            "Name6",
            "Type6"
        )
        .catalogName("CatalogName0")
        .schemaName("SchemaName0")
        .tableName("TableName2")
        .label("Label4")
        .precision(48)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

