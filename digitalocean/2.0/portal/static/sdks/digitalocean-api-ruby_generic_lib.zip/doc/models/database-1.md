
# Database 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Database1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `connection` | [`Connection`](../../doc/models/connection.md) | Optional | - |
| `created_at` | `DateTime` | Optional, Read-only | A time value given in ISO8601 combined date and time format that represents when the database cluster was created. |
| `db_names` | `Array[String]` | Optional, Read-only | An array of strings containing the names of databases created in the database cluster. |
| `engine` | [`Engine1`](../../doc/models/engine-1.md) | Required | A slug representing the database engine used for the cluster. The possible values are: "pg" for PostgreSQL, "mysql" for MySQL, "redis" for Redis, and "mongodb" for MongoDB. |
| `id` | `UUID \| String` | Optional, Read-only | A unique ID that can be used to identify and reference a database cluster. |
| `maintenance_window` | [`MaintenanceWindow`](../../doc/models/maintenance-window.md) | Optional | - |
| `name` | `String` | Required | A unique, human-readable name referring to a database cluster. |
| `num_nodes` | `Integer` | Required | The number of nodes in the database cluster. |
| `private_connection` | [`PrivateConnection`](../../doc/models/private-connection.md) | Optional | - |
| `private_network_uuid` | `String` | Optional | A string specifying the UUID of the VPC to which the database cluster will be assigned. If excluded, the cluster when creating a new database cluster, it will be assigned to your account's default VPC for the region.<br><br>**Constraints**: *Pattern*: `^$\|[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}` |
| `project_id` | `UUID \| String` | Optional | The ID of the project that the database cluster is assigned to. If excluded when creating a new database cluster, it will be assigned to your default project. |
| `region` | `String` | Required | The slug identifier for the region where the database cluster is located. |
| `rules` | [`Array[Rule1]`](../../doc/models/rule-1.md) | Optional | - |
| `size` | `String` | Required | The slug identifier representing the size of the nodes in the database cluster. |
| `status` | [`Status4`](../../doc/models/status-4.md) | Optional, Read-only | A string representing the current status of the database cluster. |
| `tags` | `Array[String]` | Optional | An array of tags that have been applied to the database cluster. |
| `users` | [`Array[User]`](../../doc/models/user.md) | Optional, Read-only | - |
| `version` | `String` | Optional | A string representing the version of the database engine in use for the cluster. |
| `version_end_of_availability` | `String` | Optional, Read-only | A timestamp referring to the date when the particular version will no longer be available for creating new clusters. If null, the version does not have an end of availability timeline. |
| `version_end_of_life` | `String` | Optional, Read-only | A timestamp referring to the date when the particular version will no longer be supported. If null, the version does not have an end of life timeline. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
database1 = Database1.new(
  engine: Engine1::PG,
  name: 'backend',
  num_nodes: 2,
  region: 'nyc3',
  size: 'db-s-2vcpu-4gb',
  connection: Connection.new(
    database: 'database2',
    host: 'host0',
    password: 'password2',
    port: 174,
    ssl: false,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  created_at: DateTimeHelper.from_rfc3339('2019-01-11T18:37:36Z'),
  db_names: [
    'doadmin'
  ],
  id: '9cc10173-e9ea-4176-9dbc-a4cee4c4ff30',
  maintenance_window: MaintenanceWindow.new(
    day: 'day0',
    hour: 'hour8',
    description: [
      'description3',
      'description2'
    ],
    pending: false,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  private_network_uuid: 'd455e75d-4858-4eec-8c95-da2f0a5f93a7',
  project_id: '9cc10173-e9ea-4176-9dbc-a4cee4c4ff30',
  status: Status4::CREATING,
  tags: [
    'production'
  ],
  version: '10',
  version_end_of_availability: '2023-05-09T00:00:00Z',
  version_end_of_life: '2023-11-09T00:00:00Z',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

