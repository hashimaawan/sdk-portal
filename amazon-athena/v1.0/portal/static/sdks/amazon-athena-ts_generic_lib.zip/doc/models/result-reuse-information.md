
# Result Reuse Information

Contains information about whether the result of a previous query was reused.

## Structure

`ResultReuseInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reusedPreviousResult` | `boolean` | Required | - |

## Example

```ts
import { ResultReuseInformation } from 'amazon-athenalib';

const resultReuseInformation: ResultReuseInformation = {
  reusedPreviousResult: false,
};
```

