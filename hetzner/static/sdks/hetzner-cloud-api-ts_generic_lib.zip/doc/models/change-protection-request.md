
# Change Protection Request

## Structure

`ChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the Floating IP from being deleted |

## Example

```ts
import { ChangeProtectionRequest } from 'hetzner-cloud-apilib';

const changeProtectionRequest: ChangeProtectionRequest = {
  mDelete: true,
};
```

