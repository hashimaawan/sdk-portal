
# Health Status

*This model accepts additional fields of type interface{}.*

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ListenPort` | `*int` | Optional | - |
| `Status` | [`*models.Status30`](../../doc/models/status-30.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    healthStatus := models.HealthStatus{
        ListenPort:            models.ToPointer(443),
        Status:                models.ToPointer(models.Status30_Healthy),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

