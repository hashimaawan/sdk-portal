
# Add to Placement Group Request

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PlacementGroup` | `int` | Required | ID of Placement Group the Server should be added to | int getPlacementGroup() | setPlacementGroup(int placementGroup) |

## Example

```java
import cloud.hetzner.api.models.AddToPlacementGroupRequest;

AddToPlacementGroupRequest addToPlacementGroupRequest = new AddToPlacementGroupRequest.Builder(
    1
)
.build();
```

