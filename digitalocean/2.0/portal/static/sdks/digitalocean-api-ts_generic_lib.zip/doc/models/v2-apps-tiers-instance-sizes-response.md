
# V2 Apps Tiers Instance Sizes Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsTiersInstanceSizesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `discountPercent` | `number \| undefined` | Optional | - |
| `instanceSizes` | [`InstanceSize[] \| undefined`](../../doc/models/instance-size.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores,
  V2AppsTiersInstanceSizesResponse,
} from 'digitalocean-apilib';

const v2AppsTiersInstanceSizesResponse: V2AppsTiersInstanceSizesResponse = {
  discountPercent: 2.32,
  instanceSizes: [
    {
      cpuType: MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores.Dedicated,
      cpus: 'cpus4',
      memoryBytes: 'memory_bytes8',
      name: 'name8',
      slug: 'slug8',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

