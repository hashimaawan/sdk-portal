
# Update Server Request

## Structure

`UpdateServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Optional | New name to set |

## Example

```python
import jsonpickle

from hetznercloudapi.models.update_server_request import UpdateServerRequest

update_server_request = UpdateServerRequest(
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    name='my-server'
)
```

