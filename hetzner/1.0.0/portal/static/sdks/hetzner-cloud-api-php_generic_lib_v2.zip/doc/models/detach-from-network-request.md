
# Detach from Network Request

*This model accepts additional fields of type array.*

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `network` | `int` | Required | ID of an existing network to detach the Server from | getNetwork(): int | setNetwork(int network): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\DetachFromNetworkRequestBuilder;
use HetznerCloudApiLib\ApiHelper;

$detachFromNetworkRequest = DetachFromNetworkRequestBuilder::init(
    4711
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

