
# Server 9

Configuration for type server, required if type is `server`

## Structure

`Server9`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server | int getId() | setId(int id) |

## Example

```java
import cloud.hetzner.api.models.Server9;

Server9 server9 = new Server9.Builder(
    216
)
.build();
```

