
# Traffic

The cost of additional traffic per TB

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pricePerTb` | [`PricePerTb`](../../doc/models/price-per-tb.md) | Required | - | getPricePerTb(): PricePerTb | setPricePerTb(PricePerTb pricePerTb): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\TrafficBuilder;
use HetznerCloudAPILib\Models\Builders\PricePerTbBuilder;

$traffic = TrafficBuilder::init(
    PricePerTbBuilder::init(
        '1.1900000000000000',
        '1.0000000000'
    )->build()
)->build();
```

