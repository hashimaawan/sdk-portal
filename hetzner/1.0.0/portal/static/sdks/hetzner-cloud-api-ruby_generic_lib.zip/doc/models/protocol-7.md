
# Protocol 7

Protocol of the Load Balancer

## Enumeration

`Protocol7`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```ruby
protocol7 = Protocol7::HTTP
```

