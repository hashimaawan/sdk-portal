
# S3 Acl Option Enum

## Enumeration

`S3AclOptionEnum`

## Fields

| Name |
|  --- |
| `BUCKETOWNERFULLCONTROL` |

## Example

```ts
import { S3AclOptionEnum } from 'amazon-athenalib';

const s3AclOption = S3AclOptionEnum.BUCKETOWNERFULLCONTROL;
```

