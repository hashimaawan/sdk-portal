
# X Amz Target 29 Enum

## Enumeration

`XAmzTarget29Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETWORKGROUP` |

## Example

```python
from amazonathena.models.x_amz_target_29_enum import XAmzTarget29Enum

x_amz_target_29 = XAmzTarget29Enum.ENUM_AMAZONATHENAGETWORKGROUP
```

