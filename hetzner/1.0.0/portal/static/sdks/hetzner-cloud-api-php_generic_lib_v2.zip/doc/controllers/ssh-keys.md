# SSH Keys

```php
$sshKeysApi = $client->getSshKeysApi();
```

## Class Name

`SshKeysApi`

## Methods

* [Get All SSH Keys](../../doc/controllers/ssh-keys.md#get-all-ssh-keys)
* [Create an SSH Key](../../doc/controllers/ssh-keys.md#create-an-ssh-key)
* [Delete an SSH Key](../../doc/controllers/ssh-keys.md#delete-an-ssh-key)
* [Get a SSH Key](../../doc/controllers/ssh-keys.md#get-a-ssh-key)
* [Update an SSH Key](../../doc/controllers/ssh-keys.md#update-an-ssh-key)


# Get All SSH Keys

Returns all SSH key objects.

```php
function getAllSshKeys(
    ?string $sort = null,
    ?string $name = null,
    ?string $fingerprint = null,
    ?string $labelSelector = null
): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`?string(Sort8)`](../../doc/models/sort-8.md) | Query, Optional | Can be used multiple times. |
| `name` | `?string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `fingerprint` | `?string` | Query, Optional | Can be used to filter SSH keys by their fingerprint. The response will only contain the SSH key matching the specified fingerprint. |
| `labelSelector` | `?string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `ssh_keys` key in the reply contains an array of SSH key objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`SshKeysResponse`](../../doc/models/ssh-keys-response.md).

## Example Usage

```php
$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->getAllSshKeys();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'SshKeysResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Create an SSH Key

Creates a new SSH key with the given `name` and `public_key`. Once an SSH key is created, it can be used in other calls such as creating Servers.

```php
function createAnSshKey(?SshKeysRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?SshKeysRequest`](../../doc/models/ssh-keys-request.md) | Body, Optional | - |

## Response Type

**201**: The `ssh_key` key in the reply contains the object that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`SshKeysResponse1`](../../doc/models/ssh-keys-response-1.md).

## Example Usage

```php
$body = SshKeysRequestBuilder::init(
    'My ssh key',
    'ssh-rsa AAAjjk76kgf...Xt'
)->build();

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->createAnSshKey($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'SshKeysResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Delete an SSH Key

Deletes an SSH key. It cannot be used anymore.

```php
function deleteAnSshKey(string $id): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the SSH key |

## Response Type

**204**: SSH key deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$id = 'id0';

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->deleteAnSshKey($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Get a SSH Key

Returns a specific SSH key object.

```php
function getASshKey(int $id): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the SSH key |

## Response Type

**200**: The `ssh_key` key in the reply contains an SSH key object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`SshKeysResponse1`](../../doc/models/ssh-keys-response-1.md).

## Example Usage

```php
$id = 112;

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->getASshKey($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'SshKeysResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Update an SSH Key

Updates an SSH key. You can update an SSH key name and an SSH key labels.

Please note that when updating labels, the SSH key current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```php
function updateAnSshKey(string $id, ?SshKeysRequest1 $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the SSH key |
| `body` | [`?SshKeysRequest1`](../../doc/models/ssh-keys-request-1.md) | Body, Optional | - |

## Response Type

**200**: The `ssh_key` key in the reply contains the modified SSH key object with the new description

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`SshKeysResponse1`](../../doc/models/ssh-keys-response-1.md).

## Example Usage

```php
$id = 'id0';

$body = SshKeysRequest1Builder::init()
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('My ssh key')
    ->build();

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->updateAnSshKey(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'SshKeysResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "ssh_key": {
    "created": "2016-01-30T23:50:00+00:00",
    "fingerprint": "b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f",
    "id": 2323,
    "labels": {
      "labelkey": "value"
    },
    "name": "My ssh key",
    "public_key": "ssh-rsa AAAjjk76kgf...Xt"
  }
}
```

