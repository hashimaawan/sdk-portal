
# Action

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `Read` |
| `Create` |
| `Update` |
| `Delete` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

Action action = Action.Update;
```

