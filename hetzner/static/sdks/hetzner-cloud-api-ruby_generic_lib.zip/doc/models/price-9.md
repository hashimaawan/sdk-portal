
# Price 9

## Structure

`Price9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location` | `String` | Required | Name of the Location the price is for |
| `price_hourly` | [`PriceHourly8`](../../doc/models/price-hourly-8.md) | Required | Hourly costs for a Server type in this Location |
| `price_monthly` | [`PriceMonthly10`](../../doc/models/price-monthly-10.md) | Required | Monthly costs for a Server type in this Location |

## Example

```ruby
price9 = Price9.new(
  'fsn1',
  PriceHourly8.new(
    '1.1900000000000000',
    '1.0000000000'
  ),
  PriceMonthly10.new(
    '1.1900000000000000',
    '1.0000000000'
  )
)
```

