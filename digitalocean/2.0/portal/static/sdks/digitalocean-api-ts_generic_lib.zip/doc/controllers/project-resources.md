# Project Resources

```ts
const projectResourcesApi = new ProjectResourcesApi(client);
```

## Class Name

`ProjectResourcesApi`

## Methods

* [Projects List Resources Default](../../doc/controllers/project-resources.md#projects-list-resources-default)
* [Projects Assign Resources Default](../../doc/controllers/project-resources.md#projects-assign-resources-default)
* [Projects List Resources](../../doc/controllers/project-resources.md#projects-list-resources)
* [Projects Assign Resources](../../doc/controllers/project-resources.md#projects-assign-resources)


# Projects List Resources Default

To list all your resources in your default project, send a GET request to `/v2/projects/default/resources`.

```ts
async projectsListResourcesDefault(
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2ProjectsDefaultResourcesResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse`](../../doc/models/v2-projects-default-resources-response.md).

## Example Usage

```ts
try {
  const response = await projectResourcesApi.projectsListResourcesDefault();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Projects Assign Resources Default

To assign resources to your default project, send a POST request to `/v2/projects/default/resources`.

```ts
async projectsAssignResourcesDefault(
  body: V2ProjectsDefaultResourcesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2ProjectsDefaultResourcesResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2ProjectsDefaultResourcesRequest`](../../doc/models/v2-projects-default-resources-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse1`](../../doc/models/v2-projects-default-resources-response-1.md).

## Example Usage

```ts
const body: V2ProjectsDefaultResourcesRequest = {
  resources: [
    'do:droplet:13457723',
    'do:domain:example.com'
  ],
};

try {
  const response = await projectResourcesApi.projectsAssignResourcesDefault(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Projects List Resources

To list all your resources in a project, send a GET request to `/v2/projects/$PROJECT_ID/resources`.

```ts
async projectsListResources(
  projectId: string,
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2ProjectsDefaultResourcesResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `projectId` | `string` | Template, Required | A unique identifier for a project. |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse`](../../doc/models/v2-projects-default-resources-response.md).

## Example Usage

```ts
const projectId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

const perPage = 2;

const page = 1;

try {
  const response = await projectResourcesApi.projectsListResources(
    projectId,
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Projects Assign Resources

To assign resources to a project, send a POST request to `/v2/projects/$PROJECT_ID/resources`.

```ts
async projectsAssignResources(
  projectId: string,
  body: V2ProjectsDefaultResourcesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2ProjectsDefaultResourcesResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `projectId` | `string` | Template, Required | A unique identifier for a project. |
| `body` | [`V2ProjectsDefaultResourcesRequest`](../../doc/models/v2-projects-default-resources-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse1`](../../doc/models/v2-projects-default-resources-response-1.md).

## Example Usage

```ts
const projectId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

const body: V2ProjectsDefaultResourcesRequest = {
  resources: [
    'do:droplet:13457723',
    'do:domain:example.com'
  ],
};

try {
  const response = await projectResourcesApi.projectsAssignResources(
    projectId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |

