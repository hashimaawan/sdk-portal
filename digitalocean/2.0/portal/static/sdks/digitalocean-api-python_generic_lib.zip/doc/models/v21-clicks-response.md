
# V21 Clicks Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V21ClicksResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `m_1_clicks` | [`List[M1Click]`](../../doc/models/m1-click.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.m_1_click import M1Click
from digitaloceanapi.models.v_21_clicks_response import V21ClicksResponse

v_2_1_clicks_response = V21ClicksResponse(
    m_1_clicks=[
        M1Click(
            slug='slug8',
            mtype='type2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        M1Click(
            slug='slug8',
            mtype='type2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

