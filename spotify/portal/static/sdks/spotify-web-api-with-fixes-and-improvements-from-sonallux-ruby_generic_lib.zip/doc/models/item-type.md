
# Item Type

## Enumeration

`ItemType`

## Fields

| Name |
|  --- |
| `ALBUM` |
| `ARTIST` |
| `PLAYLIST` |
| `TRACK` |
| `SHOW` |
| `EPISODE` |
| `AUDIOBOOK` |

## Example

```ruby
item_type = ItemType::SHOW
```

