
# Purpose

Some item types, Login and Password, have fields used for autofill. This property indicates that purpose and is required for some item types.

## Enumeration

`Purpose`

## Fields

| Name |
|  --- |
| `USERNAME` |
| `PASSWORD` |
| `NOTES` |

## Example

```php
use M1PasswordConnectLib\Models\Purpose;

$purpose = Purpose::PASSWORD;
```

