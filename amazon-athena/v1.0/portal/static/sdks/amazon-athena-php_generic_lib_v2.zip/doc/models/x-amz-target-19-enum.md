
# X Amz Target 19 Enum

## Enumeration

`XAmzTarget19Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATABASE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget19Enum;

$xAmzTarget19 = XAmzTarget19Enum::ENUM_AMAZONATHENAGETDATABASE;
```

