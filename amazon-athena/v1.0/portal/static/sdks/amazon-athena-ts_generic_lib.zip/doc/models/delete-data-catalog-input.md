
# Delete Data Catalog Input

## Structure

`DeleteDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ts
import { DeleteDataCatalogInput } from 'amazon-athenalib';

const deleteDataCatalogInput: DeleteDataCatalogInput = {
  name: 'Name2',
};
```

