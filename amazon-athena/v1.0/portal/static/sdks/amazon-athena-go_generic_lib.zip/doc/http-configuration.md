
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `0` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`amazonathenaRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `amazonathena.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "amazonathena"
    "net/http"
)

func main() {
    httpConfiguration := amazonathena.CreateHttpConfiguration(
        amazonathena.WithTimeout(0),
        amazonathena.WithTransport(http.DefaultTransport),
        amazonathena.WithRetryConfiguration(amazonathena.DefaultRetryConfiguration()),
    )
}
```

