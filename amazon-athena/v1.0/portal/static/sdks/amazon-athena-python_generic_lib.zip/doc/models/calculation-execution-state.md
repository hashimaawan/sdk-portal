
# Calculation Execution State

## Enumeration

`CalculationExecutionState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```python
from amazonathena.models.calculation_execution_state import CalculationExecutionState

calculation_execution_state = CalculationExecutionState.CANCELING
```

