
# Repository

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Repository`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `latest_tag` | [`LatestTag`](../../doc/models/latest-tag.md) | Optional | - |
| `name` | `String` | Optional | The name of the repository. |
| `registry_name` | `String` | Optional | The name of the container registry. |
| `tag_count` | `Integer` | Optional | The number of tags in the repository. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
repository = Repository.new(
  latest_tag: LatestTag.new(
    compressed_size_bytes: 108,
    manifest_digest: 'manifest_digest2',
    registry_name: 'registry_name4',
    repository: 'repository4',
    size_bytes: 226,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  name: 'repo-1',
  registry_name: 'example',
  tag_count: 1,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

