
# Update Floating IP Request

## Structure

`UpdateFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `String` | Optional | New Description to set |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New unique name to set |

## Example

```ruby
update_floating_ip_request = UpdateFloatingIPRequest.new(
  'Web Frontend',
  { 'labelkey' => 'value' },
  'Web Frontend'
)
```

