
# Issuance Enum

Status of the issuance process of the Certificate

## Enumeration

`IssuanceEnum`

## Fields

| Name |
|  --- |
| `PENDING` |
| `COMPLETED` |
| `FAILED` |

## Example

```java
import cloud.hetzner.api.models.IssuanceEnum;

IssuanceEnum issuance = IssuanceEnum.FAILED;
```

