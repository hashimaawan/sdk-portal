
# X Amz Target 4

## Enumeration

`XAmzTarget4`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_4 import XAmzTarget4

x_amz_target_4 = XAmzTarget4.ENUM_AMAZONATHENACREATENAMEDQUERY
```

