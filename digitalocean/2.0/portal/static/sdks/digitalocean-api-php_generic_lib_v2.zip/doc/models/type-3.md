
# Type 3

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `BUILD` |
| `DEPLOY` |
| `RUN` |

## Example

```php
use DigitalOceanApiLib\Models\Type3;

$type3 = Type3::DEPLOY;
```

