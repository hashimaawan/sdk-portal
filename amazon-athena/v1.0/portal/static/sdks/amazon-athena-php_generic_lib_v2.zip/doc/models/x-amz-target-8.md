
# X Amz Target 8

## Enumeration

`XAmzTarget8`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEWORKGROUP` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget8;

$xAmzTarget8 = XAmzTarget8::ENUM_AMAZONATHENACREATEWORKGROUP;
```

