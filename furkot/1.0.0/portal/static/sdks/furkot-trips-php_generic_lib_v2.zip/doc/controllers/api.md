# API

```php
$api = $client->getApi();
```

## Class Name

`Api`

## Methods

* [Trip GET](../../doc/controllers/api.md#trip-get)
* [Trip Stop by Trip Id GET](../../doc/controllers/api.md#trip-stop-by-trip-id-get)


# Trip GET

list user's trips

```php
function tripGet(): ApiResponse
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`Trip[]`](../../doc/models/trip.md).

## Example Usage

```php
$api = $client->getAPI();
$apiResponse = $api->tripGet();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'Trip[]:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Trip Stop by Trip Id GET

list stops for a trip identified by {trip_id}

```php
function tripStopByTripIdGet(string $tripId): ApiResponse
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tripId` | `string` | Template, Required | id of the trip |

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`Step[]`](../../doc/models/step.md).

## Example Usage

```php
$tripId = 'trip_id2';

$api = $client->getAPI();
$apiResponse = $api->tripStopByTripIdGet($tripId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'Step[]:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

