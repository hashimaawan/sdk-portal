
# Status 113 Enum

Current status of the Volume

## Enumeration

`Status113Enum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `AVAILABLE` |

## Example

```java
import cloud.hetzner.api.models.Status113Enum;

Status113Enum status113 = Status113Enum.CREATING;
```

