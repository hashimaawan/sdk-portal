
# X Amz Target 45

## Enumeration

`XAmzTarget45`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTWORKGROUPS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget45;

XAmzTarget45 xAmzTarget45 = XAmzTarget45.ENUM_AMAZONATHENALISTWORKGROUPS;
```

