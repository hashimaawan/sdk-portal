
# Resource Type

## Enumeration

`ResourceType`

## Fields

| Name |
|  --- |
| `Droplet` |
| `Volume` |

## Example

```ts
import { ResourceType } from 'digitalocean-apilib';

const resourceType = ResourceType.Droplet;
```

