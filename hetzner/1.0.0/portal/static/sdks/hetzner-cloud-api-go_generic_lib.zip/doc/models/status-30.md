
# Status 30

## Enumeration

`Status30`

## Fields

| Name |
|  --- |
| `Healthy` |
| `Unhealthy` |
| `Unknown` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    status30 := models.Status30_Healthy

}
```

