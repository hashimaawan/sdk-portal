
# X Amz Target 10

## Enumeration

`XAmzTarget10`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget10;

$xAmzTarget10 = XAmzTarget10::ENUM_AMAZONATHENADELETENAMEDQUERY;
```

