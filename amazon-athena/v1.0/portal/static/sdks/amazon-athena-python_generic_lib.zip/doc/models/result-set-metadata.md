
# Result Set Metadata

The metadata that describes the column structure and data types of a table of query results. To return a <code>ResultSetMetadata</code> object, use <a>GetQueryResults</a>.

## Structure

`ResultSetMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `column_info` | [`List[ColumnInfo]`](../../doc/models/column-info.md) | Optional | - |

## Example

```python
from amazonathena.models.column_info import ColumnInfo
from amazonathena.models.result_set_metadata import ResultSetMetadata

result_set_metadata = ResultSetMetadata(
    column_info=[
        ColumnInfo(
            name='Name6',
            mtype='Type6',
            catalog_name='CatalogName0',
            schema_name='SchemaName0',
            table_name='TableName2',
            label='Label4',
            precision=48
        )
    ]
)
```

