
# List Table Metadata Input

## Structure

`ListTableMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `DatabaseName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `Expression` | `*string` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `256` |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listTableMetadataInput := models.ListTableMetadataInput{
        CatalogName:          "CatalogName2",
        DatabaseName:         "DatabaseName2",
        Expression:           models.ToPointer("Expression0"),
        NextToken:            models.ToPointer("NextToken8"),
        MaxResults:           models.ToPointer(50),
    }

}
```

