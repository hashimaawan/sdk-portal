
# Status 24

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |
| `Unavailable` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Status24 status24 = Status24.Available;
```

