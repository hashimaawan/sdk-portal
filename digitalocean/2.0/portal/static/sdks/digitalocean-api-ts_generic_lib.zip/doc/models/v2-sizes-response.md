
# V2 Sizes Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2SizesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sizes` | [`Size[]`](../../doc/models/size.md) | Required | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2SizesResponse } from 'digitalocean-apilib';

const v2SizesResponse: V2SizesResponse = {
  sizes: [
    {
      available: true,
      description: 'Basic',
      disk: 25,
      memory: 1024,
      priceHourly: 0.00743999984115362,
      priceMonthly: 5,
      regions: [
        'ams2',
        'ams3',
        'blr1',
        'fra1',
        'lon1',
        'nyc1',
        'nyc2',
        'nyc3',
        'sfo1',
        'sfo2',
        'sfo3',
        'sgp1',
        'tor1'
      ],
      slug: 's-1vcpu-1gb',
      transfer: 1,
      vcpus: 1,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  meta: {
    total: 64,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  links: {
    pages: {
      last: 'https://api.digitalocean.com/v2/sizes?page=64&per_page=1',
      next: 'https://api.digitalocean.com/v2/sizes?page=2&per_page=1',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

