
# V2 Droplets Actions Request 24

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest24`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `kernel` | `Integer` | Optional | A unique number used to identify and reference a specific kernel. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_droplets_actions_request24 = V2DropletsActionsRequest24.new(
  type: Type12::REBOOT,
  kernel: 12389723,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

