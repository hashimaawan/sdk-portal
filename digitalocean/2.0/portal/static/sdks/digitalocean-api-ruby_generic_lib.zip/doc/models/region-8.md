
# Region 8

## Enumeration

`Region8`

## Fields

| Name |
|  --- |
| `US_EAST` |
| `US_WEST` |
| `EU_WEST` |
| `SE_ASIA` |

## Example

```ruby
region8 = Region8::US_EAST
```

