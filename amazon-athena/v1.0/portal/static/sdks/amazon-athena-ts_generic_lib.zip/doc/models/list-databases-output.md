
# List Databases Output

## Structure

`ListDatabasesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `databaseList` | [`Database[] \| undefined`](../../doc/models/database.md) | Optional | - |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListDatabasesOutput } from 'amazon-athenalib';

const listDatabasesOutput: ListDatabasesOutput = {
  databaseList: [
    {
      name: 'Name4',
      description: 'Description8',
      parameters: {},
    },
    {
      name: 'Name4',
      description: 'Description8',
      parameters: {},
    },
    {
      name: 'Name4',
      description: 'Description8',
      parameters: {},
    }
  ],
  nextToken: 'NextToken6',
};
```

