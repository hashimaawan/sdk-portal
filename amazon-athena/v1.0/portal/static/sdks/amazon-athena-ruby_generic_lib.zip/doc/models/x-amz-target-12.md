
# X Amz Target 12

## Enumeration

`XAmzTarget12`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target12 = XAmzTarget12::ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT
```

