
# Item Type

## Enumeration

`ItemType`

## Fields

| Name |
|  --- |
| `ALBUM` |
| `ARTIST` |
| `PLAYLIST` |
| `TRACK` |
| `SHOW` |
| `EPISODE` |
| `AUDIOBOOK` |

## Example

```php
use SpotifyWebApiWithFixesAndImprovementsFromSonalluxLib\Models\ItemType;

$itemType = ItemType::ARTIST;
```

