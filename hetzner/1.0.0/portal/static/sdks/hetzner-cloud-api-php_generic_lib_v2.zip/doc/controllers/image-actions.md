# Image Actions

```php
$imageActionsApi = $client->getImageActionsApi();
```

## Class Name

`ImageActionsApi`

## Methods

* [Get All Actions for an Image](../../doc/controllers/image-actions.md#get-all-actions-for-an-image)
* [Change Image Protection](../../doc/controllers/image-actions.md#change-image-protection)
* [Get an Action for an Image](../../doc/controllers/image-actions.md#get-an-action-for-an-image)


# Get All Actions for an Image

Returns all Action objects for an Image. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```php
function getAllActionsForAnImage(int $id, ?string $sort = null, ?string $status = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `sort` | [`?string(ParameterSort)`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`?string(ParameterStatus)`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionsResponse`](../../doc/models/actions-response.md).

## Example Usage

```php
$id = 112;

$imageActionsApi = $client->getImageActionsApi();
$apiResponse = $imageActionsApi->getAllActionsForAnImage($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "change_protection",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 4711,
          "type": "image"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Change Image Protection

Changes the protection configuration of the Image. Can only be used on snapshots.

```php
function changeImageProtection(int $id, ?ImagesActionsChangeProtectionRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `body` | [`?ImagesActionsChangeProtectionRequest`](../../doc/models/images-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$body = ImagesActionsChangeProtectionRequestBuilder::init()
    ->delete(true)
    ->build();

$imageActionsApi = $client->getImageActionsApi();
$apiResponse = $imageActionsApi->changeImageProtection(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "image"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for an Image

Returns a specific Action for an Image.

```php
function getAnActionForAnImage(int $id, int $actionId): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Image Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$actionId = 224;

$imageActionsApi = $client->getImageActionsApi();
$apiResponse = $imageActionsApi->getAnActionForAnImage(
    $id,
    $actionId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "image"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

