
# V2 Load Balancers Forwarding Rules Request

*This model accepts additional fields of type Object.*

## Structure

`V2LoadBalancersForwardingRulesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ForwardingRules` | [`List<ForwardingRule>`](../../doc/models/forwarding-rule.md) | Required | **Constraints**: *Minimum Items*: `1` | List<ForwardingRule> getForwardingRules() | setForwardingRules(List<ForwardingRule> forwardingRules) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.EntryProtocol;
import com.digitalocean.api.models.ForwardingRule;
import com.digitalocean.api.models.TargetProtocol;
import com.digitalocean.api.models.V2LoadBalancersForwardingRulesRequest;
import java.io.IOException;
import java.util.Arrays;

V2LoadBalancersForwardingRulesRequest v2LoadBalancersForwardingRulesRequest = new V2LoadBalancersForwardingRulesRequest.Builder(
    Arrays.asList(
        new ForwardingRule.Builder(
            443,
            EntryProtocol.HTTPS,
            80,
            TargetProtocol.HTTP
        )
        .certificateId("892071a0-bb95-49bc-8021-3afd67a210bf")
        .tlsPassthrough(false)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

