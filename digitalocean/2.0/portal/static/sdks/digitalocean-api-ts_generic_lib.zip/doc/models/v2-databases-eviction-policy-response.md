
# V2 Databases Eviction Policy Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesEvictionPolicyResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `evictionPolicy` | [`RedisMaxmemoryPolicy`](../../doc/models/redis-maxmemory-policy.md) | Required | A string specifying the desired eviction policy for the Redis cluster.<br><br>- `noeviction`: Don't evict any data, returns error when memory limit is reached.<br>- `allkeys_lru:` Evict any key, least recently used (LRU) first.<br>- `allkeys_random`: Evict keys in a random order.<br>- `volatile_lru`: Evict keys with expiration only, least recently used (LRU) first.<br>- `volatile_random`: Evict keys with expiration only in a random order.<br>- `volatile_ttl`: Evict keys with expiration only, shortest time-to-live (TTL) first. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  RedisMaxmemoryPolicy,
  V2DatabasesEvictionPolicyResponse,
} from 'digitalocean-apilib';

const v2DatabasesEvictionPolicyResponse: V2DatabasesEvictionPolicyResponse = {
  evictionPolicy: RedisMaxmemoryPolicy.AllkeysLru,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

