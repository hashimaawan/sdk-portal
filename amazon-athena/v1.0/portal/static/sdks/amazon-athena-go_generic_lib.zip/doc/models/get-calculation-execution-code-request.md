
# Get Calculation Execution Code Request

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getCalculationExecutionCodeRequest := models.GetCalculationExecutionCodeRequest{
        CalculationExecutionId: "CalculationExecutionId4",
    }

}
```

