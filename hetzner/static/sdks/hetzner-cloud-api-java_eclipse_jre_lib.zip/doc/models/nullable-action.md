
# Nullable Action

## Structure

`NullableAction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Command` | `String` | Required | Command executed in the Action | String getCommand() | setCommand(String command) |
| `Error` | [`Error`](../../doc/models/error.md) | Required | Error message for the Action if error occurred, otherwise null | Error getError() | setError(Error error) |
| `Finished` | `String` | Required | Point in time when the Action was finished (in ISO-8601 format). Only set if the Action is finished otherwise null. | String getFinished() | setFinished(String finished) |
| `Id` | `int` | Required | ID of the Resource | int getId() | setId(int id) |
| `Progress` | `double` | Required | Progress of Action in percent | double getProgress() | setProgress(double progress) |
| `Resources` | [`List<Resource>`](../../doc/models/resource.md) | Required | Resources the Action relates to | List<Resource> getResources() | setResources(List<Resource> resources) |
| `Started` | `String` | Required | Point in time when the Action was started (in ISO-8601 format) | String getStarted() | setStarted(String started) |
| `Status` | [`StatusEnum`](../../doc/models/status-enum.md) | Required | Status of the Action | StatusEnum getStatus() | setStatus(StatusEnum status) |

## Example

```java
import cloud.hetzner.api.models.Error;
import cloud.hetzner.api.models.NullableAction;
import cloud.hetzner.api.models.Resource;
import cloud.hetzner.api.models.StatusEnum;
import java.util.Arrays;

NullableAction nullableAction = new NullableAction.Builder(
    "start_server",
    new Error.Builder(
        "action_failed",
        "Action failed"
    )
    .build(),
    "2016-01-30T23:55:00+00:00",
    42,
    100D,
    Arrays.asList(
        new Resource.Builder(
            42,
            "server"
        )
        .build()
    ),
    "2016-01-30T23:55:00+00:00",
    StatusEnum.RUNNING
)
.build();
```

