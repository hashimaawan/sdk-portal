
# X Amz Target 56 Enum

## Enumeration

`XAmzTarget56Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget56Enum;

$xAmzTarget56 = XAmzTarget56Enum::ENUM_AMAZONATHENAUPDATENOTEBOOK;
```

