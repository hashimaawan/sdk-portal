
# Update Prepared Statement Input

## Structure

`UpdatePreparedStatementInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statementName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `queryStatement` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { UpdatePreparedStatementInput } from 'amazon-athenalib';

const updatePreparedStatementInput: UpdatePreparedStatementInput = {
  statementName: 'StatementName0',
  workGroup: 'WorkGroup4',
  queryStatement: 'QueryStatement4',
  description: 'Description4',
};
```

