
# Label Selector 12

Configuration for label selector targets, required if type is `label_selector`

*This model accepts additional fields of type unknown.*

## Structure

`LabelSelector12`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { LabelSelector12 } from 'hetzner-cloud-apilib';

const labelSelector12: LabelSelector12 = {
  selector: 'env=prod',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

