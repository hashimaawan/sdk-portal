
# Prepared Statement 1

## Structure

`PreparedStatement1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StatementName` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `QueryStatement` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `WorkGroupName` | `string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `LastModifiedTime` | `DateTime?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Globalization;

PreparedStatement1 preparedStatement1 = new PreparedStatement1
{
    StatementName = "StatementName6",
    QueryStatement = "QueryStatement0",
    WorkGroupName = "WorkGroupName0",
    Description = "Description8",
    LastModifiedTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};
```

