
# Protocol Enum

Type of traffic to allow

## Enumeration

`ProtocolEnum`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |
| `ESP` |
| `GRE` |

## Example

```java
import cloud.hetzner.api.models.ProtocolEnum;

ProtocolEnum protocol = ProtocolEnum.ESP;
```

