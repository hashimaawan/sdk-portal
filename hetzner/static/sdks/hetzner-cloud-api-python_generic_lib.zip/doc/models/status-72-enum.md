
# Status 72 Enum

Status of the Firewall on the Server

## Enumeration

`Status72Enum`

## Fields

| Name |
|  --- |
| `APPLIED` |
| `PENDING` |

## Example

```python
from hetznercloudapi.models.status_72_enum import Status72Enum

status_72 = Status72Enum.APPLIED
```

