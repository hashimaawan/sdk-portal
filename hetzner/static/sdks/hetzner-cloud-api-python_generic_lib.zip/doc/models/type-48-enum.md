
# Type 48 Enum

The type of the Floating IP

## Enumeration

`Type48Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_48_enum import Type48Enum

type_48 = Type48Enum.IPV4
```

