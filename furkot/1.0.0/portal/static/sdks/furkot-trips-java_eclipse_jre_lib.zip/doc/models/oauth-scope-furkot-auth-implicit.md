
# Oauth Scope Furkot Auth Implicit

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthImplicit`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list users trips info |

## Example

```java
import com.furkot.trips.models.OauthScopeFurkotAuthImplicit;

OauthScopeFurkotAuthImplicit oauthScopeFurkotAuthImplicit = OauthScopeFurkotAuthImplicit.READTRIPS;
```

