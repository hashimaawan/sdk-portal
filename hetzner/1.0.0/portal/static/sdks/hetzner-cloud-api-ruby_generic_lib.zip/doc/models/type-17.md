
# Type 17

Floating IP type

## Enumeration

`Type17`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```ruby
type17 = Type17::IPV4
```

