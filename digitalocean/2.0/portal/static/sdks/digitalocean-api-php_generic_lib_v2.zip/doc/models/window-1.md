
# Window 1

## Enumeration

`Window1`

## Fields

| Name |
|  --- |
| `ENUM_5M` |
| `ENUM_10M` |
| `ENUM_30M` |
| `ENUM_1H` |

## Example

```php
use DigitalOceanApiLib\Models\Window1;

$window1 = Window1::ENUM_30M;
```

