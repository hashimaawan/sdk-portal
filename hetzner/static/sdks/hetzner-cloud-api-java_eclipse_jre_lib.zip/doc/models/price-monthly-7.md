
# Price Monthly 7

Monthly costs for a Floating IP type in this Location

## Structure

`PriceMonthly7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Gross` | `String` | Required | Price with VAT added | String getGross() | setGross(String gross) |
| `Net` | `String` | Required | Price without VAT | String getNet() | setNet(String net) |

## Example

```java
import cloud.hetzner.api.models.PriceMonthly7;

PriceMonthly7 priceMonthly7 = new PriceMonthly7.Builder(
    "1.1900000000000000",
    "1.0000000000"
)
.build();
```

