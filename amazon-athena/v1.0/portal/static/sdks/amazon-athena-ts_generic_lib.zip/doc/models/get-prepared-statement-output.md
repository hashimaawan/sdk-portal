
# Get Prepared Statement Output

*This model accepts additional fields of type unknown.*

## Structure

`GetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preparedStatement` | [`PreparedStatement1 \| undefined`](../../doc/models/prepared-statement-1.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetPreparedStatementOutput } from 'amazon-athenalib';

const getPreparedStatementOutput: GetPreparedStatementOutput = {
  preparedStatement: {
    statementName: 'StatementName4',
    queryStatement: 'QueryStatement8',
    workGroupName: 'WorkGroupName8',
    description: 'Description0',
    lastModifiedTime: '2016-03-13T12:52:32.123Z',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

