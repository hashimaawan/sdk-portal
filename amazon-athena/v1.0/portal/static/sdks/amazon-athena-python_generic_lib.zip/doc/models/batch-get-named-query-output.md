
# Batch Get Named Query Output

*This model accepts additional fields of type Any.*

## Structure

`BatchGetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_queries` | [`List[NamedQuery]`](../../doc/models/named-query.md) | Optional | - |
| `unprocessed_named_query_ids` | [`List[UnprocessedNamedQueryId]`](../../doc/models/unprocessed-named-query-id.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.batch_get_named_query_output import BatchGetNamedQueryOutput
from amazonathena.models.named_query import NamedQuery
from amazonathena.models.unprocessed_named_query_id import UnprocessedNamedQueryId

batch_get_named_query_output = BatchGetNamedQueryOutput(
    named_queries=[
        NamedQuery(
            name='Name2',
            database='Database0',
            query_string='QueryString4',
            description='Description4',
            named_query_id='NamedQueryId0',
            work_group='WorkGroup4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        NamedQuery(
            name='Name2',
            database='Database0',
            query_string='QueryString4',
            description='Description4',
            named_query_id='NamedQueryId0',
            work_group='WorkGroup4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        NamedQuery(
            name='Name2',
            database='Database0',
            query_string='QueryString4',
            description='Description4',
            named_query_id='NamedQueryId0',
            work_group='WorkGroup4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    unprocessed_named_query_ids=[
        UnprocessedNamedQueryId(
            named_query_id='NamedQueryId4',
            error_code='ErrorCode6',
            error_message='ErrorMessage4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        UnprocessedNamedQueryId(
            named_query_id='NamedQueryId4',
            error_code='ErrorCode6',
            error_message='ErrorMessage4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

