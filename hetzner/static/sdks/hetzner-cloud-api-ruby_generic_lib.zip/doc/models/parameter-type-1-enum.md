
# Parameter Type 1 Enum

## Enumeration

`ParameterType1Enum`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```ruby
parameter_type1 = ParameterType1Enum::SPREAD
```

