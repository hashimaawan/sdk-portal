
# X Amz Target 17 Enum

## Enumeration

`XAmzTarget17Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS` |

## Example

```python
from amazonathena.models.x_amz_target_17_enum import XAmzTarget17Enum

x_amz_target_17 = XAmzTarget17Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS
```

