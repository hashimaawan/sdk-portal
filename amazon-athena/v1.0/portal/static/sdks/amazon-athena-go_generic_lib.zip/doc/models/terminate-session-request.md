
# Terminate Session Request

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    terminateSessionRequest := models.TerminateSessionRequest{
        SessionId:            "SessionId0",
    }

}
```

