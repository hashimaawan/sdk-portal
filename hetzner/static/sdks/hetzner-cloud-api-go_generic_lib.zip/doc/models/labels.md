
# Labels

User-defined labels (key-value pairs)

## Structure

`Labels`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labelkey` | `*string` | Optional | New label |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    labels := models.Labels{
        Labelkey:             models.ToPointer("value"),
    }

}
```

