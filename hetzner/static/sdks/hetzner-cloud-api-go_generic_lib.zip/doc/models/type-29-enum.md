
# Type 29 Enum

Type of the resource

## Enumeration

`Type29Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABELSELECTOR` |
| `IP` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type29 := models.Type29Enum_SERVER

}
```

