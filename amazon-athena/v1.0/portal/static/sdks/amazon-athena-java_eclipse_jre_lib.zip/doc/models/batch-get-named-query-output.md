
# Batch Get Named Query Output

## Structure

`BatchGetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NamedQueries` | [`List<NamedQuery>`](../../doc/models/named-query.md) | Optional | - | List<NamedQuery> getNamedQueries() | setNamedQueries(List<NamedQuery> namedQueries) |
| `UnprocessedNamedQueryIds` | [`List<UnprocessedNamedQueryId>`](../../doc/models/unprocessed-named-query-id.md) | Optional | - | List<UnprocessedNamedQueryId> getUnprocessedNamedQueryIds() | setUnprocessedNamedQueryIds(List<UnprocessedNamedQueryId> unprocessedNamedQueryIds) |

## Example

```java
import com.amazonaws.useast1.athena.models.BatchGetNamedQueryOutput;
import com.amazonaws.useast1.athena.models.NamedQuery;
import com.amazonaws.useast1.athena.models.UnprocessedNamedQueryId;
import java.util.Arrays;

BatchGetNamedQueryOutput batchGetNamedQueryOutput = new BatchGetNamedQueryOutput.Builder()
    .namedQueries(Arrays.asList(
        new NamedQuery.Builder(
            "Name2",
            "Database0",
            "QueryString4"
        )
        .description("Description4")
        .namedQueryId("NamedQueryId0")
        .workGroup("WorkGroup4")
        .build(),
        new NamedQuery.Builder(
            "Name2",
            "Database0",
            "QueryString4"
        )
        .description("Description4")
        .namedQueryId("NamedQueryId0")
        .workGroup("WorkGroup4")
        .build(),
        new NamedQuery.Builder(
            "Name2",
            "Database0",
            "QueryString4"
        )
        .description("Description4")
        .namedQueryId("NamedQueryId0")
        .workGroup("WorkGroup4")
        .build()
    ))
    .unprocessedNamedQueryIds(Arrays.asList(
        new UnprocessedNamedQueryId.Builder()
            .namedQueryId("NamedQueryId4")
            .errorCode("ErrorCode6")
            .errorMessage("ErrorMessage4")
            .build(),
        new UnprocessedNamedQueryId.Builder()
            .namedQueryId("NamedQueryId4")
            .errorCode("ErrorCode6")
            .errorMessage("ErrorMessage4")
            .build()
    ))
    .build();
```

