
# X Amz Target 5 Enum

## Enumeration

`XAmzTarget5Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateNotebook` |

## Example

```ts
import { XAmzTarget5Enum } from 'amazon-athenalib';

const xAmzTarget5 = XAmzTarget5Enum.EnumAmazonAthenaCreateNotebook;
```

