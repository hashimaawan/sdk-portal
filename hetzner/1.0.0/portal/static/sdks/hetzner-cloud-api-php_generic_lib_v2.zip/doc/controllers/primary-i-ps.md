# Primary I Ps

```php
$primaryIPsController = $client->getPrimaryIPsController();
```

## Class Name

`PrimaryIPsController`

## Methods

* [Get All Primary I Ps](../../doc/controllers/primary-i-ps.md#get-all-primary-i-ps)
* [Create a Primary IP](../../doc/controllers/primary-i-ps.md#create-a-primary-ip)
* [Delete a Primary IP](../../doc/controllers/primary-i-ps.md#delete-a-primary-ip)
* [Get a Primary IP](../../doc/controllers/primary-i-ps.md#get-a-primary-ip)
* [Update a Primary IP](../../doc/controllers/primary-i-ps.md#update-a-primary-ip)


# Get All Primary I Ps

Returns all Primary IP objects.

```php
function getAllPrimaryIPs(
    ?string $name = null,
    ?string $labelSelector = null,
    ?string $ip = null,
    ?string $sort = null
): PrimaryIPsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `?string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `?string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `ip` | `?string` | Query, Optional | Can be used to filter resources by their ip. The response will only contain the resources matching the specified ip. |
| `sort` | [`?string(Sort2Enum)`](../../doc/models/sort-2-enum.md) | Query, Optional | Can be used multiple times. Choices id id:asc id:desc created created:asc created:desc |

## Response Type

**200**: The `primary_ips` key contains an array of Primary IP objects

[`PrimaryIPsResponse`](../../doc/models/primary-i-ps-response.md)

## Example Usage

```php
$ip = '127.0.0.1';

$primaryIPsController = $client->getPrimaryIPsController();

try {
    $result = $primaryIPsController->getAllPrimaryIPs(
        null,
        null,
        $ip
    );
    echo 'PrimaryIPsResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Create a Primary IP

Creates a new Primary IP, optionally assigned to a Server.

If you want to create a Primary IP that is not assigned to a Server, you need to provide the `datacenter` key instead of `assignee_id`. This can be either the ID or the name of the Datacenter this Primary IP shall be created in.

Note that a Primary IP can only be assigned to a Server in the same Datacenter later on.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_not_stopped`          | The specified server is running, but needs to be powered off  |
| `server_has_ipv4`             | The server already has an ipv4 address                        |
| `server_has_ipv6`             | The server already has an ipv6 address                        |

```php
function createAPrimaryIP(?CreatePrimaryIPRequest $body = null): CreatePrimaryIPResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?CreatePrimaryIPRequest`](../../doc/models/create-primary-ip-request.md) | Body, Optional | The `type` argument is required while `datacenter` and `assignee_id` are mutually exclusive. |

## Response Type

**201**: The `primary_ip` key contains the Primary IP that was just created

[`CreatePrimaryIPResponse`](../../doc/models/create-primary-ip-response.md)

## Example Usage

```php
$body = CreatePrimaryIPRequestBuilder::init(
    'my-ip',
    Type51Enum::IPV4
)
    ->assigneeId(17)
    ->autoDelete(false)
    ->datacenter('fsn1-dc8')
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->build();

$primaryIPsController = $client->getPrimaryIPsController();

try {
    $result = $primaryIPsController->createAPrimaryIP($body);
    echo 'CreatePrimaryIPResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_primary_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 17,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "primary_ip": {
    "assignee_id": 17,
    "assignee_type": "server",
    "auto_delete": true,
    "blocked": false,
    "created": "2016-01-30T23:50:00+00:00",
    "datacenter": {
      "description": "Falkenstein DC Park 8",
      "id": 42,
      "location": {
        "city": "Falkenstein",
        "country": "DE",
        "description": "Falkenstein DC Park 1",
        "id": 1,
        "latitude": 50.47612,
        "longitude": 12.370071,
        "name": "fsn1",
        "network_zone": "eu-central"
      },
      "name": "fsn1-dc8",
      "server_types": {
        "available": [
          1,
          2,
          3
        ],
        "available_for_migration": [
          1,
          2,
          3
        ],
        "supported": [
          1,
          2,
          3
        ]
      }
    },
    "dns_ptr": [
      {
        "dns_ptr": "server.example.com",
        "ip": "2001:db8::1"
      }
    ],
    "id": 42,
    "ip": "131.232.99.1",
    "labels": {
      "labelkey": "value"
    },
    "name": "my-ip",
    "protection": {
      "delete": false
    },
    "type": "ipv4"
  }
}
```


# Delete a Primary IP

Deletes a Primary IP.

The Primary IP may be assigned to a Server. In this case it is unassigned automatically. The Server must be powered off (status `off`) in order for this operation to succeed.

```php
function deleteAPrimaryIP(int $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Primary IP deleted

`void`

## Example Usage

```php
$id = 112;

$primaryIPsController = $client->getPrimaryIPsController();

try {
    $primaryIPsController->deleteAPrimaryIP($id);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get a Primary IP

Returns a specific Primary IP object.

```php
function getAPrimaryIP(int $id): PrimaryIPResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `primary_ip` key contains a Primary IP object

[`PrimaryIPResponse`](../../doc/models/primary-ip-response.md)

## Example Usage

```php
$id = 112;

$primaryIPsController = $client->getPrimaryIPsController();

try {
    $result = $primaryIPsController->getAPrimaryIP($id);
    echo 'PrimaryIPResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Update a Primary IP

Updates the Primary IP.

Note that when updating labels, the Primary IP's current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

If the Primary IP object changes during the request, the response will be a “conflict” error.

```php
function updateAPrimaryIP(int $id, ?UpdatePrimaryIPRequest $body = null): PrimaryIPResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`?UpdatePrimaryIPRequest`](../../doc/models/update-primary-ip-request.md) | Body, Optional | - |

## Response Type

**200**: The `primary_ip` key contains the Primary IP that was just updated

[`PrimaryIPResponse`](../../doc/models/primary-ip-response.md)

## Example Usage

```php
$id = 112;

$body = UpdatePrimaryIPRequestBuilder::init()
    ->autoDelete(true)
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('my-ip')
    ->build();

$primaryIPsController = $client->getPrimaryIPsController();

try {
    $result = $primaryIPsController->updateAPrimaryIP(
        $id,
        $body
    );
    echo 'PrimaryIPResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

