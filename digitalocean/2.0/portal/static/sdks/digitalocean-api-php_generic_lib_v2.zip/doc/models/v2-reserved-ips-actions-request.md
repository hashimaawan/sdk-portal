
# V2 Reserved Ips Actions Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2ReservedIpsActionsRequest`

## Inherits From

[`BaseType`](../../doc/models/base-type.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dropletId` | `int` | Required | The ID of the Droplet that the reserved IP will be assigned to. | getDropletId(): int | setDropletId(int dropletId): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2ReservedIpsActionsRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2ReservedIpsActionsRequest = V2ReservedIpsActionsRequestBuilder::init(
    758604968
)
    ->type('V2 Reserved Ips Actions Request')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

