
# Query Runtime Statistics Rows

Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query.

## Structure

`QueryRuntimeStatisticsRows`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input_rows` | `Integer` | Optional | - |
| `input_bytes` | `Integer` | Optional | - |
| `output_bytes` | `Integer` | Optional | - |
| `output_rows` | `Integer` | Optional | - |

## Example

```ruby
query_runtime_statistics_rows = QueryRuntimeStatisticsRows.new(
  100,
  136,
  94,
  104
)
```

