
# V2 Cdn Endpoints Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endpoint` | [`Endpoint \| undefined`](../../doc/models/endpoint.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2CdnEndpointsResponse1 } from 'digitalocean-apilib';

const v2CdnEndpointsResponse1: V2CdnEndpointsResponse1 = {
  endpoint: {
    origin: 'origin2',
    certificateId: '00001b94-0000-0000-0000-000000000000',
    createdAt: '2016-03-13T12:52:32.123Z',
    customDomain: 'custom_domain6',
    endpoint: 'endpoint6',
    id: '00001f7a-0000-0000-0000-000000000000',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

