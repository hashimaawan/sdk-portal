
# Mode

travel mode

## Enumeration

`Mode`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```ruby
mode = Mode::BICYCLE
```

