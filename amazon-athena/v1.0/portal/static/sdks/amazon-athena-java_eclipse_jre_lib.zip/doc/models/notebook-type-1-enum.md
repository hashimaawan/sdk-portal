
# Notebook Type 1 Enum

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```java
import com.amazonaws.useast1.athena.models.NotebookType1Enum;

NotebookType1Enum notebookType1 = NotebookType1Enum.IPYNB;
```

