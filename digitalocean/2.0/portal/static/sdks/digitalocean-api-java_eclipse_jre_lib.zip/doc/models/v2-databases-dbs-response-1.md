
# V2 Databases Dbs Response 1

*This model accepts additional fields of type Object.*

## Structure

`V2DatabasesDbsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Db` | [`Db`](../../doc/models/db.md) | Required | - | Db getDb() | setDb(Db db) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Db;
import com.digitalocean.api.models.V2DatabasesDbsResponse1;
import java.io.IOException;

V2DatabasesDbsResponse1 v2DatabasesDbsResponse1 = new V2DatabasesDbsResponse1.Builder(
    new Db.Builder(
        "alpha"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

