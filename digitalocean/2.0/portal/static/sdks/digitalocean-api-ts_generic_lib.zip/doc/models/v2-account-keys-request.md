
# V2 Account Keys Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AccountKeysRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | A human-readable display name for this key, used to easily identify the SSH keys when they are displayed. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AccountKeysRequest } from 'digitalocean-apilib';

const v2AccountKeysRequest: V2AccountKeysRequest = {
  name: 'My SSH Public Key',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

