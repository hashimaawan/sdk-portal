
# X Amz Target 9 Enum

## Enumeration

`XAmzTarget9Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEDATACATALOG` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget9Enum;

$xAmzTarget9 = XAmzTarget9Enum::ENUM_AMAZONATHENADELETEDATACATALOG;
```

