
# Get Calculation Execution Code Response

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CodeBlock` | `String` | Optional | **Constraints**: *Maximum Length*: `68000` | String getCodeBlock() | setCodeBlock(String codeBlock) |

## Example

```java
import com.amazonaws.useast1.athena.models.GetCalculationExecutionCodeResponse;

GetCalculationExecutionCodeResponse getCalculationExecutionCodeResponse = new GetCalculationExecutionCodeResponse.Builder()
    .codeBlock("CodeBlock4")
    .build();
```

