
# Content Type

## Enumeration

`ContentType`

## Fields

| Name |
|  --- |
| `EnumApplicationjson` |
| `EnumApplicationyaml` |

## Example

```ts
import { ContentType } from 'digitalocean-apilib';

const contentType = ContentType.EnumApplicationjson;
```

