
# Type 66 Enum

## Enumeration

`Type66Enum`

## Fields

| Name |
|  --- |
| `Cpu` |
| `Disk` |
| `Network` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type66Enum type66 = Type66Enum.Network;
```

