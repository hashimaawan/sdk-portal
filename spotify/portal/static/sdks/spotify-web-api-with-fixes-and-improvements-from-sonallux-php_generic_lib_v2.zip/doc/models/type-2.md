
# Type 2

The object type: "track".

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `TRACK` |

## Example

```php
use SpotifyWebApiWithFixesAndImprovementsFromSonalluxLib\Models\Type2;

$type2 = Type2::TRACK;
```

