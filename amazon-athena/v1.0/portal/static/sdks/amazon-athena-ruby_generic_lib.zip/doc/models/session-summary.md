
# Session Summary

Contains summary information about a session.

## Structure

`SessionSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `engine_version` | [`EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - |
| `notebook_version` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `status` | [`Status3`](../../doc/models/status-3.md) | Optional | - |

## Example

```ruby
session_summary = SessionSummary.new(
  'SessionId8',
  'Description6',
  EngineVersion1.new(
    'SelectedEngineVersion4',
    'EffectiveEngineVersion6'
  ),
  'NotebookVersion4',
  Status3.new(
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    SessionState1Enum::TERMINATING
  )
)
```

