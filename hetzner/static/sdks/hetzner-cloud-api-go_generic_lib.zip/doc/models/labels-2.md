
# Labels 2

User-defined labels (key-value pairs)

## Structure

`Labels2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labelkey` | `*string` | Optional | - |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    labels2 := models.Labels2{
        Labelkey:             models.ToPointer("value"),
    }

}
```

