
# Executor State

## Enumeration

`ExecutorState`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Registered` |
| `Terminating` |
| `Terminated` |
| `Failed` |

## Example

```ts
import { ExecutorState } from 'amazon-athenalib';

const executorState = ExecutorState.Terminated;
```

