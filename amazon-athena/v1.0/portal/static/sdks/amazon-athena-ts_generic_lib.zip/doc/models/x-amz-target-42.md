
# X Amz Target 42

## Enumeration

`XAmzTarget42`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListSessions` |

## Example

```ts
import { XAmzTarget42 } from 'amazon-athenalib';

const xAmzTarget42 = XAmzTarget42.EnumAmazonAthenaListSessions;
```

