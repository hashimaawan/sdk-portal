
# List Tags for Resource Input

## Structure

`ListTagsForResourceInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `resourceARN` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` | getResourceARN(): string | setResourceARN(string resourceARN): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |
| `maxResults` | `?int` | Optional | **Constraints**: `>= 75` | getMaxResults(): ?int | setMaxResults(?int maxResults): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListTagsForResourceInputBuilder;

$listTagsForResourceInput = ListTagsForResourceInputBuilder::init(
    'ResourceARN0'
)
    ->nextToken('NextToken0')
    ->maxResults(76)
    ->build();
```

