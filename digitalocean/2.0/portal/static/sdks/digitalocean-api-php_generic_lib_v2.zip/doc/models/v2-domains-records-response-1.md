
# V2 Domains Records Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DomainsRecordsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `domainRecord` | [`?DomainRecord`](../../doc/models/domain-record.md) | Optional | - | getDomainRecord(): ?DomainRecord | setDomainRecord(?DomainRecord domainRecord): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DomainsRecordsResponse1Builder;
use DigitalOceanApiLib\Models\Builders\DomainRecordBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DomainsRecordsResponse1 = V2DomainsRecordsResponse1Builder::init()
    ->domainRecord(
        DomainRecordBuilder::init(
            'A'
        )
            ->data('162.10.66.0')
            ->flags(null)
            ->id(28448433)
            ->name('www')
            ->port(null)
            ->priority(null)
            ->tag(null)
            ->ttl(1800)
            ->weight(null)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

