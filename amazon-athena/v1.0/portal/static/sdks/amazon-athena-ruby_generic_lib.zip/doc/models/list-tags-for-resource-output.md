
# List Tags for Resource Output

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | [`Array[Tag]`](../../doc/models/tag.md) | Optional | - |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_tags_for_resource_output = ListTagsForResourceOutput.new(
  [
    Tag.new(
      'Key0',
      'Value6'
    )
  ],
  'NextToken4'
)
```

