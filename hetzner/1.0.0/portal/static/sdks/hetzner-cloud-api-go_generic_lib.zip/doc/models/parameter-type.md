
# Parameter Type

## Enumeration

`ParameterType`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    parameterType := models.ParameterType_Uploaded

}
```

