
# List Table Metadata Output

## Structure

`ListTableMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tableMetadataList` | [`TableMetadata[] \| undefined`](../../doc/models/table-metadata.md) | Optional | - |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListTableMetadataOutput } from 'amazon-athenalib';

const listTableMetadataOutput: ListTableMetadataOutput = {
  tableMetadataList: [
    {
      name: 'Name2',
      createTime: '2016-03-13T12:52:32.123Z',
      lastAccessTime: '2016-03-13T12:52:32.123Z',
      tableType: 'TableType2',
      columns: [
        {
          name: 'Name0',
          type: 'Type0',
          comment: 'Comment4',
        }
      ],
      partitionKeys: [
        {
          name: 'Name6',
          type: 'Type6',
          comment: 'Comment0',
        },
        {
          name: 'Name6',
          type: 'Type6',
          comment: 'Comment0',
        },
        {
          name: 'Name6',
          type: 'Type6',
          comment: 'Comment0',
        }
      ],
    },
    {
      name: 'Name2',
      createTime: '2016-03-13T12:52:32.123Z',
      lastAccessTime: '2016-03-13T12:52:32.123Z',
      tableType: 'TableType2',
      columns: [
        {
          name: 'Name0',
          type: 'Type0',
          comment: 'Comment4',
        }
      ],
      partitionKeys: [
        {
          name: 'Name6',
          type: 'Type6',
          comment: 'Comment0',
        },
        {
          name: 'Name6',
          type: 'Type6',
          comment: 'Comment0',
        },
        {
          name: 'Name6',
          type: 'Type6',
          comment: 'Comment0',
        }
      ],
    }
  ],
  nextToken: 'NextToken0',
};
```

