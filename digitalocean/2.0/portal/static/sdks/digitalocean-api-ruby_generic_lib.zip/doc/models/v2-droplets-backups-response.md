
# V2 Droplets Backups Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DropletsBackupsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `backups` | [`Array[Backup1]`](../../doc/models/backup-1.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_droplets_backups_response = V2DropletsBackupsResponse.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  backups: [
    Backup1.new(
      id: 196,
      created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      min_disk_size: 242,
      name: 'name4',
      regions: [
        'regions9',
        'regions0',
        'regions1'
      ],
      size_gigabytes: 180.5,
      type: Type13::SNAPSHOT,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

