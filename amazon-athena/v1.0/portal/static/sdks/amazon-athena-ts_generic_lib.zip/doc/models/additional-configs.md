
# Additional Configs

*This model accepts additional fields of type string.*

## Structure

`AdditionalConfigs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `additionalProperties` | `Record<string, string>` | Optional | **Constraints**: *Maximum Length*: `51200` |

## Example (as JSON)

```json
{
  "exampleAdditionalProperty": "AdditionalConfigs_additionalProperties5"
}
```

