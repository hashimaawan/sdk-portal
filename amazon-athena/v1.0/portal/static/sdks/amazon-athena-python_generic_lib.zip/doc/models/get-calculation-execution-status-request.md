
# Get Calculation Execution Status Request

## Structure

`GetCalculationExecutionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```python
from amazonathena.models.get_calculation_execution_status_request import GetCalculationExecutionStatusRequest

get_calculation_execution_status_request = GetCalculationExecutionStatusRequest(
    calculation_execution_id='CalculationExecutionId0'
)
```

