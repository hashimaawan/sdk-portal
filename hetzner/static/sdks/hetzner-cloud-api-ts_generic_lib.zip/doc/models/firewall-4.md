
# Firewall 4

## Structure

`Firewall4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewall` | `number \| undefined` | Optional | ID of the Firewall |

## Example

```ts
import { Firewall4 } from 'hetzner-cloud-apilib';

const firewall4: Firewall4 = {
  firewall: 176,
};
```

