
# Load Balancer Target Server

Server where the traffic should be routed through

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Server |

## Example

```python
from hetznercloudapi.models.load_balancer_target_server import LoadBalancerTargetServer

load_balancer_target_server = LoadBalancerTargetServer(
    id=80
)
```

