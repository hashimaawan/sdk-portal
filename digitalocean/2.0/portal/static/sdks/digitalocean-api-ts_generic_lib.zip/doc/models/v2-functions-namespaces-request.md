
# V2 Functions Namespaces Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `string` | Required | The namespace's unique name. |
| `region` | `string` | Required | The [datacenter region](https://docs.digitalocean.com/products/platform/availability-matrix/#available-datacenters) in which to create the namespace. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FunctionsNamespacesRequest } from 'digitalocean-apilib';

const v2FunctionsNamespacesRequest: V2FunctionsNamespacesRequest = {
  label: 'my namespace',
  region: 'nyc1',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

