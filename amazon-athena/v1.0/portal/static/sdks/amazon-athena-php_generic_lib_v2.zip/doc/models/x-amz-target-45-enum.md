
# X Amz Target 45 Enum

## Enumeration

`XAmzTarget45Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTWORKGROUPS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget45Enum;

$xAmzTarget45 = XAmzTarget45Enum::ENUM_AMAZONATHENALISTWORKGROUPS;
```

