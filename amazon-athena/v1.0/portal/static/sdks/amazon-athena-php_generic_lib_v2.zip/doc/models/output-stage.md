
# Output Stage

## Structure

`OutputStage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `stageId` | `?int` | Optional | - | getStageId(): ?int | setStageId(?int stageId): void |
| `state` | `?string` | Optional | - | getState(): ?string | setState(?string state): void |
| `outputBytes` | `?int` | Optional | - | getOutputBytes(): ?int | setOutputBytes(?int outputBytes): void |
| `outputRows` | `?int` | Optional | - | getOutputRows(): ?int | setOutputRows(?int outputRows): void |
| `inputBytes` | `?int` | Optional | - | getInputBytes(): ?int | setInputBytes(?int inputBytes): void |
| `inputRows` | `?int` | Optional | - | getInputRows(): ?int | setInputRows(?int inputRows): void |
| `executionTime` | `?int` | Optional | - | getExecutionTime(): ?int | setExecutionTime(?int executionTime): void |
| `queryStagePlan` | [`?QueryStagePlan`](../../doc/models/query-stage-plan.md) | Optional | - | getQueryStagePlan(): ?QueryStagePlan | setQueryStagePlan(?QueryStagePlan queryStagePlan): void |
| `subStages` | [`?(QueryStage[])`](../../doc/models/query-stage.md) | Optional | - | getSubStages(): ?array | setSubStages(?array subStages): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\OutputStageBuilder;

$outputStage = OutputStageBuilder::init()
    ->stageId(26)
    ->state('State4')
    ->outputBytes(212)
    ->outputRows(54)
    ->inputBytes(170)
    ->build();
```

