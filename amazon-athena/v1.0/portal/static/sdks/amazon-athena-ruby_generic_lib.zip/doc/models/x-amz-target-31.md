
# X Amz Target 31

## Enumeration

`XAmzTarget31`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```ruby
x_amz_target31 = XAmzTarget31::ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES
```

