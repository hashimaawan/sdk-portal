
# Primary Ip Response

*This model accepts additional fields of type interface{}.*

## Structure

`PrimaryIpResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PrimaryIp` | [`models.PrimaryIp1`](../../doc/models/primary-ip-1.md) | Required | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    primaryIpResponse := models.PrimaryIpResponse{
        PrimaryIp:             models.PrimaryIp1{
            AssigneeId:            models.ToPointer(17),
            AssigneeType:          "server",
            AutoDelete:            true,
            Blocked:               false,
            Created:               "2016-01-30T23:55:00+00:00",
            Datacenter:            models.Datacenter2{
                Description:           "Falkenstein DC Park 8",
                Id:                    42,
                Location:              models.Location{
                    City:                  "Falkenstein",
                    Country:               "DE",
                    Description:           "Falkenstein DC Park 1",
                    Id:                    float64(1),
                    Latitude:              float64(50.47612),
                    Longitude:             float64(12.370071),
                    Name:                  "fsn1",
                    NetworkZone:           "eu-central",
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                },
                Name:                  "fsn1-dc8",
                ServerTypes:           models.ServerTypes{
                    Available:             []float64{
                        float64(1),
                        float64(2),
                        float64(3),
                    },
                    AvailableForMigration: []float64{
                        float64(1),
                        float64(2),
                        float64(3),
                    },
                    Supported:             []float64{
                        float64(1),
                        float64(2),
                        float64(3),
                    },
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                },
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            DnsPtr:                []models.DnsPtr{
                models.DnsPtr{
                    DnsPtr:                "server.example.com",
                    Ip:                    "2001:db8::1",
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                },
            },
            Id:                    42,
            Ip:                    "131.232.99.1",
            Labels:                map[string]string{
                "key0": "labels2",
                "key1": "labels1",
            },
            Name:                  "my-resource",
            Protection:            models.Protection{
                Delete:                false,
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            Type:                  models.Type50_Ipv4,
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

