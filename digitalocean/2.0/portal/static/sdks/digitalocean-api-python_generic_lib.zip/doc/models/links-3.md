
# Links 3

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Links3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `actions` | [`List[Action1]`](../../doc/models/action-1.md) | Optional | - |
| `droplets` | [`List[Action1]`](../../doc/models/action-1.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.action_1 import Action1
from digitaloceanapi.models.links_3 import Links3

links_3 = Links3(
    actions=[
        Action1(
            href='href0',
            id=154,
            rel='rel4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Action1(
            href='href0',
            id=154,
            rel='rel4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    droplets=[
        Action1(
            href='href2',
            id=232,
            rel='rel6',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

