
# List Work Groups Input

*This model accepts additional fields of type unknown.*

## Structure

`ListWorkGroupsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 50` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ListWorkGroupsInput } from 'amazon-athenalib';

const listWorkGroupsInput: ListWorkGroupsInput = {
  nextToken: 'NextToken8',
  maxResults: 50,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

