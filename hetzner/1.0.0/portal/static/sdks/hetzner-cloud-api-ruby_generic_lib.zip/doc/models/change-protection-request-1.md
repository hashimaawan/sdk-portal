
# Change Protection Request 1

*This model accepts additional fields of type Object.*

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Network from being deleted |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
change_protection_request1 = ChangeProtectionRequest1.new(
  delete: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

