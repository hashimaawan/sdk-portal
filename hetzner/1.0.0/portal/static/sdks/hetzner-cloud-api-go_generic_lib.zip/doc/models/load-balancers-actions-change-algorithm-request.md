
# Load Balancers Actions Change Algorithm Request

*This model accepts additional fields of type interface{}.*

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`models.Type39`](../../doc/models/type-39.md) | Required | Algorithm of the Load Balancer |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    loadBalancersActionsChangeAlgorithmRequest := models.LoadBalancersActionsChangeAlgorithmRequest{
        Type:                  models.Type39_RoundRobin,
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

