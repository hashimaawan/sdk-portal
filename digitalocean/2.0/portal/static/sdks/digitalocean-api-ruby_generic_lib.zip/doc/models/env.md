
# Env

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Env`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `String` | Required | The variable name<br><br>**Constraints**: *Pattern*: `^[_A-Za-z][_A-Za-z0-9]*$` |
| `scope` | [`Scope`](../../doc/models/scope.md) | Optional | - RUN_TIME: Made available only at run-time<br>- BUILD_TIME: Made available only at build-time<br>- RUN_AND_BUILD_TIME: Made available at both build and run-time<br><br>**Default**: `Scope::RUN_AND_BUILD_TIME` |
| `type` | [`Type2`](../../doc/models/type-2.md) | Optional | - GENERAL: A plain-text environment variable<br>- SECRET: A secret encrypted environment variable<br><br>**Default**: `Type2::GENERAL` |
| `value` | `String` | Optional | The value. If the type is `SECRET`, the value will be encrypted on first submission. On following submissions, the encrypted value should be used. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
env = Env.new(
  key: 'BASE_URL',
  scope: Scope::BUILD_TIME,
  type: Type2::GENERAL,
  value: 'http://example.com',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

