
# X Amz Target 37

## Enumeration

`XAmzTarget37`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNAMEDQUERIES` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget37;

XAmzTarget37 xAmzTarget37 = XAmzTarget37.ENUM_AMAZONATHENALISTNAMEDQUERIES;
```

