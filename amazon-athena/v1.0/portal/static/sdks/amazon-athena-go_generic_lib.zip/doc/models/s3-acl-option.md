
# S3 Acl Option

## Enumeration

`S3AclOption`

## Fields

| Name |
|  --- |
| `BucketOwnerFullControl` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    s3AclOption := models.S3AclOption_BucketOwnerFullControl

}
```

