
# Get Prepared Statement Output

## Structure

`GetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prepared_statement` | [`PreparedStatement1`](../../doc/models/prepared-statement-1.md) | Optional | - |

## Example

```ruby
get_prepared_statement_output = GetPreparedStatementOutput.new(
  PreparedStatement1.new(
    'StatementName4',
    'QueryStatement8',
    'WorkGroupName8',
    'Description0',
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z')
  )
)
```

