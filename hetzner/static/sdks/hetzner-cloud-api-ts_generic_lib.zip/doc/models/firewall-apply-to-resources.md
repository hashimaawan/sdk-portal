
# Firewall Apply to Resources

## Structure

`FirewallApplyToResources`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labelSelector` | [`LabelSelector5 \| undefined`](../../doc/models/label-selector-5.md) | Optional | Configuration for type label_selector, required if type is `label_selector` |
| `server` | [`Server9 \| undefined`](../../doc/models/server-9.md) | Optional | Configuration for type server, required if type is `server` |
| `type` | [`Type7Enum \| undefined`](../../doc/models/type-7-enum.md) | Optional | Type of the resource |

## Example

```ts
import { FirewallApplyToResources, Type7Enum } from 'hetzner-cloud-apilib';

const firewallApplyToResources: FirewallApplyToResources = {
  labelSelector: {
    selector: 'selector8',
  },
  server: {
    id: 14,
  },
  type: Type7Enum.Server,
};
```

