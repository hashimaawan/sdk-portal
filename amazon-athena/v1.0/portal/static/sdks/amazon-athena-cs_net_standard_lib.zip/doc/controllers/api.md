# API

```csharp
APIController aPIController = client.APIController;
```

## Class Name

`APIController`

## Methods

* [Batch Get Named Query](../../doc/controllers/api.md#batch-get-named-query)
* [Batch Get Prepared Statement](../../doc/controllers/api.md#batch-get-prepared-statement)
* [Batch Get Query Execution](../../doc/controllers/api.md#batch-get-query-execution)
* [Create Data Catalog](../../doc/controllers/api.md#create-data-catalog)
* [Create Named Query](../../doc/controllers/api.md#create-named-query)
* [Create Notebook](../../doc/controllers/api.md#create-notebook)
* [Create Prepared Statement](../../doc/controllers/api.md#create-prepared-statement)
* [Create Presigned Notebook Url](../../doc/controllers/api.md#create-presigned-notebook-url)
* [Create Work Group](../../doc/controllers/api.md#create-work-group)
* [Delete Data Catalog](../../doc/controllers/api.md#delete-data-catalog)
* [Delete Named Query](../../doc/controllers/api.md#delete-named-query)
* [Delete Notebook](../../doc/controllers/api.md#delete-notebook)
* [Delete Prepared Statement](../../doc/controllers/api.md#delete-prepared-statement)
* [Delete Work Group](../../doc/controllers/api.md#delete-work-group)
* [Export Notebook](../../doc/controllers/api.md#export-notebook)
* [Get Calculation Execution](../../doc/controllers/api.md#get-calculation-execution)
* [Get Calculation Execution Code](../../doc/controllers/api.md#get-calculation-execution-code)
* [Get Calculation Execution Status](../../doc/controllers/api.md#get-calculation-execution-status)
* [Get Data Catalog](../../doc/controllers/api.md#get-data-catalog)
* [Get Database](../../doc/controllers/api.md#get-database)
* [Get Named Query](../../doc/controllers/api.md#get-named-query)
* [Get Notebook Metadata](../../doc/controllers/api.md#get-notebook-metadata)
* [Get Prepared Statement](../../doc/controllers/api.md#get-prepared-statement)
* [Get Query Execution](../../doc/controllers/api.md#get-query-execution)
* [Get Query Results](../../doc/controllers/api.md#get-query-results)
* [Get Query Runtime Statistics](../../doc/controllers/api.md#get-query-runtime-statistics)
* [Get Session](../../doc/controllers/api.md#get-session)
* [Get Session Status](../../doc/controllers/api.md#get-session-status)
* [Get Table Metadata](../../doc/controllers/api.md#get-table-metadata)
* [Get Work Group](../../doc/controllers/api.md#get-work-group)
* [Import Notebook](../../doc/controllers/api.md#import-notebook)
* [List Application DPU Sizes](../../doc/controllers/api.md#list-application-dpu-sizes)
* [List Calculation Executions](../../doc/controllers/api.md#list-calculation-executions)
* [List Data Catalogs](../../doc/controllers/api.md#list-data-catalogs)
* [List Databases](../../doc/controllers/api.md#list-databases)
* [List Engine Versions](../../doc/controllers/api.md#list-engine-versions)
* [List Executors](../../doc/controllers/api.md#list-executors)
* [List Named Queries](../../doc/controllers/api.md#list-named-queries)
* [List Notebook Metadata](../../doc/controllers/api.md#list-notebook-metadata)
* [List Notebook Sessions](../../doc/controllers/api.md#list-notebook-sessions)
* [List Prepared Statements](../../doc/controllers/api.md#list-prepared-statements)
* [List Query Executions](../../doc/controllers/api.md#list-query-executions)
* [List Sessions](../../doc/controllers/api.md#list-sessions)
* [List Table Metadata](../../doc/controllers/api.md#list-table-metadata)
* [List Tags for Resource](../../doc/controllers/api.md#list-tags-for-resource)
* [List Work Groups](../../doc/controllers/api.md#list-work-groups)
* [Start Calculation Execution](../../doc/controllers/api.md#start-calculation-execution)
* [Start Query Execution](../../doc/controllers/api.md#start-query-execution)
* [Start Session](../../doc/controllers/api.md#start-session)
* [Stop Calculation Execution](../../doc/controllers/api.md#stop-calculation-execution)
* [Stop Query Execution](../../doc/controllers/api.md#stop-query-execution)
* [Tag Resource](../../doc/controllers/api.md#tag-resource)
* [Terminate Session](../../doc/controllers/api.md#terminate-session)
* [Untag Resource](../../doc/controllers/api.md#untag-resource)
* [Update Data Catalog](../../doc/controllers/api.md#update-data-catalog)
* [Update Named Query](../../doc/controllers/api.md#update-named-query)
* [Update Notebook](../../doc/controllers/api.md#update-notebook)
* [Update Notebook Metadata](../../doc/controllers/api.md#update-notebook-metadata)
* [Update Prepared Statement](../../doc/controllers/api.md#update-prepared-statement)
* [Update Work Group](../../doc/controllers/api.md#update-work-group)


# Batch Get Named Query

Returns the details of a single named query or a list of up to 50 queries, which you provide as an array of query ID strings. Requires you to have access to the workgroup in which the queries were saved. Use <a>ListNamedQueriesInput</a> to get the list of named query IDs in the specified workgroup. If information could not be retrieved for a submitted query ID, information about the query ID submitted is listed under <a>UnprocessedNamedQueryId</a>. Named queries differ from executed queries. Use <a>BatchGetQueryExecutionInput</a> to get details about each unique query execution, and <a>ListQueryExecutionsInput</a> to get a list of query execution IDs.

```csharp
BatchGetNamedQueryAsync(
    Models.XAmzTargetEnum xAmzTarget,
    Models.BatchGetNamedQueryInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTargetEnum`](../../doc/models/x-amz-target-enum.md) | Header, Required | - |
| `body` | [`BatchGetNamedQueryInput`](../../doc/models/batch-get-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.BatchGetNamedQueryOutput>`](../../doc/models/batch-get-named-query-output.md)

## Example Usage

```csharp
XAmzTargetEnum xAmzTarget = XAmzTargetEnum.EnumAmazonAthenaBatchGetNamedQuery;
BatchGetNamedQueryInput body = new BatchGetNamedQueryInput
{
    NamedQueryIds = new List<string>
    {
        "NamedQueryIds9",
    },
};

try
{
    BatchGetNamedQueryOutput result = await aPIController.BatchGetNamedQueryAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Batch Get Prepared Statement

Returns the details of a single prepared statement or a list of up to 256 prepared statements for the array of prepared statement names that you provide. Requires you to have access to the workgroup to which the prepared statements belong. If a prepared statement cannot be retrieved for the name specified, the statement is listed in <code>UnprocessedPreparedStatementNames</code>.

```csharp
BatchGetPreparedStatementAsync(
    Models.XAmzTarget1Enum xAmzTarget,
    Models.BatchGetPreparedStatementInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget1Enum`](../../doc/models/x-amz-target-1-enum.md) | Header, Required | - |
| `body` | [`BatchGetPreparedStatementInput`](../../doc/models/batch-get-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.BatchGetPreparedStatementOutput>`](../../doc/models/batch-get-prepared-statement-output.md)

## Example Usage

```csharp
XAmzTarget1Enum xAmzTarget = XAmzTarget1Enum.EnumAmazonAthenaBatchGetPreparedStatement;
BatchGetPreparedStatementInput body = new BatchGetPreparedStatementInput
{
    PreparedStatementNames = new List<string>
    {
        "PreparedStatementNames0",
        "PreparedStatementNames1",
        "PreparedStatementNames2",
    },
    WorkGroup = "WorkGroup8",
};

try
{
    BatchGetPreparedStatementOutput result = await aPIController.BatchGetPreparedStatementAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Batch Get Query Execution

Returns the details of a single query execution or a list of up to 50 query executions, which you provide as an array of query execution ID strings. Requires you to have access to the workgroup in which the queries ran. To get a list of query execution IDs, use <a>ListQueryExecutionsInput$WorkGroup</a>. Query executions differ from named (saved) queries. Use <a>BatchGetNamedQueryInput</a> to get details about named queries.

```csharp
BatchGetQueryExecutionAsync(
    Models.XAmzTarget2Enum xAmzTarget,
    Models.BatchGetQueryExecutionInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget2Enum`](../../doc/models/x-amz-target-2-enum.md) | Header, Required | - |
| `body` | [`BatchGetQueryExecutionInput`](../../doc/models/batch-get-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.BatchGetQueryExecutionOutput>`](../../doc/models/batch-get-query-execution-output.md)

## Example Usage

```csharp
XAmzTarget2Enum xAmzTarget = XAmzTarget2Enum.EnumAmazonAthenaBatchGetQueryExecution;
BatchGetQueryExecutionInput body = new BatchGetQueryExecutionInput
{
    QueryExecutionIds = new List<string>
    {
        "QueryExecutionIds3",
    },
};

try
{
    BatchGetQueryExecutionOutput result = await aPIController.BatchGetQueryExecutionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Data Catalog

Creates (registers) a data catalog with the specified name and properties. Catalogs created are visible to all users of the same Amazon Web Services account.

```csharp
CreateDataCatalogAsync(
    Models.XAmzTarget3Enum xAmzTarget,
    Models.CreateDataCatalogInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget3Enum`](../../doc/models/x-amz-target-3-enum.md) | Header, Required | - |
| `body` | [`CreateDataCatalogInput`](../../doc/models/create-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget3Enum xAmzTarget = XAmzTarget3Enum.EnumAmazonAthenaCreateDataCatalog;
CreateDataCatalogInput body = new CreateDataCatalogInput
{
    Name = "Name6",
    Type = DataCatalogType1Enum.HIVE,
};

try
{
    object result = await aPIController.CreateDataCatalogAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Named Query

<p>Creates a named query in the specified workgroup. Requires that you have access to the workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```csharp
CreateNamedQueryAsync(
    Models.XAmzTarget4Enum xAmzTarget,
    Models.CreateNamedQueryInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget4Enum`](../../doc/models/x-amz-target-4-enum.md) | Header, Required | - |
| `body` | [`CreateNamedQueryInput`](../../doc/models/create-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.CreateNamedQueryOutput>`](../../doc/models/create-named-query-output.md)

## Example Usage

```csharp
XAmzTarget4Enum xAmzTarget = XAmzTarget4Enum.EnumAmazonAthenaCreateNamedQuery;
CreateNamedQueryInput body = new CreateNamedQueryInput
{
    Name = "Name6",
    Database = "Database4",
    QueryString = "QueryString8",
};

try
{
    CreateNamedQueryOutput result = await aPIController.CreateNamedQueryAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Notebook

Creates an empty <code>ipynb</code> file in the specified Apache Spark enabled workgroup. Throws an error if a file in the workgroup with the same name already exists.

```csharp
CreateNotebookAsync(
    Models.XAmzTarget5Enum xAmzTarget,
    Models.CreateNotebookInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget5Enum`](../../doc/models/x-amz-target-5-enum.md) | Header, Required | - |
| `body` | [`CreateNotebookInput`](../../doc/models/create-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.CreateNotebookOutput>`](../../doc/models/create-notebook-output.md)

## Example Usage

```csharp
XAmzTarget5Enum xAmzTarget = XAmzTarget5Enum.EnumAmazonAthenaCreateNotebook;
CreateNotebookInput body = new CreateNotebookInput
{
    WorkGroup = "WorkGroup8",
    Name = "Name6",
};

try
{
    CreateNotebookOutput result = await aPIController.CreateNotebookAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Create Prepared Statement

Creates a prepared statement for use with SQL queries in Athena.

```csharp
CreatePreparedStatementAsync(
    Models.XAmzTarget6Enum xAmzTarget,
    Models.CreatePreparedStatementInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget6Enum`](../../doc/models/x-amz-target-6-enum.md) | Header, Required | - |
| `body` | [`CreatePreparedStatementInput`](../../doc/models/create-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget6Enum xAmzTarget = XAmzTarget6Enum.EnumAmazonAthenaCreatePreparedStatement;
CreatePreparedStatementInput body = new CreatePreparedStatementInput
{
    StatementName = "StatementName4",
    WorkGroup = "WorkGroup8",
    QueryStatement = "QueryStatement8",
};

try
{
    object result = await aPIController.CreatePreparedStatementAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Presigned Notebook Url

Gets an authentication token and the URL at which the notebook can be accessed. During programmatic access, <code>CreatePresignedNotebookUrl</code> must be called every 10 minutes to refresh the authentication token. For information about granting programmatic access, see <a href="https://docs.aws.amazon.com/athena/latest/ug/setting-up.html#setting-up-grant-programmatic-access">Grant programmatic access</a>.

```csharp
CreatePresignedNotebookUrlAsync(
    Models.XAmzTarget7Enum xAmzTarget,
    Models.CreatePresignedNotebookUrlRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget7Enum`](../../doc/models/x-amz-target-7-enum.md) | Header, Required | - |
| `body` | [`CreatePresignedNotebookUrlRequest`](../../doc/models/create-presigned-notebook-url-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.CreatePresignedNotebookUrlResponse>`](../../doc/models/create-presigned-notebook-url-response.md)

## Example Usage

```csharp
XAmzTarget7Enum xAmzTarget = XAmzTarget7Enum.EnumAmazonAthenaCreatePresignedNotebookUrl;
CreatePresignedNotebookUrlRequest body = new CreatePresignedNotebookUrlRequest
{
    SessionId = "SessionId2",
};

try
{
    CreatePresignedNotebookUrlResponse result = await aPIController.CreatePresignedNotebookUrlAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Create Work Group

Creates a workgroup with the specified name. A workgroup can be an Apache Spark enabled workgroup or an Athena SQL workgroup.

```csharp
CreateWorkGroupAsync(
    Models.XAmzTarget8Enum xAmzTarget,
    Models.CreateWorkGroupInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget8Enum`](../../doc/models/x-amz-target-8-enum.md) | Header, Required | - |
| `body` | [`CreateWorkGroupInput`](../../doc/models/create-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget8Enum xAmzTarget = XAmzTarget8Enum.EnumAmazonAthenaCreateWorkGroup;
CreateWorkGroupInput body = new CreateWorkGroupInput
{
    Name = "Name6",
};

try
{
    object result = await aPIController.CreateWorkGroupAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Data Catalog

Deletes a data catalog.

```csharp
DeleteDataCatalogAsync(
    Models.XAmzTarget9Enum xAmzTarget,
    Models.DeleteDataCatalogInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget9Enum`](../../doc/models/x-amz-target-9-enum.md) | Header, Required | - |
| `body` | [`DeleteDataCatalogInput`](../../doc/models/delete-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget9Enum xAmzTarget = XAmzTarget9Enum.EnumAmazonAthenaDeleteDataCatalog;
DeleteDataCatalogInput body = new DeleteDataCatalogInput
{
    Name = "Name6",
};

try
{
    object result = await aPIController.DeleteDataCatalogAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Named Query

<p>Deletes the named query if you have access to the workgroup in which the query was saved.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```csharp
DeleteNamedQueryAsync(
    Models.XAmzTarget10Enum xAmzTarget,
    Models.DeleteNamedQueryInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget10Enum`](../../doc/models/x-amz-target-10-enum.md) | Header, Required | - |
| `body` | [`DeleteNamedQueryInput`](../../doc/models/delete-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget10Enum xAmzTarget = XAmzTarget10Enum.EnumAmazonAthenaDeleteNamedQuery;
DeleteNamedQueryInput body = new DeleteNamedQueryInput
{
    NamedQueryId = "NamedQueryId6",
};

try
{
    object result = await aPIController.DeleteNamedQueryAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Notebook

Deletes the specified notebook.

```csharp
DeleteNotebookAsync(
    Models.XAmzTarget11Enum xAmzTarget,
    Models.DeleteNotebookInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget11Enum`](../../doc/models/x-amz-target-11-enum.md) | Header, Required | - |
| `body` | [`DeleteNotebookInput`](../../doc/models/delete-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget11Enum xAmzTarget = XAmzTarget11Enum.EnumAmazonAthenaDeleteNotebook;
DeleteNotebookInput body = new DeleteNotebookInput
{
    NotebookId = "NotebookId6",
};

try
{
    object result = await aPIController.DeleteNotebookAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Delete Prepared Statement

Deletes the prepared statement with the specified name from the specified workgroup.

```csharp
DeletePreparedStatementAsync(
    Models.XAmzTarget12Enum xAmzTarget,
    Models.DeletePreparedStatementInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget12Enum`](../../doc/models/x-amz-target-12-enum.md) | Header, Required | - |
| `body` | [`DeletePreparedStatementInput`](../../doc/models/delete-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget12Enum xAmzTarget = XAmzTarget12Enum.EnumAmazonAthenaDeletePreparedStatement;
DeletePreparedStatementInput body = new DeletePreparedStatementInput
{
    StatementName = "StatementName4",
    WorkGroup = "WorkGroup8",
};

try
{
    object result = await aPIController.DeletePreparedStatementAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Delete Work Group

Deletes the workgroup with the specified name. The primary workgroup cannot be deleted.

```csharp
DeleteWorkGroupAsync(
    Models.XAmzTarget13Enum xAmzTarget,
    Models.DeleteWorkGroupInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget13Enum`](../../doc/models/x-amz-target-13-enum.md) | Header, Required | - |
| `body` | [`DeleteWorkGroupInput`](../../doc/models/delete-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget13Enum xAmzTarget = XAmzTarget13Enum.EnumAmazonAthenaDeleteWorkGroup;
DeleteWorkGroupInput body = new DeleteWorkGroupInput
{
    WorkGroup = "WorkGroup8",
};

try
{
    object result = await aPIController.DeleteWorkGroupAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Export Notebook

Exports the specified notebook and its metadata.

```csharp
ExportNotebookAsync(
    Models.XAmzTarget14Enum xAmzTarget,
    Models.ExportNotebookInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget14Enum`](../../doc/models/x-amz-target-14-enum.md) | Header, Required | - |
| `body` | [`ExportNotebookInput`](../../doc/models/export-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.ExportNotebookOutput>`](../../doc/models/export-notebook-output.md)

## Example Usage

```csharp
XAmzTarget14Enum xAmzTarget = XAmzTarget14Enum.EnumAmazonAthenaExportNotebook;
ExportNotebookInput body = new ExportNotebookInput
{
    NotebookId = "NotebookId6",
};

try
{
    ExportNotebookOutput result = await aPIController.ExportNotebookAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Calculation Execution

Describes a previously submitted calculation execution.

```csharp
GetCalculationExecutionAsync(
    Models.XAmzTarget15Enum xAmzTarget,
    Models.GetCalculationExecutionRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget15Enum`](../../doc/models/x-amz-target-15-enum.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionRequest`](../../doc/models/get-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetCalculationExecutionResponse>`](../../doc/models/get-calculation-execution-response.md)

## Example Usage

```csharp
XAmzTarget15Enum xAmzTarget = XAmzTarget15Enum.EnumAmazonAthenaGetCalculationExecution;
GetCalculationExecutionRequest body = new GetCalculationExecutionRequest
{
    CalculationExecutionId = "CalculationExecutionId8",
};

try
{
    GetCalculationExecutionResponse result = await aPIController.GetCalculationExecutionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Calculation Execution Code

Retrieves the unencrypted code that was executed for the calculation.

```csharp
GetCalculationExecutionCodeAsync(
    Models.XAmzTarget16Enum xAmzTarget,
    Models.GetCalculationExecutionCodeRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget16Enum`](../../doc/models/x-amz-target-16-enum.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionCodeRequest`](../../doc/models/get-calculation-execution-code-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetCalculationExecutionCodeResponse>`](../../doc/models/get-calculation-execution-code-response.md)

## Example Usage

```csharp
XAmzTarget16Enum xAmzTarget = XAmzTarget16Enum.EnumAmazonAthenaGetCalculationExecutionCode;
GetCalculationExecutionCodeRequest body = new GetCalculationExecutionCodeRequest
{
    CalculationExecutionId = "CalculationExecutionId8",
};

try
{
    GetCalculationExecutionCodeResponse result = await aPIController.GetCalculationExecutionCodeAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Calculation Execution Status

Gets the status of a current calculation.

```csharp
GetCalculationExecutionStatusAsync(
    Models.XAmzTarget17Enum xAmzTarget,
    Models.GetCalculationExecutionStatusRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget17Enum`](../../doc/models/x-amz-target-17-enum.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionStatusRequest`](../../doc/models/get-calculation-execution-status-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetCalculationExecutionStatusResponse>`](../../doc/models/get-calculation-execution-status-response.md)

## Example Usage

```csharp
XAmzTarget17Enum xAmzTarget = XAmzTarget17Enum.EnumAmazonAthenaGetCalculationExecutionStatus;
GetCalculationExecutionStatusRequest body = new GetCalculationExecutionStatusRequest
{
    CalculationExecutionId = "CalculationExecutionId8",
};

try
{
    GetCalculationExecutionStatusResponse result = await aPIController.GetCalculationExecutionStatusAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Data Catalog

Returns the specified data catalog.

```csharp
GetDataCatalogAsync(
    Models.XAmzTarget18Enum xAmzTarget,
    Models.GetDataCatalogInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget18Enum`](../../doc/models/x-amz-target-18-enum.md) | Header, Required | - |
| `body` | [`GetDataCatalogInput`](../../doc/models/get-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetDataCatalogOutput>`](../../doc/models/get-data-catalog-output.md)

## Example Usage

```csharp
XAmzTarget18Enum xAmzTarget = XAmzTarget18Enum.EnumAmazonAthenaGetDataCatalog;
GetDataCatalogInput body = new GetDataCatalogInput
{
    Name = "Name6",
};

try
{
    GetDataCatalogOutput result = await aPIController.GetDataCatalogAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Database

Returns a database object for the specified database and data catalog.

```csharp
GetDatabaseAsync(
    Models.XAmzTarget19Enum xAmzTarget,
    Models.GetDatabaseInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget19Enum`](../../doc/models/x-amz-target-19-enum.md) | Header, Required | - |
| `body` | [`GetDatabaseInput`](../../doc/models/get-database-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetDatabaseOutput>`](../../doc/models/get-database-output.md)

## Example Usage

```csharp
XAmzTarget19Enum xAmzTarget = XAmzTarget19Enum.EnumAmazonAthenaGetDatabase;
GetDatabaseInput body = new GetDatabaseInput
{
    CatalogName = "CatalogName0",
    DatabaseName = "DatabaseName0",
};

try
{
    GetDatabaseOutput result = await aPIController.GetDatabaseAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# Get Named Query

Returns information about a single query. Requires that you have access to the workgroup in which the query was saved.

```csharp
GetNamedQueryAsync(
    Models.XAmzTarget20Enum xAmzTarget,
    Models.GetNamedQueryInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget20Enum`](../../doc/models/x-amz-target-20-enum.md) | Header, Required | - |
| `body` | [`GetNamedQueryInput`](../../doc/models/get-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetNamedQueryOutput>`](../../doc/models/get-named-query-output.md)

## Example Usage

```csharp
XAmzTarget20Enum xAmzTarget = XAmzTarget20Enum.EnumAmazonAthenaGetNamedQuery;
GetNamedQueryInput body = new GetNamedQueryInput
{
    NamedQueryId = "NamedQueryId6",
};

try
{
    GetNamedQueryOutput result = await aPIController.GetNamedQueryAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Notebook Metadata

Retrieves notebook metadata for the specified notebook ID.

```csharp
GetNotebookMetadataAsync(
    Models.XAmzTarget21Enum xAmzTarget,
    Models.GetNotebookMetadataInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget21Enum`](../../doc/models/x-amz-target-21-enum.md) | Header, Required | - |
| `body` | [`GetNotebookMetadataInput`](../../doc/models/get-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetNotebookMetadataOutput>`](../../doc/models/get-notebook-metadata-output.md)

## Example Usage

```csharp
XAmzTarget21Enum xAmzTarget = XAmzTarget21Enum.EnumAmazonAthenaGetNotebookMetadata;
GetNotebookMetadataInput body = new GetNotebookMetadataInput
{
    NotebookId = "NotebookId6",
};

try
{
    GetNotebookMetadataOutput result = await aPIController.GetNotebookMetadataAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Prepared Statement

Retrieves the prepared statement with the specified name from the specified workgroup.

```csharp
GetPreparedStatementAsync(
    Models.XAmzTarget22Enum xAmzTarget,
    Models.GetPreparedStatementInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget22Enum`](../../doc/models/x-amz-target-22-enum.md) | Header, Required | - |
| `body` | [`GetPreparedStatementInput`](../../doc/models/get-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetPreparedStatementOutput>`](../../doc/models/get-prepared-statement-output.md)

## Example Usage

```csharp
XAmzTarget22Enum xAmzTarget = XAmzTarget22Enum.EnumAmazonAthenaGetPreparedStatement;
GetPreparedStatementInput body = new GetPreparedStatementInput
{
    StatementName = "StatementName4",
    WorkGroup = "WorkGroup8",
};

try
{
    GetPreparedStatementOutput result = await aPIController.GetPreparedStatementAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Query Execution

Returns information about a single execution of a query if you have access to the workgroup in which the query ran. Each time a query executes, information about the query execution is saved with a unique ID.

```csharp
GetQueryExecutionAsync(
    Models.XAmzTarget23Enum xAmzTarget,
    Models.GetQueryExecutionInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget23Enum`](../../doc/models/x-amz-target-23-enum.md) | Header, Required | - |
| `body` | [`GetQueryExecutionInput`](../../doc/models/get-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetQueryExecutionOutput>`](../../doc/models/get-query-execution-output.md)

## Example Usage

```csharp
XAmzTarget23Enum xAmzTarget = XAmzTarget23Enum.EnumAmazonAthenaGetQueryExecution;
GetQueryExecutionInput body = new GetQueryExecutionInput
{
    QueryExecutionId = "QueryExecutionId0",
};

try
{
    GetQueryExecutionOutput result = await aPIController.GetQueryExecutionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Query Results

<p>Streams the results of a single query execution specified by <code>QueryExecutionId</code> from the Athena query results location in Amazon S3. For more information, see <a href="https://docs.aws.amazon.com/athena/latest/ug/querying.html">Working with query results, recent queries, and output files</a> in the <i>Amazon Athena User Guide</i>. This request does not execute the query but returns results. Use <a>StartQueryExecution</a> to run a query.</p> <p>To stream query results successfully, the IAM principal with permission to call <code>GetQueryResults</code> also must have permissions to the Amazon S3 <code>GetObject</code> action for the Athena query results location.</p> <important> <p>IAM principals with permission to the Amazon S3 <code>GetObject</code> action for the query results location are able to retrieve query results from Amazon S3 even if permission to the <code>GetQueryResults</code> action is denied. To restrict user or role access, ensure that Amazon S3 permissions to the Athena query location are denied.</p> </important>


```csharp
GetQueryResultsAsync(
    Models.XAmzTarget24Enum xAmzTarget,
    Models.GetQueryResultsInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget24Enum`](../../doc/models/x-amz-target-24-enum.md) | Header, Required | - |
| `body` | [`GetQueryResultsInput`](../../doc/models/get-query-results-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.GetQueryResultsOutput>`](../../doc/models/get-query-results-output.md)

## Example Usage

```csharp
XAmzTarget24Enum xAmzTarget = XAmzTarget24Enum.EnumAmazonAthenaGetQueryResults;
GetQueryResultsInput body = new GetQueryResultsInput
{
    QueryExecutionId = "QueryExecutionId0",
};

try
{
    GetQueryResultsOutput result = await aPIController.GetQueryResultsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Query Runtime Statistics

Returns query execution runtime statistics related to a single execution of a query if you have access to the workgroup in which the query ran. Query execution runtime statistics are returned only when <a>QueryExecutionStatus$State</a> is in a SUCCEEDED or FAILED state. Stage-level input and output row count and data size statistics are not shown when a query has row-level filters defined in Lake Formation.

```csharp
GetQueryRuntimeStatisticsAsync(
    Models.XAmzTarget25Enum xAmzTarget,
    Models.GetQueryRuntimeStatisticsInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget25Enum`](../../doc/models/x-amz-target-25-enum.md) | Header, Required | - |
| `body` | [`GetQueryRuntimeStatisticsInput`](../../doc/models/get-query-runtime-statistics-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetQueryRuntimeStatisticsOutput>`](../../doc/models/get-query-runtime-statistics-output.md)

## Example Usage

```csharp
XAmzTarget25Enum xAmzTarget = XAmzTarget25Enum.EnumAmazonAthenaGetQueryRuntimeStatistics;
GetQueryRuntimeStatisticsInput body = new GetQueryRuntimeStatisticsInput
{
    QueryExecutionId = "QueryExecutionId0",
};

try
{
    GetQueryRuntimeStatisticsOutput result = await aPIController.GetQueryRuntimeStatisticsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Session

Gets the full details of a previously created session, including the session status and configuration.

```csharp
GetSessionAsync(
    Models.XAmzTarget26Enum xAmzTarget,
    Models.GetSessionRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget26Enum`](../../doc/models/x-amz-target-26-enum.md) | Header, Required | - |
| `body` | [`GetSessionRequest`](../../doc/models/get-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetSessionResponse>`](../../doc/models/get-session-response.md)

## Example Usage

```csharp
XAmzTarget26Enum xAmzTarget = XAmzTarget26Enum.EnumAmazonAthenaGetSession;
GetSessionRequest body = new GetSessionRequest
{
    SessionId = "SessionId2",
};

try
{
    GetSessionResponse result = await aPIController.GetSessionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Session Status

Gets the current status of a session.

```csharp
GetSessionStatusAsync(
    Models.XAmzTarget27Enum xAmzTarget,
    Models.GetSessionStatusRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget27Enum`](../../doc/models/x-amz-target-27-enum.md) | Header, Required | - |
| `body` | [`GetSessionStatusRequest`](../../doc/models/get-session-status-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetSessionStatusResponse>`](../../doc/models/get-session-status-response.md)

## Example Usage

```csharp
XAmzTarget27Enum xAmzTarget = XAmzTarget27Enum.EnumAmazonAthenaGetSessionStatus;
GetSessionStatusRequest body = new GetSessionStatusRequest
{
    SessionId = "SessionId2",
};

try
{
    GetSessionStatusResponse result = await aPIController.GetSessionStatusAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Table Metadata

Returns table metadata for the specified catalog, database, and table.

```csharp
GetTableMetadataAsync(
    Models.XAmzTarget28Enum xAmzTarget,
    Models.GetTableMetadataInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget28Enum`](../../doc/models/x-amz-target-28-enum.md) | Header, Required | - |
| `body` | [`GetTableMetadataInput`](../../doc/models/get-table-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetTableMetadataOutput>`](../../doc/models/get-table-metadata-output.md)

## Example Usage

```csharp
XAmzTarget28Enum xAmzTarget = XAmzTarget28Enum.EnumAmazonAthenaGetTableMetadata;
GetTableMetadataInput body = new GetTableMetadataInput
{
    CatalogName = "CatalogName0",
    DatabaseName = "DatabaseName0",
    TableName = "TableName2",
};

try
{
    GetTableMetadataOutput result = await aPIController.GetTableMetadataAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# Get Work Group

Returns information about the workgroup with the specified name.

```csharp
GetWorkGroupAsync(
    Models.XAmzTarget29Enum xAmzTarget,
    Models.GetWorkGroupInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget29Enum`](../../doc/models/x-amz-target-29-enum.md) | Header, Required | - |
| `body` | [`GetWorkGroupInput`](../../doc/models/get-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.GetWorkGroupOutput>`](../../doc/models/get-work-group-output.md)

## Example Usage

```csharp
XAmzTarget29Enum xAmzTarget = XAmzTarget29Enum.EnumAmazonAthenaGetWorkGroup;
GetWorkGroupInput body = new GetWorkGroupInput
{
    WorkGroup = "WorkGroup8",
};

try
{
    GetWorkGroupOutput result = await aPIController.GetWorkGroupAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Import Notebook

Imports a single <code>ipynb</code> file to a Spark enabled workgroup. The maximum file size that can be imported is 10 megabytes. If an <code>ipynb</code> file with the same name already exists in the workgroup, throws an error.

```csharp
ImportNotebookAsync(
    Models.XAmzTarget30Enum xAmzTarget,
    Models.ImportNotebookInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget30Enum`](../../doc/models/x-amz-target-30-enum.md) | Header, Required | - |
| `body` | [`ImportNotebookInput`](../../doc/models/import-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.ImportNotebookOutput>`](../../doc/models/import-notebook-output.md)

## Example Usage

```csharp
XAmzTarget30Enum xAmzTarget = XAmzTarget30Enum.EnumAmazonAthenaImportNotebook;
ImportNotebookInput body = new ImportNotebookInput
{
    WorkGroup = "WorkGroup8",
    Name = "Name6",
    Payload = "Payload2",
    Type = NotebookType2Enum.IPYNB,
};

try
{
    ImportNotebookOutput result = await aPIController.ImportNotebookAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Application DPU Sizes

Returns the supported DPU sizes for the supported application runtimes (for example, <code>Athena notebook version 1</code>).

```csharp
ListApplicationDPUSizesAsync(
    Models.XAmzTarget31Enum xAmzTarget,
    Models.ListApplicationDPUSizesInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget31Enum`](../../doc/models/x-amz-target-31-enum.md) | Header, Required | - |
| `body` | [`ListApplicationDPUSizesInput`](../../doc/models/list-application-dpu-sizes-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListApplicationDPUSizesOutput>`](../../doc/models/list-application-dpu-sizes-output.md)

## Example Usage

```csharp
XAmzTarget31Enum xAmzTarget = XAmzTarget31Enum.EnumAmazonAthenaListApplicationDPUSizes;
ListApplicationDPUSizesInput body = new ListApplicationDPUSizesInput
{
};

try
{
    ListApplicationDPUSizesOutput result = await aPIController.ListApplicationDPUSizesAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Calculation Executions

Lists the calculations that have been submitted to a session in descending order. Newer calculations are listed first; older calculations are listed later.

```csharp
ListCalculationExecutionsAsync(
    Models.XAmzTarget32Enum xAmzTarget,
    Models.ListCalculationExecutionsRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget32Enum`](../../doc/models/x-amz-target-32-enum.md) | Header, Required | - |
| `body` | [`ListCalculationExecutionsRequest`](../../doc/models/list-calculation-executions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListCalculationExecutionsResponse>`](../../doc/models/list-calculation-executions-response.md)

## Example Usage

```csharp
XAmzTarget32Enum xAmzTarget = XAmzTarget32Enum.EnumAmazonAthenaListCalculationExecutions;
ListCalculationExecutionsRequest body = new ListCalculationExecutionsRequest
{
    SessionId = "SessionId2",
};

try
{
    ListCalculationExecutionsResponse result = await aPIController.ListCalculationExecutionsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Data Catalogs

<p>Lists the data catalogs in the current Amazon Web Services account.</p> <note> <p>In the Athena console, data catalogs are listed as "data sources" on the <b>Data sources</b> page under the <b>Data source name</b> column.</p> </note>


```csharp
ListDataCatalogsAsync(
    Models.XAmzTarget33Enum xAmzTarget,
    Models.ListDataCatalogsInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget33Enum`](../../doc/models/x-amz-target-33-enum.md) | Header, Required | - |
| `body` | [`ListDataCatalogsInput`](../../doc/models/list-data-catalogs-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListDataCatalogsOutput>`](../../doc/models/list-data-catalogs-output.md)

## Example Usage

```csharp
XAmzTarget33Enum xAmzTarget = XAmzTarget33Enum.EnumAmazonAthenaListDataCatalogs;
ListDataCatalogsInput body = new ListDataCatalogsInput
{
};

try
{
    ListDataCatalogsOutput result = await aPIController.ListDataCatalogsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Databases

Lists the databases in the specified data catalog.

```csharp
ListDatabasesAsync(
    Models.XAmzTarget34Enum xAmzTarget,
    Models.ListDatabasesInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget34Enum`](../../doc/models/x-amz-target-34-enum.md) | Header, Required | - |
| `body` | [`ListDatabasesInput`](../../doc/models/list-databases-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListDatabasesOutput>`](../../doc/models/list-databases-output.md)

## Example Usage

```csharp
XAmzTarget34Enum xAmzTarget = XAmzTarget34Enum.EnumAmazonAthenaListDatabases;
ListDatabasesInput body = new ListDatabasesInput
{
    CatalogName = "CatalogName0",
};

try
{
    ListDatabasesOutput result = await aPIController.ListDatabasesAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# List Engine Versions

Returns a list of engine versions that are available to choose from, including the Auto option.

```csharp
ListEngineVersionsAsync(
    Models.XAmzTarget35Enum xAmzTarget,
    Models.ListEngineVersionsInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget35Enum`](../../doc/models/x-amz-target-35-enum.md) | Header, Required | - |
| `body` | [`ListEngineVersionsInput`](../../doc/models/list-engine-versions-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListEngineVersionsOutput>`](../../doc/models/list-engine-versions-output.md)

## Example Usage

```csharp
XAmzTarget35Enum xAmzTarget = XAmzTarget35Enum.EnumAmazonAthenaListEngineVersions;
ListEngineVersionsInput body = new ListEngineVersionsInput
{
};

try
{
    ListEngineVersionsOutput result = await aPIController.ListEngineVersionsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Executors

Lists, in descending order, the executors that joined a session. Newer executors are listed first; older executors are listed later. The result can be optionally filtered by state.

```csharp
ListExecutorsAsync(
    Models.XAmzTarget36Enum xAmzTarget,
    Models.ListExecutorsRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget36Enum`](../../doc/models/x-amz-target-36-enum.md) | Header, Required | - |
| `body` | [`ListExecutorsRequest`](../../doc/models/list-executors-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListExecutorsResponse>`](../../doc/models/list-executors-response.md)

## Example Usage

```csharp
XAmzTarget36Enum xAmzTarget = XAmzTarget36Enum.EnumAmazonAthenaListExecutors;
ListExecutorsRequest body = new ListExecutorsRequest
{
    SessionId = "SessionId2",
};

try
{
    ListExecutorsResponse result = await aPIController.ListExecutorsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Named Queries

<p>Provides a list of available query IDs only for queries saved in the specified workgroup. Requires that you have access to the specified workgroup. If a workgroup is not specified, lists the saved queries for the primary workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```csharp
ListNamedQueriesAsync(
    Models.XAmzTarget37Enum xAmzTarget,
    Models.ListNamedQueriesInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget37Enum`](../../doc/models/x-amz-target-37-enum.md) | Header, Required | - |
| `body` | [`ListNamedQueriesInput`](../../doc/models/list-named-queries-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListNamedQueriesOutput>`](../../doc/models/list-named-queries-output.md)

## Example Usage

```csharp
XAmzTarget37Enum xAmzTarget = XAmzTarget37Enum.EnumAmazonAthenaListNamedQueries;
ListNamedQueriesInput body = new ListNamedQueriesInput
{
};

try
{
    ListNamedQueriesOutput result = await aPIController.ListNamedQueriesAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Notebook Metadata

Displays the notebook files for the specified workgroup in paginated format.

```csharp
ListNotebookMetadataAsync(
    Models.XAmzTarget38Enum xAmzTarget,
    Models.ListNotebookMetadataInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget38Enum`](../../doc/models/x-amz-target-38-enum.md) | Header, Required | - |
| `body` | [`ListNotebookMetadataInput`](../../doc/models/list-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.ListNotebookMetadataOutput>`](../../doc/models/list-notebook-metadata-output.md)

## Example Usage

```csharp
XAmzTarget38Enum xAmzTarget = XAmzTarget38Enum.EnumAmazonAthenaListNotebookMetadata;
ListNotebookMetadataInput body = new ListNotebookMetadataInput
{
    WorkGroup = "WorkGroup8",
};

try
{
    ListNotebookMetadataOutput result = await aPIController.ListNotebookMetadataAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Notebook Sessions

Lists, in descending order, the sessions that have been created in a notebook that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code> or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```csharp
ListNotebookSessionsAsync(
    Models.XAmzTarget39Enum xAmzTarget,
    Models.ListNotebookSessionsRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget39Enum`](../../doc/models/x-amz-target-39-enum.md) | Header, Required | - |
| `body` | [`ListNotebookSessionsRequest`](../../doc/models/list-notebook-sessions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.ListNotebookSessionsResponse>`](../../doc/models/list-notebook-sessions-response.md)

## Example Usage

```csharp
XAmzTarget39Enum xAmzTarget = XAmzTarget39Enum.EnumAmazonAthenaListNotebookSessions;
ListNotebookSessionsRequest body = new ListNotebookSessionsRequest
{
    NotebookId = "NotebookId6",
};

try
{
    ListNotebookSessionsResponse result = await aPIController.ListNotebookSessionsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Prepared Statements

Lists the prepared statements in the specified workgroup.

```csharp
ListPreparedStatementsAsync(
    Models.XAmzTarget40Enum xAmzTarget,
    Models.ListPreparedStatementsInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget40Enum`](../../doc/models/x-amz-target-40-enum.md) | Header, Required | - |
| `body` | [`ListPreparedStatementsInput`](../../doc/models/list-prepared-statements-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListPreparedStatementsOutput>`](../../doc/models/list-prepared-statements-output.md)

## Example Usage

```csharp
XAmzTarget40Enum xAmzTarget = XAmzTarget40Enum.EnumAmazonAthenaListPreparedStatements;
ListPreparedStatementsInput body = new ListPreparedStatementsInput
{
    WorkGroup = "WorkGroup8",
};

try
{
    ListPreparedStatementsOutput result = await aPIController.ListPreparedStatementsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Query Executions

<p>Provides a list of available query execution IDs for the queries in the specified workgroup. If a workgroup is not specified, returns a list of query execution IDs for the primary workgroup. Requires you to have access to the workgroup in which the queries ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```csharp
ListQueryExecutionsAsync(
    Models.XAmzTarget41Enum xAmzTarget,
    Models.ListQueryExecutionsInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget41Enum`](../../doc/models/x-amz-target-41-enum.md) | Header, Required | - |
| `body` | [`ListQueryExecutionsInput`](../../doc/models/list-query-executions-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListQueryExecutionsOutput>`](../../doc/models/list-query-executions-output.md)

## Example Usage

```csharp
XAmzTarget41Enum xAmzTarget = XAmzTarget41Enum.EnumAmazonAthenaListQueryExecutions;
ListQueryExecutionsInput body = new ListQueryExecutionsInput
{
};

try
{
    ListQueryExecutionsOutput result = await aPIController.ListQueryExecutionsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Sessions

Lists the sessions in a workgroup that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code>, or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```csharp
ListSessionsAsync(
    Models.XAmzTarget42Enum xAmzTarget,
    Models.ListSessionsRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget42Enum`](../../doc/models/x-amz-target-42-enum.md) | Header, Required | - |
| `body` | [`ListSessionsRequest`](../../doc/models/list-sessions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListSessionsResponse>`](../../doc/models/list-sessions-response.md)

## Example Usage

```csharp
XAmzTarget42Enum xAmzTarget = XAmzTarget42Enum.EnumAmazonAthenaListSessions;
ListSessionsRequest body = new ListSessionsRequest
{
    WorkGroup = "WorkGroup8",
};

try
{
    ListSessionsResponse result = await aPIController.ListSessionsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Table Metadata

Lists the metadata for the tables in the specified data catalog database.

```csharp
ListTableMetadataAsync(
    Models.XAmzTarget43Enum xAmzTarget,
    Models.ListTableMetadataInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget43Enum`](../../doc/models/x-amz-target-43-enum.md) | Header, Required | - |
| `body` | [`ListTableMetadataInput`](../../doc/models/list-table-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListTableMetadataOutput>`](../../doc/models/list-table-metadata-output.md)

## Example Usage

```csharp
XAmzTarget43Enum xAmzTarget = XAmzTarget43Enum.EnumAmazonAthenaListTableMetadata;
ListTableMetadataInput body = new ListTableMetadataInput
{
    CatalogName = "CatalogName0",
    DatabaseName = "DatabaseName0",
};

try
{
    ListTableMetadataOutput result = await aPIController.ListTableMetadataAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# List Tags for Resource

Lists the tags associated with an Athena workgroup or data catalog resource.

```csharp
ListTagsForResourceAsync(
    Models.XAmzTarget44Enum xAmzTarget,
    Models.ListTagsForResourceInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget44Enum`](../../doc/models/x-amz-target-44-enum.md) | Header, Required | - |
| `body` | [`ListTagsForResourceInput`](../../doc/models/list-tags-for-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListTagsForResourceOutput>`](../../doc/models/list-tags-for-resource-output.md)

## Example Usage

```csharp
XAmzTarget44Enum xAmzTarget = XAmzTarget44Enum.EnumAmazonAthenaListTagsForResource;
ListTagsForResourceInput body = new ListTagsForResourceInput
{
    ResourceARN = "ResourceARN4",
};

try
{
    ListTagsForResourceOutput result = await aPIController.ListTagsForResourceAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Work Groups

Lists available workgroups for the account.

```csharp
ListWorkGroupsAsync(
    Models.XAmzTarget45Enum xAmzTarget,
    Models.ListWorkGroupsInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null,
    string maxResults = null,
    string nextToken = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget45Enum`](../../doc/models/x-amz-target-45-enum.md) | Header, Required | - |
| `body` | [`ListWorkGroupsInput`](../../doc/models/list-work-groups-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |
| `maxResults` | `string` | Query, Optional | Pagination limit |
| `nextToken` | `string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`Task<Models.ListWorkGroupsOutput>`](../../doc/models/list-work-groups-output.md)

## Example Usage

```csharp
XAmzTarget45Enum xAmzTarget = XAmzTarget45Enum.EnumAmazonAthenaListWorkGroups;
ListWorkGroupsInput body = new ListWorkGroupsInput
{
};

try
{
    ListWorkGroupsOutput result = await aPIController.ListWorkGroupsAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Start Calculation Execution

Submits calculations for execution within a session. You can supply the code to run as an inline code block within the request.

```csharp
StartCalculationExecutionAsync(
    Models.XAmzTarget46Enum xAmzTarget,
    Models.StartCalculationExecutionRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget46Enum`](../../doc/models/x-amz-target-46-enum.md) | Header, Required | - |
| `body` | [`StartCalculationExecutionRequest`](../../doc/models/start-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.StartCalculationExecutionResponse>`](../../doc/models/start-calculation-execution-response.md)

## Example Usage

```csharp
XAmzTarget46Enum xAmzTarget = XAmzTarget46Enum.EnumAmazonAthenaStartCalculationExecution;
StartCalculationExecutionRequest body = new StartCalculationExecutionRequest
{
    SessionId = "SessionId2",
};

try
{
    StartCalculationExecutionResponse result = await aPIController.StartCalculationExecutionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Start Query Execution

Runs the SQL query statements contained in the <code>Query</code>. Requires you to have access to the workgroup in which the query ran. Running queries against an external catalog requires <a>GetDataCatalog</a> permission to the catalog. For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.

```csharp
StartQueryExecutionAsync(
    Models.XAmzTarget47Enum xAmzTarget,
    Models.StartQueryExecutionInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget47Enum`](../../doc/models/x-amz-target-47-enum.md) | Header, Required | - |
| `body` | [`StartQueryExecutionInput`](../../doc/models/start-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.StartQueryExecutionOutput>`](../../doc/models/start-query-execution-output.md)

## Example Usage

```csharp
XAmzTarget47Enum xAmzTarget = XAmzTarget47Enum.EnumAmazonAthenaStartQueryExecution;
StartQueryExecutionInput body = new StartQueryExecutionInput
{
    QueryString = "QueryString8",
};

try
{
    StartQueryExecutionOutput result = await aPIController.StartQueryExecutionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Start Session

Creates a session for running calculations within a workgroup. The session is ready when it reaches an <code>IDLE</code> state.

```csharp
StartSessionAsync(
    Models.XAmzTarget48Enum xAmzTarget,
    Models.StartSessionRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget48Enum`](../../doc/models/x-amz-target-48-enum.md) | Header, Required | - |
| `body` | [`StartSessionRequest`](../../doc/models/start-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.StartSessionResponse>`](../../doc/models/start-session-response.md)

## Example Usage

```csharp
XAmzTarget48Enum xAmzTarget = XAmzTarget48Enum.EnumAmazonAthenaStartSession;
StartSessionRequest body = new StartSessionRequest
{
    WorkGroup = "WorkGroup8",
    EngineConfiguration = new EngineConfiguration1
    {
        MaxConcurrentDpus = 94,
    },
};

try
{
    StartSessionResponse result = await aPIController.StartSessionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |
| 483 | SessionAlreadyExistsException | `ApiException` |
| 484 | TooManyRequestsException | `ApiException` |


# Stop Calculation Execution

<p>Requests the cancellation of a calculation. A <code>StopCalculationExecution</code> call on a calculation that is already in a terminal state (for example, <code>STOPPED</code>, <code>FAILED</code>, or <code>COMPLETED</code>) succeeds but has no effect.</p> <note> <p>Cancelling a calculation is done on a best effort basis. If a calculation cannot be cancelled, you can be charged for its completion. If you are concerned about being charged for a calculation that cannot be cancelled, consider terminating the session in which the calculation is running.</p> </note>


```csharp
StopCalculationExecutionAsync(
    Models.XAmzTarget49Enum xAmzTarget,
    Models.StopCalculationExecutionRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget49Enum`](../../doc/models/x-amz-target-49-enum.md) | Header, Required | - |
| `body` | [`StopCalculationExecutionRequest`](../../doc/models/stop-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.StopCalculationExecutionResponse>`](../../doc/models/stop-calculation-execution-response.md)

## Example Usage

```csharp
XAmzTarget49Enum xAmzTarget = XAmzTarget49Enum.EnumAmazonAthenaStopCalculationExecution;
StopCalculationExecutionRequest body = new StopCalculationExecutionRequest
{
    CalculationExecutionId = "CalculationExecutionId8",
};

try
{
    StopCalculationExecutionResponse result = await aPIController.StopCalculationExecutionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Stop Query Execution

<p>Stops a query execution. Requires you to have access to the workgroup in which the query ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```csharp
StopQueryExecutionAsync(
    Models.XAmzTarget50Enum xAmzTarget,
    Models.StopQueryExecutionInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget50Enum`](../../doc/models/x-amz-target-50-enum.md) | Header, Required | - |
| `body` | [`StopQueryExecutionInput`](../../doc/models/stop-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget50Enum xAmzTarget = XAmzTarget50Enum.EnumAmazonAthenaStopQueryExecution;
StopQueryExecutionInput body = new StopQueryExecutionInput
{
    QueryExecutionId = "QueryExecutionId0",
};

try
{
    object result = await aPIController.StopQueryExecutionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Tag Resource

Adds one or more tags to an Athena resource. A tag is a label that you assign to a resource. In Athena, a resource can be a workgroup or data catalog. Each tag consists of a key and an optional value, both of which you define. For example, you can use tags to categorize Athena workgroups or data catalogs by purpose, owner, or environment. Use a consistent set of tag keys to make it easier to search and filter workgroups or data catalogs in your account. For best practices, see <a href="https://docs.aws.amazon.com/whitepapers/latest/tagging-best-practices/tagging-best-practices.html">Tagging Best Practices</a>. Tag keys can be from 1 to 128 UTF-8 Unicode characters, and tag values can be from 0 to 256 UTF-8 Unicode characters. Tags can use letters and numbers representable in UTF-8, and the following characters: + - = . _ : / @. Tag keys and values are case-sensitive. Tag keys must be unique per resource. If you specify more than one tag, separate them by commas.

```csharp
TagResourceAsync(
    Models.XAmzTarget51Enum xAmzTarget,
    Models.TagResourceInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget51Enum`](../../doc/models/x-amz-target-51-enum.md) | Header, Required | - |
| `body` | [`TagResourceInput`](../../doc/models/tag-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget51Enum xAmzTarget = XAmzTarget51Enum.EnumAmazonAthenaTagResource;
TagResourceInput body = new TagResourceInput
{
    ResourceARN = "ResourceARN4",
    Tags = new List<Tag>
    {
        new Tag
        {
        },
    },
};

try
{
    object result = await aPIController.TagResourceAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Terminate Session

Terminates an active session. A <code>TerminateSession</code> call on a session that is already inactive (for example, in a <code>FAILED</code>, <code>TERMINATED</code> or <code>TERMINATING</code> state) succeeds but has no effect. Calculations running in the session when <code>TerminateSession</code> is called are forcefully stopped, but may display as <code>FAILED</code> instead of <code>STOPPED</code>.

```csharp
TerminateSessionAsync(
    Models.XAmzTarget52Enum xAmzTarget,
    Models.TerminateSessionRequest body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget52Enum`](../../doc/models/x-amz-target-52-enum.md) | Header, Required | - |
| `body` | [`TerminateSessionRequest`](../../doc/models/terminate-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

[`Task<Models.TerminateSessionResponse>`](../../doc/models/terminate-session-response.md)

## Example Usage

```csharp
XAmzTarget52Enum xAmzTarget = XAmzTarget52Enum.EnumAmazonAthenaTerminateSession;
TerminateSessionRequest body = new TerminateSessionRequest
{
    SessionId = "SessionId2",
};

try
{
    TerminateSessionResponse result = await aPIController.TerminateSessionAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Untag Resource

Removes one or more tags from a data catalog or workgroup resource.

```csharp
UntagResourceAsync(
    Models.XAmzTarget53Enum xAmzTarget,
    Models.UntagResourceInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget53Enum`](../../doc/models/x-amz-target-53-enum.md) | Header, Required | - |
| `body` | [`UntagResourceInput`](../../doc/models/untag-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget53Enum xAmzTarget = XAmzTarget53Enum.EnumAmazonAthenaUntagResource;
UntagResourceInput body = new UntagResourceInput
{
    ResourceARN = "ResourceARN4",
    TagKeys = new List<string>
    {
        "TagKeys9",
        "TagKeys0",
    },
};

try
{
    object result = await aPIController.UntagResourceAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Update Data Catalog

Updates the data catalog that has the specified name.

```csharp
UpdateDataCatalogAsync(
    Models.XAmzTarget54Enum xAmzTarget,
    Models.UpdateDataCatalogInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget54Enum`](../../doc/models/x-amz-target-54-enum.md) | Header, Required | - |
| `body` | [`UpdateDataCatalogInput`](../../doc/models/update-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget54Enum xAmzTarget = XAmzTarget54Enum.EnumAmazonAthenaUpdateDataCatalog;
UpdateDataCatalogInput body = new UpdateDataCatalogInput
{
    Name = "Name6",
    Type = DataCatalogType3Enum.HIVE,
};

try
{
    object result = await aPIController.UpdateDataCatalogAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Update Named Query

Updates a <a>NamedQuery</a> object. The database or workgroup cannot be updated.

```csharp
UpdateNamedQueryAsync(
    Models.XAmzTarget55Enum xAmzTarget,
    Models.UpdateNamedQueryInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget55Enum`](../../doc/models/x-amz-target-55-enum.md) | Header, Required | - |
| `body` | [`UpdateNamedQueryInput`](../../doc/models/update-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget55Enum xAmzTarget = XAmzTarget55Enum.EnumAmazonAthenaUpdateNamedQuery;
UpdateNamedQueryInput body = new UpdateNamedQueryInput
{
    NamedQueryId = "NamedQueryId6",
    Name = "Name6",
    QueryString = "QueryString8",
};

try
{
    object result = await aPIController.UpdateNamedQueryAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Update Notebook

Updates the contents of a Spark notebook.

```csharp
UpdateNotebookAsync(
    Models.XAmzTarget56Enum xAmzTarget,
    Models.UpdateNotebookInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget56Enum`](../../doc/models/x-amz-target-56-enum.md) | Header, Required | - |
| `body` | [`UpdateNotebookInput`](../../doc/models/update-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget56Enum xAmzTarget = XAmzTarget56Enum.EnumAmazonAthenaUpdateNotebook;
UpdateNotebookInput body = new UpdateNotebookInput
{
    NotebookId = "NotebookId6",
    Payload = "Payload2",
    Type = NotebookType2Enum.IPYNB,
};

try
{
    object result = await aPIController.UpdateNotebookAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Update Notebook Metadata

Updates the metadata for a notebook.

```csharp
UpdateNotebookMetadataAsync(
    Models.XAmzTarget57Enum xAmzTarget,
    Models.UpdateNotebookMetadataInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget57Enum`](../../doc/models/x-amz-target-57-enum.md) | Header, Required | - |
| `body` | [`UpdateNotebookMetadataInput`](../../doc/models/update-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget57Enum xAmzTarget = XAmzTarget57Enum.EnumAmazonAthenaUpdateNotebookMetadata;
UpdateNotebookMetadataInput body = new UpdateNotebookMetadataInput
{
    NotebookId = "NotebookId6",
    Name = "Name6",
};

try
{
    object result = await aPIController.UpdateNotebookMetadataAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Update Prepared Statement

Updates a prepared statement.

```csharp
UpdatePreparedStatementAsync(
    Models.XAmzTarget58Enum xAmzTarget,
    Models.UpdatePreparedStatementInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget58Enum`](../../doc/models/x-amz-target-58-enum.md) | Header, Required | - |
| `body` | [`UpdatePreparedStatementInput`](../../doc/models/update-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget58Enum xAmzTarget = XAmzTarget58Enum.EnumAmazonAthenaUpdatePreparedStatement;
UpdatePreparedStatementInput body = new UpdatePreparedStatementInput
{
    StatementName = "StatementName4",
    WorkGroup = "WorkGroup8",
    QueryStatement = "QueryStatement8",
};

try
{
    object result = await aPIController.UpdatePreparedStatementAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Update Work Group

Updates the workgroup with the specified name. The workgroup's name cannot be changed. Only <code>ConfigurationUpdates</code> can be specified.

```csharp
UpdateWorkGroupAsync(
    Models.XAmzTarget59Enum xAmzTarget,
    Models.UpdateWorkGroupInput body,
    string xAmzContentSha256 = null,
    string xAmzDate = null,
    string xAmzAlgorithm = null,
    string xAmzCredential = null,
    string xAmzSecurityToken = null,
    string xAmzSignature = null,
    string xAmzSignedHeaders = null)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget59Enum`](../../doc/models/x-amz-target-59-enum.md) | Header, Required | - |
| `body` | [`UpdateWorkGroupInput`](../../doc/models/update-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `string` | Header, Optional | - |
| `xAmzDate` | `string` | Header, Optional | - |
| `xAmzAlgorithm` | `string` | Header, Optional | - |
| `xAmzCredential` | `string` | Header, Optional | - |
| `xAmzSecurityToken` | `string` | Header, Optional | - |
| `xAmzSignature` | `string` | Header, Optional | - |
| `xAmzSignedHeaders` | `string` | Header, Optional | - |

## Response Type

**200**: Success

`Task<object>`

## Example Usage

```csharp
XAmzTarget59Enum xAmzTarget = XAmzTarget59Enum.EnumAmazonAthenaUpdateWorkGroup;
UpdateWorkGroupInput body = new UpdateWorkGroupInput
{
    WorkGroup = "WorkGroup8",
};

try
{
    object result = await aPIController.UpdateWorkGroupAsync(
        xAmzTarget,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |

