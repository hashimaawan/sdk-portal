
# Price Monthly 9

Monthly costs for a Primary IP type in this Location

## Structure

`PriceMonthly9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    priceMonthly9 := models.PriceMonthly9{
        Gross:                "1.1900000000000000",
        Net:                  "1.0000000000",
    }

}
```

