
# Load Balancer Target Server

Server where the traffic should be routed through

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Server |

## Example

```ts
import { LoadBalancerTargetServer } from 'hetzner-cloud-apilib';

const loadBalancerTargetServer: LoadBalancerTargetServer = {
  id: 80,
};
```

