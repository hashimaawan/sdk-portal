
# Type 6

Type of resource referenced

## Enumeration

`Type6`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```ts
import { Type6 } from 'hetzner-cloud-apilib';

const type6 = Type6.Server;
```

