
# Type 17 Enum

Floating IP type

## Enumeration

`Type17Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```java
import cloud.hetzner.api.models.Type17Enum;

Type17Enum type17 = Type17Enum.IPV4;
```

