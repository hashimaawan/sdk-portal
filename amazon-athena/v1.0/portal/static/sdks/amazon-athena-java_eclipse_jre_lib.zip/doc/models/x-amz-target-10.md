
# X Amz Target 10

## Enumeration

`XAmzTarget10`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget10;

XAmzTarget10 xAmzTarget10 = XAmzTarget10.ENUM_AMAZONATHENADELETENAMEDQUERY;
```

