
# V21 Clicks Kubernetes Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V21ClicksKubernetesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | A message about the result of the request. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_1_clicks_kubernetes_response = V21ClicksKubernetesResponse.new(
  message: 'Successfully kicked off addon job.',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

