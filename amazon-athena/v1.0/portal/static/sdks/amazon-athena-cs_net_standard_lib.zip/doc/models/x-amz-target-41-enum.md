
# X Amz Target 41 Enum

## Enumeration

`XAmzTarget41Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListQueryExecutions` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget41Enum xAmzTarget41 = XAmzTarget41Enum.EnumAmazonAthenaListQueryExecutions;
```

