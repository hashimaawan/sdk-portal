
# V2 Volumes Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2VolumesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `volumes` | [`Volume[]`](../../doc/models/volume.md) | Required | Array of volumes. | getVolumes(): array | setVolumes(array volumes): void |
| `links` | [`?Links`](../../doc/models/links.md) | Optional | - | getLinks(): ?Links | setLinks(?Links links): void |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - | getMeta(): Meta | setMeta(Meta meta): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2VolumesResponseBuilder;
use DigitalOceanApiLib\Models\Builders\VolumeBuilder;
use DigitalOceanApiLib\Models\Builders\RegionBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\MetaBuilder;
use DigitalOceanApiLib\Models\Builders\LinksBuilder;
use DigitalOceanApiLib\Models\Builders\PagesBuilder;

$v2VolumesResponse = V2VolumesResponseBuilder::init(
    [
        VolumeBuilder::init()
            ->createdAt('2020-03-02T17:00:49Z')
            ->description('Block store for examples')
            ->dropletIds(
                []
            )
            ->id('506f78a4-e098-11e5-ad9f-000f53306ae1')
            ->name('example')
            ->sizeGigabytes(10)
            ->tags(
                [
                    'base-image',
                    'prod'
                ]
            )
            ->filesystemLabel('example')
            ->filesystemType('ext4')
            ->region(
                RegionBuilder::init(
                    true,
                    [
                        'private_networking',
                        'backups',
                        'ipv6',
                        'metadata'
                    ],
                    'New York 1',
                    [
                        's-1vcpu-1gb',
                        's-1vcpu-2gb',
                        's-1vcpu-3gb',
                        's-2vcpu-2gb',
                        's-3vcpu-1gb',
                        's-2vcpu-4gb',
                        's-4vcpu-8gb',
                        's-6vcpu-16gb',
                        's-8vcpu-32gb',
                        's-12vcpu-48gb',
                        's-16vcpu-64gb',
                        's-20vcpu-96gb',
                        's-24vcpu-128gb',
                        's-32vcpu-192gb'
                    ],
                    'nyc1'
                )->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ],
    MetaBuilder::init(
        1
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->links(
        LinksBuilder::init()
            ->pages(
                PagesBuilder::init()
                    ->last('last6')
                    ->next('next2')
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

