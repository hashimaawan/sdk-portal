
# M Shared Shared Vcpu Cores Dedicated Dedicated Vcpu Cores

## Enumeration

`MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores`

## Fields

| Name |
|  --- |
| `Unspecified` |
| `Shared` |
| `Dedicated` |

## Example

```ts
import {
  MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores,
} from 'digitalocean-apilib';

const mSharedSharedVcpuCoresDedicatedDedicatedVcpuCores = MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores.Dedicated;
```

