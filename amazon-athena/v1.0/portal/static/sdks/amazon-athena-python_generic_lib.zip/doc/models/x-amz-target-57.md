
# X Amz Target 57

## Enumeration

`XAmzTarget57`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_57 import XAmzTarget57

x_amz_target_57 = XAmzTarget57.ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA
```

