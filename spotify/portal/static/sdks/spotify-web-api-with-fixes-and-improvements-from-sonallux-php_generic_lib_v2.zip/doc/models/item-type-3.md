
# Item Type 3

The ID type: either `artist` or `user`.

## Enumeration

`ItemType3`

## Fields

| Name |
|  --- |
| `ARTIST` |
| `USER` |

## Example

```php
use SpotifyWebApiWithFixesAndImprovementsFromSonalluxLib\Models\ItemType3;

$itemType3 = ItemType3::ARTIST;
```

