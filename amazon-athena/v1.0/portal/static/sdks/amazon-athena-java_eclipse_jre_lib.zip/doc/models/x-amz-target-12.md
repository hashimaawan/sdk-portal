
# X Amz Target 12

## Enumeration

`XAmzTarget12`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget12;

XAmzTarget12 xAmzTarget12 = XAmzTarget12.ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT;
```

