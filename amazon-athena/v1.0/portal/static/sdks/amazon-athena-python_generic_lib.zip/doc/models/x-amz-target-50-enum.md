
# X Amz Target 50 Enum

## Enumeration

`XAmzTarget50Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPQUERYEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_50_enum import XAmzTarget50Enum

x_amz_target_50 = XAmzTarget50Enum.ENUM_AMAZONATHENASTOPQUERYEXECUTION
```

