
# Type 12

The type of action to initiate for the Droplet.

## Enumeration

`Type12`

## Fields

| Name |
|  --- |
| `EnableBackups` |
| `DisableBackups` |
| `Reboot` |
| `PowerCycle` |
| `Shutdown` |
| `PowerOff` |
| `PowerOn` |
| `Restore` |
| `PasswordReset` |
| `Resize` |
| `Rebuild` |
| `Rename` |
| `ChangeKernel` |
| `EnableIpv6` |
| `Snapshot` |

## Example

```ts
import { Type12 } from 'digitalocean-apilib';

const type12 = Type12.Reboot;
```

