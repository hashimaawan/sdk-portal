
# Type 26 Enum

Type of the ISO

## Enumeration

`Type26Enum`

## Fields

| Name |
|  --- |
| `ENUM_PUBLIC` |
| `ENUM_PRIVATE` |

## Example

```java
import cloud.hetzner.api.models.Type26Enum;

Type26Enum type26 = Type26Enum.ENUM_PUBLIC;
```

