
# Query Execution 1

## Structure

`QueryExecution1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `Query` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `StatementType` | [`StatementType1Enum?`](../../doc/models/statement-type-1-enum.md) | Optional | - |
| `ResultConfiguration` | [`ResultConfiguration1`](../../doc/models/result-configuration-1.md) | Optional | - |
| `ResultReuseConfiguration` | [`ResultReuseConfiguration1`](../../doc/models/result-reuse-configuration-1.md) | Optional | - |
| `QueryExecutionContext` | [`QueryExecutionContext1`](../../doc/models/query-execution-context-1.md) | Optional | - |
| `Status` | [`Status`](../../doc/models/status.md) | Optional | - |
| `Statistics` | [`Statistics`](../../doc/models/statistics.md) | Optional | - |
| `WorkGroup` | `string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `EngineVersion` | [`EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - |
| `ExecutionParameters` | `List<string>` | Optional | **Constraints**: *Minimum Items*: `1`, *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `SubstatementType` | `string` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryExecution1 queryExecution1 = new QueryExecution1
{
    QueryExecutionId = "QueryExecutionId6",
    Query = "Query0",
    StatementType = StatementType1Enum.UTILITY,
    ResultConfiguration = new ResultConfiguration1
    {
        OutputLocation = "OutputLocation0",
        EncryptionConfiguration = new EncryptionConfiguration2
        {
            EncryptionOption = EncryptionOption1Enum.SSES3,
            KmsKey = "KmsKey6",
        },
        ExpectedBucketOwner = "ExpectedBucketOwner0",
        AclConfiguration = new AclConfiguration1
        {
            S3AclOption = S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
        },
    },
    ResultReuseConfiguration = new ResultReuseConfiguration1
    {
        ResultReuseByAgeConfiguration = new ResultReuseByAgeConfiguration2
        {
            Enabled = false,
            MaxAgeInMinutes = 26,
        },
    },
};
```

