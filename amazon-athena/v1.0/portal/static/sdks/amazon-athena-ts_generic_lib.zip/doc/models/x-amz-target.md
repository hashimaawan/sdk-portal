
# X Amz Target

## Enumeration

`XAmzTarget`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetNamedQuery` |

## Example

```ts
import { XAmzTarget } from 'amazon-athenalib';

const xAmzTarget = XAmzTarget.EnumAmazonAthenaBatchGetNamedQuery;
```

