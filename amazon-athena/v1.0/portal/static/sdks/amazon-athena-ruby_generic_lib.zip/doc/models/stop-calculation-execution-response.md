
# Stop Calculation Execution Response

*This model accepts additional fields of type Object.*

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`CalculationExecutionState4`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
stop_calculation_execution_response = StopCalculationExecutionResponse.new(
  state: CalculationExecutionState4::QUEUED,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

