
# Apply to Resources Request

*This model accepts additional fields of type unknown.*

## Structure

`ApplyToResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applyTo` | [`FirewallApplyToResources[]`](../../doc/models/firewall-apply-to-resources.md) | Required | Resources the Firewall should be applied to |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ApplyToResourcesRequest, Type7 } from 'hetzner-cloud-apilib';

const applyToResourcesRequest: ApplyToResourcesRequest = {
  applyTo: [
    {
      labelSelector: {
        selector: 'selector8',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      server: {
        id: 14,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      type: Type7.Server,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

