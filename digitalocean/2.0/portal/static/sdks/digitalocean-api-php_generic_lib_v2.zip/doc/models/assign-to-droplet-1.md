
# Assign to Droplet 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`AssignToDroplet1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dropletId` | `int` | Required | The ID of the Droplet that the reserved IP will be assigned to. | getDropletId(): int | setDropletId(int dropletId): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\AssignToDroplet1Builder;
use DigitalOceanApiLib\ApiHelper;

$assignToDroplet1 = AssignToDroplet1Builder::init(
    2457247
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

