
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `0` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`hetznercloudapiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `hetznercloudapi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "hetznercloudapi"
    "net/http"
)

func main() {
    httpConfiguration := hetznercloudapi.CreateHttpConfiguration(
        hetznercloudapi.WithTimeout(0),
        hetznercloudapi.WithTransport(http.DefaultTransport),
        hetznercloudapi.WithRetryConfiguration(hetznercloudapi.DefaultRetryConfiguration()),
    )
}
```

