
# Type 20

The type of alert.

## Enumeration

`Type20`

## Fields

| Name |
|  --- |
| `LATENCY` |
| `DOWN` |
| `DOWN_GLOBAL` |
| `SSL_EXPIRY` |

## Example

```ruby
type20 = Type20::DOWN_GLOBAL
```

