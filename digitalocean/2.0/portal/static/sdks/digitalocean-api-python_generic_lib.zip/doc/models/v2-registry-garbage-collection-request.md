
# V2 Registry Garbage Collection Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cancel` | `bool` | Optional | A boolean value indicating that the garbage collection should be cancelled. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_registry_garbage_collection_request import V2RegistryGarbageCollectionRequest

v_2_registry_garbage_collection_request = V2RegistryGarbageCollectionRequest(
    cancel=True,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

