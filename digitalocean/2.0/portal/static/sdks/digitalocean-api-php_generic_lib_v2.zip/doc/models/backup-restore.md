
# Backup Restore

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`BackupRestore`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `backupCreatedAt` | `?DateTime` | Optional | The timestamp of an existing database cluster backup in ISO8601 combined date and time format. The most recent backup will be used if excluded. | getBackupCreatedAt(): ?\DateTime | setBackupCreatedAt(?\DateTime backupCreatedAt): void |
| `databaseName` | `string` | Required | The name of an existing database cluster from which the backup will be restored. | getDatabaseName(): string | setDatabaseName(string databaseName): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\BackupRestoreBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\ApiHelper;

$backupRestore = BackupRestoreBuilder::init(
    'backend'
)
    ->backupCreatedAt(DateTimeHelper::fromRfc3339DateTime('2019-01-31T19:25:22Z'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

