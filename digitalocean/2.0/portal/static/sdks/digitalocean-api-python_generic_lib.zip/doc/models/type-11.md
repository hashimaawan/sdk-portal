
# Type 11

The type of the IPv6 network interface.

**Note**: IPv6 private  networking is not currently supported.

## Enumeration

`Type11`

## Fields

| Name |
|  --- |
| `PUBLIC` |

## Example

```python
from digitaloceanapi.models.type_11 import Type11

type_11 = Type11.PUBLIC
```

