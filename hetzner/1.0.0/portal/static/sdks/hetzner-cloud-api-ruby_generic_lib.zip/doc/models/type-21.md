
# Type 21

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```ruby
type21 = Type21::BACKUP
```

