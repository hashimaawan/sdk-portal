
# Status 9

A status string indicating the current state of the firewall. This can be "waiting", "succeeded", or "failed".

## Enumeration

`Status9`

## Fields

| Name |
|  --- |
| `Waiting` |
| `Succeeded` |
| `Failed` |

## Example

```ts
import { Status9 } from 'digitalocean-apilib';

const status9 = Status9.Waiting;
```

