
# Backup

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Backup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `created_at` | `DateTime` | Required | A time value given in ISO8601 combined date and time format at which the backup was created. |
| `size_gigabytes` | `Float` | Required | The size of the database backup in GBs. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
backup = Backup.new(
  created_at: DateTimeHelper.from_rfc3339('2019-01-31T19:25:22Z'),
  size_gigabytes: 0.03364864,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

