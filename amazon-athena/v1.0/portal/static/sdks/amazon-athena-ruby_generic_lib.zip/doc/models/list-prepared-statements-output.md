
# List Prepared Statements Output

## Structure

`ListPreparedStatementsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prepared_statements` | [`Array[PreparedStatementSummary]`](../../doc/models/prepared-statement-summary.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `50` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_prepared_statements_output = ListPreparedStatementsOutput.new(
  [
    PreparedStatementSummary.new(
      'StatementName2',
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z')
    )
  ],
  'NextToken2'
)
```

