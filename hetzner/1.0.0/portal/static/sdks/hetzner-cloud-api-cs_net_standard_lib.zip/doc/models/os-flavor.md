
# Os Flavor

Flavor of operating system contained in the Image

## Enumeration

`OsFlavor`

## Fields

| Name |
|  --- |
| `Ubuntu` |
| `Centos` |
| `Debian` |
| `Fedora` |
| `Unknown` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

OsFlavor osFlavor = OsFlavor.Debian;
```

