
# V2 Kubernetes Clusters Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kubernetesClusters` | [`KubernetesCluster[] \| undefined`](../../doc/models/kubernetes-cluster.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2KubernetesClustersResponse } from 'digitalocean-apilib';

const v2KubernetesClustersResponse: V2KubernetesClustersResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  kubernetesClusters: [
    {
      name: 'name2',
      nodePools: [
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      region: 'region8',
      version: 'version8',
      autoUpgrade: false,
      clusterSubnet: 'cluster_subnet4',
      createdAt: '2016-03-13T12:52:32.123Z',
      endpoint: 'endpoint0',
      ha: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      name: 'name2',
      nodePools: [
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      region: 'region8',
      version: 'version8',
      autoUpgrade: false,
      clusterSubnet: 'cluster_subnet4',
      createdAt: '2016-03-13T12:52:32.123Z',
      endpoint: 'endpoint0',
      ha: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      name: 'name2',
      nodePools: [
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          size: 'size6',
          count: 206,
          name: 'name4',
          autoScale: false,
          id: '000013be-0000-0000-0000-000000000000',
          labels: { 'key1': 'val1', 'key2': 'val2' },
          maxNodes: 118,
          minNodes: 54,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      region: 'region8',
      version: 'version8',
      autoUpgrade: false,
      clusterSubnet: 'cluster_subnet4',
      createdAt: '2016-03-13T12:52:32.123Z',
      endpoint: 'endpoint0',
      ha: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

