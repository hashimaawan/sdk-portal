
# X Amz Target 47

## Enumeration

`XAmzTarget47`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTQUERYEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_47 import XAmzTarget47

x_amz_target_47 = XAmzTarget47.ENUM_AMAZONATHENASTARTQUERYEXECUTION
```

