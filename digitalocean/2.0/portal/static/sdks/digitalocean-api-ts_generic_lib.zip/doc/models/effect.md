
# Effect

How the node reacts to pods that it won't tolerate. Available effect values are `NoSchedule`, `PreferNoSchedule`, and `NoExecute`.

## Enumeration

`Effect`

## Fields

| Name |
|  --- |
| `NoSchedule` |
| `PreferNoSchedule` |
| `NoExecute` |

## Example

```ts
import { Effect } from 'digitalocean-apilib';

const effect = Effect.NoSchedule;
```

