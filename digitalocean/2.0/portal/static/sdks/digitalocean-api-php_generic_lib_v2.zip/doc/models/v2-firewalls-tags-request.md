
# V2 Firewalls Tags Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FirewallsTagsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `tags` | `?(string[])` | Required | - | getTags(): ?array | setTags(?array tags): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FirewallsTagsRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2FirewallsTagsRequest = V2FirewallsTagsRequestBuilder::init()
    ->tags(
        [
            'tags1'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

