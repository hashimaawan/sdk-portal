
# Load Balancers Actions Change Algorithm Request

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Type39Enum`](../../doc/models/type-39-enum.md) | Required | Algorithm of the Load Balancer |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LoadBalancersActionsChangeAlgorithmRequest loadBalancersActionsChangeAlgorithmRequest = new LoadBalancersActionsChangeAlgorithmRequest
{
    Type = Type39Enum.RoundRobin,
};
```

