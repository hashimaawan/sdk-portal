
# Region Enum

## Enumeration

`RegionEnum`

## Fields

| Name |
|  --- |
| `USEAST1` |
| `USEAST2` |
| `USWEST1` |
| `USWEST2` |
| `USGOVWEST1` |
| `USGOVEAST1` |
| `CACENTRAL1` |
| `EUNORTH1` |
| `EUWEST1` |
| `EUWEST2` |
| `EUWEST3` |
| `EUCENTRAL1` |
| `EUSOUTH1` |
| `AFSOUTH1` |
| `APNORTHEAST1` |
| `APNORTHEAST2` |
| `APNORTHEAST3` |
| `APSOUTHEAST1` |
| `APSOUTHEAST2` |
| `APEAST1` |
| `APSOUTH1` |
| `SAEAST1` |
| `MESOUTH1` |

## Example

```python
from amazonathena.models.region_enum import RegionEnum

region = RegionEnum.EUWEST3
```

