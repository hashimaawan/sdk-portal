
# V2 Kubernetes Clusters Clusterlint Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersClusterlintRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `exclude_checks` | `List[str]` | Optional | An array of checks that will be run when clusterlint executes checks. |
| `exclude_groups` | `List[str]` | Optional | An array of check groups that will be omitted when clusterlint executes checks. |
| `include_checks` | `List[str]` | Optional | An array of checks that will be run when clusterlint executes checks. |
| `include_groups` | `List[str]` | Optional | An array of check groups that will be run when clusterlint executes checks. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_kubernetes_clusters_clusterlint_request import V2KubernetesClustersClusterlintRequest

v_2_kubernetes_clusters_clusterlint_request = V2KubernetesClustersClusterlintRequest(
    exclude_checks=[
        'default-namespace'
    ],
    exclude_groups=[
        'workload-health'
    ],
    include_checks=[
        'bare-pods',
        'resource-requirements'
    ],
    include_groups=[
        'basic',
        'doks',
        'security'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

