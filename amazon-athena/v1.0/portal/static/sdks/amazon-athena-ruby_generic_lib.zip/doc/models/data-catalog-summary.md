
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalog_name` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `type` | [`DataCatalogType2Enum`](../../doc/models/data-catalog-type-2-enum.md) | Optional | - |

## Example

```ruby
data_catalog_summary = DataCatalogSummary.new(
  'CatalogName4',
  DataCatalogType2Enum::HIVE
)
```

