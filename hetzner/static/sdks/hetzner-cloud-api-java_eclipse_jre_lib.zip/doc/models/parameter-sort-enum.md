
# Parameter Sort Enum

## Enumeration

`ParameterSortEnum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `COMMAND` |
| `ENUM_COMMANDASC` |
| `ENUM_COMMANDDESC` |
| `STATUS` |
| `ENUM_STATUSASC` |
| `ENUM_STATUSDESC` |
| `PROGRESS` |
| `ENUM_PROGRESSASC` |
| `ENUM_PROGRESSDESC` |
| `STARTED` |
| `ENUM_STARTEDASC` |
| `ENUM_STARTEDDESC` |
| `FINISHED` |
| `ENUM_FINISHEDASC` |
| `ENUM_FINISHEDDESC` |

## Example

```java
import cloud.hetzner.api.models.ParameterSortEnum;

ParameterSortEnum parameterSort = ParameterSortEnum.ENUM_STATUSDESC;
```

