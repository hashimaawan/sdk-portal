# Server Types

```go
serverTypesController := client.ServerTypesController()
```

## Class Name

`ServerTypesController`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```go
GetAllServerTypes(
    ctx context.Context,
    name *string) (
    models.ApiResponse[models.ServerTypesResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `*string` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ServerTypesResponse](../../doc/models/server-types-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := serverTypesController.GetAllServerTypes(ctx, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get a Server Type

Gets a specific Server type object.

```go
GetAServerType(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ServerTypesResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Server Type |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ServerTypesResponse1](../../doc/models/server-types-response-1.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := serverTypesController.GetAServerType(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

