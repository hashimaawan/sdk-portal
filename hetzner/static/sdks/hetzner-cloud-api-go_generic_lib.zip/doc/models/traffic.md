
# Traffic

The cost of additional traffic per TB

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PricePerTb` | [`models.PricePerTb`](../../doc/models/price-per-tb.md) | Required | - |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    traffic := models.Traffic{
        PricePerTb:           models.PricePerTb{
            Gross:                "1.1900000000000000",
            Net:                  "1.0000000000",
        },
    }

}
```

