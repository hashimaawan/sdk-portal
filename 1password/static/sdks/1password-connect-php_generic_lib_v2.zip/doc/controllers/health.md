# Health

```php
$healthApi = $client->getHealthApi();
```

## Class Name

`HealthApi`

## Methods

* [Get Server Health](../../doc/controllers/health.md#get-server-health)
* [Get Heartbeat](../../doc/controllers/health.md#get-heartbeat)


# Get Server Health

:information_source: **Note** This endpoint does not require authentication.

```php
function getServerHealth(): ApiResponse
```

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`HealthResponse`](../../doc/models/health-response.md).

## Example Usage

```php
$healthApi = $client->getHealthApi();
$apiResponse = $healthApi->getServerHealth();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'HealthResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "dependencies": [
    {
      "service": "sync",
      "status": "TOKEN_NEEDED"
    },
    {
      "message": "Connected to./1password.sqlite",
      "service": "sqlite",
      "status": "ACTIVE"
    }
  ],
  "name": "1Password Connect API",
  "version": "1.2.1"
}
```


# Get Heartbeat

:information_source: **Note** This endpoint does not require authentication.

```php
function getHeartbeat(): ApiResponse
```

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `string`.

## Example Usage

```php
$healthApi = $client->getHealthApi();
$apiResponse = $healthApi->getHeartbeat();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'string:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

