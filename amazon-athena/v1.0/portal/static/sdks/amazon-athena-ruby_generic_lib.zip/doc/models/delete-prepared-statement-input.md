
# Delete Prepared Statement Input

*This model accepts additional fields of type Object.*

## Structure

`DeletePreparedStatementInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statement_name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `work_group` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
delete_prepared_statement_input = DeletePreparedStatementInput.new(
  statement_name: 'StatementName6',
  work_group: 'WorkGroup0',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

