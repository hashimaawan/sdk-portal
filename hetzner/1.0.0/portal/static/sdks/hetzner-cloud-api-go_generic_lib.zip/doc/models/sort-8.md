
# Sort 8

## Enumeration

`Sort8`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    sort8 := models.Sort8_EnumNameasc

}
```

