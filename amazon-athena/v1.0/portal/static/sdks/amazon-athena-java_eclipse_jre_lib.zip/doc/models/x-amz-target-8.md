
# X Amz Target 8

## Enumeration

`XAmzTarget8`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEWORKGROUP` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget8;

XAmzTarget8 xAmzTarget8 = XAmzTarget8.ENUM_AMAZONATHENACREATEWORKGROUP;
```

