
# X Amz Target 10

## Enumeration

`XAmzTarget10`

## Fields

| Name |
|  --- |
| `EnumAmazonathenadeletenamedquery` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget10 := models.XAmzTarget10_EnumAmazonathenadeletenamedquery

}
```

