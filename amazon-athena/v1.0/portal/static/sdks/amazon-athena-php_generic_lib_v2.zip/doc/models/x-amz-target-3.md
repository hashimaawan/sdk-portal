
# X Amz Target 3

## Enumeration

`XAmzTarget3`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEDATACATALOG` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget3;

$xAmzTarget3 = XAmzTarget3::ENUM_AMAZONATHENACREATEDATACATALOG;
```

