
# X Amz Target 52 Enum

## Enumeration

`XAmzTarget52Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATERMINATESESSION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget52Enum;

XAmzTarget52Enum xAmzTarget52 = XAmzTarget52Enum.ENUM_AMAZONATHENATERMINATESESSION;
```

