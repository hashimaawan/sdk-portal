
# Mode

travel mode

## Enumeration

`Mode`

## Fields

| Name |
|  --- |
| `Car` |
| `Motorcycle` |
| `Bicycle` |
| `Walk` |
| `Other` |

## Example

```go
package main

import (
    "furkotTrips/models"
)

func main() {
    mode := models.Mode_Bicycle

}
```

