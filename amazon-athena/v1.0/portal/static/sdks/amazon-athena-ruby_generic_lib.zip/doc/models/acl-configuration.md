
# Acl Configuration

Indicates that an Amazon S3 canned ACL should be set to control ownership of stored query results. When Athena stores query results in Amazon S3, the canned ACL is set with the <code>x-amz-acl</code> request header. For more information about S3 Object Ownership, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/userguide/about-object-ownership.html#object-ownership-overview">Object Ownership settings</a> in the <i>Amazon S3 User Guide</i>.

## Structure

`AclConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s_3_acl_option` | [`S3AclOption1Enum`](../../doc/models/s3-acl-option-1-enum.md) | Required | - |

## Example

```ruby
acl_configuration = AclConfiguration.new(
  S3AclOption1Enum::BUCKET_OWNER_FULL_CONTROL
)
```

