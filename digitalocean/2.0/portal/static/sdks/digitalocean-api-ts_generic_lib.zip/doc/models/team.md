
# Team

When authorized in a team context, includes information about the current team.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Team`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | The name for the current team. |
| `uuid` | `string \| undefined` | Optional | The unique universal identifier for the current team. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Team } from 'digitalocean-apilib';

const team: Team = {
  name: 'My Team',
  uuid: '5df3e3004a17e242b7c20ca6c9fc25b701a47ece',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

