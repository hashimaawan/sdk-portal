
# Issuance Enum

Status of the issuance process of the Certificate

## Enumeration

`IssuanceEnum`

## Fields

| Name |
|  --- |
| `Pending` |
| `Completed` |
| `Failed` |

## Example

```ts
import { IssuanceEnum } from 'hetzner-cloud-apilib';

const issuance = IssuanceEnum.Failed;
```

