
# Issuance

Status of the issuance process of the Certificate

## Enumeration

`Issuance`

## Fields

| Name |
|  --- |
| `Pending` |
| `Completed` |
| `Failed` |

## Example

```ts
import { Issuance } from 'hetzner-cloud-apilib';

const issuance = Issuance.Failed;
```

