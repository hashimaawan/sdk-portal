
# V2 Uptime Checks Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2UptimeChecksResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `check` | [`?Check`](../../doc/models/check.md) | Optional | - | getCheck(): ?Check | setCheck(?Check check): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2UptimeChecksResponse1Builder;
use DigitalOceanApiLib\Models\Builders\CheckBuilder;
use DigitalOceanApiLib\Models\Region8;
use DigitalOceanApiLib\ApiHelper;

$v2UptimeChecksResponse1 = V2UptimeChecksResponse1Builder::init()
    ->check(
        CheckBuilder::init()
            ->id('00000c0a-0000-0000-0000-000000000000')
            ->enabled(false)
            ->name('name2')
            ->regions(
                [
                    Region8::SE_ASIA
                ]
            )
            ->target('target0')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

