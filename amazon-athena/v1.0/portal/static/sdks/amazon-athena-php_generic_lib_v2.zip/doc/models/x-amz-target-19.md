
# X Amz Target 19

## Enumeration

`XAmzTarget19`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATABASE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget19;

$xAmzTarget19 = XAmzTarget19::ENUM_AMAZONATHENAGETDATABASE;
```

