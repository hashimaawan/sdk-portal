
# X Amz Target 5 Enum

## Enumeration

`XAmzTarget5Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget5Enum;

XAmzTarget5Enum xAmzTarget5 = XAmzTarget5Enum.ENUM_AMAZONATHENACREATENOTEBOOK;
```

