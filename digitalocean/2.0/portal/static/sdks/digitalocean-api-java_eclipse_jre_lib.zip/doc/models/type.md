
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `KUBERNETES` |

## Example

```java
import com.digitalocean.api.models.Type;

Type type = Type.DROPLET;
```

