
# X Amz Target 14

## Enumeration

`XAmzTarget14`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaexportnotebook` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget14 := models.XAmzTarget14_EnumAmazonathenaexportnotebook

}
```

