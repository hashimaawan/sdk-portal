
# List Executors Response

## Structure

`ListExecutorsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `next_token` | `String` | Optional | **Constraints**: *Maximum Length*: `2048` |
| `executors_summary` | [`Array[ExecutorsSummary]`](../../doc/models/executors-summary.md) | Optional | - |

## Example

```ruby
list_executors_response = ListExecutorsResponse.new(
  'SessionId2',
  'NextToken6',
  [
    ExecutorsSummary.new(
      'ExecutorId8',
      ExecutorType2Enum::GATEWAY,
      128,
      236,
      ExecutorState3Enum::TERMINATED,
      42
    )
  ]
)
```

