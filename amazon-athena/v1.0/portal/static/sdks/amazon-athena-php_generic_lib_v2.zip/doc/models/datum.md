
# Datum

A piece of data (a field in the table).

## Structure

`Datum`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `varCharValue` | `?string` | Optional | - | getVarCharValue(): ?string | setVarCharValue(?string varCharValue): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DatumBuilder;

$datum = DatumBuilder::init()
    ->varCharValue('VarCharValue8')
    ->build();
```

