
# V21 Clicks Kubernetes Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V21ClicksKubernetesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `addon_slugs` | `Array[String]` | Required | An array of 1-Click Application slugs to be installed to the Kubernetes cluster. |
| `cluster_uuid` | `String` | Required | A unique ID for the Kubernetes cluster to which the 1-Click Applications will be installed. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_1_clicks_kubernetes_request = V21ClicksKubernetesRequest.new(
  addon_slugs: [
    'kube-state-metrics',
    'loki'
  ],
  cluster_uuid: '50a994b6-c303-438f-9495-7e896cfe6b08',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

