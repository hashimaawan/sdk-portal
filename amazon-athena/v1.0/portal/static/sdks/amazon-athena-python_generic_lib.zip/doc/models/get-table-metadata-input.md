
# Get Table Metadata Input

## Structure

`GetTableMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalog_name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `database_name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `table_name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```python
from amazonathena.models.get_table_metadata_input import GetTableMetadataInput

get_table_metadata_input = GetTableMetadataInput(
    catalog_name='CatalogName4',
    database_name='DatabaseName4',
    table_name='TableName6'
)
```

