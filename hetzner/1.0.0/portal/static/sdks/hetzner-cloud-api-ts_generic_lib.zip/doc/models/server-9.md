
# Server 9

Configuration for type server, required if type is `server`

*This model accepts additional fields of type unknown.*

## Structure

`Server9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Server |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Server9 } from 'hetzner-cloud-apilib';

const server9: Server9 = {
  id: 216,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

