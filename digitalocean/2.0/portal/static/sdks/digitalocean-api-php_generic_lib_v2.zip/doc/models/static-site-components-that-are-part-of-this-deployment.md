
# Static Site Components that Are Part of This Deployment

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`StaticSiteComponentsThatArePartOfThisDeployment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `sourceCommitHash` | `?string` | Optional | - | getSourceCommitHash(): ?string | setSourceCommitHash(?string sourceCommitHash): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\StaticSiteComponentsThatArePartOfThisDeploymentBuilder;
use DigitalOceanApiLib\ApiHelper;

$staticSiteComponentsThatArePartOfThisDeployment = StaticSiteComponentsThatArePartOfThisDeploymentBuilder::init()
    ->name('web')
    ->sourceCommitHash('54d4a727f457231062439895000d45437c7bb405')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

