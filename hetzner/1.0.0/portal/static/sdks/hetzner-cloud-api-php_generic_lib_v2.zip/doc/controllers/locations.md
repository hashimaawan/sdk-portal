# Locations

Datacenters are organized by Locations. Datacenters in the same Location are connected with very low latency links.

```php
$locationsController = $client->getLocationsController();
```

## Class Name

`LocationsController`

## Methods

* [Get All Locations](../../doc/controllers/locations.md#get-all-locations)
* [Get a Location](../../doc/controllers/locations.md#get-a-location)


# Get All Locations

Returns all Location objects.

```php
function getAllLocations(?string $name = null): LocationsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `?string` | Query, Optional | Can be used to filter Locations by their name. The response will only contain the Location matching the specified name. |

## Response Type

**200**: The `locations` key in the reply contains an array of Location objects with this structure

[`LocationsResponse`](../../doc/models/locations-response.md)

## Example Usage

```php
$locationsController = $client->getLocationsController();

try {
    $result = $locationsController->getAllLocations();
    echo 'LocationsResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get a Location

Returns a specific Location object.

```php
function getALocation(int $id): LocationsResponse1
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Location |

## Response Type

**200**: The `location` key in the reply contains a Location object with this structure

[`LocationsResponse1`](../../doc/models/locations-response-1.md)

## Example Usage

```php
$id = 112;

$locationsController = $client->getLocationsController();

try {
    $result = $locationsController->getALocation($id);
    echo 'LocationsResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

