
# Load Balancers Actions Attach to Network Request

*This model accepts additional fields of type interface{}.*

## Structure

`LoadBalancersActionsAttachToNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Ip` | `*string` | Optional | IP to request to be assigned to this Load Balancer; if you do not provide this then you will be auto assigned an IP address |
| `Network` | `float64` | Required | ID of an existing network to attach the Load Balancer to |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    loadBalancersActionsAttachToNetworkRequest := models.LoadBalancersActionsAttachToNetworkRequest{
        Ip:                    models.ToPointer("10.0.1.1"),
        Network:               float64(4711),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

