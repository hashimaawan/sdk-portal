
# Item Type

## Enumeration

`ItemType`

## Fields

| Name |
|  --- |
| `ALBUM` |
| `ARTIST` |
| `PLAYLIST` |
| `TRACK` |
| `SHOW` |
| `EPISODE` |
| `AUDIOBOOK` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.item_type import ItemType

item_type = ItemType.SHOW
```

