
# X Amz Target 32 Enum

## Enumeration

`XAmzTarget32Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget32 := models.XAmzTarget32Enum_ENUMAMAZONATHENALISTCALCULATIONEXECUTIONS

}
```

