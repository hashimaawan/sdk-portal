
# Renewal

Status of the renewal process of the Certificate.

## Enumeration

`Renewal`

## Fields

| Name |
|  --- |
| `SCHEDULED` |
| `PENDING` |
| `FAILED` |
| `UNAVAILABLE` |

## Example

```java
import cloud.hetzner.api.models.Renewal;

Renewal renewal = Renewal.FAILED;
```

