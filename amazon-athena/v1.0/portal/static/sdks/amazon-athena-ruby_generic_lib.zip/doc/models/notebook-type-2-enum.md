
# Notebook Type 2 Enum

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```ruby
notebook_type2 = NotebookType2Enum::IPYNB
```

