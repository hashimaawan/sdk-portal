
# V2 Volumes Actions Request 2

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2VolumesActionsRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `region` | [`Region2 \| undefined`](../../doc/models/region-2.md) | Optional | The slug identifier for the region where the resource will initially be  available. |
| `type` | [`Type21`](../../doc/models/type-21.md) | Required | The volume action to initiate. |
| `sizeGigabytes` | `number` | Required | The new size of the block storage volume in GiB (1024^3).<br><br>**Constraints**: `<= 16384` |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Region2,
  Type21,
  V2VolumesActionsRequest2,
} from 'digitalocean-apilib';

const v2VolumesActionsRequest2: V2VolumesActionsRequest2 = {
  type: Type21.Attach,
  sizeGigabytes: 15384,
  region: Region2.Nyc3,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

