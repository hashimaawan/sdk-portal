
# Output Stage

## Structure

`OutputStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stageId` | `number \| undefined` | Optional | - |
| `state` | `string \| undefined` | Optional | - |
| `outputBytes` | `number \| undefined` | Optional | - |
| `outputRows` | `number \| undefined` | Optional | - |
| `inputBytes` | `number \| undefined` | Optional | - |
| `inputRows` | `number \| undefined` | Optional | - |
| `executionTime` | `number \| undefined` | Optional | - |
| `queryStagePlan` | [`QueryStagePlan \| undefined`](../../doc/models/query-stage-plan.md) | Optional | - |
| `subStages` | [`QueryStage[] \| undefined`](../../doc/models/query-stage.md) | Optional | - |

## Example

```ts
import { OutputStage } from 'amazon-athenalib';

const outputStage: OutputStage = {
  stageId: 26,
  state: 'State4',
  outputBytes: 212,
  outputRows: 54,
  inputBytes: 170,
};
```

