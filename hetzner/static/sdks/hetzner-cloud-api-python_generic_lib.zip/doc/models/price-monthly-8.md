
# Price Monthly 8

Monthly costs for a Load Balancer type in this network zone

## Structure

`PriceMonthly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `str` | Required | Price with VAT added |
| `net` | `str` | Required | Price without VAT |

## Example

```python
from hetznercloudapi.models.price_monthly_8 import PriceMonthly8

price_monthly_8 = PriceMonthly8(
    gross='1.1900000000000000',
    net='1.0000000000'
)
```

