
# Data Catalog 2

*This model accepts additional fields of type object.*

## Structure

`DataCatalog2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Type` | [`DataCatalogType1`](../../doc/models/data-catalog-type-1.md) | Required | - |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

DataCatalog2 dataCatalog2 = new DataCatalog2
{
    Name = "Name6",
    Type = DataCatalogType1.Lambda,
    Description = "Description0",
    Parameters = new Parameters
    {
        ["exampleAdditionalProperty"] = "Parameters_additionalProperties2",
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

