
# Statement Type Enum

## Enumeration

`StatementTypeEnum`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```php
use AmazonAthenaLib\Models\StatementTypeEnum;

$statementType = StatementTypeEnum::DDL;
```

