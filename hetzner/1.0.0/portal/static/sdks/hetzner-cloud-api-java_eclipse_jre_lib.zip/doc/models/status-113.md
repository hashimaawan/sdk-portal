
# Status 113

Current status of the Volume

## Enumeration

`Status113`

## Fields

| Name |
|  --- |
| `CREATING` |
| `AVAILABLE` |

## Example

```java
import cloud.hetzner.api.models.Status113;

Status113 status113 = Status113.CREATING;
```

