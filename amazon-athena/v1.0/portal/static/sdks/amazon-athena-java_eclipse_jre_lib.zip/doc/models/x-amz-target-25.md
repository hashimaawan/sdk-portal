
# X Amz Target 25

## Enumeration

`XAmzTarget25`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget25;

XAmzTarget25 xAmzTarget25 = XAmzTarget25.ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS;
```

