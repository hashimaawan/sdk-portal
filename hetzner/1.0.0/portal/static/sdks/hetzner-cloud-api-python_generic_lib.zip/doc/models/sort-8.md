
# Sort 8

## Enumeration

`Sort8`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `NAME` |
| `ENUM_NAMEASC` |
| `ENUM_NAMEDESC` |

## Example

```python
from hetznercloudapi.models.sort_8 import Sort8

sort_8 = Sort8.ENUM_IDDESC
```

