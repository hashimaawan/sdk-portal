# SSH Keys

```csharp
SSHKeysController sSHKeysController = client.SSHKeysController;
```

## Class Name

`SSHKeysController`

## Methods

* [Get All SSH Keys](../../doc/controllers/ssh-keys.md#get-all-ssh-keys)
* [Create an SSH Key](../../doc/controllers/ssh-keys.md#create-an-ssh-key)
* [Delete an SSH Key](../../doc/controllers/ssh-keys.md#delete-an-ssh-key)
* [Get a SSH Key](../../doc/controllers/ssh-keys.md#get-a-ssh-key)
* [Update an SSH Key](../../doc/controllers/ssh-keys.md#update-an-ssh-key)


# Get All SSH Keys

Returns all SSH key objects.

```csharp
GetAllSSHKeysAsync(
    Models.Sort8Enum? sort = null,
    string name = null,
    string fingerprint = null,
    string labelSelector = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`Sort8Enum?`](../../doc/models/sort-8-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `fingerprint` | `string` | Query, Optional | Can be used to filter SSH keys by their fingerprint. The response will only contain the SSH key matching the specified fingerprint. |
| `labelSelector` | `string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `ssh_keys` key in the reply contains an array of SSH key objects with this structure

[`Task<Models.SshKeysResponse>`](../../doc/models/ssh-keys-response.md)

## Example Usage

```csharp
try
{
    SshKeysResponse result = await sSHKeysController.GetAllSSHKeysAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Create an SSH Key

Creates a new SSH key with the given `name` and `public_key`. Once an SSH key is created, it can be used in other calls such as creating Servers.

```csharp
CreateAnSSHKeyAsync(
    Models.SshKeysRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SshKeysRequest`](../../doc/models/ssh-keys-request.md) | Body, Optional | - |

## Response Type

**201**: The `ssh_key` key in the reply contains the object that was just created

[`Task<Models.SshKeysResponse1>`](../../doc/models/ssh-keys-response-1.md)

## Example Usage

```csharp
SshKeysRequest body = new SshKeysRequest
{
    Name = "My ssh key",
    PublicKey = "ssh-rsa AAAjjk76kgf...Xt",
};

try
{
    SshKeysResponse1 result = await sSHKeysController.CreateAnSSHKeyAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Delete an SSH Key

Deletes an SSH key. It cannot be used anymore.

```csharp
DeleteAnSSHKeyAsync(
    string id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the SSH key |

## Response Type

**204**: SSH key deleted

`Task`

## Example Usage

```csharp
string id = "id0";
try
{
    await sSHKeysController.DeleteAnSSHKeyAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a SSH Key

Returns a specific SSH key object.

```csharp
GetASSHKeyAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the SSH key |

## Response Type

**200**: The `ssh_key` key in the reply contains an SSH key object with this structure

[`Task<Models.SshKeysResponse1>`](../../doc/models/ssh-keys-response-1.md)

## Example Usage

```csharp
int id = 112;
try
{
    SshKeysResponse1 result = await sSHKeysController.GetASSHKeyAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Update an SSH Key

Updates an SSH key. You can update an SSH key name and an SSH key labels.

Please note that when updating labels, the SSH key current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```csharp
UpdateAnSSHKeyAsync(
    string id,
    Models.SshKeysRequest1 body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the SSH key |
| `body` | [`SshKeysRequest1`](../../doc/models/ssh-keys-request-1.md) | Body, Optional | - |

## Response Type

**200**: The `ssh_key` key in the reply contains the modified SSH key object with the new description

[`Task<Models.SshKeysResponse1>`](../../doc/models/ssh-keys-response-1.md)

## Example Usage

```csharp
string id = "id0";
SshKeysRequest1 body = new SshKeysRequest1
{
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "My ssh key",
};

try
{
    SshKeysResponse1 result = await sSHKeysController.UpdateAnSSHKeyAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "ssh_key": {
    "created": "2016-01-30T23:50:00+00:00",
    "fingerprint": "b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f",
    "id": 2323,
    "labels": {
      "labelkey": "value"
    },
    "name": "My ssh key",
    "public_key": "ssh-rsa AAAjjk76kgf...Xt"
  }
}
```

