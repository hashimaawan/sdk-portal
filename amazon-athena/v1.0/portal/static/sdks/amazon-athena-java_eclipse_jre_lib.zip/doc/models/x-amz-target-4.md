
# X Amz Target 4

## Enumeration

`XAmzTarget4`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget4;

XAmzTarget4 xAmzTarget4 = XAmzTarget4.ENUM_AMAZONATHENACREATENAMEDQUERY;
```

