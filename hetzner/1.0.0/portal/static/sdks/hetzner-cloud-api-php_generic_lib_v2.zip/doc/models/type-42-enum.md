
# Type 42 Enum

Type of Subnetwork

## Enumeration

`Type42Enum`

## Fields

| Name |
|  --- |
| `CLOUD` |
| `SERVER` |
| `VSWITCH` |

## Example

```php
use HetznerCloudAPILib\Models\Type42Enum;

$type42 = Type42Enum::CLOUD;
```

