
# List Notebook Metadata Output

## Structure

`ListNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `notebook_metadata_list` | [`List[NotebookMetadata]`](../../doc/models/notebook-metadata.md) | Optional | - |

## Example

```python
import dateutil.parser

from amazonathena.models.list_notebook_metadata_output import ListNotebookMetadataOutput
from amazonathena.models.notebook_metadata import NotebookMetadata
from amazonathena.models.notebook_type_1_enum import NotebookType1Enum

list_notebook_metadata_output = ListNotebookMetadataOutput(
    next_token='NextToken8',
    notebook_metadata_list=[
        NotebookMetadata(
            notebook_id='NotebookId4',
            name='Name4',
            work_group='WorkGroup6',
            creation_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            mtype=NotebookType1Enum.IPYNB
        )
    ]
)
```

