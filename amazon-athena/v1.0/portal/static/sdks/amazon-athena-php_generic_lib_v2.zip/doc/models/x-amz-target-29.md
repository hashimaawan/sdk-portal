
# X Amz Target 29

## Enumeration

`XAmzTarget29`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETWORKGROUP` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget29;

$xAmzTarget29 = XAmzTarget29::ENUM_AMAZONATHENAGETWORKGROUP;
```

