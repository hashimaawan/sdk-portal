
# Direction

Select traffic direction on which rule should be applied. Use `source_ips` for direction `in` and `destination_ips` for direction `out`.

## Enumeration

`Direction`

## Fields

| Name |
|  --- |
| `ENUM_IN` |
| `OUT` |

## Example

```ruby
direction = Direction::ENUM_IN
```

