
# Status 10

An object containing a `state` attribute whose value is set to a string indicating the current status of the node.

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Status10`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`State1`](../../doc/models/state-1.md) | Optional | A string indicating the current status of the node. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
status10 = Status10.new(
  state: State1::PROVISIONING,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

