
# X Amz Target 34 Enum

## Enumeration

`XAmzTarget34Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATABASES` |

## Example

```python
from amazonathena.models.x_amz_target_34_enum import XAmzTarget34Enum

x_amz_target_34 = XAmzTarget34Enum.ENUM_AMAZONATHENALISTDATABASES
```

