
# Status

Status of the Action

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `Success` |
| `Running` |
| `Error` |

## Example

```ts
import { Status } from 'hetzner-cloud-apilib';

const status = Status.Error;
```

