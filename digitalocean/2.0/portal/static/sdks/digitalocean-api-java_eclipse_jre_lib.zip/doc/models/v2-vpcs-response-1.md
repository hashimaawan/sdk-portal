
# V2 Vpcs Response 1

*This model accepts additional fields of type Object.*

## Structure

`V2VpcsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Vpc` | [`Vpc`](../../doc/models/vpc.md) | Optional | - | Vpc getVpc() | setVpc(Vpc vpc) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.V2VpcsResponse1;
import com.digitalocean.api.models.Vpc;
import java.io.IOException;

V2VpcsResponse1 v2VpcsResponse1 = new V2VpcsResponse1.Builder()
    .vpc(new Vpc.Builder()
        .description("description8")
        .name("name2")
        .ipRange("ip_range4")
        .region("region8")
        .mDefault(false)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

