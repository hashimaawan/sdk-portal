
# Item Type 2

The ID type.

## Enumeration

`ItemType2`

## Fields

| Name |
|  --- |
| `Artist` |
| `User` |

## Example

```ts
import {
  ItemType2,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const itemType2 = ItemType2.Artist;
```

