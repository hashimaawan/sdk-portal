
# Engine Version

The Athena engine version for running queries, or the PySpark engine version for running sessions.

## Structure

`EngineVersion`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SelectedEngineVersion` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `EffectiveEngineVersion` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```csharp
using AmazonAthena.Standard.Models;

EngineVersion engineVersion = new EngineVersion
{
    SelectedEngineVersion = "SelectedEngineVersion0",
    EffectiveEngineVersion = "EffectiveEngineVersion0",
};
```

