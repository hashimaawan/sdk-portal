
# Load Balancers Actions Change Algorithm Request

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`models.Type39Enum`](../../doc/models/type-39-enum.md) | Required | Algorithm of the Load Balancer |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    loadBalancersActionsChangeAlgorithmRequest := models.LoadBalancersActionsChangeAlgorithmRequest{
        Type:                 models.Type39Enum_ROUNDROBIN,
    }

}
```

