
# Batch Get Named Query Output

## Structure

`BatchGetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueries` | [`[]models.NamedQuery`](../../doc/models/named-query.md) | Optional | - |
| `UnprocessedNamedQueryIds` | [`[]models.UnprocessedNamedQueryId`](../../doc/models/unprocessed-named-query-id.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    batchGetNamedQueryOutput := models.BatchGetNamedQueryOutput{
        NamedQueries:             []models.NamedQuery{
            models.NamedQuery{
                Name:                 "Name2",
                Description:          models.ToPointer("Description4"),
                Database:             "Database0",
                QueryString:          "QueryString4",
                NamedQueryId:         models.ToPointer("NamedQueryId0"),
                WorkGroup:            models.ToPointer("WorkGroup4"),
            },
            models.NamedQuery{
                Name:                 "Name2",
                Description:          models.ToPointer("Description4"),
                Database:             "Database0",
                QueryString:          "QueryString4",
                NamedQueryId:         models.ToPointer("NamedQueryId0"),
                WorkGroup:            models.ToPointer("WorkGroup4"),
            },
            models.NamedQuery{
                Name:                 "Name2",
                Description:          models.ToPointer("Description4"),
                Database:             "Database0",
                QueryString:          "QueryString4",
                NamedQueryId:         models.ToPointer("NamedQueryId0"),
                WorkGroup:            models.ToPointer("WorkGroup4"),
            },
        },
        UnprocessedNamedQueryIds: []models.UnprocessedNamedQueryId{
            models.UnprocessedNamedQueryId{
                NamedQueryId:         models.ToPointer("NamedQueryId4"),
                ErrorCode:            models.ToPointer("ErrorCode6"),
                ErrorMessage:         models.ToPointer("ErrorMessage4"),
            },
            models.UnprocessedNamedQueryId{
                NamedQueryId:         models.ToPointer("NamedQueryId4"),
                ErrorCode:            models.ToPointer("ErrorCode6"),
                ErrorMessage:         models.ToPointer("ErrorMessage4"),
            },
        },
    }

}
```

