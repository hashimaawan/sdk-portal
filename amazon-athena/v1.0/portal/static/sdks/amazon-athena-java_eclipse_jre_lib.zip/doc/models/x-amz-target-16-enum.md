
# X Amz Target 16 Enum

## Enumeration

`XAmzTarget16Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget16Enum;

XAmzTarget16Enum xAmzTarget16 = XAmzTarget16Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE;
```

