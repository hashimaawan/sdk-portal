
# Protection 11

Protection configuration for the Network

## Structure

`Protection11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `delete` | `bool` | Required | If true, prevents the Network from being deleted | getDelete(): bool | setDelete(bool delete): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\Protection11Builder;

$protection11 = Protection11Builder::init(
    false
)->build();
```

