
# Calculation Statistics

Contains statistics for a notebook calculation.

## Structure

`CalculationStatistics`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dpuExecutionInMillis` | `?int` | Optional | - | getDpuExecutionInMillis(): ?int | setDpuExecutionInMillis(?int dpuExecutionInMillis): void |
| `progress` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getProgress(): ?string | setProgress(?string progress): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\CalculationStatisticsBuilder;

$calculationStatistics = CalculationStatisticsBuilder::init()
    ->dpuExecutionInMillis(248)
    ->progress('Progress8')
    ->build();
```

