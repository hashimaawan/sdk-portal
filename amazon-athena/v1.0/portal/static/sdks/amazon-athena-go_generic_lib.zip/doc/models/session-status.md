
# Session Status

Contains information about the status of a session.

## Structure

`SessionStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StartDateTime` | `*time.Time` | Optional | - |
| `LastModifiedDateTime` | `*time.Time` | Optional | - |
| `EndDateTime` | `*time.Time` | Optional | - |
| `IdleSinceDateTime` | `*time.Time` | Optional | - |
| `State` | [`*models.SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |
| `StateChangeReason` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonathena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    sessionStatus := models.SessionStatus{
        StartDateTime:        models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        LastModifiedDateTime: models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        EndDateTime:          models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        IdleSinceDateTime:    models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        State:                models.ToPointer(models.SessionState1Enum_IDLE),
    }

}
```

