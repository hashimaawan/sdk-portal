
# X Amz Target 2 Enum

## Enumeration

`XAmzTarget2Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```ruby
x_amz_target2 = XAmzTarget2Enum::ENUM_AMAZONATHENABATCHGETQUERYEXECUTION
```

