
# List Data Catalogs Output

## Structure

`ListDataCatalogsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data_catalogs_summary` | [`List[DataCatalogSummary]`](../../doc/models/data-catalog-summary.md) | Optional | - |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```python
from amazonathena.models.data_catalog_summary import DataCatalogSummary
from amazonathena.models.data_catalog_type_2_enum import DataCatalogType2Enum
from amazonathena.models.list_data_catalogs_output import ListDataCatalogsOutput

list_data_catalogs_output = ListDataCatalogsOutput(
    data_catalogs_summary=[
        DataCatalogSummary(
            catalog_name='CatalogName4',
            mtype=DataCatalogType2Enum.HIVE
        ),
        DataCatalogSummary(
            catalog_name='CatalogName4',
            mtype=DataCatalogType2Enum.HIVE
        ),
        DataCatalogSummary(
            catalog_name='CatalogName4',
            mtype=DataCatalogType2Enum.HIVE
        )
    ],
    next_token='NextToken2'
)
```

