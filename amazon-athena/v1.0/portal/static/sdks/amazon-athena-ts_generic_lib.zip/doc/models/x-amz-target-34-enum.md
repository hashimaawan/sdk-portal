
# X Amz Target 34 Enum

## Enumeration

`XAmzTarget34Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListDatabases` |

## Example

```ts
import { XAmzTarget34Enum } from 'amazon-athenalib';

const xAmzTarget34 = XAmzTarget34Enum.EnumAmazonAthenaListDatabases;
```

