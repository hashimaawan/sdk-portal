
# Status

## Structure

`Status`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`QueryExecutionState1Enum \| undefined`](../../doc/models/query-execution-state-1-enum.md) | Optional | - |
| `stateChangeReason` | `string \| undefined` | Optional | - |
| `submissionDateTime` | `string \| undefined` | Optional | - |
| `completionDateTime` | `string \| undefined` | Optional | - |
| `athenaError` | [`AthenaError2 \| undefined`](../../doc/models/athena-error-2.md) | Optional | - |

## Example

```ts
import { QueryExecutionState1Enum, Status } from 'amazon-athenalib';

const status: Status = {
  state: QueryExecutionState1Enum.QUEUED,
  stateChangeReason: 'StateChangeReason8',
  submissionDateTime: '2016-03-13T12:52:32.123Z',
  completionDateTime: '2016-03-13T12:52:32.123Z',
  athenaError: {
    errorCategory: 3,
    errorType: 128,
    retryable: false,
    errorMessage: 'ErrorMessage8',
  },
};
```

