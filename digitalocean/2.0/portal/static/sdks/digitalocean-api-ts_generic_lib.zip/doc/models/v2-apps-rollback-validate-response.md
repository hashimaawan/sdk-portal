
# V2 Apps Rollback Validate Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsRollbackValidateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`Error \| undefined`](../../doc/models/error.md) | Optional | - |
| `valid` | `boolean \| undefined` | Optional | Indicates whether the app can be rolled back to the specified deployment. |
| `warnings` | [`Warning[] \| undefined`](../../doc/models/warning.md) | Optional | Contains a list of warnings that may cause the rollback to run under unideal circumstances. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Code, V2AppsRollbackValidateResponse } from 'digitalocean-apilib';

const v2AppsRollbackValidateResponse: V2AppsRollbackValidateResponse = {
  error: {
    code: Code.IncompatiblePhase,
    components: [
      'components3'
    ],
    message: 'message4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  valid: false,
  warnings: [
    {
      code: Code.ExceededRevisionLimit,
      components: [
        'components3'
      ],
      message: 'message4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      code: Code.ExceededRevisionLimit,
      components: [
        'components3'
      ],
      message: 'message4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

