
# Type 29 Enum

Type of the resource

## Enumeration

`Type29Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |
| `IP` |

## Example

```php
use HetznerCloudAPILib\Models\Type29Enum;

$type29 = Type29Enum::SERVER;
```

