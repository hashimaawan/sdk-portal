
# X Amz Target 27

## Enumeration

`XAmzTarget27`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSIONSTATUS` |

## Example

```python
from amazonathena.models.x_amz_target_27 import XAmzTarget27

x_amz_target_27 = XAmzTarget27.ENUM_AMAZONATHENAGETSESSIONSTATUS
```

