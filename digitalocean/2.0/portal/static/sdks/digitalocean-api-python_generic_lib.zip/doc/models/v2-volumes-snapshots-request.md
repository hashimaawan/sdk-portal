
# V2 Volumes Snapshots Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2VolumesSnapshotsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | A human-readable name for the volume snapshot. |
| `tags` | `List[str]` | Optional | A flat array of tag names as strings to be applied to the resource. Tag names may be for either existing or new tags. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_volumes_snapshots_request import V2VolumesSnapshotsRequest

v_2_volumes_snapshots_request = V2VolumesSnapshotsRequest(
    name='big-data-snapshot1475261774',
    tags=[
        'base-image',
        'prod'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

