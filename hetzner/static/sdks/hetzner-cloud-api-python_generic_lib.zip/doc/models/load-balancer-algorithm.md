
# Load Balancer Algorithm

Algorithm of the Load Balancer

## Structure

`LoadBalancerAlgorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```python
from hetznercloudapi.models.load_balancer_algorithm import LoadBalancerAlgorithm
from hetznercloudapi.models.type_28_enum import Type28Enum

load_balancer_algorithm = LoadBalancerAlgorithm(
    mtype=Type28Enum.ROUND_ROBIN
)
```

