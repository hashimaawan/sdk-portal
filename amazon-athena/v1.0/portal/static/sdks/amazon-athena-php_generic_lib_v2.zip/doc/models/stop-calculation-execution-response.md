
# Stop Calculation Execution Response

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `state` | [`?string(CalculationExecutionState4Enum)`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - | getState(): ?string | setState(?string state): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\StopCalculationExecutionResponseBuilder;
use AmazonAthenaLib\Models\CalculationExecutionState4Enum;

$stopCalculationExecutionResponse = StopCalculationExecutionResponseBuilder::init()
    ->state(CalculationExecutionState4Enum::QUEUED)
    ->build();
```

