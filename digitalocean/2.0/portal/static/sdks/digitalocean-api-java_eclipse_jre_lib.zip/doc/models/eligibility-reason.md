
# Eligibility Reason

## Enumeration

`EligibilityReason`

## Fields

| Name |
|  --- |
| `OVERREPOSITORYLIMIT` |
| `OVERSTORAGELIMIT` |

## Example

```java
import com.digitalocean.api.models.EligibilityReason;

EligibilityReason eligibilityReason = EligibilityReason.OVERREPOSITORYLIMIT;
```

