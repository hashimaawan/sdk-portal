
# Type 66

## Enumeration

`Type66`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```ruby
type66 = Type66::NETWORK
```

