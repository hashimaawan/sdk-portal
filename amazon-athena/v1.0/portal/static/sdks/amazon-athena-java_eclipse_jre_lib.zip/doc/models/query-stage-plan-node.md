
# Query Stage Plan Node

Stage plan information such as name, identifier, sub plans, and remote sources.

*This model accepts additional fields of type Object.*

## Structure

`QueryStagePlanNode`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | - | String getName() | setName(String name) |
| `Identifier` | `String` | Optional | - | String getIdentifier() | setIdentifier(String identifier) |
| `Children` | [`List<QueryStagePlanNode>`](../../doc/models/query-stage-plan-node.md) | Optional | - | List<QueryStagePlanNode> getChildren() | setChildren(List<QueryStagePlanNode> children) |
| `RemoteSources` | `List<String>` | Optional | - | List<String> getRemoteSources() | setRemoteSources(List<String> remoteSources) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.models.QueryStagePlanNode;
import java.io.IOException;
import java.util.Arrays;

QueryStagePlanNode queryStagePlanNode = new QueryStagePlanNode.Builder()
    .name("Name4")
    .identifier("Identifier0")
    .children(Arrays.asList(
        new QueryStagePlanNode.Builder()
            .name("Name6")
            .identifier("Identifier2")
            .children(Arrays.asList(
                new QueryStagePlanNode.Builder()
                    .build()
            ))
            .remoteSources(Arrays.asList(
                "RemoteSources4",
                "RemoteSources5",
                "RemoteSources6"
            ))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ))
    .remoteSources(Arrays.asList(
        "RemoteSources2",
        "RemoteSources3",
        "RemoteSources4"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

