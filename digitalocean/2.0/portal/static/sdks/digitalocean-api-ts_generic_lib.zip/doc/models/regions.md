
# Regions

A map of region to regional state

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Regions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `euWest` | [`EuWest \| undefined`](../../doc/models/eu-west.md) | Optional | - |
| `usEast` | [`EuWest \| undefined`](../../doc/models/eu-west.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Regions, Status16 } from 'digitalocean-apilib';

const regions: Regions = {
  euWest: {
    status: Status16.Down,
    statusChangedAt: 'status_changed_at4',
    thirtyDayUptimePercentage: 227.78,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  usEast: {
    status: Status16.Down,
    statusChangedAt: 'status_changed_at4',
    thirtyDayUptimePercentage: 121.56,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

