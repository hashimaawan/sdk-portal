
# Table Metadata 2

*This model accepts additional fields of type array.*

## Structure

`TableMetadata2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | getName(): string | setName(string name): void |
| `createTime` | `?DateTime` | Optional | - | getCreateTime(): ?\DateTime | setCreateTime(?\DateTime createTime): void |
| `lastAccessTime` | `?DateTime` | Optional | - | getLastAccessTime(): ?\DateTime | setLastAccessTime(?\DateTime lastAccessTime): void |
| `tableType` | `?string` | Optional | **Constraints**: *Maximum Length*: `255` | getTableType(): ?string | setTableType(?string tableType): void |
| `columns` | [`?(Column[])`](../../doc/models/column.md) | Optional | - | getColumns(): ?array | setColumns(?array columns): void |
| `partitionKeys` | [`?(Column[])`](../../doc/models/column.md) | Optional | - | getPartitionKeys(): ?array | setPartitionKeys(?array partitionKeys): void |
| `parameters` | [`?Parameters`](../../doc/models/parameters.md) | Optional | - | getParameters(): ?Parameters | setParameters(?Parameters parameters): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\TableMetadata2Builder;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\Models\Builders\ColumnBuilder;
use AmazonAthenaLib\ApiHelper;

$tableMetadata2 = TableMetadata2Builder::init(
    'Name8'
)
    ->createTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->lastAccessTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->tableType('TableType6')
    ->columns(
        [
            ColumnBuilder::init(
                'Name0'
            )
                ->type('Type0')
                ->comment('Comment4')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            ColumnBuilder::init(
                'Name0'
            )
                ->type('Type0')
                ->comment('Comment4')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->partitionKeys(
        [
            ColumnBuilder::init(
                'Name6'
            )
                ->type('Type6')
                ->comment('Comment0')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            ColumnBuilder::init(
                'Name6'
            )
                ->type('Type6')
                ->comment('Comment0')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

