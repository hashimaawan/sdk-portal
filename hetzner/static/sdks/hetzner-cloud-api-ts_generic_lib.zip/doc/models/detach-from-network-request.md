
# Detach from Network Request

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `number` | Required | ID of an existing network to detach the Server from |

## Example

```ts
import { DetachFromNetworkRequest } from 'hetzner-cloud-apilib';

const detachFromNetworkRequest: DetachFromNetworkRequest = {
  network: 4711,
};
```

