
# V2 Droplets Actions Request 22

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest22`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `image` | String \| Integer \| nil | Optional | This is a container for one-of cases. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_droplets_actions_request22 = V2DropletsActionsRequest22.new(
  type: Type12::REBOOT,
  image: 'ubuntu-20-04-x64',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

