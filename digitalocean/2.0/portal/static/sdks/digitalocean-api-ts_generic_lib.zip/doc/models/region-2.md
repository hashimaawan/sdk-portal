
# Region 2

The slug identifier for the region where the resource will initially be  available.

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `Ams1` |
| `Ams2` |
| `Ams3` |
| `Blr1` |
| `Fra1` |
| `Lon1` |
| `Nyc1` |
| `Nyc2` |
| `Nyc3` |
| `Sfo1` |
| `Sfo2` |
| `Sfo3` |
| `Sgp1` |
| `Tor1` |

## Example

```ts
import { Region2 } from 'digitalocean-apilib';

const region2 = Region2.Nyc1;
```

