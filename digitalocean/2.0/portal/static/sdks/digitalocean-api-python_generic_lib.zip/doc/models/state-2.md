
# State 2

A string indicating the current status of the cluster.

## Enumeration

`State2`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `PROVISIONING` |
| `DEGRADED` |
| `ERROR` |
| `DELETED` |
| `UPGRADING` |
| `DELETING` |

## Example

```python
from digitaloceanapi.models.state_2 import State2

state_2 = State2.DELETING
```

