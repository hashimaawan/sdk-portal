
# Effect

How the node reacts to pods that it won't tolerate. Available effect values are `NoSchedule`, `PreferNoSchedule`, and `NoExecute`.

## Enumeration

`Effect`

## Fields

| Name |
|  --- |
| `NOSCHEDULE` |
| `PREFERNOSCHEDULE` |
| `NOEXECUTE` |

## Example

```java
import com.digitalocean.api.models.Effect;

Effect effect = Effect.NOSCHEDULE;
```

