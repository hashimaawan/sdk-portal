
# Load Balancer Algorithm

Algorithm of the Load Balancer

## Structure

`LoadBalancerAlgorithm`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type28Enum)`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm | getType(): string | setType(string type): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LoadBalancerAlgorithmBuilder;
use HetznerCloudAPILib\Models\Type28Enum;

$loadBalancerAlgorithm = LoadBalancerAlgorithmBuilder::init(
    Type28Enum::ROUND_ROBIN
)->build();
```

