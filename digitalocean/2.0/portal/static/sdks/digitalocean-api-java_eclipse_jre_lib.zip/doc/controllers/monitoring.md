# Monitoring

The DigitalOcean Monitoring API makes it possible to programmatically retrieve metrics as well as configure alert
policies based on these metrics. The Monitoring API can help you gain insight into how your apps are performing
and consuming resources.

```java
MonitoringApi monitoringApi = client.getMonitoringApi();
```

## Class Name

`MonitoringApi`

## Methods

* [Monitoring List Alert Policy](../../doc/controllers/monitoring.md#monitoring-list-alert-policy)
* [Monitoring Create Alert Policy](../../doc/controllers/monitoring.md#monitoring-create-alert-policy)
* [Monitoring Delete Alert Policy](../../doc/controllers/monitoring.md#monitoring-delete-alert-policy)
* [Monitoring Get Alert Policy](../../doc/controllers/monitoring.md#monitoring-get-alert-policy)
* [Monitoring Update Alert Policy](../../doc/controllers/monitoring.md#monitoring-update-alert-policy)
* [Monitoring Get Droplet Bandwidth Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-bandwidth-metrics)
* [Monitoring Get Droplet Cpu Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-cpu-metrics)
* [Monitoring Get Droplet Filesystem Free Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-filesystem-free-metrics)
* [Monitoring Get Droplet Filesystem Size Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-filesystem-size-metrics)
* [Monitoring Get Droplet Load 1 Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-load-1-metrics)
* [Monitoring Get Droplet Load 15 Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-load-15-metrics)
* [Monitoring Get Droplet Load 5 Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-load-5-metrics)
* [Monitoring Get Droplet Memory Available Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-memory-available-metrics)
* [Monitoring Get Droplet Memory Cached Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-memory-cached-metrics)
* [Monitoring Get Droplet Memory Free Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-memory-free-metrics)
* [Monitoring Get Droplet Memory Total Metrics](../../doc/controllers/monitoring.md#monitoring-get-droplet-memory-total-metrics)


# Monitoring List Alert Policy

Returns all alert policies that are configured for the given account. To List all alert policies, send a GET request to `/v2/monitoring/alerts`.

```java
CompletableFuture<ApiResponse<V2MonitoringAlertsResponse>> monitoringListAlertPolicyAsync(
    final Integer perPage,
    final Integer page)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `Integer` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `Integer` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: A list of alert policies.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringAlertsResponse`](../../doc/models/v2-monitoring-alerts-response.md).

## Example Usage

```java
Integer perPage = 2;
Integer page = 1;

monitoringApi.monitoringListAlertPolicyAsync(perPage, page).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Create Alert Policy

To create a new alert, send a POST request to `/v2/monitoring/alerts`.

```java
CompletableFuture<ApiResponse<V2MonitoringAlertsResponse1>> monitoringCreateAlertPolicyAsync(
    final V2MonitoringAlertsRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2MonitoringAlertsRequest`](../../doc/models/v2-monitoring-alerts-request.md) | Body, Required | The `type` field dictates what type of entity that the alert policy applies to and hence what type of entity is passed in the `entities` array. If both the `tags` array and `entities` array are empty the alert policy applies to all entities of the relevant type that are owned by the user account. Otherwise the following table shows the valid entity types for each type of alert policy:<br><br>Type \| Description \| Valid Entity Type<br>-----\|-------------\|--------------------<br>`v1/insights/droplet/memory_utilization_percent` \| alert on the percent of memory utilization \| Droplet ID<br>`v1/insights/droplet/disk_read` \| alert on the rate of disk read I/O in MBps \| Droplet ID<br>`v1/insights/droplet/load_5` \| alert on the 5 minute load average \| Droplet ID<br>`v1/insights/droplet/load_15` \| alert on the 15 minute load average \| Droplet ID<br>`v1/insights/droplet/disk_utilization_percent` \| alert on the percent of disk utilization \| Droplet ID<br>`v1/insights/droplet/cpu` \| alert on the percent of CPU utilization \| Droplet ID<br>`v1/insights/droplet/disk_write` \| alert on the rate of disk write I/O in MBps \| Droplet ID<br>`v1/insights/droplet/public_outbound_bandwidth` \| alert on the rate of public outbound bandwidth in Mbps \| Droplet ID<br>`v1/insights/droplet/public_inbound_bandwidth` \| alert on the rate of public inbound bandwidth in Mbps \| Droplet ID<br>`v1/insights/droplet/private_outbound_bandwidth` \| alert on the rate of private outbound bandwidth in Mbps \| Droplet ID<br>`v1/insights/droplet/private_inbound_bandwidth` \| alert on the rate of private inbound bandwidth in Mbps \| Droplet ID<br>`v1/insights/droplet/load_1` \| alert on the 1 minute load average \| Droplet ID<br>`v1/insights/lbaas/avg_cpu_utilization_percent`\|alert on the percent of CPU utilization\|load balancer ID<br>`v1/insights/lbaas/connection_utilization_percent`\|alert on the percent of connection utilization\|load balancer ID<br>`v1/insights/lbaas/droplet_health`\|alert on Droplet health status changes\|load balancer ID<br>`v1/insights/lbaas/tls_connections_per_second_utilization_percent`\|alert on the percent of TLS connections per second utilization\|load balancer ID<br>`v1/insights/lbaas/increase_in_http_error_rate_percentage_5xx`\|alert on the percent increase of 5xx level http errors over 5m\|load balancer ID<br>`v1/insights/lbaas/increase_in_http_error_rate_percentage_4xx`\|alert on the percent increase of 4xx level http errors over 5m\|load balancer ID<br>`v1/insights/lbaas/increase_in_http_error_rate_count_5xx`\|alert on the count of 5xx level http errors over 5m\|load balancer ID<br>`v1/insights/lbaas/increase_in_http_error_rate_count_4xx`\|alert on the count of 4xx level http errors over 5m\|load balancer ID<br>`v1/insights/lbaas/high_http_request_response_time`\|alert on high average http response time\|load balancer ID<br>`v1/insights/lbaas/high_http_request_response_time_50p`\|alert on high 50th percentile http response time\|load balancer ID<br>`v1/insights/lbaas/high_http_request_response_time_95p`\|alert on high 95th percentile http response time\|load balancer ID<br>`v1/insights/lbaas/high_http_request_response_time_99p`\|alert on high 99th percentile http response time\|load balancer ID<br>`v1/dbaas/alerts/load_15_alerts` \| alert on 15 minute load average across the database cluster \| database cluster UUID<br>`v1/dbaas/alerts/memory_utilization_alerts` \| alert on the percent memory utilization average across the database cluster \| database cluster UUID<br>`v1/dbaas/alerts/disk_utilization_alerts` \| alert on the percent disk utilization average across the database cluster \| database cluster UUID<br>`v1/dbaas/alerts/cpu_alerts` \| alert on the percent CPU usage average across the database cluster \| database cluster UUID |

## Response Type

**200**: An alert policy.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringAlertsResponse1`](../../doc/models/v2-monitoring-alerts-response-1.md).

## Example Usage

```java
V2MonitoringAlertsRequest body = new V2MonitoringAlertsRequest.Builder(
    new Alerts.Builder(
        Arrays.asList(
            "bob@exmaple.com"
        ),
        Arrays.asList(
            new Slack.Builder(
                "Production Alerts",
                "https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ"
            )
            .build()
        )
    )
    .build(),
    Compare.GREATERTHAN,
    "CPU Alert",
    true,
    Arrays.asList(
        "192018292"
    ),
    Arrays.asList(
        "droplet_tag"
    ),
    Type17.ENUM_V1INSIGHTSDROPLETCPU,
    80D,
    Window1.ENUM_5M
)
.build();

monitoringApi.monitoringCreateAlertPolicyAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Delete Alert Policy

To delete an alert policy, send a DELETE request to `/v2/monitoring/alerts/{alert_uuid}`

```java
CompletableFuture<ApiResponse<Void>> monitoringDeleteAlertPolicyAsync(
    final String alertUuid)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alertUuid` | `String` | Template, Required | A unique identifier for an alert policy. |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
String alertUuid = "4de7ac8b-495b-4884-9a69-1050c6793cd6";

monitoringApi.monitoringDeleteAlertPolicyAsync(alertUuid).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Alert Policy

To retrieve a given alert policy, send a GET request to `/v2/monitoring/alerts/{alert_uuid}`

```java
CompletableFuture<ApiResponse<V2MonitoringAlertsResponse1>> monitoringGetAlertPolicyAsync(
    final String alertUuid)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alertUuid` | `String` | Template, Required | A unique identifier for an alert policy. |

## Response Type

**200**: An alert policy.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringAlertsResponse1`](../../doc/models/v2-monitoring-alerts-response-1.md).

## Example Usage

```java
String alertUuid = "4de7ac8b-495b-4884-9a69-1050c6793cd6";

monitoringApi.monitoringGetAlertPolicyAsync(alertUuid).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Update Alert Policy

To update en existing policy, send a PUT request to `v2/monitoring/alerts/{alert_uuid}`.

```java
CompletableFuture<ApiResponse<V2MonitoringAlertsResponse1>> monitoringUpdateAlertPolicyAsync(
    final String alertUuid,
    final V2MonitoringAlertsRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alertUuid` | `String` | Template, Required | A unique identifier for an alert policy. |
| `body` | [`V2MonitoringAlertsRequest`](../../doc/models/v2-monitoring-alerts-request.md) | Body, Required | The `type` field dictates what type of entity that the alert policy applies to and hence what type of entity is passed in the `entities` array. If both the `tags` array and `entities` array are empty the alert policy applies to all entities of the relevant type that are owned by the user account. Otherwise the following table shows the valid entity types for each type of alert policy:<br><br>Type \| Description \| Valid Entity Type<br>-----\|-------------\|--------------------<br>`v1/insights/droplet/memory_utilization_percent` \| alert on the percent of memory utilization \| Droplet ID<br>`v1/insights/droplet/disk_read` \| alert on the rate of disk read I/O in MBps \| Droplet ID<br>`v1/insights/droplet/load_5` \| alert on the 5 minute load average \| Droplet ID<br>`v1/insights/droplet/load_15` \| alert on the 15 minute load average \| Droplet ID<br>`v1/insights/droplet/disk_utilization_percent` \| alert on the percent of disk utilization \| Droplet ID<br>`v1/insights/droplet/cpu` \| alert on the percent of CPU utilization \| Droplet ID<br>`v1/insights/droplet/disk_write` \| alert on the rate of disk write I/O in MBps \| Droplet ID<br>`v1/insights/droplet/public_outbound_bandwidth` \| alert on the rate of public outbound bandwidth in Mbps \| Droplet ID<br>`v1/insights/droplet/public_inbound_bandwidth` \| alert on the rate of public inbound bandwidth in Mbps \| Droplet ID<br>`v1/insights/droplet/private_outbound_bandwidth` \| alert on the rate of private outbound bandwidth in Mbps \| Droplet ID<br>`v1/insights/droplet/private_inbound_bandwidth` \| alert on the rate of private inbound bandwidth in Mbps \| Droplet ID<br>`v1/insights/droplet/load_1` \| alert on the 1 minute load average \| Droplet ID<br>`v1/insights/lbaas/avg_cpu_utilization_percent`\|alert on the percent of CPU utilization\|load balancer ID<br>`v1/insights/lbaas/connection_utilization_percent`\|alert on the percent of connection utilization\|load balancer ID<br>`v1/insights/lbaas/droplet_health`\|alert on Droplet health status changes\|load balancer ID<br>`v1/insights/lbaas/tls_connections_per_second_utilization_percent`\|alert on the percent of TLS connections per second utilization\|load balancer ID<br>`v1/insights/lbaas/increase_in_http_error_rate_percentage_5xx`\|alert on the percent increase of 5xx level http errors over 5m\|load balancer ID<br>`v1/insights/lbaas/increase_in_http_error_rate_percentage_4xx`\|alert on the percent increase of 4xx level http errors over 5m\|load balancer ID<br>`v1/insights/lbaas/increase_in_http_error_rate_count_5xx`\|alert on the count of 5xx level http errors over 5m\|load balancer ID<br>`v1/insights/lbaas/increase_in_http_error_rate_count_4xx`\|alert on the count of 4xx level http errors over 5m\|load balancer ID<br>`v1/insights/lbaas/high_http_request_response_time`\|alert on high average http response time\|load balancer ID<br>`v1/insights/lbaas/high_http_request_response_time_50p`\|alert on high 50th percentile http response time\|load balancer ID<br>`v1/insights/lbaas/high_http_request_response_time_95p`\|alert on high 95th percentile http response time\|load balancer ID<br>`v1/insights/lbaas/high_http_request_response_time_99p`\|alert on high 99th percentile http response time\|load balancer ID<br>`v1/dbaas/alerts/load_15_alerts` \| alert on 15 minute load average across the database cluster \| database cluster UUID<br>`v1/dbaas/alerts/memory_utilization_alerts` \| alert on the percent memory utilization average across the database cluster \| database cluster UUID<br>`v1/dbaas/alerts/disk_utilization_alerts` \| alert on the percent disk utilization average across the database cluster \| database cluster UUID<br>`v1/dbaas/alerts/cpu_alerts` \| alert on the percent CPU usage average across the database cluster \| database cluster UUID |

## Response Type

**200**: An alert policy.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringAlertsResponse1`](../../doc/models/v2-monitoring-alerts-response-1.md).

## Example Usage

```java
String alertUuid = "4de7ac8b-495b-4884-9a69-1050c6793cd6";
V2MonitoringAlertsRequest body = new V2MonitoringAlertsRequest.Builder(
    new Alerts.Builder(
        Arrays.asList(
            "bob@exmaple.com"
        ),
        Arrays.asList(
            new Slack.Builder(
                "Production Alerts",
                "https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ"
            )
            .build()
        )
    )
    .build(),
    Compare.GREATERTHAN,
    "CPU Alert",
    true,
    Arrays.asList(
        "192018292"
    ),
    Arrays.asList(
        "droplet_tag"
    ),
    Type17.ENUM_V1INSIGHTSDROPLETCPU,
    80D,
    Window1.ENUM_5M
)
.build();

monitoringApi.monitoringUpdateAlertPolicyAsync(alertUuid, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Bandwidth Metrics

To retrieve bandwidth metrics for a given Droplet, send a GET request to `/v2/monitoring/metrics/droplet/bandwidth`. Use the `interface` query parameter to specify if the results should be for the `private` or `public` interface. Use the `direction` query parameter to specify if the results should be for `inbound` or `outbound` traffic.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletBandwidthMetricsAsync(
    final String hostId,
    final Interface mInterface,
    final Direction direction,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `mInterface` | [`Interface`](../../doc/models/interface.md) | Query, Required | The network interface. |
| `direction` | [`Direction`](../../doc/models/direction.md) | Query, Required | The traffic direction. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
Interface mInterface = Interface.ENUM_PRIVATE;
Direction direction = Direction.INBOUND;
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletBandwidthMetricsAsync(hostId, mInterface, direction, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "data": {
    "result": [
      {
        "metric": {
          "direction": "inbound",
          "host_id": "222651441",
          "interface": "private"
        },
        "values": [
          [
            1634052360,
            "0.016600450090265357"
          ],
          [
            1634052480,
            "0.015085955677299055"
          ],
          [
            1634052600,
            "0.014941163855322308"
          ],
          [
            1634052720,
            "0.016214285714285712"
          ]
        ]
      }
    ],
    "resultType": "matrix"
  },
  "status": "success"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Cpu Metrics

To retrieve CPU metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/cpu`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletCpuMetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletCpuMetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "data": {
    "result": [
      {
        "metric": {
          "host_id": "222651441",
          "mode": "idle"
        },
        "values": [
          [
            1635386880,
            "122901.18"
          ],
          [
            1635387000,
            "123020.92"
          ],
          [
            1635387120,
            "123140.8"
          ]
        ]
      },
      {
        "metric": {
          "host_id": "222651441",
          "mode": "iowait"
        },
        "values": [
          [
            1635386880,
            "14.99"
          ],
          [
            1635387000,
            "15.01"
          ],
          [
            1635387120,
            "15.01"
          ]
        ]
      },
      {
        "metric": {
          "host_id": "222651441",
          "mode": "irq"
        },
        "values": [
          [
            1635386880,
            "0"
          ],
          [
            1635387000,
            "0"
          ],
          [
            1635387120,
            "0"
          ]
        ]
      },
      {
        "metric": {
          "host_id": "222651441",
          "mode": "nice"
        },
        "values": [
          [
            1635386880,
            "66.35"
          ],
          [
            1635387000,
            "66.35"
          ],
          [
            1635387120,
            "66.35"
          ]
        ]
      },
      {
        "metric": {
          "host_id": "222651441",
          "mode": "softirq"
        },
        "values": [
          [
            1635386880,
            "2.13"
          ],
          [
            1635387000,
            "2.13"
          ],
          [
            1635387120,
            "2.13"
          ]
        ]
      },
      {
        "metric": {
          "host_id": "222651441",
          "mode": "steal"
        },
        "values": [
          [
            1635386880,
            "7.89"
          ],
          [
            1635387000,
            "7.9"
          ],
          [
            1635387120,
            "7.91"
          ]
        ]
      },
      {
        "metric": {
          "host_id": "222651441",
          "mode": "system"
        },
        "values": [
          [
            1635386880,
            "140.09"
          ],
          [
            1635387000,
            "140.2"
          ],
          [
            1635387120,
            "140.23"
          ]
        ]
      },
      {
        "metric": {
          "host_id": "222651441",
          "mode": "user"
        },
        "values": [
          [
            1635386880,
            "278.57"
          ],
          [
            1635387000,
            "278.65"
          ],
          [
            1635387120,
            "278.69"
          ]
        ]
      }
    ],
    "resultType": "matrix"
  },
  "status": "success"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Filesystem Free Metrics

To retrieve filesystem free metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/filesystem_free`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletFilesystemFreeMetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletFilesystemFreeMetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "data": {
    "result": [
      {
        "metric": {
          "device": "/dev/vda1",
          "fstype": "ext4",
          "host_id": "222651441",
          "mountpoint": "/"
        },
        "values": [
          [
            1635386880,
            "25832407040"
          ],
          [
            1635387000,
            "25832407040"
          ],
          [
            1635387120,
            "25832407040"
          ]
        ]
      }
    ],
    "resultType": "matrix"
  },
  "status": "success"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Filesystem Size Metrics

To retrieve filesystem size metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/filesystem_size`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletFilesystemSizeMetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletFilesystemSizeMetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "data": {
    "result": [
      {
        "metric": {
          "device": "/dev/vda1",
          "fstype": "ext4",
          "host_id": "222651441",
          "mountpoint": "/"
        },
        "values": [
          [
            1635386880,
            "25832407040"
          ],
          [
            1635387000,
            "25832407040"
          ],
          [
            1635387120,
            "25832407040"
          ]
        ]
      }
    ],
    "resultType": "matrix"
  },
  "status": "success"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Load 1 Metrics

To retrieve 1 minute load average metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/load_1`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletLoad1MetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletLoad1MetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Load 15 Metrics

To retrieve 15 minute load average metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/load_15`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletLoad15MetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletLoad15MetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Load 5 Metrics

To retrieve 5 minute load average metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/load_5`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletLoad5MetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletLoad5MetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Memory Available Metrics

To retrieve available memory metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/memory_available`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletMemoryAvailableMetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletMemoryAvailableMetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Memory Cached Metrics

To retrieve cached memory metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/memory_cached`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletMemoryCachedMetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletMemoryCachedMetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Memory Free Metrics

To retrieve free memory metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/memory_free`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletMemoryFreeMetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletMemoryFreeMetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Monitoring Get Droplet Memory Total Metrics

To retrieve total memory metrics for a given droplet, send a GET request to `/v2/monitoring/metrics/droplet/memory_total`.

```java
CompletableFuture<ApiResponse<V2MonitoringMetricsDropletBandwidthResponse>> monitoringGetDropletMemoryTotalMetricsAsync(
    final String hostId,
    final String start,
    final String end)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `hostId` | `String` | Query, Required | The droplet ID. |
| `start` | `String` | Query, Required | Timestamp to start metric window. |
| `end` | `String` | Query, Required | Timestamp to end metric window. |

## Response Type

**200**: The response will be a JSON object with a key called `data` and `status`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2MonitoringMetricsDropletBandwidthResponse`](../../doc/models/v2-monitoring-metrics-droplet-bandwidth-response.md).

## Example Usage

```java
String hostId = "17209102";
String start = "1620683817";
String end = "1620705417";

monitoringApi.monitoringGetDropletMemoryTotalMetricsAsync(hostId, start, end).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

