
# Result Reuse Information

Contains information about whether the result of a previous query was reused.

*This model accepts additional fields of type Object.*

## Structure

`ResultReuseInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReusedPreviousResult` | `boolean` | Required | - | boolean getReusedPreviousResult() | setReusedPreviousResult(boolean reusedPreviousResult) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.models.ResultReuseInformation;
import java.io.IOException;

ResultReuseInformation resultReuseInformation = new ResultReuseInformation.Builder(
    false
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

