
# Statistics 1

## Structure

`Statistics1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpuExecutionInMillis` | `number \| undefined` | Optional | - |
| `progress` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { Statistics1 } from 'amazon-athenalib';

const statistics1: Statistics1 = {
  dpuExecutionInMillis: 148,
  progress: 'Progress4',
};
```

