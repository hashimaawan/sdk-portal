
# X Amz Target 57 Enum

## Enumeration

`XAmzTarget57Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget57 := models.XAmzTarget57Enum_ENUMAMAZONATHENAUPDATENOTEBOOKMETADATA

}
```

