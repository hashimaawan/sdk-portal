
# X Amz Target 27

## Enumeration

`XAmzTarget27`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSIONSTATUS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget27;

XAmzTarget27 xAmzTarget27 = XAmzTarget27.ENUM_AMAZONATHENAGETSESSIONSTATUS;
```

