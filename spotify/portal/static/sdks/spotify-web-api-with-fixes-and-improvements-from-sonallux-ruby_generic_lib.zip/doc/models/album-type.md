
# Album Type

The type of the album.

## Enumeration

`AlbumType`

## Fields

| Name |
|  --- |
| `ALBUM` |
| `SINGLE` |
| `COMPILATION` |

## Example

```ruby
album_type = AlbumType::COMPILATION
```

