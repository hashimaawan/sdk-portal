
# V2 Account Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2AccountResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `account` | [`?Account`](../../doc/models/account.md) | Optional | - | getAccount(): ?Account | setAccount(?Account account): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2AccountResponseBuilder;
use DigitalOceanApiLib\Models\Builders\AccountBuilder;
use DigitalOceanApiLib\Models\Status;
use DigitalOceanApiLib\Models\Builders\TeamBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2AccountResponse = V2AccountResponseBuilder::init()
    ->account(
        AccountBuilder::init(
            248,
            'email6',
            false,
            164,
            Status::WARNING,
            'status_message8',
            'uuid6'
        )
            ->team(
                TeamBuilder::init()
                    ->name('name0')
                    ->uuid('uuid6')
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

