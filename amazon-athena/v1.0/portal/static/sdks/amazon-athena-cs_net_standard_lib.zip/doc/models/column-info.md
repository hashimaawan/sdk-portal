
# Column Info

Information about the columns in a query execution result.

*This model accepts additional fields of type object.*

## Structure

`ColumnInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `string` | Optional | - |
| `SchemaName` | `string` | Optional | - |
| `TableName` | `string` | Optional | - |
| `Name` | `string` | Required | - |
| `Label` | `string` | Optional | - |
| `Type` | `string` | Required | - |
| `Precision` | `int?` | Optional | - |
| `Scale` | `int?` | Optional | - |
| `Nullable` | [`ColumnNullable2?`](../../doc/models/column-nullable-2.md) | Optional | - |
| `CaseSensitive` | `bool?` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

ColumnInfo columnInfo = new ColumnInfo
{
    Name = "Name8",
    Type = "Type8",
    CatalogName = "CatalogName2",
    SchemaName = "SchemaName2",
    TableName = "TableName4",
    Label = "Label6",
    Precision = 196,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

