
# Type 63

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |
| `BACKUP` |

## Example

```python
from hetznercloudapi.models.type_63 import Type63

type_63 = Type63.SNAPSHOT
```

