
# Protocol

Type of traffic to allow

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Udp` |
| `Icmp` |
| `Esp` |
| `Gre` |

## Example

```ts
import { Protocol } from 'hetzner-cloud-apilib';

const protocol = Protocol.Esp;
```

