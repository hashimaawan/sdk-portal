
# Accept

## Enumeration

`Accept`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONYAML` |

## Example

```python
from digitaloceanapi.models.accept import Accept

accept = Accept.ENUM_APPLICATIONJSON
```

