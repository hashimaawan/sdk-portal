
# Data

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Data`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result` | [`Result[]`](../../doc/models/result.md) | Required | Result of query. |
| `resultType` | `string` | Required, Constant | **Value**: `'matrix'` |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Data } from 'digitalocean-apilib';

const data: Data = {
  result: [
    {
      metric: {
        'host_id': '19201920'
      },
      values: [
        null,
        null
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  resultType: 'matrix',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

