
# Executor State 3

<p>The processing state of the executor. A description of each state follows.</p> <p> <code>CREATING</code> - The executor is being started, including acquiring resources.</p> <p> <code>CREATED</code> - The executor has been started.</p> <p> <code>REGISTERED</code> - The executor has been registered.</p> <p> <code>TERMINATING</code> - The executor is in the process of shutting down.</p> <p> <code>TERMINATED</code> - The executor is no longer running.</p> <p> <code>FAILED</code> - Due to a failure, the executor is no longer running.</p>


## Enumeration

`ExecutorState3`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Registered` |
| `Terminating` |
| `Terminated` |
| `Failed` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    executorState3 := models.ExecutorState3_Creating

}
```

