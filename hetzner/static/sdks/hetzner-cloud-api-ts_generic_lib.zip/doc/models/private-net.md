
# Private Net

## Structure

`PrivateNet`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip` | `string \| undefined` | Optional | - |
| `network` | `number \| undefined` | Optional | - |

## Example

```ts
import { PrivateNet } from 'hetzner-cloud-apilib';

const privateNet: PrivateNet = {
  ip: '10.0.0.2',
  network: 4711,
};
```

