
# Issuance

Status of the issuance process of the Certificate

## Enumeration

`Issuance`

## Fields

| Name |
|  --- |
| `Pending` |
| `Completed` |
| `Failed` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Issuance issuance = Issuance.Failed;
```

