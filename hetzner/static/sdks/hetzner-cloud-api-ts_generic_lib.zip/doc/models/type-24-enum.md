
# Type 24 Enum

Destination Image type to convert to

## Enumeration

`Type24Enum`

## Fields

| Name |
|  --- |
| `Snapshot` |

## Example

```ts
import { Type24Enum } from 'hetzner-cloud-apilib';

const type24 = Type24Enum.Snapshot;
```

