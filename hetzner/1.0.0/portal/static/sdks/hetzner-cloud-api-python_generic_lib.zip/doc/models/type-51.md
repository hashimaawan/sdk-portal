
# Type 51

Primary IP type

## Enumeration

`Type51`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_51 import Type51

type_51 = Type51.IPV4
```

