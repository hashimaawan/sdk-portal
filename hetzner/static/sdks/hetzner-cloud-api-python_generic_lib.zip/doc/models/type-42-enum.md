
# Type 42 Enum

Type of Subnetwork

## Enumeration

`Type42Enum`

## Fields

| Name |
|  --- |
| `CLOUD` |
| `SERVER` |
| `VSWITCH` |

## Example

```python
from hetznercloudapi.models.type_42_enum import Type42Enum

type_42 = Type42Enum.CLOUD
```

