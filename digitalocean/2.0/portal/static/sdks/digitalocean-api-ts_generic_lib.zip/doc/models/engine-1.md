
# Engine 1

A slug representing the database engine used for the cluster. The possible values are: "pg" for PostgreSQL, "mysql" for MySQL, "redis" for Redis, and "mongodb" for MongoDB.

## Enumeration

`Engine1`

## Fields

| Name |
|  --- |
| `Pg` |
| `Mysql` |
| `Redis` |
| `Mongodb` |

## Example

```ts
import { Engine1 } from 'digitalocean-apilib';

const engine1 = Engine1.Redis;
```

