
# Get Named Query Output

## Structure

`GetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NamedQuery` | [`NamedQuery1`](../../doc/models/named-query-1.md) | Optional | - | NamedQuery1 getNamedQuery() | setNamedQuery(NamedQuery1 namedQuery) |

## Example

```java
import com.amazonaws.useast1.athena.models.GetNamedQueryOutput;
import com.amazonaws.useast1.athena.models.NamedQuery1;

GetNamedQueryOutput getNamedQueryOutput = new GetNamedQueryOutput.Builder()
    .namedQuery(new NamedQuery1.Builder(
        "Name0",
        "Database8",
        "QueryString2"
    )
    .description("Description6")
    .namedQueryId("NamedQueryId2")
    .workGroup("WorkGroup2")
    .build())
    .build();
```

