
# X Amz Target 40

## Enumeration

`XAmzTarget40`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```ruby
x_amz_target40 = XAmzTarget40::ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS
```

