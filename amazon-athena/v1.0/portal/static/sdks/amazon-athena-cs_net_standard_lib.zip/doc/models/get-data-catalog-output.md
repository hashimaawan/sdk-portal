
# Get Data Catalog Output

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DataCatalog` | [`DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetDataCatalogOutput getDataCatalogOutput = new GetDataCatalogOutput
{
    DataCatalog = new DataCatalog2
    {
        Name = "Name4",
        Type = DataCatalogType1Enum.GLUE,
        Description = "Description2",
        Parameters = new Parameters
        {
        },
    },
};
```

