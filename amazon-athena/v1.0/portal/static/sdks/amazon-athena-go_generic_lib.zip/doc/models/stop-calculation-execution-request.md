
# Stop Calculation Execution Request

## Structure

`StopCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    stopCalculationExecutionRequest := models.StopCalculationExecutionRequest{
        CalculationExecutionId: "CalculationExecutionId2",
    }

}
```

