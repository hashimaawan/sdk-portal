
# X Amz Target 57

## Enumeration

`XAmzTarget57`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNotebookMetadata` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget57 xAmzTarget57 = XAmzTarget57.EnumAmazonAthenaUpdateNotebookMetadata;
```

