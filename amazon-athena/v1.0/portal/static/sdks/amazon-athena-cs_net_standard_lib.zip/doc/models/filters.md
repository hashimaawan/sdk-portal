
# Filters

## Structure

`Filters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```csharp
using AmazonAthena.Standard.Models;

Filters filters = new Filters
{
    Name = "Name0",
};
```

