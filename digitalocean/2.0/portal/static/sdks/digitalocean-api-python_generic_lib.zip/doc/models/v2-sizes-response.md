
# V2 Sizes Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2SizesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sizes` | [`List[Size]`](../../doc/models/size.md) | Required | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.size import Size
from digitaloceanapi.models.v_2_sizes_response import V2SizesResponse

v_2_sizes_response = V2SizesResponse(
    sizes=[
        Size(
            available=True,
            description='Basic',
            disk=25,
            memory=1024,
            price_hourly=0.00743999984115362,
            price_monthly=5,
            regions=[
                'ams2',
                'ams3',
                'blr1',
                'fra1',
                'lon1',
                'nyc1',
                'nyc2',
                'nyc3',
                'sfo1',
                'sfo2',
                'sfo3',
                'sgp1',
                'tor1'
            ],
            slug='s-1vcpu-1gb',
            transfer=1,
            vcpus=1,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    meta=Meta(
        total=64,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    links=Links(
        pages=Pages(
            last='https://api.digitalocean.com/v2/sizes?page=64&per_page=1',
            next='https://api.digitalocean.com/v2/sizes?page=2&per_page=1',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

