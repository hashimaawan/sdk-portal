
# X Amz Target 53 Enum

## Enumeration

`XAmzTarget53Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUNTAGRESOURCE` |

## Example

```python
from amazonathena.models.x_amz_target_53_enum import XAmzTarget53Enum

x_amz_target_53 = XAmzTarget53Enum.ENUM_AMAZONATHENAUNTAGRESOURCE
```

