
# Column Info

Information about the columns in a query execution result.

## Structure

`ColumnInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalogName` | `string \| undefined` | Optional | - |
| `schemaName` | `string \| undefined` | Optional | - |
| `tableName` | `string \| undefined` | Optional | - |
| `name` | `string` | Required | - |
| `label` | `string \| undefined` | Optional | - |
| `type` | `string` | Required | - |
| `precision` | `number \| undefined` | Optional | - |
| `scale` | `number \| undefined` | Optional | - |
| `nullable` | [`ColumnNullable2Enum \| undefined`](../../doc/models/column-nullable-2-enum.md) | Optional | - |
| `caseSensitive` | `boolean \| undefined` | Optional | - |

## Example

```ts
import { ColumnInfo } from 'amazon-athenalib';

const columnInfo: ColumnInfo = {
  name: 'Name8',
  type: 'Type8',
  catalogName: 'CatalogName2',
  schemaName: 'SchemaName2',
  tableName: 'TableName4',
  label: 'Label6',
  precision: 196,
};
```

