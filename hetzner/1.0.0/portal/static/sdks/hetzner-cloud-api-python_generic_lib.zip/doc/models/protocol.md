
# Protocol

Type of traffic to allow

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |
| `ESP` |
| `GRE` |

## Example

```python
from hetznercloudapi.models.protocol import Protocol

protocol = Protocol.ESP
```

