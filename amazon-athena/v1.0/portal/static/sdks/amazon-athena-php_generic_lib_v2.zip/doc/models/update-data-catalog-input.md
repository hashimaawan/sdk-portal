
# Update Data Catalog Input

*This model accepts additional fields of type array.*

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getName(): string | setName(string name): void |
| `type` | [`string(DataCatalogType3)`](../../doc/models/data-catalog-type-3.md) | Required | - | getType(): string | setType(string type): void |
| `description` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getDescription(): ?string | setDescription(?string description): void |
| `parameters` | [`?Parameters`](../../doc/models/parameters.md) | Optional | - | getParameters(): ?Parameters | setParameters(?Parameters parameters): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\UpdateDataCatalogInputBuilder;
use AmazonAthenaLib\Models\DataCatalogType3;
use AmazonAthenaLib\Models\Builders\ParametersBuilder;
use AmazonAthenaLib\ApiHelper;

$updateDataCatalogInput = UpdateDataCatalogInputBuilder::init(
    'Name4',
    DataCatalogType3::GLUE
)
    ->description('Description2')
    ->parameters(
        ParametersBuilder::init()
            ->additionalProperty('exampleAdditionalProperty', 'Parameters_additionalProperties2')
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

