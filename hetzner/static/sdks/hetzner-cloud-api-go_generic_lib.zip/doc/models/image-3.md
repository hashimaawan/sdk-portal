
# Image 3

The cost of Image per GB/month

## Structure

`Image3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PricePerGbMonth` | [`models.PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    image3 := models.Image3{
        PricePerGbMonth:      models.PricePerGbMonth{
            Gross:                "1.1900000000000000",
            Net:                  "1.0000000000",
        },
    }

}
```

