
# Work Group State 3 Enum

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    workGroupState3 := models.WorkGroupState3Enum_ENABLED

}
```

