
# List Tags for Resource Input

## Structure

`ListTagsForResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resource_arn` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `int` | Optional | **Constraints**: `>= 75` |

## Example

```python
from amazonathena.models.list_tags_for_resource_input import ListTagsForResourceInput

list_tags_for_resource_input = ListTagsForResourceInput(
    resource_arn='ResourceARN2',
    next_token='NextToken8',
    max_results=140
)
```

