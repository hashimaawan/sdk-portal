
# Create Floating IP Request

## Structure

`CreateFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `*string` | Optional | - |
| `HomeLocation` | `*string` | Optional | Home Location (routing is optimized for that Location). Only optional if Server argument is passed. |
| `Labels` | `*interface{}` | Optional | User-defined labels (key-value pairs) |
| `Name` | `*string` | Optional | - |
| `Server` | `*int` | Optional | Server to assign the Floating IP to |
| `Type` | [`models.Type17Enum`](../../doc/models/type-17-enum.md) | Required | Floating IP type |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    createFloatingIPRequest := models.CreateFloatingIPRequest{
        Description:          models.ToPointer("Web Frontend"),
        HomeLocation:         models.ToPointer("fsn1"),
        Labels:               models.ToPointer(interface{}("[labelkey, value]")),
        Name:                 models.ToPointer("Web Frontend"),
        Server:               models.ToPointer(42),
        Type:                 models.Type17Enum_IPV4,
    }

}
```

