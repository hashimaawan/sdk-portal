
# Result Reuse by Age Configuration

Specifies whether previous query results are reused, and if so, their maximum age.

## Structure

`ResultReuseByAgeConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Enabled` | `bool` | Required | - |
| `MaxAgeInMinutes` | `*int` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    resultReuseByAgeConfiguration := models.ResultReuseByAgeConfiguration{
        Enabled:              false,
        MaxAgeInMinutes:      models.ToPointer(134),
    }

}
```

