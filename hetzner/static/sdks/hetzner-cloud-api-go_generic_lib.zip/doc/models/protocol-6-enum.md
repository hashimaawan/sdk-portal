
# Protocol 6 Enum

Type of the health check

## Enumeration

`Protocol6Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    protocol6 := models.Protocol6Enum_TCP

}
```

