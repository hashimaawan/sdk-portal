
# List of Txt Validation Record

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`ListOfTxtValidationRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `txtName` | `?string` | Optional, Read-only | - | getTxtName(): ?string | setTxtName(?string txtName): void |
| `txtValue` | `?string` | Optional, Read-only | - | getTxtValue(): ?string | setTxtValue(?string txtValue): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\ListOfTxtValidationRecordBuilder;
use DigitalOceanApiLib\ApiHelper;

$listOfTxtValidationRecord = ListOfTxtValidationRecordBuilder::init()
    ->txtName('_acme-challenge.app.example.com')
    ->txtValue('lXLOcN6cPv0nproViNcUHcahD9TrIPlNgdwesj0pYpk')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

