# Actions

Actions show the results and progress of asynchronous requests to the API.

```go
actionsApi := client.ActionsApi()
```

## Class Name

`ActionsApi`

## Methods

* [Get All Actions](../../doc/controllers/actions.md#get-all-actions)
* [Get an Action](../../doc/controllers/actions.md#get-an-action)


# Get All Actions

Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```go
GetAllActions(
    ctx context.Context,
    id *int,
    sort *models.ParameterSort,
    status *models.ParameterStatus) (
    models.ApiResponse[models.ActionsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `*int` | Query, Optional | Can be used multiple times, the response will contain only Actions with specified IDs |
| `sort` | [`*models.ParameterSort`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`*models.ParameterStatus`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := actionsApi.GetAllActions(ctx, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get an Action

Returns a specific Action object.

```go
GetAnAction(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |

## Response Type

**200**: The `action` key in the reply has this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := actionsApi.GetAnAction(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

