
# Create Prepared Statement Input

## Structure

`CreatePreparedStatementInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StatementName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `QueryStatement` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```csharp
using AmazonAthena.Standard.Models;

CreatePreparedStatementInput createPreparedStatementInput = new CreatePreparedStatementInput
{
    StatementName = "StatementName2",
    WorkGroup = "WorkGroup6",
    QueryStatement = "QueryStatement6",
    Description = "Description2",
};
```

