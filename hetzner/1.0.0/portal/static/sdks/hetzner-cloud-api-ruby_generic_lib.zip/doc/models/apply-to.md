
# Apply To

*This model accepts additional fields of type Object.*

## Structure

`ApplyTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label_selector` | [`LabelSelector1`](../../doc/models/label-selector-1.md) | Optional | Configuration for type LabelSelector, required if type is `label_selector` |
| `server` | [`Server2`](../../doc/models/server-2.md) | Optional | Configuration for type Server, required if type is `server` |
| `type` | [`Type7`](../../doc/models/type-7.md) | Required | Type of the resource |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
apply_to = ApplyTo.new(
  type: Type7::SERVER,
  label_selector: LabelSelector1.new(
    selector: 'selector8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  server: Server2.new(
    id: 14,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

