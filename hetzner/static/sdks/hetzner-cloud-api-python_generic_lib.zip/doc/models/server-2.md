
# Server 2

Configuration for type Server, required if type is `server`

## Structure

`Server2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Server |

## Example

```python
from hetznercloudapi.models.server_2 import Server2

server_2 = Server2(
    id=216
)
```

