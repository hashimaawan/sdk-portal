
# X Amz Target 1

## Enumeration

`XAmzTarget1`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target1 = XAmzTarget1::ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT
```

