
# X Amz Target 4

## Enumeration

`XAmzTarget4`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENAMEDQUERY` |

## Example

```ruby
x_amz_target4 = XAmzTarget4::ENUM_AMAZONATHENACREATENAMEDQUERY
```

