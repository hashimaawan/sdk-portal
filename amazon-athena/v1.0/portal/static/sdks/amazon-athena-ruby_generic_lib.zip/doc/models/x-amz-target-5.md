
# X Amz Target 5

## Enumeration

`XAmzTarget5`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENOTEBOOK` |

## Example

```ruby
x_amz_target5 = XAmzTarget5::ENUM_AMAZONATHENACREATENOTEBOOK
```

