
# Storage Type Enum

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageTypeEnum`

## Fields

| Name |
|  --- |
| `Local` |
| `Network` |

## Example

```ts
import { StorageTypeEnum } from 'hetzner-cloud-apilib';

const storageType = StorageTypeEnum.Local;
```

