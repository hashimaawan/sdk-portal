# Floating IP Actions

```java
FloatingIpActionsApi floatingIpActionsApi = client.getFloatingIpActionsApi();
```

## Class Name

`FloatingIpActionsApi`

## Methods

* [Floating I Ps Action List](../../doc/controllers/floating-ip-actions.md#floating-i-ps-action-list)
* [Floating I Ps Action Post](../../doc/controllers/floating-ip-actions.md#floating-i-ps-action-post)
* [Floating I Ps Action Get](../../doc/controllers/floating-ip-actions.md#floating-i-ps-action-get)


# Floating I Ps Action List

To retrieve all actions that have been executed on a floating IP, send a GET request to `/v2/floating_ips/$FLOATING_IP/actions`.

```java
CompletableFuture<ApiResponse<V2FloatingIpsActionsResponse>> floatingIPsActionListAsync(
    final String floatingIp)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floatingIp` | `String` | Template, Required | A floating IP address. |

## Response Type

**200**: The results will be returned as a JSON object with an `actions` key. This will be set to an array filled with action objects containing the standard floating IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2FloatingIpsActionsResponse`](../../doc/models/v2-floating-ips-actions-response.md).

## Example Usage

```java
String floatingIp = "45.55.96.47";

floatingIpActionsApi.floatingIPsActionListAsync(floatingIp).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Floating I Ps Action Post

To initiate an action on a floating IP send a POST request to
`/v2/floating_ips/$FLOATING_IP/actions`. In the JSON body to the request,
set the `type` attribute to on of the supported action types:

| Action     | Details
|------------|--------
| `assign`   | Assigns a floating IP to a Droplet
| `unassign` | Unassign a floating IP from a Droplet

```java
CompletableFuture<ApiResponse<V2FloatingIpsActionsResponse1>> floatingIPsActionPostAsync(
    final String floatingIp,
    final FloatingIPsActionPostBody body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floatingIp` | `String` | Template, Required | A floating IP address. |
| `body` | [`FloatingIPsActionPostBody`](../../doc/models/containers/floating-i-ps-action-post-body.md) | Body, Optional | This is a container for any-of cases. |

## Response Type

**201**: The response will be an object with a key called `action`. The value of this will be an object that contains the standard floating IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2FloatingIpsActionsResponse1`](../../doc/models/v2-floating-ips-actions-response-1.md).

## Example Usage

```java
String floatingIp = "45.55.96.47";
FloatingIPsActionPostBody body = FloatingIPsActionPostBody.fromBaseType(
    new V2ReservedIpsActionsRequest.Builder(
        758604968
    )
    .type("V2 Reserved Ips Actions Request")
    .build()
);

floatingIpActionsApi.floatingIPsActionPostAsync(floatingIp, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Floating I Ps Action Get

To retrieve the status of a floating IP action, send a GET request to `/v2/floating_ips/$FLOATING_IP/actions/$ACTION_ID`.

```java
CompletableFuture<ApiResponse<V2FloatingIpsActionsResponse1>> floatingIPsActionGetAsync(
    final String floatingIp,
    final int actionId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floatingIp` | `String` | Template, Required | A floating IP address. |
| `actionId` | `int` | Template, Required | A unique numeric ID that can be used to identify and reference an action.<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be an object with a key called `action`. The value of this will be an object that contains the standard floating IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2FloatingIpsActionsResponse1`](../../doc/models/v2-floating-ips-actions-response-1.md).

## Example Usage

```java
String floatingIp = "45.55.96.47";
int actionId = 36804636;

floatingIpActionsApi.floatingIPsActionGetAsync(floatingIp, actionId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

