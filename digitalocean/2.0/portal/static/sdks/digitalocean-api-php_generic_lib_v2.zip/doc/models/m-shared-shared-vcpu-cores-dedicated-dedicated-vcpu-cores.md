
# M Shared Shared Vcpu Cores Dedicated Dedicated Vcpu Cores

## Enumeration

`MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `SHARED` |
| `DEDICATED` |

## Example

```php
use DigitalOceanApiLib\Models\MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores;

$mSharedSharedVcpuCoresDedicatedDedicatedVcpuCores = MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores::DEDICATED;
```

