
# X Amz Target 25 Enum

## Enumeration

`XAmzTarget25Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget25Enum;

$xAmzTarget25 = XAmzTarget25Enum::ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS;
```

