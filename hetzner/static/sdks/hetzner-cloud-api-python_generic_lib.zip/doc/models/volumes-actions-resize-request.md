
# Volumes Actions Resize Request

## Structure

`VolumesActionsResizeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `size` | `float` | Required | New Volume size in GB (must be greater than current size) |

## Example

```python
from hetznercloudapi.models.volumes_actions_resize_request import VolumesActionsResizeRequest

volumes_actions_resize_request = VolumesActionsResizeRequest(
    size=50
)
```

