
# Locations Response

## Structure

`LocationsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `locations` | [`Location[]`](../../doc/models/location.md) | Required | - | getLocations(): array | setLocations(array locations): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LocationsResponseBuilder;
use HetznerCloudAPILib\Models\Builders\LocationBuilder;

$locationsResponse = LocationsResponseBuilder::init(
    [
        LocationBuilder::init(
            'Falkenstein',
            'DE',
            'Falkenstein DC Park 1',
            1,
            50.47612,
            12.370071,
            'fsn1',
            'eu-central'
        )->build()
    ]
)->build();
```

