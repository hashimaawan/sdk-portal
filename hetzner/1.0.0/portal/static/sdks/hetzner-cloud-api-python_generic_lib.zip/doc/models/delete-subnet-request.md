
# Delete Subnet Request

*This model accepts additional fields of type Any.*

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip_range` | `str` | Required | IP range of subnet to delete |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.delete_subnet_request import DeleteSubnetRequest

delete_subnet_request = DeleteSubnetRequest(
    ip_range='10.0.1.0/24',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

