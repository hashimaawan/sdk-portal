
# Change Type Request

## Structure

`ChangeTypeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `loadBalancerType` | `string` | Required | ID or name of Load Balancer type the Load Balancer should migrate to |

## Example

```ts
import { ChangeTypeRequest } from 'hetzner-cloud-apilib';

const changeTypeRequest: ChangeTypeRequest = {
  loadBalancerType: 'lb21',
};
```

