# Vaults

Access 1Password Vaults

```go
vaultsApi := client.VaultsApi()
```

## Class Name

`VaultsApi`

## Methods

* [Get Vaults](../../doc/controllers/vaults.md#get-vaults)
* [Get Vault by Id](../../doc/controllers/vaults.md#get-vault-by-id)


# Get Vaults

```go
GetVaults(
    ctx context.Context,
    filter *string) (
    models.ApiResponse[[]models.Vault],
    error)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filter` | `*string` | Query, Optional | Filter the Vault collection based on Vault name using SCIM eq filter |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.Vault](../../doc/models/vault.md).

## Example Usage

```go
ctx := context.Background()

filter := "name eq \"Some Vault Name\""

apiResponse, err := vaultsApi.GetVaults(ctx, &filter)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorResponse:
            log.Fatalln("ErrorResponseException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Vault by Id

```go
GetVaultById(
    ctx context.Context,
    vaultUuid string) (
    models.ApiResponse[models.Vault],
    error)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.Vault](../../doc/models/vault.md).

## Example Usage

```go
ctx := context.Background()

vaultUuid := "vaultUuid2"

apiResponse, err := vaultsApi.GetVaultById(ctx, vaultUuid)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorResponse:
            log.Fatalln("ErrorResponseException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Vault not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

