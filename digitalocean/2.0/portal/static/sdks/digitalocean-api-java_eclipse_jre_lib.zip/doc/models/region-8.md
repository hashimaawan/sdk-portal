
# Region 8

## Enumeration

`Region8`

## Fields

| Name |
|  --- |
| `US_EAST` |
| `US_WEST` |
| `EU_WEST` |
| `SE_ASIA` |

## Example

```java
import com.digitalocean.api.models.Region8;

Region8 region8 = Region8.US_EAST;
```

