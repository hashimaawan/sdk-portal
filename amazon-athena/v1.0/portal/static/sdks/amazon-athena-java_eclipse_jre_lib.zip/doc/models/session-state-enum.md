
# Session State Enum

## Enumeration

`SessionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```java
import com.amazonaws.useast1.athena.models.SessionStateEnum;

SessionStateEnum sessionState = SessionStateEnum.TERMINATING;
```

