
# Type 26

Type of the ISO

## Enumeration

`Type26`

## Fields

| Name |
|  --- |
| `Public` |
| `Private` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type26 := models.Type26_Public

}
```

