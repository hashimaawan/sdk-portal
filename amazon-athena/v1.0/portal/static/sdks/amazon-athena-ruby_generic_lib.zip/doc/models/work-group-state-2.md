
# Work Group State 2

The workgroup state that will be updated for the given workgroup.

## Enumeration

`WorkGroupState2`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ruby
work_group_state2 = WorkGroupState2::ENABLED
```

