
# Blob

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Blob`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `compressedSizeBytes` | `number \| undefined` | Optional | The compressed size of the blob in bytes. |
| `digest` | `string \| undefined` | Optional | The digest of the blob |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Blob } from 'digitalocean-apilib';

const blob: Blob = {
  compressedSizeBytes: 2803255,
  digest: 'sha256:cb8a924afdf0229ef7515d9e5b3024e23b3eb03ddbba287f4a19c6ac90b8d221',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

