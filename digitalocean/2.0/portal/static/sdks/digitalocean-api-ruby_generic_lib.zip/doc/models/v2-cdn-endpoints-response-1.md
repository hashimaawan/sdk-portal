
# V2 Cdn Endpoints Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endpoint` | [`Endpoint`](../../doc/models/endpoint.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_cdn_endpoints_response1 = V2CdnEndpointsResponse1.new(
  endpoint: Endpoint.new(
    origin: 'origin2',
    certificate_id: '00001b94-0000-0000-0000-000000000000',
    created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    custom_domain: 'custom_domain6',
    endpoint: 'endpoint6',
    id: '00001f7a-0000-0000-0000-000000000000',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

