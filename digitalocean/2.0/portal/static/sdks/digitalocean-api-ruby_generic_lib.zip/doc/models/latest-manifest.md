
# Latest Manifest

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`LatestManifest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `blobs` | [`Array[Blob]`](../../doc/models/blob.md) | Optional | All blobs associated with this manifest |
| `compressed_size_bytes` | `Integer` | Optional | The compressed size of the manifest in bytes. |
| `digest` | `String` | Optional | The manifest digest |
| `registry_name` | `String` | Optional | The name of the container registry. |
| `repository` | `String` | Optional | The name of the repository. |
| `size_bytes` | `Integer` | Optional | The uncompressed size of the manifest in bytes (this size is calculated asynchronously so it may not be immediately available). |
| `tags` | `Array[String]` | Optional | All tags associated with this manifest |
| `updated_at` | `DateTime` | Optional | The time the manifest was last updated. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
latest_manifest = LatestManifest.new(
  blobs: [
    Blob.new(
      compressed_size_bytes: 12,
      digest: 'digest2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Blob.new(
      compressed_size_bytes: 12,
      digest: 'digest2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Blob.new(
      compressed_size_bytes: 12,
      digest: 'digest2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  compressed_size_bytes: 2803255,
  digest: 'sha256:cb8a924afdf0229ef7515d9e5b3024e23b3eb03ddbba287f4a19c6ac90b8d221',
  registry_name: 'example',
  repository: 'repo-1',
  size_bytes: 5861888,
  tags: [
    'latest',
    'v1',
    'v2'
  ],
  updated_at: DateTimeHelper.from_rfc3339('2020-04-09T23:54:25Z'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

