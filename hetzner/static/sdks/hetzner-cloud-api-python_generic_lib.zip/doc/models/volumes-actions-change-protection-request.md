
# Volumes Actions Change Protection Request

## Structure

`VolumesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Optional | If true, prevents the Volume from being deleted |

## Example

```python
from hetznercloudapi.models.volumes_actions_change_protection_request import VolumesActionsChangeProtectionRequest

volumes_actions_change_protection_request = VolumesActionsChangeProtectionRequest(
    delete=True
)
```

