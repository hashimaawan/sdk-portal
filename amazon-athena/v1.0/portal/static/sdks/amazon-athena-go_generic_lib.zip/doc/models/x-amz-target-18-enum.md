
# X Amz Target 18 Enum

## Enumeration

`XAmzTarget18Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETDATACATALOG` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget18 := models.XAmzTarget18Enum_ENUMAMAZONATHENAGETDATACATALOG

}
```

