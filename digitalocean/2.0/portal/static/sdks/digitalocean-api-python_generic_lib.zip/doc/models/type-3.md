
# Type 3

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `BUILD` |
| `DEPLOY` |
| `RUN` |

## Example

```python
from digitaloceanapi.models.type_3 import Type3

type_3 = Type3.UNSPECIFIED
```

