
# Alert

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Alert`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `disabled` | `?bool` | Optional | Is the alert disabled? | getDisabled(): ?bool | setDisabled(?bool disabled): void |
| `operator` | [`?string(Operator)`](../../doc/models/operator.md) | Optional | **Default**: `Operator::UNSPECIFIED_OPERATOR` | getOperator(): ?string | setOperator(?string operator): void |
| `rule` | [`?string(Rule)`](../../doc/models/rule.md) | Optional | **Default**: `Rule::UNSPECIFIED_RULE` | getRule(): ?string | setRule(?string rule): void |
| `value` | `?float` | Optional | Threshold value for alert | getValue(): ?float | setValue(?float value): void |
| `window` | [`?string(Window)`](../../doc/models/window.md) | Optional | **Default**: `Window::UNSPECIFIED_WINDOW` | getWindow(): ?string | setWindow(?string window): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\AlertBuilder;
use DigitalOceanApiLib\Models\Operator;
use DigitalOceanApiLib\Models\Rule;
use DigitalOceanApiLib\Models\Window;
use DigitalOceanApiLib\ApiHelper;

$alert = AlertBuilder::init()
    ->disabled(false)
    ->operator(Operator::GREATER_THAN)
    ->rule(Rule::CPU_UTILIZATION)
    ->value(2.32)
    ->window(Window::FIVE_MINUTES)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

