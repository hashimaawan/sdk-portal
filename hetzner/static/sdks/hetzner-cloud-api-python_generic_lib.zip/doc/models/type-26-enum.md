
# Type 26 Enum

Type of the ISO

## Enumeration

`Type26Enum`

## Fields

| Name |
|  --- |
| `PUBLIC` |
| `PRIVATE` |

## Example

```python
from hetznercloudapi.models.type_26_enum import Type26Enum

type_26 = Type26Enum.PUBLIC
```

