
# X Amz Target 48

## Enumeration

`XAmzTarget48`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTSESSION` |

## Example

```ruby
x_amz_target48 = XAmzTarget48::ENUM_AMAZONATHENASTARTSESSION
```

