
# V2 Uptime Checks State Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2UptimeChecksStateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`State3 \| undefined`](../../doc/models/state-3.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Status16, V2UptimeChecksStateResponse } from 'digitalocean-apilib';

const v2UptimeChecksStateResponse: V2UptimeChecksStateResponse = {
  state: {
    previousOutage: {
      durationSeconds: 16,
      endedAt: 'ended_at4',
      region: 'region8',
      startedAt: 'started_at4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    regions: {
      euWest: {
        status: Status16.Down,
        statusChangedAt: 'status_changed_at4',
        thirtyDayUptimePercentage: 227.78,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      usEast: {
        status: Status16.Down,
        statusChangedAt: 'status_changed_at4',
        thirtyDayUptimePercentage: 121.56,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

