
# Error

Error message for the Action if error occurred, otherwise null

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `str` | Required | Fixed machine readable code |
| `message` | `str` | Required | Humanized error message |

## Example

```python
from hetznercloudapi.models.error import Error

error = Error(
    code='action_failed',
    message='Action failed'
)
```

