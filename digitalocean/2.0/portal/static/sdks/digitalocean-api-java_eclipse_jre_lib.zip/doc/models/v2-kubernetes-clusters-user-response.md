
# V2 Kubernetes Clusters User Response

*This model accepts additional fields of type Object.*

## Structure

`V2KubernetesClustersUserResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `KubernetesClusterUser` | [`KubernetesClusterUser`](../../doc/models/kubernetes-cluster-user.md) | Optional | - | KubernetesClusterUser getKubernetesClusterUser() | setKubernetesClusterUser(KubernetesClusterUser kubernetesClusterUser) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.KubernetesClusterUser;
import com.digitalocean.api.models.V2KubernetesClustersUserResponse;
import java.io.IOException;
import java.util.Arrays;

V2KubernetesClustersUserResponse v2KubernetesClustersUserResponse = new V2KubernetesClustersUserResponse.Builder()
    .kubernetesClusterUser(new KubernetesClusterUser.Builder()
        .groups(Arrays.asList(
            "groups8"
        ))
        .username("username6")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

