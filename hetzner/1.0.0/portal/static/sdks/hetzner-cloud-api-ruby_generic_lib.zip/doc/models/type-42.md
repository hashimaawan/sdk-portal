
# Type 42

Type of Subnetwork

## Enumeration

`Type42`

## Fields

| Name |
|  --- |
| `CLOUD` |
| `SERVER` |
| `VSWITCH` |

## Example

```ruby
type42 = Type42::CLOUD
```

