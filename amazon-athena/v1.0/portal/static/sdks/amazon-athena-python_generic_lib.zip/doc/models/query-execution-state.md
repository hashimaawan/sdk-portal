
# Query Execution State

## Enumeration

`QueryExecutionState`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```python
from amazonathena.models.query_execution_state import QueryExecutionState

query_execution_state = QueryExecutionState.SUCCEEDED
```

