
# Day

The day of the maintenance window policy. May be one of `monday` through `sunday`, or `any` to indicate an arbitrary week day.

## Enumeration

`Day`

## Fields

| Name |
|  --- |
| `Any` |
| `Monday` |
| `Tuesday` |
| `Wednesday` |
| `Thursday` |
| `Friday` |
| `Saturday` |
| `Sunday` |

## Example

```ts
import { Day } from 'digitalocean-apilib';

const day = Day.Thursday;
```

