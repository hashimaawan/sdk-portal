
# V2 Droplets Destroy with Associated Resources Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DropletsDestroyWithAssociatedResourcesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `floatingIps` | [`?(FloatingIp[])`](../../doc/models/floating-ip.md) | Optional | - | getFloatingIps(): ?array | setFloatingIps(?array floatingIps): void |
| `reservedIps` | [`?(FloatingIp[])`](../../doc/models/floating-ip.md) | Optional | - | getReservedIps(): ?array | setReservedIps(?array reservedIps): void |
| `snapshots` | [`?(FloatingIp[])`](../../doc/models/floating-ip.md) | Optional | - | getSnapshots(): ?array | setSnapshots(?array snapshots): void |
| `volumeSnapshots` | [`?(FloatingIp[])`](../../doc/models/floating-ip.md) | Optional | - | getVolumeSnapshots(): ?array | setVolumeSnapshots(?array volumeSnapshots): void |
| `volumes` | [`?(FloatingIp[])`](../../doc/models/floating-ip.md) | Optional | - | getVolumes(): ?array | setVolumes(?array volumes): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DropletsDestroyWithAssociatedResourcesResponseBuilder;
use DigitalOceanApiLib\Models\Builders\FloatingIpBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DropletsDestroyWithAssociatedResourcesResponse = V2DropletsDestroyWithAssociatedResourcesResponseBuilder::init()
    ->floatingIps(
        [
            FloatingIpBuilder::init()
                ->cost('cost0')
                ->id('id2')
                ->name('name2')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            FloatingIpBuilder::init()
                ->cost('cost0')
                ->id('id2')
                ->name('name2')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->reservedIps(
        [
            FloatingIpBuilder::init()
                ->cost('cost8')
                ->id('id0')
                ->name('name0')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->snapshots(
        [
            FloatingIpBuilder::init()
                ->cost('cost0')
                ->id('id2')
                ->name('name2')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            FloatingIpBuilder::init()
                ->cost('cost0')
                ->id('id2')
                ->name('name2')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->volumeSnapshots(
        [
            FloatingIpBuilder::init()
                ->cost('cost6')
                ->id('id8')
                ->name('name8')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->volumes(
        [
            FloatingIpBuilder::init()
                ->cost('cost4')
                ->id('id6')
                ->name('name6')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            FloatingIpBuilder::init()
                ->cost('cost4')
                ->id('id6')
                ->name('name6')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

