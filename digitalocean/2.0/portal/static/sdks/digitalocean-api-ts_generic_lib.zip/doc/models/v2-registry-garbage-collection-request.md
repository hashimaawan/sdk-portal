
# V2 Registry Garbage Collection Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cancel` | `boolean \| undefined` | Optional | A boolean value indicating that the garbage collection should be cancelled. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2RegistryGarbageCollectionRequest } from 'digitalocean-apilib';

const v2RegistryGarbageCollectionRequest: V2RegistryGarbageCollectionRequest = {
  cancel: true,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

