
# Work Group State 2

The workgroup state that will be updated for the given workgroup.

## Enumeration

`WorkGroupState2`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```python
from amazonathena.models.work_group_state_2 import WorkGroupState2

work_group_state_2 = WorkGroupState2.ENABLED
```

