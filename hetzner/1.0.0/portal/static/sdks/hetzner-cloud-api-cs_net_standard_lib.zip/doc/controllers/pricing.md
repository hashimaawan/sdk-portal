# Pricing

Returns prices for resources.

```csharp
PricingController pricingController = client.PricingController;
```

## Class Name

`PricingController`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```csharp
GetAllPricesAsync()
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

[`Task<Models.PricingResponse>`](../../doc/models/pricing-response.md)

## Example Usage

```csharp
try
{
    PricingResponse result = await pricingController.GetAllPricesAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

