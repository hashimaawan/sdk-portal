
# X Amz Target 26

## Enumeration

`XAmzTarget26`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget26;

$xAmzTarget26 = XAmzTarget26::ENUM_AMAZONATHENAGETSESSION;
```

