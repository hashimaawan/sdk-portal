
# Start Calculation Execution Response

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CalculationExecutionId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | String getCalculationExecutionId() | setCalculationExecutionId(String calculationExecutionId) |
| `State` | [`CalculationExecutionState4Enum`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - | CalculationExecutionState4Enum getState() | setState(CalculationExecutionState4Enum state) |

## Example

```java
import com.amazonaws.useast1.athena.models.CalculationExecutionState4Enum;
import com.amazonaws.useast1.athena.models.StartCalculationExecutionResponse;

StartCalculationExecutionResponse startCalculationExecutionResponse = new StartCalculationExecutionResponse.Builder()
    .calculationExecutionId("CalculationExecutionId0")
    .state(CalculationExecutionState4Enum.CANCELING)
    .build();
```

