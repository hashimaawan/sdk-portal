
# Add to Placement Group Request

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `placementGroup` | `int` | Required | ID of Placement Group the Server should be added to | getPlacementGroup(): int | setPlacementGroup(int placementGroup): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\AddToPlacementGroupRequestBuilder;

$addToPlacementGroupRequest = AddToPlacementGroupRequestBuilder::init(
    1
)->build();
```

