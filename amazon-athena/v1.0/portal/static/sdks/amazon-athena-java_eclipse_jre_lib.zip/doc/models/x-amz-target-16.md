
# X Amz Target 16

## Enumeration

`XAmzTarget16`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget16;

XAmzTarget16 xAmzTarget16 = XAmzTarget16.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE;
```

