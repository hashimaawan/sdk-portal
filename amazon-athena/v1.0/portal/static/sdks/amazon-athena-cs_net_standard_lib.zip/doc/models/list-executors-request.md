
# List Executors Request

## Structure

`ListExecutorsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ExecutorStateFilter` | [`ExecutorState1Enum?`](../../doc/models/executor-state-1-enum.md) | Optional | - |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `string` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ListExecutorsRequest listExecutorsRequest = new ListExecutorsRequest
{
    SessionId = "SessionId0",
    ExecutorStateFilter = ExecutorState1Enum.CREATING,
    MaxResults = 100,
    NextToken = "NextToken8",
};
```

