
# V2 Databases Firewall Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DatabasesFirewallRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rules` | [`List[Rule1]`](../../doc/models/rule-1.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.rule_1 import Rule1
from digitaloceanapi.models.type_7 import Type7
from digitaloceanapi.models.v_2_databases_firewall_request import V2DatabasesFirewallRequest

v_2_databases_firewall_request = V2DatabasesFirewallRequest(
    rules=[
        Rule1(
            mtype=Type7.IP_ADDR,
            value='value0',
            cluster_uuid='cluster_uuid4',
            created_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            uuid='uuid4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

