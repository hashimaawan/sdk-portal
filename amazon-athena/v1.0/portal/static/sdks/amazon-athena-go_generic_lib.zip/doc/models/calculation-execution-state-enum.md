
# Calculation Execution State Enum

## Enumeration

`CalculationExecutionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    calculationExecutionState := models.CalculationExecutionStateEnum_COMPLETED

}
```

