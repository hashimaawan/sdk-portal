
# Ssh Keys Request 1

*This model accepts additional fields of type unknown.*

## Structure

`SshKeysRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New name Name to set |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SshKeysRequest1 } from 'hetzner-cloud-apilib';

const sshKeysRequest1: SshKeysRequest1 = {
  labels: { 'labelkey': 'value' },
  name: 'My ssh key',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

