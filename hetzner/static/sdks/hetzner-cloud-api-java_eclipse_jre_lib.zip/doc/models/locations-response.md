
# Locations Response

## Structure

`LocationsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Locations` | [`List<Location>`](../../doc/models/location.md) | Required | - | List<Location> getLocations() | setLocations(List<Location> locations) |

## Example

```java
import cloud.hetzner.api.models.Location;
import cloud.hetzner.api.models.LocationsResponse;
import java.util.Arrays;

LocationsResponse locationsResponse = new LocationsResponse.Builder(
    Arrays.asList(
        new Location.Builder(
            "Falkenstein",
            "DE",
            "Falkenstein DC Park 1",
            1D,
            50.47612D,
            12.370071D,
            "fsn1",
            "eu-central"
        )
        .build()
    )
)
.build();
```

