
# Type 63 Enum

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63Enum`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |
| `BACKUP` |

## Example

```python
from hetznercloudapi.models.type_63_enum import Type63Enum

type_63 = Type63Enum.SNAPSHOT
```

