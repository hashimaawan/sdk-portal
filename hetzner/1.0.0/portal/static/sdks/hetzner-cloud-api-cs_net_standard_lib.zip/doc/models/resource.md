
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Resource |
| `Type` | `string` | Required | Type of resource referenced |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Resource resource = new Resource
{
    Id = 42,
    Type = "server",
};
```

