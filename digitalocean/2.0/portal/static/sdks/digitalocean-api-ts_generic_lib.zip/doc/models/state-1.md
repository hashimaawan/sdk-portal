
# State 1

A string indicating the current status of the node.

## Enumeration

`State1`

## Fields

| Name |
|  --- |
| `Provisioning` |
| `Running` |
| `Draining` |
| `Deleting` |

## Example

```ts
import { State1 } from 'digitalocean-apilib';

const state1 = State1.Draining;
```

