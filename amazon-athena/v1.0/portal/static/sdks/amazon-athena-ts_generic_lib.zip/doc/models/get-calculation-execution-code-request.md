
# Get Calculation Execution Code Request

*This model accepts additional fields of type unknown.*

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetCalculationExecutionCodeRequest } from 'amazon-athenalib';

const getCalculationExecutionCodeRequest: GetCalculationExecutionCodeRequest = {
  calculationExecutionId: 'CalculationExecutionId4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

