
# V2 Registry Options Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2RegistryOptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `options` | [`Options2`](../../doc/models/options-2.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_registry_options_response = V2RegistryOptionsResponse.new(
  options: Options2.new(
    available_regions: [
      'available_regions9'
    ],
    subscription_tiers: [
      SubscriptionTier.new(
        allow_storage_overage: false,
        included_bandwidth_bytes: 172,
        included_repositories: 194,
        included_storage_bytes: 242,
        monthly_price_in_cents: 236,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      SubscriptionTier.new(
        allow_storage_overage: false,
        included_bandwidth_bytes: 172,
        included_repositories: 194,
        included_storage_bytes: 242,
        monthly_price_in_cents: 236,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      SubscriptionTier.new(
        allow_storage_overage: false,
        included_bandwidth_bytes: 172,
        included_repositories: 194,
        included_storage_bytes: 242,
        monthly_price_in_cents: 236,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

