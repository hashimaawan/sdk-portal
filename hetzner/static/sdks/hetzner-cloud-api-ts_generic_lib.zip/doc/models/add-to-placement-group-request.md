
# Add to Placement Group Request

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placementGroup` | `number` | Required | ID of Placement Group the Server should be added to |

## Example

```ts
import { AddToPlacementGroupRequest } from 'hetzner-cloud-apilib';

const addToPlacementGroupRequest: AddToPlacementGroupRequest = {
  placementGroup: 1,
};
```

