
# Load Balancers Actions Detach from Network Request

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Network` | `float64` | Required | ID of an existing network to detach the Load Balancer from |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    loadBalancersActionsDetachFromNetworkRequest := models.LoadBalancersActionsDetachFromNetworkRequest{
        Network:              float64(4711),
    }

}
```

