
# Images

An object containing data for various available formats and sizes of this GIF.

## Structure

`Images`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `downsized` | [`Image`](../../doc/models/image.md) | Optional | - |
| `downsized_large` | [`Image`](../../doc/models/image.md) | Optional | - |
| `downsized_medium` | [`Image`](../../doc/models/image.md) | Optional | - |
| `downsized_small` | [`Image`](../../doc/models/image.md) | Optional | - |
| `downsized_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height_downsampled` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height_small` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height_small_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width_downsampled` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width_small` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width_small_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `looping` | [`Image`](../../doc/models/image.md) | Optional | - |
| `original` | [`Image`](../../doc/models/image.md) | Optional | - |
| `original_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `preview` | [`Image`](../../doc/models/image.md) | Optional | - |
| `preview_gif` | [`Image`](../../doc/models/image.md) | Optional | - |

## Example

```ruby
images = Images.new(
  Image.new(
    'frames0',
    'height8',
    'mp40',
    'mp4_size2',
    'size2'
  ),
  Image.new(
    'frames6',
    'height4',
    'mp46',
    'mp4_size8',
    'size8'
  ),
  Image.new(
    'frames2',
    'height0',
    'mp42',
    'mp4_size4',
    'size4'
  ),
  Image.new(
    'frames0',
    'height8',
    'mp40',
    'mp4_size2',
    'size2'
  ),
  Image.new(
    'frames4',
    'height4',
    'mp46',
    'mp4_size8',
    'size2'
  ),
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new,
  Image.new
)
```

