
# Compare

## Enumeration

`Compare`

## Fields

| Name |
|  --- |
| `GREATERTHAN` |
| `LESSTHAN` |

## Example

```php
use DigitalOceanApiLib\Models\Compare;

$compare = Compare::GREATERTHAN;
```

