
# X Amz Target 32 Enum

## Enumeration

`XAmzTarget32Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```ruby
x_amz_target32 = XAmzTarget32Enum::ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS
```

