
# Import Notebook Output

*This model accepts additional fields of type unknown.*

## Structure

`ImportNotebookOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ImportNotebookOutput } from 'amazon-athenalib';

const importNotebookOutput: ImportNotebookOutput = {
  notebookId: 'NotebookId2',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

