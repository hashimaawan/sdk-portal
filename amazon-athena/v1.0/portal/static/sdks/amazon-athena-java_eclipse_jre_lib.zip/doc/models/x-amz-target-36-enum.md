
# X Amz Target 36 Enum

## Enumeration

`XAmzTarget36Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTEXECUTORS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget36Enum;

XAmzTarget36Enum xAmzTarget36 = XAmzTarget36Enum.ENUM_AMAZONATHENALISTEXECUTORS;
```

