
# Server Public Net Firewall

*This model accepts additional fields of type array.*

## Structure

`ServerPublicNetFirewall`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | ID of the Resource | getId(): ?int | setId(?int id): void |
| `status` | [`?string(Status72)`](../../doc/models/status-72.md) | Optional | Status of the Firewall on the Server | getStatus(): ?string | setStatus(?string status): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\ServerPublicNetFirewallBuilder;
use HetznerCloudApiLib\Models\Status72;
use HetznerCloudApiLib\ApiHelper;

$serverPublicNetFirewall = ServerPublicNetFirewallBuilder::init()
    ->id(42)
    ->status(Status72::APPLIED)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

