
# Type 10

The type of the IPv4 network interface.

## Enumeration

`Type10`

## Fields

| Name |
|  --- |
| `ENUM_PUBLIC` |
| `ENUM_PRIVATE` |

## Example

```java
import com.digitalocean.api.models.Type10;

Type10 type10 = Type10.ENUM_PUBLIC;
```

