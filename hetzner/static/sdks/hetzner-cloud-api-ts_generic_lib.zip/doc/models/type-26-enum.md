
# Type 26 Enum

Type of the ISO

## Enumeration

`Type26Enum`

## Fields

| Name |
|  --- |
| `Public` |
| `Private` |

## Example

```ts
import { Type26Enum } from 'hetzner-cloud-apilib';

const type26 = Type26Enum.Public;
```

