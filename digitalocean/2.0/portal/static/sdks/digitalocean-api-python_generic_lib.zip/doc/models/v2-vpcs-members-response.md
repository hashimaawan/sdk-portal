
# V2 Vpcs Members Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2VpcsMembersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `members` | [`List[Member]`](../../doc/models/member.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.links import Links
from digitaloceanapi.models.member import Member
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.v_2_vpcs_members_response import V2VpcsMembersResponse

v_2_vpcs_members_response = V2VpcsMembersResponse(
    meta=Meta(
        total=4,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    members=[
        Member(
            created_at='2020-03-13T19:30:48Z',
            name='nyc1-load-balancer-01',
            urn='do:loadbalancer:fb294d78-d193-4cb2-8737-ea620993591b',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Member(
            created_at='2020-03-13T19:30:18Z',
            name='db-postgresql-nyc1-55986',
            urn='do:dbaas:13f7a2f6-43df-4c4a-8129-8733267ddeea',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Member(
            created_at='2020-03-13T19:30:16Z',
            name='k8s-nyc1-1584127772221',
            urn='do:kubernetes:da39d893-96e1-4e4d-971d-1fdda33a46b1',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Member(
            created_at='2020-03-13T19:29:20Z',
            name='ubuntu-s-1vcpu-1gb-nyc1-01',
            urn='do:droplet:86e29982-03a7-4946-8a07-a0114dff8754',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    links=Links(
        pages=Pages(
            last='last6',
            next='next2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

