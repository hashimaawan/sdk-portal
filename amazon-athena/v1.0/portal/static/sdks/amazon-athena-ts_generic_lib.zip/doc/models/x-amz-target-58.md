
# X Amz Target 58

## Enumeration

`XAmzTarget58`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdatePreparedStatement` |

## Example

```ts
import { XAmzTarget58 } from 'amazon-athenalib';

const xAmzTarget58 = XAmzTarget58.EnumAmazonAthenaUpdatePreparedStatement;
```

