
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Resource |
| `mtype` | `str` | Required | Type of resource referenced |

## Example

```python
from hetznercloudapi.models.resource import Resource

resource = Resource(
    id=42,
    mtype='server'
)
```

