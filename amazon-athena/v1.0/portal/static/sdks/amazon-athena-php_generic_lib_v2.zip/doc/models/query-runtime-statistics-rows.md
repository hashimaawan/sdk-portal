
# Query Runtime Statistics Rows

Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query.

## Structure

`QueryRuntimeStatisticsRows`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `inputRows` | `?int` | Optional | - | getInputRows(): ?int | setInputRows(?int inputRows): void |
| `inputBytes` | `?int` | Optional | - | getInputBytes(): ?int | setInputBytes(?int inputBytes): void |
| `outputBytes` | `?int` | Optional | - | getOutputBytes(): ?int | setOutputBytes(?int outputBytes): void |
| `outputRows` | `?int` | Optional | - | getOutputRows(): ?int | setOutputRows(?int outputRows): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\QueryRuntimeStatisticsRowsBuilder;

$queryRuntimeStatisticsRows = QueryRuntimeStatisticsRowsBuilder::init()
    ->inputRows(234)
    ->inputBytes(254)
    ->outputBytes(40)
    ->outputRows(226)
    ->build();
```

