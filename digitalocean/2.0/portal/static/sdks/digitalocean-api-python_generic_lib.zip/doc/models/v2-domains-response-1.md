
# V2 Domains Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DomainsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `domain` | [`Domain1`](../../doc/models/domain-1.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.domain_1 import Domain1
from digitaloceanapi.models.v_2_domains_response_1 import V2DomainsResponse1

v_2_domains_response_1 = V2DomainsResponse1(
    domain=Domain1(
        ip_address='ip_address6',
        name='example.com',
        ttl=1800,
        zone_file=None,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

