
# V2 Vpcs Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2VpcsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpcs` | [`Array[Vpc]`](../../doc/models/vpc.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_vpcs_response = V2VpcsResponse.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  vpcs: [
    Vpc.new(
      description: 'description8',
      name: 'name2',
      ip_range: 'ip_range4',
      region: 'region8',
      default: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Vpc.new(
      description: 'description8',
      name: 'name2',
      ip_range: 'ip_range4',
      region: 'region8',
      default: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

