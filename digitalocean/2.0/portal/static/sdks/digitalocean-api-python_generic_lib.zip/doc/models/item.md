
# Item

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Item`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `str` | Optional | Amount of the charge |
| `count` | `str` | Optional | Number of times the charge was applied |
| `name` | `str` | Optional | Description of the charge |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.item import Item

item = Item(
    amount='10.00',
    count='1',
    name='Spaces Subscription',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

