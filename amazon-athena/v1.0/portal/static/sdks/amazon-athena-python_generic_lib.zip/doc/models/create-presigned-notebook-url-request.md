
# Create Presigned Notebook Url Request

*This model accepts additional fields of type Any.*

## Structure

`CreatePresignedNotebookUrlRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.create_presigned_notebook_url_request import CreatePresignedNotebookUrlRequest

create_presigned_notebook_url_request = CreatePresignedNotebookUrlRequest(
    session_id='SessionId4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

