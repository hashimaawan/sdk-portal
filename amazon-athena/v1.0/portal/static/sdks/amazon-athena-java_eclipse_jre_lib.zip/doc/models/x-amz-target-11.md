
# X Amz Target 11

## Enumeration

`XAmzTarget11`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget11;

XAmzTarget11 xAmzTarget11 = XAmzTarget11.ENUM_AMAZONATHENADELETENOTEBOOK;
```

