
# Protection 20

Protection configuration for the Server

## Structure

`Protection20`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Required | If true, prevents the Server from being deleted |
| `rebuild` | `TrueClass \| FalseClass` | Required | If true, prevents the Server from being rebuilt |

## Example

```ruby
protection20 = Protection20.new(
  false,
  false
)
```

