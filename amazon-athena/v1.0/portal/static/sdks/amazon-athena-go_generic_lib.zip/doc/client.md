
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| region | `models.Region` | The AWS region<br>*Default*: `"us-east-1"` |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| customHeaderAuthenticationCredentials | [`CustomHeaderAuthenticationCredentials`](auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
package main

import (
    "amazonAthena"
)

func main() {
    client := amazonAthena.NewClient(
    amazonAthena.CreateConfiguration(
            amazonAthena.WithHttpConfiguration(
                amazonAthena.CreateHttpConfiguration(
                    amazonAthena.WithTimeout(30),
                ),
            ),
            amazonAthena.WithEnvironment(amazonAthena.PRODUCTION),
            amazonAthena.WithCustomHeaderAuthenticationCredentials(
                amazonAthena.NewCustomHeaderAuthenticationCredentials("Authorization"),
            ),
            amazonAthena.WithRegion("us-east-1"),
            amazonAthena.WithLoggerConfiguration(
                amazonAthena.WithLevel("info"),
                amazonAthena.WithRequestConfiguration(
                    amazonAthena.WithRequestBody(true),
                ),
                amazonAthena.WithResponseConfiguration(
                    amazonAthena.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Amazon Athena Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| Api() | Gets Api |

