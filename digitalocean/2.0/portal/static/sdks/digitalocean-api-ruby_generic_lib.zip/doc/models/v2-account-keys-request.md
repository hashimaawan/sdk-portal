
# V2 Account Keys Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AccountKeysRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | A human-readable display name for this key, used to easily identify the SSH keys when they are displayed. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_account_keys_request = V2AccountKeysRequest.new(
  name: 'My SSH Public Key',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

