
# Price 9

## Structure

`Price9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Location` | `string` | Required | Name of the Location the price is for |
| `PriceHourly` | [`PriceHourly8`](../../doc/models/price-hourly-8.md) | Required | Hourly costs for a Server type in this Location |
| `PriceMonthly` | [`PriceMonthly10`](../../doc/models/price-monthly-10.md) | Required | Monthly costs for a Server type in this Location |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Price9 price9 = new Price9
{
    Location = "fsn1",
    PriceHourly = new PriceHourly8
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
    },
    PriceMonthly = new PriceMonthly10
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
    },
};
```

