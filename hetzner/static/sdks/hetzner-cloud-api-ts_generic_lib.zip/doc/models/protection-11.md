
# Protection 11

Protection configuration for the Network

## Structure

`Protection11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean` | Required | If true, prevents the Network from being deleted |

## Example

```ts
import { Protection11 } from 'hetzner-cloud-apilib';

const protection11: Protection11 = {
  mDelete: false,
};
```

