Gem::Specification.new do |s|
  s.name = 'furkot_trips'
  s.version = '1.0.0'
  s.summary = 'furkot_trips'
  s.description = 'Furkot provides Rest API to access user trip data. Using Furkot API an application can list user trips and display stops for a specific trip. Furkot API uses OAuth2 protocol to authorize applications to access data on behalf of users.'
  s.authors = ['APIMatic SDK Generator']
  s.email = ['trips@furkot.com']
  s.homepage = 'https://apimatic.io'
  s.licenses = ['MIT']
  s.add_dependency('apimatic_core_interfaces', '~> 0.2.3')
  s.add_dependency('apimatic_core', '~> 0.3.20')
  s.add_dependency('apimatic_faraday_client_adapter', '~> 0.1.6')
  s.required_ruby_version = ['>= 2.6']
  s.files = Dir['{bin,lib,man,test,spec}/**/*', 'README*', 'LICENSE*']
  s.require_paths = ['lib']
end
