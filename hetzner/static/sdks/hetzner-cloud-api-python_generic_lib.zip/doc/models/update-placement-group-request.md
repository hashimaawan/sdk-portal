
# Update Placement Group Request

## Structure

`UpdatePlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Optional | New PlacementGroup name |

## Example

```python
import jsonpickle

from hetznercloudapi.models.update_placement_group_request import UpdatePlacementGroupRequest

update_placement_group_request = UpdatePlacementGroupRequest(
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    name='my Placement Group'
)
```

