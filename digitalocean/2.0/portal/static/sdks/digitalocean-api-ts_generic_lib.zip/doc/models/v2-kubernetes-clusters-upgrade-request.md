
# V2 Kubernetes Clusters Upgrade Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUpgradeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string \| undefined` | Optional | The slug identifier for the version of Kubernetes that the cluster will be upgraded to. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2KubernetesClustersUpgradeRequest } from 'digitalocean-apilib';

const v2KubernetesClustersUpgradeRequest: V2KubernetesClustersUpgradeRequest = {
  version: '1.16.13-do.0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

