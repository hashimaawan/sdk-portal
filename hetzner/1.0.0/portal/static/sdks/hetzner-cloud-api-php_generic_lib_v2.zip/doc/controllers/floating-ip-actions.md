# Floating IP Actions

```php
$floatingIPActionsController = $client->getFloatingIPActionsController();
```

## Class Name

`FloatingIPActionsController`

## Methods

* [Get All Actions for a Floating IP](../../doc/controllers/floating-ip-actions.md#get-all-actions-for-a-floating-ip)
* [Assign a Floating IP to a Server](../../doc/controllers/floating-ip-actions.md#assign-a-floating-ip-to-a-server)
* [Change Reverse DNS Entry for a Floating IP](../../doc/controllers/floating-ip-actions.md#change-reverse-dns-entry-for-a-floating-ip)
* [Change Floating IP Protection](../../doc/controllers/floating-ip-actions.md#change-floating-ip-protection)
* [Unassign a Floating IP](../../doc/controllers/floating-ip-actions.md#unassign-a-floating-ip)
* [Get an Action for a Floating IP](../../doc/controllers/floating-ip-actions.md#get-an-action-for-a-floating-ip)


# Get All Actions for a Floating IP

Returns all Action objects for a Floating IP. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```php
function getAllActionsForAFloatingIP(
    int $id,
    ?string $sort = null,
    ?string $status = null
): FloatingIpsActionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `sort` | [`?string(ParameterSortEnum)`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`?string(ParameterStatusEnum)`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`FloatingIpsActionsResponse`](../../doc/models/floating-ips-actions-response.md)

## Example Usage

```php
$id = 112;

$floatingIPActionsController = $client->getFloatingIPActionsController();

try {
    $result = $floatingIPActionsController->getAllActionsForAFloatingIP($id);
    echo 'FloatingIpsActionsResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "assign_floating_ip",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 4711,
          "type": "server"
        },
        {
          "id": 4712,
          "type": "floating_ip"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Assign a Floating IP to a Server

Assigns a Floating IP to a Server.

```php
function assignAFloatingIPToAServer(int $id, ?AssignFloatingIPRequest $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `body` | [`?AssignFloatingIPRequest`](../../doc/models/assign-floating-ip-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `assign` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = AssignFloatingIPRequestBuilder::init(
    42
)->build();

$floatingIPActionsController = $client->getFloatingIPActionsController();

try {
    $result = $floatingIPActionsController->assignAFloatingIPToAServer(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "assign_floating_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Reverse DNS Entry for a Floating IP

Changes the hostname that will appear when getting the hostname belonging to this Floating IP.

```php
function changeReverseDNSEntryForAFloatingIP(int $id, ?ChangeDNSPTRRequest $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `body` | [`?ChangeDNSPTRRequest`](../../doc/models/change-dnsptr-request.md) | Body, Optional | Select the IP address for which to change the DNS entry by passing `ip`. For a Floating IP of type `ipv4` this must exactly match the IP address of the Floating IP. For a Floating IP of type `ipv6` this must be a single IP within the IPv6 /64 range that belongs to this Floating IP.<br><br>The target hostname is set by passing `dns_ptr`. |

## Response Type

**201**: The `action` key contains the `change_dns_ptr` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = ChangeDNSPTRRequestBuilder::init(
    '1.2.3.4'
)
    ->dnsPtr('server02.example.com')
    ->build();

$floatingIPActionsController = $client->getFloatingIPActionsController();

try {
    $result = $floatingIPActionsController->changeReverseDNSEntryForAFloatingIP(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_dns_ptr",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Floating IP Protection

Changes the protection configuration of the Floating IP.

```php
function changeFloatingIPProtection(int $id, ?ChangeProtectionRequest $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `body` | [`?ChangeProtectionRequest`](../../doc/models/change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = ChangeProtectionRequestBuilder::init()
    ->delete(true)
    ->build();

$floatingIPActionsController = $client->getFloatingIPActionsController();

try {
    $result = $floatingIPActionsController->changeFloatingIPProtection(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Unassign a Floating IP

Unassigns a Floating IP, resulting in it being unreachable. You may assign it to a Server again at a later time.

```php
function unassignAFloatingIP(int $id): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |

## Response Type

**201**: The `action` key contains the `unassign` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$floatingIPActionsController = $client->getFloatingIPActionsController();

try {
    $result = $floatingIPActionsController->unassignAFloatingIP($id);
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "unassign_floating_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for a Floating IP

Returns a specific Action object for a Floating IP.

```php
function getAnActionForAFloatingIP(int $id, int $actionId): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key in the reply has this structure

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$actionId = 224;

$floatingIPActionsController = $client->getFloatingIPActionsController();

try {
    $result = $floatingIPActionsController->getAnActionForAFloatingIP(
        $id,
        $actionId
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "assign_floating_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

