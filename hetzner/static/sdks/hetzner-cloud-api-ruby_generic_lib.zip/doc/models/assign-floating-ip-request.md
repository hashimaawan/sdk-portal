
# Assign Floating IP Request

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `floating_ip_assigned`        | The floating IP is already assigned                           |

## Structure

`AssignFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server` | `Integer` | Required | ID of the Server the Floating IP shall be assigned to |

## Example

```ruby
assign_floating_ip_request = AssignFloatingIPRequest.new(
  42
)
```

