
# Get Named Query Output

## Structure

`GetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namedQuery` | [`NamedQuery1 \| undefined`](../../doc/models/named-query-1.md) | Optional | - |

## Example

```ts
import { GetNamedQueryOutput } from 'amazon-athenalib';

const getNamedQueryOutput: GetNamedQueryOutput = {
  namedQuery: {
    name: 'Name0',
    database: 'Database8',
    queryString: 'QueryString2',
    description: 'Description6',
    namedQueryId: 'NamedQueryId2',
    workGroup: 'WorkGroup2',
  },
};
```

