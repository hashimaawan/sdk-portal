
# Load Balancer Type 6

## Structure

`LoadBalancerType6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `double` | Required | ID of the Load Balancer type the price is for |
| `Name` | `string` | Required | Name of the Load Balancer type the price is for |
| `Prices` | [`List<Price7>`](../../doc/models/price-7.md) | Required | Load Balancer type costs per Location |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

LoadBalancerType6 loadBalancerType6 = new LoadBalancerType6
{
    Id = 1,
    Name = "lb11",
    Prices = new List<Price7>
    {
        new Price7
        {
            Location = "fsn1",
            PriceHourly = new PriceHourly6
            {
                Gross = "1.1900000000000000",
                Net = "1.0000000000",
            },
            PriceMonthly = new PriceMonthly8
            {
                Gross = "1.1900000000000000",
                Net = "1.0000000000",
            },
        },
    },
};
```

