
# V2 Kubernetes Clusters User Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUserResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kubernetes_cluster_user` | [`KubernetesClusterUser`](../../doc/models/kubernetes-cluster-user.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.kubernetes_cluster_user import KubernetesClusterUser
from digitaloceanapi.models.v_2_kubernetes_clusters_user_response import V2KubernetesClustersUserResponse

v_2_kubernetes_clusters_user_response = V2KubernetesClustersUserResponse(
    kubernetes_cluster_user=KubernetesClusterUser(
        groups=[
            'groups8'
        ],
        username='username6',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

