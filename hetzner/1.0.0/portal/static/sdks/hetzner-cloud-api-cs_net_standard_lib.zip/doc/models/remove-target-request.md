
# Remove Target Request

## Structure

`RemoveTargetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Ip` | [`Ip`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. |
| `LabelSelector` | [`LabelSelector12`](../../doc/models/label-selector-12.md) | Optional | Configuration for label selector targets, required if type is `label_selector` |
| `Server` | [`Server16`](../../doc/models/server-16.md) | Optional | Configuration for type Server, required if type is `server` |
| `Type` | [`Type29Enum`](../../doc/models/type-29-enum.md) | Required | Type of the resource |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

RemoveTargetRequest removeTargetRequest = new RemoveTargetRequest
{
    Type = Type29Enum.Ip,
    Ip = new Ip
    {
        Ip = "ip8",
    },
    LabelSelector = new LabelSelector12
    {
        Selector = "selector8",
    },
    Server = new Server16
    {
        Id = 217.74,
    },
};
```

