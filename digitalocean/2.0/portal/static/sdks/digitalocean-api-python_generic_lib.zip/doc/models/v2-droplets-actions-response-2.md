
# V2 Droplets Actions Response 2

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DropletsActionsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action`](../../doc/models/action.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.action import Action
from digitaloceanapi.models.region import Region
from digitaloceanapi.models.v_2_droplets_actions_response_2 import V2DropletsActionsResponse2

v_2_droplets_actions_response_2 = V2DropletsActionsResponse2(
    action=Action(
        completed_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
        id=238,
        region=Region(
            available=False,
            features=[
                'features7',
                'features8',
                'features9'
            ],
            name='name6',
            sizes=[
                'sizes6'
            ],
            slug='slug0',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        region_slug='region_slug0',
        resource_id=66,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

