
# Playlists Followers Request

*This model accepts additional fields of type object.*

## Structure

`PlaylistsFollowersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Public` | `bool?` | Optional | Defaults to `true`. If `true` the playlist will be included in user's public playlists, if `false` it will remain private. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Utilities;

PlaylistsFollowersRequest playlistsFollowersRequest = new PlaylistsFollowersRequest
{
    MPublic = false,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

