
# X Amz Target 28 Enum

## Enumeration

`XAmzTarget28Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETTABLEMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget28Enum;

XAmzTarget28Enum xAmzTarget28 = XAmzTarget28Enum.ENUM_AMAZONATHENAGETTABLEMETADATA;
```

