
# Notebook Type 2

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```python
from amazonathena.models.notebook_type_2 import NotebookType2

notebook_type_2 = NotebookType2.IPYNB
```

