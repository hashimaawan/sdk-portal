
# Type 3

The object type.

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `USER` |

## Example

```php
use SpotifyWebApiWithFixesAndImprovementsFromSonalluxLib\Models\Type3;

$type3 = Type3::USER;
```

