
# Resource Type 1

The type of resource that the snapshot originated from.

## Enumeration

`ResourceType1`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `VOLUME` |

## Example

```python
from digitaloceanapi.models.resource_type_1 import ResourceType1

resource_type_1 = ResourceType1.DROPLET
```

