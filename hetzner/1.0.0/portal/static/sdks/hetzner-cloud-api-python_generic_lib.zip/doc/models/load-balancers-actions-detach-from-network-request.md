
# Load Balancers Actions Detach from Network Request

*This model accepts additional fields of type Any.*

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `float` | Required | ID of an existing network to detach the Load Balancer from |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.load_balancers_actions_detach_from_network_request import LoadBalancersActionsDetachFromNetworkRequest

load_balancers_actions_detach_from_network_request = LoadBalancersActionsDetachFromNetworkRequest(
    network=4711,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

