
# Issuance Enum

Status of the issuance process of the Certificate

## Enumeration

`IssuanceEnum`

## Fields

| Name |
|  --- |
| `PENDING` |
| `COMPLETED` |
| `FAILED` |

## Example

```python
from hetznercloudapi.models.issuance_enum import IssuanceEnum

issuance = IssuanceEnum.FAILED
```

