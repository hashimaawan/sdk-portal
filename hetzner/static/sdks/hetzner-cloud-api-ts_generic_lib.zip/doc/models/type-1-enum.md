
# Type 1 Enum

Choose between uploading a Certificate in PEM format or requesting a managed *Let's Encrypt* Certificate. If omitted defaults to `uploaded`.

## Enumeration

`Type1Enum`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```ts
import { Type1Enum } from 'hetzner-cloud-apilib';

const type1 = Type1Enum.Uploaded;
```

