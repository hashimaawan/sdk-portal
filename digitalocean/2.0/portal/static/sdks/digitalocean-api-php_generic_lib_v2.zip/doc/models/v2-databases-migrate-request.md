
# V2 Databases Migrate Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesMigrateRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `region` | `string` | Required | A slug identifier for the region to which the database cluster will be migrated. | getRegion(): string | setRegion(string region): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesMigrateRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesMigrateRequest = V2DatabasesMigrateRequestBuilder::init(
    'lon1'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

