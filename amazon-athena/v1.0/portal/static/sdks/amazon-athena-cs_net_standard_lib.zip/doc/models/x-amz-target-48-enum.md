
# X Amz Target 48 Enum

## Enumeration

`XAmzTarget48Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartSession` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget48Enum xAmzTarget48 = XAmzTarget48Enum.EnumAmazonAthenaStartSession;
```

