
# List Query Executions Input

## Structure

`ListQueryExecutionsInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |
| `maxResults` | `?int` | Optional | **Constraints**: `>= 0`, `<= 50` | getMaxResults(): ?int | setMaxResults(?int maxResults): void |
| `workGroup` | `?string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): ?string | setWorkGroup(?string workGroup): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListQueryExecutionsInputBuilder;

$listQueryExecutionsInput = ListQueryExecutionsInputBuilder::init()
    ->nextToken('NextToken2')
    ->maxResults(34)
    ->workGroup('WorkGroup4')
    ->build();
```

