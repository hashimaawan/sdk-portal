
# X Amz Target 22 Enum

## Enumeration

`XAmzTarget22Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget22Enum;

XAmzTarget22Enum xAmzTarget22 = XAmzTarget22Enum.ENUM_AMAZONATHENAGETPREPAREDSTATEMENT;
```

