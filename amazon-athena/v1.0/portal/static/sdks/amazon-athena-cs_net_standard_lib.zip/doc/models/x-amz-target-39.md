
# X Amz Target 39

## Enumeration

`XAmzTarget39`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNotebookSessions` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget39 xAmzTarget39 = XAmzTarget39.EnumAmazonAthenaListNotebookSessions;
```

