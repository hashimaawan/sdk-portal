
# Unprocessed Prepared Statement Name

The name of a prepared statement that could not be returned.

## Structure

`UnprocessedPreparedStatementName`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StatementName` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `ErrorCode` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ErrorMessage` | `string` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

UnprocessedPreparedStatementName unprocessedPreparedStatementName = new UnprocessedPreparedStatementName
{
    StatementName = "StatementName8",
    ErrorCode = "ErrorCode6",
    ErrorMessage = "ErrorMessage6",
};
```

