
# Status

This value is one of "active", "warning" or "locked".

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `WARNING` |
| `LOCKED` |

## Example

```python
from digitaloceanapi.models.status import Status

status = Status.LOCKED
```

