
# V2 Functions Namespaces Triggers Request 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_enabled` | `bool` | Optional | Indicates weather the trigger is paused or unpaused. |
| `scheduled_details` | [`ScheduledDetails`](../../doc/models/scheduled-details.md) | Optional | Trigger details for SCHEDULED type, where body is optional. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.body import Body
from digitaloceanapi.models.scheduled_details import ScheduledDetails
from digitaloceanapi.models.v_2_functions_namespaces_triggers_request_1 import V2FunctionsNamespacesTriggersRequest1

v_2_functions_namespaces_triggers_request_1 = V2FunctionsNamespacesTriggersRequest1(
    is_enabled=True,
    scheduled_details=ScheduledDetails(
        cron='cron2',
        body=Body(
            name='name6',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

