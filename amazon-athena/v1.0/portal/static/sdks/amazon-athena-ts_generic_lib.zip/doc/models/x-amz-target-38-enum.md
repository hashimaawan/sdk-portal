
# X Amz Target 38 Enum

## Enumeration

`XAmzTarget38Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNotebookMetadata` |

## Example

```ts
import { XAmzTarget38Enum } from 'amazon-athenalib';

const xAmzTarget38 = XAmzTarget38Enum.EnumAmazonAthenaListNotebookMetadata;
```

