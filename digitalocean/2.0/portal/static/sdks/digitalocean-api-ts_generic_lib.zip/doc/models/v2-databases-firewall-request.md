
# V2 Databases Firewall Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesFirewallRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rules` | [`Rule1[] \| undefined`](../../doc/models/rule-1.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type7, V2DatabasesFirewallRequest } from 'digitalocean-apilib';

const v2DatabasesFirewallRequest: V2DatabasesFirewallRequest = {
  rules: [
    {
      type: Type7.IpAddr,
      value: 'value0',
      clusterUuid: 'cluster_uuid4',
      createdAt: '2016-03-13T12:52:32.123Z',
      uuid: 'uuid4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      type: Type7.IpAddr,
      value: 'value0',
      clusterUuid: 'cluster_uuid4',
      createdAt: '2016-03-13T12:52:32.123Z',
      uuid: 'uuid4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

