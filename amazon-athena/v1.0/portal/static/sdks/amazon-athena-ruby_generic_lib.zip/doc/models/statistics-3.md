
# Statistics 3

## Structure

`Statistics3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `Integer` | Optional | - |

## Example

```ruby
statistics3 = Statistics3.new(
  130
)
```

