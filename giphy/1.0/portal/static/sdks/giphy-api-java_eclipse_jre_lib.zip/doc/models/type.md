
# Type

Type of the gif. By default, this is almost always gif

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `GIF` |

## Example

```java
import com.giphy.api.models.Type;

Type type = Type.GIF;
```

