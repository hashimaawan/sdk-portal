
# Statement Type Enum

## Enumeration

`StatementTypeEnum`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```python
from amazonathena.models.statement_type_enum import StatementTypeEnum

statement_type = StatementTypeEnum.DDL
```

