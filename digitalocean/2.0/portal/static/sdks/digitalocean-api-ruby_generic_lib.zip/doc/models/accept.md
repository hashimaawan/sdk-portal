
# Accept

## Enumeration

`Accept`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONYAML` |

## Example

```ruby
accept = Accept::ENUM_APPLICATIONJSON
```

