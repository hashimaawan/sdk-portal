
# Servers Actions Enable Rescue Request

*This model accepts additional fields of type object.*

## Structure

`ServersActionsEnableRescueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SshKeys` | `List<int>` | Optional | Array of SSH key IDs which should be injected into the rescue system. |
| `Type` | [`Type65?`](../../doc/models/type-65.md) | Optional | Type of rescue system to boot (default: `linux64`) |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;
using System.Collections.Generic;

ServersActionsEnableRescueRequest serversActionsEnableRescueRequest = new ServersActionsEnableRescueRequest
{
    SshKeys = new List<int>
    {
        2323,
    },
    Type = Type65.Linux64,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

