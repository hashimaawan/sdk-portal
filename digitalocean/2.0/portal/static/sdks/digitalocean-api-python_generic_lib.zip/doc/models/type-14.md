
# Type 14

## Enumeration

`Type14`

## Fields

| Name |
|  --- |
| `APPLICATION` |
| `DISTRIBUTION` |

## Example

```python
from digitaloceanapi.models.type_14 import Type14

type_14 = Type14.APPLICATION
```

