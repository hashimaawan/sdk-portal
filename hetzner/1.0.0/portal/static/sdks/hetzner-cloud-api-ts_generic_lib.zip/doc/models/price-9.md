
# Price 9

*This model accepts additional fields of type unknown.*

## Structure

`Price9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location` | `string` | Required | Name of the Location the price is for |
| `priceHourly` | [`PriceHourly8`](../../doc/models/price-hourly-8.md) | Required | Hourly costs for a Server type in this Location |
| `priceMonthly` | [`PriceMonthly10`](../../doc/models/price-monthly-10.md) | Required | Monthly costs for a Server type in this Location |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Price9 } from 'hetzner-cloud-apilib';

const price9: Price9 = {
  location: 'fsn1',
  priceHourly: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  priceMonthly: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

