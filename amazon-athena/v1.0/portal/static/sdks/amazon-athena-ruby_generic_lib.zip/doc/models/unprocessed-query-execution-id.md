
# Unprocessed Query Execution Id

Describes a query execution that failed to process.

*This model accepts additional fields of type Object.*

## Structure

`UnprocessedQueryExecutionId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `error_code` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `error_message` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
unprocessed_query_execution_id = UnprocessedQueryExecutionId.new(
  query_execution_id: 'QueryExecutionId8',
  error_code: 'ErrorCode4',
  error_message: 'ErrorMessage6',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

