
# Engine

- MYSQL: MySQL
- PG: PostgreSQL
- REDIS: Redis

## Enumeration

`Engine`

## Fields

| Name |
|  --- |
| `Unset` |
| `Mysql` |
| `Pg` |
| `Redis` |

## Example

```ts
import { Engine } from 'digitalocean-apilib';

const engine = Engine.Pg;
```

