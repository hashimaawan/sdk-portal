
# Cpu Type Enum

Type of cpu

## Enumeration

`CpuTypeEnum`

## Fields

| Name |
|  --- |
| `Shared` |
| `Dedicated` |

## Example

```ts
import { CpuTypeEnum } from 'hetzner-cloud-apilib';

const cpuType = CpuTypeEnum.Shared;
```

