
# Status Enum

Status of the Action

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ERROR` |

## Example

```ruby
status = StatusEnum::ERROR
```

