# SSH Keys

```python
ssh_keys_controller = client.ssh_keys
```

## Class Name

`SSHKeysController`

## Methods

* [Get All SSH Keys](../../doc/controllers/ssh-keys.md#get-all-ssh-keys)
* [Create an SSH Key](../../doc/controllers/ssh-keys.md#create-an-ssh-key)
* [Delete an SSH Key](../../doc/controllers/ssh-keys.md#delete-an-ssh-key)
* [Get a SSH Key](../../doc/controllers/ssh-keys.md#get-a-ssh-key)
* [Update an SSH Key](../../doc/controllers/ssh-keys.md#update-an-ssh-key)


# Get All SSH Keys

Returns all SSH key objects.

```python
def get_all_ssh_keys(self,
                    sort=None,
                    name=None,
                    fingerprint=None,
                    label_selector=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`Sort8Enum`](../../doc/models/sort-8-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `str` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `fingerprint` | `str` | Query, Optional | Can be used to filter SSH keys by their fingerprint. The response will only contain the SSH key matching the specified fingerprint. |
| `label_selector` | `str` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `ssh_keys` key in the reply contains an array of SSH key objects with this structure

[`SshKeysResponse`](../../doc/models/ssh-keys-response.md)

## Example Usage

```python
result = ssh_keys_controller.get_all_ssh_keys()
print(result)
```


# Create an SSH Key

Creates a new SSH key with the given `name` and `public_key`. Once an SSH key is created, it can be used in other calls such as creating Servers.

```python
def create_an_ssh_key(self,
                     body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SshKeysRequest`](../../doc/models/ssh-keys-request.md) | Body, Optional | - |

## Response Type

**201**: The `ssh_key` key in the reply contains the object that was just created

[`SshKeysResponse1`](../../doc/models/ssh-keys-response-1.md)

## Example Usage

```python
body = SshKeysRequest(
    name='My ssh key',
    public_key='ssh-rsa AAAjjk76kgf...Xt'
)

result = ssh_keys_controller.create_an_ssh_key(
    body=body
)
print(result)
```


# Delete an SSH Key

Deletes an SSH key. It cannot be used anymore.

```python
def delete_an_ssh_key(self,
                     id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Template, Required | ID of the SSH key |

## Response Type

**204**: SSH key deleted

`void`

## Example Usage

```python
id = 'id0'

ssh_keys_controller.delete_an_ssh_key(id)
```


# Get a SSH Key

Returns a specific SSH key object.

```python
def get_a_ssh_key(self,
                 id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the SSH key |

## Response Type

**200**: The `ssh_key` key in the reply contains an SSH key object with this structure

[`SshKeysResponse1`](../../doc/models/ssh-keys-response-1.md)

## Example Usage

```python
id = 112

result = ssh_keys_controller.get_a_ssh_key(id)
print(result)
```


# Update an SSH Key

Updates an SSH key. You can update an SSH key name and an SSH key labels.

Please note that when updating labels, the SSH key current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```python
def update_an_ssh_key(self,
                     id,
                     body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Template, Required | ID of the SSH key |
| `body` | [`SshKeysRequest1`](../../doc/models/ssh-keys-request-1.md) | Body, Optional | - |

## Response Type

**200**: The `ssh_key` key in the reply contains the modified SSH key object with the new description

[`SshKeysResponse1`](../../doc/models/ssh-keys-response-1.md)

## Example Usage

```python
id = 'id0'

body = SshKeysRequest1(
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    name='My ssh key'
)

result = ssh_keys_controller.update_an_ssh_key(
    id,
    body=body
)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "ssh_key": {
    "created": "2016-01-30T23:50:00+00:00",
    "fingerprint": "b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f",
    "id": 2323,
    "labels": {
      "labelkey": "value"
    },
    "name": "My ssh key",
    "public_key": "ssh-rsa AAAjjk76kgf...Xt"
  }
}
```

