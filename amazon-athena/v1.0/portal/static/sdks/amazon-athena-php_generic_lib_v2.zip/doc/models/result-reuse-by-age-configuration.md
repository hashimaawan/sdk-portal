
# Result Reuse by Age Configuration

Specifies whether previous query results are reused, and if so, their maximum age.

## Structure

`ResultReuseByAgeConfiguration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `enabled` | `bool` | Required | - | getEnabled(): bool | setEnabled(bool enabled): void |
| `maxAgeInMinutes` | `?int` | Optional | **Constraints**: `>= 0`, `<= 10080` | getMaxAgeInMinutes(): ?int | setMaxAgeInMinutes(?int maxAgeInMinutes): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultReuseByAgeConfigurationBuilder;

$resultReuseByAgeConfiguration = ResultReuseByAgeConfigurationBuilder::init(
    false
)
    ->maxAgeInMinutes(134)
    ->build();
```

