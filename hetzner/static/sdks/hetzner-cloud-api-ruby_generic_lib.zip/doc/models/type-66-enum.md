
# Type 66 Enum

## Enumeration

`Type66Enum`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```ruby
type66 = Type66Enum::NETWORK
```

