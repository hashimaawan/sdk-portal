
# Delete Subnet Request

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip_range` | `String` | Required | IP range of subnet to delete |

## Example

```ruby
delete_subnet_request = DeleteSubnetRequest.new(
  '10.0.1.0/24'
)
```

