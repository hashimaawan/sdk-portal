
# Query Execution

Information about a single instance of a query execution.

*This model accepts additional fields of type array.*

## Structure

`QueryExecution`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `queryExecutionId` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getQueryExecutionId(): ?string | setQueryExecutionId(?string queryExecutionId): void |
| `query` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` | getQuery(): ?string | setQuery(?string query): void |
| `statementType` | [`?string(StatementType1)`](../../doc/models/statement-type-1.md) | Optional | - | getStatementType(): ?string | setStatementType(?string statementType): void |
| `resultConfiguration` | [`?ResultConfiguration1`](../../doc/models/result-configuration-1.md) | Optional | - | getResultConfiguration(): ?ResultConfiguration1 | setResultConfiguration(?ResultConfiguration1 resultConfiguration): void |
| `resultReuseConfiguration` | [`?ResultReuseConfiguration1`](../../doc/models/result-reuse-configuration-1.md) | Optional | - | getResultReuseConfiguration(): ?ResultReuseConfiguration1 | setResultReuseConfiguration(?ResultReuseConfiguration1 resultReuseConfiguration): void |
| `queryExecutionContext` | [`?QueryExecutionContext1`](../../doc/models/query-execution-context-1.md) | Optional | - | getQueryExecutionContext(): ?QueryExecutionContext1 | setQueryExecutionContext(?QueryExecutionContext1 queryExecutionContext): void |
| `status` | [`?Status`](../../doc/models/status.md) | Optional | - | getStatus(): ?Status | setStatus(?Status status): void |
| `statistics` | [`?Statistics`](../../doc/models/statistics.md) | Optional | - | getStatistics(): ?Statistics | setStatistics(?Statistics statistics): void |
| `workGroup` | `?string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): ?string | setWorkGroup(?string workGroup): void |
| `engineVersion` | [`?EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - | getEngineVersion(): ?EngineVersion1 | setEngineVersion(?EngineVersion1 engineVersion): void |
| `executionParameters` | `?(string[])` | Optional | **Constraints**: *Minimum Items*: `1`, *Minimum Length*: `1`, *Maximum Length*: `1024` | getExecutionParameters(): ?array | setExecutionParameters(?array executionParameters): void |
| `substatementType` | `?string` | Optional | - | getSubstatementType(): ?string | setSubstatementType(?string substatementType): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\QueryExecutionBuilder;
use AmazonAthenaLib\Models\StatementType1;
use AmazonAthenaLib\Models\Builders\ResultConfiguration1Builder;
use AmazonAthenaLib\Models\Builders\EncryptionConfiguration2Builder;
use AmazonAthenaLib\Models\EncryptionOption1;
use AmazonAthenaLib\ApiHelper;
use AmazonAthenaLib\Models\Builders\AclConfiguration1Builder;
use AmazonAthenaLib\Models\S3AclOption1;
use AmazonAthenaLib\Models\Builders\ResultReuseConfiguration1Builder;
use AmazonAthenaLib\Models\Builders\ResultReuseByAgeConfiguration2Builder;

$queryExecution = QueryExecutionBuilder::init()
    ->queryExecutionId('QueryExecutionId4')
    ->query('Query2')
    ->statementType(StatementType1::DML)
    ->resultConfiguration(
        ResultConfiguration1Builder::init()
            ->outputLocation('OutputLocation0')
            ->encryptionConfiguration(
                EncryptionConfiguration2Builder::init(
                    EncryptionOption1::SSE_S3
                )
                    ->kmsKey('KmsKey6')
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->expectedBucketOwner('ExpectedBucketOwner0')
            ->aclConfiguration(
                AclConfiguration1Builder::init(
                    S3AclOption1::BUCKET_OWNER_FULL_CONTROL
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->resultReuseConfiguration(
        ResultReuseConfiguration1Builder::init()
            ->resultReuseByAgeConfiguration(
                ResultReuseByAgeConfiguration2Builder::init(
                    false
                )
                    ->maxAgeInMinutes(26)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

