
# Region 4

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Region4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | A DigitalOcean region where Kubernetes is available. |
| `slug` | `str` | Optional | The identifier for a region for use when creating a new cluster. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.region_4 import Region4

region_4 = Region4(
    name='New York 3',
    slug='nyc3',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

