
# Column Nullable

## Enumeration

`ColumnNullable`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```php
use AmazonAthenaLib\Models\ColumnNullable;

$columnNullable = ColumnNullable::NOT_NULL;
```

