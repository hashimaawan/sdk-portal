
# Column Info

Information about the columns in a query execution result.

## Structure

`ColumnInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `catalogName` | `?string` | Optional | - | getCatalogName(): ?string | setCatalogName(?string catalogName): void |
| `schemaName` | `?string` | Optional | - | getSchemaName(): ?string | setSchemaName(?string schemaName): void |
| `tableName` | `?string` | Optional | - | getTableName(): ?string | setTableName(?string tableName): void |
| `name` | `string` | Required | - | getName(): string | setName(string name): void |
| `label` | `?string` | Optional | - | getLabel(): ?string | setLabel(?string label): void |
| `type` | `string` | Required | - | getType(): string | setType(string type): void |
| `precision` | `?int` | Optional | - | getPrecision(): ?int | setPrecision(?int precision): void |
| `scale` | `?int` | Optional | - | getScale(): ?int | setScale(?int scale): void |
| `nullable` | [`?string(ColumnNullable2Enum)`](../../doc/models/column-nullable-2-enum.md) | Optional | - | getNullable(): ?string | setNullable(?string nullable): void |
| `caseSensitive` | `?bool` | Optional | - | getCaseSensitive(): ?bool | setCaseSensitive(?bool caseSensitive): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ColumnInfoBuilder;

$columnInfo = ColumnInfoBuilder::init(
    'Name8',
    'Type8'
)
    ->catalogName('CatalogName2')
    ->schemaName('SchemaName2')
    ->tableName('TableName4')
    ->label('Label6')
    ->precision(196)
    ->build();
```

