
# V2 Reports Droplet Neighbors Ids Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ReportsDropletNeighborsIdsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `neighborIds` | `number[] \| undefined` | Optional | An array of arrays. Each array will contain a set of Droplet IDs for Droplets that share a physical server. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2ReportsDropletNeighborsIdsResponse } from 'digitalocean-apilib';

const v2ReportsDropletNeighborsIdsResponse: V2ReportsDropletNeighborsIdsResponse = {
  neighborIds: [
    168671828168663509168671815,
    168671883168671750
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

