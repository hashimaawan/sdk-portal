
# Engine Version

The Athena engine version for running queries, or the PySpark engine version for running sessions.

## Structure

`EngineVersion`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selected_engine_version` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `effective_engine_version` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```python
from amazonathena.models.engine_version import EngineVersion

engine_version = EngineVersion(
    selected_engine_version='SelectedEngineVersion4',
    effective_engine_version='EffectiveEngineVersion4'
)
```

