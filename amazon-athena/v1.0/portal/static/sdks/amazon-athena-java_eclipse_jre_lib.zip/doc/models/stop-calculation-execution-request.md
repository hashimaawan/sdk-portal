
# Stop Calculation Execution Request

## Structure

`StopCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CalculationExecutionId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | String getCalculationExecutionId() | setCalculationExecutionId(String calculationExecutionId) |

## Example

```java
import com.amazonaws.useast1.athena.models.StopCalculationExecutionRequest;

StopCalculationExecutionRequest stopCalculationExecutionRequest = new StopCalculationExecutionRequest.Builder(
    "CalculationExecutionId2"
)
.build();
```

