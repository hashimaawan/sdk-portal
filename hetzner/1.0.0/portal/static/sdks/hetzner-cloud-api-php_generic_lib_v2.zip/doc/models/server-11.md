
# Server 11

## Structure

`Server11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Server | getId(): int | setId(int id): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\Server11Builder;

$server11 = Server11Builder::init(
    85
)->build();
```

