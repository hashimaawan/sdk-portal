
# List Tags for Resource Output

*This model accepts additional fields of type interface{}.*

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Tags` | [`[]models.Tag`](../../doc/models/tag.md) | Optional | - |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    listTagsForResourceOutput := models.ListTagsForResourceOutput{
        Tags:                  []models.Tag{
            models.Tag{
                Key:                   models.ToPointer("Key0"),
                Value:                 models.ToPointer("Value6"),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            models.Tag{
                Key:                   models.ToPointer("Key0"),
                Value:                 models.ToPointer("Value6"),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            models.Tag{
                Key:                   models.ToPointer("Key0"),
                Value:                 models.ToPointer("Value6"),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        NextToken:             models.ToPointer("NextToken4"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

