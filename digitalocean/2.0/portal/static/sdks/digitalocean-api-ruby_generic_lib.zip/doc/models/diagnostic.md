
# Diagnostic

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Diagnostic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_name` | `String` | Optional | The clusterlint check that resulted in the diagnostic. |
| `message` | `String` | Optional | Feedback about the object for users to fix. |
| `object` | [`Object`](../../doc/models/object.md) | Optional | Metadata about the Kubernetes API object the diagnostic is reported on. |
| `severity` | `String` | Optional | Can be one of error, warning or suggestion. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
diagnostic = Diagnostic.new(
  check_name: 'unused-config-map',
  message: 'Unused config map',
  object: Object.new(
    kind: 'kind0',
    name: 'name2',
    namespace: 'namespace0',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  severity: 'warning',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

