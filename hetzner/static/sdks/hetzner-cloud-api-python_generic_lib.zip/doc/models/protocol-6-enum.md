
# Protocol 6 Enum

Type of the health check

## Enumeration

`Protocol6Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |

## Example

```python
from hetznercloudapi.models.protocol_6_enum import Protocol6Enum

protocol_6 = Protocol6Enum.TCP
```

