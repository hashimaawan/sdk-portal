
# Type 16

Type of the Floating IP

## Enumeration

`Type16`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type16 } from 'hetzner-cloud-apilib';

const type16 = Type16.Ipv4;
```

