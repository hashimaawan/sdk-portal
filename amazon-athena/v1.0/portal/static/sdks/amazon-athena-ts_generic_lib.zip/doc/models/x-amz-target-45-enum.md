
# X Amz Target 45 Enum

## Enumeration

`XAmzTarget45Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListWorkGroups` |

## Example

```ts
import { XAmzTarget45Enum } from 'amazon-athenalib';

const xAmzTarget45 = XAmzTarget45Enum.EnumAmazonAthenaListWorkGroups;
```

