
# Protocol 7

Protocol of the Load Balancer

## Enumeration

`Protocol7`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```java
import cloud.hetzner.api.models.Protocol7;

Protocol7 protocol7 = Protocol7.HTTP;
```

