
# X Amz Target 59

## Enumeration

`XAmzTarget59`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEWORKGROUP` |

## Example

```python
from amazonathena.models.x_amz_target_59 import XAmzTarget59

x_amz_target_59 = XAmzTarget59.ENUM_AMAZONATHENAUPDATEWORKGROUP
```

