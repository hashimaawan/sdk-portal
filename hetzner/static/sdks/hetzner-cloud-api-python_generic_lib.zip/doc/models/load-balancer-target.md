
# Load Balancer Target

## Structure

`LoadBalancerTarget`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `health_status` | [`List[HealthStatus]`](../../doc/models/health-status.md) | Optional | List of health statuses of the services on this target |
| `ip` | [`Ip`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. |
| `label_selector` | [`LabelSelector7`](../../doc/models/label-selector-7.md) | Optional | Label selector and a list of selected targets |
| `server` | [`LoadBalancerTargetServer`](../../doc/models/load-balancer-target-server.md) | Optional | Server where the traffic should be routed through |
| `targets` | [`List[Target]`](../../doc/models/target.md) | Optional | List of selected targets |
| `mtype` | [`Type29Enum`](../../doc/models/type-29-enum.md) | Required | Type of the resource |
| `use_private_ip` | `bool` | Optional | Use the private network IP instead of the public IP. Default value is false. |

## Example

```python
from hetznercloudapi.models.health_status import HealthStatus
from hetznercloudapi.models.ip import Ip
from hetznercloudapi.models.label_selector_7 import LabelSelector7
from hetznercloudapi.models.load_balancer_target import LoadBalancerTarget
from hetznercloudapi.models.load_balancer_target_server import LoadBalancerTargetServer
from hetznercloudapi.models.server_11 import Server11
from hetznercloudapi.models.status_30_enum import Status30Enum
from hetznercloudapi.models.target import Target
from hetznercloudapi.models.type_29_enum import Type29Enum

load_balancer_target = LoadBalancerTarget(
    mtype=Type29Enum.SERVER,
    health_status=[
        HealthStatus(
            listen_port=142,
            status=Status30Enum.UNKNOWN
        ),
        HealthStatus(
            listen_port=142,
            status=Status30Enum.UNKNOWN
        ),
        HealthStatus(
            listen_port=142,
            status=Status30Enum.UNKNOWN
        )
    ],
    ip=Ip(
        ip='ip8'
    ),
    label_selector=LabelSelector7(
        selector='selector8'
    ),
    server=LoadBalancerTargetServer(
        id=14
    ),
    targets=[
        Target(
            health_status=[
                HealthStatus(
                    listen_port=142,
                    status=Status30Enum.UNKNOWN
                ),
                HealthStatus(
                    listen_port=142,
                    status=Status30Enum.UNKNOWN
                )
            ],
            server=Server11(
                id=14
            ),
            mtype='type2',
            use_private_ip=False
        )
    ]
)
```

