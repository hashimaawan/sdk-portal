
# Notebook Type 1

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```java
import com.amazonaws.useast1.athena.models.NotebookType1;

NotebookType1 notebookType1 = NotebookType1.IPYNB;
```

