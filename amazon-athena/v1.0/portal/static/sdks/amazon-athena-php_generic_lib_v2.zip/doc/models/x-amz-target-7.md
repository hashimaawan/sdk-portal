
# X Amz Target 7

## Enumeration

`XAmzTarget7`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget7;

$xAmzTarget7 = XAmzTarget7::ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL;
```

