
# Load Balancers Actions Change Algorithm Request

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type39Enum)`](../../doc/models/type-39-enum.md) | Required | Algorithm of the Load Balancer | getType(): string | setType(string type): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LoadBalancersActionsChangeAlgorithmRequestBuilder;
use HetznerCloudAPILib\Models\Type39Enum;

$loadBalancersActionsChangeAlgorithmRequest = LoadBalancersActionsChangeAlgorithmRequestBuilder::init(
    Type39Enum::ROUND_ROBIN
)->build();
```

