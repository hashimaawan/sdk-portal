
# X Amz Target 48 Enum

## Enumeration

`XAmzTarget48Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENASTARTSESSION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget48 := models.XAmzTarget48Enum_ENUMAMAZONATHENASTARTSESSION

}
```

