
# V2 Databases Users Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `users` | [`User[] \| undefined`](../../doc/models/user.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  AuthPlugin,
  Role,
  V2DatabasesUsersResponse,
} from 'digitalocean-apilib';

const v2DatabasesUsersResponse: V2DatabasesUsersResponse = {
  users: [
    {
      name: 'name6',
      mysqlSettings: {
        authPlugin: AuthPlugin.MysqlNativePassword,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      password: 'password0',
      role: Role.Primary,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      name: 'name6',
      mysqlSettings: {
        authPlugin: AuthPlugin.MysqlNativePassword,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      password: 'password0',
      role: Role.Primary,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

