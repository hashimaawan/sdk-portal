
# Type 2

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `UserCreated` |
| `Personal` |
| `Everyone` |
| `Transfer` |

## Example

```ts
import { Type2 } from 'm-1-password-connectlib';

const type2 = Type2.Everyone;
```

