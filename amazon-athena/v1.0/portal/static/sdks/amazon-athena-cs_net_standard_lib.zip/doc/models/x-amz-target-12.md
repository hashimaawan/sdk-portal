
# X Amz Target 12

## Enumeration

`XAmzTarget12`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeletePreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget12 xAmzTarget12 = XAmzTarget12.EnumAmazonAthenaDeletePreparedStatement;
```

