
# Load Balancer Target

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancerTarget`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `health_status` | [`Array[HealthStatus]`](../../doc/models/health-status.md) | Optional | List of health statuses of the services on this target |
| `ip` | [`Ip`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. |
| `label_selector` | [`LabelSelector7`](../../doc/models/label-selector-7.md) | Optional | Label selector and a list of selected targets |
| `server` | [`LoadBalancerTargetServer`](../../doc/models/load-balancer-target-server.md) | Optional | Server where the traffic should be routed through |
| `targets` | [`Array[Target]`](../../doc/models/target.md) | Optional | List of selected targets |
| `type` | [`Type29`](../../doc/models/type-29.md) | Required | Type of the resource |
| `use_private_ip` | `TrueClass \| FalseClass` | Optional | Use the private network IP instead of the public IP. Default value is false. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
load_balancer_target = LoadBalancerTarget.new(
  type: Type29::SERVER,
  health_status: [
    HealthStatus.new(
      listen_port: 142,
      status: Status30::UNKNOWN,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    HealthStatus.new(
      listen_port: 142,
      status: Status30::UNKNOWN,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    HealthStatus.new(
      listen_port: 142,
      status: Status30::UNKNOWN,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  ip: Ip.new(
    ip: 'ip8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  label_selector: LabelSelector7.new(
    selector: 'selector8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  server: LoadBalancerTargetServer.new(
    id: 14,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  targets: [
    Target.new(
      health_status: [
        HealthStatus.new(
          listen_port: 142,
          status: Status30::UNKNOWN,
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        HealthStatus.new(
          listen_port: 142,
          status: Status30::UNKNOWN,
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      server: Server11.new(
        id: 14,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      type: 'type2',
      use_private_ip: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

