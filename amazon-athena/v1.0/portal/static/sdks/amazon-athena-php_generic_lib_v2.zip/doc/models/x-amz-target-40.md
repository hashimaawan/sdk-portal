
# X Amz Target 40

## Enumeration

`XAmzTarget40`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget40;

$xAmzTarget40 = XAmzTarget40::ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS;
```

