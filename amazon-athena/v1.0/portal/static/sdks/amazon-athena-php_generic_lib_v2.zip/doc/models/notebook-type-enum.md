
# Notebook Type Enum

## Enumeration

`NotebookTypeEnum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```php
use AmazonAthenaLib\Models\NotebookTypeEnum;

$notebookType = NotebookTypeEnum::IPYNB;
```

