
# Servers Actions Enable Rescue Response

## Structure

`ServersActionsEnableRescueResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action \| undefined`](../../doc/models/action.md) | Optional | - |
| `rootPassword` | `string \| undefined` | Optional | Password that will be set for this Server once the Action succeeds |

## Example

```ts
import {
  ServersActionsEnableRescueResponse,
  StatusEnum,
} from 'hetzner-cloud-apilib';

const serversActionsEnableRescueResponse: ServersActionsEnableRescueResponse = {
  action: {
    command: 'command6',
    error: {
      code: 'code2',
      message: 'message4',
    },
    finished: 'finished0',
    id: 238,
    progress: 143.26,
    resources: [
      {
        id: 198,
        type: 'type0',
      },
      {
        id: 198,
        type: 'type0',
      },
      {
        id: 198,
        type: 'type0',
      }
    ],
    started: 'started8',
    status: StatusEnum.Running,
  },
  rootPassword: 'zCWbFhnu950dUTko5f40',
};
```

