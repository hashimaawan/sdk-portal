
# X Amz Target 55

## Enumeration

`XAmzTarget55`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaupdatenamedquery` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget55 := models.XAmzTarget55_EnumAmazonathenaupdatenamedquery

}
```

