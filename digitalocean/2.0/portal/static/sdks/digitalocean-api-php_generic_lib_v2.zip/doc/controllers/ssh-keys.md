# SSH Keys

```php
$sshKeysApi = $client->getSshKeysApi();
```

## Class Name

`SshKeysApi`

## Methods

* [Ssh Keys List](../../doc/controllers/ssh-keys.md#ssh-keys-list)
* [Ssh Keys Create](../../doc/controllers/ssh-keys.md#ssh-keys-create)
* [Ssh Keys Delete](../../doc/controllers/ssh-keys.md#ssh-keys-delete)
* [Ssh Keys Get](../../doc/controllers/ssh-keys.md#ssh-keys-get)
* [Ssh Keys Update](../../doc/controllers/ssh-keys.md#ssh-keys-update)


# Ssh Keys List

To list all of the keys in your account, send a GET request to `/v2/account/keys`. The response will be a JSON object with a key set to `ssh_keys`. The value of this will be an array of ssh_key objects, each of which contains the standard ssh_key attributes.

```php
function sshKeysList(?int $perPage = 20, ?int $page = 1): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: A JSON object with the key set to `ssh_keys`. The value is an array of `ssh_key` objects, each of which contains the standard `ssh_key` attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AccountKeysResponse`](../../doc/models/v2-account-keys-response.md).

## Example Usage

```php
$perPage = 2;

$page = 1;

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->sshKeysList(
    $perPage,
    $page
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AccountKeysResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Ssh Keys Create

To add a new SSH public key to your DigitalOcean account, send a POST request to `/v2/account/keys`. Set the `name` attribute to the name you wish to use and the `public_key` attribute to the full public key you are adding.

```php
function sshKeysCreate(SshKey $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`SshKey`](../../doc/models/ssh-key.md) | Body, Required | - |

## Response Type

**201**: The response body will be a JSON object with a key set to `ssh_key`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AccountKeysResponse1`](../../doc/models/v2-account-keys-response-1.md).

## Example Usage

```php
$body = SshKeyBuilder::init(
    'My SSH Public Key',
    'ssh-rsa AEXAMPLEaC1yc2EAAAADAQABAAAAQQDDHr/jh2Jy4yALcK4JyWbVkPRaWmhck3IgCoeOO3z1e2dBowLh64QAM+Qb72pxekALga2oi4GvT+TlWNhzPH4V example'
)->build();

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->sshKeysCreate($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AccountKeysResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Ssh Keys Delete

To destroy a public SSH key that you have in your account, send a DELETE request to `/v2/account/keys/$KEY_ID` or `/v2/account/keys/$KEY_FINGERPRINT`.
A 204 status will be returned, indicating that the action was successful and that the response body is empty.

```php
function sshKeysDelete($sshKeyIdentifier): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sshKeyIdentifier` | int\|string | Template, Required | This is a container for any-of cases. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$sshKeyIdentifier = 512189;

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->sshKeysDelete($sshKeyIdentifier);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Ssh Keys Get

To get information about a key, send a GET request to `/v2/account/keys/$KEY_ID` or `/v2/account/keys/$KEY_FINGERPRINT`.
The response will be a JSON object with the key `ssh_key` and value an ssh_key object which contains the standard ssh_key attributes.

```php
function sshKeysGet($sshKeyIdentifier): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sshKeyIdentifier` | int\|string | Template, Required | This is a container for any-of cases. |

## Response Type

**200**: A JSON object with the key set to `ssh_key`. The value is an `ssh_key` object containing the standard `ssh_key` attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AccountKeysResponse1`](../../doc/models/v2-account-keys-response-1.md).

## Example Usage

```php
$sshKeyIdentifier = 512189;

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->sshKeysGet($sshKeyIdentifier);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AccountKeysResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Ssh Keys Update

To update the name of an SSH key, send a PUT request to either `/v2/account/keys/$SSH_KEY_ID` or `/v2/account/keys/$SSH_KEY_FINGERPRINT`. Set the `name` attribute to the new name you want to use.

```php
function sshKeysUpdate($sshKeyIdentifier, V2AccountKeysRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sshKeyIdentifier` | int\|string | Template, Required | This is a container for any-of cases. |
| `body` | [`V2AccountKeysRequest`](../../doc/models/v2-account-keys-request.md) | Body, Required | Set the `name` attribute to the new name you want to use. |

## Response Type

**200**: A JSON object with the key set to `ssh_key`. The value is an `ssh_key` object containing the standard `ssh_key` attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2AccountKeysResponse1`](../../doc/models/v2-account-keys-response-1.md).

## Example Usage

```php
$sshKeyIdentifier = 512189;

$body = V2AccountKeysRequestBuilder::init()
    ->name('My SSH Public Key')
    ->build();

$sshKeysApi = $client->getSshKeysApi();
$apiResponse = $sshKeysApi->sshKeysUpdate(
    $sshKeyIdentifier,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2AccountKeysResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

