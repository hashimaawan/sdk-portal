
# Type 24

Destination Image type to convert to

## Enumeration

`Type24`

## Fields

| Name |
|  --- |
| `Snapshot` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type24 type24 = Type24.Snapshot;
```

