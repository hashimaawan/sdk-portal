
# X Amz Target 1 Enum

## Enumeration

`XAmzTarget1Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget1Enum;

$xAmzTarget1 = XAmzTarget1Enum::ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT;
```

