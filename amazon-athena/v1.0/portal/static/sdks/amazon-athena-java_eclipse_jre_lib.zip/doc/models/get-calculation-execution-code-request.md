
# Get Calculation Execution Code Request

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CalculationExecutionId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | String getCalculationExecutionId() | setCalculationExecutionId(String calculationExecutionId) |

## Example

```java
import com.amazonaws.useast1.athena.models.GetCalculationExecutionCodeRequest;

GetCalculationExecutionCodeRequest getCalculationExecutionCodeRequest = new GetCalculationExecutionCodeRequest.Builder(
    "CalculationExecutionId4"
)
.build();
```

