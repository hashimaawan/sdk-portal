
# Terminate Session Request

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ruby
terminate_session_request = TerminateSessionRequest.new(
  'SessionId8'
)
```

