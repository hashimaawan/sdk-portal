
# X Amz Target 39

## Enumeration

`XAmzTarget39`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```python
from amazonathena.models.x_amz_target_39 import XAmzTarget39

x_amz_target_39 = XAmzTarget39.ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS
```

