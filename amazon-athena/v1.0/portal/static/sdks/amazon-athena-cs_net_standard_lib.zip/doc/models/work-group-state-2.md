
# Work Group State 2

The workgroup state that will be updated for the given workgroup.

## Enumeration

`WorkGroupState2`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```csharp
using AmazonAthena.Standard.Models;

WorkGroupState2 workGroupState2 = WorkGroupState2.Enabled;
```

