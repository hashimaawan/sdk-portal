
# Vault 3

*This model accepts additional fields of type Object.*

## Structure

`Vault3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | **Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
vault3 = Vault3.new(
  id: 'id0',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

