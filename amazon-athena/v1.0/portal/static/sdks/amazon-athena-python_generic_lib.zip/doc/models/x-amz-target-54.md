
# X Amz Target 54

## Enumeration

`XAmzTarget54`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEDATACATALOG` |

## Example

```python
from amazonathena.models.x_amz_target_54 import XAmzTarget54

x_amz_target_54 = XAmzTarget54.ENUM_AMAZONATHENAUPDATEDATACATALOG
```

