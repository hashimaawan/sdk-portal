
# Work Group 2

## Structure

`WorkGroup2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `state` | [`WorkGroupState3Enum \| undefined`](../../doc/models/work-group-state-3-enum.md) | Optional | - |
| `configuration` | [`MConfiguration \| undefined`](../../doc/models/m-configuration.md) | Optional | - |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `creationTime` | `string \| undefined` | Optional | - |

## Example

```ts
import {
  EncryptionOption1Enum,
  S3AclOption1Enum,
  WorkGroup2,
  WorkGroupState3Enum,
} from 'amazon-athenalib';

const workGroup2: WorkGroup2 = {
  name: 'Name0',
  state: WorkGroupState3Enum.ENABLED,
  configuration: {
    resultConfiguration: {
      outputLocation: 'OutputLocation0',
      encryptionConfiguration: {
        encryptionOption: EncryptionOption1Enum.SSES3,
        kmsKey: 'KmsKey6',
      },
      expectedBucketOwner: 'ExpectedBucketOwner0',
      aclConfiguration: {
        s3AclOption: S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
      },
    },
    enforceWorkGroupConfiguration: false,
    publishCloudWatchMetricsEnabled: false,
    bytesScannedCutoffPerQuery: 10000000,
    requesterPaysEnabled: false,
  },
  description: 'Description6',
  creationTime: '2016-03-13T12:52:32.123Z',
};
```

