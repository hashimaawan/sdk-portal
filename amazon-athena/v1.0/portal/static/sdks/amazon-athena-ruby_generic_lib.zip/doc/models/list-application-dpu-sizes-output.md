
# List Application DPU Sizes Output

## Structure

`ListApplicationDPUSizesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `application_dpu_sizes` | [`Array[ApplicationDPUSizes]`](../../doc/models/application-dpu-sizes.md) | Optional | - |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_application_dpu_sizes_output = ListApplicationDPUSizesOutput.new(
  [
    ApplicationDPUSizes.new(
      'ApplicationRuntimeId0',
      [
        113,
        114
      ]
    )
  ],
  'NextToken6'
)
```

