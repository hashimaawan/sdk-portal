
# Phase

## Enumeration

`Phase`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING_BUILD` |
| `BUILDING` |
| `PENDING_DEPLOY` |
| `DEPLOYING` |
| `ACTIVE` |
| `SUPERSEDED` |
| `ERROR` |
| `CANCELED` |

## Example

```php
use DigitalOceanApiLib\Models\Phase;

$phase = Phase::BUILDING;
```

