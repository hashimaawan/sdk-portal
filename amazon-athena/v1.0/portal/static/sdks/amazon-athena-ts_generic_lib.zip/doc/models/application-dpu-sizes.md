
# Application DPU Sizes

Contains the application runtime IDs and their supported DPU sizes.

## Structure

`ApplicationDPUSizes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applicationRuntimeId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `supportedDPUSizes` | `number[] \| undefined` | Optional | - |

## Example

```ts
import { ApplicationDPUSizes } from 'amazon-athenalib';

const applicationDPUSizes: ApplicationDPUSizes = {
  applicationRuntimeId: 'ApplicationRuntimeId2',
  supportedDPUSizes: [
    57
  ],
};
```

