
# Images Actions Change Protection Request

*This model accepts additional fields of type unknown.*

## Structure

`ImagesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the snapshot from being deleted |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ImagesActionsChangeProtectionRequest } from 'hetzner-cloud-apilib';

const imagesActionsChangeProtectionRequest: ImagesActionsChangeProtectionRequest = {
  mDelete: true,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

