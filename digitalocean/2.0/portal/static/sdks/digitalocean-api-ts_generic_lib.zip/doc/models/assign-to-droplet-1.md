
# Assign to Droplet 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`AssignToDroplet1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletId` | `number` | Required | The ID of the Droplet that the reserved IP will be assigned to. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { AssignToDroplet1 } from 'digitalocean-apilib';

const assignToDroplet1: AssignToDroplet1 = {
  dropletId: 2457247,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

