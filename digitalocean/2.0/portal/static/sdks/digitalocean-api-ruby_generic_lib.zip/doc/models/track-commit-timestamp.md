
# Track Commit Timestamp

Record commit time of transactions.

## Enumeration

`TrackCommitTimestamp`

## Fields

| Name |
|  --- |
| `OFF` |
| `ON` |

## Example

```ruby
track_commit_timestamp = TrackCommitTimestamp::OFF
```

