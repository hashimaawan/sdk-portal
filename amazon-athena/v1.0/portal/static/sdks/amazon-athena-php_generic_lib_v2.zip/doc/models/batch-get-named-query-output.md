
# Batch Get Named Query Output

## Structure

`BatchGetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `namedQueries` | [`?(NamedQuery[])`](../../doc/models/named-query.md) | Optional | - | getNamedQueries(): ?array | setNamedQueries(?array namedQueries): void |
| `unprocessedNamedQueryIds` | [`?(UnprocessedNamedQueryId[])`](../../doc/models/unprocessed-named-query-id.md) | Optional | - | getUnprocessedNamedQueryIds(): ?array | setUnprocessedNamedQueryIds(?array unprocessedNamedQueryIds): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\BatchGetNamedQueryOutputBuilder;
use AmazonAthenaLib\Models\Builders\NamedQueryBuilder;
use AmazonAthenaLib\Models\Builders\UnprocessedNamedQueryIdBuilder;

$batchGetNamedQueryOutput = BatchGetNamedQueryOutputBuilder::init()
    ->namedQueries(
        [
            NamedQueryBuilder::init(
                'Name2',
                'Database0',
                'QueryString4'
            )
                ->description('Description4')
                ->namedQueryId('NamedQueryId0')
                ->workGroup('WorkGroup4')
                ->build(),
            NamedQueryBuilder::init(
                'Name2',
                'Database0',
                'QueryString4'
            )
                ->description('Description4')
                ->namedQueryId('NamedQueryId0')
                ->workGroup('WorkGroup4')
                ->build(),
            NamedQueryBuilder::init(
                'Name2',
                'Database0',
                'QueryString4'
            )
                ->description('Description4')
                ->namedQueryId('NamedQueryId0')
                ->workGroup('WorkGroup4')
                ->build()
        ]
    )
    ->unprocessedNamedQueryIds(
        [
            UnprocessedNamedQueryIdBuilder::init()
                ->namedQueryId('NamedQueryId4')
                ->errorCode('ErrorCode6')
                ->errorMessage('ErrorMessage4')
                ->build(),
            UnprocessedNamedQueryIdBuilder::init()
                ->namedQueryId('NamedQueryId4')
                ->errorCode('ErrorCode6')
                ->errorMessage('ErrorMessage4')
                ->build()
        ]
    )
    ->build();
```

