
# X Amz Target

## Enumeration

`XAmzTarget`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget;

$xAmzTarget = XAmzTarget::ENUM_AMAZONATHENABATCHGETNAMEDQUERY;
```

