
# Status 113

Current status of the Volume

## Enumeration

`Status113`

## Fields

| Name |
|  --- |
| `Creating` |
| `Available` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Status113 status113 = Status113.Creating;
```

