
# Firewall Remove from Resources

## Structure

`FirewallRemoveFromResources`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LabelSelector` | [`*models.LabelSelector5`](../../doc/models/label-selector-5.md) | Optional | Configuration for type label_selector, required if type is `label_selector` |
| `Server` | [`*models.Server9`](../../doc/models/server-9.md) | Optional | Configuration for type server, required if type is `server` |
| `Type` | [`*models.Type7Enum`](../../doc/models/type-7-enum.md) | Optional | Type of the resource |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    firewallRemoveFromResources := models.FirewallRemoveFromResources{
        LabelSelector:        models.ToPointer(models.LabelSelector5{
            Selector:             "selector8",
        }),
        Server:               models.ToPointer(models.Server9{
            Id:                   14,
        }),
        Type:                 models.ToPointer(models.Type7Enum_SERVER),
    }

}
```

