
# Region 2

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```ruby
region2 = Region2::CNNORTH1
```

