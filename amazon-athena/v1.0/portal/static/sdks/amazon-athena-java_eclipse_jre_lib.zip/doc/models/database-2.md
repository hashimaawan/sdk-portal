
# Database 2

## Structure

`Database2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | String getName() | setName(String name) |
| `Description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getDescription() | setDescription(String description) |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - | Parameters getParameters() | setParameters(Parameters parameters) |

## Example

```java
import com.amazonaws.useast1.athena.models.Database2;
import com.amazonaws.useast1.athena.models.Parameters;

Database2 database2 = new Database2.Builder(
    "Name4"
)
.description("Description2")
.parameters(new Parameters.Builder()
        .build())
.build();
```

