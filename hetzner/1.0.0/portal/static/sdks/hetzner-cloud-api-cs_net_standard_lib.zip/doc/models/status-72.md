
# Status 72

Status of the Firewall on the Server

## Enumeration

`Status72`

## Fields

| Name |
|  --- |
| `Applied` |
| `Pending` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Status72 status72 = Status72.Applied;
```

