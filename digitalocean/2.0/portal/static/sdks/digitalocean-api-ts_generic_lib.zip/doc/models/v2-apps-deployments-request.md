
# V2 Apps Deployments Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsDeploymentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `forceBuild` | `boolean \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AppsDeploymentsRequest } from 'digitalocean-apilib';

const v2AppsDeploymentsRequest: V2AppsDeploymentsRequest = {
  forceBuild: true,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

