
# X Amz Target 33

## Enumeration

`XAmzTarget33`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListDataCatalogs` |

## Example

```ts
import { XAmzTarget33 } from 'amazon-athenalib';

const xAmzTarget33 = XAmzTarget33.EnumAmazonAthenaListDataCatalogs;
```

