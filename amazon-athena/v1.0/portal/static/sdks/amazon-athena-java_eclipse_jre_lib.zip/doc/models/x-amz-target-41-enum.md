
# X Amz Target 41 Enum

## Enumeration

`XAmzTarget41Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget41Enum;

XAmzTarget41Enum xAmzTarget41 = XAmzTarget41Enum.ENUM_AMAZONATHENALISTQUERYEXECUTIONS;
```

