
# X Amz Target 25 Enum

## Enumeration

`XAmzTarget25Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```python
from amazonathena.models.x_amz_target_25_enum import XAmzTarget25Enum

x_amz_target_25 = XAmzTarget25Enum.ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS
```

