
# V2 Firewalls Droplets Request 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FirewallsDropletsRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_ids` | `Array[Integer]` | Required | An array containing the IDs of the Droplets to be assigned to the firewall. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_firewalls_droplets_request1 = V2FirewallsDropletsRequest1.new(
  droplet_ids: [
    49696269
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

