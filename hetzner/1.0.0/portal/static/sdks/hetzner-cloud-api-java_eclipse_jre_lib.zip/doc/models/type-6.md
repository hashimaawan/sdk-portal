
# Type 6

Type of resource referenced

## Enumeration

`Type6`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```java
import cloud.hetzner.api.models.Type6;

Type6 type6 = Type6.SERVER;
```

