
# X Amz Target 31

## Enumeration

`XAmzTarget31`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListApplicationDpuSizes` |

## Example

```ts
import { XAmzTarget31 } from 'amazon-athenalib';

const xAmzTarget31 = XAmzTarget31.EnumAmazonAthenaListApplicationDpuSizes;
```

