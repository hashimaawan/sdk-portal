
# X Amz Target 8 Enum

## Enumeration

`XAmzTarget8Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENACREATEWORKGROUP` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget8 := models.XAmzTarget8Enum_ENUMAMAZONATHENACREATEWORKGROUP

}
```

