
# Parameter Type 1 Enum

## Enumeration

`ParameterType1Enum`

## Fields

| Name |
|  --- |
| `Spread` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ParameterType1Enum parameterType1 = ParameterType1Enum.Spread;
```

