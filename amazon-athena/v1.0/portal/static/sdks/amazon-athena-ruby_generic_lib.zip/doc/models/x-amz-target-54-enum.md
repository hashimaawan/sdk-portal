
# X Amz Target 54 Enum

## Enumeration

`XAmzTarget54Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEDATACATALOG` |

## Example

```ruby
x_amz_target54 = XAmzTarget54Enum::ENUM_AMAZONATHENAUPDATEDATACATALOG
```

