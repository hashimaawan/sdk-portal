
# X Amz Target 31

## Enumeration

`XAmzTarget31`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget31;

XAmzTarget31 xAmzTarget31 = XAmzTarget31.ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES;
```

