
# Update Volume Request

## Structure

`UpdateVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labels` | [`Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `Name` | `string` | Required | New Volume name |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

UpdateVolumeRequest updateVolumeRequest = new UpdateVolumeRequest
{
    Name = "database-storage",
    Labels = new Labels2
    {
        Labelkey = "labelkey4",
    },
};
```

