
# Os Flavor

Flavor of operating system contained in the Image

## Enumeration

`OsFlavor`

## Fields

| Name |
|  --- |
| `UBUNTU` |
| `CENTOS` |
| `DEBIAN` |
| `FEDORA` |
| `UNKNOWN` |

## Example

```php
use HetznerCloudApiLib\Models\OsFlavor;

$osFlavor = OsFlavor::DEBIAN;
```

