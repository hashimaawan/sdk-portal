
# Status 4

A string representing the current status of the database cluster.

## Enumeration

`Status4`

## Fields

| Name |
|  --- |
| `CREATING` |
| `ONLINE` |
| `RESIZING` |
| `MIGRATING` |
| `FORKING` |

## Example

```python
from digitaloceanapi.models.status_4 import Status4

status_4 = Status4.RESIZING
```

