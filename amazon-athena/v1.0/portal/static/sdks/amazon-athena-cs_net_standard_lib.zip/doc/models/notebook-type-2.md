
# Notebook Type 2

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2`

## Fields

| Name |
|  --- |
| `Ipynb` |

## Example

```csharp
using AmazonAthena.Standard.Models;

NotebookType2 notebookType2 = NotebookType2.Ipynb;
```

