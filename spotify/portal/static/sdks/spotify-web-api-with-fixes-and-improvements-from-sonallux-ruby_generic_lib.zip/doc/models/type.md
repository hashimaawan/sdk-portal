
# Type

The object type.

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `ARTIST` |

## Example

```ruby
type = Type::ARTIST
```

