
# Label Selector 7

Label selector and a list of selected targets

## Structure

`LabelSelector7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `String` | Required | Label selector |

## Example

```ruby
label_selector7 = LabelSelector7.new(
  'env=prod'
)
```

