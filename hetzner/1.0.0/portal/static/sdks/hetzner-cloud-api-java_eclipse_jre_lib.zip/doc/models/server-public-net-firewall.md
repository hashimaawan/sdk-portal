
# Server Public Net Firewall

*This model accepts additional fields of type Object.*

## Structure

`ServerPublicNetFirewall`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Integer` | Optional | ID of the Resource | Integer getId() | setId(Integer id) |
| `Status` | [`Status72`](../../doc/models/status-72.md) | Optional | Status of the Firewall on the Server | Status72 getStatus() | setStatus(Status72 status) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.ServerPublicNetFirewall;
import cloud.hetzner.api.models.Status72;
import java.io.IOException;

ServerPublicNetFirewall serverPublicNetFirewall = new ServerPublicNetFirewall.Builder()
    .id(42)
    .status(Status72.APPLIED)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

