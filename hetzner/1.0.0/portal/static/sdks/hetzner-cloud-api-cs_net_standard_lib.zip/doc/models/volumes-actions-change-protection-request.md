
# Volumes Actions Change Protection Request

## Structure

`VolumesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool?` | Optional | If true, prevents the Volume from being deleted |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

VolumesActionsChangeProtectionRequest volumesActionsChangeProtectionRequest = new VolumesActionsChangeProtectionRequest
{
    Delete = true,
};
```

