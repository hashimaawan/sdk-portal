
# Create Notebook Input

## Structure

`CreateNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `ClientRequestToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```csharp
using AmazonAthena.Standard.Models;

CreateNotebookInput createNotebookInput = new CreateNotebookInput
{
    WorkGroup = "WorkGroup2",
    Name = "Name0",
    ClientRequestToken = "ClientRequestToken4",
};
```

