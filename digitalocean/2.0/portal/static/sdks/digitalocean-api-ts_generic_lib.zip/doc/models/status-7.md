
# Status 7

A status string indicating the state of a custom image. This may be `NEW`,
`available`, `pending`, `deleted`, or `retired`.

## Enumeration

`Status7`

## Fields

| Name |
|  --- |
| `New` |
| `Available` |
| `Pending` |
| `Deleted` |
| `Retired` |

## Example

```ts
import { Status7 } from 'digitalocean-apilib';

const status7 = Status7.New;
```

