
# Os Flavor Enum

Flavor of operating system contained in the Image

## Enumeration

`OsFlavorEnum`

## Fields

| Name |
|  --- |
| `UBUNTU` |
| `CENTOS` |
| `DEBIAN` |
| `FEDORA` |
| `UNKNOWN` |

## Example

```python
from hetznercloudapi.models.os_flavor_enum import OsFlavorEnum

os_flavor = OsFlavorEnum.UNKNOWN
```

