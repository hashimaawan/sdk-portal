
# Stop Query Execution Input

*This model accepts additional fields of type unknown.*

## Structure

`StopQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { StopQueryExecutionInput } from 'amazon-athenalib';

const stopQueryExecutionInput: StopQueryExecutionInput = {
  queryExecutionId: 'QueryExecutionId4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

