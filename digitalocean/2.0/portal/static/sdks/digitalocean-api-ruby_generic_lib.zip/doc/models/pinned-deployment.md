
# Pinned Deployment

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`PinnedDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cause` | `String` | Optional | - |
| `cloned_from` | `String` | Optional | - |
| `created_at` | `DateTime` | Optional | - |
| `functions` | [`Array[FunctionsComponentsThatArePartOfThisDeployment]`](../../doc/models/functions-components-that-are-part-of-this-deployment.md) | Optional | - |
| `id` | `String` | Optional | - |
| `jobs` | [`Array[JobComponentsThatArePartOfThisDeployment]`](../../doc/models/job-components-that-are-part-of-this-deployment.md) | Optional | - |
| `phase` | [`Phase`](../../doc/models/phase.md) | Optional | **Default**: `Phase::UNKNOWN` |
| `phase_last_updated_at` | `DateTime` | Optional | - |
| `progress` | [`Progress`](../../doc/models/progress.md) | Optional | - |
| `services` | [`Array[ServiceComponentsThatArePartOfThisDeployment]`](../../doc/models/service-components-that-are-part-of-this-deployment.md) | Optional | - |
| `spec` | [`AppSpec`](../../doc/models/app-spec.md) | Optional | The desired configuration of an application. |
| `static_sites` | [`Array[StaticSiteComponentsThatArePartOfThisDeployment]`](../../doc/models/static-site-components-that-are-part-of-this-deployment.md) | Optional | - |
| `tier_slug` | `String` | Optional, Read-only | - |
| `updated_at` | `DateTime` | Optional | - |
| `workers` | [`Array[WorkerComponentsThatArePartOfThisDeployment]`](../../doc/models/worker-components-that-are-part-of-this-deployment.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
pinned_deployment = PinnedDeployment.new(
  cause: 'commit 9a4df0b pushed to github/digitalocean/sample-golang',
  cloned_from: '3aa4d20e-5527-4c00-b496-601fbd22520a',
  created_at: DateTimeHelper.from_rfc3339('2020-07-28T18:00:00Z'),
  functions: [
    FunctionsComponentsThatArePartOfThisDeployment.new(
      name: 'name4',
      namespace: 'namespace8',
      source_commit_hash: 'source_commit_hash4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  id: 'b6bdf840-2854-4f87-a36c-5f231c617c84',
  phase: Phase::ACTIVE,
  phase_last_updated_at: DateTimeHelper.from_rfc3339('0001-01-01T00:00:00Z'),
  tier_slug: 'basic',
  updated_at: DateTimeHelper.from_rfc3339('2020-07-28T18:00:00Z'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

