
# V2 Projects Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2ProjectsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `project` | [`?Project`](../../doc/models/project.md) | Optional | - | getProject(): ?Project | setProject(?Project project): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2ProjectsResponse1Builder;
use DigitalOceanApiLib\Models\Builders\ProjectBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\Models\Environment;
use DigitalOceanApiLib\ApiHelper;

$v2ProjectsResponse1 = V2ProjectsResponse1Builder::init()
    ->project(
        ProjectBuilder::init()
            ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->description('description4')
            ->environment(Environment::DEVELOPMENT)
            ->id('000026e4-0000-0000-0000-000000000000')
            ->name('name6')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

