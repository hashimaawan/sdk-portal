
# Get Calculation Execution Response

*This model accepts additional fields of type Object.*

## Structure

`GetCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CalculationExecutionId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | String getCalculationExecutionId() | setCalculationExecutionId(String calculationExecutionId) |
| `SessionId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getSessionId() | setSessionId(String sessionId) |
| `Description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getDescription() | setDescription(String description) |
| `WorkingDirectory` | `String` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` | String getWorkingDirectory() | setWorkingDirectory(String workingDirectory) |
| `Status` | [`Status1`](../../doc/models/status-1.md) | Optional | - | Status1 getStatus() | setStatus(Status1 status) |
| `Statistics` | [`Statistics1`](../../doc/models/statistics-1.md) | Optional | - | Statistics1 getStatistics() | setStatistics(Statistics1 statistics) |
| `Result` | [`Result`](../../doc/models/result.md) | Optional | - | Result getResult() | setResult(Result result) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.DateTimeHelper;
import com.amazonaws.useast1.athena.models.CalculationExecutionState1;
import com.amazonaws.useast1.athena.models.GetCalculationExecutionResponse;
import com.amazonaws.useast1.athena.models.Status1;
import java.io.IOException;

GetCalculationExecutionResponse getCalculationExecutionResponse = new GetCalculationExecutionResponse.Builder()
    .calculationExecutionId("CalculationExecutionId4")
    .sessionId("SessionId8")
    .description("Description6")
    .workingDirectory("WorkingDirectory8")
    .status(new Status1.Builder()
        .submissionDateTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .completionDateTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .state(CalculationExecutionState1.CANCELING)
        .stateChangeReason("StateChangeReason8")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

