
# V2 Apps Tiers Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsTiersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tiers` | [`Tier[] \| undefined`](../../doc/models/tier.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AppsTiersResponse } from 'digitalocean-apilib';

const v2AppsTiersResponse: V2AppsTiersResponse = {
  tiers: [
    {
      buildSeconds: 'build_seconds4',
      egressBandwidthBytes: 'egress_bandwidth_bytes2',
      name: 'name8',
      slug: 'slug8',
      storageBytes: 'storage_bytes4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      buildSeconds: 'build_seconds4',
      egressBandwidthBytes: 'egress_bandwidth_bytes2',
      name: 'name8',
      slug: 'slug8',
      storageBytes: 'storage_bytes4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      buildSeconds: 'build_seconds4',
      egressBandwidthBytes: 'egress_bandwidth_bytes2',
      name: 'name8',
      slug: 'slug8',
      storageBytes: 'storage_bytes4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

