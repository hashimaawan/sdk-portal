
# Load Balancer Target Server

Server where the traffic should be routed through

*This model accepts additional fields of type object.*

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

LoadBalancerTargetServer loadBalancerTargetServer = new LoadBalancerTargetServer
{
    Id = 80,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

