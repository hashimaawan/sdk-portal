
# Query Stage

Stage statistics such as input and output rows and bytes, execution time and stage state. This information also includes substages and the query stage plan.

## Structure

`QueryStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stage_id` | `int` | Optional | - |
| `state` | `str` | Optional | - |
| `output_bytes` | `int` | Optional | - |
| `output_rows` | `int` | Optional | - |
| `input_bytes` | `int` | Optional | - |
| `input_rows` | `int` | Optional | - |
| `execution_time` | `int` | Optional | - |
| `query_stage_plan` | [`QueryStagePlan`](../../doc/models/query-stage-plan.md) | Optional | - |
| `sub_stages` | [`List[QueryStage]`](../../doc/models/query-stage.md) | Optional | - |

## Example

```python
from amazonathena.models.query_stage import QueryStage

query_stage = QueryStage(
    stage_id=162,
    state='State0',
    output_bytes=76,
    output_rows=190,
    input_bytes=222
)
```

