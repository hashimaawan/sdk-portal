
# Parameter Type

## Enumeration

`ParameterType`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```ts
import { ParameterType } from 'hetzner-cloud-apilib';

const parameterType = ParameterType.Uploaded;
```

