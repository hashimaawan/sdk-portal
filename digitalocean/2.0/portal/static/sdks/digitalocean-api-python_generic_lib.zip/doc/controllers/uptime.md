# Uptime

[DigitalOcean Uptime Checks](https://docs.digitalocean.com/products/uptime/) provide the ability to monitor your endpoints from around the world, and alert you when they're slow, unavailable, or SSL certificates are expiring.
To interact with Uptime, you will generally send requests to the Uptime endpoint at `/v2/uptime/`.

```python
uptime_api = client.uptime
```

## Class Name

`UptimeApi`

## Methods

* [Uptime Checks List](../../doc/controllers/uptime.md#uptime-checks-list)
* [Uptime Check Create](../../doc/controllers/uptime.md#uptime-check-create)
* [Uptime Check Delete](../../doc/controllers/uptime.md#uptime-check-delete)
* [Uptime Check Get](../../doc/controllers/uptime.md#uptime-check-get)
* [Uptime Check Update](../../doc/controllers/uptime.md#uptime-check-update)
* [Uptime Check Alerts List](../../doc/controllers/uptime.md#uptime-check-alerts-list)
* [Uptime Alert Create](../../doc/controllers/uptime.md#uptime-alert-create)
* [Uptime Alert Delete](../../doc/controllers/uptime.md#uptime-alert-delete)
* [Uptime Alert Get](../../doc/controllers/uptime.md#uptime-alert-get)
* [Uptime Alert Update](../../doc/controllers/uptime.md#uptime-alert-update)
* [Uptime Check State Get](../../doc/controllers/uptime.md#uptime-check-state-get)


# Uptime Checks List

To list all of the Uptime checks on your account, send a GET request to `/v2/uptime/checks`.

```python
def uptime_checks_list(self,
                      per_page=20,
                      page=1)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_page` | `int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object with a key called `checks`. This will be set to an array of objects, each of which will contain the standard attributes associated with an uptime check

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksResponse`](../../doc/models/v2-uptime-checks-response.md).

## Example Usage

```python
per_page = 2

page = 1

result = uptime_api.uptime_checks_list(
    per_page=per_page,
    page=page
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Check Create

To create an Uptime check, send a POST request to `/v2/uptime/checks` specifying the attributes
in the table below in the JSON body.

```python
def uptime_check_create(self,
                       body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2UptimeChecksRequest`](../../doc/models/v2-uptime-checks-request.md) | Body, Required | - |

## Response Type

**201**: The response will be a JSON object with a key called `check`. The value of this will be an object that contains the standard attributes associated with an uptime check.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksResponse1`](../../doc/models/v2-uptime-checks-response-1.md).

## Example Usage

```python
body = V2UptimeChecksRequest(
    enabled=True,
    name='Landing page check',
    regions=[
        Region8.US_EAST,
        Region8.EU_WEST
    ],
    target='https://www.landingpage.com',
    mtype=Type19.HTTPS
)

result = uptime_api.uptime_check_create(body)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Check Delete

To delete an Uptime check, send a DELETE request to `/v2/uptime/checks/$CHECK_ID`. A 204 status
code with no body will be returned in response to a successful request.

Deleting a check will also delete alerts associated with the check.

```python
def uptime_check_delete(self,
                       check_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

result = uptime_api.uptime_check_delete(check_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Check Get

To show information about an existing check, send a GET request to `/v2/uptime/checks/$CHECK_ID`.

```python
def uptime_check_get(self,
                    check_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |

## Response Type

**200**: The response will be a JSON object with a key called `check`. The value of this will be an object that contains the standard attributes associated with an uptime check.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksResponse1`](../../doc/models/v2-uptime-checks-response-1.md).

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

result = uptime_api.uptime_check_get(check_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Check Update

To update the settings of an Uptime check, send a PUT request to `/v2/uptime/checks/$CHECK_ID`.

```python
def uptime_check_update(self,
                       check_id,
                       body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |
| `body` | [`V2UptimeChecksRequest`](../../doc/models/v2-uptime-checks-request.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `check`. The value of this will be an object that contains the standard attributes associated with an uptime check.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksResponse1`](../../doc/models/v2-uptime-checks-response-1.md).

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

body = V2UptimeChecksRequest(
    enabled=True,
    name='Landing page check',
    regions=[
        Region8.US_EAST,
        Region8.EU_WEST
    ],
    target='https://www.landingpage.com',
    mtype=Type19.HTTPS
)

result = uptime_api.uptime_check_update(
    check_id,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Check Alerts List

To list all of the alerts for an Uptime check, send a GET request to `/v2/uptime/checks/$CHECK_ID/alerts`.

```python
def uptime_check_alerts_list(self,
                            check_id,
                            per_page=20,
                            page=1)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |
| `per_page` | `int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object with a key called `alerts`. This will be set to an array of objects, each of which will contain the standard attributes associated with an uptime alert.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksAlertsResponse`](../../doc/models/v2-uptime-checks-alerts-response.md).

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

per_page = 2

page = 1

result = uptime_api.uptime_check_alerts_list(
    check_id,
    per_page=per_page,
    page=page
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Alert Create

To create an Uptime alert, send a POST request to `/v2/uptime/checks/$CHECK_ID/alerts` specifying the attributes
in the table below in the JSON body.

```python
def uptime_alert_create(self,
                       check_id,
                       body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |
| `body` | [`Alerts1`](../../doc/models/alerts-1.md) | Body, Required | The ''type'' field dictates the type of alert, and hence what type of value to pass into the threshold property.<br>Type \| Description \| Threshold Value<br>-----\|-------------\|--------------------<br>`latency` \| alerts on the response latency \| milliseconds<br>`down` \| alerts on a target registering as down in any region \| N/A (Not required)<br>`down_global` \| alerts on a target registering as down globally \| N/A (Not required)<br>`ssl_expiry` \| alerts on a SSL certificate expiring within $threshold days \| days |

## Response Type

**201**: The response will be a JSON object with a key called `alert`. The value of this will be an object that contains the standard attributes associated with an uptime alert.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksAlertsResponse1`](../../doc/models/v2-uptime-checks-alerts-response-1.md).

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

body = Alerts1(
    comparison=Comparison.GREATER_THAN,
    name='Landing page degraded performance',
    period=Period.ENUM_2M,
    threshold=300,
    mtype=Type20.LATENCY
)

result = uptime_api.uptime_alert_create(
    check_id,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Alert Delete

To delete an Uptime alert, send a DELETE request to `/v2/uptime/checks/$CHECK_ID/alerts/$ALERT_ID`. A 204 status
code with no body will be returned in response to a successful request.

```python
def uptime_alert_delete(self,
                       check_id,
                       alert_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |
| `alert_id` | `uuid\|str` | Template, Required | A unique identifier for an alert. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

alert_id = '17f0f0ae-b7e5-4ef6-86e3-aa569db58284'

result = uptime_api.uptime_alert_delete(
    check_id,
    alert_id
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Alert Get

To show information about an existing alert, send a GET request to `/v2/uptime/checks/$CHECK_ID/alerts/$ALERT_ID`.

```python
def uptime_alert_get(self,
                    check_id,
                    alert_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |
| `alert_id` | `uuid\|str` | Template, Required | A unique identifier for an alert. |

## Response Type

**200**: The response will be a JSON object with a key called `alert`. The value of this will be an object that contains the standard attributes associated with an uptime alert.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksAlertsResponse1`](../../doc/models/v2-uptime-checks-alerts-response-1.md).

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

alert_id = '17f0f0ae-b7e5-4ef6-86e3-aa569db58284'

result = uptime_api.uptime_alert_get(
    check_id,
    alert_id
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Alert Update

To update the settings of an Uptime alert, send a PUT request to `/v2/uptime/checks/$CHECK_ID/alerts/$ALERT_ID`.

```python
def uptime_alert_update(self,
                       check_id,
                       alert_id,
                       body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |
| `alert_id` | `uuid\|str` | Template, Required | A unique identifier for an alert. |
| `body` | [`V2UptimeChecksAlertsRequest`](../../doc/models/v2-uptime-checks-alerts-request.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `alert`. The value of this will be an object that contains the standard attributes associated with an uptime alert.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksAlertsResponse1`](../../doc/models/v2-uptime-checks-alerts-response-1.md).

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

alert_id = '17f0f0ae-b7e5-4ef6-86e3-aa569db58284'

body = V2UptimeChecksAlertsRequest(
    comparison=Comparison.GREATER_THAN,
    name='Landing page degraded performance',
    period=Period.ENUM_2M,
    threshold=300,
    mtype=Type20.LATENCY
)

result = uptime_api.uptime_alert_update(
    check_id,
    alert_id,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Uptime Check State Get

To show information about an existing check's state, send a GET request to `/v2/uptime/checks/$CHECK_ID/state`.

```python
def uptime_check_state_get(self,
                          check_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_id` | `uuid\|str` | Template, Required | A unique identifier for a check. |

## Response Type

**200**: The response will be a JSON object with a key called `state`. The value of this will be an object that contains the standard attributes associated with an uptime check's state.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2UptimeChecksStateResponse`](../../doc/models/v2-uptime-checks-state-response.md).

## Example Usage

```python
check_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

result = uptime_api.uptime_check_state_get(check_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

