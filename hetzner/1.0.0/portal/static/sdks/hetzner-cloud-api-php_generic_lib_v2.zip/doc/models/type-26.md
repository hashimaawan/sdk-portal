
# Type 26

Type of the ISO

## Enumeration

`Type26`

## Fields

| Name |
|  --- |
| `PUBLIC_` |
| `PRIVATE_` |

## Example

```php
use HetznerCloudApiLib\Models\Type26;

$type26 = Type26::PUBLIC_;
```

