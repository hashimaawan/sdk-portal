
# Status 9

A status string indicating the current state of the firewall. This can be "waiting", "succeeded", or "failed".

## Enumeration

`Status9`

## Fields

| Name |
|  --- |
| `WAITING` |
| `SUCCEEDED` |
| `FAILED` |

## Example

```php
use DigitalOceanApiLib\Models\Status9;

$status9 = Status9::WAITING;
```

