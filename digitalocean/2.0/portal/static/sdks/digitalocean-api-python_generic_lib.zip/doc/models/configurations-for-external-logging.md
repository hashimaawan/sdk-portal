
# Configurations for External Logging

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`ConfigurationsForExternalLogging`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `datadog` | [`Datadog`](../../doc/models/datadog.md) | Optional | DataDog configuration. |
| `logtail` | [`Logtail`](../../doc/models/logtail.md) | Optional | Logtail configuration. |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `2`, *Maximum Length*: `42`, *Pattern*: `^[A-Za-z0-9()\[\]'"][-A-Za-z0-9_. \/()\[\]]{0,40}[A-Za-z0-9()\[\]'"]$` |
| `papertrail` | [`Papertrail`](../../doc/models/papertrail.md) | Optional | Papertrail configuration. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.configurations_for_external_logging import ConfigurationsForExternalLogging
from digitaloceanapi.models.datadog import Datadog
from digitaloceanapi.models.logtail import Logtail
from digitaloceanapi.models.papertrail import Papertrail

configurations_for_external_logging = ConfigurationsForExternalLogging(
    name='my_log_destination',
    datadog=Datadog(
        api_key='api_key2',
        endpoint='endpoint8',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    logtail=Logtail(
        token='token4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    papertrail=Papertrail(
        endpoint='endpoint4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

