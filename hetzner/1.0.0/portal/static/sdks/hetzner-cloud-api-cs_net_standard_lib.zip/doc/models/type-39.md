
# Type 39

Algorithm of the Load Balancer

## Enumeration

`Type39`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type39 type39 = Type39.RoundRobin;
```

