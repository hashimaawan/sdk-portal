
# X Amz Target 36

## Enumeration

`XAmzTarget36`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTEXECUTORS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget36;

XAmzTarget36 xAmzTarget36 = XAmzTarget36.ENUM_AMAZONATHENALISTEXECUTORS;
```

