
# Type 17 Enum

Floating IP type

## Enumeration

`Type17Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type17 := models.Type17Enum_IPV4

}
```

