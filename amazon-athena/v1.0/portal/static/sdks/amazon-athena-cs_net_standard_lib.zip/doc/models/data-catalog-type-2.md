
# Data Catalog Type 2

The data catalog type.

## Enumeration

`DataCatalogType2`

## Fields

| Name |
|  --- |
| `Lambda` |
| `Glue` |
| `Hive` |

## Example

```csharp
using AmazonAthena.Standard.Models;

DataCatalogType2 dataCatalogType2 = DataCatalogType2.Lambda;
```

