
# Delete Prepared Statement Input

## Structure

`DeletePreparedStatementInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StatementName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    deletePreparedStatementInput := models.DeletePreparedStatementInput{
        StatementName:        "StatementName8",
        WorkGroup:            "WorkGroup2",
    }

}
```

