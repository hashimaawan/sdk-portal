
# Get Query Execution Output

## Structure

`GetQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecution` | [`QueryExecution1`](../../doc/models/query-execution-1.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetQueryExecutionOutput getQueryExecutionOutput = new GetQueryExecutionOutput
{
    QueryExecution = new QueryExecution1
    {
        QueryExecutionId = "QueryExecutionId0",
        Query = "Query6",
        StatementType = StatementType1Enum.DDL,
        ResultConfiguration = new ResultConfiguration1
        {
            OutputLocation = "OutputLocation0",
            EncryptionConfiguration = new EncryptionConfiguration2
            {
                EncryptionOption = EncryptionOption1Enum.SSES3,
                KmsKey = "KmsKey6",
            },
            ExpectedBucketOwner = "ExpectedBucketOwner0",
            AclConfiguration = new AclConfiguration1
            {
                S3AclOption = S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
            },
        },
        ResultReuseConfiguration = new ResultReuseConfiguration1
        {
            ResultReuseByAgeConfiguration = new ResultReuseByAgeConfiguration2
            {
                Enabled = false,
                MaxAgeInMinutes = 26,
            },
        },
    },
};
```

