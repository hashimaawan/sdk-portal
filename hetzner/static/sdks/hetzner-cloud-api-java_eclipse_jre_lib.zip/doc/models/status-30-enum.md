
# Status 30 Enum

## Enumeration

`Status30Enum`

## Fields

| Name |
|  --- |
| `HEALTHY` |
| `UNHEALTHY` |
| `UNKNOWN` |

## Example

```java
import cloud.hetzner.api.models.Status30Enum;

Status30Enum status30 = Status30Enum.HEALTHY;
```

