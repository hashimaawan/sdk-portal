
# V2 Projects Default Resources Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2ProjectsDefaultResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resources` | `List[str]` | Optional | A list of uniform resource names (URNs) to be added to a project.<br><br>**Constraints**: *Pattern*: `^do:(dbaas\|domain\|droplet\|floatingip\|loadbalancer\|space\|volume\|kubernetes\|vpc):.*` |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_projects_default_resources_request import V2ProjectsDefaultResourcesRequest

v_2_projects_default_resources_request = V2ProjectsDefaultResourcesRequest(
    resources=[
        'do:droplet:13457723'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

