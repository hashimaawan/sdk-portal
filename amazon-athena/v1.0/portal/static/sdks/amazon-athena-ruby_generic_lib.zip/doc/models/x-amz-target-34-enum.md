
# X Amz Target 34 Enum

## Enumeration

`XAmzTarget34Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATABASES` |

## Example

```ruby
x_amz_target34 = XAmzTarget34Enum::ENUM_AMAZONATHENALISTDATABASES
```

