
# Calculation Execution State Enum

## Enumeration

`CalculationExecutionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```php
use AmazonAthenaLib\Models\CalculationExecutionStateEnum;

$calculationExecutionState = CalculationExecutionStateEnum::COMPLETED;
```

