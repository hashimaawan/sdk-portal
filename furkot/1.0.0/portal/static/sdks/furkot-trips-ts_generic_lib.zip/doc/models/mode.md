
# Mode

travel mode

## Enumeration

`Mode`

## Fields

| Name |
|  --- |
| `Car` |
| `Motorcycle` |
| `Bicycle` |
| `Walk` |
| `Other` |

## Example

```ts
import { Mode } from 'furkot-tripslib';

const mode = Mode.Bicycle;
```

