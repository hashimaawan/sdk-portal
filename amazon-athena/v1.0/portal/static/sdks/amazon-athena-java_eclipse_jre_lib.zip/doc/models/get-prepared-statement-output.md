
# Get Prepared Statement Output

## Structure

`GetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PreparedStatement` | [`PreparedStatement1`](../../doc/models/prepared-statement-1.md) | Optional | - | PreparedStatement1 getPreparedStatement() | setPreparedStatement(PreparedStatement1 preparedStatement) |

## Example

```java
import com.amazonaws.useast1.athena.DateTimeHelper;
import com.amazonaws.useast1.athena.models.GetPreparedStatementOutput;
import com.amazonaws.useast1.athena.models.PreparedStatement1;

GetPreparedStatementOutput getPreparedStatementOutput = new GetPreparedStatementOutput.Builder()
    .preparedStatement(new PreparedStatement1.Builder()
        .statementName("StatementName4")
        .queryStatement("QueryStatement8")
        .workGroupName("WorkGroupName8")
        .description("Description0")
        .lastModifiedTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .build())
    .build();
```

