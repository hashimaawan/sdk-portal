
# X Amz Target 20

## Enumeration

`XAmzTarget20`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget20;

XAmzTarget20 xAmzTarget20 = XAmzTarget20.ENUM_AMAZONATHENAGETNAMEDQUERY;
```

