
# Images Actions Change Protection Request

*This model accepts additional fields of type Object.*

## Structure

`ImagesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the snapshot from being deleted |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
images_actions_change_protection_request = ImagesActionsChangeProtectionRequest.new(
  delete: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

