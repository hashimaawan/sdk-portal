
# Server 2

Configuration for type Server, required if type is `server`

## Structure

`Server2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the Server |

## Example

```ruby
server2 = Server2.new(
  162
)
```

