
# Type 41

## Enumeration

`Type41`

## Fields

| Name |
|  --- |
| `OPEN_CONNECTIONS` |
| `CONNECTIONS_PER_SECOND` |
| `REQUESTS_PER_SECOND` |
| `BANDWIDTH` |

## Example

```ruby
type41 = Type41::REQUESTS_PER_SECOND
```

