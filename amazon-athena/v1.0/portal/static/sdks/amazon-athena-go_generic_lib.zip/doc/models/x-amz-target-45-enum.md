
# X Amz Target 45 Enum

## Enumeration

`XAmzTarget45Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTWORKGROUPS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget45 := models.XAmzTarget45Enum_ENUMAMAZONATHENALISTWORKGROUPS

}
```

