
# V2 Volumes Snapshots Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2VolumesSnapshotsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | A human-readable name for the volume snapshot. |
| `tags` | `string[] \| null \| undefined` | Optional | A flat array of tag names as strings to be applied to the resource. Tag names may be for either existing or new tags. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2VolumesSnapshotsRequest } from 'digitalocean-apilib';

const v2VolumesSnapshotsRequest: V2VolumesSnapshotsRequest = {
  name: 'big-data-snapshot1475261774',
  tags: [
    'base-image',
    'prod'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

