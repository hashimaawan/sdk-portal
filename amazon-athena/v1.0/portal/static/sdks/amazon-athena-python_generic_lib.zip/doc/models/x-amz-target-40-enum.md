
# X Amz Target 40 Enum

## Enumeration

`XAmzTarget40Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```python
from amazonathena.models.x_amz_target_40_enum import XAmzTarget40Enum

x_amz_target_40 = XAmzTarget40Enum.ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS
```

