
# Datadog

DataDog configuration.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Datadog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `apiKey` | `string` | Required | Datadog API key. |
| `endpoint` | `string \| undefined` | Optional | Datadog HTTP log intake endpoint. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Datadog } from 'digitalocean-apilib';

const datadog: Datadog = {
  apiKey: 'abcdefghijklmnopqrstuvwxyz0123456789',
  endpoint: 'https://mydatadogendpoint.com',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

