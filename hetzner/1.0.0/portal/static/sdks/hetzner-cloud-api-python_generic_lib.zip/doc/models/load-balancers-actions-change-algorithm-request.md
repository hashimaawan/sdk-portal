
# Load Balancers Actions Change Algorithm Request

*This model accepts additional fields of type Any.*

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type39`](../../doc/models/type-39.md) | Required | Algorithm of the Load Balancer |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.load_balancers_actions_change_algorithm_request import LoadBalancersActionsChangeAlgorithmRequest
from hetznercloudapi.models.type_39 import Type39

load_balancers_actions_change_algorithm_request = LoadBalancersActionsChangeAlgorithmRequest(
    mtype=Type39.ROUND_ROBIN,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

