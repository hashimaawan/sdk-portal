
# Protocol 7

Protocol of the Load Balancer

## Enumeration

`Protocol7`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```python
from hetznercloudapi.models.protocol_7 import Protocol7

protocol_7 = Protocol7.HTTPS
```

