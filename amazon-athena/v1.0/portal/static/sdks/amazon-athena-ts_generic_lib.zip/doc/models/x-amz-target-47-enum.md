
# X Amz Target 47 Enum

## Enumeration

`XAmzTarget47Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartQueryExecution` |

## Example

```ts
import { XAmzTarget47Enum } from 'amazon-athenalib';

const xAmzTarget47 = XAmzTarget47Enum.EnumAmazonAthenaStartQueryExecution;
```

