
# X Amz Target 28

## Enumeration

`XAmzTarget28`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETTABLEMETADATA` |

## Example

```ruby
x_amz_target28 = XAmzTarget28::ENUM_AMAZONATHENAGETTABLEMETADATA
```

