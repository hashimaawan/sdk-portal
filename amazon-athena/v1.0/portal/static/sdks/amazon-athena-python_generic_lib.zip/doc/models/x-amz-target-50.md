
# X Amz Target 50

## Enumeration

`XAmzTarget50`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPQUERYEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_50 import XAmzTarget50

x_amz_target_50 = XAmzTarget50.ENUM_AMAZONATHENASTOPQUERYEXECUTION
```

