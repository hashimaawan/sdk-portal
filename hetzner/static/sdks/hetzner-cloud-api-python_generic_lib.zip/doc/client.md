
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT", "GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](../doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |

The API client can be initialized as follows:

## Code-Based Client Initialization

```python
from hetznercloudapi.configuration import Environment
from hetznercloudapi.hetznercloudapi_client import HetznercloudapiClient

client = HetznercloudapiClient(
    environment=Environment.PRODUCTION
)
```

## Environment-Based Client Initialization

```python
from hetznercloudapi.hetznercloudapi_client import HetznercloudapiClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = HetznercloudapiClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](../doc/environment-based-client-initialization.md) section for details.

## Hetzner Cloud API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| actions | Gets ActionsController |
| certificates | Gets CertificatesController |
| certificate_actions | Gets CertificateActionsController |
| datacenters | Gets DatacentersController |
| firewalls | Gets FirewallsController |
| firewall_actions | Gets FirewallActionsController |
| floating_i_ps | Gets FloatingIPsController |
| floating_ip_actions | Gets FloatingIPActionsController |
| images | Gets ImagesController |
| image_actions | Gets ImageActionsController |
| is_os | Gets ISOsController |
| load_balancers | Gets LoadBalancersController |
| load_balancer_actions | Gets LoadBalancerActionsController |
| load_balancer_types | Gets LoadBalancerTypesController |
| locations | Gets LocationsController |
| primary_i_ps | Gets PrimaryIPsController |
| primary_ip_actions | Gets PrimaryIPActionsController |
| networks | Gets NetworksController |
| network_actions | Gets NetworkActionsController |
| placement_groups | Gets PlacementGroupsController |
| pricing | Gets PricingController |
| servers | Gets ServersController |
| server_actions | Gets ServerActionsController |
| server_types | Gets ServerTypesController |
| ssh_keys | Gets SSHKeysController |
| volumes | Gets VolumesController |
| volume_actions | Gets VolumeActionsController |

