
# Firewall 4

## Structure

`Firewall4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Firewall` | `int?` | Optional | ID of the Firewall |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Firewall4 firewall4 = new Firewall4
{
    Firewall = 176,
};
```

