
# Options 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Options1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `regions` | [`Array[Region4]`](../../doc/models/region-4.md) | Optional | - |
| `sizes` | [`Array[Size1]`](../../doc/models/size-1.md) | Optional | - |
| `versions` | [`Array[AvailableUpgradeVersion]`](../../doc/models/available-upgrade-version.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
options1 = Options1.new(
  regions: [
    Region4.new(
      name: 'name0',
      slug: 'slug6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  sizes: [
    Size1.new(
      name: 'name0',
      slug: 'slug6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Size1.new(
      name: 'name0',
      slug: 'slug6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  versions: [
    AvailableUpgradeVersion.new(
      kubernetes_version: 'kubernetes_version6',
      slug: 'slug4',
      supported_features: [
        'supported_features7',
        'supported_features8'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

