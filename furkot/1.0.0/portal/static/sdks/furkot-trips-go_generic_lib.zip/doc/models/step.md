
# Step

## Structure

`Step`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Address` | `*string` | Optional | address of the stop |
| `Arrival` | `*time.Time` | Optional | arrival at the stop in its local timezone as YYYY-MM-DDThh:mm |
| `Coordinates` | [`*models.Coordinates`](../../doc/models/coordinates.md) | Optional | geographical coordinates of the stop |
| `Departure` | `*time.Time` | Optional | departure from the stop in its local timezone as YYYY-MM-DDThh:mm |
| `Name` | `*string` | Optional | name of the stop |
| `Nights` | `*int64` | Optional | number of nights |
| `Passthru` | `*bool` | Optional | true for pass-through points anchoring route |
| `Route` | [`*models.Route`](../../doc/models/route.md) | Optional | route leading to the stop |
| `Url` | `*string` | Optional | url of the page with more information about the stop |

## Example

```go
package main

import (
    "log"
    "time"
    "furkottrips/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    step := models.Step{
        Address:              models.ToPointer("address4"),
        Arrival:              models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        Coordinates:          models.ToPointer(models.Coordinates{
            Lat:                  models.ToPointer(float64(182.98)),
            Lon:                  models.ToPointer(float64(16.08)),
        }),
        Departure:            models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        Name:                 models.ToPointer("name8"),
    }

}
```

