
# Region 4

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Region4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | A DigitalOcean region where Kubernetes is available. |
| `slug` | `string \| undefined` | Optional | The identifier for a region for use when creating a new cluster. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Region4 } from 'digitalocean-apilib';

const region4: Region4 = {
  name: 'New York 3',
  slug: 'nyc3',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

