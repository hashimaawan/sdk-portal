
# Data Catalog Type Enum

## Enumeration

`DataCatalogTypeEnum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```python
from amazonathena.models.data_catalog_type_enum import DataCatalogTypeEnum

data_catalog_type = DataCatalogTypeEnum.LAMBDA
```

