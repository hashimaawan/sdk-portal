
# Get Notebook Metadata Output

## Structure

`GetNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NotebookMetadata` | [`*models.NotebookMetadata1`](../../doc/models/notebook-metadata-1.md) | Optional | - |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonathena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    getNotebookMetadataOutput := models.GetNotebookMetadataOutput{
        NotebookMetadata:     models.ToPointer(models.NotebookMetadata1{
            NotebookId:           models.ToPointer("NotebookId0"),
            Name:                 models.ToPointer("Name0"),
            WorkGroup:            models.ToPointer("WorkGroup2"),
            CreationTime:         models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
            Type:                 models.ToPointer(models.NotebookType1Enum_IPYNB),
        }),
    }

}
```

