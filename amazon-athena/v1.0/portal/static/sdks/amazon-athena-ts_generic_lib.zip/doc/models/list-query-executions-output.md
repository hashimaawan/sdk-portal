
# List Query Executions Output

## Structure

`ListQueryExecutionsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionIds` | `string[] \| undefined` | Optional | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListQueryExecutionsOutput } from 'amazon-athenalib';

const listQueryExecutionsOutput: ListQueryExecutionsOutput = {
  queryExecutionIds: [
    'QueryExecutionIds9'
  ],
  nextToken: 'NextToken2',
};
```

