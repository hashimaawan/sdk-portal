
# Health Status

*This model accepts additional fields of type unknown.*

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listenPort` | `number \| undefined` | Optional | - |
| `status` | [`Status30 \| undefined`](../../doc/models/status-30.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { HealthStatus, Status30 } from 'hetzner-cloud-apilib';

const healthStatus: HealthStatus = {
  listenPort: 443,
  status: Status30.Healthy,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

