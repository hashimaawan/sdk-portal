
# Item Type

## Enumeration

`ItemType`

## Fields

| Name |
|  --- |
| `Album` |
| `Artist` |
| `Playlist` |
| `Track` |
| `Show` |
| `Episode` |
| `Audiobook` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    itemType := models.ItemType_Artist

}
```

