
# Get Calculation Execution Code Response

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `codeBlock` | `?string` | Optional | **Constraints**: *Maximum Length*: `68000` | getCodeBlock(): ?string | setCodeBlock(?string codeBlock): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetCalculationExecutionCodeResponseBuilder;

$getCalculationExecutionCodeResponse = GetCalculationExecutionCodeResponseBuilder::init()
    ->codeBlock('CodeBlock4')
    ->build();
```

