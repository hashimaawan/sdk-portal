
# V2 Apps Metrics Bandwidth Daily Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2AppsMetricsBandwidthDailyResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appBandwidthUsage` | [`?(AppBandwidthUsage[])`](../../doc/models/app-bandwidth-usage.md) | Optional | A list of bandwidth usage details by app. | getAppBandwidthUsage(): ?array | setAppBandwidthUsage(?array appBandwidthUsage): void |
| `date` | `?DateTime` | Optional | The date for the metrics data. | getDate(): ?\DateTime | setDate(?\DateTime date): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2AppsMetricsBandwidthDailyResponseBuilder;
use DigitalOceanApiLib\Models\Builders\AppBandwidthUsageBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Utils\DateTimeHelper;

$v2AppsMetricsBandwidthDailyResponse = V2AppsMetricsBandwidthDailyResponseBuilder::init()
    ->appBandwidthUsage(
        [
            AppBandwidthUsageBuilder::init()
                ->appId('app_id4')
                ->bandwidthBytes('bandwidth_bytes6')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            AppBandwidthUsageBuilder::init()
                ->appId('app_id4')
                ->bandwidthBytes('bandwidth_bytes6')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->date(DateTimeHelper::fromRfc3339DateTime('2023-01-17T00:00:00Z'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

