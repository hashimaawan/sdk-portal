
# Get Session Request

## Structure

`GetSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getSessionRequest := models.GetSessionRequest{
        SessionId:            "SessionId2",
    }

}
```

