
# X Amz Target 7

## Enumeration

`XAmzTarget7`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreatePresignedNotebookUrl` |

## Example

```ts
import { XAmzTarget7 } from 'amazon-athenalib';

const xAmzTarget7 = XAmzTarget7.EnumAmazonAthenaCreatePresignedNotebookUrl;
```

