
# Servers Actions Reset Password Response

## Structure

`ServersActionsResetPasswordResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action`](../../doc/models/action.md) | Optional | - |
| `root_password` | `String` | Optional | Password that will be set for this Server once the Action succeeds |

## Example

```ruby
servers_actions_reset_password_response = ServersActionsResetPasswordResponse.new(
  Action.new(
    'command6',
    Error.new(
      'code2',
      'message4'
    ),
    'finished0',
    238,
    143.26,
    [
      Resource.new(
        198,
        'type0'
      ),
      Resource.new(
        198,
        'type0'
      ),
      Resource.new(
        198,
        'type0'
      )
    ],
    'started8',
    StatusEnum::RUNNING
  ),
  'zCWbFhnu950dUTko5f40'
)
```

