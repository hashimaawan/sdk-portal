
# X Amz Target 15 Enum

## Enumeration

`XAmzTarget15Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget15 := models.XAmzTarget15Enum_ENUMAMAZONATHENAGETCALCULATIONEXECUTION

}
```

