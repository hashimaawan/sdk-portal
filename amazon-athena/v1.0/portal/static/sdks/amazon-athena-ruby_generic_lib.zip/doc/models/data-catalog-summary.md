
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

*This model accepts additional fields of type Object.*

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalog_name` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `type` | [`DataCatalogType2`](../../doc/models/data-catalog-type-2.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
data_catalog_summary = DataCatalogSummary.new(
  catalog_name: 'CatalogName4',
  type: DataCatalogType2::HIVE,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

