
# Geographical Information about an App Origin

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`GeographicalInformationAboutAnAppOrigin`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `continent` | `?string` | Optional, Read-only | - | getContinent(): ?string | setContinent(?string continent): void |
| `dataCenters` | `?(string[])` | Optional, Read-only | - | getDataCenters(): ?array | setDataCenters(?array dataCenters): void |
| `default` | `?bool` | Optional, Read-only | Whether or not the region is presented as the default. | getDefault(): ?bool | setDefault(?bool default): void |
| `disabled` | `?bool` | Optional, Read-only | - | getDisabled(): ?bool | setDisabled(?bool disabled): void |
| `flag` | `?string` | Optional, Read-only | - | getFlag(): ?string | setFlag(?string flag): void |
| `label` | `?string` | Optional, Read-only | - | getLabel(): ?string | setLabel(?string label): void |
| `reason` | `?string` | Optional, Read-only | - | getReason(): ?string | setReason(?string reason): void |
| `slug` | `?string` | Optional, Read-only | - | getSlug(): ?string | setSlug(?string slug): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\GeographicalInformationAboutAnAppOriginBuilder;
use DigitalOceanApiLib\ApiHelper;

$geographicalInformationAboutAnAppOrigin = GeographicalInformationAboutAnAppOriginBuilder::init()
    ->continent('europe')
    ->dataCenters(
        [
            'ams'
        ]
    )
    ->default(true)
    ->disabled(true)
    ->flag('ams')
    ->label('ams')
    ->reason('to crowded')
    ->slug('basic')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

