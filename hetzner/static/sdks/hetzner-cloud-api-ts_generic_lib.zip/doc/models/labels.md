
# Labels

User-defined labels (key-value pairs)

## Structure

`Labels`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labelkey` | `string \| undefined` | Optional | New label |

## Example

```ts
import { Labels } from 'hetzner-cloud-apilib';

const labels: Labels = {
  labelkey: 'value',
};
```

