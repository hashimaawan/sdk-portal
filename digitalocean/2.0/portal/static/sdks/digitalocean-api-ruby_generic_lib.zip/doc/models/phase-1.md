
# Phase 1

## Enumeration

`Phase1`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING` |
| `CONFIGURING` |
| `ACTIVE` |
| `ERROR` |

## Example

```ruby
phase1 = Phase1::ERROR
```

