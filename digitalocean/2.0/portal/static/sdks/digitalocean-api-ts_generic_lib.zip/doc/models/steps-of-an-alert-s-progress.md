
# Steps of an Alert S Progress

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`StepsOfAnAlertSProgress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endedAt` | `string \| undefined` | Optional | - |
| `name` | `string \| undefined` | Optional | - |
| `reason` | [`Reason \| undefined`](../../doc/models/reason.md) | Optional | - |
| `startedAt` | `string \| undefined` | Optional | - |
| `status` | [`Status2 \| undefined`](../../doc/models/status-2.md) | Optional | **Default**: `Status2.Unknown` |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Status2, StepsOfAnAlertSProgress } from 'digitalocean-apilib';

const stepsOfAnAlertSProgress: StepsOfAnAlertSProgress = {
  endedAt: '2020-11-19T20:27:18Z',
  name: 'example_step',
  reason: {
    code: 'code2',
    message: 'message4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  startedAt: '2020-11-19T20:27:18Z',
  status: Status2.Success,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

