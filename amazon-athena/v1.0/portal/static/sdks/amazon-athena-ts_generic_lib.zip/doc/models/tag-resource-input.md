
# Tag Resource Input

## Structure

`TagResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resourceARN` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `tags` | [`Tag[]`](../../doc/models/tag.md) | Required | - |

## Example

```ts
import { TagResourceInput } from 'amazon-athenalib';

const tagResourceInput: TagResourceInput = {
  resourceARN: 'ResourceARN6',
  tags: [
    {
      key: 'Key0',
      value: 'Value6',
    }
  ],
};
```

