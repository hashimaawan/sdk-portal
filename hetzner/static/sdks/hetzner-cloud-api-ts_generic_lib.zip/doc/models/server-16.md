
# Server 16

Configuration for type Server, required if type is `server`

## Structure

`Server16`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Server |

## Example

```ts
import { Server16 } from 'hetzner-cloud-apilib';

const server16: Server16 = {
  id: 80,
};
```

