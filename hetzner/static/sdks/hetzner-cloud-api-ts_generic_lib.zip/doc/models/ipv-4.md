
# Ipv 4

IP address (v4)

## Structure

`Ipv4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dnsPtr` | `string \| null \| undefined` | Optional | Reverse DNS PTR entry for the IPv4 address of this Load Balancer |
| `ip` | `string \| null \| undefined` | Optional | IP address (v4) of this Load Balancer |

## Example

```ts
import { Ipv4 } from 'hetzner-cloud-apilib';

const ipv4: Ipv4 = {
  dnsPtr: 'lb1.example.com',
  ip: '1.2.3.4',
};
```

