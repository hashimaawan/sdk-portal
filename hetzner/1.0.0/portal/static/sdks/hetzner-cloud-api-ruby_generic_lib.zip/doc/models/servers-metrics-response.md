
# Servers Metrics Response

*This model accepts additional fields of type Object.*

## Structure

`ServersMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `metrics` | [`Metrics`](../../doc/models/metrics.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
servers_metrics_response = ServersMetricsResponse.new(
  metrics: Metrics.new(
    mend: '2017-01-01T23:00:00+00:00',
    start: '2017-01-01T00:00:00+00:00',
    step: 60,
    time_series: {
      'name_of_timeseries' => TimeSeries.new(
        values: [
          [
            1435781470.622,
            '42'
          ],
          [
            1435781471.622,
            '43'
          ]
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    },
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

