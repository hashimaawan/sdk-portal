
# X Amz Target 17 Enum

## Enumeration

`XAmzTarget17Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget17Enum;

XAmzTarget17Enum xAmzTarget17 = XAmzTarget17Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS;
```

