
# Protection 20

Protection configuration for the Server

## Structure

`Protection20`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Required | If true, prevents the Server from being deleted |
| `rebuild` | `bool` | Required | If true, prevents the Server from being rebuilt |

## Example

```python
from hetznercloudapi.models.protection_20 import Protection20

protection_20 = Protection20(
    delete=False,
    rebuild=False
)
```

