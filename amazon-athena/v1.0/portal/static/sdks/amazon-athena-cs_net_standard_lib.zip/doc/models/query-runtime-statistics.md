
# Query Runtime Statistics

The query execution timeline, statistics on input and output rows and bytes, and the different query stages that form the query execution plan.

## Structure

`QueryRuntimeStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Timeline` | [`QueryRuntimeStatisticsTimeline`](../../doc/models/query-runtime-statistics-timeline.md) | Optional | Timeline statistics such as query queue time, planning time, execution time, service processing time, and total execution time. |
| `Rows` | [`QueryRuntimeStatisticsRows`](../../doc/models/query-runtime-statistics-rows.md) | Optional | Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query. |
| `OutputStage` | [`OutputStage`](../../doc/models/output-stage.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryRuntimeStatistics queryRuntimeStatistics = new QueryRuntimeStatistics
{
    Timeline = new QueryRuntimeStatisticsTimeline
    {
        QueryQueueTimeInMillis = 156,
        QueryPlanningTimeInMillis = 82,
        EngineExecutionTimeInMillis = 112,
        ServiceProcessingTimeInMillis = 126,
        TotalExecutionTimeInMillis = 106,
    },
    Rows = new QueryRuntimeStatisticsRows
    {
        InputRows = 230,
        InputBytes = 250,
        OutputBytes = 36,
        OutputRows = 230,
    },
    OutputStage = new OutputStage
    {
        StageId = 130,
        State = "State0",
        OutputBytes = 108,
        OutputRows = 158,
        InputBytes = 190,
    },
};
```

