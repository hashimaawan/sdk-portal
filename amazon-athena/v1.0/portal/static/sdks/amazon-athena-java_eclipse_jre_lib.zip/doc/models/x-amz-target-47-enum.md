
# X Amz Target 47 Enum

## Enumeration

`XAmzTarget47Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTQUERYEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget47Enum;

XAmzTarget47Enum xAmzTarget47 = XAmzTarget47Enum.ENUM_AMAZONATHENASTARTQUERYEXECUTION;
```

