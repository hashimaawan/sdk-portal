
# Get Database Output

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | [`Database2 \| undefined`](../../doc/models/database-2.md) | Optional | - |

## Example

```ts
import { GetDatabaseOutput } from 'amazon-athenalib';

const getDatabaseOutput: GetDatabaseOutput = {
  database: {
    name: 'Name2',
    description: 'Description8',
    parameters: {},
  },
};
```

