
# Region 2

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `Cnnorth1` |
| `Cnnorthwest1` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    region2 := models.Region2_Cnnorth1

}
```

