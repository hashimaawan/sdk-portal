
# X Amz Target 55 Enum

## Enumeration

`XAmzTarget55Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_55_enum import XAmzTarget55Enum

x_amz_target_55 = XAmzTarget55Enum.ENUM_AMAZONATHENAUPDATENAMEDQUERY
```

