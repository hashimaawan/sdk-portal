# Placement Groups

```csharp
PlacementGroupsController placementGroupsController = client.PlacementGroupsController;
```

## Class Name

`PlacementGroupsController`

## Methods

* [Get All Placement Groups](../../doc/controllers/placement-groups.md#get-all-placement-groups)
* [Create a Placement Group](../../doc/controllers/placement-groups.md#create-a-placement-group)
* [Delete a Placement Group](../../doc/controllers/placement-groups.md#delete-a-placement-group)
* [Get a Placement Group](../../doc/controllers/placement-groups.md#get-a-placement-group)
* [Update a Placement Group](../../doc/controllers/placement-groups.md#update-a-placement-group)


# Get All Placement Groups

Returns all PlacementGroup objects.

```csharp
GetAllPlacementGroupsAsync(
    Models.SortEnum? sort = null,
    string name = null,
    string labelSelector = null,
    Models.ParameterType1Enum? type = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`SortEnum?`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `type` | [`ParameterType1Enum?`](../../doc/models/parameter-type-1-enum.md) | Query, Optional | Can be used multiple times. The response will only contain PlacementGroups matching the type. |

## Response Type

**200**: The `placement_groups` key contains an array of PlacementGroup objects

[`Task<Models.PlacementGroupsResponse>`](../../doc/models/placement-groups-response.md)

## Example Usage

```csharp
try
{
    PlacementGroupsResponse result = await placementGroupsController.GetAllPlacementGroupsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "placement_groups": [
    {
      "created": "2019-01-08T12:10:00+00:00",
      "id": 897,
      "labels": {
        "key": "value"
      },
      "name": "my Placement Group",
      "servers": [
        4711,
        4712
      ],
      "type": "spread"
    }
  ]
}
```


# Create a Placement Group

Creates a new PlacementGroup.

```csharp
CreateAPlacementGroupAsync(
    Models.CreatePlacementGroupRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreatePlacementGroupRequest`](../../doc/models/create-placement-group-request.md) | Body, Optional | - |

## Response Type

**201**: The `PlacementGroup` key contains the PlacementGroup that was just created.

[`Task<Models.CreatePlacementGroupResponse>`](../../doc/models/create-placement-group-response.md)

## Example Usage

```csharp
CreatePlacementGroupRequest body = new CreatePlacementGroupRequest
{
    Name = "my Placement Group",
    Type = "spread",
};

try
{
    CreatePlacementGroupResponse result = await placementGroupsController.CreateAPlacementGroupAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [],
    "type": "spread"
  }
}
```


# Delete a Placement Group

Deletes a PlacementGroup.

```csharp
DeleteAPlacementGroupAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: PlacementGroup deleted

`Task`

## Example Usage

```csharp
int id = 112;
try
{
    await placementGroupsController.DeleteAPlacementGroupAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Placement Group

Gets a specific PlacementGroup object.

```csharp
GetAPlacementGroupAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `placement_group` key contains a PlacementGroup object

[`Task<Models.PlacementGroupResponse>`](../../doc/models/placement-group-response.md)

## Example Usage

```csharp
int id = 112;
try
{
    PlacementGroupResponse result = await placementGroupsController.GetAPlacementGroupAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```


# Update a Placement Group

Updates the PlacementGroup properties.

Note that when updating labels, the PlacementGroup’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the PlacementGroup object changes during the request, the response will be a “conflict” error.

```csharp
UpdateAPlacementGroupAsync(
    int id,
    Models.UpdatePlacementGroupRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`UpdatePlacementGroupRequest`](../../doc/models/update-placement-group-request.md) | Body, Optional | - |

## Response Type

**200**: The `certificate` key contains the PlacementGroup that was just updated

[`Task<Models.PlacementGroupResponse>`](../../doc/models/placement-group-response.md)

## Example Usage

```csharp
int id = 112;
UpdatePlacementGroupRequest body = new UpdatePlacementGroupRequest
{
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "my Placement Group",
};

try
{
    PlacementGroupResponse result = await placementGroupsController.UpdateAPlacementGroupAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```

