
# Get Work Group Input

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): string | setWorkGroup(string workGroup): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetWorkGroupInputBuilder;

$getWorkGroupInput = GetWorkGroupInputBuilder::init(
    'WorkGroup8'
)->build();
```

