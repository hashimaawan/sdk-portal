
# X Amz Target 29 Enum

## Enumeration

`XAmzTarget29Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETWORKGROUP` |

## Example

```ruby
x_amz_target29 = XAmzTarget29Enum::ENUM_AMAZONATHENAGETWORKGROUP
```

