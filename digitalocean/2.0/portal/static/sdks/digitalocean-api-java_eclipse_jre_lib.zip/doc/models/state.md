
# State

A string representing the current state of the certificate. It may be `pending`, `verified`, or `error`.

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `PENDING` |
| `VERIFIED` |
| `ERROR` |

## Example

```java
import com.digitalocean.api.models.State;

State state = State.ERROR;
```

