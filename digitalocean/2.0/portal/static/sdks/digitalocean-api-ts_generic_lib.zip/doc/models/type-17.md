
# Type 17

## Enumeration

`Type17`

## Fields

| Name |
|  --- |
| `EnumV1Insightsdropletload1` |
| `EnumV1Insightsdropletload5` |
| `EnumV1Insightsdropletload15` |
| `EnumV1InsightsdropletmemoryUtilizationPercent` |
| `EnumV1InsightsdropletdiskUtilizationPercent` |
| `EnumV1Insightsdropletcpu` |
| `EnumV1InsightsdropletdiskRead` |
| `EnumV1InsightsdropletdiskWrite` |
| `EnumV1InsightsdropletpublicOutboundBandwidth` |
| `EnumV1InsightsdropletpublicInboundBandwidth` |
| `EnumV1InsightsdropletprivateOutboundBandwidth` |
| `EnumV1InsightsdropletprivateInboundBandwidth` |
| `EnumV1InsightslbaasavgCpuUtilizationPercent` |
| `EnumV1InsightslbaasconnectionUtilizationPercent` |
| `EnumV1InsightslbaasdropletHealth` |
| `EnumV1InsightslbaastlsConnectionsPerSecondUtilizationPercent` |
| `EnumV1InsightslbaasincreaseInHttpErrorRatePercentage5Xx` |
| `EnumV1InsightslbaasincreaseInHttpErrorRatePercentage4Xx` |
| `EnumV1InsightslbaasincreaseInHttpErrorRateCount5Xx` |
| `EnumV1InsightslbaasincreaseInHttpErrorRateCount4Xx` |
| `EnumV1InsightslbaashighHttpRequestResponseTime` |
| `EnumV1InsightslbaashighHttpRequestResponseTime50P` |
| `EnumV1InsightslbaashighHttpRequestResponseTime95P` |
| `EnumV1InsightslbaashighHttpRequestResponseTime99P` |
| `EnumV1Dbaasalertsload15Alerts` |
| `EnumV1DbaasalertsmemoryUtilizationAlerts` |
| `EnumV1DbaasalertsdiskUtilizationAlerts` |
| `EnumV1DbaasalertscpuAlerts` |

## Example

```ts
import { Type17 } from 'digitalocean-apilib';

const type17 = Type17.EnumV1InsightsdropletdiskUtilizationPercent;
```

