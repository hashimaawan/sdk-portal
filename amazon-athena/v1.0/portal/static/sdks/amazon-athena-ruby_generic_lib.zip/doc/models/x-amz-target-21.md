
# X Amz Target 21

## Enumeration

`XAmzTarget21`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```ruby
x_amz_target21 = XAmzTarget21::ENUM_AMAZONATHENAGETNOTEBOOKMETADATA
```

