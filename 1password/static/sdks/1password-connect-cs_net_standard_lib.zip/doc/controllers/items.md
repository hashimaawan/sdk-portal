# Items

Access and manage items inside 1Password Vaults

```csharp
ItemsApi itemsApi = client.ItemsApi;
```

## Class Name

`ItemsApi`

## Methods

* [Get Vault Items](../../doc/controllers/items.md#get-vault-items)
* [Create Vault Item](../../doc/controllers/items.md#create-vault-item)
* [Delete Vault Item](../../doc/controllers/items.md#delete-vault-item)
* [Get Vault Item by Id](../../doc/controllers/items.md#get-vault-item-by-id)
* [Patch Vault Item](../../doc/controllers/items.md#patch-vault-item)
* [Update Vault Item](../../doc/controllers/items.md#update-vault-item)


# Get Vault Items

```csharp
GetVaultItemsAsync(
    string vaultUuid,
    string filter = null)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `filter` | `string` | Query, Optional | Filter the Item collection based on Item name using SCIM eq filter |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [List<Models.Item>](../../doc/models/item.md).

## Example Usage

```csharp
string vaultUuid = "vaultUuid2";
string filter = "title eq \"Some Item Name\"";
try
{
    ApiResponse<List<Item>> result = await itemsApi.GetVaultItemsAsync(
        vaultUuid,
        filter
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Vault not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Create Vault Item

```csharp
CreateVaultItemAsync(
    string vaultUuid,
    Models.FullItem body = null)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to create an Item in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`FullItem`](../../doc/models/full-item.md) | Body, Optional | - |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.FullItem](../../doc/models/full-item.md).

## Example Usage

```csharp
string vaultUuid = "vaultUuid2";
FullItem body = new FullItem
{
    Category = Category.Membership,
    Vault = new Vault1
    {
        Id = "id6",
    },
    Favorite = false,
    Urls = new List<Url>
    {
        new Url
        {
            Href = "https://example.com",
            Primary = true,
        },
        new Url
        {
            Href = "https://example.org",
        },
    },
};

try
{
    ApiResponse<FullItem> result = await itemsApi.CreateVaultItemAsync(
        vaultUuid,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Unable to create item due to invalid input | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Delete Vault Item

```csharp
DeleteVaultItemAsync(
    string vaultUuid,
    string itemUuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault the item is in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**204**: Successfully deleted an item

`Task`

## Example Usage

```csharp
string vaultUuid = "vaultUuid2";
string itemUuid = "itemUuid6";
try
{
    await itemsApi.DeleteVaultItemAsync(
        vaultUuid,
        itemUuid
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Vault Item by Id

```csharp
GetVaultItemByIdAsync(
    string vaultUuid,
    string itemUuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Item from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to fetch<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.FullItem](../../doc/models/full-item.md).

## Example Usage

```csharp
string vaultUuid = "vaultUuid2";
string itemUuid = "itemUuid6";
try
{
    ApiResponse<FullItem> result = await itemsApi.GetVaultItemByIdAsync(
        vaultUuid,
        itemUuid
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Patch Vault Item

Applies a modified [RFC6902 JSON Patch](https://tools.ietf.org/html/rfc6902) document to an Item or ItemField. This endpoint only supports `add`, `remove` and `replace` operations.

When modifying a specific ItemField, the ItemField's ID in the `path` attribute of the operation object: `/fields/{fieldId}`

```csharp
PatchVaultItemAsync(
    string vaultUuid,
    string itemUuid,
    List<Models.Patch> body = null)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault the item is in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`List<Patch>`](../../doc/models/patch.md) | Body, Optional | - |

## Response Type

**200**: OK - Item updated. If no Patch operations were provided, Item is unmodified.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.FullItem](../../doc/models/full-item.md).

## Example Usage

```csharp
string vaultUuid = "vaultUuid2";
string itemUuid = "itemUuid6";
List<Patch> body = new List<Patch>
{
    new Patch
    {
        Op = Op.Add,
        Path = "/fields",
        MValue = ApiHelper.JsonDeserialize<object>("{\"label\":\"New Field\",\"type\":\"string\",\"value\":\"hunter2\"}"),
    },
};

try
{
    ApiResponse<FullItem> result = await itemsApi.PatchVaultItemAsync(
        vaultUuid,
        itemUuid,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Vault Item

```csharp
UpdateVaultItemAsync(
    string vaultUuid,
    string itemUuid,
    Models.FullItem body = null)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Item's Vault<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`FullItem`](../../doc/models/full-item.md) | Body, Optional | - |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.FullItem](../../doc/models/full-item.md).

## Example Usage

```csharp
string vaultUuid = "vaultUuid2";
string itemUuid = "itemUuid6";
FullItem body = new FullItem
{
    Category = Category.Membership,
    Vault = new Vault1
    {
        Id = "id6",
    },
    Favorite = false,
    Urls = new List<Url>
    {
        new Url
        {
            Href = "https://example.com",
            Primary = true,
        },
        new Url
        {
            Href = "https://example.org",
        },
    },
};

try
{
    ApiResponse<FullItem> result = await itemsApi.UpdateVaultItemAsync(
        vaultUuid,
        itemUuid,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Unable to create item due to invalid input | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

