
# Type 3

The object type.

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `USER` |

## Example

```java
import com.spotify.api.models.Type3;

Type3 type3 = Type3.USER;
```

