
# Phase

## Enumeration

`Phase`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING_BUILD` |
| `BUILDING` |
| `PENDING_DEPLOY` |
| `DEPLOYING` |
| `ACTIVE` |
| `SUPERSEDED` |
| `ERROR` |
| `CANCELED` |

## Example

```python
from digitaloceanapi.models.phase import Phase

phase = Phase.BUILDING
```

