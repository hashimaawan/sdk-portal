
# List Engine Versions Output

*This model accepts additional fields of type array.*

## Structure

`ListEngineVersionsOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `engineVersions` | [`?(EngineVersion[])`](../../doc/models/engine-version.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` | getEngineVersions(): ?array | setEngineVersions(?array engineVersions): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListEngineVersionsOutputBuilder;
use AmazonAthenaLib\Models\Builders\EngineVersionBuilder;
use AmazonAthenaLib\ApiHelper;

$listEngineVersionsOutput = ListEngineVersionsOutputBuilder::init()
    ->engineVersions(
        [
            EngineVersionBuilder::init()
                ->selectedEngineVersion('SelectedEngineVersion2')
                ->effectiveEngineVersion('EffectiveEngineVersion2')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->nextToken('NextToken0')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

