
# V2 Registry Subscription Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2RegistrySubscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription` | [`Subscription \| undefined`](../../doc/models/subscription.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2RegistrySubscriptionResponse } from 'digitalocean-apilib';

const v2RegistrySubscriptionResponse: V2RegistrySubscriptionResponse = {
  subscription: {
    createdAt: '2016-03-13T12:52:32.123Z',
    tier: {
      allowStorageOverage: false,
      includedBandwidthBytes: BigInt(46),
      includedRepositories: 68,
      includedStorageBytes: BigInt(112),
      monthlyPriceInCents: 110,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    updatedAt: '2016-03-13T12:52:32.123Z',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

