
# Create Presigned Notebook Url Response

*This model accepts additional fields of type Any.*

## Structure

`CreatePresignedNotebookUrlResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_url` | `str` | Required | - |
| `auth_token` | `str` | Required | **Constraints**: *Maximum Length*: `2048` |
| `auth_token_expiration_time` | `int` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.create_presigned_notebook_url_response import CreatePresignedNotebookUrlResponse

create_presigned_notebook_url_response = CreatePresignedNotebookUrlResponse(
    notebook_url='NotebookUrl8',
    auth_token='AuthToken2',
    auth_token_expiration_time=54,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

