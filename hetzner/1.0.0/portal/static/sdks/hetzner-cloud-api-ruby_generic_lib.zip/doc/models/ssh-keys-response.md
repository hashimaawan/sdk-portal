
# Ssh Keys Response

*This model accepts additional fields of type Object.*

## Structure

`SshKeysResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |
| `ssh_keys` | [`Array[SshKey]`](../../doc/models/ssh-key.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
ssh_keys_response = SshKeysResponse.new(
  ssh_keys: [
    SshKey.new(
      created: '2016-01-30T23:55:00+00:00',
      fingerprint: 'b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f',
      id: 42,
      labels: {
        'key0' => 'labels4',
        'key1' => 'labels5',
        'key2' => 'labels6'
      },
      name: 'my-resource',
      public_key: 'ssh-rsa AAAjjk76kgf...Xt',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  meta: Meta.new(
    pagination: Pagination.new(
      last_page: 77.7,
      next_page: 209.18,
      page: 17.58,
      per_page: 13.34,
      previous_page: 50.02,
      total_entries: 206.64,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

