
# Server Types Response 1

## Structure

`ServerTypesResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server_type` | [`ServerType`](../../doc/models/server-type.md) | Required | - |

## Example

```ruby
server_types_response1 = ServerTypesResponse1.new(
  ServerType.new(
    1,
    CpuTypeEnum::SHARED,
    false,
    'CX11',
    24,
    1,
    1,
    'cx11',
    [
      Price9.new(
        'fsn1',
        PriceHourly8.new(
          '1.1900000000000000',
          '1.0000000000'
        ),
        PriceMonthly10.new(
          '1.1900000000000000',
          '1.0000000000'
        )
      )
    ],
    StorageTypeEnum::LOCAL
  )
)
```

