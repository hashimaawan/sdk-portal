
# Status 14

The status of assigning and fetching the resources.

## Enumeration

`Status14`

## Fields

| Name |
|  --- |
| `OK` |
| `NOT_FOUND` |
| `ASSIGNED` |
| `ALREADY_ASSIGNED` |
| `SERVICE_DOWN` |

## Example

```python
from digitaloceanapi.models.status_14 import Status14

status_14 = Status14.NOT_FOUND
```

