
# Static Site

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`StaticSite`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `build_command` | `String` | Optional | An optional build command to run while building this component from source. |
| `dockerfile_path` | `String` | Optional | The path to the Dockerfile relative to the root of the repo. If set, it will be used to build this component. Otherwise, App Platform will attempt to build it using buildpacks. |
| `environment_slug` | `String` | Optional | An environment slug describing the type of this app. For a full list, please refer to [the product documentation](https://www.digitalocean.com/docs/app-platform/). |
| `envs` | [`Array[Env]`](../../doc/models/env.md) | Optional | A list of environment variables made available to the component. |
| `git` | [`Git`](../../doc/models/git.md) | Optional | - |
| `github` | [`Github`](../../doc/models/github.md) | Optional | - |
| `gitlab` | [`Gitlab`](../../doc/models/gitlab.md) | Optional | - |
| `image` | [`Image`](../../doc/models/image.md) | Optional | - |
| `log_destinations` | [`ConfigurationsForExternalLogging`](../../doc/models/configurations-for-external-logging.md) | Optional | - |
| `name` | `String` | Required | The name. Must be unique across all components within the same app.<br><br>**Constraints**: *Minimum Length*: `2`, *Maximum Length*: `32`, *Pattern*: `^[a-z][a-z0-9-]{0,30}[a-z0-9]$` |
| `run_command` | `String` | Optional | An optional run command to override the component's default. |
| `source_dir` | `String` | Optional | An optional path to the working directory to use for the build. For Dockerfile builds, this will be used as the build context. Must be relative to the root of the repo. |
| `catchall_document` | `String` | Optional | The name of the document to use as the fallback for any requests to documents that are not found when serving this static site. Only 1 of `catchall_document` or `error_document` can be set. |
| `cors` | [`Cors`](../../doc/models/cors.md) | Optional | - |
| `error_document` | `String` | Optional | The name of the error document to use when serving this static site. Default: 404.html. If no such file exists within the built assets, App Platform will supply one.<br><br>**Default**: `'404.html'` |
| `index_document` | `String` | Optional | The name of the index document to use when serving this static site. Default: index.html<br><br>**Default**: `'index.html'` |
| `output_dir` | `String` | Optional | An optional path to where the built assets will be located, relative to the build context. If not set, App Platform will automatically scan for these directory names: `_static`, `dist`, `public`, `build`. |
| `routes` | [`Array[ACriterionForRoutingHttpTrafficToAComponent]`](../../doc/models/a-criterion-for-routing-http-traffic-to-a-component.md) | Optional | A list of HTTP routes that should be routed to this component. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
static_site = StaticSite.new(
  name: 'api',
  build_command: 'npm run build',
  dockerfile_path: 'path/to/Dockerfile',
  environment_slug: 'node-js',
  envs: [
    Env.new(
      key: 'key2',
      scope: Scope::UNSET,
      type: Type2::GENERAL,
      value: 'value4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Env.new(
      key: 'key2',
      scope: Scope::UNSET,
      type: Type2::GENERAL,
      value: 'value4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Env.new(
      key: 'key2',
      scope: Scope::UNSET,
      type: Type2::GENERAL,
      value: 'value4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  git: Git.new(
    branch: 'branch8',
    repo_clone_url: 'repo_clone_url8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  run_command: 'bin/api',
  source_dir: 'path/to/dir',
  catchall_document: 'index.html',
  error_document: 'error.html',
  index_document: 'main.html',
  output_dir: 'dist/',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

