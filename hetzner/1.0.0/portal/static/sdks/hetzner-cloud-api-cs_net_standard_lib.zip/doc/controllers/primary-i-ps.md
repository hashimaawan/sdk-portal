# Primary I Ps

```csharp
PrimaryIPsApi primaryIPsApi = client.PrimaryIPsApi;
```

## Class Name

`PrimaryIPsApi`

## Methods

* [Get All Primary I Ps](../../doc/controllers/primary-i-ps.md#get-all-primary-i-ps)
* [Create a Primary IP](../../doc/controllers/primary-i-ps.md#create-a-primary-ip)
* [Delete a Primary IP](../../doc/controllers/primary-i-ps.md#delete-a-primary-ip)
* [Get a Primary IP](../../doc/controllers/primary-i-ps.md#get-a-primary-ip)
* [Update a Primary IP](../../doc/controllers/primary-i-ps.md#update-a-primary-ip)


# Get All Primary I Ps

Returns all Primary IP objects.

```csharp
GetAllPrimaryIPsAsync(
    string name = null,
    string labelSelector = null,
    string ip = null,
    Models.Sort2? sort = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `ip` | `string` | Query, Optional | Can be used to filter resources by their ip. The response will only contain the resources matching the specified ip. |
| `sort` | [`Sort2?`](../../doc/models/sort-2.md) | Query, Optional | Can be used multiple times. Choices id id:asc id:desc created created:asc created:desc |

## Response Type

**200**: The `primary_ips` key contains an array of Primary IP objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.PrimaryIPsResponse](../../doc/models/primary-i-ps-response.md).

## Example Usage

```csharp
string ip = "127.0.0.1";
try
{
    ApiResponse<PrimaryIPsResponse> result = await primaryIPsApi.GetAllPrimaryIPsAsync(
        null,
        null,
        ip
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Create a Primary IP

Creates a new Primary IP, optionally assigned to a Server.

If you want to create a Primary IP that is not assigned to a Server, you need to provide the `datacenter` key instead of `assignee_id`. This can be either the ID or the name of the Datacenter this Primary IP shall be created in.

Note that a Primary IP can only be assigned to a Server in the same Datacenter later on.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_not_stopped`          | The specified server is running, but needs to be powered off  |
| `server_has_ipv4`             | The server already has an ipv4 address                        |
| `server_has_ipv6`             | The server already has an ipv6 address                        |

```csharp
CreateAPrimaryIpAsync(
    Models.CreatePrimaryIpRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreatePrimaryIpRequest`](../../doc/models/create-primary-ip-request.md) | Body, Optional | The `type` argument is required while `datacenter` and `assignee_id` are mutually exclusive. |

## Response Type

**201**: The `primary_ip` key contains the Primary IP that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.CreatePrimaryIpResponse](../../doc/models/create-primary-ip-response.md).

## Example Usage

```csharp
CreatePrimaryIpRequest body = new CreatePrimaryIpRequest
{
    AssigneeType = "server",
    Name = "my-ip",
    Type = Type51.Ipv4,
    AssigneeId = 17,
    AutoDelete = false,
    Datacenter = "fsn1-dc8",
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
};

try
{
    ApiResponse<CreatePrimaryIpResponse> result = await primaryIPsApi.CreateAPrimaryIpAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_primary_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 17,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "primary_ip": {
    "assignee_id": 17,
    "assignee_type": "server",
    "auto_delete": true,
    "blocked": false,
    "created": "2016-01-30T23:50:00+00:00",
    "datacenter": {
      "description": "Falkenstein DC Park 8",
      "id": 42,
      "location": {
        "city": "Falkenstein",
        "country": "DE",
        "description": "Falkenstein DC Park 1",
        "id": 1,
        "latitude": 50.47612,
        "longitude": 12.370071,
        "name": "fsn1",
        "network_zone": "eu-central"
      },
      "name": "fsn1-dc8",
      "server_types": {
        "available": [
          1,
          2,
          3
        ],
        "available_for_migration": [
          1,
          2,
          3
        ],
        "supported": [
          1,
          2,
          3
        ]
      }
    },
    "dns_ptr": [
      {
        "dns_ptr": "server.example.com",
        "ip": "2001:db8::1"
      }
    ],
    "id": 42,
    "ip": "131.232.99.1",
    "labels": {
      "labelkey": "value"
    },
    "name": "my-ip",
    "protection": {
      "delete": false
    },
    "type": "ipv4"
  }
}
```


# Delete a Primary IP

Deletes a Primary IP.

The Primary IP may be assigned to a Server. In this case it is unassigned automatically. The Server must be powered off (status `off`) in order for this operation to succeed.

```csharp
DeleteAPrimaryIpAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Primary IP deleted

`Task`

## Example Usage

```csharp
int id = 112;
try
{
    await primaryIPsApi.DeleteAPrimaryIpAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Primary IP

Returns a specific Primary IP object.

```csharp
GetAPrimaryIpAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `primary_ip` key contains a Primary IP object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.PrimaryIpResponse](../../doc/models/primary-ip-response.md).

## Example Usage

```csharp
int id = 112;
try
{
    ApiResponse<PrimaryIpResponse> result = await primaryIPsApi.GetAPrimaryIpAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Update a Primary IP

Updates the Primary IP.

Note that when updating labels, the Primary IP's current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

If the Primary IP object changes during the request, the response will be a “conflict” error.

```csharp
UpdateAPrimaryIpAsync(
    int id,
    Models.UpdatePrimaryIpRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`UpdatePrimaryIpRequest`](../../doc/models/update-primary-ip-request.md) | Body, Optional | - |

## Response Type

**200**: The `primary_ip` key contains the Primary IP that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.PrimaryIpResponse](../../doc/models/primary-ip-response.md).

## Example Usage

```csharp
int id = 112;
UpdatePrimaryIpRequest body = new UpdatePrimaryIpRequest
{
    AutoDelete = true,
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "my-ip",
};

try
{
    ApiResponse<PrimaryIpResponse> result = await primaryIPsApi.UpdateAPrimaryIpAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

