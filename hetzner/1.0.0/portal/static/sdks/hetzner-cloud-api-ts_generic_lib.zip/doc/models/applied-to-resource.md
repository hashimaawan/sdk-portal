
# Applied to Resource

*This model accepts additional fields of type unknown.*

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server` | [`Server \| undefined`](../../doc/models/server.md) | Optional | - |
| `type` | [`Type5 \| undefined`](../../doc/models/type-5.md) | Optional | Type of resource referenced |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AppliedToResource, Type5 } from 'hetzner-cloud-apilib';

const appliedToResource: AppliedToResource = {
  server: {
    id: 14,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  type: Type5.Server,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

