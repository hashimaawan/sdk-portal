
# Get Calculation Execution Request

## Structure

`GetCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getCalculationExecutionRequest := models.GetCalculationExecutionRequest{
        CalculationExecutionId: "CalculationExecutionId2",
    }

}
```

