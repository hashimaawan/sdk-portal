# API

```python
client_api = client.client
```

## Class Name

`Api`

## Methods

* [Batch Get Named Query](../../doc/controllers/api.md#batch-get-named-query)
* [Batch Get Prepared Statement](../../doc/controllers/api.md#batch-get-prepared-statement)
* [Batch Get Query Execution](../../doc/controllers/api.md#batch-get-query-execution)
* [Create Data Catalog](../../doc/controllers/api.md#create-data-catalog)
* [Create Named Query](../../doc/controllers/api.md#create-named-query)
* [Create Notebook](../../doc/controllers/api.md#create-notebook)
* [Create Prepared Statement](../../doc/controllers/api.md#create-prepared-statement)
* [Create Presigned Notebook Url](../../doc/controllers/api.md#create-presigned-notebook-url)
* [Create Work Group](../../doc/controllers/api.md#create-work-group)
* [Delete Data Catalog](../../doc/controllers/api.md#delete-data-catalog)
* [Delete Named Query](../../doc/controllers/api.md#delete-named-query)
* [Delete Notebook](../../doc/controllers/api.md#delete-notebook)
* [Delete Prepared Statement](../../doc/controllers/api.md#delete-prepared-statement)
* [Delete Work Group](../../doc/controllers/api.md#delete-work-group)
* [Export Notebook](../../doc/controllers/api.md#export-notebook)
* [Get Calculation Execution](../../doc/controllers/api.md#get-calculation-execution)
* [Get Calculation Execution Code](../../doc/controllers/api.md#get-calculation-execution-code)
* [Get Calculation Execution Status](../../doc/controllers/api.md#get-calculation-execution-status)
* [Get Data Catalog](../../doc/controllers/api.md#get-data-catalog)
* [Get Database](../../doc/controllers/api.md#get-database)
* [Get Named Query](../../doc/controllers/api.md#get-named-query)
* [Get Notebook Metadata](../../doc/controllers/api.md#get-notebook-metadata)
* [Get Prepared Statement](../../doc/controllers/api.md#get-prepared-statement)
* [Get Query Execution](../../doc/controllers/api.md#get-query-execution)
* [Get Query Results](../../doc/controllers/api.md#get-query-results)
* [Get Query Runtime Statistics](../../doc/controllers/api.md#get-query-runtime-statistics)
* [Get Session](../../doc/controllers/api.md#get-session)
* [Get Session Status](../../doc/controllers/api.md#get-session-status)
* [Get Table Metadata](../../doc/controllers/api.md#get-table-metadata)
* [Get Work Group](../../doc/controllers/api.md#get-work-group)
* [Import Notebook](../../doc/controllers/api.md#import-notebook)
* [List Application DPU Sizes](../../doc/controllers/api.md#list-application-dpu-sizes)
* [List Calculation Executions](../../doc/controllers/api.md#list-calculation-executions)
* [List Data Catalogs](../../doc/controllers/api.md#list-data-catalogs)
* [List Databases](../../doc/controllers/api.md#list-databases)
* [List Engine Versions](../../doc/controllers/api.md#list-engine-versions)
* [List Executors](../../doc/controllers/api.md#list-executors)
* [List Named Queries](../../doc/controllers/api.md#list-named-queries)
* [List Notebook Metadata](../../doc/controllers/api.md#list-notebook-metadata)
* [List Notebook Sessions](../../doc/controllers/api.md#list-notebook-sessions)
* [List Prepared Statements](../../doc/controllers/api.md#list-prepared-statements)
* [List Query Executions](../../doc/controllers/api.md#list-query-executions)
* [List Sessions](../../doc/controllers/api.md#list-sessions)
* [List Table Metadata](../../doc/controllers/api.md#list-table-metadata)
* [List Tags for Resource](../../doc/controllers/api.md#list-tags-for-resource)
* [List Work Groups](../../doc/controllers/api.md#list-work-groups)
* [Start Calculation Execution](../../doc/controllers/api.md#start-calculation-execution)
* [Start Query Execution](../../doc/controllers/api.md#start-query-execution)
* [Start Session](../../doc/controllers/api.md#start-session)
* [Stop Calculation Execution](../../doc/controllers/api.md#stop-calculation-execution)
* [Stop Query Execution](../../doc/controllers/api.md#stop-query-execution)
* [Tag Resource](../../doc/controllers/api.md#tag-resource)
* [Terminate Session](../../doc/controllers/api.md#terminate-session)
* [Untag Resource](../../doc/controllers/api.md#untag-resource)
* [Update Data Catalog](../../doc/controllers/api.md#update-data-catalog)
* [Update Named Query](../../doc/controllers/api.md#update-named-query)
* [Update Notebook](../../doc/controllers/api.md#update-notebook)
* [Update Notebook Metadata](../../doc/controllers/api.md#update-notebook-metadata)
* [Update Prepared Statement](../../doc/controllers/api.md#update-prepared-statement)
* [Update Work Group](../../doc/controllers/api.md#update-work-group)


# Batch Get Named Query

Returns the details of a single named query or a list of up to 50 queries, which you provide as an array of query ID strings. Requires you to have access to the workgroup in which the queries were saved. Use <a>ListNamedQueriesInput</a> to get the list of named query IDs in the specified workgroup. If information could not be retrieved for a submitted query ID, information about the query ID submitted is listed under <a>UnprocessedNamedQueryId</a>. Named queries differ from executed queries. Use <a>BatchGetQueryExecutionInput</a> to get details about each unique query execution, and <a>ListQueryExecutionsInput</a> to get a list of query execution IDs.

```python
def batch_get_named_query(self,
                         x_amz_target,
                         body,
                         x_amz_content_sha_256=None,
                         x_amz_date=None,
                         x_amz_algorithm=None,
                         x_amz_credential=None,
                         x_amz_security_token=None,
                         x_amz_signature=None,
                         x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget`](../../doc/models/x-amz-target.md) | Header, Required | - |
| `body` | [`BatchGetNamedQueryInput`](../../doc/models/batch-get-named-query-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`BatchGetNamedQueryOutput`](../../doc/models/batch-get-named-query-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget.ENUM_AMAZONATHENABATCHGETNAMEDQUERY

body = BatchGetNamedQueryInput(
    named_query_ids=[
        'NamedQueryIds9'
    ]
)

result = client_api.batch_get_named_query(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Batch Get Prepared Statement

Returns the details of a single prepared statement or a list of up to 256 prepared statements for the array of prepared statement names that you provide. Requires you to have access to the workgroup to which the prepared statements belong. If a prepared statement cannot be retrieved for the name specified, the statement is listed in <code>UnprocessedPreparedStatementNames</code>.

```python
def batch_get_prepared_statement(self,
                                x_amz_target,
                                body,
                                x_amz_content_sha_256=None,
                                x_amz_date=None,
                                x_amz_algorithm=None,
                                x_amz_credential=None,
                                x_amz_security_token=None,
                                x_amz_signature=None,
                                x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget1`](../../doc/models/x-amz-target-1.md) | Header, Required | - |
| `body` | [`BatchGetPreparedStatementInput`](../../doc/models/batch-get-prepared-statement-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`BatchGetPreparedStatementOutput`](../../doc/models/batch-get-prepared-statement-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget1.ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT

body = BatchGetPreparedStatementInput(
    prepared_statement_names=[
        'PreparedStatementNames0',
        'PreparedStatementNames1',
        'PreparedStatementNames2'
    ],
    work_group='WorkGroup8'
)

result = client_api.batch_get_prepared_statement(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Batch Get Query Execution

Returns the details of a single query execution or a list of up to 50 query executions, which you provide as an array of query execution ID strings. Requires you to have access to the workgroup in which the queries ran. To get a list of query execution IDs, use <a>ListQueryExecutionsInput$WorkGroup</a>. Query executions differ from named (saved) queries. Use <a>BatchGetNamedQueryInput</a> to get details about named queries.

```python
def batch_get_query_execution(self,
                             x_amz_target,
                             body,
                             x_amz_content_sha_256=None,
                             x_amz_date=None,
                             x_amz_algorithm=None,
                             x_amz_credential=None,
                             x_amz_security_token=None,
                             x_amz_signature=None,
                             x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget2`](../../doc/models/x-amz-target-2.md) | Header, Required | - |
| `body` | [`BatchGetQueryExecutionInput`](../../doc/models/batch-get-query-execution-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`BatchGetQueryExecutionOutput`](../../doc/models/batch-get-query-execution-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget2.ENUM_AMAZONATHENABATCHGETQUERYEXECUTION

body = BatchGetQueryExecutionInput(
    query_execution_ids=[
        'QueryExecutionIds3'
    ]
)

result = client_api.batch_get_query_execution(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Data Catalog

Creates (registers) a data catalog with the specified name and properties. Catalogs created are visible to all users of the same Amazon Web Services account.

```python
def create_data_catalog(self,
                       x_amz_target,
                       body,
                       x_amz_content_sha_256=None,
                       x_amz_date=None,
                       x_amz_algorithm=None,
                       x_amz_credential=None,
                       x_amz_security_token=None,
                       x_amz_signature=None,
                       x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget3`](../../doc/models/x-amz-target-3.md) | Header, Required | - |
| `body` | [`CreateDataCatalogInput`](../../doc/models/create-data-catalog-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget3.ENUM_AMAZONATHENACREATEDATACATALOG

body = CreateDataCatalogInput(
    name='Name6',
    mtype=DataCatalogType1.HIVE
)

result = client_api.create_data_catalog(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Named Query

<p>Creates a named query in the specified workgroup. Requires that you have access to the workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```python
def create_named_query(self,
                      x_amz_target,
                      body,
                      x_amz_content_sha_256=None,
                      x_amz_date=None,
                      x_amz_algorithm=None,
                      x_amz_credential=None,
                      x_amz_security_token=None,
                      x_amz_signature=None,
                      x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget4`](../../doc/models/x-amz-target-4.md) | Header, Required | - |
| `body` | [`CreateNamedQueryInput`](../../doc/models/create-named-query-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`CreateNamedQueryOutput`](../../doc/models/create-named-query-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget4.ENUM_AMAZONATHENACREATENAMEDQUERY

body = CreateNamedQueryInput(
    name='Name6',
    database='Database4',
    query_string='QueryString8'
)

result = client_api.create_named_query(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Notebook

Creates an empty <code>ipynb</code> file in the specified Apache Spark enabled workgroup. Throws an error if a file in the workgroup with the same name already exists.

```python
def create_notebook(self,
                   x_amz_target,
                   body,
                   x_amz_content_sha_256=None,
                   x_amz_date=None,
                   x_amz_algorithm=None,
                   x_amz_credential=None,
                   x_amz_security_token=None,
                   x_amz_signature=None,
                   x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget5`](../../doc/models/x-amz-target-5.md) | Header, Required | - |
| `body` | [`CreateNotebookInput`](../../doc/models/create-notebook-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`CreateNotebookOutput`](../../doc/models/create-notebook-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget5.ENUM_AMAZONATHENACREATENOTEBOOK

body = CreateNotebookInput(
    work_group='WorkGroup8',
    name='Name6'
)

result = client_api.create_notebook(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Create Prepared Statement

Creates a prepared statement for use with SQL queries in Athena.

```python
def create_prepared_statement(self,
                             x_amz_target,
                             body,
                             x_amz_content_sha_256=None,
                             x_amz_date=None,
                             x_amz_algorithm=None,
                             x_amz_credential=None,
                             x_amz_security_token=None,
                             x_amz_signature=None,
                             x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget6`](../../doc/models/x-amz-target-6.md) | Header, Required | - |
| `body` | [`CreatePreparedStatementInput`](../../doc/models/create-prepared-statement-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget6.ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT

body = CreatePreparedStatementInput(
    statement_name='StatementName4',
    work_group='WorkGroup8',
    query_statement='QueryStatement8'
)

result = client_api.create_prepared_statement(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Presigned Notebook Url

Gets an authentication token and the URL at which the notebook can be accessed. During programmatic access, <code>CreatePresignedNotebookUrl</code> must be called every 10 minutes to refresh the authentication token. For information about granting programmatic access, see <a href="https://docs.aws.amazon.com/athena/latest/ug/setting-up.html#setting-up-grant-programmatic-access">Grant programmatic access</a>.

```python
def create_presigned_notebook_url(self,
                                 x_amz_target,
                                 body,
                                 x_amz_content_sha_256=None,
                                 x_amz_date=None,
                                 x_amz_algorithm=None,
                                 x_amz_credential=None,
                                 x_amz_security_token=None,
                                 x_amz_signature=None,
                                 x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget7`](../../doc/models/x-amz-target-7.md) | Header, Required | - |
| `body` | [`CreatePresignedNotebookUrlRequest`](../../doc/models/create-presigned-notebook-url-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`CreatePresignedNotebookUrlResponse`](../../doc/models/create-presigned-notebook-url-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget7.ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL

body = CreatePresignedNotebookUrlRequest(
    session_id='SessionId2'
)

result = client_api.create_presigned_notebook_url(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Create Work Group

Creates a workgroup with the specified name. A workgroup can be an Apache Spark enabled workgroup or an Athena SQL workgroup.

```python
def create_work_group(self,
                     x_amz_target,
                     body,
                     x_amz_content_sha_256=None,
                     x_amz_date=None,
                     x_amz_algorithm=None,
                     x_amz_credential=None,
                     x_amz_security_token=None,
                     x_amz_signature=None,
                     x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget8`](../../doc/models/x-amz-target-8.md) | Header, Required | - |
| `body` | [`CreateWorkGroupInput`](../../doc/models/create-work-group-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget8.ENUM_AMAZONATHENACREATEWORKGROUP

body = CreateWorkGroupInput(
    name='Name6'
)

result = client_api.create_work_group(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Data Catalog

Deletes a data catalog.

```python
def delete_data_catalog(self,
                       x_amz_target,
                       body,
                       x_amz_content_sha_256=None,
                       x_amz_date=None,
                       x_amz_algorithm=None,
                       x_amz_credential=None,
                       x_amz_security_token=None,
                       x_amz_signature=None,
                       x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget9`](../../doc/models/x-amz-target-9.md) | Header, Required | - |
| `body` | [`DeleteDataCatalogInput`](../../doc/models/delete-data-catalog-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget9.ENUM_AMAZONATHENADELETEDATACATALOG

body = DeleteDataCatalogInput(
    name='Name6'
)

result = client_api.delete_data_catalog(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Named Query

<p>Deletes the named query if you have access to the workgroup in which the query was saved.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```python
def delete_named_query(self,
                      x_amz_target,
                      body,
                      x_amz_content_sha_256=None,
                      x_amz_date=None,
                      x_amz_algorithm=None,
                      x_amz_credential=None,
                      x_amz_security_token=None,
                      x_amz_signature=None,
                      x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget10`](../../doc/models/x-amz-target-10.md) | Header, Required | - |
| `body` | [`DeleteNamedQueryInput`](../../doc/models/delete-named-query-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget10.ENUM_AMAZONATHENADELETENAMEDQUERY

body = DeleteNamedQueryInput(
    named_query_id='NamedQueryId6'
)

result = client_api.delete_named_query(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Notebook

Deletes the specified notebook.

```python
def delete_notebook(self,
                   x_amz_target,
                   body,
                   x_amz_content_sha_256=None,
                   x_amz_date=None,
                   x_amz_algorithm=None,
                   x_amz_credential=None,
                   x_amz_security_token=None,
                   x_amz_signature=None,
                   x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget11`](../../doc/models/x-amz-target-11.md) | Header, Required | - |
| `body` | [`DeleteNotebookInput`](../../doc/models/delete-notebook-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget11.ENUM_AMAZONATHENADELETENOTEBOOK

body = DeleteNotebookInput(
    notebook_id='NotebookId6'
)

result = client_api.delete_notebook(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Delete Prepared Statement

Deletes the prepared statement with the specified name from the specified workgroup.

```python
def delete_prepared_statement(self,
                             x_amz_target,
                             body,
                             x_amz_content_sha_256=None,
                             x_amz_date=None,
                             x_amz_algorithm=None,
                             x_amz_credential=None,
                             x_amz_security_token=None,
                             x_amz_signature=None,
                             x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget12`](../../doc/models/x-amz-target-12.md) | Header, Required | - |
| `body` | [`DeletePreparedStatementInput`](../../doc/models/delete-prepared-statement-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget12.ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT

body = DeletePreparedStatementInput(
    statement_name='StatementName4',
    work_group='WorkGroup8'
)

result = client_api.delete_prepared_statement(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Delete Work Group

Deletes the workgroup with the specified name. The primary workgroup cannot be deleted.

```python
def delete_work_group(self,
                     x_amz_target,
                     body,
                     x_amz_content_sha_256=None,
                     x_amz_date=None,
                     x_amz_algorithm=None,
                     x_amz_credential=None,
                     x_amz_security_token=None,
                     x_amz_signature=None,
                     x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget13`](../../doc/models/x-amz-target-13.md) | Header, Required | - |
| `body` | [`DeleteWorkGroupInput`](../../doc/models/delete-work-group-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget13.ENUM_AMAZONATHENADELETEWORKGROUP

body = DeleteWorkGroupInput(
    work_group='WorkGroup8'
)

result = client_api.delete_work_group(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Export Notebook

Exports the specified notebook and its metadata.

```python
def export_notebook(self,
                   x_amz_target,
                   body,
                   x_amz_content_sha_256=None,
                   x_amz_date=None,
                   x_amz_algorithm=None,
                   x_amz_credential=None,
                   x_amz_security_token=None,
                   x_amz_signature=None,
                   x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget14`](../../doc/models/x-amz-target-14.md) | Header, Required | - |
| `body` | [`ExportNotebookInput`](../../doc/models/export-notebook-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ExportNotebookOutput`](../../doc/models/export-notebook-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget14.ENUM_AMAZONATHENAEXPORTNOTEBOOK

body = ExportNotebookInput(
    notebook_id='NotebookId6'
)

result = client_api.export_notebook(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Calculation Execution

Describes a previously submitted calculation execution.

```python
def get_calculation_execution(self,
                             x_amz_target,
                             body,
                             x_amz_content_sha_256=None,
                             x_amz_date=None,
                             x_amz_algorithm=None,
                             x_amz_credential=None,
                             x_amz_security_token=None,
                             x_amz_signature=None,
                             x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget15`](../../doc/models/x-amz-target-15.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionRequest`](../../doc/models/get-calculation-execution-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetCalculationExecutionResponse`](../../doc/models/get-calculation-execution-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget15.ENUM_AMAZONATHENAGETCALCULATIONEXECUTION

body = GetCalculationExecutionRequest(
    calculation_execution_id='CalculationExecutionId8'
)

result = client_api.get_calculation_execution(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Calculation Execution Code

Retrieves the unencrypted code that was executed for the calculation.

```python
def get_calculation_execution_code(self,
                                  x_amz_target,
                                  body,
                                  x_amz_content_sha_256=None,
                                  x_amz_date=None,
                                  x_amz_algorithm=None,
                                  x_amz_credential=None,
                                  x_amz_security_token=None,
                                  x_amz_signature=None,
                                  x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget16`](../../doc/models/x-amz-target-16.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionCodeRequest`](../../doc/models/get-calculation-execution-code-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetCalculationExecutionCodeResponse`](../../doc/models/get-calculation-execution-code-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget16.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE

body = GetCalculationExecutionCodeRequest(
    calculation_execution_id='CalculationExecutionId8'
)

result = client_api.get_calculation_execution_code(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Calculation Execution Status

Gets the status of a current calculation.

```python
def get_calculation_execution_status(self,
                                    x_amz_target,
                                    body,
                                    x_amz_content_sha_256=None,
                                    x_amz_date=None,
                                    x_amz_algorithm=None,
                                    x_amz_credential=None,
                                    x_amz_security_token=None,
                                    x_amz_signature=None,
                                    x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget17`](../../doc/models/x-amz-target-17.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionStatusRequest`](../../doc/models/get-calculation-execution-status-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetCalculationExecutionStatusResponse`](../../doc/models/get-calculation-execution-status-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget17.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS

body = GetCalculationExecutionStatusRequest(
    calculation_execution_id='CalculationExecutionId8'
)

result = client_api.get_calculation_execution_status(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Data Catalog

Returns the specified data catalog.

```python
def get_data_catalog(self,
                    x_amz_target,
                    body,
                    x_amz_content_sha_256=None,
                    x_amz_date=None,
                    x_amz_algorithm=None,
                    x_amz_credential=None,
                    x_amz_security_token=None,
                    x_amz_signature=None,
                    x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget18`](../../doc/models/x-amz-target-18.md) | Header, Required | - |
| `body` | [`GetDataCatalogInput`](../../doc/models/get-data-catalog-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetDataCatalogOutput`](../../doc/models/get-data-catalog-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget18.ENUM_AMAZONATHENAGETDATACATALOG

body = GetDataCatalogInput(
    name='Name6'
)

result = client_api.get_data_catalog(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Database

Returns a database object for the specified database and data catalog.

```python
def get_database(self,
                x_amz_target,
                body,
                x_amz_content_sha_256=None,
                x_amz_date=None,
                x_amz_algorithm=None,
                x_amz_credential=None,
                x_amz_security_token=None,
                x_amz_signature=None,
                x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget19`](../../doc/models/x-amz-target-19.md) | Header, Required | - |
| `body` | [`GetDatabaseInput`](../../doc/models/get-database-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetDatabaseOutput`](../../doc/models/get-database-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget19.ENUM_AMAZONATHENAGETDATABASE

body = GetDatabaseInput(
    catalog_name='CatalogName0',
    database_name='DatabaseName0'
)

result = client_api.get_database(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# Get Named Query

Returns information about a single query. Requires that you have access to the workgroup in which the query was saved.

```python
def get_named_query(self,
                   x_amz_target,
                   body,
                   x_amz_content_sha_256=None,
                   x_amz_date=None,
                   x_amz_algorithm=None,
                   x_amz_credential=None,
                   x_amz_security_token=None,
                   x_amz_signature=None,
                   x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget20`](../../doc/models/x-amz-target-20.md) | Header, Required | - |
| `body` | [`GetNamedQueryInput`](../../doc/models/get-named-query-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetNamedQueryOutput`](../../doc/models/get-named-query-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget20.ENUM_AMAZONATHENAGETNAMEDQUERY

body = GetNamedQueryInput(
    named_query_id='NamedQueryId6'
)

result = client_api.get_named_query(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Notebook Metadata

Retrieves notebook metadata for the specified notebook ID.

```python
def get_notebook_metadata(self,
                         x_amz_target,
                         body,
                         x_amz_content_sha_256=None,
                         x_amz_date=None,
                         x_amz_algorithm=None,
                         x_amz_credential=None,
                         x_amz_security_token=None,
                         x_amz_signature=None,
                         x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget21`](../../doc/models/x-amz-target-21.md) | Header, Required | - |
| `body` | [`GetNotebookMetadataInput`](../../doc/models/get-notebook-metadata-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetNotebookMetadataOutput`](../../doc/models/get-notebook-metadata-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget21.ENUM_AMAZONATHENAGETNOTEBOOKMETADATA

body = GetNotebookMetadataInput(
    notebook_id='NotebookId6'
)

result = client_api.get_notebook_metadata(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Prepared Statement

Retrieves the prepared statement with the specified name from the specified workgroup.

```python
def get_prepared_statement(self,
                          x_amz_target,
                          body,
                          x_amz_content_sha_256=None,
                          x_amz_date=None,
                          x_amz_algorithm=None,
                          x_amz_credential=None,
                          x_amz_security_token=None,
                          x_amz_signature=None,
                          x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget22`](../../doc/models/x-amz-target-22.md) | Header, Required | - |
| `body` | [`GetPreparedStatementInput`](../../doc/models/get-prepared-statement-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetPreparedStatementOutput`](../../doc/models/get-prepared-statement-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget22.ENUM_AMAZONATHENAGETPREPAREDSTATEMENT

body = GetPreparedStatementInput(
    statement_name='StatementName4',
    work_group='WorkGroup8'
)

result = client_api.get_prepared_statement(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Query Execution

Returns information about a single execution of a query if you have access to the workgroup in which the query ran. Each time a query executes, information about the query execution is saved with a unique ID.

```python
def get_query_execution(self,
                       x_amz_target,
                       body,
                       x_amz_content_sha_256=None,
                       x_amz_date=None,
                       x_amz_algorithm=None,
                       x_amz_credential=None,
                       x_amz_security_token=None,
                       x_amz_signature=None,
                       x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget23`](../../doc/models/x-amz-target-23.md) | Header, Required | - |
| `body` | [`GetQueryExecutionInput`](../../doc/models/get-query-execution-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetQueryExecutionOutput`](../../doc/models/get-query-execution-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget23.ENUM_AMAZONATHENAGETQUERYEXECUTION

body = GetQueryExecutionInput(
    query_execution_id='QueryExecutionId0'
)

result = client_api.get_query_execution(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Query Results

<p>Streams the results of a single query execution specified by <code>QueryExecutionId</code> from the Athena query results location in Amazon S3. For more information, see <a href="https://docs.aws.amazon.com/athena/latest/ug/querying.html">Working with query results, recent queries, and output files</a> in the <i>Amazon Athena User Guide</i>. This request does not execute the query but returns results. Use <a>StartQueryExecution</a> to run a query.</p> <p>To stream query results successfully, the IAM principal with permission to call <code>GetQueryResults</code> also must have permissions to the Amazon S3 <code>GetObject</code> action for the Athena query results location.</p> <important> <p>IAM principals with permission to the Amazon S3 <code>GetObject</code> action for the query results location are able to retrieve query results from Amazon S3 even if permission to the <code>GetQueryResults</code> action is denied. To restrict user or role access, ensure that Amazon S3 permissions to the Athena query location are denied.</p> </important>


```python
def get_query_results(self,
                     x_amz_target,
                     body,
                     x_amz_content_sha_256=None,
                     x_amz_date=None,
                     x_amz_algorithm=None,
                     x_amz_credential=None,
                     x_amz_security_token=None,
                     x_amz_signature=None,
                     x_amz_signed_headers=None,
                     max_results=None,
                     next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget24`](../../doc/models/x-amz-target-24.md) | Header, Required | - |
| `body` | [`GetQueryResultsInput`](../../doc/models/get-query-results-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetQueryResultsOutput`](../../doc/models/get-query-results-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget24.ENUM_AMAZONATHENAGETQUERYRESULTS

body = GetQueryResultsInput(
    query_execution_id='QueryExecutionId0'
)

result = client_api.get_query_results(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Query Runtime Statistics

Returns query execution runtime statistics related to a single execution of a query if you have access to the workgroup in which the query ran. Query execution runtime statistics are returned only when <a>QueryExecutionStatus$State</a> is in a SUCCEEDED or FAILED state. Stage-level input and output row count and data size statistics are not shown when a query has row-level filters defined in Lake Formation.

```python
def get_query_runtime_statistics(self,
                                x_amz_target,
                                body,
                                x_amz_content_sha_256=None,
                                x_amz_date=None,
                                x_amz_algorithm=None,
                                x_amz_credential=None,
                                x_amz_security_token=None,
                                x_amz_signature=None,
                                x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget25`](../../doc/models/x-amz-target-25.md) | Header, Required | - |
| `body` | [`GetQueryRuntimeStatisticsInput`](../../doc/models/get-query-runtime-statistics-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetQueryRuntimeStatisticsOutput`](../../doc/models/get-query-runtime-statistics-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget25.ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS

body = GetQueryRuntimeStatisticsInput(
    query_execution_id='QueryExecutionId0'
)

result = client_api.get_query_runtime_statistics(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Session

Gets the full details of a previously created session, including the session status and configuration.

```python
def get_session(self,
               x_amz_target,
               body,
               x_amz_content_sha_256=None,
               x_amz_date=None,
               x_amz_algorithm=None,
               x_amz_credential=None,
               x_amz_security_token=None,
               x_amz_signature=None,
               x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget26`](../../doc/models/x-amz-target-26.md) | Header, Required | - |
| `body` | [`GetSessionRequest`](../../doc/models/get-session-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetSessionResponse`](../../doc/models/get-session-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget26.ENUM_AMAZONATHENAGETSESSION

body = GetSessionRequest(
    session_id='SessionId2'
)

result = client_api.get_session(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Session Status

Gets the current status of a session.

```python
def get_session_status(self,
                      x_amz_target,
                      body,
                      x_amz_content_sha_256=None,
                      x_amz_date=None,
                      x_amz_algorithm=None,
                      x_amz_credential=None,
                      x_amz_security_token=None,
                      x_amz_signature=None,
                      x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget27`](../../doc/models/x-amz-target-27.md) | Header, Required | - |
| `body` | [`GetSessionStatusRequest`](../../doc/models/get-session-status-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetSessionStatusResponse`](../../doc/models/get-session-status-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget27.ENUM_AMAZONATHENAGETSESSIONSTATUS

body = GetSessionStatusRequest(
    session_id='SessionId2'
)

result = client_api.get_session_status(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Table Metadata

Returns table metadata for the specified catalog, database, and table.

```python
def get_table_metadata(self,
                      x_amz_target,
                      body,
                      x_amz_content_sha_256=None,
                      x_amz_date=None,
                      x_amz_algorithm=None,
                      x_amz_credential=None,
                      x_amz_security_token=None,
                      x_amz_signature=None,
                      x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget28`](../../doc/models/x-amz-target-28.md) | Header, Required | - |
| `body` | [`GetTableMetadataInput`](../../doc/models/get-table-metadata-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetTableMetadataOutput`](../../doc/models/get-table-metadata-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget28.ENUM_AMAZONATHENAGETTABLEMETADATA

body = GetTableMetadataInput(
    catalog_name='CatalogName0',
    database_name='DatabaseName0',
    table_name='TableName2'
)

result = client_api.get_table_metadata(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# Get Work Group

Returns information about the workgroup with the specified name.

```python
def get_work_group(self,
                  x_amz_target,
                  body,
                  x_amz_content_sha_256=None,
                  x_amz_date=None,
                  x_amz_algorithm=None,
                  x_amz_credential=None,
                  x_amz_security_token=None,
                  x_amz_signature=None,
                  x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget29`](../../doc/models/x-amz-target-29.md) | Header, Required | - |
| `body` | [`GetWorkGroupInput`](../../doc/models/get-work-group-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`GetWorkGroupOutput`](../../doc/models/get-work-group-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget29.ENUM_AMAZONATHENAGETWORKGROUP

body = GetWorkGroupInput(
    work_group='WorkGroup8'
)

result = client_api.get_work_group(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Import Notebook

Imports a single <code>ipynb</code> file to a Spark enabled workgroup. The maximum file size that can be imported is 10 megabytes. If an <code>ipynb</code> file with the same name already exists in the workgroup, throws an error.

```python
def import_notebook(self,
                   x_amz_target,
                   body,
                   x_amz_content_sha_256=None,
                   x_amz_date=None,
                   x_amz_algorithm=None,
                   x_amz_credential=None,
                   x_amz_security_token=None,
                   x_amz_signature=None,
                   x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget30`](../../doc/models/x-amz-target-30.md) | Header, Required | - |
| `body` | [`ImportNotebookInput`](../../doc/models/import-notebook-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ImportNotebookOutput`](../../doc/models/import-notebook-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget30.ENUM_AMAZONATHENAIMPORTNOTEBOOK

body = ImportNotebookInput(
    work_group='WorkGroup8',
    name='Name6',
    payload='Payload2',
    mtype=NotebookType2.IPYNB
)

result = client_api.import_notebook(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Application DPU Sizes

Returns the supported DPU sizes for the supported application runtimes (for example, <code>Athena notebook version 1</code>).

```python
def list_application_dpu_sizes(self,
                              x_amz_target,
                              body,
                              x_amz_content_sha_256=None,
                              x_amz_date=None,
                              x_amz_algorithm=None,
                              x_amz_credential=None,
                              x_amz_security_token=None,
                              x_amz_signature=None,
                              x_amz_signed_headers=None,
                              max_results=None,
                              next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget31`](../../doc/models/x-amz-target-31.md) | Header, Required | - |
| `body` | [`ListApplicationDpuSizesInput`](../../doc/models/list-application-dpu-sizes-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListApplicationDpuSizesOutput`](../../doc/models/list-application-dpu-sizes-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget31.ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES

body = ListApplicationDpuSizesInput()

result = client_api.list_application_dpu_sizes(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Calculation Executions

Lists the calculations that have been submitted to a session in descending order. Newer calculations are listed first; older calculations are listed later.

```python
def list_calculation_executions(self,
                               x_amz_target,
                               body,
                               x_amz_content_sha_256=None,
                               x_amz_date=None,
                               x_amz_algorithm=None,
                               x_amz_credential=None,
                               x_amz_security_token=None,
                               x_amz_signature=None,
                               x_amz_signed_headers=None,
                               max_results=None,
                               next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget32`](../../doc/models/x-amz-target-32.md) | Header, Required | - |
| `body` | [`ListCalculationExecutionsRequest`](../../doc/models/list-calculation-executions-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListCalculationExecutionsResponse`](../../doc/models/list-calculation-executions-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget32.ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS

body = ListCalculationExecutionsRequest(
    session_id='SessionId2'
)

result = client_api.list_calculation_executions(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Data Catalogs

<p>Lists the data catalogs in the current Amazon Web Services account.</p> <note> <p>In the Athena console, data catalogs are listed as "data sources" on the <b>Data sources</b> page under the <b>Data source name</b> column.</p> </note>


```python
def list_data_catalogs(self,
                      x_amz_target,
                      body,
                      x_amz_content_sha_256=None,
                      x_amz_date=None,
                      x_amz_algorithm=None,
                      x_amz_credential=None,
                      x_amz_security_token=None,
                      x_amz_signature=None,
                      x_amz_signed_headers=None,
                      max_results=None,
                      next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget33`](../../doc/models/x-amz-target-33.md) | Header, Required | - |
| `body` | [`ListDataCatalogsInput`](../../doc/models/list-data-catalogs-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListDataCatalogsOutput`](../../doc/models/list-data-catalogs-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget33.ENUM_AMAZONATHENALISTDATACATALOGS

body = ListDataCatalogsInput()

result = client_api.list_data_catalogs(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Databases

Lists the databases in the specified data catalog.

```python
def list_databases(self,
                  x_amz_target,
                  body,
                  x_amz_content_sha_256=None,
                  x_amz_date=None,
                  x_amz_algorithm=None,
                  x_amz_credential=None,
                  x_amz_security_token=None,
                  x_amz_signature=None,
                  x_amz_signed_headers=None,
                  max_results=None,
                  next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget34`](../../doc/models/x-amz-target-34.md) | Header, Required | - |
| `body` | [`ListDatabasesInput`](../../doc/models/list-databases-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListDatabasesOutput`](../../doc/models/list-databases-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget34.ENUM_AMAZONATHENALISTDATABASES

body = ListDatabasesInput(
    catalog_name='CatalogName0'
)

result = client_api.list_databases(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# List Engine Versions

Returns a list of engine versions that are available to choose from, including the Auto option.

```python
def list_engine_versions(self,
                        x_amz_target,
                        body,
                        x_amz_content_sha_256=None,
                        x_amz_date=None,
                        x_amz_algorithm=None,
                        x_amz_credential=None,
                        x_amz_security_token=None,
                        x_amz_signature=None,
                        x_amz_signed_headers=None,
                        max_results=None,
                        next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget35`](../../doc/models/x-amz-target-35.md) | Header, Required | - |
| `body` | [`ListEngineVersionsInput`](../../doc/models/list-engine-versions-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListEngineVersionsOutput`](../../doc/models/list-engine-versions-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget35.ENUM_AMAZONATHENALISTENGINEVERSIONS

body = ListEngineVersionsInput()

result = client_api.list_engine_versions(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Executors

Lists, in descending order, the executors that joined a session. Newer executors are listed first; older executors are listed later. The result can be optionally filtered by state.

```python
def list_executors(self,
                  x_amz_target,
                  body,
                  x_amz_content_sha_256=None,
                  x_amz_date=None,
                  x_amz_algorithm=None,
                  x_amz_credential=None,
                  x_amz_security_token=None,
                  x_amz_signature=None,
                  x_amz_signed_headers=None,
                  max_results=None,
                  next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget36`](../../doc/models/x-amz-target-36.md) | Header, Required | - |
| `body` | [`ListExecutorsRequest`](../../doc/models/list-executors-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListExecutorsResponse`](../../doc/models/list-executors-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget36.ENUM_AMAZONATHENALISTEXECUTORS

body = ListExecutorsRequest(
    session_id='SessionId2'
)

result = client_api.list_executors(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Named Queries

<p>Provides a list of available query IDs only for queries saved in the specified workgroup. Requires that you have access to the specified workgroup. If a workgroup is not specified, lists the saved queries for the primary workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```python
def list_named_queries(self,
                      x_amz_target,
                      body,
                      x_amz_content_sha_256=None,
                      x_amz_date=None,
                      x_amz_algorithm=None,
                      x_amz_credential=None,
                      x_amz_security_token=None,
                      x_amz_signature=None,
                      x_amz_signed_headers=None,
                      max_results=None,
                      next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget37`](../../doc/models/x-amz-target-37.md) | Header, Required | - |
| `body` | [`ListNamedQueriesInput`](../../doc/models/list-named-queries-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListNamedQueriesOutput`](../../doc/models/list-named-queries-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget37.ENUM_AMAZONATHENALISTNAMEDQUERIES

body = ListNamedQueriesInput()

result = client_api.list_named_queries(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Notebook Metadata

Displays the notebook files for the specified workgroup in paginated format.

```python
def list_notebook_metadata(self,
                          x_amz_target,
                          body,
                          x_amz_content_sha_256=None,
                          x_amz_date=None,
                          x_amz_algorithm=None,
                          x_amz_credential=None,
                          x_amz_security_token=None,
                          x_amz_signature=None,
                          x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget38`](../../doc/models/x-amz-target-38.md) | Header, Required | - |
| `body` | [`ListNotebookMetadataInput`](../../doc/models/list-notebook-metadata-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListNotebookMetadataOutput`](../../doc/models/list-notebook-metadata-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget38.ENUM_AMAZONATHENALISTNOTEBOOKMETADATA

body = ListNotebookMetadataInput(
    work_group='WorkGroup8'
)

result = client_api.list_notebook_metadata(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Notebook Sessions

Lists, in descending order, the sessions that have been created in a notebook that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code> or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```python
def list_notebook_sessions(self,
                          x_amz_target,
                          body,
                          x_amz_content_sha_256=None,
                          x_amz_date=None,
                          x_amz_algorithm=None,
                          x_amz_credential=None,
                          x_amz_security_token=None,
                          x_amz_signature=None,
                          x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget39`](../../doc/models/x-amz-target-39.md) | Header, Required | - |
| `body` | [`ListNotebookSessionsRequest`](../../doc/models/list-notebook-sessions-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListNotebookSessionsResponse`](../../doc/models/list-notebook-sessions-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget39.ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS

body = ListNotebookSessionsRequest(
    notebook_id='NotebookId6'
)

result = client_api.list_notebook_sessions(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Prepared Statements

Lists the prepared statements in the specified workgroup.

```python
def list_prepared_statements(self,
                            x_amz_target,
                            body,
                            x_amz_content_sha_256=None,
                            x_amz_date=None,
                            x_amz_algorithm=None,
                            x_amz_credential=None,
                            x_amz_security_token=None,
                            x_amz_signature=None,
                            x_amz_signed_headers=None,
                            max_results=None,
                            next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget40`](../../doc/models/x-amz-target-40.md) | Header, Required | - |
| `body` | [`ListPreparedStatementsInput`](../../doc/models/list-prepared-statements-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListPreparedStatementsOutput`](../../doc/models/list-prepared-statements-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget40.ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS

body = ListPreparedStatementsInput(
    work_group='WorkGroup8'
)

result = client_api.list_prepared_statements(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Query Executions

<p>Provides a list of available query execution IDs for the queries in the specified workgroup. If a workgroup is not specified, returns a list of query execution IDs for the primary workgroup. Requires you to have access to the workgroup in which the queries ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```python
def list_query_executions(self,
                         x_amz_target,
                         body,
                         x_amz_content_sha_256=None,
                         x_amz_date=None,
                         x_amz_algorithm=None,
                         x_amz_credential=None,
                         x_amz_security_token=None,
                         x_amz_signature=None,
                         x_amz_signed_headers=None,
                         max_results=None,
                         next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget41`](../../doc/models/x-amz-target-41.md) | Header, Required | - |
| `body` | [`ListQueryExecutionsInput`](../../doc/models/list-query-executions-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListQueryExecutionsOutput`](../../doc/models/list-query-executions-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget41.ENUM_AMAZONATHENALISTQUERYEXECUTIONS

body = ListQueryExecutionsInput()

result = client_api.list_query_executions(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Sessions

Lists the sessions in a workgroup that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code>, or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```python
def list_sessions(self,
                 x_amz_target,
                 body,
                 x_amz_content_sha_256=None,
                 x_amz_date=None,
                 x_amz_algorithm=None,
                 x_amz_credential=None,
                 x_amz_security_token=None,
                 x_amz_signature=None,
                 x_amz_signed_headers=None,
                 max_results=None,
                 next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget42`](../../doc/models/x-amz-target-42.md) | Header, Required | - |
| `body` | [`ListSessionsRequest`](../../doc/models/list-sessions-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListSessionsResponse`](../../doc/models/list-sessions-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget42.ENUM_AMAZONATHENALISTSESSIONS

body = ListSessionsRequest(
    work_group='WorkGroup8'
)

result = client_api.list_sessions(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Table Metadata

Lists the metadata for the tables in the specified data catalog database.

```python
def list_table_metadata(self,
                       x_amz_target,
                       body,
                       x_amz_content_sha_256=None,
                       x_amz_date=None,
                       x_amz_algorithm=None,
                       x_amz_credential=None,
                       x_amz_security_token=None,
                       x_amz_signature=None,
                       x_amz_signed_headers=None,
                       max_results=None,
                       next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget43`](../../doc/models/x-amz-target-43.md) | Header, Required | - |
| `body` | [`ListTableMetadataInput`](../../doc/models/list-table-metadata-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListTableMetadataOutput`](../../doc/models/list-table-metadata-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget43.ENUM_AMAZONATHENALISTTABLEMETADATA

body = ListTableMetadataInput(
    catalog_name='CatalogName0',
    database_name='DatabaseName0'
)

result = client_api.list_table_metadata(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# List Tags for Resource

Lists the tags associated with an Athena workgroup or data catalog resource.

```python
def list_tags_for_resource(self,
                          x_amz_target,
                          body,
                          x_amz_content_sha_256=None,
                          x_amz_date=None,
                          x_amz_algorithm=None,
                          x_amz_credential=None,
                          x_amz_security_token=None,
                          x_amz_signature=None,
                          x_amz_signed_headers=None,
                          max_results=None,
                          next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget44`](../../doc/models/x-amz-target-44.md) | Header, Required | - |
| `body` | [`ListTagsForResourceInput`](../../doc/models/list-tags-for-resource-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListTagsForResourceOutput`](../../doc/models/list-tags-for-resource-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget44.ENUM_AMAZONATHENALISTTAGSFORRESOURCE

body = ListTagsForResourceInput(
    resource_arn='ResourceARN4'
)

result = client_api.list_tags_for_resource(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Work Groups

Lists available workgroups for the account.

```python
def list_work_groups(self,
                    x_amz_target,
                    body,
                    x_amz_content_sha_256=None,
                    x_amz_date=None,
                    x_amz_algorithm=None,
                    x_amz_credential=None,
                    x_amz_security_token=None,
                    x_amz_signature=None,
                    x_amz_signed_headers=None,
                    max_results=None,
                    next_token=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget45`](../../doc/models/x-amz-target-45.md) | Header, Required | - |
| `body` | [`ListWorkGroupsInput`](../../doc/models/list-work-groups-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |
| `max_results` | `str` | Query, Optional | Pagination limit |
| `next_token` | `str` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ListWorkGroupsOutput`](../../doc/models/list-work-groups-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget45.ENUM_AMAZONATHENALISTWORKGROUPS

body = ListWorkGroupsInput()

result = client_api.list_work_groups(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Start Calculation Execution

Submits calculations for execution within a session. You can supply the code to run as an inline code block within the request.

```python
def start_calculation_execution(self,
                               x_amz_target,
                               body,
                               x_amz_content_sha_256=None,
                               x_amz_date=None,
                               x_amz_algorithm=None,
                               x_amz_credential=None,
                               x_amz_security_token=None,
                               x_amz_signature=None,
                               x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget46`](../../doc/models/x-amz-target-46.md) | Header, Required | - |
| `body` | [`StartCalculationExecutionRequest`](../../doc/models/start-calculation-execution-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`StartCalculationExecutionResponse`](../../doc/models/start-calculation-execution-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget46.ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION

body = StartCalculationExecutionRequest(
    session_id='SessionId2'
)

result = client_api.start_calculation_execution(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Start Query Execution

Runs the SQL query statements contained in the <code>Query</code>. Requires you to have access to the workgroup in which the query ran. Running queries against an external catalog requires <a>GetDataCatalog</a> permission to the catalog. For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.

```python
def start_query_execution(self,
                         x_amz_target,
                         body,
                         x_amz_content_sha_256=None,
                         x_amz_date=None,
                         x_amz_algorithm=None,
                         x_amz_credential=None,
                         x_amz_security_token=None,
                         x_amz_signature=None,
                         x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget47`](../../doc/models/x-amz-target-47.md) | Header, Required | - |
| `body` | [`StartQueryExecutionInput`](../../doc/models/start-query-execution-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`StartQueryExecutionOutput`](../../doc/models/start-query-execution-output.md).

## Example Usage

```python
x_amz_target = XAmzTarget47.ENUM_AMAZONATHENASTARTQUERYEXECUTION

body = StartQueryExecutionInput(
    query_string='QueryString8'
)

result = client_api.start_query_execution(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Start Session

Creates a session for running calculations within a workgroup. The session is ready when it reaches an <code>IDLE</code> state.

```python
def start_session(self,
                 x_amz_target,
                 body,
                 x_amz_content_sha_256=None,
                 x_amz_date=None,
                 x_amz_algorithm=None,
                 x_amz_credential=None,
                 x_amz_security_token=None,
                 x_amz_signature=None,
                 x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget48`](../../doc/models/x-amz-target-48.md) | Header, Required | - |
| `body` | [`StartSessionRequest`](../../doc/models/start-session-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`StartSessionResponse`](../../doc/models/start-session-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget48.ENUM_AMAZONATHENASTARTSESSION

body = StartSessionRequest(
    work_group='WorkGroup8',
    engine_configuration=EngineConfiguration1(
        max_concurrent_dpus=94
    )
)

result = client_api.start_session(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |
| 483 | SessionAlreadyExistsException | `ApiException` |
| 484 | TooManyRequestsException | `ApiException` |


# Stop Calculation Execution

<p>Requests the cancellation of a calculation. A <code>StopCalculationExecution</code> call on a calculation that is already in a terminal state (for example, <code>STOPPED</code>, <code>FAILED</code>, or <code>COMPLETED</code>) succeeds but has no effect.</p> <note> <p>Cancelling a calculation is done on a best effort basis. If a calculation cannot be cancelled, you can be charged for its completion. If you are concerned about being charged for a calculation that cannot be cancelled, consider terminating the session in which the calculation is running.</p> </note>


```python
def stop_calculation_execution(self,
                              x_amz_target,
                              body,
                              x_amz_content_sha_256=None,
                              x_amz_date=None,
                              x_amz_algorithm=None,
                              x_amz_credential=None,
                              x_amz_security_token=None,
                              x_amz_signature=None,
                              x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget49`](../../doc/models/x-amz-target-49.md) | Header, Required | - |
| `body` | [`StopCalculationExecutionRequest`](../../doc/models/stop-calculation-execution-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`StopCalculationExecutionResponse`](../../doc/models/stop-calculation-execution-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget49.ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION

body = StopCalculationExecutionRequest(
    calculation_execution_id='CalculationExecutionId8'
)

result = client_api.stop_calculation_execution(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Stop Query Execution

<p>Stops a query execution. Requires you to have access to the workgroup in which the query ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```python
def stop_query_execution(self,
                        x_amz_target,
                        body,
                        x_amz_content_sha_256=None,
                        x_amz_date=None,
                        x_amz_algorithm=None,
                        x_amz_credential=None,
                        x_amz_security_token=None,
                        x_amz_signature=None,
                        x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget50`](../../doc/models/x-amz-target-50.md) | Header, Required | - |
| `body` | [`StopQueryExecutionInput`](../../doc/models/stop-query-execution-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget50.ENUM_AMAZONATHENASTOPQUERYEXECUTION

body = StopQueryExecutionInput(
    query_execution_id='QueryExecutionId0'
)

result = client_api.stop_query_execution(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Tag Resource

Adds one or more tags to an Athena resource. A tag is a label that you assign to a resource. In Athena, a resource can be a workgroup or data catalog. Each tag consists of a key and an optional value, both of which you define. For example, you can use tags to categorize Athena workgroups or data catalogs by purpose, owner, or environment. Use a consistent set of tag keys to make it easier to search and filter workgroups or data catalogs in your account. For best practices, see <a href="https://docs.aws.amazon.com/whitepapers/latest/tagging-best-practices/tagging-best-practices.html">Tagging Best Practices</a>. Tag keys can be from 1 to 128 UTF-8 Unicode characters, and tag values can be from 0 to 256 UTF-8 Unicode characters. Tags can use letters and numbers representable in UTF-8, and the following characters: + - = . _ : / @. Tag keys and values are case-sensitive. Tag keys must be unique per resource. If you specify more than one tag, separate them by commas.

```python
def tag_resource(self,
                x_amz_target,
                body,
                x_amz_content_sha_256=None,
                x_amz_date=None,
                x_amz_algorithm=None,
                x_amz_credential=None,
                x_amz_security_token=None,
                x_amz_signature=None,
                x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget51`](../../doc/models/x-amz-target-51.md) | Header, Required | - |
| `body` | [`TagResourceInput`](../../doc/models/tag-resource-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget51.ENUM_AMAZONATHENATAGRESOURCE

body = TagResourceInput(
    resource_arn='ResourceARN4',
    tags=[
        Tag()
    ]
)

result = client_api.tag_resource(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Terminate Session

Terminates an active session. A <code>TerminateSession</code> call on a session that is already inactive (for example, in a <code>FAILED</code>, <code>TERMINATED</code> or <code>TERMINATING</code> state) succeeds but has no effect. Calculations running in the session when <code>TerminateSession</code> is called are forcefully stopped, but may display as <code>FAILED</code> instead of <code>STOPPED</code>.

```python
def terminate_session(self,
                     x_amz_target,
                     body,
                     x_amz_content_sha_256=None,
                     x_amz_date=None,
                     x_amz_algorithm=None,
                     x_amz_credential=None,
                     x_amz_security_token=None,
                     x_amz_signature=None,
                     x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget52`](../../doc/models/x-amz-target-52.md) | Header, Required | - |
| `body` | [`TerminateSessionRequest`](../../doc/models/terminate-session-request.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`TerminateSessionResponse`](../../doc/models/terminate-session-response.md).

## Example Usage

```python
x_amz_target = XAmzTarget52.ENUM_AMAZONATHENATERMINATESESSION

body = TerminateSessionRequest(
    session_id='SessionId2'
)

result = client_api.terminate_session(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Untag Resource

Removes one or more tags from a data catalog or workgroup resource.

```python
def untag_resource(self,
                  x_amz_target,
                  body,
                  x_amz_content_sha_256=None,
                  x_amz_date=None,
                  x_amz_algorithm=None,
                  x_amz_credential=None,
                  x_amz_security_token=None,
                  x_amz_signature=None,
                  x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget53`](../../doc/models/x-amz-target-53.md) | Header, Required | - |
| `body` | [`UntagResourceInput`](../../doc/models/untag-resource-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget53.ENUM_AMAZONATHENAUNTAGRESOURCE

body = UntagResourceInput(
    resource_arn='ResourceARN4',
    tag_keys=[
        'TagKeys9',
        'TagKeys0'
    ]
)

result = client_api.untag_resource(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Update Data Catalog

Updates the data catalog that has the specified name.

```python
def update_data_catalog(self,
                       x_amz_target,
                       body,
                       x_amz_content_sha_256=None,
                       x_amz_date=None,
                       x_amz_algorithm=None,
                       x_amz_credential=None,
                       x_amz_security_token=None,
                       x_amz_signature=None,
                       x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget54`](../../doc/models/x-amz-target-54.md) | Header, Required | - |
| `body` | [`UpdateDataCatalogInput`](../../doc/models/update-data-catalog-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget54.ENUM_AMAZONATHENAUPDATEDATACATALOG

body = UpdateDataCatalogInput(
    name='Name6',
    mtype=DataCatalogType3.HIVE
)

result = client_api.update_data_catalog(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Update Named Query

Updates a <a>NamedQuery</a> object. The database or workgroup cannot be updated.

```python
def update_named_query(self,
                      x_amz_target,
                      body,
                      x_amz_content_sha_256=None,
                      x_amz_date=None,
                      x_amz_algorithm=None,
                      x_amz_credential=None,
                      x_amz_security_token=None,
                      x_amz_signature=None,
                      x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget55`](../../doc/models/x-amz-target-55.md) | Header, Required | - |
| `body` | [`UpdateNamedQueryInput`](../../doc/models/update-named-query-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget55.ENUM_AMAZONATHENAUPDATENAMEDQUERY

body = UpdateNamedQueryInput(
    named_query_id='NamedQueryId6',
    name='Name6',
    query_string='QueryString8'
)

result = client_api.update_named_query(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Update Notebook

Updates the contents of a Spark notebook.

```python
def update_notebook(self,
                   x_amz_target,
                   body,
                   x_amz_content_sha_256=None,
                   x_amz_date=None,
                   x_amz_algorithm=None,
                   x_amz_credential=None,
                   x_amz_security_token=None,
                   x_amz_signature=None,
                   x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget56`](../../doc/models/x-amz-target-56.md) | Header, Required | - |
| `body` | [`UpdateNotebookInput`](../../doc/models/update-notebook-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget56.ENUM_AMAZONATHENAUPDATENOTEBOOK

body = UpdateNotebookInput(
    notebook_id='NotebookId6',
    payload='Payload2',
    mtype=NotebookType2.IPYNB
)

result = client_api.update_notebook(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Update Notebook Metadata

Updates the metadata for a notebook.

```python
def update_notebook_metadata(self,
                            x_amz_target,
                            body,
                            x_amz_content_sha_256=None,
                            x_amz_date=None,
                            x_amz_algorithm=None,
                            x_amz_credential=None,
                            x_amz_security_token=None,
                            x_amz_signature=None,
                            x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget57`](../../doc/models/x-amz-target-57.md) | Header, Required | - |
| `body` | [`UpdateNotebookMetadataInput`](../../doc/models/update-notebook-metadata-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget57.ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA

body = UpdateNotebookMetadataInput(
    notebook_id='NotebookId6',
    name='Name6'
)

result = client_api.update_notebook_metadata(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Update Prepared Statement

Updates a prepared statement.

```python
def update_prepared_statement(self,
                             x_amz_target,
                             body,
                             x_amz_content_sha_256=None,
                             x_amz_date=None,
                             x_amz_algorithm=None,
                             x_amz_credential=None,
                             x_amz_security_token=None,
                             x_amz_signature=None,
                             x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget58`](../../doc/models/x-amz-target-58.md) | Header, Required | - |
| `body` | [`UpdatePreparedStatementInput`](../../doc/models/update-prepared-statement-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget58.ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT

body = UpdatePreparedStatementInput(
    statement_name='StatementName4',
    work_group='WorkGroup8',
    query_statement='QueryStatement8'
)

result = client_api.update_prepared_statement(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Update Work Group

Updates the workgroup with the specified name. The workgroup's name cannot be changed. Only <code>ConfigurationUpdates</code> can be specified.

```python
def update_work_group(self,
                     x_amz_target,
                     body,
                     x_amz_content_sha_256=None,
                     x_amz_date=None,
                     x_amz_algorithm=None,
                     x_amz_credential=None,
                     x_amz_security_token=None,
                     x_amz_signature=None,
                     x_amz_signed_headers=None)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_amz_target` | [`XAmzTarget59`](../../doc/models/x-amz-target-59.md) | Header, Required | - |
| `body` | [`UpdateWorkGroupInput`](../../doc/models/update-work-group-input.md) | Body, Required | - |
| `x_amz_content_sha_256` | `str` | Header, Optional | - |
| `x_amz_date` | `str` | Header, Optional | - |
| `x_amz_algorithm` | `str` | Header, Optional | - |
| `x_amz_credential` | `str` | Header, Optional | - |
| `x_amz_security_token` | `str` | Header, Optional | - |
| `x_amz_signature` | `str` | Header, Optional | - |
| `x_amz_signed_headers` | `str` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
x_amz_target = XAmzTarget59.ENUM_AMAZONATHENAUPDATEWORKGROUP

body = UpdateWorkGroupInput(
    work_group='WorkGroup8'
)

result = client_api.update_work_group(
    x_amz_target,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |

