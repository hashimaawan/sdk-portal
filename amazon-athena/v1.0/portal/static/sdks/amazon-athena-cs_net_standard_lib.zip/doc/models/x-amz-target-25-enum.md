
# X Amz Target 25 Enum

## Enumeration

`XAmzTarget25Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryRuntimeStatistics` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget25Enum xAmzTarget25 = XAmzTarget25Enum.EnumAmazonAthenaGetQueryRuntimeStatistics;
```

