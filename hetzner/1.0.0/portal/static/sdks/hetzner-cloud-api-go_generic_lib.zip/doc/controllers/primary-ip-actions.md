# Primary IP Actions

```go
primaryIpActionsApi := client.PrimaryIpActionsApi()
```

## Class Name

`PrimaryIpActionsApi`

## Methods

* [Assign a Primary IP to a Resource](../../doc/controllers/primary-ip-actions.md#assign-a-primary-ip-to-a-resource)
* [Change Reverse DNS Entry for a Primary IP](../../doc/controllers/primary-ip-actions.md#change-reverse-dns-entry-for-a-primary-ip)
* [Change Primary IP Protection](../../doc/controllers/primary-ip-actions.md#change-primary-ip-protection)
* [Unassign a Primary IP from a Resource](../../doc/controllers/primary-ip-actions.md#unassign-a-primary-ip-from-a-resource)


# Assign a Primary IP to a Resource

Assigns a Primary IP to a Server.

A Server can only have one Primary IP of type `ipv4` and one of type `ipv6` assigned. If you need more IPs use Floating IPs.

The Server must be powered off (status `off`) in order for this operation to succeed.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_not_stopped`          | The server is running, but needs to be powered off            |
| `primary_ip_already_assigned` | Primary ip is already assigned to a different server          |
| `server_has_ipv4`             | The server already has an ipv4 address                        |
| `server_has_ipv6`             | The server already has an ipv6 address                        |

```go
AssignAPrimaryIpToAResource(
    ctx context.Context,
    id int,
    body *models.AssignPrimaryIpRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Primary IP |
| `body` | [`*models.AssignPrimaryIpRequest`](../../doc/models/assign-primary-ip-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key in the reply contains an Action object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.AssignPrimaryIpRequest{
    AssigneeId:            4711,
    AssigneeType:          "server",
}

apiResponse, err := primaryIpActionsApi.AssignAPrimaryIpToAResource(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "assign_primary_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "primary_ip"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Reverse DNS Entry for a Primary IP

Changes the hostname that will appear when getting the hostname belonging to this Primary IP.

```go
ChangeReverseDnsEntryForAPrimaryIp(
    ctx context.Context,
    id int,
    body *models.ChangeDnsptrRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Primary IP |
| `body` | [`*models.ChangeDnsptrRequest`](../../doc/models/change-dnsptr-request.md) | Body, Optional | Select the IP address for which to change the DNS entry by passing `ip`. For a Primary IP of type `ipv4` this must exactly match the IP address of the Primary IP. For a Primary IP of type `ipv6` this must be a single IP within the IPv6 /64 range that belongs to this Primary IP.<br><br>The target hostname is set by passing `dns_ptr`. |

## Response Type

**201**: The `action` key contains the `change_dns_ptr` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.ChangeDnsptrRequest{
    DnsPtr:                models.ToPointer("server02.example.com"),
    Ip:                    "1.2.3.4",
}

apiResponse, err := primaryIpActionsApi.ChangeReverseDnsEntryForAPrimaryIp(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_dns_ptr",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "primary_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Primary IP Protection

Changes the protection configuration of a Primary IP.

A Primary IP can only be delete protected if its `auto_delete` property is set to `false`.

```go
ChangePrimaryIpProtection(
    ctx context.Context,
    id int,
    body *models.ChangeProtectionRequest2) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Primary IP |
| `body` | [`*models.ChangeProtectionRequest2`](../../doc/models/change-protection-request-2.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.ChangeProtectionRequest2{
    Delete:                models.ToPointer(true),
}

apiResponse, err := primaryIpActionsApi.ChangePrimaryIpProtection(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "primary_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Unassign a Primary IP from a Resource

Unassigns a Primary IP from a Server.

The Server must be powered off (status `off`) in order for this operation to succeed.

Note that only Servers that have at least one network interface (public or private) attached can be powered on.

#### Call specific error codes

| Code                              | Description                                                   |
|---------------------------------- |-------------------------------------------------------------- |
| `server_not_stopped`              | The server is running, but needs to be powered off            |
| `server_is_load_balancer_target`  | The server ipv4 address is a loadbalancer target              |

```go
UnassignAPrimaryIpFromAResource(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Primary IP |

## Response Type

**201**: The `action` key in the reply contains an Action object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := primaryIpActionsApi.UnassignAPrimaryIpFromAResource(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "unassign_primary_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "primary_ip"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```

