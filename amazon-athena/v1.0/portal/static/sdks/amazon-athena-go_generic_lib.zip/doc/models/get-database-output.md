
# Get Database Output

*This model accepts additional fields of type interface{}.*

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Database` | [`*models.Database2`](../../doc/models/database-2.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    getDatabaseOutput := models.GetDatabaseOutput{
        Database:              models.ToPointer(models.Database2{
            Name:                  "Name2",
            Description:           models.ToPointer("Description8"),
            Parameters:            models.ToPointer(models.Parameters{
                AdditionalProperties:  map[string]string{
                    "exampleAdditionalProperty": "Parameters_additionalProperties2",
                },
            }),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

