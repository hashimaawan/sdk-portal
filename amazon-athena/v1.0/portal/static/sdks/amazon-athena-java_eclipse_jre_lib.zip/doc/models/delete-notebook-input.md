
# Delete Notebook Input

## Structure

`DeleteNotebookInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NotebookId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` | String getNotebookId() | setNotebookId(String notebookId) |

## Example

```java
import com.amazonaws.useast1.athena.models.DeleteNotebookInput;

DeleteNotebookInput deleteNotebookInput = new DeleteNotebookInput.Builder(
    "NotebookId0"
)
.build();
```

