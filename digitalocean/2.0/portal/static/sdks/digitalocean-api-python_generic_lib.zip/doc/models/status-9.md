
# Status 9

A status string indicating the current state of the firewall. This can be "waiting", "succeeded", or "failed".

## Enumeration

`Status9`

## Fields

| Name |
|  --- |
| `WAITING` |
| `SUCCEEDED` |
| `FAILED` |

## Example

```python
from digitaloceanapi.models.status_9 import Status9

status_9 = Status9.SUCCEEDED
```

