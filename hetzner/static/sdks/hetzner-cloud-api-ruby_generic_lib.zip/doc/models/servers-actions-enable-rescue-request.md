
# Servers Actions Enable Rescue Request

## Structure

`ServersActionsEnableRescueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ssh_keys` | `Array[Integer]` | Optional | Array of SSH key IDs which should be injected into the rescue system. |
| `type` | [`Type65Enum`](../../doc/models/type-65-enum.md) | Optional | Type of rescue system to boot (default: `linux64`) |

## Example

```ruby
servers_actions_enable_rescue_request = ServersActionsEnableRescueRequest.new(
  [
    2323
  ],
  Type65Enum::LINUX64
)
```

