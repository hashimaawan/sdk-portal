
# Get Calculation Execution Code Request

*This model accepts additional fields of type array.*

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | getCalculationExecutionId(): string | setCalculationExecutionId(string calculationExecutionId): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetCalculationExecutionCodeRequestBuilder;
use AmazonAthenaLib\ApiHelper;

$getCalculationExecutionCodeRequest = GetCalculationExecutionCodeRequestBuilder::init(
    'CalculationExecutionId4'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

