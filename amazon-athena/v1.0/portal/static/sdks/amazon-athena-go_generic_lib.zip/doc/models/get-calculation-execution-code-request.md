
# Get Calculation Execution Code Request

*This model accepts additional fields of type interface{}.*

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    getCalculationExecutionCodeRequest := models.GetCalculationExecutionCodeRequest{
        CalculationExecutionId: "CalculationExecutionId4",
        AdditionalProperties:   map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

