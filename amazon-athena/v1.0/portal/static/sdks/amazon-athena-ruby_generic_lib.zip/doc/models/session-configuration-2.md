
# Session Configuration 2

## Structure

`SessionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `execution_role` | `String` | Optional | **Constraints**: *Minimum Length*: `20`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:iam::\d{12}:role/?[a-zA-Z_0-9+=,.@\-_/]+$` |
| `working_directory` | `String` | Optional | - |
| `idle_timeout_seconds` | `Integer` | Optional | - |
| `encryption_configuration` | [`EncryptionConfiguration`](../../doc/models/encryption-configuration.md) | Optional | If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information. |

## Example

```ruby
session_configuration2 = SessionConfiguration2.new(
  'ExecutionRole4',
  'WorkingDirectory8',
  46,
  EncryptionConfiguration.new(
    EncryptionOption1Enum::SSE_S3,
    'KmsKey6'
  )
)
```

