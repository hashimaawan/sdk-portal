
# Row

The rows that make up a query result table.

*This model accepts additional fields of type Object.*

## Structure

`Row`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`List<Datum>`](../../doc/models/datum.md) | Optional | - | List<Datum> getData() | setData(List<Datum> data) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.models.Datum;
import com.amazonaws.useast1.athena.models.Row;
import java.io.IOException;
import java.util.Arrays;

Row row = new Row.Builder()
    .data(Arrays.asList(
        new Datum.Builder()
            .varCharValue("VarCharValue8")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

