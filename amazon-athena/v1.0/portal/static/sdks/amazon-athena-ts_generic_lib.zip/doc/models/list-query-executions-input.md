
# List Query Executions Input

*This model accepts additional fields of type unknown.*

## Structure

`ListQueryExecutionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 0`, `<= 50` |
| `workGroup` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ListQueryExecutionsInput } from 'amazon-athenalib';

const listQueryExecutionsInput: ListQueryExecutionsInput = {
  nextToken: 'NextToken2',
  maxResults: 34,
  workGroup: 'WorkGroup4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

