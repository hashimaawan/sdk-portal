
# Executor Type Enum

## Enumeration

`ExecutorTypeEnum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```php
use AmazonAthenaLib\Models\ExecutorTypeEnum;

$executorType = ExecutorTypeEnum::GATEWAY;
```

