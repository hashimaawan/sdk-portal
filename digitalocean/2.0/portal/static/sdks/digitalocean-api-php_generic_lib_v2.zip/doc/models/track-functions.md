
# Track Functions

Enables tracking of function call counts and time used.

## Enumeration

`TrackFunctions`

## Fields

| Name |
|  --- |
| `ALL` |
| `PL` |
| `NONE` |

## Example

```php
use DigitalOceanApiLib\Models\TrackFunctions;

$trackFunctions = TrackFunctions::PL;
```

