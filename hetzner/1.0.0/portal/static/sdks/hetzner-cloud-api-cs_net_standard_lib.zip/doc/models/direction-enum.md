
# Direction Enum

Select traffic direction on which rule should be applied. Use `source_ips` for direction `in` and `destination_ips` for direction `out`.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `In` |
| `Out` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

DirectionEnum direction = DirectionEnum.In;
```

