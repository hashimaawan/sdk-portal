# Firewalls

Firewalls can limit the network access to or from your resources.

* When applying a firewall with no `in` rule all inbound traffic will be dropped. The default for `in` is `DROP`.
* When applying a firewall with no `out` rule all outbound traffic will be accepted. The default for `out` is `ACCEPT`.

```ruby
firewalls_controller = client.firewalls
```

## Class Name

`FirewallsController`

## Methods

* [Get All Firewalls](../../doc/controllers/firewalls.md#get-all-firewalls)
* [Create a Firewall](../../doc/controllers/firewalls.md#create-a-firewall)
* [Delete a Firewall](../../doc/controllers/firewalls.md#delete-a-firewall)
* [Get a Firewall](../../doc/controllers/firewalls.md#get-a-firewall)
* [Update a Firewall](../../doc/controllers/firewalls.md#update-a-firewall)


# Get All Firewalls

Returns all Firewall objects.

```ruby
def get_all_firewalls(sort: nil,
                      name: nil,
                      label_selector: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`SortEnum`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `String` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `label_selector` | `String` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `firewalls` key contains an array of Firewall objects

[`FirewallsResponse`](../../doc/models/firewalls-response.md)

## Example Usage

```ruby
result = firewalls_controller.get_all_firewalls
puts result
```


# Create a Firewall

Creates a new Firewall.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_already_added`        | Server added more than one time to resource                   |
| `incompatible_network_type`   | The Network type is incompatible for the given resource       |
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```ruby
def create_a_firewall(body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateFirewallRequest`](../../doc/models/create-firewall-request.md) | Body, Optional | - |

## Response Type

**201**: The `firewall` key contains the Firewall that was just created

[`CreateFirewallResponse`](../../doc/models/create-firewall-response.md)

## Example Usage

```ruby
body = CreateFirewallRequest.new(
  'Corporate Intranet Protection',
  [
    ApplyTo.new(
      Type7Enum::SERVER,
      LabelSelector1.new,
      Server2.new(
        42
      )
    )
  ],
  { 'env' => 'dev' },
  [
    Rule.new(
      DirectionEnum::ENUM_IN,
      ProtocolEnum::TCP,
      'Allow port 80',
      [],
      '80',
      [
        '28.239.13.1/32',
        '28.239.14.0/24',
        'ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128'
      ]
    )
  ]
)

result = firewalls_controller.create_a_firewall(body: body)
puts result
```


# Delete a Firewall

Deletes a Firewall.

#### Call specific error codes

| Code                 | Description                               |
|--------------------- |-------------------------------------------|
| `resource_in_use`    | Firewall must not be in use to be deleted |

```ruby
def delete_a_firewall(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the resource |

## Response Type

**204**: Firewall deleted

`void`

## Example Usage

```ruby
id = 112

firewalls_controller.delete_a_firewall(id)
```


# Get a Firewall

Gets a specific Firewall object.

```ruby
def get_a_firewall(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the resource |

## Response Type

**200**: The `firewall` key contains a Firewall object

[`FirewallResponse`](../../doc/models/firewall-response.md)

## Example Usage

```ruby
id = 112

result = firewalls_controller.get_a_firewall(id)
puts result
```


# Update a Firewall

Updates the Firewall.

Note that when updating labels, the Firewall's current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the Firewall object changes during the request, the response will be a “conflict” error.

```ruby
def update_a_firewall(id,
                      body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the resource |
| `body` | [`UpdateFirewallRequest`](../../doc/models/update-firewall-request.md) | Body, Optional | - |

## Response Type

**200**: The `firewall` key contains the Firewall that was just updated

[`FirewallResponse`](../../doc/models/firewall-response.md)

## Example Usage

```ruby
id = 112

body = UpdateFirewallRequest.new(
  { 'labelkey' => 'value' },
  'new-name'
)

result = firewalls_controller.update_a_firewall(
  id,
  body: body
)
puts result
```

