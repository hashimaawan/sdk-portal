
# X Amz Target 10

## Enumeration

`XAmzTarget10`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENAMEDQUERY` |

## Example

```ruby
x_amz_target10 = XAmzTarget10::ENUM_AMAZONATHENADELETENAMEDQUERY
```

