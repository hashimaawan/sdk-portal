
# List Tags for Resource Input

## Structure

`ListTagsForResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResourceARN` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 75` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ListTagsForResourceInput listTagsForResourceInput = new ListTagsForResourceInput
{
    ResourceARN = "ResourceARN0",
    NextToken = "NextToken0",
    MaxResults = 76,
};
```

