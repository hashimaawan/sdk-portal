
# Status 16

## Enumeration

`Status16`

## Fields

| Name |
|  --- |
| `Down` |
| `Up` |
| `Checking` |

## Example

```ts
import { Status16 } from 'digitalocean-apilib';

const status16 = Status16.Down;
```

