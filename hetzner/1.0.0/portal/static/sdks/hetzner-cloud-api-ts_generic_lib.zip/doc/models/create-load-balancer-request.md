
# Create Load Balancer Request

*This model accepts additional fields of type unknown.*

## Structure

`CreateLoadBalancerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `algorithm` | [`LoadBalancerAlgorithm`](../../doc/models/load-balancer-algorithm.md) | Required | Algorithm of the Load Balancer |
| `labels` | [`Labels \| undefined`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `loadBalancerType` | `string` | Required | ID or name of the Load Balancer type this Load Balancer should be created with |
| `location` | `string \| undefined` | Optional | ID or name of Location to create Load Balancer in |
| `name` | `string` | Required | Name of the Load Balancer |
| `network` | `number \| undefined` | Optional | ID of the network the Load Balancer should be attached to on creation |
| `networkZone` | `string \| undefined` | Optional | Name of network zone |
| `publicInterface` | `boolean \| undefined` | Optional | Enable or disable the public interface of the Load Balancer |
| `services` | [`LoadBalancerService[] \| undefined`](../../doc/models/load-balancer-service.md) | Optional | Array of services |
| `targets` | [`LoadBalancerTarget[] \| undefined`](../../doc/models/load-balancer-target.md) | Optional | Array of targets |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { CreateLoadBalancerRequest, Type28 } from 'hetzner-cloud-apilib';

const createLoadBalancerRequest: CreateLoadBalancerRequest = {
  algorithm: {
    type: Type28.RoundRobin,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  loadBalancerType: 'lb11',
  name: 'Web Frontend',
  labels: {
    labelkey: 'labelkey4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  location: 'location2',
  network: 123,
  networkZone: 'eu-central',
  publicInterface: true,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

