
# X Amz Target 47 Enum

## Enumeration

`XAmzTarget47Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENASTARTQUERYEXECUTION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget47 := models.XAmzTarget47Enum_ENUMAMAZONATHENASTARTQUERYEXECUTION

}
```

