
# Phase

## Enumeration

`Phase`

## Fields

| Name |
|  --- |
| `Unknown` |
| `PendingBuild` |
| `Building` |
| `PendingDeploy` |
| `Deploying` |
| `Active` |
| `Superseded` |
| `Error` |
| `Canceled` |

## Example

```ts
import { Phase } from 'digitalocean-apilib';

const phase = Phase.Building;
```

