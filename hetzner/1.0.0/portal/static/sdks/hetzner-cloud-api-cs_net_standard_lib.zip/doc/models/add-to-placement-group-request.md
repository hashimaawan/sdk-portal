
# Add to Placement Group Request

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PlacementGroup` | `int` | Required | ID of Placement Group the Server should be added to |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

AddToPlacementGroupRequest addToPlacementGroupRequest = new AddToPlacementGroupRequest
{
    PlacementGroup = 1,
};
```

