
# V2 Databases Dbs Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesDbsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dbs` | [`Array[Db]`](../../doc/models/db.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_dbs_response = V2DatabasesDbsResponse.new(
  dbs: [
    Db.new(
      name: 'name6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

