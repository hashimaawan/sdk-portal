
# Protocol Enum

Type of traffic to allow

## Enumeration

`ProtocolEnum`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |
| `ESP` |
| `GRE` |

## Example

```python
from hetznercloudapi.models.protocol_enum import ProtocolEnum

protocol = ProtocolEnum.ESP
```

