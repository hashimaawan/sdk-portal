
# Query Stage Plan Node

Stage plan information such as name, identifier, sub plans, and remote sources.

## Structure

`QueryStagePlanNode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | - |
| `identifier` | `string \| undefined` | Optional | - |
| `children` | [`QueryStagePlanNode[] \| undefined`](../../doc/models/query-stage-plan-node.md) | Optional | - |
| `remoteSources` | `string[] \| undefined` | Optional | - |

## Example

```ts
import { QueryStagePlanNode } from 'amazon-athenalib';

const queryStagePlanNode: QueryStagePlanNode = {
  name: 'Name4',
  identifier: 'Identifier0',
  children: [
    {
      name: 'Name6',
      identifier: 'Identifier2',
      children: [
        {
        }
      ],
      remoteSources: [
        'RemoteSources4',
        'RemoteSources5',
        'RemoteSources6'
      ],
    }
  ],
  remoteSources: [
    'RemoteSources2',
    'RemoteSources3',
    'RemoteSources4'
  ],
};
```

