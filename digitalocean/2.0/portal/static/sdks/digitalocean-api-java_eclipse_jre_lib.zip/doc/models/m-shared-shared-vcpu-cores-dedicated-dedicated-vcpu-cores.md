
# M Shared Shared Vcpu Cores Dedicated Dedicated Vcpu Cores

## Enumeration

`MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `SHARED` |
| `DEDICATED` |

## Example

```java
import com.digitalocean.api.models.MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores;

MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores mSharedSharedVcpuCoresDedicatedDedicatedVcpuCores = MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores.DEDICATED;
```

