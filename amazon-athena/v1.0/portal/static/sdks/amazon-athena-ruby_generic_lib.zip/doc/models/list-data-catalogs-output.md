
# List Data Catalogs Output

## Structure

`ListDataCatalogsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data_catalogs_summary` | [`Array[DataCatalogSummary]`](../../doc/models/data-catalog-summary.md) | Optional | - |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_data_catalogs_output = ListDataCatalogsOutput.new(
  [
    DataCatalogSummary.new(
      'CatalogName4',
      DataCatalogType2Enum::HIVE
    ),
    DataCatalogSummary.new(
      'CatalogName4',
      DataCatalogType2Enum::HIVE
    ),
    DataCatalogSummary.new(
      'CatalogName4',
      DataCatalogType2Enum::HIVE
    )
  ],
  'NextToken2'
)
```

