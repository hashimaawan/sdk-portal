
# Update Data Catalog Input

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `type` | [`DataCatalogType3Enum`](../../doc/models/data-catalog-type-3-enum.md) | Required | - |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters \| undefined`](../../doc/models/parameters.md) | Optional | - |

## Example

```ts
import {
  DataCatalogType3Enum,
  UpdateDataCatalogInput,
} from 'amazon-athenalib';

const updateDataCatalogInput: UpdateDataCatalogInput = {
  name: 'Name4',
  type: DataCatalogType3Enum.GLUE,
  description: 'Description2',
  parameters: {},
};
```

