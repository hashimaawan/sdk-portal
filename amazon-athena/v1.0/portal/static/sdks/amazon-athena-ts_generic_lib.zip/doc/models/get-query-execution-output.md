
# Get Query Execution Output

## Structure

`GetQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecution` | [`QueryExecution1 \| undefined`](../../doc/models/query-execution-1.md) | Optional | - |

## Example

```ts
import {
  EncryptionOption1Enum,
  GetQueryExecutionOutput,
  S3AclOption1Enum,
  StatementType1Enum,
} from 'amazon-athenalib';

const getQueryExecutionOutput: GetQueryExecutionOutput = {
  queryExecution: {
    queryExecutionId: 'QueryExecutionId0',
    query: 'Query6',
    statementType: StatementType1Enum.DDL,
    resultConfiguration: {
      outputLocation: 'OutputLocation0',
      encryptionConfiguration: {
        encryptionOption: EncryptionOption1Enum.SSES3,
        kmsKey: 'KmsKey6',
      },
      expectedBucketOwner: 'ExpectedBucketOwner0',
      aclConfiguration: {
        s3AclOption: S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
      },
    },
    resultReuseConfiguration: {
      resultReuseByAgeConfiguration: {
        enabled: false,
        maxAgeInMinutes: 26,
      },
    },
  },
};
```

