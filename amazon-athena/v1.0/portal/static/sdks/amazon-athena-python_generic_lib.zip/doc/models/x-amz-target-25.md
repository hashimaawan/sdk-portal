
# X Amz Target 25

## Enumeration

`XAmzTarget25`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```python
from amazonathena.models.x_amz_target_25 import XAmzTarget25

x_amz_target_25 = XAmzTarget25.ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS
```

