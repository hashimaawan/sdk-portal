
# X Amz Target 22

## Enumeration

`XAmzTarget22`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget22;

$xAmzTarget22 = XAmzTarget22::ENUM_AMAZONATHENAGETPREPAREDSTATEMENT;
```

