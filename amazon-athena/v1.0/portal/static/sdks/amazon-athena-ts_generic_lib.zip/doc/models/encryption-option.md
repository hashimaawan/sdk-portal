
# Encryption Option

## Enumeration

`EncryptionOption`

## Fields

| Name |
|  --- |
| `SseS3` |
| `SseKms` |
| `CseKms` |

## Example

```ts
import { EncryptionOption } from 'amazon-athenalib';

const encryptionOption = EncryptionOption.SseS3;
```

