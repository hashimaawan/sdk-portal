
# Type 28 Enum

Type of the algorithm

## Enumeration

`Type28Enum`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```ruby
type28 = Type28Enum::ROUND_ROBIN
```

