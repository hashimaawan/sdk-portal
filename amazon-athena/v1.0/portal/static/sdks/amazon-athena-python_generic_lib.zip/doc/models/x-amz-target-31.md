
# X Amz Target 31

## Enumeration

`XAmzTarget31`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```python
from amazonathena.models.x_amz_target_31 import XAmzTarget31

x_amz_target_31 = XAmzTarget31.ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES
```

