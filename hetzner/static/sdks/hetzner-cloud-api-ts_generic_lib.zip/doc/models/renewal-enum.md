
# Renewal Enum

Status of the renewal process of the Certificate.

## Enumeration

`RenewalEnum`

## Fields

| Name |
|  --- |
| `Scheduled` |
| `Pending` |
| `Failed` |
| `Unavailable` |

## Example

```ts
import { RenewalEnum } from 'hetzner-cloud-apilib';

const renewal = RenewalEnum.Failed;
```

