
# Protection 20

Protection configuration for the Server

## Structure

`Protection20`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool` | Required | If true, prevents the Server from being deleted |
| `Rebuild` | `bool` | Required | If true, prevents the Server from being rebuilt |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    protection20 := models.Protection20{
        Delete:               false,
        Rebuild:              false,
    }

}
```

