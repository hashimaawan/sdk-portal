
# Album Group

This field describes the relationship between the artist and the album.

## Enumeration

`AlbumGroup`

## Fields

| Name |
|  --- |
| `Album` |
| `Single` |
| `Compilation` |
| `AppearsOn` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

AlbumGroup albumGroup = AlbumGroup.Compilation;
```

