# API

```ruby
client_controller = client.client
```

## Class Name

`APIController`

## Methods

* [Trip GET](../../doc/controllers/api.md#trip-get)
* [Trip Stop by Trip Id GET](../../doc/controllers/api.md#trip-stop-by-trip-id-get)


# Trip GET

list user's trips

```ruby
def trip_get
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

[`Array[Trip]`](../../doc/models/trip.md)

## Example Usage

```ruby
result = client_controller.trip_get
puts result
```


# Trip Stop by Trip Id GET

list stops for a trip identified by {trip_id}

```ruby
def trip_stop_by_trip_id_get(trip_id)
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trip_id` | `String` | Template, Required | id of the trip |

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

[`Array[Step]`](../../doc/models/step.md)

## Example Usage

```ruby
trip_id = 'trip_id2'

result = client_controller.trip_stop_by_trip_id_get(trip_id)
puts result
```

