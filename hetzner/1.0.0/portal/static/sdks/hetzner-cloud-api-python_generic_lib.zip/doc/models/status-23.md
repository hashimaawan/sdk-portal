
# Status 23

## Enumeration

`Status23`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |

## Example

```python
from hetznercloudapi.models.status_23 import Status23

status_23 = Status23.AVAILABLE
```

