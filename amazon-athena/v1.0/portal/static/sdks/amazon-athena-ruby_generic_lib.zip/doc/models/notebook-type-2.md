
# Notebook Type 2

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```ruby
notebook_type2 = NotebookType2::IPYNB
```

