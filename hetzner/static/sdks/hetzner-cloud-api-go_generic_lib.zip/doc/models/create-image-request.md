
# Create Image Request

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `*string` | Optional | Description of the Image, will be auto-generated if not set |
| `Labels` | [`*models.Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `Type` | [`*models.Type63Enum`](../../doc/models/type-63-enum.md) | Optional | Type of Image to create (default: `snapshot`) |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    createImageRequest := models.CreateImageRequest{
        Description:          models.ToPointer("my image"),
        Labels:               models.ToPointer(models.Labels{
            Labelkey:             models.ToPointer("labelkey4"),
        }),
        Type:                 models.ToPointer(models.Type63Enum_SNAPSHOT),
    }

}
```

