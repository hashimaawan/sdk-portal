# Pricing

Returns prices for resources.

```java
PricingController pricingController = client.getPricingController();
```

## Class Name

`PricingController`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```java
CompletableFuture<PricingResponse> getAllPricesAsync()
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

[`PricingResponse`](../../doc/models/pricing-response.md)

## Example Usage

```java
pricingController.getAllPricesAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

