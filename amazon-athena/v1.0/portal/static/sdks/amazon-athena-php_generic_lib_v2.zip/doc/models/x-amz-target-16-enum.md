
# X Amz Target 16 Enum

## Enumeration

`XAmzTarget16Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget16Enum;

$xAmzTarget16 = XAmzTarget16Enum::ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE;
```

