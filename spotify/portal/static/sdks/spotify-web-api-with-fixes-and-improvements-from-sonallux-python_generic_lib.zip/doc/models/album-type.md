
# Album Type

The type of the album.

## Enumeration

`AlbumType`

## Fields

| Name |
|  --- |
| `ALBUM` |
| `SINGLE` |
| `COMPILATION` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.album_type import AlbumType

album_type = AlbumType.COMPILATION
```

