# Datacenters

Each Datacenter represents a *virtual* Datacenter which is made up of possible many physical Datacenters where Servers are hosted.

Datacenter names are composed from their Location and virtual Datacenter number, for example `fsn1-dc14` means virtual Datacenter `14` in Location `fsn1`.

Right now there is only one Datacenter for each Location. The Datacenter numbers for `fsn`, `nbg` and `hel` are arbitrarily set to `14`, `3` and `2` for historic reasons and do not represent real physical Hetzner datacenters.

```ruby
datacenters_api = client.datacenters
```

## Class Name

`DatacentersApi`

## Methods

* [Get All Datacenters](../../doc/controllers/datacenters.md#get-all-datacenters)
* [Get a Datacenter](../../doc/controllers/datacenters.md#get-a-datacenter)


# Get All Datacenters

Returns all Datacenter objects.

```ruby
def get_all_datacenters(name: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter Datacenters by their name. The response will only contain the Datacenter matching the specified name. When the name does not match the Datacenter name format, an `invalid_input` error is returned. |

## Response Type

**200**: The reply contains the `datacenters` and `recommendation` keys

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`DatacentersResponse`](../../doc/models/datacenters-response.md).

## Example Usage

```ruby
result = datacenters_api.get_all_datacenters

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get a Datacenter

Returns a specific Datacenter object.

```ruby
def get_a_datacenter(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of Datacenter |

## Response Type

**200**: The `datacenter` key in the reply contains a Datacenter object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`DatacentersResponse1`](../../doc/models/datacenters-response-1.md).

## Example Usage

```ruby
id = 112

result = datacenters_api.get_a_datacenter(id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

