
# X Amz Target 37 Enum

## Enumeration

`XAmzTarget37Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNamedQueries` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget37Enum xAmzTarget37 = XAmzTarget37Enum.EnumAmazonAthenaListNamedQueries;
```

