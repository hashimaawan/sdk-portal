
# Parameter Sort Enum

## Enumeration

`ParameterSortEnum`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Command` |
| `EnumCommandasc` |
| `EnumCommanddesc` |
| `Status` |
| `EnumStatusasc` |
| `EnumStatusdesc` |
| `Progress` |
| `EnumProgressasc` |
| `EnumProgressdesc` |
| `Started` |
| `EnumStartedasc` |
| `EnumStarteddesc` |
| `Finished` |
| `EnumFinishedasc` |
| `EnumFinisheddesc` |

## Example

```ts
import { ParameterSortEnum } from 'hetzner-cloud-apilib';

const parameterSort = ParameterSortEnum.EnumStatusdesc;
```

