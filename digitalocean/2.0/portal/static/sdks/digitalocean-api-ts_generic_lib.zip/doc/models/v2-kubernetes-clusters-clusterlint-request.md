
# V2 Kubernetes Clusters Clusterlint Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersClusterlintRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `excludeChecks` | `string[] \| undefined` | Optional | An array of checks that will be run when clusterlint executes checks. |
| `excludeGroups` | `string[] \| undefined` | Optional | An array of check groups that will be omitted when clusterlint executes checks. |
| `includeChecks` | `string[] \| undefined` | Optional | An array of checks that will be run when clusterlint executes checks. |
| `includeGroups` | `string[] \| undefined` | Optional | An array of check groups that will be run when clusterlint executes checks. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2KubernetesClustersClusterlintRequest } from 'digitalocean-apilib';

const v2KubernetesClustersClusterlintRequest: V2KubernetesClustersClusterlintRequest = {
  excludeChecks: [
    'default-namespace'
  ],
  excludeGroups: [
    'workload-health'
  ],
  includeChecks: [
    'bare-pods',
    'resource-requirements'
  ],
  includeGroups: [
    'basic',
    'doks',
    'security'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

