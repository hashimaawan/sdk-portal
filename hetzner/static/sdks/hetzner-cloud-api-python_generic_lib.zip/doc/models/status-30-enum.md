
# Status 30 Enum

## Enumeration

`Status30Enum`

## Fields

| Name |
|  --- |
| `HEALTHY` |
| `UNHEALTHY` |
| `UNKNOWN` |

## Example

```python
from hetznercloudapi.models.status_30_enum import Status30Enum

status_30 = Status30Enum.HEALTHY
```

