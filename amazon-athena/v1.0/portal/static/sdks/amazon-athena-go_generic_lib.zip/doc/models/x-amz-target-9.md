
# X Amz Target 9

## Enumeration

`XAmzTarget9`

## Fields

| Name |
|  --- |
| `EnumAmazonathenadeletedatacatalog` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget9 := models.XAmzTarget9_EnumAmazonathenadeletedatacatalog

}
```

