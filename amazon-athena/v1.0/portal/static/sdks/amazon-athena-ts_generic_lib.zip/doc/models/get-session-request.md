
# Get Session Request

## Structure

`GetSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ts
import { GetSessionRequest } from 'amazon-athenalib';

const getSessionRequest: GetSessionRequest = {
  sessionId: 'SessionId2',
};
```

