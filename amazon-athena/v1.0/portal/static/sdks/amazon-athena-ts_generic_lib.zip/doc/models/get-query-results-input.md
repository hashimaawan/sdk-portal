
# Get Query Results Input

*This model accepts additional fields of type unknown.*

## Structure

`GetQueryResultsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 1000` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetQueryResultsInput } from 'amazon-athenalib';

const getQueryResultsInput: GetQueryResultsInput = {
  queryExecutionId: 'QueryExecutionId6',
  nextToken: 'NextToken2',
  maxResults: 42,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

