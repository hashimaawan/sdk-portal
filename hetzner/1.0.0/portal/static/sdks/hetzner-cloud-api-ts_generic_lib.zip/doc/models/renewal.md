
# Renewal

Status of the renewal process of the Certificate.

## Enumeration

`Renewal`

## Fields

| Name |
|  --- |
| `Scheduled` |
| `Pending` |
| `Failed` |
| `Unavailable` |

## Example

```ts
import { Renewal } from 'hetzner-cloud-apilib';

const renewal = Renewal.Failed;
```

