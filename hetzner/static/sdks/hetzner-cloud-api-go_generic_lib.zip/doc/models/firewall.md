
# Firewall

## Structure

`Firewall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppliedTo` | [`[]models.AppliedTo`](../../doc/models/applied-to.md) | Required | - |
| `Created` | `string` | Required | Point in time when the Resource was created (in ISO-8601 format) |
| `Id` | `int` | Required | ID of the Resource |
| `Labels` | `map[string]string` | Optional | User-defined labels (key-value pairs) |
| `Name` | `string` | Required | Name of the Resource. Must be unique per Project. |
| `Rules` | [`[]models.Rule`](../../doc/models/rule.md) | Required | - |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    firewall := models.Firewall{
        AppliedTo:            []models.AppliedTo{
            models.AppliedTo{
                AppliedToResources:   []models.AppliedToResource{
                    models.AppliedToResource{
                        Server:               models.ToPointer(models.Server{
                            Id:                   14,
                        }),
                        Type:                 models.ToPointer(models.Type5Enum_SERVER),
                    },
                },
                LabelSelector:        models.ToPointer(models.LabelSelector{
                    Selector:             "selector8",
                }),
                Server:               models.ToPointer(models.Server{
                    Id:                   14,
                }),
                Type:                 models.Type6Enum_SERVER,
            },
        },
        Created:              "2016-01-30T23:55:00+00:00",
        Id:                   42,
        Labels:               map[string]string{
            "key0": "labels2",
            "key1": "labels1",
        },
        Name:                 "my-resource",
        Rules:                []models.Rule{
            models.Rule{
                Description:          models.NewOptional(models.ToPointer("description2")),
                DestinationIps:       []string{
                    "28.239.13.1/32",
                    "28.239.14.0/24",
                    "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
                },
                Direction:            models.DirectionEnum_IN,
                Port:                 models.ToPointer("80"),
                Protocol:             models.ProtocolEnum_UDP,
                SourceIps:            []string{
                    "28.239.13.1/32",
                    "28.239.14.0/24",
                    "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
                },
            },
        },
    }

}
```

