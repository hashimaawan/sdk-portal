
# Acl Configuration 1

*This model accepts additional fields of type unknown.*

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s3AclOption` | [`S3AclOption1`](../../doc/models/s3-acl-option-1.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AclConfiguration1, S3AclOption1 } from 'amazon-athenalib';

const aclConfiguration1: AclConfiguration1 = {
  s3AclOption: S3AclOption1.BucketOwnerFullControl,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

