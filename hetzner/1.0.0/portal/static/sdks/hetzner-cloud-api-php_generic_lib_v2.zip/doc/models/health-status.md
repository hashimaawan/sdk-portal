
# Health Status

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `listenPort` | `?int` | Optional | - | getListenPort(): ?int | setListenPort(?int listenPort): void |
| `status` | [`?string(Status30Enum)`](../../doc/models/status-30-enum.md) | Optional | - | getStatus(): ?string | setStatus(?string status): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\HealthStatusBuilder;
use HetznerCloudAPILib\Models\Status30Enum;

$healthStatus = HealthStatusBuilder::init()
    ->listenPort(443)
    ->status(Status30Enum::HEALTHY)
    ->build();
```

