
# V2 Floating Ips Response 2

*This model accepts additional fields of type Object.*

## Structure

`V2FloatingIpsResponse2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FloatingIp` | [`FloatingIp1`](../../doc/models/floating-ip-1.md) | Optional | - | FloatingIp1 getFloatingIp() | setFloatingIp(FloatingIp1 floatingIp) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.FloatingIp1;
import com.digitalocean.api.models.Region;
import com.digitalocean.api.models.V2FloatingIpsResponse2;
import com.digitalocean.api.models.containers.FloatingIp1Droplet;
import java.io.IOException;
import java.util.Arrays;
import java.util.UUID;

V2FloatingIpsResponse2 v2FloatingIpsResponse2 = new V2FloatingIpsResponse2.Builder()
    .floatingIp(new FloatingIp1.Builder()
        .droplet(FloatingIp1Droplet.fromObject(
            ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
        ))
        .ip("ip2")
        .locked(false)
        .projectId(UUID.fromString("0000167e-0000-0000-0000-000000000000"))
        .region(new Region.Builder(
            false,
            Arrays.asList(
                "features7",
                "features8",
                "features9"
            ),
            "name6",
            Arrays.asList(
                "sizes6"
            ),
            "slug0"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

