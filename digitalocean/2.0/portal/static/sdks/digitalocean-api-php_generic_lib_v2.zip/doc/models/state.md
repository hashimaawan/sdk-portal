
# State

A string representing the current state of the certificate. It may be `pending`, `verified`, or `error`.

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `PENDING` |
| `VERIFIED` |
| `ERROR` |

## Example

```php
use DigitalOceanApiLib\Models\State;

$state = State::ERROR;
```

