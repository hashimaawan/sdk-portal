
# X Amz Target 45 Enum

## Enumeration

`XAmzTarget45Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTWORKGROUPS` |

## Example

```ruby
x_amz_target45 = XAmzTarget45Enum::ENUM_AMAZONATHENALISTWORKGROUPS
```

