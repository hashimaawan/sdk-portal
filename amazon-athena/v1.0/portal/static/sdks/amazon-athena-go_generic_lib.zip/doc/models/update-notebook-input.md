
# Update Notebook Input

## Structure

`UpdateNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NotebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `Payload` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `10485760` |
| `Type` | [`models.NotebookType2Enum`](../../doc/models/notebook-type-2-enum.md) | Required | - |
| `SessionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ClientRequestToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    updateNotebookInput := models.UpdateNotebookInput{
        NotebookId:           "NotebookId8",
        Payload:              "Payload4",
        Type:                 models.NotebookType2Enum_IPYNB,
        SessionId:            models.ToPointer("SessionId0"),
        ClientRequestToken:   models.ToPointer("ClientRequestToken2"),
    }

}
```

