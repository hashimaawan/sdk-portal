
# X Amz Target 30 Enum

## Enumeration

`XAmzTarget30Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAIMPORTNOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget30Enum;

$xAmzTarget30 = XAmzTarget30Enum::ENUM_AMAZONATHENAIMPORTNOTEBOOK;
```

