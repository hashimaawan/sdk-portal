
# Statement Type

## Enumeration

`StatementType`

## Fields

| Name |
|  --- |
| `Ddl` |
| `Dml` |
| `Utility` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    statementType := models.StatementType_Ddl

}
```

