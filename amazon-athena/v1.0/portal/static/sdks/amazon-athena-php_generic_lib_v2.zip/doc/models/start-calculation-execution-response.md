
# Start Calculation Execution Response

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `calculationExecutionId` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | getCalculationExecutionId(): ?string | setCalculationExecutionId(?string calculationExecutionId): void |
| `state` | [`?string(CalculationExecutionState4Enum)`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - | getState(): ?string | setState(?string state): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\StartCalculationExecutionResponseBuilder;
use AmazonAthenaLib\Models\CalculationExecutionState4Enum;

$startCalculationExecutionResponse = StartCalculationExecutionResponseBuilder::init()
    ->calculationExecutionId('CalculationExecutionId0')
    ->state(CalculationExecutionState4Enum::CANCELING)
    ->build();
```

