
# Create Presigned Notebook Url Request

*This model accepts additional fields of type interface{}.*

## Structure

`CreatePresignedNotebookUrlRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    createPresignedNotebookUrlRequest := models.CreatePresignedNotebookUrlRequest{
        SessionId:             "SessionId0",
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

