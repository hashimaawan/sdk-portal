
# Price Hourly

Hourly costs for a Resource in this Location

## Structure

`PriceHourly`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

PriceHourly priceHourly = new PriceHourly
{
    Gross = "1.1900000000000000",
    Net = "1.0000000000",
};
```

