
# List Engine Versions Input

*This model accepts additional fields of type Object.*

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 10` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
list_engine_versions_input = ListEngineVersionsInput.new(
  next_token: 'NextToken0',
  max_results: 10,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

