
# X Amz Target 22

## Enumeration

`XAmzTarget22`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetpreparedstatement` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget22 := models.XAmzTarget22_EnumAmazonathenagetpreparedstatement

}
```

