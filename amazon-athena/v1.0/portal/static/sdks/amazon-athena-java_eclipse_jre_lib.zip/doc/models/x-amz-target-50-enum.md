
# X Amz Target 50 Enum

## Enumeration

`XAmzTarget50Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPQUERYEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget50Enum;

XAmzTarget50Enum xAmzTarget50 = XAmzTarget50Enum.ENUM_AMAZONATHENASTOPQUERYEXECUTION;
```

