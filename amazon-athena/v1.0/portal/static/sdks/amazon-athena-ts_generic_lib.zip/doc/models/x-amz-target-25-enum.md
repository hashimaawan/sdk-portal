
# X Amz Target 25 Enum

## Enumeration

`XAmzTarget25Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryRuntimeStatistics` |

## Example

```ts
import { XAmzTarget25Enum } from 'amazon-athenalib';

const xAmzTarget25 = XAmzTarget25Enum.EnumAmazonAthenaGetQueryRuntimeStatistics;
```

