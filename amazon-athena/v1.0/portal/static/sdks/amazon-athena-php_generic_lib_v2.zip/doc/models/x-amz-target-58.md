
# X Amz Target 58

## Enumeration

`XAmzTarget58`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget58;

$xAmzTarget58 = XAmzTarget58::ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT;
```

