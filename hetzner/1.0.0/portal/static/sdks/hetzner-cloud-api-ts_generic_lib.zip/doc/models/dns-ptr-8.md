
# Dns Ptr 8

*This model accepts additional fields of type unknown.*

## Structure

`DnsPtr8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dnsPtr` | `string` | Required | DNS pointer for the specific IP address |
| `ip` | `string` | Required | Single IPv6 address of this Server for which the reverse DNS entry has been set up |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DnsPtr8 } from 'hetzner-cloud-apilib';

const dnsPtr8: DnsPtr8 = {
  dnsPtr: 'server.example.com',
  ip: '2001:db8::1',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

