
# Type 14

## Enumeration

`Type14`

## Fields

| Name |
|  --- |
| `APPLICATION` |
| `DISTRIBUTION` |

## Example

```ruby
type14 = Type14::APPLICATION
```

