
# Storage Type Enum

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageTypeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `NETWORK` |

## Example

```python
from hetznercloudapi.models.storage_type_enum import StorageTypeEnum

storage_type = StorageTypeEnum.LOCAL
```

