
# X Amz Target 24 Enum

## Enumeration

`XAmzTarget24Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryResults` |

## Example

```ts
import { XAmzTarget24Enum } from 'amazon-athenalib';

const xAmzTarget24 = XAmzTarget24Enum.EnumAmazonAthenaGetQueryResults;
```

