
# X Amz Target 57 Enum

## Enumeration

`XAmzTarget57Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNotebookMetadata` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget57Enum xAmzTarget57 = XAmzTarget57Enum.EnumAmazonAthenaUpdateNotebookMetadata;
```

