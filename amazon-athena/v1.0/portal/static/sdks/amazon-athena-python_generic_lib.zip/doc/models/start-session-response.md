
# Start Session Response

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `state` | [`SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```python
from amazonathena.models.session_state_1_enum import SessionState1Enum
from amazonathena.models.start_session_response import StartSessionResponse

start_session_response = StartSessionResponse(
    session_id='SessionId6',
    state=SessionState1Enum.DEGRADED
)
```

