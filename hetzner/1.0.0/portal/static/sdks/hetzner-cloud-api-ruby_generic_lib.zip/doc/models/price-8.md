
# Price 8

*This model accepts additional fields of type Object.*

## Structure

`Price8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location` | `String` | Required | Name of the Location the price is for |
| `price_hourly` | [`PriceHourly7`](../../doc/models/price-hourly-7.md) | Required | Hourly costs for a Primary IP type in this Location |
| `price_monthly` | [`PriceMonthly9`](../../doc/models/price-monthly-9.md) | Required | Monthly costs for a Primary IP type in this Location |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
price8 = Price8.new(
  location: 'fsn1',
  price_hourly: PriceHourly7.new(
    gross: '1.1900000000000000',
    net: '1.0000000000',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  price_monthly: PriceMonthly9.new(
    gross: '1.1900000000000000',
    net: '1.0000000000',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

