
# X Amz Target 2

## Enumeration

`XAmzTarget2`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_2 import XAmzTarget2

x_amz_target_2 = XAmzTarget2.ENUM_AMAZONATHENABATCHGETQUERYEXECUTION
```

