
# Executor Type Enum

## Enumeration

`ExecutorTypeEnum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```java
import com.amazonaws.useast1.athena.models.ExecutorTypeEnum;

ExecutorTypeEnum executorType = ExecutorTypeEnum.GATEWAY;
```

