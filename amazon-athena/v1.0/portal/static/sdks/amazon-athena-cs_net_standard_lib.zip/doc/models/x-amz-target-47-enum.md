
# X Amz Target 47 Enum

## Enumeration

`XAmzTarget47Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartQueryExecution` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget47Enum xAmzTarget47 = XAmzTarget47Enum.EnumAmazonAthenaStartQueryExecution;
```

