
# X Amz Target 1 Enum

## Enumeration

`XAmzTarget1Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget1 := models.XAmzTarget1Enum_ENUMAMAZONATHENABATCHGETPREPAREDSTATEMENT

}
```

