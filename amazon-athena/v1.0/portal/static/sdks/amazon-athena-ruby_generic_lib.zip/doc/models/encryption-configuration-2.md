
# Encryption Configuration 2

*This model accepts additional fields of type Object.*

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryption_option` | [`EncryptionOption1`](../../doc/models/encryption-option-1.md) | Required | - |
| `kms_key` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
encryption_configuration2 = EncryptionConfiguration2.new(
  encryption_option: EncryptionOption1::SSE_KMS,
  kms_key: 'KmsKey2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

