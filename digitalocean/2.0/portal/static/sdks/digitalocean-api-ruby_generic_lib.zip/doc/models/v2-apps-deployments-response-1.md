
# V2 Apps Deployments Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AppsDeploymentsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deployment` | [`AnAppDeployment`](../../doc/models/an-app-deployment.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_apps_deployments_response1 = V2AppsDeploymentsResponse1.new(
  deployment: AnAppDeployment.new(
    cause: 'cause8',
    cloned_from: 'cloned_from0',
    created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    functions: [
      FunctionsComponentsThatArePartOfThisDeployment.new(
        name: 'name4',
        namespace: 'namespace8',
        source_commit_hash: 'source_commit_hash4',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    id: 'id2',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

