
# Prepared Statement Summary

The name and last modified time of the prepared statement.

## Structure

`PreparedStatementSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statement_name` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `last_modified_time` | `DateTime` | Optional | - |

## Example

```ruby
prepared_statement_summary = PreparedStatementSummary.new(
  'StatementName0',
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z')
)
```

