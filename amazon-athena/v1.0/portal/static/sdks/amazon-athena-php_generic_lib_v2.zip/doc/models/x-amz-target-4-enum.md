
# X Amz Target 4 Enum

## Enumeration

`XAmzTarget4Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget4Enum;

$xAmzTarget4 = XAmzTarget4Enum::ENUM_AMAZONATHENACREATENAMEDQUERY;
```

