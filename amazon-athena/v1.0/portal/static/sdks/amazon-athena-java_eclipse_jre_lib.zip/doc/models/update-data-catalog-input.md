
# Update Data Catalog Input

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getName() | setName(String name) |
| `Type` | [`DataCatalogType3Enum`](../../doc/models/data-catalog-type-3-enum.md) | Required | - | DataCatalogType3Enum getType() | setType(DataCatalogType3Enum type) |
| `Description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getDescription() | setDescription(String description) |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - | Parameters getParameters() | setParameters(Parameters parameters) |

## Example

```java
import com.amazonaws.useast1.athena.models.DataCatalogType3Enum;
import com.amazonaws.useast1.athena.models.Parameters;
import com.amazonaws.useast1.athena.models.UpdateDataCatalogInput;

UpdateDataCatalogInput updateDataCatalogInput = new UpdateDataCatalogInput.Builder(
    "Name4",
    DataCatalogType3Enum.GLUE
)
.description("Description2")
.parameters(new Parameters.Builder()
        .build())
.build();
```

