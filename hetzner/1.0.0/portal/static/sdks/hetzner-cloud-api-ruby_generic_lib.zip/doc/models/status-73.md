
# Status 73

Status of the Server

## Enumeration

`Status73`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `INITIALIZING` |
| `STARTING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `MIGRATING` |
| `REBUILDING` |
| `UNKNOWN` |

## Example

```ruby
status73 = Status73::STARTING
```

