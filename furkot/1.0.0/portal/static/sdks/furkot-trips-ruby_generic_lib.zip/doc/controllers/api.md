# API

```ruby
client_api = client.client
```

## Class Name

`Api`

## Methods

* [Trip GET](../../doc/controllers/api.md#trip-get)
* [Trip Stop by Trip Id GET](../../doc/controllers/api.md#trip-stop-by-trip-id-get)


# Trip GET

list user's trips

```ruby
def trip_get
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`Array[Trip]`](../../doc/models/trip.md).

## Example Usage

```ruby
result = client_api.trip_get

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Trip Stop by Trip Id GET

list stops for a trip identified by {trip_id}

```ruby
def trip_stop_by_trip_id_get(trip_id)
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trip_id` | `String` | Template, Required | id of the trip |

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`Array[Step]`](../../doc/models/step.md).

## Example Usage

```ruby
trip_id = 'trip_id2'

result = client_api.trip_stop_by_trip_id_get(trip_id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

