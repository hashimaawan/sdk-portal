
# List Table Metadata Output

## Structure

`ListTableMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `table_metadata_list` | [`Array[TableMetadata]`](../../doc/models/table-metadata.md) | Optional | - |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_table_metadata_output = ListTableMetadataOutput.new(
  [
    TableMetadata.new(
      'Name2',
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      'TableType2',
      [
        Column.new(
          'Name0',
          'Type0',
          'Comment4'
        )
      ],
      [
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        ),
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        ),
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        )
      ],
      Parameters.new
    ),
    TableMetadata.new(
      'Name2',
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      'TableType2',
      [
        Column.new(
          'Name0',
          'Type0',
          'Comment4'
        )
      ],
      [
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        ),
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        ),
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        )
      ],
      Parameters.new
    ),
    TableMetadata.new(
      'Name2',
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      'TableType2',
      [
        Column.new(
          'Name0',
          'Type0',
          'Comment4'
        )
      ],
      [
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        ),
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        ),
        Column.new(
          'Name6',
          'Type6',
          'Comment0'
        )
      ],
      Parameters.new
    )
  ],
  'NextToken8'
)
```

