
# Calculation Result

Contains information about an application-specific calculation result.

## Structure

`CalculationResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `std_out_s_3_uri` | `str` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` |
| `std_error_s_3_uri` | `str` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` |
| `result_s_3_uri` | `str` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` |
| `result_type` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `\w+\/[-+.\w]+` |

## Example

```python
from amazonathena.models.calculation_result import CalculationResult

calculation_result = CalculationResult(
    std_out_s_3_uri='StdOutS3Uri0',
    std_error_s_3_uri='StdErrorS3Uri2',
    result_s_3_uri='ResultS3Uri4',
    result_type='ResultType8'
)
```

