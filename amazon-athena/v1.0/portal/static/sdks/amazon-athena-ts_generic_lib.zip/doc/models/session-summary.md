
# Session Summary

Contains summary information about a session.

## Structure

`SessionSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `engineVersion` | [`EngineVersion1 \| undefined`](../../doc/models/engine-version-1.md) | Optional | - |
| `notebookVersion` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `status` | [`Status3 \| undefined`](../../doc/models/status-3.md) | Optional | - |

## Example

```ts
import { SessionState1Enum, SessionSummary } from 'amazon-athenalib';

const sessionSummary: SessionSummary = {
  sessionId: 'SessionId0',
  description: 'Description8',
  engineVersion: {
    selectedEngineVersion: 'SelectedEngineVersion4',
    effectiveEngineVersion: 'EffectiveEngineVersion6',
  },
  notebookVersion: 'NotebookVersion2',
  status: {
    startDateTime: '2016-03-13T12:52:32.123Z',
    lastModifiedDateTime: '2016-03-13T12:52:32.123Z',
    endDateTime: '2016-03-13T12:52:32.123Z',
    idleSinceDateTime: '2016-03-13T12:52:32.123Z',
    state: SessionState1Enum.TERMINATING,
  },
};
```

