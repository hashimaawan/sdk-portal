# Volumes

A Volume is a highly-available, scalable, and SSD-based block storage for Servers.

Pricing for Volumes depends on the Volume size and Location, not the actual used storage.

Please see [Hetzner Docs](https://docs.hetzner.com/cloud/#Volumes) for more details about Volumes.

```php
$volumesController = $client->getVolumesController();
```

## Class Name

`VolumesController`

## Methods

* [Get All Volumes](../../doc/controllers/volumes.md#get-all-volumes)
* [Create a Volume](../../doc/controllers/volumes.md#create-a-volume)
* [Delete a Volume](../../doc/controllers/volumes.md#delete-a-volume)
* [Get a Volume](../../doc/controllers/volumes.md#get-a-volume)
* [Update a Volume](../../doc/controllers/volumes.md#update-a-volume)


# Get All Volumes

Gets all existing Volumes that you have available.

```php
function getAllVolumes(
    ?string $status = null,
    ?string $sort = null,
    ?string $name = null,
    ?string $labelSelector = null
): VolumesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`?string(Status23Enum)`](../../doc/models/status-23-enum.md) | Query, Optional | Can be used multiple times. The response will only contain Volumes matching the status. |
| `sort` | [`?string(SortEnum)`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `?string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `?string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `volumes` key contains a list of volumes

[`VolumesResponse`](../../doc/models/volumes-response.md)

## Example Usage

```php
$volumesController = $client->getVolumesController();

try {
    $result = $volumesController->getAllVolumes();
    echo 'VolumesResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Create a Volume

Creates a new Volume attached to a Server. If you want to create a Volume that is not attached to a Server, you need to provide the `location` key instead of `server`. This can be either the ID or the name of the Location this Volume will be created in. Note that a Volume can be attached to a Server only in the same Location as the Volume itself.

Specifying the Server during Volume creation will automatically attach the Volume to that Server after it has been initialized. In that case, the `next_actions` key in the response is an array which contains a single `attach_volume` action.

The minimum Volume size is 10GB and the maximum size is 10TB (10240GB).

A volume’s name can consist of alphanumeric characters, dashes, underscores, and dots, but has to start and end with an alphanumeric character. The total length is limited to 64 characters. Volume names must be unique per Project.

#### Call specific error codes

| Code                                | Description                                         |
|-------------------------------------|-----------------------------------------------------|
| `no_space_left_in_location`         | There is no volume space left in the given location |

```php
function createAVolume(?CreateVolumeRequest $body = null): VolumesResponse1
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?CreateVolumeRequest`](../../doc/models/create-volume-request.md) | Body, Optional | - |

## Response Type

**201**: The `volume` key contains the Volume that was just created

The `action` key contains the Action tracking Volume creation

[`VolumesResponse1`](../../doc/models/volumes-response-1.md)

## Example Usage

```php
$body = CreateVolumeRequestBuilder::init(
    'test-database',
    42
)
    ->automount(false)
    ->format('xfs')
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->location('nbg1')
    ->build();

$volumesController = $client->getVolumesController();

try {
    $result = $volumesController->createAVolume($body);
    echo 'VolumesResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "next_actions": [
    {
      "command": "attach_volume",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": null,
      "id": 13,
      "progress": 0,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 554,
          "type": "volume"
        }
      ],
      "started": "2016-01-30T23:50:00+00:00",
      "status": "running"
    }
  ],
  "volume": {
    "created": "2016-01-30T23:50:11+00:00",
    "format": "xfs",
    "id": 4711,
    "labels": {
      "env": "dev"
    },
    "linux_device": "/dev/disk/by-id/scsi-0HC_Volume_4711",
    "location": {
      "city": "Falkenstein",
      "country": "DE",
      "description": "Falkenstein DC Park 1",
      "id": 1,
      "latitude": 50.47612,
      "longitude": 12.370071,
      "name": "fsn1",
      "network_zone": "eu-central"
    },
    "name": "database-storage",
    "protection": {
      "delete": false
    },
    "server": 12,
    "size": 42,
    "status": "available"
  }
}
```


# Delete a Volume

Deletes a volume. All Volume data is irreversibly destroyed. The Volume must not be attached to a Server and it must not have delete protection enabled.

```php
function deleteAVolume(string $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the Volume |

## Response Type

**204**: Volume deleted

`void`

## Example Usage

```php
$id = 'id0';

$volumesController = $client->getVolumesController();

try {
    $volumesController->deleteAVolume($id);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get a Volume

Gets a specific Volume object.

```php
function getAVolume(int $id): VolumesResponse2
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |

## Response Type

**200**: The `volume` key contains the volume

[`VolumesResponse2`](../../doc/models/volumes-response-2.md)

## Example Usage

```php
$id = 112;

$volumesController = $client->getVolumesController();

try {
    $result = $volumesController->getAVolume($id);
    echo 'VolumesResponse2:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Update a Volume

Updates the Volume properties.

Note that when updating labels, the volume’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```php
function updateAVolume(string $id, ?UpdateVolumeRequest $body = null): VolumesResponse2
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the Volume to update |
| `body` | [`?UpdateVolumeRequest`](../../doc/models/update-volume-request.md) | Body, Optional | - |

## Response Type

**200**: The `volume` key contains the updated volume

[`VolumesResponse2`](../../doc/models/volumes-response-2.md)

## Example Usage

```php
$id = 'id0';

$body = UpdateVolumeRequestBuilder::init(
    'database-storage'
)->build();

$volumesController = $client->getVolumesController();

try {
    $result = $volumesController->updateAVolume(
        $id,
        $body
    );
    echo 'VolumesResponse2:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "volume": {
    "created": "2016-01-30T23:50:11+00:00",
    "format": "xfs",
    "id": 4711,
    "labels": {
      "labelkey": "value"
    },
    "linux_device": "/dev/disk/by-id/scsi-0HC_Volume_4711",
    "location": {
      "city": "Falkenstein",
      "country": "DE",
      "description": "Falkenstein DC Park 1",
      "id": 1,
      "latitude": 50.47612,
      "longitude": 12.370071,
      "name": "fsn1",
      "network_zone": "eu-central"
    },
    "name": "database-storage",
    "protection": {
      "delete": false
    },
    "server": 12,
    "size": 42,
    "status": "available"
  }
}
```

