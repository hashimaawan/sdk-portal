
# List Tags for Resource Output

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Tags` | [`List<Tag>`](../../doc/models/tag.md) | Optional | - | List<Tag> getTags() | setTags(List<Tag> tags) |
| `NextToken` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getNextToken() | setNextToken(String nextToken) |

## Example

```java
import com.amazonaws.useast1.athena.models.ListTagsForResourceOutput;
import com.amazonaws.useast1.athena.models.Tag;
import java.util.Arrays;

ListTagsForResourceOutput listTagsForResourceOutput = new ListTagsForResourceOutput.Builder()
    .tags(Arrays.asList(
        new Tag.Builder()
            .key("Key0")
            .value("Value6")
            .build(),
        new Tag.Builder()
            .key("Key0")
            .value("Value6")
            .build(),
        new Tag.Builder()
            .key("Key0")
            .value("Value6")
            .build()
    ))
    .nextToken("NextToken4")
    .build();
```

