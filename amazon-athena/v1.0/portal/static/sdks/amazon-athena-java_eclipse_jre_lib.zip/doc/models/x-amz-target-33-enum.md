
# X Amz Target 33 Enum

## Enumeration

`XAmzTarget33Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATACATALOGS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget33Enum;

XAmzTarget33Enum xAmzTarget33 = XAmzTarget33Enum.ENUM_AMAZONATHENALISTDATACATALOGS;
```

