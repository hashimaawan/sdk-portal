
# Update Volume Request

*This model accepts additional fields of type unknown.*

## Structure

`UpdateVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2 \| undefined`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `string` | Required | New Volume name |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UpdateVolumeRequest } from 'hetzner-cloud-apilib';

const updateVolumeRequest: UpdateVolumeRequest = {
  name: 'database-storage',
  labels: {
    labelkey: 'labelkey4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

