
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Item` |
| `Vault` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

M1PasswordConnect.Standard.Models.Type type = M1PasswordConnect.Standard.Models.Type.Item;
```

