
# Firewall 4

## Structure

`Firewall4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Firewall` | `Integer` | Optional | ID of the Firewall | Integer getFirewall() | setFirewall(Integer firewall) |

## Example

```java
import cloud.hetzner.api.models.Firewall4;

Firewall4 firewall4 = new Firewall4.Builder()
    .firewall(176)
    .build();
```

