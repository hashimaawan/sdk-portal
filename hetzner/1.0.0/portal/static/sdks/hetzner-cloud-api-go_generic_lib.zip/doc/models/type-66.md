
# Type 66

## Enumeration

`Type66`

## Fields

| Name |
|  --- |
| `Cpu` |
| `Disk` |
| `Network` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type66 := models.Type66_Network

}
```

