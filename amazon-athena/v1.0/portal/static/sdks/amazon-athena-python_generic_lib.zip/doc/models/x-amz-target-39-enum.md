
# X Amz Target 39 Enum

## Enumeration

`XAmzTarget39Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```python
from amazonathena.models.x_amz_target_39_enum import XAmzTarget39Enum

x_amz_target_39 = XAmzTarget39Enum.ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS
```

