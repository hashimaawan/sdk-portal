
# X Amz Target 6 Enum

## Enumeration

`XAmzTarget6Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target6 = XAmzTarget6Enum::ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT
```

