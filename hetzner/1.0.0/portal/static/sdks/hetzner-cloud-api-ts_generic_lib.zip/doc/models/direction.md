
# Direction

Select traffic direction on which rule should be applied. Use `source_ips` for direction `in` and `destination_ips` for direction `out`.

## Enumeration

`Direction`

## Fields

| Name |
|  --- |
| `In` |
| `Out` |

## Example

```ts
import { Direction } from 'hetzner-cloud-apilib';

const direction = Direction.In;
```

