
# List Named Queries Input

## Structure

`ListNamedQueriesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 0`, `<= 50` |
| `workGroup` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```ts
import { ListNamedQueriesInput } from 'amazon-athenalib';

const listNamedQueriesInput: ListNamedQueriesInput = {
  nextToken: 'NextToken8',
  maxResults: 50,
  workGroup: 'WorkGroup0',
};
```

