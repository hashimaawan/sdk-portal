
# List Notebook Metadata Output

## Structure

`ListNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |
| `notebookMetadataList` | [`?(NotebookMetadata[])`](../../doc/models/notebook-metadata.md) | Optional | - | getNotebookMetadataList(): ?array | setNotebookMetadataList(?array notebookMetadataList): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListNotebookMetadataOutputBuilder;
use AmazonAthenaLib\Models\Builders\NotebookMetadataBuilder;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\Models\NotebookType1Enum;

$listNotebookMetadataOutput = ListNotebookMetadataOutputBuilder::init()
    ->nextToken('NextToken2')
    ->notebookMetadataList(
        [
            NotebookMetadataBuilder::init()
                ->notebookId('NotebookId4')
                ->name('Name4')
                ->workGroup('WorkGroup6')
                ->creationTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->type(NotebookType1Enum::IPYNB)
                ->build()
        ]
    )
    ->build();
```

