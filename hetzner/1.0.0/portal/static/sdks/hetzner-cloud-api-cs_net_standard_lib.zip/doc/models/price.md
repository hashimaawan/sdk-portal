
# Price

## Structure

`Price`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Location` | `string` | Required | Name of the Location the price is for |
| `PriceHourly` | [`PriceHourly`](../../doc/models/price-hourly.md) | Required | Hourly costs for a Resource in this Location |
| `PriceMonthly` | [`PriceMonthly`](../../doc/models/price-monthly.md) | Required | Monthly costs for a Resource in this Location |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Price price = new Price
{
    Location = "fsn1",
    PriceHourly = new PriceHourly
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
    },
    PriceMonthly = new PriceMonthly
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
    },
};
```

