
# Type 26

Type of the ISO

## Enumeration

`Type26`

## Fields

| Name |
|  --- |
| `ENUM_PUBLIC` |
| `ENUM_PRIVATE` |

## Example

```java
import cloud.hetzner.api.models.Type26;

Type26 type26 = Type26.ENUM_PUBLIC;
```

