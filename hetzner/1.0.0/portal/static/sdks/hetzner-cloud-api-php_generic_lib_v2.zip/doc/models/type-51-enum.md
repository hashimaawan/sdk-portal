
# Type 51 Enum

Primary IP type

## Enumeration

`Type51Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```php
use HetznerCloudAPILib\Models\Type51Enum;

$type51 = Type51Enum::IPV4;
```

