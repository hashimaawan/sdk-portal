
# Load Balancers Actions Change Protection Request

## Structure

`LoadBalancersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Load Balancer from being deleted |

## Example

```ruby
load_balancers_actions_change_protection_request = LoadBalancersActionsChangeProtectionRequest.new(
  true
)
```

