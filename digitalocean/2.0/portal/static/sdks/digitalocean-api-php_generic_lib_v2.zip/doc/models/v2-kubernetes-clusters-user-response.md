
# V2 Kubernetes Clusters User Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUserResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `kubernetesClusterUser` | [`?KubernetesClusterUser`](../../doc/models/kubernetes-cluster-user.md) | Optional | - | getKubernetesClusterUser(): ?KubernetesClusterUser | setKubernetesClusterUser(?KubernetesClusterUser kubernetesClusterUser): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2KubernetesClustersUserResponseBuilder;
use DigitalOceanApiLib\Models\Builders\KubernetesClusterUserBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2KubernetesClustersUserResponse = V2KubernetesClustersUserResponseBuilder::init()
    ->kubernetesClusterUser(
        KubernetesClusterUserBuilder::init()
            ->groups(
                [
                    'groups8'
                ]
            )
            ->username('username6')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

