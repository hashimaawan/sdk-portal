
# Stop Query Execution Input

## Structure

`StopQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```python
from amazonathena.models.stop_query_execution_input import StopQueryExecutionInput

stop_query_execution_input = StopQueryExecutionInput(
    query_execution_id='QueryExecutionId6'
)
```

