
# Price Hourly 6

Hourly costs for a Load Balancer type in this network zone

## Structure

`PriceHourly6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

PriceHourly6 priceHourly6 = new PriceHourly6
{
    Gross = "1.1900000000000000",
    Net = "1.0000000000",
};
```

