
# V2 Firewalls Rules Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2FirewallsRulesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `inbound_rules` | [`List[InboundRule]`](../../doc/models/inbound-rule.md) | Required | - |
| `outbound_rules` | [`List[OutboundRule]`](../../doc/models/outbound-rule.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.destinations import Destinations
from digitaloceanapi.models.inbound_rule import InboundRule
from digitaloceanapi.models.outbound_rule import OutboundRule
from digitaloceanapi.models.protocol import Protocol
from digitaloceanapi.models.sources import Sources
from digitaloceanapi.models.v_2_firewalls_rules_request import V2FirewallsRulesRequest

v_2_firewalls_rules_request = V2FirewallsRulesRequest(
    inbound_rules=[
        InboundRule(
            ports='8000',
            protocol=Protocol.TCP,
            sources=Sources(
                addresses=[
                    '1.2.3.4',
                    '18.0.0.0/8'
                ],
                droplet_ids=[
                    8043964
                ],
                kubernetes_ids=[
                    '41b74c5d-9bd0-5555-5555-a57c495b81a3'
                ],
                load_balancer_uids=[
                    '4de7ac8b-495b-4884-9a69-1050c6793cd6'
                ],
                tags=[
                    'tags1',
                    'tags2',
                    'tags3'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    outbound_rules=[
        OutboundRule(
            ports='8000',
            protocol=Protocol.TCP,
            destinations=Destinations(
                addresses=[
                    '1.2.3.4',
                    '18.0.0.0/8'
                ],
                droplet_ids=[
                    8043964
                ],
                kubernetes_ids=[
                    '41b74c5d-9bd0-5555-5555-a57c495b81a3'
                ],
                load_balancer_uids=[
                    '4de7ac8b-495b-4884-9a69-1050c6793cd6'
                ],
                tags=[
                    'tags7',
                    'tags8',
                    'tags9'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

