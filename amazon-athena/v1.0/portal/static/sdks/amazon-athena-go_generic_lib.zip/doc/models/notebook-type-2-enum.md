
# Notebook Type 2 Enum

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    notebookType2 := models.NotebookType2Enum_IPYNB

}
```

