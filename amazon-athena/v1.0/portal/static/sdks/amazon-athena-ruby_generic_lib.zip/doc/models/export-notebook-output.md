
# Export Notebook Output

## Structure

`ExportNotebookOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_metadata` | [`NotebookMetadata1`](../../doc/models/notebook-metadata-1.md) | Optional | - |
| `payload` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `10485760` |

## Example

```ruby
export_notebook_output = ExportNotebookOutput.new(
  NotebookMetadata1.new(
    'NotebookId0',
    'Name0',
    'WorkGroup2',
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    NotebookType1Enum::IPYNB,
    DateTimeHelper.from_rfc3339(nil)
  ),
  'Payload6'
)
```

