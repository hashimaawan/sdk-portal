
# Oauth Scope Furkot Auth Implicit

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthImplicit`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list users trips info |

## Example

```ruby
oauth_scope_furkot_auth_implicit = OauthScopeFurkotAuthImplicit::READTRIPS
```

