
# Change IP Range Request

## Structure

`ChangeIPRangeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IpRange` | `string` | Required | The new prefix for the whole Network |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ChangeIPRangeRequest changeIPRangeRequest = new ChangeIPRangeRequest
{
    IpRange = "10.0.0.0/12",
};
```

