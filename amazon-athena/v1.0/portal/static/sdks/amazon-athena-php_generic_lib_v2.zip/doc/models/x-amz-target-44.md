
# X Amz Target 44

## Enumeration

`XAmzTarget44`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget44;

$xAmzTarget44 = XAmzTarget44::ENUM_AMAZONATHENALISTTAGSFORRESOURCE;
```

