
# Remove from Resources Request

*This model accepts additional fields of type Object.*

## Structure

`RemoveFromResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `remove_from` | [`Array[FirewallRemoveFromResources]`](../../doc/models/firewall-remove-from-resources.md) | Required | Resources the Firewall should be removed from |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
remove_from_resources_request = RemoveFromResourcesRequest.new(
  remove_from: [
    FirewallRemoveFromResources.new(
      label_selector: LabelSelector5.new(
        selector: 'selector8',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      server: Server9.new(
        id: 14,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      type: Type7::SERVER,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

