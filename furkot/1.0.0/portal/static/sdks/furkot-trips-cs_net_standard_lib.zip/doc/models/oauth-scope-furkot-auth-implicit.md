
# Oauth Scope Furkot Auth Implicit

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthImplicit`

## Fields

| Name | Description |
|  --- | --- |
| `Readtrips` | list users trips info |

## Example

```csharp
using FurkotTrips.Standard.Models;

OauthScopeFurkotAuthImplicit oauthScopeFurkotAuthImplicit = OauthScopeFurkotAuthImplicit.Readtrips;
```

