
# Label Selector 7

Label selector and a list of selected targets

## Structure

`LabelSelector7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `str` | Required | Label selector |

## Example

```python
from hetznercloudapi.models.label_selector_7 import LabelSelector7

label_selector_7 = LabelSelector7(
    selector='env=prod'
)
```

