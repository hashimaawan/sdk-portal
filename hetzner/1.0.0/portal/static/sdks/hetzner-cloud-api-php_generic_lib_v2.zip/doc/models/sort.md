
# Sort

## Enumeration

`Sort`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `NAME` |
| `ENUM_NAMEASC` |
| `ENUM_NAMEDESC` |
| `CREATED` |
| `ENUM_CREATEDASC` |
| `ENUM_CREATEDDESC` |

## Example

```php
use HetznerCloudApiLib\Models\Sort;

$sort = Sort::ENUM_IDASC;
```

