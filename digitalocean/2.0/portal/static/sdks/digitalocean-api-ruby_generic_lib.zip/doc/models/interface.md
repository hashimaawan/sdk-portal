
# Interface

## Enumeration

`Interface`

## Fields

| Name |
|  --- |
| `PRIVATE` |
| `PUBLIC` |

## Example

```ruby
interface = Interface::PRIVATE
```

