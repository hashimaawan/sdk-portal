
# Type 1

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `MString` |
| `Email` |
| `Concealed` |
| `Url` |
| `Totp` |
| `Date` |
| `MonthYear` |
| `Menu` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    type1 := models.Type1_Concealed

}
```

