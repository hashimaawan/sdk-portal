
# Type 19

The type of health check to perform.

## Enumeration

`Type19`

## Fields

| Name |
|  --- |
| `PING` |
| `HTTP` |
| `HTTPS` |

## Example

```python
from digitaloceanapi.models.type_19 import Type19

type_19 = Type19.HTTPS
```

