
# Query Execution State Enum

## Enumeration

`QueryExecutionStateEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    queryExecutionState := models.QueryExecutionStateEnum_CANCELLED

}
```

