# IS Os

ISOs are read-only Images of DVDs. While we recommend using our Image functionality to install your Servers we also provide some stock ISOs so you can install more exotic operating systems by yourself.

On request our support uploads a private ISO just for you. These are marked with type `private` and only visible in your Project.

To attach an ISO to your Server use `POST /servers/{id}/actions/attach_iso`.

```ruby
is_os_controller = client.is_os
```

## Class Name

`ISOsController`

## Methods

* [Get All IS Os](../../doc/controllers/is-os.md#get-all-is-os)
* [Get an ISO](../../doc/controllers/is-os.md#get-an-iso)


# Get All IS Os

Returns all available ISO objects.

```ruby
def get_all_is_os(name: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter ISOs by their name. The response will only contain the ISO matching the specified name. |

## Response Type

**200**: The `isos` key in the reply contains an array of iso objects with this structure

[`IsosResponse`](../../doc/models/isos-response.md)

## Example Usage

```ruby
result = is_os_controller.get_all_is_os
puts result
```


# Get an ISO

Returns a specific ISO object.

```ruby
def get_an_iso(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the ISO |

## Response Type

**200**: The `iso` key in the reply contains an array of ISO objects with this structure

[`IsosResponse1`](../../doc/models/isos-response-1.md)

## Example Usage

```ruby
id = 112

result = is_os_controller.get_an_iso(id)
puts result
```

