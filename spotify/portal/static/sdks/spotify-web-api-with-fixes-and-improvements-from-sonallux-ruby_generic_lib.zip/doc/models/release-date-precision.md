
# Release Date Precision

The precision with which `release_date` value is known.

## Enumeration

`ReleaseDatePrecision`

## Fields

| Name |
|  --- |
| `YEAR` |
| `MONTH` |
| `DAY` |

## Example

```ruby
release_date_precision = ReleaseDatePrecision::YEAR
```

