
# Executor Type Enum

## Enumeration

`ExecutorTypeEnum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ExecutorTypeEnum executorType = ExecutorTypeEnum.GATEWAY;
```

