
# X Amz Target 13 Enum

## Enumeration

`XAmzTarget13Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEWORKGROUP` |

## Example

```ruby
x_amz_target13 = XAmzTarget13Enum::ENUM_AMAZONATHENADELETEWORKGROUP
```

