
# Output Stage

## Structure

`OutputStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stage_id` | `int` | Optional | - |
| `state` | `str` | Optional | - |
| `output_bytes` | `int` | Optional | - |
| `output_rows` | `int` | Optional | - |
| `input_bytes` | `int` | Optional | - |
| `input_rows` | `int` | Optional | - |
| `execution_time` | `int` | Optional | - |
| `query_stage_plan` | [`QueryStagePlan`](../../doc/models/query-stage-plan.md) | Optional | - |
| `sub_stages` | [`List[QueryStage]`](../../doc/models/query-stage.md) | Optional | - |

## Example

```python
from amazonathena.models.output_stage import OutputStage

output_stage = OutputStage(
    stage_id=152,
    state='State2',
    output_bytes=86,
    output_rows=180,
    input_bytes=44
)
```

