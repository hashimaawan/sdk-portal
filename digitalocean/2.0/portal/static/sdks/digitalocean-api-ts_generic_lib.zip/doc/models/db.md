
# Db

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Db`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | The name of the database. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Db } from 'digitalocean-apilib';

const db: Db = {
  name: 'alpha',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

