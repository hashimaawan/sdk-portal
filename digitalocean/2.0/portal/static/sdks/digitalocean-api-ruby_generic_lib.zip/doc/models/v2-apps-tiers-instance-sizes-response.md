
# V2 Apps Tiers Instance Sizes Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AppsTiersInstanceSizesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `discount_percent` | `Float` | Optional | - |
| `instance_sizes` | [`Array[InstanceSize]`](../../doc/models/instance-size.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_apps_tiers_instance_sizes_response = V2AppsTiersInstanceSizesResponse.new(
  discount_percent: 2.32,
  instance_sizes: [
    InstanceSize.new(
      cpu_type: MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores::DEDICATED,
      cpus: 'cpus4',
      memory_bytes: 'memory_bytes8',
      name: 'name8',
      slug: 'slug8',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

