
# X Amz Target 12

## Enumeration

`XAmzTarget12`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_12 import XAmzTarget12

x_amz_target_12 = XAmzTarget12.ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT
```

