
# Status 113

Current status of the Volume

## Enumeration

`Status113`

## Fields

| Name |
|  --- |
| `CREATING` |
| `AVAILABLE` |

## Example

```php
use HetznerCloudApiLib\Models\Status113;

$status113 = Status113::CREATING;
```

