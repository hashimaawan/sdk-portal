
# V2 Account Keys Request

*This model accepts additional fields of type Object.*

## Structure

`V2AccountKeysRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | A human-readable display name for this key, used to easily identify the SSH keys when they are displayed. | String getName() | setName(String name) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.V2AccountKeysRequest;
import java.io.IOException;

V2AccountKeysRequest v2AccountKeysRequest = new V2AccountKeysRequest.Builder()
    .name("My SSH Public Key")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

