
# Calculation Execution State Enum

## Enumeration

`CalculationExecutionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```python
from amazonathena.models.calculation_execution_state_enum import CalculationExecutionStateEnum

calculation_execution_state = CalculationExecutionStateEnum.CANCELING
```

