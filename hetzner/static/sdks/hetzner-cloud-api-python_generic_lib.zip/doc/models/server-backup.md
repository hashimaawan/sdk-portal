
# Server Backup

Will increase base Server costs by specific percentage

## Structure

`ServerBackup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `percentage` | `str` | Required | Percentage by how much the base price will increase |

## Example

```python
from hetznercloudapi.models.server_backup import ServerBackup

server_backup = ServerBackup(
    percentage='20.0000000000'
)
```

