
# V2 Domains Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DomainsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `domain` | [`Domain1`](../../doc/models/domain-1.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_domains_response1 = V2DomainsResponse1.new(
  domain: Domain1.new(
    ip_address: 'ip_address6',
    name: 'example.com',
    ttl: 1800,
    zone_file: nil,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

