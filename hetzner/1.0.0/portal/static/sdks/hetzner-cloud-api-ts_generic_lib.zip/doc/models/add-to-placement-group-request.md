
# Add to Placement Group Request

*This model accepts additional fields of type unknown.*

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placementGroup` | `number` | Required | ID of Placement Group the Server should be added to |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AddToPlacementGroupRequest } from 'hetzner-cloud-apilib';

const addToPlacementGroupRequest: AddToPlacementGroupRequest = {
  placementGroup: 1,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

