
# X Amz Target 32

## Enumeration

`XAmzTarget32`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```ruby
x_amz_target32 = XAmzTarget32::ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS
```

