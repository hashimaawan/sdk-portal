
# Os Flavor Enum

Flavor of operating system contained in the Image

## Enumeration

`OsFlavorEnum`

## Fields

| Name |
|  --- |
| `Ubuntu` |
| `Centos` |
| `Debian` |
| `Fedora` |
| `Unknown` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

OsFlavorEnum osFlavor = OsFlavorEnum.Debian;
```

