
# V2 Sizes Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2SizesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sizes` | [`Array[Size]`](../../doc/models/size.md) | Required | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_sizes_response = V2SizesResponse.new(
  sizes: [
    Size.new(
      available: true,
      description: 'Basic',
      disk: 25,
      memory: 1024,
      price_hourly: 0.00743999984115362,
      price_monthly: 5,
      regions: [
        'ams2',
        'ams3',
        'blr1',
        'fra1',
        'lon1',
        'nyc1',
        'nyc2',
        'nyc3',
        'sfo1',
        'sfo2',
        'sfo3',
        'sgp1',
        'tor1'
      ],
      slug: 's-1vcpu-1gb',
      transfer: 1,
      vcpus: 1,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  meta: Meta.new(
    total: 64,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  links: Links.new(
    pages: Pages.new(
      last: 'https://api.digitalocean.com/v2/sizes?page=64&per_page=1',
      mnext: 'https://api.digitalocean.com/v2/sizes?page=2&per_page=1',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

