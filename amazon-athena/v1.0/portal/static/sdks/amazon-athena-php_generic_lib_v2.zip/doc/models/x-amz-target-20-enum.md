
# X Amz Target 20 Enum

## Enumeration

`XAmzTarget20Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget20Enum;

$xAmzTarget20 = XAmzTarget20Enum::ENUM_AMAZONATHENAGETNAMEDQUERY;
```

