
# X Amz Target 19 Enum

## Enumeration

`XAmzTarget19Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETDATABASE` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget19 := models.XAmzTarget19Enum_ENUMAMAZONATHENAGETDATABASE

}
```

