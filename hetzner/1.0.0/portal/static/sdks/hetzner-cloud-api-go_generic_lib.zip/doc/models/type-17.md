
# Type 17

Floating IP type

## Enumeration

`Type17`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type17 := models.Type17_Ipv4

}
```

