
# Encryption Option

## Enumeration

`EncryptionOption`

## Fields

| Name |
|  --- |
| `SseS3` |
| `SseKms` |
| `CseKms` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    encryptionOption := models.EncryptionOption_SseS3

}
```

