
# Work Group State 3

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    workGroupState3 := models.WorkGroupState3_Enabled

}
```

