
# Result Reuse by Age Configuration 2

*This model accepts additional fields of type interface{}.*

## Structure

`ResultReuseByAgeConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Enabled` | `bool` | Required | - |
| `MaxAgeInMinutes` | `*int` | Optional | **Constraints**: `>= 0`, `<= 10080` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    resultReuseByAgeConfiguration2 := models.ResultReuseByAgeConfiguration2{
        Enabled:               false,
        MaxAgeInMinutes:       models.ToPointer(44),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

