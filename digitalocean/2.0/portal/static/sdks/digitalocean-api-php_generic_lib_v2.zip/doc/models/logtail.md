
# Logtail

Logtail configuration.

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Logtail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `token` | `?string` | Optional | Logtail token. | getToken(): ?string | setToken(?string token): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\LogtailBuilder;
use DigitalOceanApiLib\ApiHelper;

$logtail = LogtailBuilder::init()
    ->token('abcdefghijklmnopqrstuvwxyz0123456789')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

