# Locations

Datacenters are organized by Locations. Datacenters in the same Location are connected with very low latency links.

```java
LocationsController locationsController = client.getLocationsController();
```

## Class Name

`LocationsController`

## Methods

* [Get All Locations](../../doc/controllers/locations.md#get-all-locations)
* [Get a Location](../../doc/controllers/locations.md#get-a-location)


# Get All Locations

Returns all Location objects.

```java
CompletableFuture<LocationsResponse> getAllLocationsAsync(
    final String name)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter Locations by their name. The response will only contain the Location matching the specified name. |

## Response Type

**200**: The `locations` key in the reply contains an array of Location objects with this structure

[`LocationsResponse`](../../doc/models/locations-response.md)

## Example Usage

```java
locationsController.getAllLocationsAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a Location

Returns a specific Location object.

```java
CompletableFuture<LocationsResponse1> getALocationAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Location |

## Response Type

**200**: The `location` key in the reply contains a Location object with this structure

[`LocationsResponse1`](../../doc/models/locations-response-1.md)

## Example Usage

```java
int id = 112;

locationsController.getALocationAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

