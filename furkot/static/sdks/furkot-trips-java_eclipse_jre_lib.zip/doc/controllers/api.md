# API

```java
APIController aPIController = client.getAPIController();
```

## Class Name

`APIController`

## Methods

* [Trip GET](../../doc/controllers/api.md#trip-get)
* [Trip Stop by Trip Id GET](../../doc/controllers/api.md#trip-stop-by-trip-id-get)


# Trip GET

list user's trips

```java
CompletableFuture<List<Trip>> tripGETAsync()
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

[`List<Trip>`](../../doc/models/trip.md)

## Example Usage

```java
aPIController.tripGETAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Trip Stop by Trip Id GET

list stops for a trip identified by {trip_id}

```java
CompletableFuture<List<Step>> tripStopByTripIdGETAsync(
    final String tripId)
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tripId` | `String` | Template, Required | id of the trip |

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

[`List<Step>`](../../doc/models/step.md)

## Example Usage

```java
String tripId = "trip_id2";

aPIController.tripStopByTripIdGETAsync(tripId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

