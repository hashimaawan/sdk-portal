
# Session Configuration

Contains session configuration information.

*This model accepts additional fields of type Any.*

## Structure

`SessionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `execution_role` | `str` | Optional | **Constraints**: *Minimum Length*: `20`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:iam::\d{12}:role/?[a-zA-Z_0-9+=,.@\-_/]+$` |
| `working_directory` | `str` | Optional | - |
| `idle_timeout_seconds` | `int` | Optional | - |
| `encryption_configuration` | [`EncryptionConfiguration`](../../doc/models/encryption-configuration.md) | Optional | If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information. |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.encryption_configuration import EncryptionConfiguration
from amazonathena.models.encryption_option_1 import EncryptionOption1
from amazonathena.models.session_configuration import SessionConfiguration

session_configuration = SessionConfiguration(
    execution_role='ExecutionRole8',
    working_directory='WorkingDirectory2',
    idle_timeout_seconds=176,
    encryption_configuration=EncryptionConfiguration(
        encryption_option=EncryptionOption1.SSE_S3,
        kms_key='KmsKey6',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

