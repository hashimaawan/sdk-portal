
# V2 Databases Online Migration Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesOnlineMigrationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `createdAt` | `?string` | Optional | The time the migration was initiated, in ISO 8601 format. | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |
| `id` | `?string` | Optional | The ID of the most recent migration. | getId(): ?string | setId(?string id): void |
| `status` | [`?string(Status5)`](../../doc/models/status-5.md) | Optional | The current status of the migration. | getStatus(): ?string | setStatus(?string status): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesOnlineMigrationResponseBuilder;
use DigitalOceanApiLib\Models\Status5;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesOnlineMigrationResponse = V2DatabasesOnlineMigrationResponseBuilder::init()
    ->createdAt('2020-10-29T15:57:38Z')
    ->id('77b28fc8-19ff-11eb-8c9c-c68e24557488')
    ->status(Status5::RUNNING)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

