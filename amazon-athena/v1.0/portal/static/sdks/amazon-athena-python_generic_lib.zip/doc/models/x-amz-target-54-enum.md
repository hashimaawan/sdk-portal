
# X Amz Target 54 Enum

## Enumeration

`XAmzTarget54Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEDATACATALOG` |

## Example

```python
from amazonathena.models.x_amz_target_54_enum import XAmzTarget54Enum

x_amz_target_54 = XAmzTarget54Enum.ENUM_AMAZONATHENAUPDATEDATACATALOG
```

