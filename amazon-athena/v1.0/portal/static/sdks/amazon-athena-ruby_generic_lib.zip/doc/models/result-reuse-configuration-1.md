
# Result Reuse Configuration 1

## Structure

`ResultReuseConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result_reuse_by_age_configuration` | [`ResultReuseByAgeConfiguration2`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |

## Example

```ruby
result_reuse_configuration1 = ResultReuseConfiguration1.new(
  ResultReuseByAgeConfiguration2.new(
    false,
    26
  )
)
```

