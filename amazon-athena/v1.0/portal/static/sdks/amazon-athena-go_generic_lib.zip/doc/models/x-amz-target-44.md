
# X Amz Target 44

## Enumeration

`XAmzTarget44`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalisttagsforresource` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget44 := models.XAmzTarget44_EnumAmazonathenalisttagsforresource

}
```

