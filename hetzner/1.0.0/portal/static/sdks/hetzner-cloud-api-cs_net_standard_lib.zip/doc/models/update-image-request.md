
# Update Image Request

*This model accepts additional fields of type object.*

## Structure

`UpdateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Optional | New description of Image |
| `Labels` | `object` | Optional | User-defined labels (key-value pairs) |
| `Type` | [`Type24?`](../../doc/models/type-24.md) | Optional | Destination Image type to convert to |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

UpdateImageRequest updateImageRequest = new UpdateImageRequest
{
    Description = "My new Image description",
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Type = Type24.Snapshot,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

