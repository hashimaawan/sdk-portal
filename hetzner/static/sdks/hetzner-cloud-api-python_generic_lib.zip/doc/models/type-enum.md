
# Type Enum

Type of the Certificate

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```python
from hetznercloudapi.models.type_enum import TypeEnum

mtype = TypeEnum.UPLOADED
```

