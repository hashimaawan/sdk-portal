
# X Amz Target 54 Enum

## Enumeration

`XAmzTarget54Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAUPDATEDATACATALOG` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget54 := models.XAmzTarget54Enum_ENUMAMAZONATHENAUPDATEDATACATALOG

}
```

