
# Type

The object type.

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Artist` |

## Example

```ts
import {
  Type,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const type = Type.Artist;
```

