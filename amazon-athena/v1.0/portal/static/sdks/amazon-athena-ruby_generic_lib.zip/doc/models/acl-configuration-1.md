
# Acl Configuration 1

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s_3_acl_option` | [`S3AclOption1Enum`](../../doc/models/s3-acl-option-1-enum.md) | Required | - |

## Example

```ruby
acl_configuration1 = AclConfiguration1.new(
  S3AclOption1Enum::BUCKET_OWNER_FULL_CONTROL
)
```

