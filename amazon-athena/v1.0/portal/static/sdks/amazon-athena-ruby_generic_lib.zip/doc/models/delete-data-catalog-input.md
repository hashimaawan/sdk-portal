
# Delete Data Catalog Input

## Structure

`DeleteDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ruby
delete_data_catalog_input = DeleteDataCatalogInput.new(
  'Name2'
)
```

