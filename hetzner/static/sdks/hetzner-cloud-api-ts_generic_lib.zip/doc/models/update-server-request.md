
# Update Server Request

## Structure

`UpdateServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New name to set |

## Example

```ts
import { UpdateServerRequest } from 'hetzner-cloud-apilib';

const updateServerRequest: UpdateServerRequest = {
  labels: { 'labelkey': 'value' },
  name: 'my-server',
};
```

