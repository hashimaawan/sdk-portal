# Gifs

```php
$gifsController = $client->getGifsController();
```

## Class Name

`GifsController`

## Methods

* [Get Gifs by Id](../../doc/controllers/gifs.md#get-gifs-by-id)
* [Random Gif](../../doc/controllers/gifs.md#random-gif)
* [Search Gifs](../../doc/controllers/gifs.md#search-gifs)
* [Translate Gif](../../doc/controllers/gifs.md#translate-gif)
* [Trending Gifs](../../doc/controllers/gifs.md#trending-gifs)
* [Get Gif by Id](../../doc/controllers/gifs.md#get-gif-by-id)


# Get Gifs by Id

A multiget version of the get GIF by ID endpoint.

```php
function getGifsById(?string $ids = null): GifsResponse
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ids` | `?string` | Query, Optional | Filters results by specified GIF IDs, separated by commas. |

## Response Type

**200**

[`GifsResponse`](../../doc/models/gifs-response.md)

## Example Usage

```php
$gifsController = $client->getGifsController();

try {
    $result = $gifsController->getGifsById();
    echo 'GifsResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Random Gif

Returns a random GIF, limited by tag. Excluding the tag parameter will return a random GIF from the GIPHY catalog.

```php
function randomGif(?string $tag = null, ?string $rating = null): GifsRandomResponse
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tag` | `?string` | Query, Optional | Filters results by specified tag. |
| `rating` | `?string` | Query, Optional | Filters results by specified rating. |

## Response Type

**200**

[`GifsRandomResponse`](../../doc/models/gifs-random-response.md)

## Example Usage

```php
$gifsController = $client->getGifsController();

try {
    $result = $gifsController->randomGif();
    echo 'GifsRandomResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Search Gifs

Search all GIPHY GIFs for a word or phrase. Punctuation will be stripped and ignored.  Use a plus or url encode for phrases. Example paul+rudd, ryan+gosling or american+psycho.

```php
function searchGifs(
    string $q,
    ?int $limit = 25,
    ?int $offset = 0,
    ?string $rating = null,
    ?string $lang = null
): GifsSearchResponse
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `q` | `string` | Query, Required | Search query term or prhase. |
| `limit` | `?int` | Query, Optional | The maximum number of records to return.<br><br>**Default**: `25` |
| `offset` | `?int` | Query, Optional | An optional results offset.<br><br>**Default**: `0` |
| `rating` | `?string` | Query, Optional | Filters results by specified rating. |
| `lang` | `?string` | Query, Optional | Specify default language for regional content; use a 2-letter ISO 639-1 language code. |

## Response Type

**200**: Search results

[`GifsSearchResponse`](../../doc/models/gifs-search-response.md)

## Example Usage

```php
$q = 'q0';

$limit = 25;

$offset = 0;

$gifsController = $client->getGifsController();

try {
    $result = $gifsController->searchGifs(
        $q,
        $limit,
        $offset
    );
    echo 'GifsSearchResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Translate Gif

The translate API draws on search, but uses the GIPHY `special sauce` to handle translating from one vocabulary to another. In this case, words and phrases to GIF

```php
function translateGif(string $s): GifsTranslateResponse
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s` | `string` | Query, Required | Search term. |

## Response Type

**200**

[`GifsTranslateResponse`](../../doc/models/gifs-translate-response.md)

## Example Usage

```php
$s = 's8';

$gifsController = $client->getGifsController();

try {
    $result = $gifsController->translateGif($s);
    echo 'GifsTranslateResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Trending Gifs

Fetch GIFs currently trending online. Hand curated by the GIPHY editorial team.  The data returned mirrors the GIFs showcased on the GIPHY homepage. Returns 25 results by default.

```php
function trendingGifs(?int $limit = 25, ?int $offset = 0, ?string $rating = null): GifsTrendingResponse
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `?int` | Query, Optional | The maximum number of records to return.<br><br>**Default**: `25` |
| `offset` | `?int` | Query, Optional | An optional results offset.<br><br>**Default**: `0` |
| `rating` | `?string` | Query, Optional | Filters results by specified rating. |

## Response Type

**200**

[`GifsTrendingResponse`](../../doc/models/gifs-trending-response.md)

## Example Usage

```php
$limit = 25;

$offset = 0;

$gifsController = $client->getGifsController();

try {
    $result = $gifsController->trendingGifs(
        $limit,
        $offset
    );
    echo 'GifsTrendingResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Get Gif by Id

Returns a GIF given that GIF's unique ID

```php
function getGifById(int $gifId): GifsResponse1
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gifId` | `int` | Template, Required | Filters results by specified GIF ID. |

## Response Type

**200**

[`GifsResponse1`](../../doc/models/gifs-response-1.md)

## Example Usage

```php
$gifId = 250;

$gifsController = $client->getGifsController();

try {
    $result = $gifsController->getGifById($gifId);
    echo 'GifsResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |

