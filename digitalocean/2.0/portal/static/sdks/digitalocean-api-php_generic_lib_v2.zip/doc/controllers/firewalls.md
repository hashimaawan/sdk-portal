# Firewalls

[DigitalOcean Cloud Firewalls](https://www.digitalocean.com/docs/networking/firewalls/)
provide the ability to restrict network access to and from a Droplet
allowing you to define which ports will accept inbound or outbound
connections. By sending requests to the `/v2/firewalls` endpoint, you can
list, create, or delete firewalls as well as modify access rules.

```php
$firewallsApi = $client->getFirewallsApi();
```

## Class Name

`FirewallsApi`

## Methods

* [Firewalls List](../../doc/controllers/firewalls.md#firewalls-list)
* [Firewalls Create](../../doc/controllers/firewalls.md#firewalls-create)
* [Firewalls Delete](../../doc/controllers/firewalls.md#firewalls-delete)
* [Firewalls Get](../../doc/controllers/firewalls.md#firewalls-get)
* [Firewalls Update](../../doc/controllers/firewalls.md#firewalls-update)
* [Firewalls Delete Droplets](../../doc/controllers/firewalls.md#firewalls-delete-droplets)
* [Firewalls Assign Droplets](../../doc/controllers/firewalls.md#firewalls-assign-droplets)
* [Firewalls Delete Rules](../../doc/controllers/firewalls.md#firewalls-delete-rules)
* [Firewalls Add Rules](../../doc/controllers/firewalls.md#firewalls-add-rules)
* [Firewalls Delete Tags](../../doc/controllers/firewalls.md#firewalls-delete-tags)
* [Firewalls Add Tags](../../doc/controllers/firewalls.md#firewalls-add-tags)


# Firewalls List

To list all of the firewalls available on your account, send a GET request to `/v2/firewalls`.

```php
function firewallsList(?int $perPage = 20, ?int $page = 1): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: To list all of the firewalls available on your account, send a GET request to `/v2/firewalls`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2FirewallsResponse`](../../doc/models/v2-firewalls-response.md).

## Example Usage

```php
$perPage = 2;

$page = 1;

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsList(
    $perPage,
    $page
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2FirewallsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "firewalls": [
    {
      "created_at": "2017-05-23T21:23:59Z",
      "droplet_ids": [
        8043964
      ],
      "id": "fb6045f1-cf1d-4ca3-bfac-18832663025b",
      "inbound_rules": [
        {
          "ports": "80",
          "protocol": "tcp",
          "sources": {
            "load_balancer_uids": [
              "4de7ac8b-495b-4884-9a69-1050c6793cd6"
            ]
          }
        },
        {
          "ports": "22",
          "protocol": "tcp",
          "sources": {
            "addresses": [
              "18.0.0.0/8"
            ],
            "tags": [
              "gateway"
            ]
          }
        }
      ],
      "name": "firewall",
      "outbound_rules": [
        {
          "destinations": {
            "addresses": [
              "0.0.0.0/0",
              "::/0"
            ]
          },
          "ports": "80",
          "protocol": "tcp"
        }
      ],
      "pending_changes": [],
      "status": "succeeded",
      "tags": []
    }
  ],
  "links": {},
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Create

To create a new firewall, send a POST request to `/v2/firewalls`. The request
must contain at least one inbound or outbound access rule.

```php
function firewallsCreate(?V2FirewallsRequest $body = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?V2FirewallsRequest`](../../doc/models/v2-firewalls-request.md) | Body, Optional | - |

## Response Type

**202**: The response will be a JSON object with a firewall key. This will be set to an object containing the standard firewall attributes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```php
$body = V2FirewallsRequestBuilder::init(
    'firewall'
)
    ->dropletIds(
        [
            8043964
        ]
    )
    ->inboundRules(
        [
            InboundRuleBuilder::init(
                '80',
                Protocol::TCP,
                SourcesBuilder::init()
                    ->loadBalancerUids(
                        [
                            '4de7ac8b-495b-4884-9a69-1050c6793cd6'
                        ]
                    )
                    ->build()
            )->build(),
            InboundRuleBuilder::init(
                '22',
                Protocol::TCP,
                SourcesBuilder::init()
                    ->addresses(
                        [
                            '18.0.0.0/8'
                        ]
                    )
                    ->tags(
                        [
                            'gateway'
                        ]
                    )
                    ->build()
            )->build()
        ]
    )
    ->outboundRules(
        [
            OutboundRuleBuilder::init(
                '80',
                Protocol::TCP,
                DestinationsBuilder::init()
                    ->addresses(
                        [
                            '0.0.0.0/0',
                            '::/0'
                        ]
                    )
                    ->build()
            )->build()
        ]
    )->build();

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsCreate($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2FirewallsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2017-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [
      {
        "droplet_id": 8043964,
        "removing": false,
        "status": "waiting"
      }
    ],
    "status": "waiting",
    "tags": []
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Delete

To delete a firewall send a DELETE request to `/v2/firewalls/$FIREWALL_ID`.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function firewallsDelete(string $firewallId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsDelete($firewallId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Get

To show information about an existing firewall, send a GET request to `/v2/firewalls/$FIREWALL_ID`.

```php
function firewallsGet(string $firewallId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |

## Response Type

**200**: The response will be a JSON object with a firewall key. This will be set to an object containing the standard firewall attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsGet($firewallId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2FirewallsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2017-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [],
    "status": "succeeded",
    "tags": []
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Update

To update the configuration of an existing firewall, send a PUT request to
`/v2/firewalls/$FIREWALL_ID`. The request should contain a full representation
of the firewall including existing attributes. **Note that any attributes that
are not provided will be reset to their default values.**

```php
function firewallsUpdate(string $firewallId, ?V2FirewallsRequest $body = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`?V2FirewallsRequest`](../../doc/models/v2-firewalls-request.md) | Body, Optional | - |

## Response Type

**200**: The response will be a JSON object with a `firewall` key. This will be set to an object containing the standard firewall attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$body = V2FirewallsRequestBuilder::init(
    'frontend-firewall'
)
    ->dropletIds(
        [
            8043964
        ]
    )
    ->tags(
        [
            'frontend'
        ]
    )
    ->inboundRules(
        [
            InboundRuleBuilder::init(
                '8080',
                Protocol::TCP,
                SourcesBuilder::init()
                    ->loadBalancerUids(
                        [
                            '4de7ac8b-495b-4884-9a69-1050c6793cd6'
                        ]
                    )
                    ->build()
            )->build(),
            InboundRuleBuilder::init(
                '22',
                Protocol::TCP,
                SourcesBuilder::init()
                    ->addresses(
                        [
                            '18.0.0.0/8'
                        ]
                    )
                    ->tags(
                        [
                            'gateway'
                        ]
                    )
                    ->build()
            )->build()
        ]
    )
    ->outboundRules(
        [
            OutboundRuleBuilder::init(
                '8080',
                Protocol::TCP,
                DestinationsBuilder::init()
                    ->addresses(
                        [
                            '0.0.0.0/0',
                            '::/0'
                        ]
                    )
                    ->build()
            )->build()
        ]
    )->build();

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsUpdate(
    $firewallId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2FirewallsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2020-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "frontend-firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [
      {
        "droplet_id": 8043964,
        "removing": false,
        "status": "waiting"
      }
    ],
    "status": "waiting",
    "tags": [
      "frontend"
    ]
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Delete Droplets

To remove a Droplet from a firewall, send a DELETE request to
`/v2/firewalls/$FIREWALL_ID/droplets`. In the body of the request, there should
be a `droplet_ids` attribute containing a list of Droplet IDs.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function firewallsDeleteDroplets(string $firewallId, ?V2FirewallsDropletsRequest $body = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`?V2FirewallsDropletsRequest`](../../doc/models/v2-firewalls-droplets-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$body = V2FirewallsDropletsRequestBuilder::init(
    [
        49696269
    ]
)->build();

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsDeleteDroplets(
    $firewallId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Assign Droplets

To assign a Droplet to a firewall, send a POST request to
`/v2/firewalls/$FIREWALL_ID/droplets`. In the body of the request, there
should be a `droplet_ids` attribute containing a list of Droplet IDs.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function firewallsAssignDroplets(string $firewallId, ?V2FirewallsDropletsRequest1 $body = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`?V2FirewallsDropletsRequest1`](../../doc/models/v2-firewalls-droplets-request-1.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$body = V2FirewallsDropletsRequest1Builder::init(
    [
        49696269
    ]
)->build();

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsAssignDroplets(
    $firewallId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Delete Rules

To remove access rules from a firewall, send a DELETE request to
`/v2/firewalls/$FIREWALL_ID/rules`. The body of the request may include an
`inbound_rules` and/or `outbound_rules` attribute containing an array of rules
to be removed.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function firewallsDeleteRules(string $firewallId, ?V2FirewallsRulesRequest $body = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`?V2FirewallsRulesRequest`](../../doc/models/v2-firewalls-rules-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$body = V2FirewallsRulesRequestBuilder::init()
    ->inboundRules(
        [
            InboundRuleBuilder::init(
                '3306',
                Protocol::TCP,
                SourcesBuilder::init()
                    ->dropletIds(
                        [
                            49696269
                        ]
                    )
                    ->build()
            )->build()
        ]
    )
    ->outboundRules(
        [
            OutboundRuleBuilder::init(
                '3306',
                Protocol::TCP,
                DestinationsBuilder::init()
                    ->dropletIds(
                        [
                            49696269
                        ]
                    )
                    ->build()
            )->build()
        ]
    )->build();

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsDeleteRules(
    $firewallId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Add Rules

To add additional access rules to a firewall, send a POST request to
`/v2/firewalls/$FIREWALL_ID/rules`. The body of the request may include an
inbound_rules and/or outbound_rules attribute containing an array of rules to
be added.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function firewallsAddRules(string $firewallId, ?V2FirewallsRulesRequest $body = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`?V2FirewallsRulesRequest`](../../doc/models/v2-firewalls-rules-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$body = V2FirewallsRulesRequestBuilder::init()
    ->inboundRules(
        [
            InboundRuleBuilder::init(
                '3306',
                Protocol::TCP,
                SourcesBuilder::init()
                    ->dropletIds(
                        [
                            49696269
                        ]
                    )
                    ->build()
            )->build()
        ]
    )
    ->outboundRules(
        [
            OutboundRuleBuilder::init(
                '3306',
                Protocol::TCP,
                DestinationsBuilder::init()
                    ->dropletIds(
                        [
                            49696269
                        ]
                    )
                    ->build()
            )->build()
        ]
    )->build();

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsAddRules(
    $firewallId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Delete Tags

To remove a tag representing a group of Droplets from a firewall, send a
DELETE request to `/v2/firewalls/$FIREWALL_ID/tags`. In the body of the
request, there should be a `tags` attribute containing a list of tag names.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function firewallsDeleteTags(string $firewallId, ?V2FirewallsTagsRequest $body = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`?V2FirewallsTagsRequest`](../../doc/models/v2-firewalls-tags-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$body = V2FirewallsTagsRequestBuilder::init()
    ->tags(
        [
            'frontend'
        ]
    )
    ->build();

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsDeleteTags(
    $firewallId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Add Tags

To assign a tag representing a group of Droplets to a firewall, send a POST
request to `/v2/firewalls/$FIREWALL_ID/tags`. In the body of the request,
there should be a `tags` attribute containing a list of tag names.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function firewallsAddTags(string $firewallId, ?V2FirewallsTagsRequest $body = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`?V2FirewallsTagsRequest`](../../doc/models/v2-firewalls-tags-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

$body = V2FirewallsTagsRequestBuilder::init()
    ->tags(
        [
            'frontend'
        ]
    )
    ->build();

$firewallsApi = $client->getFirewallsApi();
$apiResponse = $firewallsApi->firewallsAddTags(
    $firewallId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

