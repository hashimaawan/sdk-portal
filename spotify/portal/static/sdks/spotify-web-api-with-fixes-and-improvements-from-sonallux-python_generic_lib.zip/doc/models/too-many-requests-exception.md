
# Too Many Requests Exception

*This model accepts additional fields of type Any.*

## Structure

`TooManyRequestsException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`ErrorObject`](../../doc/models/error-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
try:
    # make the API call
except TooManyRequestsException as e:
    print(e)
except ApiException as e:
    print(e)
```

