
# X Amz Target 35 Enum

## Enumeration

`XAmzTarget35Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTENGINEVERSIONS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget35 := models.XAmzTarget35Enum_ENUMAMAZONATHENALISTENGINEVERSIONS

}
```

