
# Region 2

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```php
use AmazonAthenaLib\Models\Region2;

$region2 = Region2::CNNORTH1;
```

