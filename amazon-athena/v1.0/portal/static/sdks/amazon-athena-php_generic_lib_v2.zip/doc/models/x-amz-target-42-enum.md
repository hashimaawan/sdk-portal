
# X Amz Target 42 Enum

## Enumeration

`XAmzTarget42Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTSESSIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget42Enum;

$xAmzTarget42 = XAmzTarget42Enum::ENUM_AMAZONATHENALISTSESSIONS;
```

