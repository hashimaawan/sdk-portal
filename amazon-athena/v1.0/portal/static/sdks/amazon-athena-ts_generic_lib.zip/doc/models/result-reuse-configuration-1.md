
# Result Reuse Configuration 1

## Structure

`ResultReuseConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resultReuseByAgeConfiguration` | [`ResultReuseByAgeConfiguration2 \| undefined`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |

## Example

```ts
import { ResultReuseConfiguration1 } from 'amazon-athenalib';

const resultReuseConfiguration1: ResultReuseConfiguration1 = {
  resultReuseByAgeConfiguration: {
    enabled: false,
    maxAgeInMinutes: 26,
  },
};
```

