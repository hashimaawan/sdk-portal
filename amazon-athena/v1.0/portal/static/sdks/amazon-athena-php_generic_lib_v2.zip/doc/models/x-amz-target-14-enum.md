
# X Amz Target 14 Enum

## Enumeration

`XAmzTarget14Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAEXPORTNOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget14Enum;

$xAmzTarget14 = XAmzTarget14Enum::ENUM_AMAZONATHENAEXPORTNOTEBOOK;
```

