
# Regions

A map of region to regional state

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Regions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `eu_west` | [`EuWest`](../../doc/models/eu-west.md) | Optional | - |
| `us_east` | [`EuWest`](../../doc/models/eu-west.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
regions = Regions.new(
  eu_west: EuWest.new(
    status: Status16::DOWN,
    status_changed_at: 'status_changed_at4',
    thirty_day_uptime_percentage: 227.78,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  us_east: EuWest.new(
    status: Status16::DOWN,
    status_changed_at: 'status_changed_at4',
    thirty_day_uptime_percentage: 121.56,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

