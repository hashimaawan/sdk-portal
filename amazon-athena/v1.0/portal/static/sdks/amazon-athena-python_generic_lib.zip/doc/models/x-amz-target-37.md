
# X Amz Target 37

## Enumeration

`XAmzTarget37`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNAMEDQUERIES` |

## Example

```python
from amazonathena.models.x_amz_target_37 import XAmzTarget37

x_amz_target_37 = XAmzTarget37.ENUM_AMAZONATHENALISTNAMEDQUERIES
```

