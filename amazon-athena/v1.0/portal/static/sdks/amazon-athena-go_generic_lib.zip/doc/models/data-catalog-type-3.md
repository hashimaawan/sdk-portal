
# Data Catalog Type 3

Specifies the type of data catalog to update. Specify <code>LAMBDA</code> for a federated catalog, <code>HIVE</code> for an external hive metastore, or <code>GLUE</code> for an Glue Data Catalog.

## Enumeration

`DataCatalogType3`

## Fields

| Name |
|  --- |
| `Lambda` |
| `Glue` |
| `Hive` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    dataCatalogType3 := models.DataCatalogType3_Lambda

}
```

