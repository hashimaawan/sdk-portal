
# Query Execution State

## Enumeration

`QueryExecutionState`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```php
use AmazonAthenaLib\Models\QueryExecutionState;

$queryExecutionState = QueryExecutionState::CANCELLED;
```

