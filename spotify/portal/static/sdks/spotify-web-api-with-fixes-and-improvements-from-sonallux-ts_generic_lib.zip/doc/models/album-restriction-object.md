
# Album Restriction Object

*This model accepts additional fields of type unknown.*

## Structure

`AlbumRestrictionObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reason` | [`Reason \| undefined`](../../doc/models/reason.md) | Optional | The reason for the restriction. Albums may be restricted if the content is not available in a given market, to the user's subscription type, or when the user's account is set to not play explicit content.<br>Additional reasons may be added in the future. |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  AlbumRestrictionObject,
  Reason,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const albumRestrictionObject: AlbumRestrictionObject = {
  reason: Reason.Market,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

