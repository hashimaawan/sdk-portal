
# Region 4

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Region4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | A DigitalOcean region where Kubernetes is available. |
| `slug` | `String` | Optional | The identifier for a region for use when creating a new cluster. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
region4 = Region4.new(
  name: 'New York 3',
  slug: 'nyc3',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

