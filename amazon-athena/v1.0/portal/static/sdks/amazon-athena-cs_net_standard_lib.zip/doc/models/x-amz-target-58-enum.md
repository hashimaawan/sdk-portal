
# X Amz Target 58 Enum

## Enumeration

`XAmzTarget58Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdatePreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget58Enum xAmzTarget58 = XAmzTarget58Enum.EnumAmazonAthenaUpdatePreparedStatement;
```

