
# Get Calculation Execution Code Response

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `codeBlock` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```ts
import { GetCalculationExecutionCodeResponse } from 'amazon-athenalib';

const getCalculationExecutionCodeResponse: GetCalculationExecutionCodeResponse = {
  codeBlock: 'CodeBlock4',
};
```

