
# Get Query Execution Output

## Structure

`GetQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `queryExecution` | [`?QueryExecution1`](../../doc/models/query-execution-1.md) | Optional | - | getQueryExecution(): ?QueryExecution1 | setQueryExecution(?QueryExecution1 queryExecution): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetQueryExecutionOutputBuilder;
use AmazonAthenaLib\Models\Builders\QueryExecution1Builder;
use AmazonAthenaLib\Models\StatementType1Enum;
use AmazonAthenaLib\Models\Builders\ResultConfiguration1Builder;
use AmazonAthenaLib\Models\Builders\EncryptionConfiguration2Builder;
use AmazonAthenaLib\Models\EncryptionOption1Enum;
use AmazonAthenaLib\Models\Builders\AclConfiguration1Builder;
use AmazonAthenaLib\Models\S3AclOption1Enum;
use AmazonAthenaLib\Models\Builders\ResultReuseConfiguration1Builder;
use AmazonAthenaLib\Models\Builders\ResultReuseByAgeConfiguration2Builder;

$getQueryExecutionOutput = GetQueryExecutionOutputBuilder::init()
    ->queryExecution(
        QueryExecution1Builder::init()
            ->queryExecutionId('QueryExecutionId0')
            ->query('Query6')
            ->statementType(StatementType1Enum::DDL)
            ->resultConfiguration(
                ResultConfiguration1Builder::init()
                    ->outputLocation('OutputLocation0')
                    ->encryptionConfiguration(
                        EncryptionConfiguration2Builder::init(
                            EncryptionOption1Enum::SSE_S3
                        )
                            ->kmsKey('KmsKey6')
                            ->build()
                    )
                    ->expectedBucketOwner('ExpectedBucketOwner0')
                    ->aclConfiguration(
                        AclConfiguration1Builder::init(
                            S3AclOption1Enum::BUCKET_OWNER_FULL_CONTROL
                        )->build()
                    )->build()
            )
            ->resultReuseConfiguration(
                ResultReuseConfiguration1Builder::init()
                    ->resultReuseByAgeConfiguration(
                        ResultReuseByAgeConfiguration2Builder::init(
                            false
                        )
                            ->maxAgeInMinutes(26)
                            ->build()
                    )
                    ->build()
            )
            ->build()
    )
    ->build();
```

