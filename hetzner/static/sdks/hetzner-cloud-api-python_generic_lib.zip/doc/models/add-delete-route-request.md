
# Add Delete Route Request

## Structure

`AddDeleteRouteRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `destination` | `str` | Required | Destination network or host of this route. Must not overlap with an existing ip_range in any subnets or with any destinations in other routes or with the first IP of the networks ip_range or with 172.31.1.1. Must be one of the private IPv4 ranges of RFC1918. |
| `gateway` | `str` | Required | Gateway for the route. Cannot be the first IP of the networks ip_range, an IP behind a vSwitch or 172.31.1.1, as this IP is being used as a gateway for the public network interface of Servers. |

## Example

```python
from hetznercloudapi.models.add_delete_route_request import AddDeleteRouteRequest

add_delete_route_request = AddDeleteRouteRequest(
    destination='10.100.1.0/24',
    gateway='10.0.1.1'
)
```

