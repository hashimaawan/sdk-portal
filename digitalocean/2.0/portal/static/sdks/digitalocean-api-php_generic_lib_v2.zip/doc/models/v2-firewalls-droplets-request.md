
# V2 Firewalls Droplets Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FirewallsDropletsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dropletIds` | `int[]` | Required | An array containing the IDs of the Droplets to be removed from the firewall. | getDropletIds(): array | setDropletIds(array dropletIds): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FirewallsDropletsRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2FirewallsDropletsRequest = V2FirewallsDropletsRequestBuilder::init(
    [
        49696269
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

