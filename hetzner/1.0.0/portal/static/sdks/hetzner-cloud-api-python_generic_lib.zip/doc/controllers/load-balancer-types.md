# Load Balancer Types

```python
load_balancer_types_api = client.load_balancer_types
```

## Class Name

`LoadBalancerTypesApi`

## Methods

* [Get All Load Balancer Types](../../doc/controllers/load-balancer-types.md#get-all-load-balancer-types)
* [Get a Load Balancer Type](../../doc/controllers/load-balancer-types.md#get-a-load-balancer-type)


# Get All Load Balancer Types

Gets all Load Balancer type objects.

```python
def get_all_load_balancer_types(self,
                               name=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Query, Optional | Can be used to filter Load Balancer types by their name. The response will only contain the Load Balancer type matching the specified name. |

## Response Type

**200**: The `load_balancer_types` key in the reply contains an array of Load Balancer type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`LoadBalancerTypesResponse`](../../doc/models/load-balancer-types-response.md).

## Example Usage

```python
result = load_balancer_types_api.get_all_load_balancer_types()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Get a Load Balancer Type

Gets a specific Load Balancer type object.

```python
def get_a_load_balancer_type(self,
                            id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Load Balancer type |

## Response Type

**200**: The `load_balancer_type` key in the reply contains a Load Balancer type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`LoadBalancerTypesResponse1`](../../doc/models/load-balancer-types-response-1.md).

## Example Usage

```python
id = 112

result = load_balancer_types_api.get_a_load_balancer_type(id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

