
# List Tags for Resource Output

*This model accepts additional fields of type unknown.*

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | [`Tag[] \| undefined`](../../doc/models/tag.md) | Optional | - |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ListTagsForResourceOutput } from 'amazon-athenalib';

const listTagsForResourceOutput: ListTagsForResourceOutput = {
  tags: [
    {
      key: 'Key0',
      value: 'Value6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      key: 'Key0',
      value: 'Value6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      key: 'Key0',
      value: 'Value6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  nextToken: 'NextToken4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

