
# Type 29

Type of the resource

## Enumeration

`Type29`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |
| `Ip` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type29 type29 = Type29.Server;
```

