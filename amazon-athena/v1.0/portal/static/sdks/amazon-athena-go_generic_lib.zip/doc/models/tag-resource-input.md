
# Tag Resource Input

*This model accepts additional fields of type interface{}.*

## Structure

`TagResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResourceArn` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `Tags` | [`[]models.Tag`](../../doc/models/tag.md) | Required | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    tagResourceInput := models.TagResourceInput{
        ResourceArn:           "ResourceARN6",
        Tags:                  []models.Tag{
            models.Tag{
                Key:                   models.ToPointer("Key0"),
                Value:                 models.ToPointer("Value6"),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

