
# X Amz Target 27

## Enumeration

`XAmzTarget27`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetSessionStatus` |

## Example

```ts
import { XAmzTarget27 } from 'amazon-athenalib';

const xAmzTarget27 = XAmzTarget27.EnumAmazonAthenaGetSessionStatus;
```

