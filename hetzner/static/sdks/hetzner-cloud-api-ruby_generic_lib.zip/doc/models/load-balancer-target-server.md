
# Load Balancer Target Server

Server where the traffic should be routed through

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the Server |

## Example

```ruby
load_balancer_target_server = LoadBalancerTargetServer.new(
  80
)
```

