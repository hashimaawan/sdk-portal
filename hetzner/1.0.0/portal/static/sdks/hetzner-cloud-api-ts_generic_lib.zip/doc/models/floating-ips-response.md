
# Floating Ips Response

*This model accepts additional fields of type unknown.*

## Structure

`FloatingIpsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floatingIps` | [`FloatingIp[]`](../../doc/models/floating-ip.md) | Required | - |
| `meta` | [`Meta \| undefined`](../../doc/models/meta.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FloatingIpsResponse, Type16 } from 'hetzner-cloud-apilib';

const floatingIpsResponse: FloatingIpsResponse = {
  floatingIps: [
    {
      blocked: false,
      created: '2016-01-30T23:55:00+00:00',
      description: 'this describes my resource',
      dnsPtr: [
        {
          dnsPtr: 'server.example.com',
          ip: '2001:db8::1',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      homeLocation: {
        city: 'Falkenstein',
        country: 'DE',
        description: 'Falkenstein DC Park 1',
        id: 1,
        latitude: 50.47612,
        longitude: 12.370071,
        name: 'fsn1',
        networkZone: 'eu-central',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      id: 42,
      ip: '131.232.99.1',
      labels: {
        'key0': 'labels2'
      },
      name: 'my-resource',
      protection: {
        mDelete: false,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      server: 42,
      type: Type16.Ipv4,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  meta: {
    pagination: {
      lastPage: 77.7,
      nextPage: 209.18,
      page: 17.58,
      perPage: 13.34,
      previousPage: 50.02,
      totalEntries: 206.64,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

