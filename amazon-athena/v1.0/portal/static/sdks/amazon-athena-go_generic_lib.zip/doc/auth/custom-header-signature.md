
# Custom Header Signature



Documentation for accessing and setting credentials for hmac.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| authorization | `string` | Amazon Signature authorization v4 | `WithAuthorization` | `Authorization()` |



**Note:** Required auth credentials can be set using `WithCustomHeaderAuthenticationCredentials()` by providing a credentials instance with `NewCustomHeaderAuthenticationCredentials()` in the configuration initialization and accessed using the `CustomHeaderAuthenticationCredentials()` method in the configuration instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```go
package main

import (
    "amazonAthena"
)

func main() {
    client := amazonAthena.NewClient(
    amazonAthena.CreateConfiguration(
            amazonAthena.WithCustomHeaderAuthenticationCredentials(
                amazonAthena.NewCustomHeaderAuthenticationCredentials("Authorization"),
            ),
        ),
    )
}
```


