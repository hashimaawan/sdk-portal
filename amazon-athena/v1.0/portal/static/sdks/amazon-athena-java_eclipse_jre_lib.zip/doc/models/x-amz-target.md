
# X Amz Target

## Enumeration

`XAmzTarget`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget;

XAmzTarget xAmzTarget = XAmzTarget.ENUM_AMAZONATHENABATCHGETNAMEDQUERY;
```

