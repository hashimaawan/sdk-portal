
# Pending Change

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`PendingChange`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_id` | `int` | Optional | - |
| `removing` | `bool` | Optional | - |
| `status` | `str` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.pending_change import PendingChange

pending_change = PendingChange(
    droplet_id=8043964,
    removing=False,
    status='waiting',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

