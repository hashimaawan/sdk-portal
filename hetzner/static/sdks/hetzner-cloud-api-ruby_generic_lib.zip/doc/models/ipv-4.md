
# Ipv 4

IP address (v4)

## Structure

`Ipv4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dns_ptr` | `String` | Optional | Reverse DNS PTR entry for the IPv4 address of this Load Balancer |
| `ip` | `String` | Optional | IP address (v4) of this Load Balancer |

## Example

```ruby
ipv4 = Ipv4.new(
  'lb1.example.com',
  '1.2.3.4'
)
```

