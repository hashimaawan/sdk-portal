
# Type 6

Type of resource referenced

## Enumeration

`Type6`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```python
from hetznercloudapi.models.type_6 import Type6

type_6 = Type6.SERVER
```

