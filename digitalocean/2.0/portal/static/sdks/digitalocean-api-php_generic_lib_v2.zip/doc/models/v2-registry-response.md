
# V2 Registry Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2RegistryResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `registry` | [`?Registry`](../../doc/models/registry.md) | Optional | - | getRegistry(): ?Registry | setRegistry(?Registry registry): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2RegistryResponseBuilder;
use DigitalOceanApiLib\Models\Builders\RegistryBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\ApiHelper;

$v2RegistryResponse = V2RegistryResponseBuilder::init()
    ->registry(
        RegistryBuilder::init()
            ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->name('name2')
            ->region('region8')
            ->storageUsageBytes(50)
            ->storageUsageBytesUpdatedAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

