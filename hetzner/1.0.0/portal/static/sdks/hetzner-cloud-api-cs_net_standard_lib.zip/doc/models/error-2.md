
# Error 2

If issuance or renewal reports `failed`, this property contains information about what happened

## Structure

`Error2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Optional | - |
| `Message` | `string` | Optional | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Error2 error2 = new Error2
{
    Code = "code2",
    Message = "message4",
};
```

