
# Pending Change

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`PendingChange`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletId` | `number \| undefined` | Optional | - |
| `removing` | `boolean \| undefined` | Optional | - |
| `status` | `string \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { PendingChange } from 'digitalocean-apilib';

const pendingChange: PendingChange = {
  dropletId: 8043964,
  removing: false,
  status: 'waiting',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

