
# Minimum Tls Version

The minimum version of TLS a client application can use to access resources for the domain.  Must be one of the following values wrapped within quotations: `"1.2"` or `"1.3"`.

## Enumeration

`MinimumTlsVersion`

## Fields

| Name |
|  --- |
| `Enum12` |
| `Enum13` |

## Example

```ts
import { MinimumTlsVersion } from 'digitalocean-apilib';

const minimumTlsVersion = MinimumTlsVersion.Enum12;
```

