
# V2 Registry Subscription Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2RegistrySubscriptionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tier_slug` | [`TierSlug`](../../doc/models/tier-slug.md) | Optional | The slug of the subscription tier to sign up for. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_registry_subscription_request = V2RegistrySubscriptionRequest.new(
  tier_slug: TierSlug::BASIC,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

