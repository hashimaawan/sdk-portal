
# Custom Query Parameter



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| api_key | `String` | - | `api_key` |



**Note:** Auth credentials can be set using named parameter for any of the above credentials (e.g. `api_key`) in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```ruby
require 'giphy_api'
include GiphyApi

client = Client.new(
  custom_query_authentication_credentials: CustomQueryAuthenticationCredentials.new(
    api_key: 'api_key'
  )
)
```


