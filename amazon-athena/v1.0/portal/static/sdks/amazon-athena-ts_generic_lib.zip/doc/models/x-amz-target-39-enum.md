
# X Amz Target 39 Enum

## Enumeration

`XAmzTarget39Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNotebookSessions` |

## Example

```ts
import { XAmzTarget39Enum } from 'amazon-athenalib';

const xAmzTarget39 = XAmzTarget39Enum.EnumAmazonAthenaListNotebookSessions;
```

