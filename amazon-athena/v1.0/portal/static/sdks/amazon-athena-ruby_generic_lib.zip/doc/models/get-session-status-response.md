
# Get Session Status Response

## Structure

`GetSessionStatusResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `status` | [`Status3`](../../doc/models/status-3.md) | Optional | - |

## Example

```ruby
get_session_status_response = GetSessionStatusResponse.new(
  'SessionId4',
  Status3.new(
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    SessionState1Enum::TERMINATING
  )
)
```

