
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| loggingConfig | [`Consumer<ApiLoggingConfiguration.Builder>`](../doc/api-logging-configuration-builder.md) | Set up Logging Configuration instance. |
| furkotAuthAccessCodeCredentials | [`FurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |
| furkotAuthImplicitCredentials | [`FurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

```java
import com.furkot.trips.Environment;
import com.furkot.trips.FurkotTripsClient;
import com.furkot.trips.authentication.FurkotAuthAccessCodeModel;
import com.furkot.trips.authentication.FurkotAuthImplicitModel;
import com.furkot.trips.exceptions.ApiException;
import com.furkot.trips.http.response.ApiResponse;
import com.furkot.trips.models.OauthScopeFurkotAuthAccessCode;
import com.furkot.trips.models.OauthScopeFurkotAuthImplicit;
import com.furkot.trips.models.OauthToken;
import java.io.IOException;
import java.util.Arrays;
import org.slf4j.event.Level;

public class Program {
    public static void main(String[] args) {
        FurkotTripsClient client = new FurkotTripsClient.Builder()
            .loggingConfig(builder -> builder
                    .level(Level.DEBUG)
                    .requestConfig(logConfigBuilder -> logConfigBuilder.body(true))
                    .responseConfig(logConfigBuilder -> logConfigBuilder.headers(true)))
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .furkotAuthAccessCodeCredentials(new FurkotAuthAccessCodeModel.Builder(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri"
                )
                .oauthScopes(Arrays.asList(
                        OauthScopeFurkotAuthAccessCode.READTRIPS
                    ))
                .build())
            .furkotAuthImplicitCredentials(new FurkotAuthImplicitModel.Builder(
                    "OAuthClientId",
                    "OAuthRedirectUri"
                )
                .oauthScopes(Arrays.asList(
                        OauthScopeFurkotAuthImplicit.READTRIPS
                    ))
                .build())
            .environment(Environment.PRODUCTION)
            .build();

    }
}
```

## Furkot TripsClient Class

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

### Apis

| Name | Description | Return Type |
|  --- | --- | --- |
| `getApi()` | Provides access to Client controller. | `Api` |
| `getOauthAuthorizationApi()` | Provides access to OauthAuthorization controller. | `OauthAuthorizationApi` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getLoggingConfig()` | Logging Configuration instance. | [`ReadonlyLoggingConfiguration`](../doc/api-logging-configuration.md) |
| `getFurkotAuthAccessCodeCredentials()` | The credentials to use with FurkotAuthAccessCode. | [`FurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) |
| `getFurkotAuthImplicitCredentials()` | The credentials to use with FurkotAuthImplicit. | [`FurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

