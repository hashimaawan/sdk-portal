
# Cpu Type Enum

Type of cpu

## Enumeration

`CpuTypeEnum`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```java
import cloud.hetzner.api.models.CpuTypeEnum;

CpuTypeEnum cpuType = CpuTypeEnum.SHARED;
```

