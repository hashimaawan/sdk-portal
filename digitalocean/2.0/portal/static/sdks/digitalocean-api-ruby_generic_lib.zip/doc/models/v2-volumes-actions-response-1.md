
# V2 Volumes Actions Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2VolumesActionsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `actions` | [`Array[Action4]`](../../doc/models/action-4.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_volumes_actions_response1 = V2VolumesActionsResponse1.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  actions: [
    Action4.new(
      resource_id: 238,
      type: 'attach_volume',
      completed_at: DateTimeHelper.from_rfc3339('2020-11-21T21:51:09Z'),
      id: 72531856,
      region: Region.new(
        available: true,
        features: [
          'private_networking',
          'backups',
          'ipv6',
          'metadata'
        ],
        name: 'New York 1',
        sizes: [
          's-1vcpu-1gb',
          's-1vcpu-2gb',
          's-1vcpu-3gb',
          's-2vcpu-2gb',
          's-3vcpu-1gb',
          's-2vcpu-4gb',
          's-4vcpu-8gb',
          's-6vcpu-16gb',
          's-8vcpu-32gb',
          's-12vcpu-48gb',
          's-16vcpu-64gb',
          's-20vcpu-96gb',
          's-24vcpu-128gb',
          's-32vcpu-192gb'
        ],
        slug: 'nyc1',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      region_slug: 'nyc1',
      resource_type: 'volume',
      started_at: DateTimeHelper.from_rfc3339('2020-11-21T21:51:09Z'),
      status: Status1::COMPLETED,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

