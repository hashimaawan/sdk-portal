
# Executor State Enum

## Enumeration

`ExecutorStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```ts
import { ExecutorStateEnum } from 'amazon-athenalib';

const executorState = ExecutorStateEnum.TERMINATED;
```

