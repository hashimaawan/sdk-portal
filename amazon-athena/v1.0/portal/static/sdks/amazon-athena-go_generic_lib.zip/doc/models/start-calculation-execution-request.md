
# Start Calculation Execution Request

## Structure

`StartCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `CalculationConfiguration` | [`*models.GetCalculationExecutionCodeResponse`](../../doc/models/get-calculation-execution-code-response.md) | Optional | - |
| `CodeBlock` | `*string` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `ClientRequestToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    startCalculationExecutionRequest := models.StartCalculationExecutionRequest{
        SessionId:                "SessionId4",
        Description:              models.ToPointer("Description2"),
        CalculationConfiguration: models.ToPointer(models.GetCalculationExecutionCodeResponse{
            CodeBlock:            models.ToPointer("CodeBlock4"),
        }),
        CodeBlock:                models.ToPointer("CodeBlock6"),
        ClientRequestToken:       models.ToPointer("ClientRequestToken8"),
    }

}
```

