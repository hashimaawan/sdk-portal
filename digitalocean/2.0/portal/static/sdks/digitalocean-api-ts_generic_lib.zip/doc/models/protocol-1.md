
# Protocol 1

The protocol used for health checks sent to the backend Droplets. The possible values are `http`, `https`, or `tcp`.

## Enumeration

`Protocol1`

## Fields

| Name |
|  --- |
| `Http` |
| `Https` |
| `Tcp` |

## Example

```ts
import { Protocol1 } from 'digitalocean-apilib';

const protocol1 = Protocol1.Http;
```

