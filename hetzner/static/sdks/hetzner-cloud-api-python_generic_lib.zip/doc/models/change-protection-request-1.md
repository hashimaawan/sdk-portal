
# Change Protection Request 1

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Optional | If true, prevents the Network from being deleted |

## Example

```python
from hetznercloudapi.models.change_protection_request_1 import ChangeProtectionRequest1

change_protection_request_1 = ChangeProtectionRequest1(
    delete=True
)
```

