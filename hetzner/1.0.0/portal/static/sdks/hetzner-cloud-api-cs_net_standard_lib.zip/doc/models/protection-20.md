
# Protection 20

Protection configuration for the Server

## Structure

`Protection20`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool` | Required | If true, prevents the Server from being deleted |
| `Rebuild` | `bool` | Required | If true, prevents the Server from being rebuilt |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Protection20 protection20 = new Protection20
{
    Delete = false,
    Rebuild = false,
};
```

