
# Start Session Response

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `state` | [`SessionState1Enum \| undefined`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```ts
import { SessionState1Enum, StartSessionResponse } from 'amazon-athenalib';

const startSessionResponse: StartSessionResponse = {
  sessionId: 'SessionId4',
  state: SessionState1Enum.CREATING,
};
```

