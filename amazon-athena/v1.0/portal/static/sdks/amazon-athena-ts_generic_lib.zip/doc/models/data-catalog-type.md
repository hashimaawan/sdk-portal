
# Data Catalog Type

## Enumeration

`DataCatalogType`

## Fields

| Name |
|  --- |
| `Lambda` |
| `Glue` |
| `Hive` |

## Example

```ts
import { DataCatalogType } from 'amazon-athenalib';

const dataCatalogType = DataCatalogType.Hive;
```

