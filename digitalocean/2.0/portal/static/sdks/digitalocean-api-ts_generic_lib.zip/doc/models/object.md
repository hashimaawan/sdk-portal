
# Object

Metadata about the Kubernetes API object the diagnostic is reported on.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Object`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | `string \| undefined` | Optional | The kind of Kubernetes API object |
| `name` | `string \| undefined` | Optional | Name of the object |
| `namespace` | `string \| undefined` | Optional | The namespace the object resides in the cluster. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Object } from 'digitalocean-apilib';

const object: Object = {
  kind: 'config map',
  name: 'foo',
  namespace: 'kube-system',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

