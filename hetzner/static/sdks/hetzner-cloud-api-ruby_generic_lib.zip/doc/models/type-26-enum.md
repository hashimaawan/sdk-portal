
# Type 26 Enum

Type of the ISO

## Enumeration

`Type26Enum`

## Fields

| Name |
|  --- |
| `PUBLIC` |
| `PRIVATE` |

## Example

```ruby
type26 = Type26Enum::PUBLIC
```

