
# Status 24

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |
| `Unavailable` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    status24 := models.Status24_Available

}
```

