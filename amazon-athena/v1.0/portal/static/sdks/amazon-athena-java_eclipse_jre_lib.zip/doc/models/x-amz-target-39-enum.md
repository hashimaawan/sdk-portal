
# X Amz Target 39 Enum

## Enumeration

`XAmzTarget39Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget39Enum;

XAmzTarget39Enum xAmzTarget39 = XAmzTarget39Enum.ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS;
```

