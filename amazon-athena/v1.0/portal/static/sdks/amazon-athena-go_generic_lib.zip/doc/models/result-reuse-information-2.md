
# Result Reuse Information 2

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReusedPreviousResult` | `bool` | Required | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    resultReuseInformation2 := models.ResultReuseInformation2{
        ReusedPreviousResult: false,
    }

}
```

