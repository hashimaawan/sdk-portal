
# X Amz Target 41 Enum

## Enumeration

`XAmzTarget41Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```python
from amazonathena.models.x_amz_target_41_enum import XAmzTarget41Enum

x_amz_target_41 = XAmzTarget41Enum.ENUM_AMAZONATHENALISTQUERYEXECUTIONS
```

