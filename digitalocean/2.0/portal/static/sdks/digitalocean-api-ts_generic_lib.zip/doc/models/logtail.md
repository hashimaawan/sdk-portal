
# Logtail

Logtail configuration.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Logtail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string \| undefined` | Optional | Logtail token. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Logtail } from 'digitalocean-apilib';

const logtail: Logtail = {
  token: 'abcdefghijklmnopqrstuvwxyz0123456789',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

