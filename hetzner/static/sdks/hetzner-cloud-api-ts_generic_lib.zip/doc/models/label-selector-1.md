
# Label Selector 1

Configuration for type LabelSelector, required if type is `label_selector`

## Structure

`LabelSelector1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector |

## Example

```ts
import { LabelSelector1 } from 'hetzner-cloud-apilib';

const labelSelector1: LabelSelector1 = {
  selector: 'selector2',
};
```

