
# Sort 2

## Enumeration

`Sort2`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `CREATED` |
| `ENUM_CREATEDASC` |
| `ENUM_CREATEDDESC` |

## Example

```java
import cloud.hetzner.api.models.Sort2;

Sort2 sort2 = Sort2.ENUM_CREATEDASC;
```

