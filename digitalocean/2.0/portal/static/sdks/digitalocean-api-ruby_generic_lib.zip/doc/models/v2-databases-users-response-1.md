
# V2 Databases Users Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user` | [`User`](../../doc/models/user.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_users_response1 = V2DatabasesUsersResponse1.new(
  user: User.new(
    name: 'app-01',
    mysql_settings: MysqlSettings.new(
      auth_plugin: AuthPlugin::MYSQL_NATIVE_PASSWORD,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    password: 'jge5lfxtzhx42iff',
    role: Role::NORMAL,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

