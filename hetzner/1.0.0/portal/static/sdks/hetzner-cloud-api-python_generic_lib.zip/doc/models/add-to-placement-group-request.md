
# Add to Placement Group Request

*This model accepts additional fields of type Any.*

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placement_group` | `int` | Required | ID of Placement Group the Server should be added to |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.add_to_placement_group_request import AddToPlacementGroupRequest

add_to_placement_group_request = AddToPlacementGroupRequest(
    placement_group=1,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

