
# Type 22

Type of the Image

## Enumeration

`Type22`

## Fields

| Name |
|  --- |
| `System` |
| `App` |
| `Snapshot` |
| `Backup` |
| `Temporary` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type22 := models.Type22_Temporary

}
```

