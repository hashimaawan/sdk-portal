
# Not Found Exception

*This model accepts additional fields of type Object.*

## Structure

`NotFoundException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`ErrorObject`](../../doc/models/error-object.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue NotFoundException => e
  puts "Caught NotFoundException: #{e.message}"
end
```

