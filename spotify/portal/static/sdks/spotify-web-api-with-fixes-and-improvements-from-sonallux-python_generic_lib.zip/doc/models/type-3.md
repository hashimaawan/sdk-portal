
# Type 3

The object type.

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `USER` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.type_3 import Type3

type_3 = Type3.USER
```

