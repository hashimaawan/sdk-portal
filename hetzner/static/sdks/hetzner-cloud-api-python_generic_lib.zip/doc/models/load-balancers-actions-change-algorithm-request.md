
# Load Balancers Actions Change Algorithm Request

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type39Enum`](../../doc/models/type-39-enum.md) | Required | Algorithm of the Load Balancer |

## Example

```python
from hetznercloudapi.models.load_balancers_actions_change_algorithm_request import LoadBalancersActionsChangeAlgorithmRequest
from hetznercloudapi.models.type_39_enum import Type39Enum

load_balancers_actions_change_algorithm_request = LoadBalancersActionsChangeAlgorithmRequest(
    mtype=Type39Enum.ROUND_ROBIN
)
```

