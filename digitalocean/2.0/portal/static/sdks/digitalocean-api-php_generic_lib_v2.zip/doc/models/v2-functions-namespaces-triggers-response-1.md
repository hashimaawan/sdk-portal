
# V2 Functions Namespaces Triggers Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `trigger` | [`?Trigger`](../../doc/models/trigger.md) | Optional | - | getTrigger(): ?Trigger | setTrigger(?Trigger trigger): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FunctionsNamespacesTriggersResponse1Builder;
use DigitalOceanApiLib\Models\Builders\TriggerBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2FunctionsNamespacesTriggersResponse1 = V2FunctionsNamespacesTriggersResponse1Builder::init()
    ->trigger(
        TriggerBuilder::init()
            ->createdAt('created_at6')
            ->function('function6')
            ->isEnabled(false)
            ->name('name8')
            ->namespace('namespace4')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

