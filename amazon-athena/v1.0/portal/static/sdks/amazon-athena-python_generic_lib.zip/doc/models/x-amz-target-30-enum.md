
# X Amz Target 30 Enum

## Enumeration

`XAmzTarget30Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAIMPORTNOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_30_enum import XAmzTarget30Enum

x_amz_target_30 = XAmzTarget30Enum.ENUM_AMAZONATHENAIMPORTNOTEBOOK
```

