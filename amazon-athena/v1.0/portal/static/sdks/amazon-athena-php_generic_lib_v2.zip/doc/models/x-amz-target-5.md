
# X Amz Target 5

## Enumeration

`XAmzTarget5`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget5;

$xAmzTarget5 = XAmzTarget5::ENUM_AMAZONATHENACREATENOTEBOOK;
```

