
# Status 1

## Structure

`Status1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `submissionDateTime` | `string \| undefined` | Optional | - |
| `completionDateTime` | `string \| undefined` | Optional | - |
| `state` | [`CalculationExecutionState1Enum \| undefined`](../../doc/models/calculation-execution-state-1-enum.md) | Optional | - |
| `stateChangeReason` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { CalculationExecutionState1Enum, Status1 } from 'amazon-athenalib';

const status1: Status1 = {
  submissionDateTime: '2016-03-13T12:52:32.123Z',
  completionDateTime: '2016-03-13T12:52:32.123Z',
  state: CalculationExecutionState1Enum.QUEUED,
  stateChangeReason: 'StateChangeReason0',
};
```

