
# Remove from Resources Request

*This model accepts additional fields of type array.*

## Structure

`RemoveFromResourcesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `removeFrom` | [`FirewallRemoveFromResources[]`](../../doc/models/firewall-remove-from-resources.md) | Required | Resources the Firewall should be removed from | getRemoveFrom(): array | setRemoveFrom(array removeFrom): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\RemoveFromResourcesRequestBuilder;
use HetznerCloudApiLib\Models\Builders\FirewallRemoveFromResourcesBuilder;
use HetznerCloudApiLib\Models\Builders\LabelSelector5Builder;
use HetznerCloudApiLib\ApiHelper;
use HetznerCloudApiLib\Models\Builders\Server9Builder;
use HetznerCloudApiLib\Models\Type7;

$removeFromResourcesRequest = RemoveFromResourcesRequestBuilder::init(
    [
        FirewallRemoveFromResourcesBuilder::init()
            ->labelSelector(
                LabelSelector5Builder::init(
                    'selector8'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->server(
                Server9Builder::init(
                    14
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->type(Type7::SERVER)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

