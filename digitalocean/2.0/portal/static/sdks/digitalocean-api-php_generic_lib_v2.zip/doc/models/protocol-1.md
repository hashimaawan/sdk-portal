
# Protocol 1

The protocol used for health checks sent to the backend Droplets. The possible values are `http`, `https`, or `tcp`.

## Enumeration

`Protocol1`

## Fields

| Name |
|  --- |
| `HTTP` |
| `HTTPS` |
| `TCP` |

## Example

```php
use DigitalOceanApiLib\Models\Protocol1;

$protocol1 = Protocol1::HTTP;
```

