
# X Amz Target 11 Enum

## Enumeration

`XAmzTarget11Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget11Enum;

XAmzTarget11Enum xAmzTarget11 = XAmzTarget11Enum.ENUM_AMAZONATHENADELETENOTEBOOK;
```

