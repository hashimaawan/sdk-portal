
# X Amz Target 5 Enum

## Enumeration

`XAmzTarget5Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENACREATENOTEBOOK` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget5 := models.XAmzTarget5Enum_ENUMAMAZONATHENACREATENOTEBOOK

}
```

