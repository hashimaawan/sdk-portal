
# X Amz Target 29 Enum

## Enumeration

`XAmzTarget29Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetWorkGroup` |

## Example

```ts
import { XAmzTarget29Enum } from 'amazon-athenalib';

const xAmzTarget29 = XAmzTarget29Enum.EnumAmazonAthenaGetWorkGroup;
```

