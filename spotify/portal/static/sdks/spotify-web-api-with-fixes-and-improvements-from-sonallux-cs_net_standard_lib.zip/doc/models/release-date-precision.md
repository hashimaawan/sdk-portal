
# Release Date Precision

The precision with which `release_date` value is known.

## Enumeration

`ReleaseDatePrecision`

## Fields

| Name |
|  --- |
| `Year` |
| `Month` |
| `Day` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

ReleaseDatePrecision releaseDatePrecision = ReleaseDatePrecision.Year;
```

