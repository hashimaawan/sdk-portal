
# Row

The rows that make up a query result table.

*This model accepts additional fields of type unknown.*

## Structure

`Row`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`Datum[] \| undefined`](../../doc/models/datum.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Row } from 'amazon-athenalib';

const row: Row = {
  data: [
    {
      varCharValue: 'VarCharValue8',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

