
# Get Data Catalog Input

## Structure

`GetDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ruby
get_data_catalog_input = GetDataCatalogInput.new(
  'Name2'
)
```

