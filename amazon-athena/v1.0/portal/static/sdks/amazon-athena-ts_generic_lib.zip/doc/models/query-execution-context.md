
# Query Execution Context

The database and data catalog context in which the query execution occurs.

## Structure

`QueryExecutionContext`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `catalog` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ts
import { QueryExecutionContext } from 'amazon-athenalib';

const queryExecutionContext: QueryExecutionContext = {
  database: 'Database0',
  catalog: 'Catalog6',
};
```

