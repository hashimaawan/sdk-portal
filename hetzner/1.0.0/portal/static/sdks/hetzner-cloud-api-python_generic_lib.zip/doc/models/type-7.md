
# Type 7

Type of the resource

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```python
from hetznercloudapi.models.type_7 import Type7

type_7 = Type7.SERVER
```

