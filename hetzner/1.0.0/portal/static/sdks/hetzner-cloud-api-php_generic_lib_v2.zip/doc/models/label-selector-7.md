
# Label Selector 7

Label selector and a list of selected targets

## Structure

`LabelSelector7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector | getSelector(): string | setSelector(string selector): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LabelSelector7Builder;

$labelSelector7 = LabelSelector7Builder::init(
    'env=prod'
)->build();
```

