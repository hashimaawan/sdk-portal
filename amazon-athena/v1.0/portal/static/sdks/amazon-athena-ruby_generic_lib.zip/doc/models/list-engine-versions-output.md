
# List Engine Versions Output

## Structure

`ListEngineVersionsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `engine_versions` | [`Array[EngineVersion]`](../../doc/models/engine-version.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_engine_versions_output = ListEngineVersionsOutput.new(
  [
    EngineVersion.new(
      'SelectedEngineVersion2',
      'EffectiveEngineVersion2'
    ),
    EngineVersion.new(
      'SelectedEngineVersion2',
      'EffectiveEngineVersion2'
    )
  ],
  'NextToken2'
)
```

