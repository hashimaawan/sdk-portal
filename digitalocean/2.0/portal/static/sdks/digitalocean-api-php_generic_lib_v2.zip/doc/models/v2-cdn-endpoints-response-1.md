
# V2 Cdn Endpoints Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `endpoint` | [`?Endpoint`](../../doc/models/endpoint.md) | Optional | - | getEndpoint(): ?Endpoint | setEndpoint(?Endpoint endpoint): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2CdnEndpointsResponse1Builder;
use DigitalOceanApiLib\Models\Builders\EndpointBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\ApiHelper;

$v2CdnEndpointsResponse1 = V2CdnEndpointsResponse1Builder::init()
    ->endpoint(
        EndpointBuilder::init(
            'origin2'
        )
            ->certificateId('00001b94-0000-0000-0000-000000000000')
            ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->customDomain('custom_domain6')
            ->endpoint('endpoint6')
            ->id('00001f7a-0000-0000-0000-000000000000')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

