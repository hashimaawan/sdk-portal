
# Log Line Prefix

Selects one of the available log-formats. These can support popular log analyzers like pgbadger, pganalyze, etc.

## Enumeration

`LogLinePrefix`

## Fields

| Name |
|  --- |
| `EnumPidpuserudbdappaclienth` |
| `EnumMPQuserudbdappa` |
| `EnumTPL1Userudbdappaclienth` |

## Example

```ts
import { LogLinePrefix } from 'digitalocean-apilib';

const logLinePrefix = LogLinePrefix.EnumTPL1Userudbdappaclienth;
```

