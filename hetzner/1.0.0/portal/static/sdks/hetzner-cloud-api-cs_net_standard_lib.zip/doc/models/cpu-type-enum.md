
# Cpu Type Enum

Type of cpu

## Enumeration

`CpuTypeEnum`

## Fields

| Name |
|  --- |
| `Shared` |
| `Dedicated` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

CpuTypeEnum cpuType = CpuTypeEnum.Shared;
```

