
# V2 Floating Ips Response 2

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FloatingIpsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floatingIp` | [`FloatingIp1 \| undefined`](../../doc/models/floating-ip-1.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FloatingIpsResponse2 } from 'digitalocean-apilib';

const v2FloatingIpsResponse2: V2FloatingIpsResponse2 = {
  floatingIp: {
    droplet: { 'key1': 'val1', 'key2': 'val2' },
    ip: 'ip2',
    locked: false,
    projectId: '0000167e-0000-0000-0000-000000000000',
    region: {
      available: false,
      features: [
        'features7',
        'features8',
        'features9'
      ],
      name: 'name6',
      sizes: [
        'sizes6'
      ],
      slug: 'slug0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

