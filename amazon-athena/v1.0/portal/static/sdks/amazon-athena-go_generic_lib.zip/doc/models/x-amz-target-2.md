
# X Amz Target 2

## Enumeration

`XAmzTarget2`

## Fields

| Name |
|  --- |
| `EnumAmazonathenabatchgetqueryexecution` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget2 := models.XAmzTarget2_EnumAmazonathenabatchgetqueryexecution

}
```

