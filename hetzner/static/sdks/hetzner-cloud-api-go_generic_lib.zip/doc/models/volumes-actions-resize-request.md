
# Volumes Actions Resize Request

## Structure

`VolumesActionsResizeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Size` | `float64` | Required | New Volume size in GB (must be greater than current size) |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    volumesActionsResizeRequest := models.VolumesActionsResizeRequest{
        Size:                 float64(50),
    }

}
```

