
# V2 Databases Upgrade Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesUpgradeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string \| undefined` | Optional | A string representing the version of the database engine in use for the cluster. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2DatabasesUpgradeRequest } from 'digitalocean-apilib';

const v2DatabasesUpgradeRequest: V2DatabasesUpgradeRequest = {
  version: '10',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

