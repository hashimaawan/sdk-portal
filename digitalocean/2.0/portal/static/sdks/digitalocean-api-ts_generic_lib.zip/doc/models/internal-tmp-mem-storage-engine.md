
# Internal Tmp Mem Storage Engine

The storage engine for in-memory internal temporary tables.

## Enumeration

`InternalTmpMemStorageEngine`

## Fields

| Name |
|  --- |
| `TempTable` |
| `Memory` |

## Example

```ts
import { InternalTmpMemStorageEngine } from 'digitalocean-apilib';

const internalTmpMemStorageEngine = InternalTmpMemStorageEngine.TempTable;
```

