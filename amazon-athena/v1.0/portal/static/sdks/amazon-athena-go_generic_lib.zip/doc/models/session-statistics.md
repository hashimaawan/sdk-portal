
# Session Statistics

Contains statistics for a session.

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DpuExecutionInMillis` | `*int` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    sessionStatistics := models.SessionStatistics{
        DpuExecutionInMillis: models.ToPointer(188),
    }

}
```

