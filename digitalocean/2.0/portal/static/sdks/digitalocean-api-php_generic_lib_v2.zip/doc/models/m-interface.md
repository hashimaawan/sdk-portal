
# M Interface

## Enumeration

`MInterface`

## Fields

| Name |
|  --- |
| `PRIVATE_` |
| `PUBLIC_` |

## Example

```php
use DigitalOceanApiLib\Models\MInterface;

$interface = MInterface::PRIVATE_;
```

