
# Ssh Keys Request 1

## Structure

`SshKeysRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New name Name to set |

## Example

```ts
import { SshKeysRequest1 } from 'hetzner-cloud-apilib';

const sshKeysRequest1: SshKeysRequest1 = {
  labels: { 'labelkey': 'value' },
  name: 'My ssh key',
};
```

