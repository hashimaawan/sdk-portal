
# Query Runtime Statistics Rows

Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query.

*This model accepts additional fields of type object.*

## Structure

`QueryRuntimeStatisticsRows`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InputRows` | `int?` | Optional | - |
| `InputBytes` | `int?` | Optional | - |
| `OutputBytes` | `int?` | Optional | - |
| `OutputRows` | `int?` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

QueryRuntimeStatisticsRows queryRuntimeStatisticsRows = new QueryRuntimeStatisticsRows
{
    InputRows = 234,
    InputBytes = 254,
    OutputBytes = 40,
    OutputRows = 226,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

