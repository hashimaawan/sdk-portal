
# Protocol 7 Enum

Protocol of the Load Balancer

## Enumeration

`Protocol7Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```php
use HetznerCloudAPILib\Models\Protocol7Enum;

$protocol7 = Protocol7Enum::HTTP;
```

