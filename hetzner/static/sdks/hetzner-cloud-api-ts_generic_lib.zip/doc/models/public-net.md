
# Public Net

Public network information

## Structure

`PublicNet`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enabled` | `boolean` | Required | Public Interface enabled or not |
| `ipv4` | [`Ipv4`](../../doc/models/ipv-4.md) | Required | IP address (v4) |
| `ipv6` | [`Ipv6`](../../doc/models/ipv-6.md) | Required | IP address (v6) |

## Example

```ts
import { PublicNet } from 'hetzner-cloud-apilib';

const publicNet: PublicNet = {
  enabled: false,
  ipv4: {
    dnsPtr: 'lb1.example.com',
    ip: '1.2.3.4',
  },
  ipv6: {
    dnsPtr: 'lb1.example.com',
    ip: '2001:db8::1',
  },
};
```

