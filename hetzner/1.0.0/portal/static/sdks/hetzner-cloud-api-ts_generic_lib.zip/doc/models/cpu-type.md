
# Cpu Type

Type of cpu

## Enumeration

`CpuType`

## Fields

| Name |
|  --- |
| `Shared` |
| `Dedicated` |

## Example

```ts
import { CpuType } from 'hetzner-cloud-apilib';

const cpuType = CpuType.Shared;
```

