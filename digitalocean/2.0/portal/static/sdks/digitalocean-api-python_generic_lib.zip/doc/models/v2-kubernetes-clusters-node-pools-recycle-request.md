
# V2 Kubernetes Clusters Node Pools Recycle Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersNodePoolsRecycleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nodes` | `List[str]` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_kubernetes_clusters_node_pools_recycle_request import V2KubernetesClustersNodePoolsRecycleRequest

v_2_kubernetes_clusters_node_pools_recycle_request = V2KubernetesClustersNodePoolsRecycleRequest(
    nodes=[
        'd8db5e1a-6103-43b5-a7b3-8a948210a9fc'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

