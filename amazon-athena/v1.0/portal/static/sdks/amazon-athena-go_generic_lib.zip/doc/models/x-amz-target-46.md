
# X Amz Target 46

## Enumeration

`XAmzTarget46`

## Fields

| Name |
|  --- |
| `EnumAmazonathenastartcalculationexecution` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget46 := models.XAmzTarget46_EnumAmazonathenastartcalculationexecution

}
```

