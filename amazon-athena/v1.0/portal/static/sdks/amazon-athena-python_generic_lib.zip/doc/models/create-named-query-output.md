
# Create Named Query Output

## Structure

`CreateNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```python
from amazonathena.models.create_named_query_output import CreateNamedQueryOutput

create_named_query_output = CreateNamedQueryOutput(
    named_query_id='NamedQueryId4'
)
```

