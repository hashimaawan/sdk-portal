
# Type 5

Type of resource referenced

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `SERVER` |

## Example

```python
from hetznercloudapi.models.type_5 import Type5

type_5 = Type5.SERVER
```

