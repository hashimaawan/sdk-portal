
# V2 Uptime Checks Alerts Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2UptimeChecksAlertsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alert` | [`Alerts1`](../../doc/models/alerts-1.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_uptime_checks_alerts_response1 = V2UptimeChecksAlertsResponse1.new(
  alert: Alerts1.new(
    id: '00002454-0000-0000-0000-000000000000',
    comparison: Comparison::GREATER_THAN,
    name: 'name0',
    notifications: Notifications.new(
      email: [
        'email4',
        'email3'
      ],
      slack: [
        Slack.new(
          channel: 'channel6',
          url: 'url2',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        Slack.new(
          channel: 'channel6',
          url: 'url2',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        Slack.new(
          channel: 'channel6',
          url: 'url2',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    period: Period::ENUM_30M,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

