
# Type 7

Type of the resource

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```ts
import { Type7 } from 'hetzner-cloud-apilib';

const type7 = Type7.Server;
```

