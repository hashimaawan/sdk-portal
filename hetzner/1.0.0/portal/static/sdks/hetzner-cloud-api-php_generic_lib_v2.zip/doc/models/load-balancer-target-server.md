
# Load Balancer Target Server

Server where the traffic should be routed through

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Server | getId(): int | setId(int id): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LoadBalancerTargetServerBuilder;

$loadBalancerTargetServer = LoadBalancerTargetServerBuilder::init(
    80
)->build();
```

