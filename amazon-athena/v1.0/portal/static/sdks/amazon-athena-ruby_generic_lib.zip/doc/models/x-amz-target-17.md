
# X Amz Target 17

## Enumeration

`XAmzTarget17`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS` |

## Example

```ruby
x_amz_target17 = XAmzTarget17::ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS
```

