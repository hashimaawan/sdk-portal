
# X Amz Target 6

## Enumeration

`XAmzTarget6`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target6 = XAmzTarget6::ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT
```

