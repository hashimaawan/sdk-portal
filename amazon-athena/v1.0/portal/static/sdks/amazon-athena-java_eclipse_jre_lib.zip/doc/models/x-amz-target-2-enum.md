
# X Amz Target 2 Enum

## Enumeration

`XAmzTarget2Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget2Enum;

XAmzTarget2Enum xAmzTarget2 = XAmzTarget2Enum.ENUM_AMAZONATHENABATCHGETQUERYEXECUTION;
```

