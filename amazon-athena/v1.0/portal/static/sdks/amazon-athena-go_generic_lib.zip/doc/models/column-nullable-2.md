
# Column Nullable 2

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2`

## Fields

| Name |
|  --- |
| `NotNull` |
| `Nullable` |
| `Unknown` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    columnNullable2 := models.ColumnNullable2_NotNull

}
```

