
# V2 Reserved Ips Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2ReservedIpsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reservedIps` | [`?(ReservedIp[])`](../../doc/models/reserved-ip.md) | Optional | - | getReservedIps(): ?array | setReservedIps(?array reservedIps): void |
| `links` | [`?Links`](../../doc/models/links.md) | Optional | - | getLinks(): ?Links | setLinks(?Links links): void |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - | getMeta(): Meta | setMeta(Meta meta): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2ReservedIpsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\MetaBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\ReservedIpBuilder;
use DigitalOceanApiLib\Models\Builders\RegionBuilder;
use DigitalOceanApiLib\Models\Builders\LinksBuilder;
use DigitalOceanApiLib\Models\Builders\PagesBuilder;

$v2ReservedIpsResponse = V2ReservedIpsResponseBuilder::init(
    MetaBuilder::init(
        1
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->reservedIps(
        [
            ReservedIpBuilder::init()
                ->droplet(
                    null
                )
                ->ip('45.55.96.47')
                ->locked(false)
                ->projectId('746c6152-2fa2-11ed-92d3-27aaa54e4988')
                ->region(
                    RegionBuilder::init(
                        true,
                        [
                            'private_networking',
                            'backups',
                            'ipv6',
                            'metadata',
                            'install_agent',
                            'storage',
                            'image_transfer'
                        ],
                        'New York 3',
                        [
                            's-1vcpu-1gb',
                            's-1vcpu-2gb',
                            's-1vcpu-3gb',
                            's-2vcpu-2gb',
                            's-3vcpu-1gb',
                            's-2vcpu-4gb',
                            's-4vcpu-8gb',
                            's-6vcpu-16gb',
                            's-8vcpu-32gb',
                            's-12vcpu-48gb',
                            's-16vcpu-64gb',
                            's-20vcpu-96gb',
                            's-24vcpu-128gb',
                            's-32vcpu-192g'
                        ],
                        'nyc3'
                    )
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->links(
        LinksBuilder::init()
            ->pages(
                PagesBuilder::init()
                    ->last('last6')
                    ->next('next2')
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

