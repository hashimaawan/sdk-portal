
# Region 6

Slug of the region where registry data is stored. When not provided, a region will be selected.

## Enumeration

`Region6`

## Fields

| Name |
|  --- |
| `NYC3` |
| `SFO3` |
| `AMS3` |
| `SGP1` |
| `FRA1` |

## Example

```python
from digitaloceanapi.models.region_6 import Region6

region_6 = Region6.FRA1
```

