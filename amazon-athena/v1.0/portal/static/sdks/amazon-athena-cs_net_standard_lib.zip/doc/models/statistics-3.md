
# Statistics 3

## Structure

`Statistics3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DpuExecutionInMillis` | `int?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

Statistics3 statistics3 = new Statistics3
{
    DpuExecutionInMillis = 130,
};
```

