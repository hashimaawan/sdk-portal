
# X Amz Target 43

## Enumeration

`XAmzTarget43`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalisttablemetadata` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget43 := models.XAmzTarget43_EnumAmazonathenalisttablemetadata

}
```

