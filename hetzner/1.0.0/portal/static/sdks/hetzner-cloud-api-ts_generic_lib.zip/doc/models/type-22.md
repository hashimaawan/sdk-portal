
# Type 22

Type of the Image

## Enumeration

`Type22`

## Fields

| Name |
|  --- |
| `System` |
| `App` |
| `Snapshot` |
| `Backup` |
| `Temporary` |

## Example

```ts
import { Type22 } from 'hetzner-cloud-apilib';

const type22 = Type22.Temporary;
```

