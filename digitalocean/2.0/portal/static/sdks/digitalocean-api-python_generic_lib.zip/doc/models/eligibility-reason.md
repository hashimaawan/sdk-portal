
# Eligibility Reason

## Enumeration

`EligibilityReason`

## Fields

| Name |
|  --- |
| `OVERREPOSITORYLIMIT` |
| `OVERSTORAGELIMIT` |

## Example

```python
from digitaloceanapi.models.eligibility_reason import EligibilityReason

eligibility_reason = EligibilityReason.OVERREPOSITORYLIMIT
```

