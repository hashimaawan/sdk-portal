
# Terminate Session Request

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SessionId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getSessionId() | setSessionId(String sessionId) |

## Example

```java
import com.amazonaws.useast1.athena.models.TerminateSessionRequest;

TerminateSessionRequest terminateSessionRequest = new TerminateSessionRequest.Builder(
    "SessionId0"
)
.build();
```

