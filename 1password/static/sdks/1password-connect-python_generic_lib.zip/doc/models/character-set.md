
# Character Set

## Enumeration

`CharacterSet`

## Fields

| Name |
|  --- |
| `LETTERS` |
| `DIGITS` |
| `SYMBOLS` |

## Example

```python
from m1passwordconnect.models.character_set import CharacterSet

character_set = CharacterSet.DIGITS
```

