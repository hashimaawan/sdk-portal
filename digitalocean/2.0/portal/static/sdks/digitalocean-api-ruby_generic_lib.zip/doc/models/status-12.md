
# Status 12

A status string indicating the current state of the load balancer. This can be `new`, `active`, or `errored`.

## Enumeration

`Status12`

## Fields

| Name |
|  --- |
| `NEW` |
| `ACTIVE` |
| `ERRORED` |

## Example

```ruby
status12 = Status12::NEW
```

