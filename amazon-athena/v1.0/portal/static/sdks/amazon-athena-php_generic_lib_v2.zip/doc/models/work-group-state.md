
# Work Group State

## Enumeration

`WorkGroupState`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```php
use AmazonAthenaLib\Models\WorkGroupState;

$workGroupState = WorkGroupState::ENABLED;
```

