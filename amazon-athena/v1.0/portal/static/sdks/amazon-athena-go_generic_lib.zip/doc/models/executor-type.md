
# Executor Type

## Enumeration

`ExecutorType`

## Fields

| Name |
|  --- |
| `Coordinator` |
| `Gateway` |
| `Worker` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    executorType := models.ExecutorType_Gateway

}
```

