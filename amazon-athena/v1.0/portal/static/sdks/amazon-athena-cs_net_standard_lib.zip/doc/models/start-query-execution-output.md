
# Start Query Execution Output

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```csharp
using AmazonAthena.Standard.Models;

StartQueryExecutionOutput startQueryExecutionOutput = new StartQueryExecutionOutput
{
    QueryExecutionId = "QueryExecutionId0",
};
```

