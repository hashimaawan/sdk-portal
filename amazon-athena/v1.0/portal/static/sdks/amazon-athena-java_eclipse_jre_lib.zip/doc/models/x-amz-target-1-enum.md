
# X Amz Target 1 Enum

## Enumeration

`XAmzTarget1Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget1Enum;

XAmzTarget1Enum xAmzTarget1 = XAmzTarget1Enum.ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT;
```

