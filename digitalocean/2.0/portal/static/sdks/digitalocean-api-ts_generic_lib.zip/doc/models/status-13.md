
# Status 13

## Enumeration

`Status13`

## Fields

| Name |
|  --- |
| `Success` |
| `Error` |

## Example

```ts
import { Status13 } from 'digitalocean-apilib';

const status13 = Status13.Success;
```

