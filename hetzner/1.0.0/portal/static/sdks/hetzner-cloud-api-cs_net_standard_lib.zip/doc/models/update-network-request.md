
# Update Network Request

## Structure

`UpdateNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labels` | [`Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `Name` | `string` | Optional | New network name |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

UpdateNetworkRequest updateNetworkRequest = new UpdateNetworkRequest
{
    Labels = new Labels2
    {
        Labelkey = "labelkey4",
    },
    Name = "new-name",
};
```

