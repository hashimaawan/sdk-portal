
# X Amz Target 11

## Enumeration

`XAmzTarget11`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENOTEBOOK` |

## Example

```ruby
x_amz_target11 = XAmzTarget11::ENUM_AMAZONATHENADELETENOTEBOOK
```

