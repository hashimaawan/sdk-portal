
# Untag Resource Input

*This model accepts additional fields of type unknown.*

## Structure

`UntagResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resourceArn` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `tagKeys` | `string[]` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UntagResourceInput } from 'amazon-athenalib';

const untagResourceInput: UntagResourceInput = {
  resourceArn: 'ResourceARN6',
  tagKeys: [
    'TagKeys1',
    'TagKeys2',
    'TagKeys3'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

