
# Pricing

## Structure

`Pricing`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency` | `string` | Required | Currency the returned prices are expressed in, coded according to ISO 4217 |
| `floatingIp` | [`FloatingIp4`](../../doc/models/floating-ip-4.md) | Required | The cost of one Floating IP per month |
| `floatingIps` | [`FloatingIp5[]`](../../doc/models/floating-ip-5.md) | Required | Costs of Floating IPs types per Location and type |
| `image` | [`Image3`](../../doc/models/image-3.md) | Required | The cost of Image per GB/month |
| `loadBalancerTypes` | [`LoadBalancerType6[]`](../../doc/models/load-balancer-type-6.md) | Required | Costs of Load Balancer types per Location and type |
| `primaryIps` | [`PrimaryIp[]`](../../doc/models/primary-ip.md) | Required | Costs of Primary IPs types per Location |
| `serverBackup` | [`ServerBackup`](../../doc/models/server-backup.md) | Required | Will increase base Server costs by specific percentage |
| `serverTypes` | [`ServerTypes2[]`](../../doc/models/server-types-2.md) | Required | Costs of Server types per Location and type |
| `traffic` | [`Traffic`](../../doc/models/traffic.md) | Required | The cost of additional traffic per TB |
| `vatRate` | `string` | Required | The VAT rate used for calculating prices with VAT |
| `volume` | [`Volume`](../../doc/models/volume.md) | Required | The cost of Volume per GB/month |

## Example

```ts
import { Pricing, Type48, Type49 } from 'hetzner-cloud-apilib';

const pricing: Pricing = {
  currency: 'EUR',
  floatingIp: {
    priceMonthly: {
      gross: '1.1900000000000000',
      net: '1.0000000000',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  floatingIps: [
    {
      prices: [
        {
          location: 'fsn1',
          priceMonthly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      type: Type48.Ipv4,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  image: {
    pricePerGbMonth: {
      gross: '1.1900000000000000',
      net: '1.0000000000',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  loadBalancerTypes: [
    {
      id: 1,
      name: 'lb11',
      prices: [
        {
          location: 'fsn1',
          priceHourly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          priceMonthly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  primaryIps: [
    {
      prices: [
        {
          location: 'fsn1',
          priceHourly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          priceMonthly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      type: Type49.Ipv4,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  serverBackup: {
    percentage: '20.0000000000',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  serverTypes: [
    {
      id: 4,
      name: 'cx11',
      prices: [
        {
          location: 'fsn1',
          priceHourly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          priceMonthly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  traffic: {
    pricePerTb: {
      gross: '1.1900000000000000',
      net: '1.0000000000',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  vatRate: '19.000000',
  volume: {
    pricePerGbMonth: {
      gross: '1.1900000000000000',
      net: '1.0000000000',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
};
```

