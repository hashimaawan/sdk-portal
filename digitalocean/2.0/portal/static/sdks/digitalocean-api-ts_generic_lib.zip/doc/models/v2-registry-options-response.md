
# V2 Registry Options Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2RegistryOptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `options` | [`Options2 \| undefined`](../../doc/models/options-2.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2RegistryOptionsResponse } from 'digitalocean-apilib';

const v2RegistryOptionsResponse: V2RegistryOptionsResponse = {
  options: {
    availableRegions: [
      'available_regions9'
    ],
    subscriptionTiers: [
      {
        allowStorageOverage: false,
        includedBandwidthBytes: BigInt(172),
        includedRepositories: 194,
        includedStorageBytes: BigInt(242),
        monthlyPriceInCents: 236,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        allowStorageOverage: false,
        includedBandwidthBytes: BigInt(172),
        includedRepositories: 194,
        includedStorageBytes: BigInt(242),
        monthlyPriceInCents: 236,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        allowStorageOverage: false,
        includedBandwidthBytes: BigInt(172),
        includedRepositories: 194,
        includedStorageBytes: BigInt(242),
        monthlyPriceInCents: 236,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

