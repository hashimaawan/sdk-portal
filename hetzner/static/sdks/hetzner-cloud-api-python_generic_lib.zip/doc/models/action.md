
# Action

## Structure

`Action`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `command` | `str` | Required | Command executed in the Action |
| `error` | [`Error`](../../doc/models/error.md) | Required | Error message for the Action if error occurred, otherwise null |
| `finished` | `str` | Required | Point in time when the Action was finished (in ISO-8601 format). Only set if the Action is finished otherwise null. |
| `id` | `int` | Required | ID of the Resource |
| `progress` | `float` | Required | Progress of Action in percent |
| `resources` | [`List[Resource]`](../../doc/models/resource.md) | Required | Resources the Action relates to |
| `started` | `str` | Required | Point in time when the Action was started (in ISO-8601 format) |
| `status` | [`StatusEnum`](../../doc/models/status-enum.md) | Required | Status of the Action |

## Example

```python
from hetznercloudapi.models.action import Action
from hetznercloudapi.models.error import Error
from hetznercloudapi.models.resource import Resource
from hetznercloudapi.models.status_enum import StatusEnum

action = Action(
    command='start_server',
    error=Error(
        code='action_failed',
        message='Action failed'
    ),
    finished='2016-01-30T23:55:00+00:00',
    id=42,
    progress=100,
    resources=[
        Resource(
            id=42,
            mtype='server'
        )
    ],
    started='2016-01-30T23:55:00+00:00',
    status=StatusEnum.RUNNING
)
```

