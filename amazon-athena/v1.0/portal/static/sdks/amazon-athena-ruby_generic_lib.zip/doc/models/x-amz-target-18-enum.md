
# X Amz Target 18 Enum

## Enumeration

`XAmzTarget18Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATACATALOG` |

## Example

```ruby
x_amz_target18 = XAmzTarget18Enum::ENUM_AMAZONATHENAGETDATACATALOG
```

