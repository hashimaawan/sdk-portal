
# V2 Firewalls Droplets Request 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FirewallsDropletsRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletIds` | `number[]` | Required | An array containing the IDs of the Droplets to be assigned to the firewall. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FirewallsDropletsRequest1 } from 'digitalocean-apilib';

const v2FirewallsDropletsRequest1: V2FirewallsDropletsRequest1 = {
  dropletIds: [
    49696269
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

