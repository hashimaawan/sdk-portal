
# V2 Kubernetes Clusters Upgrade Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUpgradeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `version` | `?string` | Optional | The slug identifier for the version of Kubernetes that the cluster will be upgraded to. | getVersion(): ?string | setVersion(?string version): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2KubernetesClustersUpgradeRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2KubernetesClustersUpgradeRequest = V2KubernetesClustersUpgradeRequestBuilder::init()
    ->version('1.16.13-do.0')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

