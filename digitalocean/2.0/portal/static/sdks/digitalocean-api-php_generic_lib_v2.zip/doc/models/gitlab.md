
# Gitlab

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Gitlab`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `branch` | `?string` | Optional | The name of the branch to use | getBranch(): ?string | setBranch(?string branch): void |
| `deployOnPush` | `?bool` | Optional | Whether to automatically deploy new commits made to the repo | getDeployOnPush(): ?bool | setDeployOnPush(?bool deployOnPush): void |
| `repo` | `?string` | Optional | The name of the repo in the format owner/repo. Example: `digitalocean/sample-golang` | getRepo(): ?string | setRepo(?string repo): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\GitlabBuilder;
use DigitalOceanApiLib\ApiHelper;

$gitlab = GitlabBuilder::init()
    ->branch('main')
    ->deployOnPush(true)
    ->repo('digitalocean/sample-golang')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

