# API

```python
client_api = client.client
```

## Class Name

`Api`

## Methods

* [Trip GET](../../doc/controllers/api.md#trip-get)
* [Trip Stop by Trip Id GET](../../doc/controllers/api.md#trip-stop-by-trip-id-get)


# Trip GET

list user's trips

```python
def trip_get(self)
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`List[Trip]`](../../doc/models/trip.md).

## Example Usage

```python
result = client_api.trip_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Trip Stop by Trip Id GET

list stops for a trip identified by {trip_id}

```python
def trip_stop_by_trip_id_get(self,
                            trip_id)
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trip_id` | `str` | Template, Required | id of the trip |

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`List[Step]`](../../doc/models/step.md).

## Example Usage

```python
trip_id = 'trip_id2'

result = client_api.trip_stop_by_trip_id_get(trip_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

