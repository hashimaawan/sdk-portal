
# Operator

## Enumeration

`Operator`

## Fields

| Name |
|  --- |
| `UNSPECIFIED_OPERATOR` |
| `GREATER_THAN` |
| `LESS_THAN` |

## Example

```ruby
operator = Operator::LESS_THAN
```

