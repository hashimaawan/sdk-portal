
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `0` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`m1forgefinanceapisRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `m1forgefinanceapis.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "m1forgefinanceapis"
    "net/http"
)

func main() {
    httpConfiguration := m1forgefinanceapis.CreateHttpConfiguration(
        m1forgefinanceapis.WithTimeout(0),
        m1forgefinanceapis.WithTransport(http.DefaultTransport),
        m1forgefinanceapis.WithRetryConfiguration(m1forgefinanceapis.DefaultRetryConfiguration()),
    )
}
```

