
# Used By

## Structure

`UsedBy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of resource referenced |
| `mtype` | `str` | Required | Type of resource referenced |

## Example

```python
from hetznercloudapi.models.used_by import UsedBy

used_by = UsedBy(
    id=4711,
    mtype='load_balancer'
)
```

