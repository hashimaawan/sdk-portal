
# Progress 2

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Progress2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `steps` | [`Array[StepsOfAnAlertSProgress]`](../../doc/models/steps-of-an-alert-s-progress.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
progress2 = Progress2.new(
  steps: [
    StepsOfAnAlertSProgress.new(
      ended_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      name: 'name2',
      reason: Reason.new(
        code: 'code2',
        message: 'message4',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      started_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      status: Status2::SUCCESS,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    StepsOfAnAlertSProgress.new(
      ended_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      name: 'name2',
      reason: Reason.new(
        code: 'code2',
        message: 'message4',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      started_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      status: Status2::SUCCESS,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

