
# Get Calculation Execution Response

*This model accepts additional fields of type array.*

## Structure

`GetCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `calculationExecutionId` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | getCalculationExecutionId(): ?string | setCalculationExecutionId(?string calculationExecutionId): void |
| `sessionId` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getSessionId(): ?string | setSessionId(?string sessionId): void |
| `description` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getDescription(): ?string | setDescription(?string description): void |
| `workingDirectory` | `?string` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` | getWorkingDirectory(): ?string | setWorkingDirectory(?string workingDirectory): void |
| `status` | [`?Status1`](../../doc/models/status-1.md) | Optional | - | getStatus(): ?Status1 | setStatus(?Status1 status): void |
| `statistics` | [`?Statistics1`](../../doc/models/statistics-1.md) | Optional | - | getStatistics(): ?Statistics1 | setStatistics(?Statistics1 statistics): void |
| `result` | [`?Result`](../../doc/models/result.md) | Optional | - | getResult(): ?Result | setResult(?Result result): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetCalculationExecutionResponseBuilder;
use AmazonAthenaLib\Models\Builders\Status1Builder;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\Models\CalculationExecutionState1;
use AmazonAthenaLib\ApiHelper;

$getCalculationExecutionResponse = GetCalculationExecutionResponseBuilder::init()
    ->calculationExecutionId('CalculationExecutionId4')
    ->sessionId('SessionId8')
    ->description('Description6')
    ->workingDirectory('WorkingDirectory8')
    ->status(
        Status1Builder::init()
            ->submissionDateTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->completionDateTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->state(CalculationExecutionState1::CANCELING)
            ->stateChangeReason('StateChangeReason8')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

