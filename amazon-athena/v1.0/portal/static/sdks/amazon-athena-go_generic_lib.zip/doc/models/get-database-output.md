
# Get Database Output

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Database` | [`*models.Database2`](../../doc/models/database-2.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getDatabaseOutput := models.GetDatabaseOutput{
        Database:             models.ToPointer(models.Database2{
            Name:                 "Name2",
            Description:          models.ToPointer("Description8"),
            Parameters:           models.ToPointer(models.Parameters{
            }),
        }),
    }

}
```

