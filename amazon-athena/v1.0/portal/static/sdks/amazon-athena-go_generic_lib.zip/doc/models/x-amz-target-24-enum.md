
# X Amz Target 24 Enum

## Enumeration

`XAmzTarget24Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETQUERYRESULTS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget24 := models.XAmzTarget24Enum_ENUMAMAZONATHENAGETQUERYRESULTS

}
```

