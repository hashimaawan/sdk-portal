
# Status 1

The current status of the action. This can be "in-progress", "completed", or "errored".

## Enumeration

`Status1`

## Fields

| Name |
|  --- |
| `INPROGRESS` |
| `COMPLETED` |
| `ERRORED` |

## Example

```php
use DigitalOceanApiLib\Models\Status1;

$status1 = Status1::INPROGRESS;
```

