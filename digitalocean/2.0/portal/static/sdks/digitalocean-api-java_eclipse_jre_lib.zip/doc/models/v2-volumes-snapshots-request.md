
# V2 Volumes Snapshots Request

*This model accepts additional fields of type Object.*

## Structure

`V2VolumesSnapshotsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | A human-readable name for the volume snapshot. | String getName() | setName(String name) |
| `Tags` | `List<String>` | Optional | A flat array of tag names as strings to be applied to the resource. Tag names may be for either existing or new tags. | List<String> getTags() | setTags(List<String> tags) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.V2VolumesSnapshotsRequest;
import java.io.IOException;
import java.util.Arrays;

V2VolumesSnapshotsRequest v2VolumesSnapshotsRequest = new V2VolumesSnapshotsRequest.Builder(
    "big-data-snapshot1475261774"
)
.tags(Arrays.asList(
        "base-image",
        "prod"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

