
# Update Certificate Request

## Structure

`UpdateCertificateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Optional | New Certificate name |

## Example

```python
import jsonpickle

from hetznercloudapi.models.update_certificate_request import UpdateCertificateRequest

update_certificate_request = UpdateCertificateRequest(
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    name='my website cert'
)
```

