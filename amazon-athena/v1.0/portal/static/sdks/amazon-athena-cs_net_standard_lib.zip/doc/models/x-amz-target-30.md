
# X Amz Target 30

## Enumeration

`XAmzTarget30`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaImportNotebook` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget30 xAmzTarget30 = XAmzTarget30.EnumAmazonAthenaImportNotebook;
```

