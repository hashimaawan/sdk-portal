
# Type 15

The action to be taken on the image. Can be either `convert` or `transfer`.

## Enumeration

`Type15`

## Fields

| Name |
|  --- |
| `CONVERT` |
| `TRANSFER` |

## Example

```ruby
type15 = Type15::CONVERT
```

