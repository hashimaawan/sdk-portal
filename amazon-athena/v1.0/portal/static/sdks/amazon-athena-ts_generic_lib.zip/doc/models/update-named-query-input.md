
# Update Named Query Input

## Structure

`UpdateNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `queryString` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |

## Example

```ts
import { UpdateNamedQueryInput } from 'amazon-athenalib';

const updateNamedQueryInput: UpdateNamedQueryInput = {
  namedQueryId: 'NamedQueryId8',
  name: 'Name4',
  queryString: 'QueryString6',
  description: 'Description2',
};
```

