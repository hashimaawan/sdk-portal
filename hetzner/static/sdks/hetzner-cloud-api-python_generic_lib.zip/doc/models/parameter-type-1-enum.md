
# Parameter Type 1 Enum

## Enumeration

`ParameterType1Enum`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```python
from hetznercloudapi.models.parameter_type_1_enum import ParameterType1Enum

parameter_type_1 = ParameterType1Enum.SPREAD
```

