
# Change Protection Request

## Structure

`ChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `*bool` | Optional | If true, prevents the Floating IP from being deleted |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    changeProtectionRequest := models.ChangeProtectionRequest{
        Delete:               models.ToPointer(true),
    }

}
```

