
# Floating Ip 5

*This model accepts additional fields of type unknown.*

## Structure

`FloatingIp5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prices` | [`Price6[]`](../../doc/models/price-6.md) | Required | Floating IP type costs per Location |
| `type` | [`Type48`](../../doc/models/type-48.md) | Required | The type of the Floating IP |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FloatingIp5, Type48 } from 'hetzner-cloud-apilib';

const floatingIp5: FloatingIp5 = {
  prices: [
    {
      location: 'fsn1',
      priceMonthly: {
        gross: '1.1900000000000000',
        net: '1.0000000000',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  type: Type48.Ipv4,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

