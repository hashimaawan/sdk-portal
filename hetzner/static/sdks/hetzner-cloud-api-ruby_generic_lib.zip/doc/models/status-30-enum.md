
# Status 30 Enum

## Enumeration

`Status30Enum`

## Fields

| Name |
|  --- |
| `HEALTHY` |
| `UNHEALTHY` |
| `UNKNOWN` |

## Example

```ruby
status30 = Status30Enum::HEALTHY
```

