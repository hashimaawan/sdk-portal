
# Images Actions Change Protection Request

## Structure

`ImagesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `delete` | `?bool` | Optional | If true, prevents the snapshot from being deleted | getDelete(): ?bool | setDelete(?bool delete): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ImagesActionsChangeProtectionRequestBuilder;

$imagesActionsChangeProtectionRequest = ImagesActionsChangeProtectionRequestBuilder::init()
    ->delete(true)
    ->build();
```

