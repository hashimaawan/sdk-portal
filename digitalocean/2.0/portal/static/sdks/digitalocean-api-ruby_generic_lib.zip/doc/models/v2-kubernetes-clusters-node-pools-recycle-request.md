
# V2 Kubernetes Clusters Node Pools Recycle Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersNodePoolsRecycleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nodes` | `Array[String]` | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_kubernetes_clusters_node_pools_recycle_request = V2KubernetesClustersNodePoolsRecycleRequest.new(
  nodes: [
    'd8db5e1a-6103-43b5-a7b3-8a948210a9fc'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

