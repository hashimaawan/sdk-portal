
# X Amz Target 47 Enum

## Enumeration

`XAmzTarget47Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTQUERYEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget47Enum;

$xAmzTarget47 = XAmzTarget47Enum::ENUM_AMAZONATHENASTARTQUERYEXECUTION;
```

