
# Result Set Metadata 2

## Structure

`ResultSetMetadata2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ColumnInfo` | [`List<ColumnInfo>`](../../doc/models/column-info.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

ResultSetMetadata2 resultSetMetadata2 = new ResultSetMetadata2
{
    ColumnInfo = new List<ColumnInfo>
    {
        new ColumnInfo
        {
            Name = "Name6",
            Type = "Type6",
            CatalogName = "CatalogName0",
            SchemaName = "SchemaName0",
            TableName = "TableName2",
            Label = "Label4",
            Precision = 48,
        },
        new ColumnInfo
        {
            Name = "Name6",
            Type = "Type6",
            CatalogName = "CatalogName0",
            SchemaName = "SchemaName0",
            TableName = "TableName2",
            Label = "Label4",
            Precision = 48,
        },
    },
};
```

