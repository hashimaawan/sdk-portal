
# Status

Status of the Action

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ERROR` |

## Example

```ruby
status = Status::ERROR
```

