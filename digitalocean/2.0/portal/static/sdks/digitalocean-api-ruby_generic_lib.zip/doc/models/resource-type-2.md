
# Resource Type 2

The type of the resource.

## Enumeration

`ResourceType2`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `IMAGE` |
| `VOLUME` |
| `VOLUME_SNAPSHOT` |

## Example

```ruby
resource_type2 = ResourceType2::VOLUME
```

