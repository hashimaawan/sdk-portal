
# X Amz Target 26 Enum

## Enumeration

`XAmzTarget26Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget26Enum;

XAmzTarget26Enum xAmzTarget26 = XAmzTarget26Enum.ENUM_AMAZONATHENAGETSESSION;
```

