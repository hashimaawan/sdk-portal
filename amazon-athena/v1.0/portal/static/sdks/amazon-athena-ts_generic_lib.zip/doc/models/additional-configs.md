
# Additional Configs

## Structure

`AdditionalConfigs`

## Fields

|  |
| 

## Example (as JSON)

```json
{}
```

