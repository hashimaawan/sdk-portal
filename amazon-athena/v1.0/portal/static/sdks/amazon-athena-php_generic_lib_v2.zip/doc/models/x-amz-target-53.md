
# X Amz Target 53

## Enumeration

`XAmzTarget53`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUNTAGRESOURCE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget53;

$xAmzTarget53 = XAmzTarget53::ENUM_AMAZONATHENAUNTAGRESOURCE;
```

