
# Type 22 Enum

Type of the Image

## Enumeration

`Type22Enum`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `APP` |
| `SNAPSHOT` |
| `BACKUP` |
| `TEMPORARY` |

## Example

```ruby
type22 = Type22Enum::TEMPORARY
```

