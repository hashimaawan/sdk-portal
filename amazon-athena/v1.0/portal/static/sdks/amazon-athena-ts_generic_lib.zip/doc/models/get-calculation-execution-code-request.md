
# Get Calculation Execution Code Request

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```ts
import { GetCalculationExecutionCodeRequest } from 'amazon-athenalib';

const getCalculationExecutionCodeRequest: GetCalculationExecutionCodeRequest = {
  calculationExecutionId: 'CalculationExecutionId4',
};
```

