
# Get Table Metadata Output

*This model accepts additional fields of type Any.*

## Structure

`GetTableMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `table_metadata` | [`TableMetadata2`](../../doc/models/table-metadata-2.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from amazonathena.models.column import Column
from amazonathena.models.get_table_metadata_output import GetTableMetadataOutput
from amazonathena.models.table_metadata_2 import TableMetadata2

get_table_metadata_output = GetTableMetadataOutput(
    table_metadata=TableMetadata2(
        name='Name6',
        create_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
        last_access_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
        table_type='TableType0',
        columns=[
            Column(
                name='Name0',
                mtype='Type0',
                comment='Comment4',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Column(
                name='Name0',
                mtype='Type0',
                comment='Comment4',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Column(
                name='Name0',
                mtype='Type0',
                comment='Comment4',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        partition_keys=[
            Column(
                name='Name6',
                mtype='Type6',
                comment='Comment0',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

