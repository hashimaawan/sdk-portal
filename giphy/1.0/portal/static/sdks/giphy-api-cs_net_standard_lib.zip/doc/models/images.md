
# Images

An object containing data for various available formats and sizes of this GIF.

## Structure

`Images`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Downsized` | [`Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedLarge` | [`Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedMedium` | [`Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedSmall` | [`Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeight` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightDownsampled` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightSmall` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightSmallStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidth` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthDownsampled` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthSmall` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthSmallStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `Looping` | [`Image`](../../doc/models/image.md) | Optional | - |
| `Original` | [`Image`](../../doc/models/image.md) | Optional | - |
| `OriginalStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `Preview` | [`Image`](../../doc/models/image.md) | Optional | - |
| `PreviewGif` | [`Image`](../../doc/models/image.md) | Optional | - |

## Example

```csharp
using GiphyAPI.Standard.Models;

Images images = new Images
{
    Downsized = new Image
    {
        Frames = "frames0",
        Height = "height8",
        Mp4 = "mp40",
        Mp4Size = "mp4_size2",
        Size = "size2",
    },
    DownsizedLarge = new Image
    {
        Frames = "frames6",
        Height = "height4",
        Mp4 = "mp46",
        Mp4Size = "mp4_size8",
        Size = "size8",
    },
    DownsizedMedium = new Image
    {
        Frames = "frames2",
        Height = "height0",
        Mp4 = "mp42",
        Mp4Size = "mp4_size4",
        Size = "size4",
    },
    DownsizedSmall = new Image
    {
        Frames = "frames0",
        Height = "height8",
        Mp4 = "mp40",
        Mp4Size = "mp4_size2",
        Size = "size2",
    },
    DownsizedStill = new Image
    {
        Frames = "frames4",
        Height = "height4",
        Mp4 = "mp46",
        Mp4Size = "mp4_size8",
        Size = "size2",
    },
};
```

