
# X Amz Target 31 Enum

## Enumeration

`XAmzTarget31Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget31 := models.XAmzTarget31Enum_ENUMAMAZONATHENALISTAPPLICATIONDPUSIZES

}
```

