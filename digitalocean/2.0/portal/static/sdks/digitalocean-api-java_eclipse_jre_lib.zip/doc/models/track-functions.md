
# Track Functions

Enables tracking of function call counts and time used.

## Enumeration

`TrackFunctions`

## Fields

| Name |
|  --- |
| `ALL` |
| `PL` |
| `NONE` |

## Example

```java
import com.digitalocean.api.models.TrackFunctions;

TrackFunctions trackFunctions = TrackFunctions.PL;
```

