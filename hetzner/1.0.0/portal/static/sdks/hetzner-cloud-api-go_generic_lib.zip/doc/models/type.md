
# Type

Type of the Certificate

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    mType := models.Type_Uploaded

}
```

