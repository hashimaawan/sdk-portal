
# Mode Enum

travel mode

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```php
use FurkotTripsLib\Models\ModeEnum;

$mode = ModeEnum::BICYCLE;
```

