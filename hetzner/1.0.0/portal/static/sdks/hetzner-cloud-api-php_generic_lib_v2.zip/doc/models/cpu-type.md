
# Cpu Type

Type of cpu

## Enumeration

`CpuType`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```php
use HetznerCloudApiLib\Models\CpuType;

$cpuType = CpuType::SHARED;
```

