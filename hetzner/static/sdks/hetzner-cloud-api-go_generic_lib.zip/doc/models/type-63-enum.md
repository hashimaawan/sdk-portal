
# Type 63 Enum

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63Enum`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |
| `BACKUP` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type63 := models.Type63Enum_SNAPSHOT

}
```

