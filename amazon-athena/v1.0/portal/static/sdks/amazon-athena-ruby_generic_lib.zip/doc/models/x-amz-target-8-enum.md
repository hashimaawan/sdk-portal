
# X Amz Target 8 Enum

## Enumeration

`XAmzTarget8Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEWORKGROUP` |

## Example

```ruby
x_amz_target8 = XAmzTarget8Enum::ENUM_AMAZONATHENACREATEWORKGROUP
```

