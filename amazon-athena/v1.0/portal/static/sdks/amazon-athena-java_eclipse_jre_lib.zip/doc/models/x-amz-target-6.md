
# X Amz Target 6

## Enumeration

`XAmzTarget6`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget6;

XAmzTarget6 xAmzTarget6 = XAmzTarget6.ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT;
```

