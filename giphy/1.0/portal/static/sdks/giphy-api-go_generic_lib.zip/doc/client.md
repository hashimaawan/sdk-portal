
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| customQueryAuthenticationCredentials | [`CustomQueryAuthenticationCredentials`](auth/custom-query-parameter.md) | The Credentials Setter for Custom Query Parameter |

The API client can be initialized as follows:

```go
package main

import (
    "giphyApi"
)

func main() {
    client := giphyApi.NewClient(
    giphyApi.CreateConfiguration(
            giphyApi.WithHttpConfiguration(
                giphyApi.CreateHttpConfiguration(
                    giphyApi.WithTimeout(30),
                ),
            ),
            giphyApi.WithCustomQueryAuthenticationCredentials(
                giphyApi.NewCustomQueryAuthenticationCredentials("api_key"),
            ),
            giphyApi.WithLoggerConfiguration(
                giphyApi.WithLevel("info"),
                giphyApi.WithRequestConfiguration(
                    giphyApi.WithRequestBody(true),
                ),
                giphyApi.WithResponseConfiguration(
                    giphyApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Giphy API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| GifsApi() | Gets GifsApi |
| StickersApi() | Gets StickersApi |

