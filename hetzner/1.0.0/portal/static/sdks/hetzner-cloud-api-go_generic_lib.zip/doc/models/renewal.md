
# Renewal

Status of the renewal process of the Certificate.

## Enumeration

`Renewal`

## Fields

| Name |
|  --- |
| `Scheduled` |
| `Pending` |
| `Failed` |
| `Unavailable` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    renewal := models.Renewal_Failed

}
```

