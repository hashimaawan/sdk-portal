
# Start Session Response

*This model accepts additional fields of type interface{}.*

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `State` | [`*models.SessionState1`](../../doc/models/session-state-1.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    startSessionResponse := models.StartSessionResponse{
        SessionId:             models.ToPointer("SessionId4"),
        State:                 models.ToPointer(models.SessionState1_Creating),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

