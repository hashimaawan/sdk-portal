
# V2 Cdn Endpoints Cache Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsCacheRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `files` | `string[]` | Required | An array of strings containing the path to the content to be purged from the CDN cache. | getFiles(): array | setFiles(array files): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2CdnEndpointsCacheRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2CdnEndpointsCacheRequest = V2CdnEndpointsCacheRequestBuilder::init(
    [
        'path/to/image.png',
        'path/to/css/*'
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

