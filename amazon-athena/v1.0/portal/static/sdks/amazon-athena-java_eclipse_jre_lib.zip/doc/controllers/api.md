# API

```java
APIController aPIController = client.getAPIController();
```

## Class Name

`APIController`

## Methods

* [Batch Get Named Query](../../doc/controllers/api.md#batch-get-named-query)
* [Batch Get Prepared Statement](../../doc/controllers/api.md#batch-get-prepared-statement)
* [Batch Get Query Execution](../../doc/controllers/api.md#batch-get-query-execution)
* [Create Data Catalog](../../doc/controllers/api.md#create-data-catalog)
* [Create Named Query](../../doc/controllers/api.md#create-named-query)
* [Create Notebook](../../doc/controllers/api.md#create-notebook)
* [Create Prepared Statement](../../doc/controllers/api.md#create-prepared-statement)
* [Create Presigned Notebook Url](../../doc/controllers/api.md#create-presigned-notebook-url)
* [Create Work Group](../../doc/controllers/api.md#create-work-group)
* [Delete Data Catalog](../../doc/controllers/api.md#delete-data-catalog)
* [Delete Named Query](../../doc/controllers/api.md#delete-named-query)
* [Delete Notebook](../../doc/controllers/api.md#delete-notebook)
* [Delete Prepared Statement](../../doc/controllers/api.md#delete-prepared-statement)
* [Delete Work Group](../../doc/controllers/api.md#delete-work-group)
* [Export Notebook](../../doc/controllers/api.md#export-notebook)
* [Get Calculation Execution](../../doc/controllers/api.md#get-calculation-execution)
* [Get Calculation Execution Code](../../doc/controllers/api.md#get-calculation-execution-code)
* [Get Calculation Execution Status](../../doc/controllers/api.md#get-calculation-execution-status)
* [Get Data Catalog](../../doc/controllers/api.md#get-data-catalog)
* [Get Database](../../doc/controllers/api.md#get-database)
* [Get Named Query](../../doc/controllers/api.md#get-named-query)
* [Get Notebook Metadata](../../doc/controllers/api.md#get-notebook-metadata)
* [Get Prepared Statement](../../doc/controllers/api.md#get-prepared-statement)
* [Get Query Execution](../../doc/controllers/api.md#get-query-execution)
* [Get Query Results](../../doc/controllers/api.md#get-query-results)
* [Get Query Runtime Statistics](../../doc/controllers/api.md#get-query-runtime-statistics)
* [Get Session](../../doc/controllers/api.md#get-session)
* [Get Session Status](../../doc/controllers/api.md#get-session-status)
* [Get Table Metadata](../../doc/controllers/api.md#get-table-metadata)
* [Get Work Group](../../doc/controllers/api.md#get-work-group)
* [Import Notebook](../../doc/controllers/api.md#import-notebook)
* [List Application DPU Sizes](../../doc/controllers/api.md#list-application-dpu-sizes)
* [List Calculation Executions](../../doc/controllers/api.md#list-calculation-executions)
* [List Data Catalogs](../../doc/controllers/api.md#list-data-catalogs)
* [List Databases](../../doc/controllers/api.md#list-databases)
* [List Engine Versions](../../doc/controllers/api.md#list-engine-versions)
* [List Executors](../../doc/controllers/api.md#list-executors)
* [List Named Queries](../../doc/controllers/api.md#list-named-queries)
* [List Notebook Metadata](../../doc/controllers/api.md#list-notebook-metadata)
* [List Notebook Sessions](../../doc/controllers/api.md#list-notebook-sessions)
* [List Prepared Statements](../../doc/controllers/api.md#list-prepared-statements)
* [List Query Executions](../../doc/controllers/api.md#list-query-executions)
* [List Sessions](../../doc/controllers/api.md#list-sessions)
* [List Table Metadata](../../doc/controllers/api.md#list-table-metadata)
* [List Tags for Resource](../../doc/controllers/api.md#list-tags-for-resource)
* [List Work Groups](../../doc/controllers/api.md#list-work-groups)
* [Start Calculation Execution](../../doc/controllers/api.md#start-calculation-execution)
* [Start Query Execution](../../doc/controllers/api.md#start-query-execution)
* [Start Session](../../doc/controllers/api.md#start-session)
* [Stop Calculation Execution](../../doc/controllers/api.md#stop-calculation-execution)
* [Stop Query Execution](../../doc/controllers/api.md#stop-query-execution)
* [Tag Resource](../../doc/controllers/api.md#tag-resource)
* [Terminate Session](../../doc/controllers/api.md#terminate-session)
* [Untag Resource](../../doc/controllers/api.md#untag-resource)
* [Update Data Catalog](../../doc/controllers/api.md#update-data-catalog)
* [Update Named Query](../../doc/controllers/api.md#update-named-query)
* [Update Notebook](../../doc/controllers/api.md#update-notebook)
* [Update Notebook Metadata](../../doc/controllers/api.md#update-notebook-metadata)
* [Update Prepared Statement](../../doc/controllers/api.md#update-prepared-statement)
* [Update Work Group](../../doc/controllers/api.md#update-work-group)


# Batch Get Named Query

Returns the details of a single named query or a list of up to 50 queries, which you provide as an array of query ID strings. Requires you to have access to the workgroup in which the queries were saved. Use <a>ListNamedQueriesInput</a> to get the list of named query IDs in the specified workgroup. If information could not be retrieved for a submitted query ID, information about the query ID submitted is listed under <a>UnprocessedNamedQueryId</a>. Named queries differ from executed queries. Use <a>BatchGetQueryExecutionInput</a> to get details about each unique query execution, and <a>ListQueryExecutionsInput</a> to get a list of query execution IDs.

```java
CompletableFuture<BatchGetNamedQueryOutput> batchGetNamedQueryAsync(
    final XAmzTargetEnum xAmzTarget,
    final BatchGetNamedQueryInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTargetEnum`](../../doc/models/x-amz-target-enum.md) | Header, Required | - |
| `body` | [`BatchGetNamedQueryInput`](../../doc/models/batch-get-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`BatchGetNamedQueryOutput`](../../doc/models/batch-get-named-query-output.md)

## Example Usage

```java
XAmzTargetEnum xAmzTarget = XAmzTargetEnum.ENUM_AMAZONATHENABATCHGETNAMEDQUERY;
BatchGetNamedQueryInput body = new BatchGetNamedQueryInput.Builder(
    Arrays.asList(
        "NamedQueryIds9"
    )
)
.build();


aPIController.batchGetNamedQueryAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Batch Get Prepared Statement

Returns the details of a single prepared statement or a list of up to 256 prepared statements for the array of prepared statement names that you provide. Requires you to have access to the workgroup to which the prepared statements belong. If a prepared statement cannot be retrieved for the name specified, the statement is listed in <code>UnprocessedPreparedStatementNames</code>.

```java
CompletableFuture<BatchGetPreparedStatementOutput> batchGetPreparedStatementAsync(
    final XAmzTarget1Enum xAmzTarget,
    final BatchGetPreparedStatementInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget1Enum`](../../doc/models/x-amz-target-1-enum.md) | Header, Required | - |
| `body` | [`BatchGetPreparedStatementInput`](../../doc/models/batch-get-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`BatchGetPreparedStatementOutput`](../../doc/models/batch-get-prepared-statement-output.md)

## Example Usage

```java
XAmzTarget1Enum xAmzTarget = XAmzTarget1Enum.ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT;
BatchGetPreparedStatementInput body = new BatchGetPreparedStatementInput.Builder(
    Arrays.asList(
        "PreparedStatementNames0",
        "PreparedStatementNames1",
        "PreparedStatementNames2"
    ),
    "WorkGroup8"
)
.build();


aPIController.batchGetPreparedStatementAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Batch Get Query Execution

Returns the details of a single query execution or a list of up to 50 query executions, which you provide as an array of query execution ID strings. Requires you to have access to the workgroup in which the queries ran. To get a list of query execution IDs, use <a>ListQueryExecutionsInput$WorkGroup</a>. Query executions differ from named (saved) queries. Use <a>BatchGetNamedQueryInput</a> to get details about named queries.

```java
CompletableFuture<BatchGetQueryExecutionOutput> batchGetQueryExecutionAsync(
    final XAmzTarget2Enum xAmzTarget,
    final BatchGetQueryExecutionInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget2Enum`](../../doc/models/x-amz-target-2-enum.md) | Header, Required | - |
| `body` | [`BatchGetQueryExecutionInput`](../../doc/models/batch-get-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`BatchGetQueryExecutionOutput`](../../doc/models/batch-get-query-execution-output.md)

## Example Usage

```java
XAmzTarget2Enum xAmzTarget = XAmzTarget2Enum.ENUM_AMAZONATHENABATCHGETQUERYEXECUTION;
BatchGetQueryExecutionInput body = new BatchGetQueryExecutionInput.Builder(
    Arrays.asList(
        "QueryExecutionIds3"
    )
)
.build();


aPIController.batchGetQueryExecutionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Data Catalog

Creates (registers) a data catalog with the specified name and properties. Catalogs created are visible to all users of the same Amazon Web Services account.

```java
CompletableFuture<Object> createDataCatalogAsync(
    final XAmzTarget3Enum xAmzTarget,
    final CreateDataCatalogInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget3Enum`](../../doc/models/x-amz-target-3-enum.md) | Header, Required | - |
| `body` | [`CreateDataCatalogInput`](../../doc/models/create-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget3Enum xAmzTarget = XAmzTarget3Enum.ENUM_AMAZONATHENACREATEDATACATALOG;
CreateDataCatalogInput body = new CreateDataCatalogInput.Builder(
    "Name6",
    DataCatalogType1Enum.HIVE
)
.build();


aPIController.createDataCatalogAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Named Query

<p>Creates a named query in the specified workgroup. Requires that you have access to the workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```java
CompletableFuture<CreateNamedQueryOutput> createNamedQueryAsync(
    final XAmzTarget4Enum xAmzTarget,
    final CreateNamedQueryInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget4Enum`](../../doc/models/x-amz-target-4-enum.md) | Header, Required | - |
| `body` | [`CreateNamedQueryInput`](../../doc/models/create-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`CreateNamedQueryOutput`](../../doc/models/create-named-query-output.md)

## Example Usage

```java
XAmzTarget4Enum xAmzTarget = XAmzTarget4Enum.ENUM_AMAZONATHENACREATENAMEDQUERY;
CreateNamedQueryInput body = new CreateNamedQueryInput.Builder(
    "Name6",
    "Database4",
    "QueryString8"
)
.build();


aPIController.createNamedQueryAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Notebook

Creates an empty <code>ipynb</code> file in the specified Apache Spark enabled workgroup. Throws an error if a file in the workgroup with the same name already exists.

```java
CompletableFuture<CreateNotebookOutput> createNotebookAsync(
    final XAmzTarget5Enum xAmzTarget,
    final CreateNotebookInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget5Enum`](../../doc/models/x-amz-target-5-enum.md) | Header, Required | - |
| `body` | [`CreateNotebookInput`](../../doc/models/create-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`CreateNotebookOutput`](../../doc/models/create-notebook-output.md)

## Example Usage

```java
XAmzTarget5Enum xAmzTarget = XAmzTarget5Enum.ENUM_AMAZONATHENACREATENOTEBOOK;
CreateNotebookInput body = new CreateNotebookInput.Builder(
    "WorkGroup8",
    "Name6"
)
.build();


aPIController.createNotebookAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Create Prepared Statement

Creates a prepared statement for use with SQL queries in Athena.

```java
CompletableFuture<Object> createPreparedStatementAsync(
    final XAmzTarget6Enum xAmzTarget,
    final CreatePreparedStatementInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget6Enum`](../../doc/models/x-amz-target-6-enum.md) | Header, Required | - |
| `body` | [`CreatePreparedStatementInput`](../../doc/models/create-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget6Enum xAmzTarget = XAmzTarget6Enum.ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT;
CreatePreparedStatementInput body = new CreatePreparedStatementInput.Builder(
    "StatementName4",
    "WorkGroup8",
    "QueryStatement8"
)
.build();


aPIController.createPreparedStatementAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Presigned Notebook Url

Gets an authentication token and the URL at which the notebook can be accessed. During programmatic access, <code>CreatePresignedNotebookUrl</code> must be called every 10 minutes to refresh the authentication token. For information about granting programmatic access, see <a href="https://docs.aws.amazon.com/athena/latest/ug/setting-up.html#setting-up-grant-programmatic-access">Grant programmatic access</a>.

```java
CompletableFuture<CreatePresignedNotebookUrlResponse> createPresignedNotebookUrlAsync(
    final XAmzTarget7Enum xAmzTarget,
    final CreatePresignedNotebookUrlRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget7Enum`](../../doc/models/x-amz-target-7-enum.md) | Header, Required | - |
| `body` | [`CreatePresignedNotebookUrlRequest`](../../doc/models/create-presigned-notebook-url-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`CreatePresignedNotebookUrlResponse`](../../doc/models/create-presigned-notebook-url-response.md)

## Example Usage

```java
XAmzTarget7Enum xAmzTarget = XAmzTarget7Enum.ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL;
CreatePresignedNotebookUrlRequest body = new CreatePresignedNotebookUrlRequest.Builder(
    "SessionId2"
)
.build();


aPIController.createPresignedNotebookUrlAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Create Work Group

Creates a workgroup with the specified name. A workgroup can be an Apache Spark enabled workgroup or an Athena SQL workgroup.

```java
CompletableFuture<Object> createWorkGroupAsync(
    final XAmzTarget8Enum xAmzTarget,
    final CreateWorkGroupInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget8Enum`](../../doc/models/x-amz-target-8-enum.md) | Header, Required | - |
| `body` | [`CreateWorkGroupInput`](../../doc/models/create-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget8Enum xAmzTarget = XAmzTarget8Enum.ENUM_AMAZONATHENACREATEWORKGROUP;
CreateWorkGroupInput body = new CreateWorkGroupInput.Builder(
    "Name6"
)
.build();


aPIController.createWorkGroupAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Data Catalog

Deletes a data catalog.

```java
CompletableFuture<Object> deleteDataCatalogAsync(
    final XAmzTarget9Enum xAmzTarget,
    final DeleteDataCatalogInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget9Enum`](../../doc/models/x-amz-target-9-enum.md) | Header, Required | - |
| `body` | [`DeleteDataCatalogInput`](../../doc/models/delete-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget9Enum xAmzTarget = XAmzTarget9Enum.ENUM_AMAZONATHENADELETEDATACATALOG;
DeleteDataCatalogInput body = new DeleteDataCatalogInput.Builder(
    "Name6"
)
.build();


aPIController.deleteDataCatalogAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Named Query

<p>Deletes the named query if you have access to the workgroup in which the query was saved.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```java
CompletableFuture<Object> deleteNamedQueryAsync(
    final XAmzTarget10Enum xAmzTarget,
    final DeleteNamedQueryInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget10Enum`](../../doc/models/x-amz-target-10-enum.md) | Header, Required | - |
| `body` | [`DeleteNamedQueryInput`](../../doc/models/delete-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget10Enum xAmzTarget = XAmzTarget10Enum.ENUM_AMAZONATHENADELETENAMEDQUERY;
DeleteNamedQueryInput body = new DeleteNamedQueryInput.Builder(
    "NamedQueryId6"
)
.build();


aPIController.deleteNamedQueryAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Notebook

Deletes the specified notebook.

```java
CompletableFuture<Object> deleteNotebookAsync(
    final XAmzTarget11Enum xAmzTarget,
    final DeleteNotebookInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget11Enum`](../../doc/models/x-amz-target-11-enum.md) | Header, Required | - |
| `body` | [`DeleteNotebookInput`](../../doc/models/delete-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget11Enum xAmzTarget = XAmzTarget11Enum.ENUM_AMAZONATHENADELETENOTEBOOK;
DeleteNotebookInput body = new DeleteNotebookInput.Builder(
    "NotebookId6"
)
.build();


aPIController.deleteNotebookAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Delete Prepared Statement

Deletes the prepared statement with the specified name from the specified workgroup.

```java
CompletableFuture<Object> deletePreparedStatementAsync(
    final XAmzTarget12Enum xAmzTarget,
    final DeletePreparedStatementInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget12Enum`](../../doc/models/x-amz-target-12-enum.md) | Header, Required | - |
| `body` | [`DeletePreparedStatementInput`](../../doc/models/delete-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget12Enum xAmzTarget = XAmzTarget12Enum.ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT;
DeletePreparedStatementInput body = new DeletePreparedStatementInput.Builder(
    "StatementName4",
    "WorkGroup8"
)
.build();


aPIController.deletePreparedStatementAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Delete Work Group

Deletes the workgroup with the specified name. The primary workgroup cannot be deleted.

```java
CompletableFuture<Object> deleteWorkGroupAsync(
    final XAmzTarget13Enum xAmzTarget,
    final DeleteWorkGroupInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget13Enum`](../../doc/models/x-amz-target-13-enum.md) | Header, Required | - |
| `body` | [`DeleteWorkGroupInput`](../../doc/models/delete-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget13Enum xAmzTarget = XAmzTarget13Enum.ENUM_AMAZONATHENADELETEWORKGROUP;
DeleteWorkGroupInput body = new DeleteWorkGroupInput.Builder(
    "WorkGroup8"
)
.build();


aPIController.deleteWorkGroupAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Export Notebook

Exports the specified notebook and its metadata.

```java
CompletableFuture<ExportNotebookOutput> exportNotebookAsync(
    final XAmzTarget14Enum xAmzTarget,
    final ExportNotebookInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget14Enum`](../../doc/models/x-amz-target-14-enum.md) | Header, Required | - |
| `body` | [`ExportNotebookInput`](../../doc/models/export-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`ExportNotebookOutput`](../../doc/models/export-notebook-output.md)

## Example Usage

```java
XAmzTarget14Enum xAmzTarget = XAmzTarget14Enum.ENUM_AMAZONATHENAEXPORTNOTEBOOK;
ExportNotebookInput body = new ExportNotebookInput.Builder(
    "NotebookId6"
)
.build();


aPIController.exportNotebookAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Calculation Execution

Describes a previously submitted calculation execution.

```java
CompletableFuture<GetCalculationExecutionResponse> getCalculationExecutionAsync(
    final XAmzTarget15Enum xAmzTarget,
    final GetCalculationExecutionRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget15Enum`](../../doc/models/x-amz-target-15-enum.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionRequest`](../../doc/models/get-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetCalculationExecutionResponse`](../../doc/models/get-calculation-execution-response.md)

## Example Usage

```java
XAmzTarget15Enum xAmzTarget = XAmzTarget15Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTION;
GetCalculationExecutionRequest body = new GetCalculationExecutionRequest.Builder(
    "CalculationExecutionId8"
)
.build();


aPIController.getCalculationExecutionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Calculation Execution Code

Retrieves the unencrypted code that was executed for the calculation.

```java
CompletableFuture<GetCalculationExecutionCodeResponse> getCalculationExecutionCodeAsync(
    final XAmzTarget16Enum xAmzTarget,
    final GetCalculationExecutionCodeRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget16Enum`](../../doc/models/x-amz-target-16-enum.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionCodeRequest`](../../doc/models/get-calculation-execution-code-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetCalculationExecutionCodeResponse`](../../doc/models/get-calculation-execution-code-response.md)

## Example Usage

```java
XAmzTarget16Enum xAmzTarget = XAmzTarget16Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE;
GetCalculationExecutionCodeRequest body = new GetCalculationExecutionCodeRequest.Builder(
    "CalculationExecutionId8"
)
.build();


aPIController.getCalculationExecutionCodeAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Calculation Execution Status

Gets the status of a current calculation.

```java
CompletableFuture<GetCalculationExecutionStatusResponse> getCalculationExecutionStatusAsync(
    final XAmzTarget17Enum xAmzTarget,
    final GetCalculationExecutionStatusRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget17Enum`](../../doc/models/x-amz-target-17-enum.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionStatusRequest`](../../doc/models/get-calculation-execution-status-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetCalculationExecutionStatusResponse`](../../doc/models/get-calculation-execution-status-response.md)

## Example Usage

```java
XAmzTarget17Enum xAmzTarget = XAmzTarget17Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS;
GetCalculationExecutionStatusRequest body = new GetCalculationExecutionStatusRequest.Builder(
    "CalculationExecutionId8"
)
.build();


aPIController.getCalculationExecutionStatusAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Data Catalog

Returns the specified data catalog.

```java
CompletableFuture<GetDataCatalogOutput> getDataCatalogAsync(
    final XAmzTarget18Enum xAmzTarget,
    final GetDataCatalogInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget18Enum`](../../doc/models/x-amz-target-18-enum.md) | Header, Required | - |
| `body` | [`GetDataCatalogInput`](../../doc/models/get-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetDataCatalogOutput`](../../doc/models/get-data-catalog-output.md)

## Example Usage

```java
XAmzTarget18Enum xAmzTarget = XAmzTarget18Enum.ENUM_AMAZONATHENAGETDATACATALOG;
GetDataCatalogInput body = new GetDataCatalogInput.Builder(
    "Name6"
)
.build();


aPIController.getDataCatalogAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Database

Returns a database object for the specified database and data catalog.

```java
CompletableFuture<GetDatabaseOutput> getDatabaseAsync(
    final XAmzTarget19Enum xAmzTarget,
    final GetDatabaseInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget19Enum`](../../doc/models/x-amz-target-19-enum.md) | Header, Required | - |
| `body` | [`GetDatabaseInput`](../../doc/models/get-database-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetDatabaseOutput`](../../doc/models/get-database-output.md)

## Example Usage

```java
XAmzTarget19Enum xAmzTarget = XAmzTarget19Enum.ENUM_AMAZONATHENAGETDATABASE;
GetDatabaseInput body = new GetDatabaseInput.Builder(
    "CatalogName0",
    "DatabaseName0"
)
.build();


aPIController.getDatabaseAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# Get Named Query

Returns information about a single query. Requires that you have access to the workgroup in which the query was saved.

```java
CompletableFuture<GetNamedQueryOutput> getNamedQueryAsync(
    final XAmzTarget20Enum xAmzTarget,
    final GetNamedQueryInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget20Enum`](../../doc/models/x-amz-target-20-enum.md) | Header, Required | - |
| `body` | [`GetNamedQueryInput`](../../doc/models/get-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetNamedQueryOutput`](../../doc/models/get-named-query-output.md)

## Example Usage

```java
XAmzTarget20Enum xAmzTarget = XAmzTarget20Enum.ENUM_AMAZONATHENAGETNAMEDQUERY;
GetNamedQueryInput body = new GetNamedQueryInput.Builder(
    "NamedQueryId6"
)
.build();


aPIController.getNamedQueryAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Notebook Metadata

Retrieves notebook metadata for the specified notebook ID.

```java
CompletableFuture<GetNotebookMetadataOutput> getNotebookMetadataAsync(
    final XAmzTarget21Enum xAmzTarget,
    final GetNotebookMetadataInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget21Enum`](../../doc/models/x-amz-target-21-enum.md) | Header, Required | - |
| `body` | [`GetNotebookMetadataInput`](../../doc/models/get-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetNotebookMetadataOutput`](../../doc/models/get-notebook-metadata-output.md)

## Example Usage

```java
XAmzTarget21Enum xAmzTarget = XAmzTarget21Enum.ENUM_AMAZONATHENAGETNOTEBOOKMETADATA;
GetNotebookMetadataInput body = new GetNotebookMetadataInput.Builder(
    "NotebookId6"
)
.build();


aPIController.getNotebookMetadataAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Prepared Statement

Retrieves the prepared statement with the specified name from the specified workgroup.

```java
CompletableFuture<GetPreparedStatementOutput> getPreparedStatementAsync(
    final XAmzTarget22Enum xAmzTarget,
    final GetPreparedStatementInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget22Enum`](../../doc/models/x-amz-target-22-enum.md) | Header, Required | - |
| `body` | [`GetPreparedStatementInput`](../../doc/models/get-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetPreparedStatementOutput`](../../doc/models/get-prepared-statement-output.md)

## Example Usage

```java
XAmzTarget22Enum xAmzTarget = XAmzTarget22Enum.ENUM_AMAZONATHENAGETPREPAREDSTATEMENT;
GetPreparedStatementInput body = new GetPreparedStatementInput.Builder(
    "StatementName4",
    "WorkGroup8"
)
.build();


aPIController.getPreparedStatementAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Query Execution

Returns information about a single execution of a query if you have access to the workgroup in which the query ran. Each time a query executes, information about the query execution is saved with a unique ID.

```java
CompletableFuture<GetQueryExecutionOutput> getQueryExecutionAsync(
    final XAmzTarget23Enum xAmzTarget,
    final GetQueryExecutionInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget23Enum`](../../doc/models/x-amz-target-23-enum.md) | Header, Required | - |
| `body` | [`GetQueryExecutionInput`](../../doc/models/get-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetQueryExecutionOutput`](../../doc/models/get-query-execution-output.md)

## Example Usage

```java
XAmzTarget23Enum xAmzTarget = XAmzTarget23Enum.ENUM_AMAZONATHENAGETQUERYEXECUTION;
GetQueryExecutionInput body = new GetQueryExecutionInput.Builder(
    "QueryExecutionId0"
)
.build();


aPIController.getQueryExecutionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Query Results

<p>Streams the results of a single query execution specified by <code>QueryExecutionId</code> from the Athena query results location in Amazon S3. For more information, see <a href="https://docs.aws.amazon.com/athena/latest/ug/querying.html">Working with query results, recent queries, and output files</a> in the <i>Amazon Athena User Guide</i>. This request does not execute the query but returns results. Use <a>StartQueryExecution</a> to run a query.</p> <p>To stream query results successfully, the IAM principal with permission to call <code>GetQueryResults</code> also must have permissions to the Amazon S3 <code>GetObject</code> action for the Athena query results location.</p> <important> <p>IAM principals with permission to the Amazon S3 <code>GetObject</code> action for the query results location are able to retrieve query results from Amazon S3 even if permission to the <code>GetQueryResults</code> action is denied. To restrict user or role access, ensure that Amazon S3 permissions to the Athena query location are denied.</p> </important>


```java
CompletableFuture<GetQueryResultsOutput> getQueryResultsAsync(
    final XAmzTarget24Enum xAmzTarget,
    final GetQueryResultsInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget24Enum`](../../doc/models/x-amz-target-24-enum.md) | Header, Required | - |
| `body` | [`GetQueryResultsInput`](../../doc/models/get-query-results-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`GetQueryResultsOutput`](../../doc/models/get-query-results-output.md)

## Example Usage

```java
XAmzTarget24Enum xAmzTarget = XAmzTarget24Enum.ENUM_AMAZONATHENAGETQUERYRESULTS;
GetQueryResultsInput body = new GetQueryResultsInput.Builder(
    "QueryExecutionId0"
)
.build();


aPIController.getQueryResultsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Query Runtime Statistics

Returns query execution runtime statistics related to a single execution of a query if you have access to the workgroup in which the query ran. Query execution runtime statistics are returned only when <a>QueryExecutionStatus$State</a> is in a SUCCEEDED or FAILED state. Stage-level input and output row count and data size statistics are not shown when a query has row-level filters defined in Lake Formation.

```java
CompletableFuture<GetQueryRuntimeStatisticsOutput> getQueryRuntimeStatisticsAsync(
    final XAmzTarget25Enum xAmzTarget,
    final GetQueryRuntimeStatisticsInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget25Enum`](../../doc/models/x-amz-target-25-enum.md) | Header, Required | - |
| `body` | [`GetQueryRuntimeStatisticsInput`](../../doc/models/get-query-runtime-statistics-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetQueryRuntimeStatisticsOutput`](../../doc/models/get-query-runtime-statistics-output.md)

## Example Usage

```java
XAmzTarget25Enum xAmzTarget = XAmzTarget25Enum.ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS;
GetQueryRuntimeStatisticsInput body = new GetQueryRuntimeStatisticsInput.Builder(
    "QueryExecutionId0"
)
.build();


aPIController.getQueryRuntimeStatisticsAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Session

Gets the full details of a previously created session, including the session status and configuration.

```java
CompletableFuture<GetSessionResponse> getSessionAsync(
    final XAmzTarget26Enum xAmzTarget,
    final GetSessionRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget26Enum`](../../doc/models/x-amz-target-26-enum.md) | Header, Required | - |
| `body` | [`GetSessionRequest`](../../doc/models/get-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetSessionResponse`](../../doc/models/get-session-response.md)

## Example Usage

```java
XAmzTarget26Enum xAmzTarget = XAmzTarget26Enum.ENUM_AMAZONATHENAGETSESSION;
GetSessionRequest body = new GetSessionRequest.Builder(
    "SessionId2"
)
.build();


aPIController.getSessionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Session Status

Gets the current status of a session.

```java
CompletableFuture<GetSessionStatusResponse> getSessionStatusAsync(
    final XAmzTarget27Enum xAmzTarget,
    final GetSessionStatusRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget27Enum`](../../doc/models/x-amz-target-27-enum.md) | Header, Required | - |
| `body` | [`GetSessionStatusRequest`](../../doc/models/get-session-status-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetSessionStatusResponse`](../../doc/models/get-session-status-response.md)

## Example Usage

```java
XAmzTarget27Enum xAmzTarget = XAmzTarget27Enum.ENUM_AMAZONATHENAGETSESSIONSTATUS;
GetSessionStatusRequest body = new GetSessionStatusRequest.Builder(
    "SessionId2"
)
.build();


aPIController.getSessionStatusAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Table Metadata

Returns table metadata for the specified catalog, database, and table.

```java
CompletableFuture<GetTableMetadataOutput> getTableMetadataAsync(
    final XAmzTarget28Enum xAmzTarget,
    final GetTableMetadataInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget28Enum`](../../doc/models/x-amz-target-28-enum.md) | Header, Required | - |
| `body` | [`GetTableMetadataInput`](../../doc/models/get-table-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetTableMetadataOutput`](../../doc/models/get-table-metadata-output.md)

## Example Usage

```java
XAmzTarget28Enum xAmzTarget = XAmzTarget28Enum.ENUM_AMAZONATHENAGETTABLEMETADATA;
GetTableMetadataInput body = new GetTableMetadataInput.Builder(
    "CatalogName0",
    "DatabaseName0",
    "TableName2"
)
.build();


aPIController.getTableMetadataAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# Get Work Group

Returns information about the workgroup with the specified name.

```java
CompletableFuture<GetWorkGroupOutput> getWorkGroupAsync(
    final XAmzTarget29Enum xAmzTarget,
    final GetWorkGroupInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget29Enum`](../../doc/models/x-amz-target-29-enum.md) | Header, Required | - |
| `body` | [`GetWorkGroupInput`](../../doc/models/get-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`GetWorkGroupOutput`](../../doc/models/get-work-group-output.md)

## Example Usage

```java
XAmzTarget29Enum xAmzTarget = XAmzTarget29Enum.ENUM_AMAZONATHENAGETWORKGROUP;
GetWorkGroupInput body = new GetWorkGroupInput.Builder(
    "WorkGroup8"
)
.build();


aPIController.getWorkGroupAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Import Notebook

Imports a single <code>ipynb</code> file to a Spark enabled workgroup. The maximum file size that can be imported is 10 megabytes. If an <code>ipynb</code> file with the same name already exists in the workgroup, throws an error.

```java
CompletableFuture<ImportNotebookOutput> importNotebookAsync(
    final XAmzTarget30Enum xAmzTarget,
    final ImportNotebookInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget30Enum`](../../doc/models/x-amz-target-30-enum.md) | Header, Required | - |
| `body` | [`ImportNotebookInput`](../../doc/models/import-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`ImportNotebookOutput`](../../doc/models/import-notebook-output.md)

## Example Usage

```java
XAmzTarget30Enum xAmzTarget = XAmzTarget30Enum.ENUM_AMAZONATHENAIMPORTNOTEBOOK;
ImportNotebookInput body = new ImportNotebookInput.Builder(
    "WorkGroup8",
    "Name6",
    "Payload2",
    NotebookType2Enum.IPYNB
)
.build();


aPIController.importNotebookAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Application DPU Sizes

Returns the supported DPU sizes for the supported application runtimes (for example, <code>Athena notebook version 1</code>).

```java
CompletableFuture<ListApplicationDPUSizesOutput> listApplicationDPUSizesAsync(
    final XAmzTarget31Enum xAmzTarget,
    final ListApplicationDPUSizesInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget31Enum`](../../doc/models/x-amz-target-31-enum.md) | Header, Required | - |
| `body` | [`ListApplicationDPUSizesInput`](../../doc/models/list-application-dpu-sizes-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListApplicationDPUSizesOutput`](../../doc/models/list-application-dpu-sizes-output.md)

## Example Usage

```java
XAmzTarget31Enum xAmzTarget = XAmzTarget31Enum.ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES;
ListApplicationDPUSizesInput body = new ListApplicationDPUSizesInput.Builder()
    .build();


aPIController.listApplicationDPUSizesAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Calculation Executions

Lists the calculations that have been submitted to a session in descending order. Newer calculations are listed first; older calculations are listed later.

```java
CompletableFuture<ListCalculationExecutionsResponse> listCalculationExecutionsAsync(
    final XAmzTarget32Enum xAmzTarget,
    final ListCalculationExecutionsRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget32Enum`](../../doc/models/x-amz-target-32-enum.md) | Header, Required | - |
| `body` | [`ListCalculationExecutionsRequest`](../../doc/models/list-calculation-executions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListCalculationExecutionsResponse`](../../doc/models/list-calculation-executions-response.md)

## Example Usage

```java
XAmzTarget32Enum xAmzTarget = XAmzTarget32Enum.ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS;
ListCalculationExecutionsRequest body = new ListCalculationExecutionsRequest.Builder(
    "SessionId2"
)
.build();


aPIController.listCalculationExecutionsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Data Catalogs

<p>Lists the data catalogs in the current Amazon Web Services account.</p> <note> <p>In the Athena console, data catalogs are listed as "data sources" on the <b>Data sources</b> page under the <b>Data source name</b> column.</p> </note>


```java
CompletableFuture<ListDataCatalogsOutput> listDataCatalogsAsync(
    final XAmzTarget33Enum xAmzTarget,
    final ListDataCatalogsInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget33Enum`](../../doc/models/x-amz-target-33-enum.md) | Header, Required | - |
| `body` | [`ListDataCatalogsInput`](../../doc/models/list-data-catalogs-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListDataCatalogsOutput`](../../doc/models/list-data-catalogs-output.md)

## Example Usage

```java
XAmzTarget33Enum xAmzTarget = XAmzTarget33Enum.ENUM_AMAZONATHENALISTDATACATALOGS;
ListDataCatalogsInput body = new ListDataCatalogsInput.Builder()
    .build();


aPIController.listDataCatalogsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Databases

Lists the databases in the specified data catalog.

```java
CompletableFuture<ListDatabasesOutput> listDatabasesAsync(
    final XAmzTarget34Enum xAmzTarget,
    final ListDatabasesInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget34Enum`](../../doc/models/x-amz-target-34-enum.md) | Header, Required | - |
| `body` | [`ListDatabasesInput`](../../doc/models/list-databases-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListDatabasesOutput`](../../doc/models/list-databases-output.md)

## Example Usage

```java
XAmzTarget34Enum xAmzTarget = XAmzTarget34Enum.ENUM_AMAZONATHENALISTDATABASES;
ListDatabasesInput body = new ListDatabasesInput.Builder(
    "CatalogName0"
)
.build();


aPIController.listDatabasesAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# List Engine Versions

Returns a list of engine versions that are available to choose from, including the Auto option.

```java
CompletableFuture<ListEngineVersionsOutput> listEngineVersionsAsync(
    final XAmzTarget35Enum xAmzTarget,
    final ListEngineVersionsInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget35Enum`](../../doc/models/x-amz-target-35-enum.md) | Header, Required | - |
| `body` | [`ListEngineVersionsInput`](../../doc/models/list-engine-versions-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListEngineVersionsOutput`](../../doc/models/list-engine-versions-output.md)

## Example Usage

```java
XAmzTarget35Enum xAmzTarget = XAmzTarget35Enum.ENUM_AMAZONATHENALISTENGINEVERSIONS;
ListEngineVersionsInput body = new ListEngineVersionsInput.Builder()
    .build();


aPIController.listEngineVersionsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Executors

Lists, in descending order, the executors that joined a session. Newer executors are listed first; older executors are listed later. The result can be optionally filtered by state.

```java
CompletableFuture<ListExecutorsResponse> listExecutorsAsync(
    final XAmzTarget36Enum xAmzTarget,
    final ListExecutorsRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget36Enum`](../../doc/models/x-amz-target-36-enum.md) | Header, Required | - |
| `body` | [`ListExecutorsRequest`](../../doc/models/list-executors-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListExecutorsResponse`](../../doc/models/list-executors-response.md)

## Example Usage

```java
XAmzTarget36Enum xAmzTarget = XAmzTarget36Enum.ENUM_AMAZONATHENALISTEXECUTORS;
ListExecutorsRequest body = new ListExecutorsRequest.Builder(
    "SessionId2"
)
.build();


aPIController.listExecutorsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Named Queries

<p>Provides a list of available query IDs only for queries saved in the specified workgroup. Requires that you have access to the specified workgroup. If a workgroup is not specified, lists the saved queries for the primary workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```java
CompletableFuture<ListNamedQueriesOutput> listNamedQueriesAsync(
    final XAmzTarget37Enum xAmzTarget,
    final ListNamedQueriesInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget37Enum`](../../doc/models/x-amz-target-37-enum.md) | Header, Required | - |
| `body` | [`ListNamedQueriesInput`](../../doc/models/list-named-queries-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListNamedQueriesOutput`](../../doc/models/list-named-queries-output.md)

## Example Usage

```java
XAmzTarget37Enum xAmzTarget = XAmzTarget37Enum.ENUM_AMAZONATHENALISTNAMEDQUERIES;
ListNamedQueriesInput body = new ListNamedQueriesInput.Builder()
    .build();


aPIController.listNamedQueriesAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Notebook Metadata

Displays the notebook files for the specified workgroup in paginated format.

```java
CompletableFuture<ListNotebookMetadataOutput> listNotebookMetadataAsync(
    final XAmzTarget38Enum xAmzTarget,
    final ListNotebookMetadataInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget38Enum`](../../doc/models/x-amz-target-38-enum.md) | Header, Required | - |
| `body` | [`ListNotebookMetadataInput`](../../doc/models/list-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`ListNotebookMetadataOutput`](../../doc/models/list-notebook-metadata-output.md)

## Example Usage

```java
XAmzTarget38Enum xAmzTarget = XAmzTarget38Enum.ENUM_AMAZONATHENALISTNOTEBOOKMETADATA;
ListNotebookMetadataInput body = new ListNotebookMetadataInput.Builder(
    "WorkGroup8"
)
.build();


aPIController.listNotebookMetadataAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Notebook Sessions

Lists, in descending order, the sessions that have been created in a notebook that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code> or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```java
CompletableFuture<ListNotebookSessionsResponse> listNotebookSessionsAsync(
    final XAmzTarget39Enum xAmzTarget,
    final ListNotebookSessionsRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget39Enum`](../../doc/models/x-amz-target-39-enum.md) | Header, Required | - |
| `body` | [`ListNotebookSessionsRequest`](../../doc/models/list-notebook-sessions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`ListNotebookSessionsResponse`](../../doc/models/list-notebook-sessions-response.md)

## Example Usage

```java
XAmzTarget39Enum xAmzTarget = XAmzTarget39Enum.ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS;
ListNotebookSessionsRequest body = new ListNotebookSessionsRequest.Builder(
    "NotebookId6"
)
.build();


aPIController.listNotebookSessionsAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Prepared Statements

Lists the prepared statements in the specified workgroup.

```java
CompletableFuture<ListPreparedStatementsOutput> listPreparedStatementsAsync(
    final XAmzTarget40Enum xAmzTarget,
    final ListPreparedStatementsInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget40Enum`](../../doc/models/x-amz-target-40-enum.md) | Header, Required | - |
| `body` | [`ListPreparedStatementsInput`](../../doc/models/list-prepared-statements-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListPreparedStatementsOutput`](../../doc/models/list-prepared-statements-output.md)

## Example Usage

```java
XAmzTarget40Enum xAmzTarget = XAmzTarget40Enum.ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS;
ListPreparedStatementsInput body = new ListPreparedStatementsInput.Builder(
    "WorkGroup8"
)
.build();


aPIController.listPreparedStatementsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Query Executions

<p>Provides a list of available query execution IDs for the queries in the specified workgroup. If a workgroup is not specified, returns a list of query execution IDs for the primary workgroup. Requires you to have access to the workgroup in which the queries ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```java
CompletableFuture<ListQueryExecutionsOutput> listQueryExecutionsAsync(
    final XAmzTarget41Enum xAmzTarget,
    final ListQueryExecutionsInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget41Enum`](../../doc/models/x-amz-target-41-enum.md) | Header, Required | - |
| `body` | [`ListQueryExecutionsInput`](../../doc/models/list-query-executions-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListQueryExecutionsOutput`](../../doc/models/list-query-executions-output.md)

## Example Usage

```java
XAmzTarget41Enum xAmzTarget = XAmzTarget41Enum.ENUM_AMAZONATHENALISTQUERYEXECUTIONS;
ListQueryExecutionsInput body = new ListQueryExecutionsInput.Builder()
    .build();


aPIController.listQueryExecutionsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Sessions

Lists the sessions in a workgroup that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code>, or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```java
CompletableFuture<ListSessionsResponse> listSessionsAsync(
    final XAmzTarget42Enum xAmzTarget,
    final ListSessionsRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget42Enum`](../../doc/models/x-amz-target-42-enum.md) | Header, Required | - |
| `body` | [`ListSessionsRequest`](../../doc/models/list-sessions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListSessionsResponse`](../../doc/models/list-sessions-response.md)

## Example Usage

```java
XAmzTarget42Enum xAmzTarget = XAmzTarget42Enum.ENUM_AMAZONATHENALISTSESSIONS;
ListSessionsRequest body = new ListSessionsRequest.Builder(
    "WorkGroup8"
)
.build();


aPIController.listSessionsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Table Metadata

Lists the metadata for the tables in the specified data catalog database.

```java
CompletableFuture<ListTableMetadataOutput> listTableMetadataAsync(
    final XAmzTarget43Enum xAmzTarget,
    final ListTableMetadataInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget43Enum`](../../doc/models/x-amz-target-43-enum.md) | Header, Required | - |
| `body` | [`ListTableMetadataInput`](../../doc/models/list-table-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListTableMetadataOutput`](../../doc/models/list-table-metadata-output.md)

## Example Usage

```java
XAmzTarget43Enum xAmzTarget = XAmzTarget43Enum.ENUM_AMAZONATHENALISTTABLEMETADATA;
ListTableMetadataInput body = new ListTableMetadataInput.Builder(
    "CatalogName0",
    "DatabaseName0"
)
.build();


aPIController.listTableMetadataAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# List Tags for Resource

Lists the tags associated with an Athena workgroup or data catalog resource.

```java
CompletableFuture<ListTagsForResourceOutput> listTagsForResourceAsync(
    final XAmzTarget44Enum xAmzTarget,
    final ListTagsForResourceInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget44Enum`](../../doc/models/x-amz-target-44-enum.md) | Header, Required | - |
| `body` | [`ListTagsForResourceInput`](../../doc/models/list-tags-for-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListTagsForResourceOutput`](../../doc/models/list-tags-for-resource-output.md)

## Example Usage

```java
XAmzTarget44Enum xAmzTarget = XAmzTarget44Enum.ENUM_AMAZONATHENALISTTAGSFORRESOURCE;
ListTagsForResourceInput body = new ListTagsForResourceInput.Builder(
    "ResourceARN4"
)
.build();


aPIController.listTagsForResourceAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Work Groups

Lists available workgroups for the account.

```java
CompletableFuture<ListWorkGroupsOutput> listWorkGroupsAsync(
    final XAmzTarget45Enum xAmzTarget,
    final ListWorkGroupsInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders,
    final String maxResults,
    final String nextToken)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget45Enum`](../../doc/models/x-amz-target-45-enum.md) | Header, Required | - |
| `body` | [`ListWorkGroupsInput`](../../doc/models/list-work-groups-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |
| `maxResults` | `String` | Query, Optional | Pagination limit |
| `nextToken` | `String` | Query, Optional | Pagination token |

## Response Type

**200**: Success

[`ListWorkGroupsOutput`](../../doc/models/list-work-groups-output.md)

## Example Usage

```java
XAmzTarget45Enum xAmzTarget = XAmzTarget45Enum.ENUM_AMAZONATHENALISTWORKGROUPS;
ListWorkGroupsInput body = new ListWorkGroupsInput.Builder()
    .build();


aPIController.listWorkGroupsAsync(xAmzTarget, body, null, null, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Start Calculation Execution

Submits calculations for execution within a session. You can supply the code to run as an inline code block within the request.

```java
CompletableFuture<StartCalculationExecutionResponse> startCalculationExecutionAsync(
    final XAmzTarget46Enum xAmzTarget,
    final StartCalculationExecutionRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget46Enum`](../../doc/models/x-amz-target-46-enum.md) | Header, Required | - |
| `body` | [`StartCalculationExecutionRequest`](../../doc/models/start-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`StartCalculationExecutionResponse`](../../doc/models/start-calculation-execution-response.md)

## Example Usage

```java
XAmzTarget46Enum xAmzTarget = XAmzTarget46Enum.ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION;
StartCalculationExecutionRequest body = new StartCalculationExecutionRequest.Builder(
    "SessionId2"
)
.build();


aPIController.startCalculationExecutionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Start Query Execution

Runs the SQL query statements contained in the <code>Query</code>. Requires you to have access to the workgroup in which the query ran. Running queries against an external catalog requires <a>GetDataCatalog</a> permission to the catalog. For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.

```java
CompletableFuture<StartQueryExecutionOutput> startQueryExecutionAsync(
    final XAmzTarget47Enum xAmzTarget,
    final StartQueryExecutionInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget47Enum`](../../doc/models/x-amz-target-47-enum.md) | Header, Required | - |
| `body` | [`StartQueryExecutionInput`](../../doc/models/start-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`StartQueryExecutionOutput`](../../doc/models/start-query-execution-output.md)

## Example Usage

```java
XAmzTarget47Enum xAmzTarget = XAmzTarget47Enum.ENUM_AMAZONATHENASTARTQUERYEXECUTION;
StartQueryExecutionInput body = new StartQueryExecutionInput.Builder(
    "QueryString8"
)
.build();


aPIController.startQueryExecutionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Start Session

Creates a session for running calculations within a workgroup. The session is ready when it reaches an <code>IDLE</code> state.

```java
CompletableFuture<StartSessionResponse> startSessionAsync(
    final XAmzTarget48Enum xAmzTarget,
    final StartSessionRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget48Enum`](../../doc/models/x-amz-target-48-enum.md) | Header, Required | - |
| `body` | [`StartSessionRequest`](../../doc/models/start-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`StartSessionResponse`](../../doc/models/start-session-response.md)

## Example Usage

```java
XAmzTarget48Enum xAmzTarget = XAmzTarget48Enum.ENUM_AMAZONATHENASTARTSESSION;
StartSessionRequest body = new StartSessionRequest.Builder(
    "WorkGroup8",
    new EngineConfiguration1.Builder(
        94
    )
    .build()
)
.build();


aPIController.startSessionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |
| 483 | SessionAlreadyExistsException | `ApiException` |
| 484 | TooManyRequestsException | `ApiException` |


# Stop Calculation Execution

<p>Requests the cancellation of a calculation. A <code>StopCalculationExecution</code> call on a calculation that is already in a terminal state (for example, <code>STOPPED</code>, <code>FAILED</code>, or <code>COMPLETED</code>) succeeds but has no effect.</p> <note> <p>Cancelling a calculation is done on a best effort basis. If a calculation cannot be cancelled, you can be charged for its completion. If you are concerned about being charged for a calculation that cannot be cancelled, consider terminating the session in which the calculation is running.</p> </note>


```java
CompletableFuture<StopCalculationExecutionResponse> stopCalculationExecutionAsync(
    final XAmzTarget49Enum xAmzTarget,
    final StopCalculationExecutionRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget49Enum`](../../doc/models/x-amz-target-49-enum.md) | Header, Required | - |
| `body` | [`StopCalculationExecutionRequest`](../../doc/models/stop-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`StopCalculationExecutionResponse`](../../doc/models/stop-calculation-execution-response.md)

## Example Usage

```java
XAmzTarget49Enum xAmzTarget = XAmzTarget49Enum.ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION;
StopCalculationExecutionRequest body = new StopCalculationExecutionRequest.Builder(
    "CalculationExecutionId8"
)
.build();


aPIController.stopCalculationExecutionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Stop Query Execution

<p>Stops a query execution. Requires you to have access to the workgroup in which the query ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```java
CompletableFuture<Object> stopQueryExecutionAsync(
    final XAmzTarget50Enum xAmzTarget,
    final StopQueryExecutionInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget50Enum`](../../doc/models/x-amz-target-50-enum.md) | Header, Required | - |
| `body` | [`StopQueryExecutionInput`](../../doc/models/stop-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget50Enum xAmzTarget = XAmzTarget50Enum.ENUM_AMAZONATHENASTOPQUERYEXECUTION;
StopQueryExecutionInput body = new StopQueryExecutionInput.Builder(
    "QueryExecutionId0"
)
.build();


aPIController.stopQueryExecutionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Tag Resource

Adds one or more tags to an Athena resource. A tag is a label that you assign to a resource. In Athena, a resource can be a workgroup or data catalog. Each tag consists of a key and an optional value, both of which you define. For example, you can use tags to categorize Athena workgroups or data catalogs by purpose, owner, or environment. Use a consistent set of tag keys to make it easier to search and filter workgroups or data catalogs in your account. For best practices, see <a href="https://docs.aws.amazon.com/whitepapers/latest/tagging-best-practices/tagging-best-practices.html">Tagging Best Practices</a>. Tag keys can be from 1 to 128 UTF-8 Unicode characters, and tag values can be from 0 to 256 UTF-8 Unicode characters. Tags can use letters and numbers representable in UTF-8, and the following characters: + - = . _ : / @. Tag keys and values are case-sensitive. Tag keys must be unique per resource. If you specify more than one tag, separate them by commas.

```java
CompletableFuture<Object> tagResourceAsync(
    final XAmzTarget51Enum xAmzTarget,
    final TagResourceInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget51Enum`](../../doc/models/x-amz-target-51-enum.md) | Header, Required | - |
| `body` | [`TagResourceInput`](../../doc/models/tag-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget51Enum xAmzTarget = XAmzTarget51Enum.ENUM_AMAZONATHENATAGRESOURCE;
TagResourceInput body = new TagResourceInput.Builder(
    "ResourceARN4",
    Arrays.asList(
        new Tag.Builder()
            .build()
    )
)
.build();


aPIController.tagResourceAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Terminate Session

Terminates an active session. A <code>TerminateSession</code> call on a session that is already inactive (for example, in a <code>FAILED</code>, <code>TERMINATED</code> or <code>TERMINATING</code> state) succeeds but has no effect. Calculations running in the session when <code>TerminateSession</code> is called are forcefully stopped, but may display as <code>FAILED</code> instead of <code>STOPPED</code>.

```java
CompletableFuture<TerminateSessionResponse> terminateSessionAsync(
    final XAmzTarget52Enum xAmzTarget,
    final TerminateSessionRequest body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget52Enum`](../../doc/models/x-amz-target-52-enum.md) | Header, Required | - |
| `body` | [`TerminateSessionRequest`](../../doc/models/terminate-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

[`TerminateSessionResponse`](../../doc/models/terminate-session-response.md)

## Example Usage

```java
XAmzTarget52Enum xAmzTarget = XAmzTarget52Enum.ENUM_AMAZONATHENATERMINATESESSION;
TerminateSessionRequest body = new TerminateSessionRequest.Builder(
    "SessionId2"
)
.build();


aPIController.terminateSessionAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Untag Resource

Removes one or more tags from a data catalog or workgroup resource.

```java
CompletableFuture<Object> untagResourceAsync(
    final XAmzTarget53Enum xAmzTarget,
    final UntagResourceInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget53Enum`](../../doc/models/x-amz-target-53-enum.md) | Header, Required | - |
| `body` | [`UntagResourceInput`](../../doc/models/untag-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget53Enum xAmzTarget = XAmzTarget53Enum.ENUM_AMAZONATHENAUNTAGRESOURCE;
UntagResourceInput body = new UntagResourceInput.Builder(
    "ResourceARN4",
    Arrays.asList(
        "TagKeys9",
        "TagKeys0"
    )
)
.build();


aPIController.untagResourceAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Update Data Catalog

Updates the data catalog that has the specified name.

```java
CompletableFuture<Object> updateDataCatalogAsync(
    final XAmzTarget54Enum xAmzTarget,
    final UpdateDataCatalogInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget54Enum`](../../doc/models/x-amz-target-54-enum.md) | Header, Required | - |
| `body` | [`UpdateDataCatalogInput`](../../doc/models/update-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget54Enum xAmzTarget = XAmzTarget54Enum.ENUM_AMAZONATHENAUPDATEDATACATALOG;
UpdateDataCatalogInput body = new UpdateDataCatalogInput.Builder(
    "Name6",
    DataCatalogType3Enum.HIVE
)
.build();


aPIController.updateDataCatalogAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Update Named Query

Updates a <a>NamedQuery</a> object. The database or workgroup cannot be updated.

```java
CompletableFuture<Object> updateNamedQueryAsync(
    final XAmzTarget55Enum xAmzTarget,
    final UpdateNamedQueryInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget55Enum`](../../doc/models/x-amz-target-55-enum.md) | Header, Required | - |
| `body` | [`UpdateNamedQueryInput`](../../doc/models/update-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget55Enum xAmzTarget = XAmzTarget55Enum.ENUM_AMAZONATHENAUPDATENAMEDQUERY;
UpdateNamedQueryInput body = new UpdateNamedQueryInput.Builder(
    "NamedQueryId6",
    "Name6",
    "QueryString8"
)
.build();


aPIController.updateNamedQueryAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Update Notebook

Updates the contents of a Spark notebook.

```java
CompletableFuture<Object> updateNotebookAsync(
    final XAmzTarget56Enum xAmzTarget,
    final UpdateNotebookInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget56Enum`](../../doc/models/x-amz-target-56-enum.md) | Header, Required | - |
| `body` | [`UpdateNotebookInput`](../../doc/models/update-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget56Enum xAmzTarget = XAmzTarget56Enum.ENUM_AMAZONATHENAUPDATENOTEBOOK;
UpdateNotebookInput body = new UpdateNotebookInput.Builder(
    "NotebookId6",
    "Payload2",
    NotebookType2Enum.IPYNB
)
.build();


aPIController.updateNotebookAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Update Notebook Metadata

Updates the metadata for a notebook.

```java
CompletableFuture<Object> updateNotebookMetadataAsync(
    final XAmzTarget57Enum xAmzTarget,
    final UpdateNotebookMetadataInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget57Enum`](../../doc/models/x-amz-target-57-enum.md) | Header, Required | - |
| `body` | [`UpdateNotebookMetadataInput`](../../doc/models/update-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget57Enum xAmzTarget = XAmzTarget57Enum.ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA;
UpdateNotebookMetadataInput body = new UpdateNotebookMetadataInput.Builder(
    "NotebookId6",
    "Name6"
)
.build();


aPIController.updateNotebookMetadataAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Update Prepared Statement

Updates a prepared statement.

```java
CompletableFuture<Object> updatePreparedStatementAsync(
    final XAmzTarget58Enum xAmzTarget,
    final UpdatePreparedStatementInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget58Enum`](../../doc/models/x-amz-target-58-enum.md) | Header, Required | - |
| `body` | [`UpdatePreparedStatementInput`](../../doc/models/update-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget58Enum xAmzTarget = XAmzTarget58Enum.ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT;
UpdatePreparedStatementInput body = new UpdatePreparedStatementInput.Builder(
    "StatementName4",
    "WorkGroup8",
    "QueryStatement8"
)
.build();


aPIController.updatePreparedStatementAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Update Work Group

Updates the workgroup with the specified name. The workgroup's name cannot be changed. Only <code>ConfigurationUpdates</code> can be specified.

```java
CompletableFuture<Object> updateWorkGroupAsync(
    final XAmzTarget59Enum xAmzTarget,
    final UpdateWorkGroupInput body,
    final String xAmzContentSha256,
    final String xAmzDate,
    final String xAmzAlgorithm,
    final String xAmzCredential,
    final String xAmzSecurityToken,
    final String xAmzSignature,
    final String xAmzSignedHeaders)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`XAmzTarget59Enum`](../../doc/models/x-amz-target-59-enum.md) | Header, Required | - |
| `body` | [`UpdateWorkGroupInput`](../../doc/models/update-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `String` | Header, Optional | - |
| `xAmzDate` | `String` | Header, Optional | - |
| `xAmzAlgorithm` | `String` | Header, Optional | - |
| `xAmzCredential` | `String` | Header, Optional | - |
| `xAmzSecurityToken` | `String` | Header, Optional | - |
| `xAmzSignature` | `String` | Header, Optional | - |
| `xAmzSignedHeaders` | `String` | Header, Optional | - |

## Response Type

**200**: Success

`Object`

## Example Usage

```java
XAmzTarget59Enum xAmzTarget = XAmzTarget59Enum.ENUM_AMAZONATHENAUPDATEWORKGROUP;
UpdateWorkGroupInput body = new UpdateWorkGroupInput.Builder(
    "WorkGroup8"
)
.build();


aPIController.updateWorkGroupAsync(xAmzTarget, body, null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |

