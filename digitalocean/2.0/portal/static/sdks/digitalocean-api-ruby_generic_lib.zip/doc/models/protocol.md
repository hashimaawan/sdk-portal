
# Protocol

The type of traffic to be allowed. This may be one of `tcp`, `udp`, or `icmp`.

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |

## Example

```ruby
protocol = Protocol::TCP
```

