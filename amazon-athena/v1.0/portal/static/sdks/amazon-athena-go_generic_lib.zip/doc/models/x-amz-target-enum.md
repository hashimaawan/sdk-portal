
# X Amz Target Enum

## Enumeration

`XAmzTargetEnum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget := models.XAmzTargetEnum_ENUMAMAZONATHENABATCHGETNAMEDQUERY

}
```

