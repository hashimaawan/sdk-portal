
# X Amz Target 53 Enum

## Enumeration

`XAmzTarget53Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUNTAGRESOURCE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget53Enum;

XAmzTarget53Enum xAmzTarget53 = XAmzTarget53Enum.ENUM_AMAZONATHENAUNTAGRESOURCE;
```

