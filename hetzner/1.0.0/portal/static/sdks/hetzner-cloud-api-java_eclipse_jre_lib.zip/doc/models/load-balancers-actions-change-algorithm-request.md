
# Load Balancers Actions Change Algorithm Request

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`Type39`](../../doc/models/type-39.md) | Required | Algorithm of the Load Balancer | Type39 getType() | setType(Type39 type) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.LoadBalancersActionsChangeAlgorithmRequest;
import cloud.hetzner.api.models.Type39;
import java.io.IOException;

LoadBalancersActionsChangeAlgorithmRequest loadBalancersActionsChangeAlgorithmRequest = new LoadBalancersActionsChangeAlgorithmRequest.Builder(
    Type39.ROUND_ROBIN
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

