
# Create Presigned Notebook Url Request

## Structure

`CreatePresignedNotebookUrlRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    createPresignedNotebookUrlRequest := models.CreatePresignedNotebookUrlRequest{
        SessionId:            "SessionId0",
    }

}
```

