
# X Amz Target 51

## Enumeration

`XAmzTarget51`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATAGRESOURCE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget51;

$xAmzTarget51 = XAmzTarget51::ENUM_AMAZONATHENATAGRESOURCE;
```

