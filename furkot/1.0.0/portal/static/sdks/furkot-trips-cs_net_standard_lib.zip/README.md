
# Getting Started with Furkot Trips

## Introduction

Furkot provides Rest API to access user trip data.
Using Furkot API an application can list user trips and display stops for a specific trip.
Furkot API uses OAuth2 protocol to authorize applications to access data on behalf of users.

Furkot API description: [https://help.furkot.com/widgets/furkot-api.html](https://help.furkot.com/widgets/furkot-api.html)

## Building

The generated code uses the Newtonsoft Json.NET NuGet Package. If the automatic NuGet package restore is enabled, these dependencies will be installed automatically. Therefore, you will need internet access for build.

* Open the solution (FurkotTrips.sln) file.

Invoke the build process using Ctrl + Shift + B shortcut key or using the Build menu as shown below.

The build process generates a portable class library, which can be used like a normal class library. More information on how to use can be found at the MSDN Portable Class Libraries documentation.

The supported version is **.NET Standard 2.0**. For checking compatibility of your .NET implementation with the generated library, [click here](https://dotnet.microsoft.com/en-us/platform/dotnet-standard#versions).

## Installation

The following section explains how to use the FurkotTrips.Standard library in a new project.

### 1. Starting a new project

For starting a new project, right click on the current solution from the solution explorer and choose `Add -> New Project`.

![Add a new project in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Furkot%20Trips-CSharp&workspaceName=FurkotTrips&projectName=FurkotTrips.Standard&rootNamespace=FurkotTrips.Standard&step=addProject)

Next, choose `Console Application`, provide `TestConsoleProject` as the project name and click OK.

![Create a new Console Application in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Furkot%20Trips-CSharp&workspaceName=FurkotTrips&projectName=FurkotTrips.Standard&rootNamespace=FurkotTrips.Standard&step=createProject)

### 2. Set as startup project

The new console project is the entry point for the eventual execution. This requires us to set the `TestConsoleProject` as the start-up project. To do this, right-click on the `TestConsoleProject` and choose `Set as StartUp Project` form the context menu.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Furkot%20Trips-CSharp&workspaceName=FurkotTrips&projectName=FurkotTrips.Standard&rootNamespace=FurkotTrips.Standard&step=setStartup)

### 3. Add reference of the library project

In order to use the `FurkotTrips.Standard` library in the new project, first we must add a project reference to the `TestConsoleProject`. First, right click on the `References` node in the solution explorer and click `Add Reference...`

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Furkot%20Trips-CSharp&workspaceName=FurkotTrips&projectName=FurkotTrips.Standard&rootNamespace=FurkotTrips.Standard&step=addReference)

Next, a window will be displayed where we must set the `checkbox` on `FurkotTrips.Standard` and click `OK`. By doing this, we have added a reference of the `FurkotTrips.Standard` project into the new `TestConsoleProject`.

![Creating a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Furkot%20Trips-CSharp&workspaceName=FurkotTrips&projectName=FurkotTrips.Standard&rootNamespace=FurkotTrips.Standard&step=createReference)

### 4. Write sample code

Once the `TestConsoleProject` is created, a file named `Program.cs` will be visible in the solution explorer with an empty `Main` method. This is the entry point for the execution of the entire solution. Here, you can add code to initialize the client library and acquire the instance of a Controller class. Sample code to initialize the client library and using Controller methods is given in the subsequent sections.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Furkot%20Trips-CSharp&workspaceName=FurkotTrips&projectName=FurkotTrips.Standard&rootNamespace=FurkotTrips.Standard&step=addCode)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.Production`** |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| FurkotAuthAccessCodeCredentials | [`FurkotAuthAccessCodeCredentials`](doc/auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |
| FurkotAuthImplicitCredentials | [`FurkotAuthImplicitCredentials`](doc/auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

### Code-Based Initialization

```csharp
using FurkotTrips.Standard;
using FurkotTrips.Standard.Authentication;
using FurkotTrips.Standard.Models;
using System.Collections.Generic;

namespace ConsoleApp;

FurkotTripsClient client = new FurkotTripsClient.Builder()
    .FurkotAuthAccessCodeCredentials(
        new FurkotAuthAccessCodeModel.Builder(
            "OAuthClientId",
            "OAuthClientSecret",
            "OAuthRedirectUri"
        )
        .OAuthScopes(
            new List<OAuthScopeFurkotAuthAccessCodeEnum>
            {
                OAuthScopeFurkotAuthAccessCodeEnum.Readtrips,
            })
        .Build())
    .FurkotAuthImplicitCredentials(
        new FurkotAuthImplicitModel.Builder(
            "OAuthClientId",
            "OAuthRedirectUri"
        )
        .OAuthScopes(
            new List<OAuthScopeFurkotAuthImplicitEnum>
            {
                OAuthScopeFurkotAuthImplicitEnum.Readtrips,
            })
        .Build())
    .HttpClientConfig(httpClientConfig =>
        httpClientConfig.Timeout(TimeSpan.FromSeconds(100)))
    .Environment(FurkotTrips.Standard.Environment.Production)
    .Build();
```

### Configuration-Based Initialization

```csharp
using FurkotTrips.Standard;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp;

// Build the IConfiguration using .NET conventions (JSON, environment, etc.)
var configuration = new ConfigurationBuilder()
    .AddJsonFile("config.json")
    .AddEnvironmentVariables() // [optional] read environment variables
    .Build();

// Instantiate your SDK and configure it from IConfiguration
var client = FurkotTripsClient
    .FromConfiguration(configuration.GetSection("FurkotTrips"));
```

See the [Configuration-Based Initialization](doc/configuration-based-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| Production | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`furkot_auth_access_code (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)
* [`furkot_auth_implicit (OAuth 2 Implicit Grant)`](doc/auth/oauth-2-implicit-grant.md)

## List of APIs

* [API](doc/controllers/api.md)

## SDK Infrastructure

### Configuration

* [Configuration-Based Initialization](doc/configuration-based-initialization.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfigurationBuilder](doc/http-client-configuration-builder.md)
* [ProxyConfigurationBuilder](doc/proxy-configuration-builder.md)

### HTTP

* [HttpCallback](doc/http-callback.md)
* [HttpContext](doc/http-context.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)

### Utilities

* [ApiException](doc/api-exception.md)
* [ApiHelper](doc/api-helper.md)
* [CustomDateTimeConverter](doc/custom-date-time-converter.md)
* [UnixDateTimeConverter](doc/unix-date-time-converter.md)

