
# Server Types

The Server types the Datacenter can handle

## Structure

`ServerTypes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `available` | `float[]` | Required | IDs of Server types that are supported and for which the Datacenter has enough resources left | getAvailable(): array | setAvailable(array available): void |
| `availableForMigration` | `float[]` | Required | IDs of Server types that are supported and for which the Datacenter has enough resources left | getAvailableForMigration(): array | setAvailableForMigration(array availableForMigration): void |
| `supported` | `float[]` | Required | IDs of Server types that are supported in the Datacenter | getSupported(): array | setSupported(array supported): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ServerTypesBuilder;

$serverTypes = ServerTypesBuilder::init(
    [
        1,
        2,
        3
    ],
    [
        1,
        2,
        3
    ],
    [
        1,
        2,
        3
    ]
)->build();
```

