
# Get Work Group Input

*This model accepts additional fields of type Object.*

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_work_group_input = GetWorkGroupInput.new(
  work_group: 'WorkGroup0',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

