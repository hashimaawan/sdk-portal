
# Calculation Execution State

## Enumeration

`CalculationExecutionState`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Queued` |
| `Running` |
| `Canceling` |
| `Canceled` |
| `Completed` |
| `Failed` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    calculationExecutionState := models.CalculationExecutionState_Completed

}
```

