
# Query Execution Status

The completion date, current state, submission time, and state change reason (if applicable) for the query execution.

## Structure

`QueryExecutionStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`QueryExecutionState1Enum`](../../doc/models/query-execution-state-1-enum.md) | Optional | - |
| `state_change_reason` | `str` | Optional | - |
| `submission_date_time` | `datetime` | Optional | - |
| `completion_date_time` | `datetime` | Optional | - |
| `athena_error` | [`AthenaError2`](../../doc/models/athena-error-2.md) | Optional | - |

## Example

```python
import dateutil.parser

from amazonathena.models.athena_error_2 import AthenaError2
from amazonathena.models.query_execution_state_1_enum import QueryExecutionState1Enum
from amazonathena.models.query_execution_status import QueryExecutionStatus

query_execution_status = QueryExecutionStatus(
    state=QueryExecutionState1Enum.QUEUED,
    state_change_reason='StateChangeReason8',
    submission_date_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
    completion_date_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
    athena_error=AthenaError2(
        error_category=3,
        error_type=128,
        retryable=False,
        error_message='ErrorMessage8'
    )
)
```

