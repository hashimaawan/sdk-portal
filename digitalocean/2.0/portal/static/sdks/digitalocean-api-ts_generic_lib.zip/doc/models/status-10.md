
# Status 10

An object containing a `state` attribute whose value is set to a string indicating the current status of the node.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Status10`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`State1 \| undefined`](../../doc/models/state-1.md) | Optional | A string indicating the current status of the node. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { State1, Status10 } from 'digitalocean-apilib';

const status10: Status10 = {
  state: State1.Provisioning,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

