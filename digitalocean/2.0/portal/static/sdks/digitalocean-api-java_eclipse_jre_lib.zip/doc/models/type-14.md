
# Type 14

## Enumeration

`Type14`

## Fields

| Name |
|  --- |
| `APPLICATION` |
| `DISTRIBUTION` |

## Example

```java
import com.digitalocean.api.models.Type14;

Type14 type14 = Type14.APPLICATION;
```

