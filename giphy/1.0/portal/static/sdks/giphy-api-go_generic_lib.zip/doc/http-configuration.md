
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `0` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`giphyapiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `giphyapi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "giphyapi"
    "net/http"
)

func main() {
    httpConfiguration := giphyapi.CreateHttpConfiguration(
        giphyapi.WithTimeout(0),
        giphyapi.WithTransport(http.DefaultTransport),
        giphyapi.WithRetryConfiguration(giphyapi.DefaultRetryConfiguration()),
    )
}
```

