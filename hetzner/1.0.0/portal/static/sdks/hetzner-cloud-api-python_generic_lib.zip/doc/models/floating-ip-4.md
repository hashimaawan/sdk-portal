
# Floating Ip 4

The cost of one Floating IP per month

*This model accepts additional fields of type Any.*

## Structure

`FloatingIp4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price_monthly` | [`PriceMonthly6`](../../doc/models/price-monthly-6.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.floating_ip_4 import FloatingIp4
from hetznercloudapi.models.price_monthly_6 import PriceMonthly6

floating_ip_4 = FloatingIp4(
    price_monthly=PriceMonthly6(
        gross='1.1900000000000000',
        net='1.0000000000',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

