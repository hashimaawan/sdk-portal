
# Protocol

The type of traffic to be allowed. This may be one of `tcp`, `udp`, or `icmp`.

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |

## Example

```java
import com.digitalocean.api.models.Protocol;

Protocol protocol = Protocol.TCP;
```

