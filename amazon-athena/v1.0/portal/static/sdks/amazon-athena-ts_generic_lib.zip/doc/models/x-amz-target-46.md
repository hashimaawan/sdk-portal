
# X Amz Target 46

## Enumeration

`XAmzTarget46`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartCalculationExecution` |

## Example

```ts
import { XAmzTarget46 } from 'amazon-athenalib';

const xAmzTarget46 = XAmzTarget46.EnumAmazonAthenaStartCalculationExecution;
```

