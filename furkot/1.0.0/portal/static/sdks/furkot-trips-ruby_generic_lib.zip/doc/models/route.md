
# Route

route leading to the stop

## Structure

`Route`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `distance` | `Integer` | Optional | route distance in meters |
| `duration` | `Integer` | Optional | route duration in seconds |
| `mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Optional | travel mode |
| `polyline` | `String` | Optional | route path compatible with Google polyline encoding algorithm |

## Example

```ruby
route = Route.new(
  134,
  168,
  ModeEnum::CAR,
  'polyline0'
)
```

