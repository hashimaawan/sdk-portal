
# Type Enum

Type of the gif. By default, this is almost always gif

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `Gif` |

## Example

```ts
import { TypeEnum } from 'giphy-apilib';

const type = TypeEnum.Gif;
```

