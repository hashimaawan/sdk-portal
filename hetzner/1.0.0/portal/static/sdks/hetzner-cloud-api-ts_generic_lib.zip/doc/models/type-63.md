
# Type 63

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63`

## Fields

| Name |
|  --- |
| `Snapshot` |
| `Backup` |

## Example

```ts
import { Type63 } from 'hetzner-cloud-apilib';

const type63 = Type63.Snapshot;
```

