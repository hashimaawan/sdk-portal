
# Load Balancer Target Server

Server where the traffic should be routed through

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the Server |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
load_balancer_target_server = LoadBalancerTargetServer.new(
  id: 80,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

