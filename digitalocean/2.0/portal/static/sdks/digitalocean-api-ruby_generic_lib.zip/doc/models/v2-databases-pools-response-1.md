
# V2 Databases Pools Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesPoolsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pool` | [`Pool`](../../doc/models/pool.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_pools_response1 = V2DatabasesPoolsResponse1.new(
  pool: Pool.new(
    db: 'defaultdb',
    mode: 'transaction',
    name: 'backend-pool',
    size: 10,
    connection: Connection.new(
      database: 'database2',
      host: 'host0',
      password: 'password2',
      port: 174,
      ssl: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    private_connection: PrivateConnection.new(
      database: 'database4',
      host: 'host4',
      password: 'password8',
      port: 228,
      ssl: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    user: 'doadmin',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

