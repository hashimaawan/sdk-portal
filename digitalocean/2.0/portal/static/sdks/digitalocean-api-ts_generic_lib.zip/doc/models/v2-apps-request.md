
# V2 Apps Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `projectId` | `string \| undefined` | Optional | The ID of the project the app should be assigned to. If omitted, it will be assigned to your default project. |
| `spec` | [`AppSpec`](../../doc/models/app-spec.md) | Required | The desired configuration of an application. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Engine,
  MinimumTlsVersion,
  Operator,
  Region1,
  Rule,
  Scope,
  Type1,
  Type2,
  V2AppsRequest,
  Window,
} from 'digitalocean-apilib';

const v2AppsRequest: V2AppsRequest = {
  spec: {
    name: 'web-app-01',
    databases: [
      {
        name: 'name6',
        clusterName: 'cluster_name8',
        dbName: 'db_name0',
        dbUser: 'db_user8',
        engine: Engine.Pg,
        production: false,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    domains: [
      {
        domain: 'domain6',
        minimumTlsVersion: MinimumTlsVersion.Enum12,
        type: Type1.Primary,
        wildcard: false,
        zone: 'zone2',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        domain: 'domain6',
        minimumTlsVersion: MinimumTlsVersion.Enum12,
        type: Type1.Primary,
        wildcard: false,
        zone: 'zone2',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    functions: [
      {
        name: 'name4',
        alerts: [
          {
            disabled: false,
            operator: Operator.LessThan,
            rule: Rule.MemUtilization,
            value: 12.58,
            window: Window.ThirtyMinutes,
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          }
        ],
        cors: {
          allowCredentials: false,
          allowHeaders: [
            'allow_headers9',
            'allow_headers0'
          ],
          allowMethods: [
            'allow_methods8',
            'allow_methods9',
            'allow_methods0'
          ],
          allowOrigins: [
            {}
          ],
          exposeHeaders: [
            'expose_headers2'
          ],
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        envs: [
          {
            key: 'key2',
            scope: Scope.Unset,
            type: Type2.General,
            value: 'value4',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          {
            key: 'key2',
            scope: Scope.Unset,
            type: Type2.General,
            value: 'value4',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          {
            key: 'key2',
            scope: Scope.Unset,
            type: Type2.General,
            value: 'value4',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          }
        ],
        git: {
          branch: 'branch8',
          repoCloneUrl: 'repo_clone_url8',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        github: {
          branch: 'branch4',
          deployOnPush: false,
          repo: 'repo6',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    jobs: [
      {
        name: 'name4',
        buildCommand: 'build_command8',
        dockerfilePath: 'dockerfile_path6',
        environmentSlug: 'environment_slug2',
        envs: [
          {
            key: 'key2',
            scope: Scope.Unset,
            type: Type2.General,
            value: 'value4',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          {
            key: 'key2',
            scope: Scope.Unset,
            type: Type2.General,
            value: 'value4',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          },
          {
            key: 'key2',
            scope: Scope.Unset,
            type: Type2.General,
            value: 'value4',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          }
        ],
        git: {
          branch: 'branch8',
          repoCloneUrl: 'repo_clone_url8',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    region: Region1.Nyc,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  projectId: 'project_id4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

