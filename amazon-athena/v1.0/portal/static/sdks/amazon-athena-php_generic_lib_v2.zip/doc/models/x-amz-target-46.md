
# X Amz Target 46

## Enumeration

`XAmzTarget46`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget46;

$xAmzTarget46 = XAmzTarget46::ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION;
```

