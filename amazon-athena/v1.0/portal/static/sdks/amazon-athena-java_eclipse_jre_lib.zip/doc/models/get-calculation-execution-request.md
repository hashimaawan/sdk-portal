
# Get Calculation Execution Request

## Structure

`GetCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CalculationExecutionId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | String getCalculationExecutionId() | setCalculationExecutionId(String calculationExecutionId) |

## Example

```java
import com.amazonaws.useast1.athena.models.GetCalculationExecutionRequest;

GetCalculationExecutionRequest getCalculationExecutionRequest = new GetCalculationExecutionRequest.Builder(
    "CalculationExecutionId2"
)
.build();
```

