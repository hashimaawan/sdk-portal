
# Athena Error 2

## Structure

`AthenaError2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_category` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 3` |
| `error_type` | `Integer` | Optional | **Constraints**: `>= 0`, `<= 9999` |
| `retryable` | `TrueClass \| FalseClass` | Optional | - |
| `error_message` | `String` | Optional | - |

## Example

```ruby
athena_error2 = AthenaError2.new(
  3,
  44,
  false,
  'ErrorMessage4'
)
```

