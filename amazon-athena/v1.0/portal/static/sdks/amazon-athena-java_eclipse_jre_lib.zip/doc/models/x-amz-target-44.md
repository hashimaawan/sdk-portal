
# X Amz Target 44

## Enumeration

`XAmzTarget44`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget44;

XAmzTarget44 xAmzTarget44 = XAmzTarget44.ENUM_AMAZONATHENALISTTAGSFORRESOURCE;
```

