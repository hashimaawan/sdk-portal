
# Type 21

The volume action to initiate.

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `ATTACH` |
| `DETACH` |
| `RESIZE` |

## Example

```php
use DigitalOceanApiLib\Models\Type21;

$type21 = Type21::DETACH;
```

