
# Servers Actions Enable Rescue Request

## Structure

`ServersActionsEnableRescueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SshKeys` | `[]int` | Optional | Array of SSH key IDs which should be injected into the rescue system. |
| `Type` | [`*models.Type65Enum`](../../doc/models/type-65-enum.md) | Optional | Type of rescue system to boot (default: `linux64`) |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    serversActionsEnableRescueRequest := models.ServersActionsEnableRescueRequest{
        SshKeys:              []int{
            2323,
        },
        Type:                 models.ToPointer(models.Type65Enum_LINUX64),
    }

}
```

