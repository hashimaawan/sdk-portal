
# Type 17

Floating IP type

## Enumeration

`Type17`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type17 } from 'hetzner-cloud-apilib';

const type17 = Type17.Ipv4;
```

