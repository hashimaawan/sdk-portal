
# X Amz Target 53 Enum

## Enumeration

`XAmzTarget53Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUNTAGRESOURCE` |

## Example

```ruby
x_amz_target53 = XAmzTarget53Enum::ENUM_AMAZONATHENAUNTAGRESOURCE
```

