# API

```ruby
client_controller = client.client
```

## Class Name

`APIController`

## Methods

* [Allstarballotpredictor GET](../../doc/controllers/api.md#allstarballotpredictor-get)
* [Boxscore GET](../../doc/controllers/api.md#boxscore-get)
* [Boxscoreadvanced GET](../../doc/controllers/api.md#boxscoreadvanced-get)
* [Boxscoreadvancedv 2 GET](../../doc/controllers/api.md#boxscoreadvancedv-2-get)
* [Boxscorefourfactors GET](../../doc/controllers/api.md#boxscorefourfactors-get)
* [Boxscorefourfactorsv 2 GET](../../doc/controllers/api.md#boxscorefourfactorsv-2-get)
* [Boxscoremisc GET](../../doc/controllers/api.md#boxscoremisc-get)
* [Boxscoremiscv 2 GET](../../doc/controllers/api.md#boxscoremiscv-2-get)
* [Boxscoreplayertrackv 2 GET](../../doc/controllers/api.md#boxscoreplayertrackv-2-get)
* [Boxscorescoring GET](../../doc/controllers/api.md#boxscorescoring-get)
* [Boxscorescoringv 2 GET](../../doc/controllers/api.md#boxscorescoringv-2-get)
* [Boxscoresummaryv 2 GET](../../doc/controllers/api.md#boxscoresummaryv-2-get)
* [Boxscoretraditionalv 2 GET](../../doc/controllers/api.md#boxscoretraditionalv-2-get)
* [Boxscoreusage GET](../../doc/controllers/api.md#boxscoreusage-get)
* [Boxscoreusagev 2 GET](../../doc/controllers/api.md#boxscoreusagev-2-get)
* [Common Team Years GET](../../doc/controllers/api.md#common-team-years-get)
* [Commonallplayers GET](../../doc/controllers/api.md#commonallplayers-get)
* [Commonplayerinfo GET](../../doc/controllers/api.md#commonplayerinfo-get)
* [Commonplayoffseries GET](../../doc/controllers/api.md#commonplayoffseries-get)
* [Commonteamroster GET](../../doc/controllers/api.md#commonteamroster-get)
* [Draftcombinedrillresults GET](../../doc/controllers/api.md#draftcombinedrillresults-get)
* [Draftcombinenonstationaryshooting GET](../../doc/controllers/api.md#draftcombinenonstationaryshooting-get)
* [Draftcombineplayeranthro GET](../../doc/controllers/api.md#draftcombineplayeranthro-get)
* [Draftcombinespotshooting GET](../../doc/controllers/api.md#draftcombinespotshooting-get)
* [Draftcombinestats GET](../../doc/controllers/api.md#draftcombinestats-get)
* [Drafthistory GET](../../doc/controllers/api.md#drafthistory-get)
* [Franchisehistory GET](../../doc/controllers/api.md#franchisehistory-get)
* [Homepageleaders GET](../../doc/controllers/api.md#homepageleaders-get)
* [Homepagev 2 GET](../../doc/controllers/api.md#homepagev-2-get)
* [Leaderstiles GET](../../doc/controllers/api.md#leaderstiles-get)
* [Leaguedashlineups GET](../../doc/controllers/api.md#leaguedashlineups-get)
* [Leaguedashplayerbiostats GET](../../doc/controllers/api.md#leaguedashplayerbiostats-get)
* [Leaguedashplayerclutch GET](../../doc/controllers/api.md#leaguedashplayerclutch-get)
* [Leaguedashplayerptshot GET](../../doc/controllers/api.md#leaguedashplayerptshot-get)
* [Leaguedashplayershotlocations GET](../../doc/controllers/api.md#leaguedashplayershotlocations-get)
* [Leaguedashplayerstats GET](../../doc/controllers/api.md#leaguedashplayerstats-get)
* [Leaguedashptdefend GET](../../doc/controllers/api.md#leaguedashptdefend-get)
* [Leaguedashptteamdefend GET](../../doc/controllers/api.md#leaguedashptteamdefend-get)
* [Leaguedashteamclutch GET](../../doc/controllers/api.md#leaguedashteamclutch-get)
* [Leaguedashteamptshot GET](../../doc/controllers/api.md#leaguedashteamptshot-get)
* [Leaguedashteamshotlocations GET](../../doc/controllers/api.md#leaguedashteamshotlocations-get)
* [Leaguedashteamstats GET](../../doc/controllers/api.md#leaguedashteamstats-get)
* [Leagueleaders GET](../../doc/controllers/api.md#leagueleaders-get)
* [Playbyplay GET](../../doc/controllers/api.md#playbyplay-get)
* [Playbyplayv 2 GET](../../doc/controllers/api.md#playbyplayv-2-get)
* [Playercareerstats GET](../../doc/controllers/api.md#playercareerstats-get)
* [Playercompare GET](../../doc/controllers/api.md#playercompare-get)
* [Playerdashboardbyclutch GET](../../doc/controllers/api.md#playerdashboardbyclutch-get)
* [Playerdashboardbygamesplits GET](../../doc/controllers/api.md#playerdashboardbygamesplits-get)
* [Playerdashboardbygeneralsplits GET](../../doc/controllers/api.md#playerdashboardbygeneralsplits-get)
* [Playerdashboardbylastngames GET](../../doc/controllers/api.md#playerdashboardbylastngames-get)
* [Playerdashboardbyopponent GET](../../doc/controllers/api.md#playerdashboardbyopponent-get)
* [Playerdashboardbyshootingsplits GET](../../doc/controllers/api.md#playerdashboardbyshootingsplits-get)
* [Playerdashboardbyteamperformance GET](../../doc/controllers/api.md#playerdashboardbyteamperformance-get)
* [Playerdashboardbyyearoveryear GET](../../doc/controllers/api.md#playerdashboardbyyearoveryear-get)
* [Playerdashptpass GET](../../doc/controllers/api.md#playerdashptpass-get)
* [Playerdashptreb GET](../../doc/controllers/api.md#playerdashptreb-get)
* [Playerdashptreboundlogs GET](../../doc/controllers/api.md#playerdashptreboundlogs-get)
* [Playerdashptshotdefend GET](../../doc/controllers/api.md#playerdashptshotdefend-get)
* [Playerdashptshotlog GET](../../doc/controllers/api.md#playerdashptshotlog-get)
* [Playerdashptshots GET](../../doc/controllers/api.md#playerdashptshots-get)
* [Playergamelog GET](../../doc/controllers/api.md#playergamelog-get)
* [Playerprofile GET](../../doc/controllers/api.md#playerprofile-get)
* [Playerprofilev 2 GET](../../doc/controllers/api.md#playerprofilev-2-get)
* [Playersvsplayers GET](../../doc/controllers/api.md#playersvsplayers-get)
* [Playervsplayer GET](../../doc/controllers/api.md#playervsplayer-get)
* [Playoffpicture GET](../../doc/controllers/api.md#playoffpicture-get)
* [Scoreboard GET](../../doc/controllers/api.md#scoreboard-get)
* [Scoreboard V2 GET](../../doc/controllers/api.md#scoreboard-v2-get)
* [Shotchartdetail GET](../../doc/controllers/api.md#shotchartdetail-get)
* [Shotchartlineupdetail GET](../../doc/controllers/api.md#shotchartlineupdetail-get)
* [Teamdashboardbyclutch GET](../../doc/controllers/api.md#teamdashboardbyclutch-get)
* [Teamdashboardbygamesplits GET](../../doc/controllers/api.md#teamdashboardbygamesplits-get)
* [Teamdashboardbygeneralsplits GET](../../doc/controllers/api.md#teamdashboardbygeneralsplits-get)
* [Teamdashboardbylastngames GET](../../doc/controllers/api.md#teamdashboardbylastngames-get)
* [Teamdashboardbyopponent GET](../../doc/controllers/api.md#teamdashboardbyopponent-get)
* [Teamdashboardbyshootingsplits GET](../../doc/controllers/api.md#teamdashboardbyshootingsplits-get)
* [Teamdashboardbyteamperformance GET](../../doc/controllers/api.md#teamdashboardbyteamperformance-get)
* [Teamdashboardbyyearoveryear GET](../../doc/controllers/api.md#teamdashboardbyyearoveryear-get)
* [Teamdashlineups GET](../../doc/controllers/api.md#teamdashlineups-get)
* [Teamdashptpass GET](../../doc/controllers/api.md#teamdashptpass-get)
* [Teamdashptreb GET](../../doc/controllers/api.md#teamdashptreb-get)
* [Teamdashptshots GET](../../doc/controllers/api.md#teamdashptshots-get)
* [Teamgamelog GET](../../doc/controllers/api.md#teamgamelog-get)
* [Teaminfocommon GET](../../doc/controllers/api.md#teaminfocommon-get)
* [Teamplayerdashboard GET](../../doc/controllers/api.md#teamplayerdashboard-get)
* [Teamplayeronoffdetails GET](../../doc/controllers/api.md#teamplayeronoffdetails-get)
* [Teamplayeronoffsummary GET](../../doc/controllers/api.md#teamplayeronoffsummary-get)
* [Teamvsplayer GET](../../doc/controllers/api.md#teamvsplayer-get)
* [Teamyearbyyearstats GET](../../doc/controllers/api.md#teamyearbyyearstats-get)
* [Video Status GET](../../doc/controllers/api.md#video-status-get)


# Allstarballotpredictor GET

```ruby
def allstarballotpredictor_get(west_player1,
                               west_player2,
                               west_player3,
                               west_player4,
                               west_player5,
                               east_player1,
                               east_player2,
                               east_player3,
                               east_player4,
                               east_player5,
                               point_cap: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `west_player_1` | `String` | Query, Required | - |
| `west_player_2` | `String` | Query, Required | - |
| `west_player_3` | `String` | Query, Required | - |
| `west_player_4` | `String` | Query, Required | - |
| `west_player_5` | `String` | Query, Required | - |
| `east_player_1` | `String` | Query, Required | - |
| `east_player_2` | `String` | Query, Required | - |
| `east_player_3` | `String` | Query, Required | - |
| `east_player_4` | `String` | Query, Required | - |
| `east_player_5` | `String` | Query, Required | - |
| `point_cap` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
west_player1 = 'WestPlayer10'

west_player2 = 'WestPlayer24'

west_player3 = 'WestPlayer32'

west_player4 = 'WestPlayer48'

west_player5 = 'WestPlayer56'

east_player1 = 'EastPlayer18'

east_player2 = 'EastPlayer26'

east_player3 = 'EastPlayer32'

east_player4 = 'EastPlayer44'

east_player5 = 'EastPlayer54'

client_controller.allstarballotpredictor_get(
  west_player1,
  west_player2,
  west_player3,
  west_player4,
  west_player5,
  east_player1,
  east_player2,
  east_player3,
  east_player4,
  east_player5
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscore GET

```ruby
def boxscore_get(game_id: nil,
                 start_period: nil,
                 end_period: nil,
                 start_range: nil,
                 end_range: nil,
                 range_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Optional | - |
| `start_period` | `String` | Query, Optional | - |
| `end_period` | `String` | Query, Optional | - |
| `start_range` | `String` | Query, Optional | - |
| `end_range` | `String` | Query, Optional | - |
| `range_type` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
client_controller.boxscore_get
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreadvanced GET

```ruby
def boxscoreadvanced_get(game_id: nil,
                         start_period: nil,
                         end_period: nil,
                         start_range: nil,
                         end_range: nil,
                         range_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Optional | - |
| `start_period` | `String` | Query, Optional | - |
| `end_period` | `String` | Query, Optional | - |
| `start_range` | `String` | Query, Optional | - |
| `end_range` | `String` | Query, Optional | - |
| `range_type` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
client_controller.boxscoreadvanced_get
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreadvancedv 2 GET

```ruby
def boxscoreadvancedv2_get(game_id,
                           start_period,
                           end_period,
                           start_range,
                           end_range,
                           range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |
| `start_period` | `String` | Query, Required | - |
| `end_period` | `String` | Query, Required | - |
| `start_range` | `String` | Query, Required | - |
| `end_range` | `String` | Query, Required | - |
| `range_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscoreadvancedv2_get(
  game_id,
  start_period,
  end_period,
  start_range,
  end_range,
  range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscorefourfactors GET

```ruby
def boxscorefourfactors_get(game_id: nil,
                            start_period: nil,
                            end_period: nil,
                            start_range: nil,
                            end_range: nil,
                            range_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Optional | - |
| `start_period` | `String` | Query, Optional | - |
| `end_period` | `String` | Query, Optional | - |
| `start_range` | `String` | Query, Optional | - |
| `end_range` | `String` | Query, Optional | - |
| `range_type` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
client_controller.boxscorefourfactors_get
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscorefourfactorsv 2 GET

```ruby
def boxscorefourfactorsv2_get(game_id,
                              start_period,
                              end_period,
                              start_range,
                              end_range,
                              range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |
| `start_period` | `String` | Query, Required | - |
| `end_period` | `String` | Query, Required | - |
| `start_range` | `String` | Query, Required | - |
| `end_range` | `String` | Query, Required | - |
| `range_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscorefourfactorsv2_get(
  game_id,
  start_period,
  end_period,
  start_range,
  end_range,
  range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoremisc GET

```ruby
def boxscoremisc_get(game_id: nil,
                     start_period: nil,
                     end_period: nil,
                     start_range: nil,
                     end_range: nil,
                     range_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Optional | - |
| `start_period` | `String` | Query, Optional | - |
| `end_period` | `String` | Query, Optional | - |
| `start_range` | `String` | Query, Optional | - |
| `end_range` | `String` | Query, Optional | - |
| `range_type` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
client_controller.boxscoremisc_get
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoremiscv 2 GET

```ruby
def boxscoremiscv2_get(game_id,
                       start_period,
                       end_period,
                       start_range,
                       end_range,
                       range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |
| `start_period` | `String` | Query, Required | - |
| `end_period` | `String` | Query, Required | - |
| `start_range` | `String` | Query, Required | - |
| `end_range` | `String` | Query, Required | - |
| `range_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscoremiscv2_get(
  game_id,
  start_period,
  end_period,
  start_range,
  end_range,
  range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreplayertrackv 2 GET

```ruby
def boxscoreplayertrackv2_get(game_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

client_controller.boxscoreplayertrackv2_get(game_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscorescoring GET

```ruby
def boxscorescoring_get(game_id: nil,
                        start_period: nil,
                        end_period: nil,
                        start_range: nil,
                        end_range: nil,
                        range_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Optional | - |
| `start_period` | `String` | Query, Optional | - |
| `end_period` | `String` | Query, Optional | - |
| `start_range` | `String` | Query, Optional | - |
| `end_range` | `String` | Query, Optional | - |
| `range_type` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
client_controller.boxscorescoring_get
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscorescoringv 2 GET

```ruby
def boxscorescoringv2_get(game_id,
                          start_period,
                          end_period,
                          start_range,
                          end_range,
                          range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |
| `start_period` | `String` | Query, Required | - |
| `end_period` | `String` | Query, Required | - |
| `start_range` | `String` | Query, Required | - |
| `end_range` | `String` | Query, Required | - |
| `range_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscorescoringv2_get(
  game_id,
  start_period,
  end_period,
  start_range,
  end_range,
  range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoresummaryv 2 GET

```ruby
def boxscoresummaryv2_get(game_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

client_controller.boxscoresummaryv2_get(game_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoretraditionalv 2 GET

```ruby
def boxscoretraditionalv2_get(game_id,
                              start_period,
                              end_period,
                              start_range,
                              end_range,
                              range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |
| `start_period` | `String` | Query, Required | - |
| `end_period` | `String` | Query, Required | - |
| `start_range` | `String` | Query, Required | - |
| `end_range` | `String` | Query, Required | - |
| `range_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscoretraditionalv2_get(
  game_id,
  start_period,
  end_period,
  start_range,
  end_range,
  range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreusage GET

```ruby
def boxscoreusage_get(game_id: nil,
                      start_period: nil,
                      end_period: nil,
                      start_range: nil,
                      end_range: nil,
                      range_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Optional | - |
| `start_period` | `String` | Query, Optional | - |
| `end_period` | `String` | Query, Optional | - |
| `start_range` | `String` | Query, Optional | - |
| `end_range` | `String` | Query, Optional | - |
| `range_type` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
client_controller.boxscoreusage_get
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreusagev 2 GET

```ruby
def boxscoreusagev2_get(game_id,
                        start_period,
                        end_period,
                        start_range,
                        end_range,
                        range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |
| `start_period` | `String` | Query, Required | - |
| `end_period` | `String` | Query, Required | - |
| `start_range` | `String` | Query, Required | - |
| `end_range` | `String` | Query, Required | - |
| `range_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscoreusagev2_get(
  game_id,
  start_period,
  end_period,
  start_range,
  end_range,
  range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Common Team Years GET

```ruby
def common_team_years_get(league_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

client_controller.common_team_years_get(league_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Commonallplayers GET

```ruby
def commonallplayers_get(league_id,
                         season,
                         is_only_current_season)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `is_only_current_season` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season = 'Season0'

is_only_current_season = 'IsOnlyCurrentSeason6'

client_controller.commonallplayers_get(
  league_id,
  season,
  is_only_current_season
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Commonplayerinfo GET

```ruby
def commonplayerinfo_get(player_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
player_id = 'PlayerID6'

client_controller.commonplayerinfo_get(player_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Commonplayoffseries GET

```ruby
def commonplayoffseries_get(league_id,
                            season)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season = 'Season0'

client_controller.commonplayoffseries_get(
  league_id,
  season
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Commonteamroster GET

```ruby
def commonteamroster_get(season,
                         team_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
season = 'Season0'

team_id = 'TeamID8'

client_controller.commonteamroster_get(
  season,
  team_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombinedrillresults GET

```ruby
def draftcombinedrillresults_get(league_id,
                                 season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season_year` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombinedrillresults_get(
  league_id,
  season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombinenonstationaryshooting GET

```ruby
def draftcombinenonstationaryshooting_get(league_id,
                                          season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season_year` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombinenonstationaryshooting_get(
  league_id,
  season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombineplayeranthro GET

```ruby
def draftcombineplayeranthro_get(league_id,
                                 season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season_year` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombineplayeranthro_get(
  league_id,
  season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombinespotshooting GET

```ruby
def draftcombinespotshooting_get(league_id,
                                 season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season_year` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombinespotshooting_get(
  league_id,
  season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombinestats GET

```ruby
def draftcombinestats_get(league_id,
                          season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season_year` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombinestats_get(
  league_id,
  season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Drafthistory GET

```ruby
def drafthistory_get(league_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

client_controller.drafthistory_get(league_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Franchisehistory GET

```ruby
def franchisehistory_get(league_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

client_controller.franchisehistory_get(league_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Homepageleaders GET

```ruby
def homepageleaders_get(stat_category,
                        league_id,
                        season,
                        season_type,
                        player_or_team,
                        player_scope,
                        game_scope,
                        game: nil,
                        player: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stat_category` | `String` | Query, Required | - |
| `league_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_or_team` | `String` | Query, Required | - |
| `player_scope` | `String` | Query, Required | - |
| `game_scope` | `String` | Query, Required | - |
| `game` | `String` | Query, Optional | - |
| `player` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
stat_category = 'StatCategory6'

league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

player_or_team = 'PlayerOrTeam8'

player_scope = 'PlayerScope2'

game_scope = 'GameScope0'

client_controller.homepageleaders_get(
  stat_category,
  league_id,
  season,
  season_type,
  player_or_team,
  player_scope,
  game_scope
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Homepagev 2 GET

```ruby
def homepagev2_get(stat_type,
                   league_id,
                   season,
                   season_type,
                   player_or_team,
                   player_scope,
                   game_scope,
                   game: nil,
                   player: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stat_type` | `String` | Query, Required | - |
| `league_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_or_team` | `String` | Query, Required | - |
| `player_scope` | `String` | Query, Required | - |
| `game_scope` | `String` | Query, Required | - |
| `game` | `String` | Query, Optional | - |
| `player` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
stat_type = 'StatType8'

league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

player_or_team = 'PlayerOrTeam8'

player_scope = 'PlayerScope2'

game_scope = 'GameScope0'

client_controller.homepagev2_get(
  stat_type,
  league_id,
  season,
  season_type,
  player_or_team,
  player_scope,
  game_scope
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaderstiles GET

```ruby
def leaderstiles_get(stat,
                     league_id,
                     season,
                     season_type,
                     player_or_team,
                     player_scope,
                     game_scope,
                     game: nil,
                     player: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stat` | `String` | Query, Required | - |
| `league_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_or_team` | `String` | Query, Required | - |
| `player_scope` | `String` | Query, Required | - |
| `game_scope` | `String` | Query, Required | - |
| `game` | `String` | Query, Optional | - |
| `player` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
stat = 'Stat2'

league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

player_or_team = 'PlayerOrTeam8'

player_scope = 'PlayerScope2'

game_scope = 'GameScope0'

client_controller.leaderstiles_get(
  stat,
  league_id,
  season,
  season_type,
  player_or_team,
  player_scope,
  game_scope
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashlineups GET

```ruby
def leaguedashlineups_get(group_quantity,
                          season_type,
                          measure_type,
                          per_mode,
                          plus_minus,
                          pace_adjust,
                          rank,
                          season,
                          outcome,
                          location,
                          month,
                          season_segment,
                          date_from,
                          date_to,
                          opponent_team_id,
                          vs_conference,
                          vs_division,
                          game_segment,
                          period,
                          last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `group_quantity` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
group_quantity = 'GroupQuantity0'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashlineups_get(
  group_quantity,
  season_type,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayerbiostats GET

```ruby
def leaguedashplayerbiostats_get(per_mode,
                                 league_id,
                                 season,
                                 season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `league_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.leaguedashplayerbiostats_get(
  per_mode,
  league_id,
  season,
  season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayerclutch GET

```ruby
def leaguedashplayerclutch_get(clutch_time,
                               ahead_behind,
                               point_diff,
                               game_scope,
                               player_experience,
                               player_position,
                               starter_bench,
                               measure_type,
                               per_mode,
                               plus_minus,
                               pace_adjust,
                               rank,
                               season,
                               season_type,
                               outcome,
                               location,
                               month,
                               season_segment,
                               date_from,
                               date_to,
                               opponent_team_id,
                               vs_conference,
                               vs_division,
                               game_segment,
                               period,
                               last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clutch_time` | `String` | Query, Required | - |
| `ahead_behind` | `String` | Query, Required | - |
| `point_diff` | `String` | Query, Required | - |
| `game_scope` | `String` | Query, Required | - |
| `player_experience` | `String` | Query, Required | - |
| `player_position` | `String` | Query, Required | - |
| `starter_bench` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
clutch_time = 'ClutchTime4'

ahead_behind = 'AheadBehind8'

point_diff = 'PointDiff6'

game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashplayerclutch_get(
  clutch_time,
  ahead_behind,
  point_diff,
  game_scope,
  player_experience,
  player_position,
  starter_bench,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayerptshot GET

```ruby
def leaguedashplayerptshot_get(league_id,
                               per_mode,
                               season,
                               season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.leaguedashplayerptshot_get(
  league_id,
  per_mode,
  season,
  season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayershotlocations GET

```ruby
def leaguedashplayershotlocations_get(measure_type,
                                      per_mode,
                                      plus_minus,
                                      pace_adjust,
                                      rank,
                                      season,
                                      season_type,
                                      outcome,
                                      location,
                                      month,
                                      season_segment,
                                      date_from,
                                      date_to,
                                      opponent_team_id,
                                      vs_conference,
                                      vs_division,
                                      game_segment,
                                      period,
                                      last_n_games,
                                      distance_range,
                                      game_scope,
                                      player_experience,
                                      player_position,
                                      starter_bench)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |
| `distance_range` | `String` | Query, Required | - |
| `game_scope` | `String` | Query, Required | - |
| `player_experience` | `String` | Query, Required | - |
| `player_position` | `String` | Query, Required | - |
| `starter_bench` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

distance_range = 'DistanceRange6'

game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

client_controller.leaguedashplayershotlocations_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games,
  distance_range,
  game_scope,
  player_experience,
  player_position,
  starter_bench
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayerstats GET

```ruby
def leaguedashplayerstats_get(game_scope,
                              player_experience,
                              player_position,
                              starter_bench,
                              measure_type,
                              per_mode,
                              plus_minus,
                              pace_adjust,
                              rank,
                              season,
                              season_type,
                              outcome,
                              location,
                              month,
                              season_segment,
                              date_from,
                              date_to,
                              opponent_team_id,
                              vs_conference,
                              vs_division,
                              game_segment,
                              period,
                              last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_scope` | `String` | Query, Required | - |
| `player_experience` | `String` | Query, Required | - |
| `player_position` | `String` | Query, Required | - |
| `starter_bench` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashplayerstats_get(
  game_scope,
  player_experience,
  player_position,
  starter_bench,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashptdefend GET

```ruby
def leaguedashptdefend_get(league_id,
                           per_mode,
                           season,
                           season_type,
                           defense_category)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `defense_category` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

defense_category = 'DefenseCategory0'

client_controller.leaguedashptdefend_get(
  league_id,
  per_mode,
  season,
  season_type,
  defense_category
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashptteamdefend GET

```ruby
def leaguedashptteamdefend_get(league_id,
                               per_mode,
                               season,
                               season_type,
                               defense_category)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `defense_category` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

defense_category = 'DefenseCategory0'

client_controller.leaguedashptteamdefend_get(
  league_id,
  per_mode,
  season,
  season_type,
  defense_category
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashteamclutch GET

```ruby
def leaguedashteamclutch_get(clutch_time,
                             ahead_behind,
                             point_diff,
                             game_scope,
                             player_experience,
                             player_position,
                             starter_bench,
                             measure_type,
                             per_mode,
                             plus_minus,
                             pace_adjust,
                             rank,
                             season,
                             season_type,
                             outcome,
                             location,
                             month,
                             season_segment,
                             date_from,
                             date_to,
                             opponent_team_id,
                             vs_conference,
                             vs_division,
                             game_segment,
                             period,
                             last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clutch_time` | `String` | Query, Required | - |
| `ahead_behind` | `String` | Query, Required | - |
| `point_diff` | `String` | Query, Required | - |
| `game_scope` | `String` | Query, Required | - |
| `player_experience` | `String` | Query, Required | - |
| `player_position` | `String` | Query, Required | - |
| `starter_bench` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
clutch_time = 'ClutchTime4'

ahead_behind = 'AheadBehind8'

point_diff = 'PointDiff6'

game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashteamclutch_get(
  clutch_time,
  ahead_behind,
  point_diff,
  game_scope,
  player_experience,
  player_position,
  starter_bench,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashteamptshot GET

```ruby
def leaguedashteamptshot_get(league_id,
                             per_mode,
                             season,
                             season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.leaguedashteamptshot_get(
  league_id,
  per_mode,
  season,
  season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashteamshotlocations GET

```ruby
def leaguedashteamshotlocations_get(measure_type,
                                    per_mode,
                                    plus_minus,
                                    pace_adjust,
                                    rank,
                                    season,
                                    season_type,
                                    outcome,
                                    location,
                                    month,
                                    season_segment,
                                    date_from,
                                    date_to,
                                    opponent_team_id,
                                    vs_conference,
                                    vs_division,
                                    game_segment,
                                    period,
                                    last_n_games,
                                    distance_range,
                                    game_scope,
                                    player_experience,
                                    player_position,
                                    starter_bench)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |
| `distance_range` | `String` | Query, Required | - |
| `game_scope` | `String` | Query, Required | - |
| `player_experience` | `String` | Query, Required | - |
| `player_position` | `String` | Query, Required | - |
| `starter_bench` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

distance_range = 'DistanceRange6'

game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

client_controller.leaguedashteamshotlocations_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games,
  distance_range,
  game_scope,
  player_experience,
  player_position,
  starter_bench
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashteamstats GET

```ruby
def leaguedashteamstats_get(measure_type,
                            per_mode,
                            plus_minus,
                            pace_adjust,
                            rank,
                            season,
                            season_type,
                            outcome,
                            location,
                            month,
                            season_segment,
                            date_from,
                            date_to,
                            opponent_team_id,
                            vs_conference,
                            vs_division,
                            game_segment,
                            period,
                            last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashteamstats_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leagueleaders GET

```ruby
def leagueleaders_get(league_id,
                      per_mode,
                      season,
                      season_type,
                      scope,
                      stat_category: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `scope` | `String` | Query, Required | - |
| `stat_category` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

scope = 'Scope0'

client_controller.leagueleaders_get(
  league_id,
  per_mode,
  season,
  season_type,
  scope
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playbyplay GET

```ruby
def playbyplay_get(game_id,
                   start_period,
                   end_period)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |
| `start_period` | `String` | Query, Required | - |
| `end_period` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

client_controller.playbyplay_get(
  game_id,
  start_period,
  end_period
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playbyplayv 2 GET

```ruby
def playbyplayv2_get(game_id,
                     start_period,
                     end_period)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `String` | Query, Required | - |
| `start_period` | `String` | Query, Required | - |
| `end_period` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

client_controller.playbyplayv2_get(
  game_id,
  start_period,
  end_period
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playercareerstats GET

```ruby
def playercareerstats_get(per_mode,
                          player_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

player_id = 'PlayerID6'

client_controller.playercareerstats_get(
  per_mode,
  player_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playercompare GET

```ruby
def playercompare_get(player_id_list,
                      vs_player_id_list,
                      season_type,
                      measure_type,
                      per_mode,
                      plus_minus,
                      pace_adjust,
                      rank,
                      season,
                      outcome,
                      location,
                      month,
                      season_segment,
                      date_from,
                      date_to,
                      opponent_team_id,
                      vs_conference,
                      vs_division,
                      game_segment,
                      period,
                      last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_id_list` | `String` | Query, Required | - |
| `vs_player_id_list` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
player_id_list = 'PlayerIDList4'

vs_player_id_list = 'VsPlayerIDList2'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playercompare_get(
  player_id_list,
  vs_player_id_list,
  season_type,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyclutch GET

```ruby
def playerdashboardbyclutch_get(measure_type,
                                per_mode,
                                plus_minus,
                                pace_adjust,
                                rank,
                                season,
                                season_type,
                                player_id,
                                outcome,
                                location,
                                month,
                                season_segment,
                                date_from,
                                date_to,
                                opponent_team_id,
                                vs_conference,
                                vs_division,
                                game_segment,
                                period,
                                last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyclutch_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  player_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbygamesplits GET

```ruby
def playerdashboardbygamesplits_get(measure_type,
                                    per_mode,
                                    plus_minus,
                                    pace_adjust,
                                    rank,
                                    season,
                                    season_type,
                                    player_id,
                                    outcome,
                                    location,
                                    month,
                                    season_segment,
                                    date_from,
                                    date_to,
                                    opponent_team_id,
                                    vs_conference,
                                    vs_division,
                                    game_segment,
                                    period,
                                    last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbygamesplits_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  player_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbygeneralsplits GET

```ruby
def playerdashboardbygeneralsplits_get(measure_type,
                                       per_mode,
                                       plus_minus,
                                       pace_adjust,
                                       rank,
                                       season,
                                       season_type,
                                       player_id,
                                       outcome,
                                       location,
                                       month,
                                       season_segment,
                                       date_from,
                                       date_to,
                                       opponent_team_id,
                                       vs_conference,
                                       vs_division,
                                       game_segment,
                                       period,
                                       last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbygeneralsplits_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  player_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbylastngames GET

```ruby
def playerdashboardbylastngames_get(measure_type,
                                    per_mode,
                                    plus_minus,
                                    pace_adjust,
                                    rank,
                                    season,
                                    season_type,
                                    player_id,
                                    outcome,
                                    location,
                                    month,
                                    season_segment,
                                    date_from,
                                    date_to,
                                    opponent_team_id,
                                    vs_conference,
                                    vs_division,
                                    game_segment,
                                    period,
                                    last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbylastngames_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  player_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyopponent GET

```ruby
def playerdashboardbyopponent_get(measure_type,
                                  per_mode,
                                  plus_minus,
                                  pace_adjust,
                                  rank,
                                  season,
                                  season_type,
                                  player_id,
                                  outcome,
                                  location,
                                  month,
                                  season_segment,
                                  date_from,
                                  date_to,
                                  opponent_team_id,
                                  vs_conference,
                                  vs_division,
                                  game_segment,
                                  period,
                                  last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyopponent_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  player_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyshootingsplits GET

```ruby
def playerdashboardbyshootingsplits_get(measure_type,
                                        per_mode,
                                        plus_minus,
                                        pace_adjust,
                                        rank,
                                        season,
                                        season_type,
                                        player_id,
                                        outcome,
                                        location,
                                        month,
                                        season_segment,
                                        date_from,
                                        date_to,
                                        opponent_team_id,
                                        vs_conference,
                                        vs_division,
                                        game_segment,
                                        period,
                                        last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyshootingsplits_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  player_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyteamperformance GET

```ruby
def playerdashboardbyteamperformance_get(measure_type,
                                         per_mode,
                                         plus_minus,
                                         pace_adjust,
                                         rank,
                                         season,
                                         season_type,
                                         player_id,
                                         outcome,
                                         location,
                                         month,
                                         season_segment,
                                         date_from,
                                         date_to,
                                         opponent_team_id,
                                         vs_conference,
                                         vs_division,
                                         game_segment,
                                         period,
                                         last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyteamperformance_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  player_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyyearoveryear GET

```ruby
def playerdashboardbyyearoveryear_get(measure_type,
                                      per_mode,
                                      plus_minus,
                                      pace_adjust,
                                      rank,
                                      season,
                                      season_type,
                                      player_id,
                                      outcome,
                                      location,
                                      month,
                                      season_segment,
                                      date_from,
                                      date_to,
                                      opponent_team_id,
                                      vs_conference,
                                      vs_division,
                                      game_segment,
                                      period,
                                      last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyyearoveryear_get(
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  player_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptpass GET

```ruby
def playerdashptpass_get(per_mode,
                         season,
                         season_type,
                         player_id,
                         team_id,
                         outcome,
                         location,
                         month,
                         season_segment,
                         date_from,
                         date_to,
                         opponent_team_id,
                         vs_conference,
                         vs_division,
                         last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

last_n_games = 'LastNGames4'

client_controller.playerdashptpass_get(
  per_mode,
  season,
  season_type,
  player_id,
  team_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptreb GET

```ruby
def playerdashptreb_get(per_mode,
                        season,
                        season_type,
                        player_id,
                        team_id,
                        outcome,
                        location,
                        month,
                        season_segment,
                        date_from,
                        date_to,
                        opponent_team_id,
                        vs_conference,
                        vs_division,
                        game_segment,
                        period,
                        last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashptreb_get(
  per_mode,
  season,
  season_type,
  player_id,
  team_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptreboundlogs GET

```ruby
def playerdashptreboundlogs_get(season: nil,
                                season_type: nil,
                                player_id: nil,
                                team_id: nil,
                                outcome: nil,
                                location: nil,
                                month: nil,
                                season_segment: nil,
                                date_from: nil,
                                date_to: nil,
                                opponent_team_id: nil,
                                vs_conference: nil,
                                vs_division: nil,
                                game_segment: nil,
                                period: nil,
                                last_n_games: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `String` | Query, Optional | - |
| `season_type` | `String` | Query, Optional | - |
| `player_id` | `String` | Query, Optional | - |
| `team_id` | `String` | Query, Optional | - |
| `outcome` | `String` | Query, Optional | - |
| `location` | `String` | Query, Optional | - |
| `month` | `String` | Query, Optional | - |
| `season_segment` | `String` | Query, Optional | - |
| `date_from` | `String` | Query, Optional | - |
| `date_to` | `String` | Query, Optional | - |
| `opponent_team_id` | `String` | Query, Optional | - |
| `vs_conference` | `String` | Query, Optional | - |
| `vs_division` | `String` | Query, Optional | - |
| `game_segment` | `String` | Query, Optional | - |
| `period` | `String` | Query, Optional | - |
| `last_n_games` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
client_controller.playerdashptreboundlogs_get
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptshotdefend GET

```ruby
def playerdashptshotdefend_get(per_mode,
                               season,
                               season_type,
                               player_id,
                               team_id,
                               outcome,
                               location,
                               month,
                               season_segment,
                               date_from,
                               date_to,
                               opponent_team_id,
                               vs_conference,
                               vs_division,
                               game_segment,
                               period,
                               last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashptshotdefend_get(
  per_mode,
  season,
  season_type,
  player_id,
  team_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptshotlog GET

```ruby
def playerdashptshotlog_get(league_id: nil,
                            season: nil,
                            season_type: nil,
                            player_id: nil,
                            team_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Optional | - |
| `season` | `String` | Query, Optional | - |
| `season_type` | `String` | Query, Optional | - |
| `player_id` | `String` | Query, Optional | - |
| `team_id` | `String` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
client_controller.playerdashptshotlog_get
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptshots GET

```ruby
def playerdashptshots_get(per_mode,
                          season,
                          season_type,
                          player_id,
                          team_id,
                          outcome,
                          location,
                          month,
                          season_segment,
                          date_from,
                          date_to,
                          opponent_team_id,
                          vs_conference,
                          vs_division,
                          game_segment,
                          period,
                          last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashptshots_get(
  per_mode,
  season,
  season_type,
  player_id,
  team_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playergamelog GET

```ruby
def playergamelog_get(player_id,
                      season,
                      season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
player_id = 'PlayerID6'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.playergamelog_get(
  player_id,
  season,
  season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerprofile GET

```ruby
def playerprofile_get(league_id,
                      player_id,
                      season,
                      season_type,
                      graph_start_season,
                      graph_end_season,
                      graph_stat)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `graph_start_season` | `String` | Query, Required | - |
| `graph_end_season` | `String` | Query, Required | - |
| `graph_stat` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

player_id = 'PlayerID6'

season = 'Season0'

season_type = 'SeasonType8'

graph_start_season = 'GraphStartSeason2'

graph_end_season = 'GraphEndSeason6'

graph_stat = 'GraphStat0'

client_controller.playerprofile_get(
  league_id,
  player_id,
  season,
  season_type,
  graph_start_season,
  graph_end_season,
  graph_stat
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerprofilev 2 GET

```ruby
def playerprofilev2_get(per_mode,
                        player_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

player_id = 'PlayerID6'

client_controller.playerprofilev2_get(
  per_mode,
  player_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playersvsplayers GET

```ruby
def playersvsplayers_get(player_team_id,
                         player_id1,
                         player_id2,
                         player_id3,
                         player_id4,
                         player_id5,
                         vs_team_id,
                         vs_player_id1,
                         vs_player_id2,
                         vs_player_id3,
                         vs_player_id4,
                         vs_player_id5,
                         season_type,
                         measure_type,
                         per_mode,
                         plus_minus,
                         pace_adjust,
                         rank,
                         season,
                         outcome,
                         location,
                         month,
                         season_segment,
                         date_from,
                         date_to,
                         opponent_team_id,
                         vs_conference,
                         vs_division,
                         game_segment,
                         period,
                         last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_team_id` | `String` | Query, Required | - |
| `player_id_1` | `String` | Query, Required | - |
| `player_id_2` | `String` | Query, Required | - |
| `player_id_3` | `String` | Query, Required | - |
| `player_id_4` | `String` | Query, Required | - |
| `player_id_5` | `String` | Query, Required | - |
| `vs_team_id` | `String` | Query, Required | - |
| `vs_player_id_1` | `String` | Query, Required | - |
| `vs_player_id_2` | `String` | Query, Required | - |
| `vs_player_id_3` | `String` | Query, Required | - |
| `vs_player_id_4` | `String` | Query, Required | - |
| `vs_player_id_5` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
player_team_id = 'PlayerTeamID4'

player_id1 = 'PlayerID18'

player_id2 = 'PlayerID24'

player_id3 = 'PlayerID32'

player_id4 = 'PlayerID44'

player_id5 = 'PlayerID54'

vs_team_id = 'VsTeamID8'

vs_player_id1 = 'VsPlayerID12'

vs_player_id2 = 'VsPlayerID28'

vs_player_id3 = 'VsPlayerID38'

vs_player_id4 = 'VsPlayerID46'

vs_player_id5 = 'VsPlayerID56'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playersvsplayers_get(
  player_team_id,
  player_id1,
  player_id2,
  player_id3,
  player_id4,
  player_id5,
  vs_team_id,
  vs_player_id1,
  vs_player_id2,
  vs_player_id3,
  vs_player_id4,
  vs_player_id5,
  season_type,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playervsplayer GET

```ruby
def playervsplayer_get(player_id,
                       vs_player_id,
                       season_type,
                       measure_type,
                       per_mode,
                       plus_minus,
                       pace_adjust,
                       rank,
                       season,
                       outcome,
                       location,
                       month,
                       season_segment,
                       date_from,
                       date_to,
                       opponent_team_id,
                       vs_conference,
                       vs_division,
                       game_segment,
                       period,
                       last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_id` | `String` | Query, Required | - |
| `vs_player_id` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
player_id = 'PlayerID6'

vs_player_id = 'VsPlayerID8'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playervsplayer_get(
  player_id,
  vs_player_id,
  season_type,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playoffpicture GET

```ruby
def playoffpicture_get(league_id,
                       season_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season_id = 'SeasonID6'

client_controller.playoffpicture_get(
  league_id,
  season_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Scoreboard GET

```ruby
def scoreboard_get(game_date,
                   league_id,
                   day_offset)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_date` | `String` | Query, Required | - |
| `league_id` | `String` | Query, Required | - |
| `day_offset` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_date = 'GameDate8'

league_id = 'LeagueID4'

day_offset = 'DayOffset6'

client_controller.scoreboard_get(
  game_date,
  league_id,
  day_offset
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Scoreboard V2 GET

```ruby
def scoreboard_v2_get(game_date,
                      league_id,
                      day_offset)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_date` | `String` | Query, Required | - |
| `league_id` | `String` | Query, Required | - |
| `day_offset` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
game_date = 'GameDate8'

league_id = 'LeagueID4'

day_offset = 'DayOffset6'

client_controller.scoreboard_v2_get(
  game_date,
  league_id,
  day_offset
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Shotchartdetail GET

```ruby
def shotchartdetail_get(season_type,
                        team_id,
                        player_id,
                        game_id,
                        outcome,
                        location,
                        month,
                        season_segment,
                        date_from,
                        date_to,
                        opponent_team_id,
                        vs_conference,
                        vs_division,
                        position,
                        rookie_year,
                        game_segment,
                        period,
                        last_n_games,
                        context_measure)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season_type` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `player_id` | `String` | Query, Required | - |
| `game_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `position` | `String` | Query, Required | - |
| `rookie_year` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |
| `context_measure` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
season_type = 'SeasonType8'

team_id = 'TeamID8'

player_id = 'PlayerID6'

game_id = 'GameID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

position = 'Position8'

rookie_year = 'RookieYear8'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

context_measure = 'ContextMeasure2'

client_controller.shotchartdetail_get(
  season_type,
  team_id,
  player_id,
  game_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  position,
  rookie_year,
  game_segment,
  period,
  last_n_games,
  context_measure
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Shotchartlineupdetail GET

```ruby
def shotchartlineupdetail_get(league_id,
                              season,
                              season_type,
                              team_id,
                              outcome,
                              location,
                              month,
                              season_segment,
                              date_from,
                              date_to,
                              opponent_team_id,
                              vs_conference,
                              vs_division,
                              game_segment,
                              period,
                              last_n_games,
                              game_id,
                              group_id,
                              context_measure,
                              context_filter)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |
| `game_id` | `String` | Query, Required | - |
| `group_id` | `String` | Query, Required | - |
| `context_measure` | `String` | Query, Required | - |
| `context_filter` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

game_id = 'GameID8'

group_id = 'GROUP_ID6'

context_measure = 'ContextMeasure2'

context_filter = 'ContextFilter6'

client_controller.shotchartlineupdetail_get(
  league_id,
  season,
  season_type,
  team_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games,
  game_id,
  group_id,
  context_measure,
  context_filter
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyclutch GET

```ruby
def teamdashboardbyclutch_get(team_id,
                              measure_type,
                              per_mode,
                              plus_minus,
                              pace_adjust,
                              rank,
                              season,
                              season_type,
                              outcome,
                              location,
                              month,
                              season_segment,
                              date_from,
                              date_to,
                              opponent_team_id,
                              vs_conference,
                              vs_division,
                              game_segment,
                              period,
                              last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyclutch_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbygamesplits GET

```ruby
def teamdashboardbygamesplits_get(team_id,
                                  measure_type,
                                  per_mode,
                                  plus_minus,
                                  pace_adjust,
                                  rank,
                                  season,
                                  season_type,
                                  outcome,
                                  location,
                                  month,
                                  season_segment,
                                  date_from,
                                  date_to,
                                  opponent_team_id,
                                  vs_conference,
                                  vs_division,
                                  game_segment,
                                  period,
                                  last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbygamesplits_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbygeneralsplits GET

```ruby
def teamdashboardbygeneralsplits_get(season_type,
                                     team_id,
                                     measure_type,
                                     per_mode,
                                     plus_minus,
                                     pace_adjust,
                                     rank,
                                     season,
                                     outcome,
                                     location,
                                     month,
                                     season_segment,
                                     date_from,
                                     date_to,
                                     opponent_team_id,
                                     vs_conference,
                                     vs_division,
                                     game_segment,
                                     period,
                                     last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season_type` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
season_type = 'SeasonType8'

team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbygeneralsplits_get(
  season_type,
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbylastngames GET

```ruby
def teamdashboardbylastngames_get(team_id,
                                  measure_type,
                                  per_mode,
                                  plus_minus,
                                  pace_adjust,
                                  rank,
                                  season,
                                  season_type,
                                  outcome,
                                  location,
                                  month,
                                  season_segment,
                                  date_from,
                                  date_to,
                                  opponent_team_id,
                                  vs_conference,
                                  vs_division,
                                  game_segment,
                                  period,
                                  last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbylastngames_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyopponent GET

```ruby
def teamdashboardbyopponent_get(team_id,
                                measure_type,
                                per_mode,
                                plus_minus,
                                pace_adjust,
                                rank,
                                season,
                                season_type,
                                outcome,
                                location,
                                month,
                                season_segment,
                                date_from,
                                date_to,
                                opponent_team_id,
                                vs_conference,
                                vs_division,
                                game_segment,
                                period,
                                last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyopponent_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyshootingsplits GET

```ruby
def teamdashboardbyshootingsplits_get(team_id,
                                      measure_type,
                                      per_mode,
                                      plus_minus,
                                      pace_adjust,
                                      rank,
                                      season,
                                      season_type,
                                      outcome,
                                      location,
                                      month,
                                      season_segment,
                                      date_from,
                                      date_to,
                                      opponent_team_id,
                                      vs_conference,
                                      vs_division,
                                      game_segment,
                                      period,
                                      last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyshootingsplits_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyteamperformance GET

```ruby
def teamdashboardbyteamperformance_get(team_id,
                                       measure_type,
                                       per_mode,
                                       plus_minus,
                                       pace_adjust,
                                       rank,
                                       season,
                                       season_type,
                                       outcome,
                                       location,
                                       month,
                                       season_segment,
                                       date_from,
                                       date_to,
                                       opponent_team_id,
                                       vs_conference,
                                       vs_division,
                                       game_segment,
                                       period,
                                       last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyteamperformance_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyyearoveryear GET

```ruby
def teamdashboardbyyearoveryear_get(team_id,
                                    measure_type,
                                    per_mode,
                                    plus_minus,
                                    pace_adjust,
                                    rank,
                                    season,
                                    season_type,
                                    outcome,
                                    location,
                                    month,
                                    season_segment,
                                    date_from,
                                    date_to,
                                    opponent_team_id,
                                    vs_conference,
                                    vs_division,
                                    game_segment,
                                    period,
                                    last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyyearoveryear_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashlineups GET

```ruby
def teamdashlineups_get(group_quantity,
                        game_id,
                        season_type,
                        team_id,
                        measure_type,
                        per_mode,
                        plus_minus,
                        pace_adjust,
                        rank,
                        season,
                        outcome,
                        location,
                        month,
                        season_segment,
                        date_from,
                        date_to,
                        opponent_team_id,
                        vs_conference,
                        vs_division,
                        game_segment,
                        period,
                        last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `group_quantity` | `String` | Query, Required | - |
| `game_id` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
group_quantity = 'GroupQuantity0'

game_id = 'GameID8'

season_type = 'SeasonType8'

team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashlineups_get(
  group_quantity,
  game_id,
  season_type,
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashptpass GET

```ruby
def teamdashptpass_get(per_mode,
                       season,
                       season_type,
                       team_id,
                       outcome,
                       location,
                       month,
                       season_segment,
                       date_from,
                       date_to,
                       opponent_team_id,
                       vs_conference,
                       vs_division,
                       last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

last_n_games = 'LastNGames4'

client_controller.teamdashptpass_get(
  per_mode,
  season,
  season_type,
  team_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashptreb GET

```ruby
def teamdashptreb_get(per_mode,
                      season,
                      season_type,
                      team_id,
                      outcome,
                      location,
                      month,
                      season_segment,
                      date_from,
                      date_to,
                      opponent_team_id,
                      vs_conference,
                      vs_division,
                      game_segment,
                      period,
                      last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashptreb_get(
  per_mode,
  season,
  season_type,
  team_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashptshots GET

```ruby
def teamdashptshots_get(per_mode,
                        season,
                        season_type,
                        team_id,
                        outcome,
                        location,
                        month,
                        season_segment,
                        date_from,
                        date_to,
                        opponent_team_id,
                        vs_conference,
                        vs_division,
                        game_segment,
                        period,
                        last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashptshots_get(
  per_mode,
  season,
  season_type,
  team_id,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamgamelog GET

```ruby
def teamgamelog_get(team_id,
                    season,
                    season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.teamgamelog_get(
  team_id,
  season,
  season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teaminfocommon GET

```ruby
def teaminfocommon_get(season,
                       team_id,
                       league_id,
                       season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `league_id` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
season = 'Season0'

team_id = 'TeamID8'

league_id = 'LeagueID4'

season_type = 'SeasonType8'

client_controller.teaminfocommon_get(
  season,
  team_id,
  league_id,
  season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamplayerdashboard GET

```ruby
def teamplayerdashboard_get(season_type,
                            team_id,
                            measure_type,
                            per_mode,
                            plus_minus,
                            pace_adjust,
                            rank,
                            season,
                            outcome,
                            location,
                            month,
                            season_segment,
                            date_from,
                            date_to,
                            opponent_team_id,
                            vs_conference,
                            vs_division,
                            game_segment,
                            period,
                            last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season_type` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
season_type = 'SeasonType8'

team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamplayerdashboard_get(
  season_type,
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamplayeronoffdetails GET

```ruby
def teamplayeronoffdetails_get(team_id,
                               measure_type,
                               per_mode,
                               plus_minus,
                               pace_adjust,
                               rank,
                               season,
                               season_type,
                               outcome,
                               location,
                               month,
                               season_segment,
                               date_from,
                               date_to,
                               opponent_team_id,
                               vs_conference,
                               vs_division,
                               game_segment,
                               period,
                               last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamplayeronoffdetails_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamplayeronoffsummary GET

```ruby
def teamplayeronoffsummary_get(team_id,
                               measure_type,
                               per_mode,
                               plus_minus,
                               pace_adjust,
                               rank,
                               season,
                               season_type,
                               outcome,
                               location,
                               month,
                               season_segment,
                               date_from,
                               date_to,
                               opponent_team_id,
                               vs_conference,
                               vs_division,
                               game_segment,
                               period,
                               last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamplayeronoffsummary_get(
  team_id,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  season_type,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamvsplayer GET

```ruby
def teamvsplayer_get(team_id,
                     vs_player_id,
                     season_type,
                     measure_type,
                     per_mode,
                     plus_minus,
                     pace_adjust,
                     rank,
                     season,
                     outcome,
                     location,
                     month,
                     season_segment,
                     date_from,
                     date_to,
                     opponent_team_id,
                     vs_conference,
                     vs_division,
                     game_segment,
                     period,
                     last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `String` | Query, Required | - |
| `vs_player_id` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `measure_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `plus_minus` | `String` | Query, Required | - |
| `pace_adjust` | `String` | Query, Required | - |
| `rank` | `String` | Query, Required | - |
| `season` | `String` | Query, Required | - |
| `outcome` | `String` | Query, Required | - |
| `location` | `String` | Query, Required | - |
| `month` | `String` | Query, Required | - |
| `season_segment` | `String` | Query, Required | - |
| `date_from` | `String` | Query, Required | - |
| `date_to` | `String` | Query, Required | - |
| `opponent_team_id` | `String` | Query, Required | - |
| `vs_conference` | `String` | Query, Required | - |
| `vs_division` | `String` | Query, Required | - |
| `game_segment` | `String` | Query, Required | - |
| `period` | `String` | Query, Required | - |
| `last_n_games` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
team_id = 'TeamID8'

vs_player_id = 'VsPlayerID8'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamvsplayer_get(
  team_id,
  vs_player_id,
  season_type,
  measure_type,
  per_mode,
  plus_minus,
  pace_adjust,
  rank,
  season,
  outcome,
  location,
  month,
  season_segment,
  date_from,
  date_to,
  opponent_team_id,
  vs_conference,
  vs_division,
  game_segment,
  period,
  last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamyearbyyearstats GET

```ruby
def teamyearbyyearstats_get(league_id,
                            season_type,
                            per_mode,
                            team_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `season_type` | `String` | Query, Required | - |
| `per_mode` | `String` | Query, Required | - |
| `team_id` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

season_type = 'SeasonType8'

per_mode = 'PerMode6'

team_id = 'TeamID8'

client_controller.teamyearbyyearstats_get(
  league_id,
  season_type,
  per_mode,
  team_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Video Status GET

```ruby
def video_status_get(league_id,
                     game_date)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `String` | Query, Required | - |
| `game_date` | `String` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```ruby
league_id = 'LeagueID4'

game_date = 'GameDate8'

client_controller.video_status_get(
  league_id,
  game_date
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |

