
# X Amz Target 48

## Enumeration

`XAmzTarget48`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartSession` |

## Example

```ts
import { XAmzTarget48 } from 'amazon-athenalib';

const xAmzTarget48 = XAmzTarget48.EnumAmazonAthenaStartSession;
```

