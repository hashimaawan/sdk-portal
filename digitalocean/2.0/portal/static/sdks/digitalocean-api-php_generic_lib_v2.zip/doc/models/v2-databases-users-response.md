
# V2 Databases Users Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `users` | [`?(User[])`](../../doc/models/user.md) | Optional | - | getUsers(): ?array | setUsers(?array users): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesUsersResponseBuilder;
use DigitalOceanApiLib\Models\Builders\UserBuilder;
use DigitalOceanApiLib\Models\Builders\MysqlSettingsBuilder;
use DigitalOceanApiLib\Models\AuthPlugin;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Role;

$v2DatabasesUsersResponse = V2DatabasesUsersResponseBuilder::init()
    ->users(
        [
            UserBuilder::init(
                'name6'
            )
                ->mysqlSettings(
                    MysqlSettingsBuilder::init(
                        AuthPlugin::MYSQL_NATIVE_PASSWORD
                    )
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                )
                ->password('password0')
                ->role(Role::PRIMARY)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            UserBuilder::init(
                'name6'
            )
                ->mysqlSettings(
                    MysqlSettingsBuilder::init(
                        AuthPlugin::MYSQL_NATIVE_PASSWORD
                    )
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                )
                ->password('password0')
                ->role(Role::PRIMARY)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

