
# Protection 11

Protection configuration for the Network

## Structure

`Protection11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Required | If true, prevents the Network from being deleted |

## Example

```python
from hetznercloudapi.models.protection_11 import Protection11

protection_11 = Protection11(
    delete=False
)
```

