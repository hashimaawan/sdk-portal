
# X Amz Target 41

## Enumeration

`XAmzTarget41`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget41;

XAmzTarget41 xAmzTarget41 = XAmzTarget41.ENUM_AMAZONATHENALISTQUERYEXECUTIONS;
```

