# Vaults

Access 1Password Vaults

```ruby
vaults_api = client.vaults
```

## Class Name

`VaultsApi`

## Methods

* [Get Vaults](../../doc/controllers/vaults.md#get-vaults)
* [Get Vault by Id](../../doc/controllers/vaults.md#get-vault-by-id)


# Get Vaults

```ruby
def get_vaults(filter: nil)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filter` | `String` | Query, Optional | Filter the Vault collection based on Vault name using SCIM eq filter |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`Array[Vault]`](../../doc/models/vault.md).

## Example Usage

```ruby
filter = 'name eq "Some Vault Name"'

result = vaults_api.get_vaults(filter: filter)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Vault by Id

```ruby
def get_vault_by_id(vault_uuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `String` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`Vault`](../../doc/models/vault.md).

## Example Usage

```ruby
vault_uuid = 'vaultUuid2'

result = vaults_api.get_vault_by_id(vault_uuid)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Vault not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

