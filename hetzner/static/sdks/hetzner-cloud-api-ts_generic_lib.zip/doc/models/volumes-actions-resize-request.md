
# Volumes Actions Resize Request

## Structure

`VolumesActionsResizeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `size` | `number` | Required | New Volume size in GB (must be greater than current size) |

## Example

```ts
import { VolumesActionsResizeRequest } from 'hetzner-cloud-apilib';

const volumesActionsResizeRequest: VolumesActionsResizeRequest = {
  size: 50,
};
```

