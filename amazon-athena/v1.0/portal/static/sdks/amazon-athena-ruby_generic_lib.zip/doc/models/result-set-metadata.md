
# Result Set Metadata

The metadata that describes the column structure and data types of a table of query results. To return a <code>ResultSetMetadata</code> object, use <a>GetQueryResults</a>.

## Structure

`ResultSetMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `column_info` | [`Array[ColumnInfo]`](../../doc/models/column-info.md) | Optional | - |

## Example

```ruby
result_set_metadata = ResultSetMetadata.new(
  [
    ColumnInfo.new(
      'Name6',
      'Type6',
      'CatalogName0',
      'SchemaName0',
      'TableName2',
      'Label4',
      48,
      nil,
      envrr
    )
  ]
)
```

