
# X Amz Target 34

## Enumeration

`XAmzTarget34`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATABASES` |

## Example

```ruby
x_amz_target34 = XAmzTarget34::ENUM_AMAZONATHENALISTDATABASES
```

