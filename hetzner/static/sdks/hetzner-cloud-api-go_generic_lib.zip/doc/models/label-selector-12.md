
# Label Selector 12

Configuration for label selector targets, required if type is `label_selector`

## Structure

`LabelSelector12`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    labelSelector12 := models.LabelSelector12{
        Selector:             "env=prod",
    }

}
```

