
# X Amz Target 43

## Enumeration

`XAmzTarget43`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListTableMetadata` |

## Example

```ts
import { XAmzTarget43 } from 'amazon-athenalib';

const xAmzTarget43 = XAmzTarget43.EnumAmazonAthenaListTableMetadata;
```

