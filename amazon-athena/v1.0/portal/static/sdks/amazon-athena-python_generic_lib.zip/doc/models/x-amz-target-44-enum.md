
# X Amz Target 44 Enum

## Enumeration

`XAmzTarget44Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```python
from amazonathena.models.x_amz_target_44_enum import XAmzTarget44Enum

x_amz_target_44 = XAmzTarget44Enum.ENUM_AMAZONATHENALISTTAGSFORRESOURCE
```

