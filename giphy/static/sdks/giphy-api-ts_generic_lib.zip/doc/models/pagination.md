
# Pagination

The Pagination Object contains information relating to the number of total results available as well as the number of results fetched and their relative positions.

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `number \| undefined` | Optional | Total number of items returned. |
| `offset` | `number \| undefined` | Optional | Position in pagination. |
| `totalCount` | `number \| undefined` | Optional | Total number of items available. |

## Example

```ts
import { Pagination } from 'giphy-apilib';

const pagination: Pagination = {
  count: 25,
  offset: 75,
  totalCount: 250,
};
```

