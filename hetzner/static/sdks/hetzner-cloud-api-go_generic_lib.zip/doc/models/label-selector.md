
# Label Selector

## Structure

`LabelSelector`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    labelSelector := models.LabelSelector{
        Selector:             "env=prod",
    }

}
```

