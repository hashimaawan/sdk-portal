
# X Amz Target 49

## Enumeration

`XAmzTarget49`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStopCalculationExecution` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget49 xAmzTarget49 = XAmzTarget49.EnumAmazonAthenaStopCalculationExecution;
```

