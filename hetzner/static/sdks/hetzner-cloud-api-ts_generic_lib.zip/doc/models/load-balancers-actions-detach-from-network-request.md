
# Load Balancers Actions Detach from Network Request

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `number` | Required | ID of an existing network to detach the Load Balancer from |

## Example

```ts
import {
  LoadBalancersActionsDetachFromNetworkRequest,
} from 'hetzner-cloud-apilib';

const loadBalancersActionsDetachFromNetworkRequest: LoadBalancersActionsDetachFromNetworkRequest = {
  network: 4711,
};
```

