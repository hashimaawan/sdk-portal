
# Protocol 7 Enum

Protocol of the Load Balancer

## Enumeration

`Protocol7Enum`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |
| `Https` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Protocol7Enum protocol7 = Protocol7Enum.Http;
```

