# Forex

```csharp
ForexApi forexApi = client.ForexApi;
```

## Class Name

`ForexApi`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```csharp
GetQuotesForAllSymbolsAsync()
```

## Response Type

**200**: A list of quotes

`Task`

## Example Usage

```csharp
try
{
    await forexApi.GetQuotesForAllSymbolsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```csharp
GetAListOfSymbolsForWhichWeProvideRealTimeQuotesAsync()
```

## Response Type

**200**: A list of symbols

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type List<string>.

## Example Usage

```csharp
try
{
    ApiResponse<List<string>> result = await forexApi.GetAListOfSymbolsForWhichWeProvideRealTimeQuotesAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

