
# Export Notebook Input

## Structure

`ExportNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```python
from amazonathena.models.export_notebook_input import ExportNotebookInput

export_notebook_input = ExportNotebookInput(
    notebook_id='NotebookId0'
)
```

