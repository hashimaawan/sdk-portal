
# Servers Actions Enable Rescue Request

## Structure

`ServersActionsEnableRescueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sshKeys` | `number[] \| undefined` | Optional | Array of SSH key IDs which should be injected into the rescue system. |
| `type` | [`Type65Enum \| undefined`](../../doc/models/type-65-enum.md) | Optional | Type of rescue system to boot (default: `linux64`) |

## Example

```ts
import {
  ServersActionsEnableRescueRequest,
  Type65Enum,
} from 'hetzner-cloud-apilib';

const serversActionsEnableRescueRequest: ServersActionsEnableRescueRequest = {
  sshKeys: [
    2323
  ],
  type: Type65Enum.Linux64,
};
```

