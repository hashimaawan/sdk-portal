
# Type 41

## Enumeration

`Type41`

## Fields

| Name |
|  --- |
| `OPEN_CONNECTIONS` |
| `CONNECTIONS_PER_SECOND` |
| `REQUESTS_PER_SECOND` |
| `BANDWIDTH` |

## Example

```java
import cloud.hetzner.api.models.Type41;

Type41 type41 = Type41.REQUESTS_PER_SECOND;
```

