
# Notebook Type

## Enumeration

`NotebookType`

## Fields

| Name |
|  --- |
| `Ipynb` |

## Example

```ts
import { NotebookType } from 'amazon-athenalib';

const notebookType = NotebookType.Ipynb;
```

