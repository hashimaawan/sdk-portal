
# X Amz Target 35

## Enumeration

`XAmzTarget35`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTENGINEVERSIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget35;

XAmzTarget35 xAmzTarget35 = XAmzTarget35.ENUM_AMAZONATHENALISTENGINEVERSIONS;
```

