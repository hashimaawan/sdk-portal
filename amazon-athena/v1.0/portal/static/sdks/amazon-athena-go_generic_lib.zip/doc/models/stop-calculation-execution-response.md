
# Stop Calculation Execution Response

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `State` | [`*models.CalculationExecutionState4Enum`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    stopCalculationExecutionResponse := models.StopCalculationExecutionResponse{
        State:                models.ToPointer(models.CalculationExecutionState4Enum_QUEUED),
    }

}
```

