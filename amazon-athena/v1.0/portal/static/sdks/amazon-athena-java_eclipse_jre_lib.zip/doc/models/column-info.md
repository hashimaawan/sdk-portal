
# Column Info

Information about the columns in a query execution result.

*This model accepts additional fields of type Object.*

## Structure

`ColumnInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CatalogName` | `String` | Optional | - | String getCatalogName() | setCatalogName(String catalogName) |
| `SchemaName` | `String` | Optional | - | String getSchemaName() | setSchemaName(String schemaName) |
| `TableName` | `String` | Optional | - | String getTableName() | setTableName(String tableName) |
| `Name` | `String` | Required | - | String getName() | setName(String name) |
| `Label` | `String` | Optional | - | String getLabel() | setLabel(String label) |
| `Type` | `String` | Required | - | String getType() | setType(String type) |
| `Precision` | `Integer` | Optional | - | Integer getPrecision() | setPrecision(Integer precision) |
| `Scale` | `Integer` | Optional | - | Integer getScale() | setScale(Integer scale) |
| `Nullable` | [`ColumnNullable2`](../../doc/models/column-nullable-2.md) | Optional | - | ColumnNullable2 getNullable() | setNullable(ColumnNullable2 nullable) |
| `CaseSensitive` | `Boolean` | Optional | - | Boolean getCaseSensitive() | setCaseSensitive(Boolean caseSensitive) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.models.ColumnInfo;
import java.io.IOException;

ColumnInfo columnInfo = new ColumnInfo.Builder(
    "Name8",
    "Type8"
)
.catalogName("CatalogName2")
.schemaName("SchemaName2")
.tableName("TableName4")
.label("Label6")
.precision(196)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

