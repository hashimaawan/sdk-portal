
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `KUBERNETES` |

## Example

```ruby
type = Type::DROPLET
```

