
# Protection

Protection configuration for the Resource

## Structure

`Protection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Required | If true, prevents the Resource from being deleted |

## Example

```ruby
protection = Protection.new(
  false
)
```

