
# Algorithm

Algorithm of the Load Balancer

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```python
from hetznercloudapi.models.algorithm import Algorithm
from hetznercloudapi.models.type_28_enum import Type28Enum

algorithm = Algorithm(
    mtype=Type28Enum.ROUND_ROBIN
)
```

