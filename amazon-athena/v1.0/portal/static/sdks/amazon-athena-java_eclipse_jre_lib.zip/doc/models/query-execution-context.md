
# Query Execution Context

The database and data catalog context in which the query execution occurs.

## Structure

`QueryExecutionContext`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Database` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` | String getDatabase() | setDatabase(String database) |
| `Catalog` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getCatalog() | setCatalog(String catalog) |

## Example

```java
import com.amazonaws.useast1.athena.models.QueryExecutionContext;

QueryExecutionContext queryExecutionContext = new QueryExecutionContext.Builder()
    .database("Database0")
    .catalog("Catalog6")
    .build();
```

