
# X Amz Target 13 Enum

## Enumeration

`XAmzTarget13Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEWORKGROUP` |

## Example

```python
from amazonathena.models.x_amz_target_13_enum import XAmzTarget13Enum

x_amz_target_13 = XAmzTarget13Enum.ENUM_AMAZONATHENADELETEWORKGROUP
```

