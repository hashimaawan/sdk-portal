
# X Amz Target 39

## Enumeration

`XAmzTarget39`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistnotebooksessions` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget39 := models.XAmzTarget39_EnumAmazonathenalistnotebooksessions

}
```

