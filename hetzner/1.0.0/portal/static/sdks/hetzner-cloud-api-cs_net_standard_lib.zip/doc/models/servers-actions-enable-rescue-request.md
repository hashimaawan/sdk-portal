
# Servers Actions Enable Rescue Request

## Structure

`ServersActionsEnableRescueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SshKeys` | `List<int>` | Optional | Array of SSH key IDs which should be injected into the rescue system. |
| `Type` | [`Type65Enum?`](../../doc/models/type-65-enum.md) | Optional | Type of rescue system to boot (default: `linux64`) |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

ServersActionsEnableRescueRequest serversActionsEnableRescueRequest = new ServersActionsEnableRescueRequest
{
    SshKeys = new List<int>
    {
        2323,
    },
    Type = Type65Enum.Linux64,
};
```

