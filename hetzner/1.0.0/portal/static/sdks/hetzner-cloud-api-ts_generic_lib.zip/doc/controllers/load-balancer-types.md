# Load Balancer Types

```ts
const loadBalancerTypesApi = new LoadBalancerTypesApi(client);
```

## Class Name

`LoadBalancerTypesApi`

## Methods

* [Get All Load Balancer Types](../../doc/controllers/load-balancer-types.md#get-all-load-balancer-types)
* [Get a Load Balancer Type](../../doc/controllers/load-balancer-types.md#get-a-load-balancer-type)


# Get All Load Balancer Types

Gets all Load Balancer type objects.

```ts
async getAllLoadBalancerTypes(
  name?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<LoadBalancerTypesResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Query, Optional | Can be used to filter Load Balancer types by their name. The response will only contain the Load Balancer type matching the specified name. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `load_balancer_types` key in the reply contains an array of Load Balancer type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`LoadBalancerTypesResponse`](../../doc/models/load-balancer-types-response.md).

## Example Usage

```ts
try {
  const response = await loadBalancerTypesApi.getAllLoadBalancerTypes();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```


# Get a Load Balancer Type

Gets a specific Load Balancer type object.

```ts
async getALoadBalancerType(
  id: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<LoadBalancerTypesResponse1>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of Load Balancer type |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `load_balancer_type` key in the reply contains a Load Balancer type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`LoadBalancerTypesResponse1`](../../doc/models/load-balancer-types-response-1.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await loadBalancerTypesApi.getALoadBalancerType(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

