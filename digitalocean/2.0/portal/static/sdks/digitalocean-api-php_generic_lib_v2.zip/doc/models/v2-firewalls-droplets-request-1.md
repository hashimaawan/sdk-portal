
# V2 Firewalls Droplets Request 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FirewallsDropletsRequest1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dropletIds` | `int[]` | Required | An array containing the IDs of the Droplets to be assigned to the firewall. | getDropletIds(): array | setDropletIds(array dropletIds): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FirewallsDropletsRequest1Builder;
use DigitalOceanApiLib\ApiHelper;

$v2FirewallsDropletsRequest1 = V2FirewallsDropletsRequest1Builder::init(
    [
        49696269
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

