
# Ssh Keys Response

*This model accepts additional fields of type Object.*

## Structure

`SshKeysResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Optional | - | Meta getMeta() | setMeta(Meta meta) |
| `SshKeys` | [`List<SshKey>`](../../doc/models/ssh-key.md) | Required | - | List<SshKey> getSshKeys() | setSshKeys(List<SshKey> sshKeys) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.Meta;
import cloud.hetzner.api.models.Pagination;
import cloud.hetzner.api.models.SshKey;
import cloud.hetzner.api.models.SshKeysResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedHashMap;

SshKeysResponse sshKeysResponse = new SshKeysResponse.Builder(
    Arrays.asList(
        new SshKey.Builder(
            "2016-01-30T23:55:00+00:00",
            "b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f",
            42,
            new LinkedHashMap<String, String>() {{
                put("key0", "labels4");
                put("key1", "labels5");
                put("key2", "labels6");
            }},
            "my-resource",
            "ssh-rsa AAAjjk76kgf...Xt"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.meta(new Meta.Builder(
        new Pagination.Builder(
            77.7D,
            209.18D,
            17.58D,
            13.34D,
            50.02D,
            206.64D
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

