
# V2 Kubernetes Registry Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2KubernetesRegistryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cluster_uuids` | `Array[String]` | Optional | An array containing the UUIDs of Kubernetes clusters. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_kubernetes_registry_request = V2KubernetesRegistryRequest.new(
  cluster_uuids: [
    'bd5f5959-5e1e-4205-a714-a914373942af',
    '50c2f44c-011d-493e-aee5-361a4a0d1844'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

