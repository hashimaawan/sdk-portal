
# V2 Images Actions Request 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ImagesActionsRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type15`](../../doc/models/type-15.md) | Required | The action to be taken on the image. Can be either `convert` or `transfer`. |
| `region` | [`Region2`](../../doc/models/region-2.md) | Required | The slug identifier for the region where the resource will initially be  available. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Region2,
  Type15,
  V2ImagesActionsRequest1,
} from 'digitalocean-apilib';

const v2ImagesActionsRequest1: V2ImagesActionsRequest1 = {
  type: Type15.Convert,
  region: Region2.Nyc3,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

