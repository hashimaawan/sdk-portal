
# Add Target Request

## Structure

`AddTargetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Ip` | [`*models.Ip`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. |
| `LabelSelector` | [`*models.LabelSelector12`](../../doc/models/label-selector-12.md) | Optional | Configuration for label selector targets, required if type is `label_selector` |
| `Server` | [`*models.Server16`](../../doc/models/server-16.md) | Optional | Configuration for type Server, required if type is `server` |
| `Type` | [`models.Type29Enum`](../../doc/models/type-29-enum.md) | Required | Type of the resource |
| `UsePrivateIp` | `*bool` | Optional | Use the private network IP instead of the public IP of the Server, requires the Server and Load Balancer to be in the same network. Default value is false. |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    addTargetRequest := models.AddTargetRequest{
        Ip:                   models.ToPointer(models.Ip{
            Ip:                   "ip8",
        }),
        LabelSelector:        models.ToPointer(models.LabelSelector12{
            Selector:             "selector8",
        }),
        Server:               models.ToPointer(models.Server16{
            Id: float64(217.74),
        }),
        Type:                 models.Type29Enum_SERVER,
        UsePrivateIp:         models.ToPointer(true),
    }

}
```

