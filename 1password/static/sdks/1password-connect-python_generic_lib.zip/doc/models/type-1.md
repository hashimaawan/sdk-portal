
# Type 1

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `STRING` |
| `EMAIL` |
| `CONCEALED` |
| `URL` |
| `TOTP` |
| `DATE` |
| `MONTH_YEAR` |
| `MENU` |

## Example

```python
from m1passwordconnect.models.type_1 import Type1

type_1 = Type1.TOTP
```

