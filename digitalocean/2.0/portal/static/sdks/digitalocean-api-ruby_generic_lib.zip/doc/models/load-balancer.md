
# Load Balancer

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`LoadBalancer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | The ID of a resource associated with a Kubernetes cluster. |
| `name` | `String` | Optional | The name of a resource associated with a Kubernetes cluster. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
load_balancer = LoadBalancer.new(
  id: 'edb0478d-7436-11ea-86e6-0a58ac144b91',
  name: 'volume-001',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

