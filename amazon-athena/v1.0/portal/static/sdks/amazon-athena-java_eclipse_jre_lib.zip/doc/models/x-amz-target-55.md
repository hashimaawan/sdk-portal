
# X Amz Target 55

## Enumeration

`XAmzTarget55`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget55;

XAmzTarget55 xAmzTarget55 = XAmzTarget55.ENUM_AMAZONATHENAUPDATENAMEDQUERY;
```

