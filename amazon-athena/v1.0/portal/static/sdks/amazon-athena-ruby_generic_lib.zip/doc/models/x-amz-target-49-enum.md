
# X Amz Target 49 Enum

## Enumeration

`XAmzTarget49Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```ruby
x_amz_target49 = XAmzTarget49Enum::ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION
```

