
# M Environment

The environment of the project's resources.

## Enumeration

`MEnvironment`

## Fields

| Name |
|  --- |
| `Development` |
| `Staging` |
| `Production` |

## Example

```ts
import { MEnvironment } from 'digitalocean-apilib';

const environment = MEnvironment.Staging;
```

