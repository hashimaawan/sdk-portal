
# Get Data Catalog Input

## Structure

`GetDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ts
import { GetDataCatalogInput } from 'amazon-athenalib';

const getDataCatalogInput: GetDataCatalogInput = {
  name: 'Name6',
};
```

