
# Health Status

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ListenPort` | `Integer` | Optional | - | Integer getListenPort() | setListenPort(Integer listenPort) |
| `Status` | [`Status30Enum`](../../doc/models/status-30-enum.md) | Optional | - | Status30Enum getStatus() | setStatus(Status30Enum status) |

## Example

```java
import cloud.hetzner.api.models.HealthStatus;
import cloud.hetzner.api.models.Status30Enum;

HealthStatus healthStatus = new HealthStatus.Builder()
    .listenPort(443)
    .status(Status30Enum.HEALTHY)
    .build();
```

