
# Sort

## Enumeration

`Sort`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Sort sort = Sort.EnumIdasc;
```

