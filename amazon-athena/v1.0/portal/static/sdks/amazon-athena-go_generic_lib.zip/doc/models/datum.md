
# Datum

A piece of data (a field in the table).

## Structure

`Datum`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `VarCharValue` | `*string` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    datum := models.Datum{
        VarCharValue:         models.ToPointer("VarCharValue8"),
    }

}
```

