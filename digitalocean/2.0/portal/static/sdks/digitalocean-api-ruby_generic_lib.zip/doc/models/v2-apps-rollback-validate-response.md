
# V2 Apps Rollback Validate Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AppsRollbackValidateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`Error`](../../doc/models/error.md) | Optional | - |
| `valid` | `TrueClass \| FalseClass` | Optional | Indicates whether the app can be rolled back to the specified deployment. |
| `warnings` | [`Array[Warning]`](../../doc/models/warning.md) | Optional | Contains a list of warnings that may cause the rollback to run under unideal circumstances. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_apps_rollback_validate_response = V2AppsRollbackValidateResponse.new(
  error: Error.new(
    code: Code::INCOMPATIBLE_PHASE,
    components: [
      'components3'
    ],
    message: 'message4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  valid: false,
  warnings: [
    Warning.new(
      code: Code::EXCEEDED_REVISION_LIMIT,
      components: [
        'components3'
      ],
      message: 'message4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

