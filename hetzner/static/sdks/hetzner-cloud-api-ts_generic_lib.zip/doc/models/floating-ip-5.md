
# Floating Ip 5

## Structure

`FloatingIp5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prices` | [`Price6[]`](../../doc/models/price-6.md) | Required | Floating IP type costs per Location |
| `type` | [`Type48Enum`](../../doc/models/type-48-enum.md) | Required | The type of the Floating IP |

## Example

```ts
import { FloatingIp5, Type48Enum } from 'hetzner-cloud-apilib';

const floatingIp5: FloatingIp5 = {
  prices: [
    {
      location: 'fsn1',
      priceMonthly: {
        gross: '1.1900000000000000',
        net: '1.0000000000',
      },
    }
  ],
  type: Type48Enum.Ipv4,
};
```

