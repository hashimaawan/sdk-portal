
# Region 2 Enum

## Enumeration

`Region2Enum`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    region2 := models.Region2Enum_CNNORTH1

}
```

