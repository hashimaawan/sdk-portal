
# Registry Type

- DOCKER_HUB: The DockerHub container registry type.
- DOCR: The DigitalOcean container registry type.

## Enumeration

`RegistryType`

## Fields

| Name |
|  --- |
| `DOCKER_HUB` |
| `DOCR` |

## Example

```python
from digitaloceanapi.models.registry_type import RegistryType

registry_type = RegistryType.DOCKER_HUB
```

