
# V21 Clicks Kubernetes Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V21ClicksKubernetesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | A message about the result of the request. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V21ClicksKubernetesResponse } from 'digitalocean-apilib';

const v21ClicksKubernetesResponse: V21ClicksKubernetesResponse = {
  message: 'Successfully kicked off addon job.',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

