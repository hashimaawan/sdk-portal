
# Type 24

Destination Image type to convert to

## Enumeration

`Type24`

## Fields

| Name |
|  --- |
| `Snapshot` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type24 := models.Type24_Snapshot

}
```

