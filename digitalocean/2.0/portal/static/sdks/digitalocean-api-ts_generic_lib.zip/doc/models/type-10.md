
# Type 10

The type of the IPv4 network interface.

## Enumeration

`Type10`

## Fields

| Name |
|  --- |
| `Public` |
| `Private` |

## Example

```ts
import { Type10 } from 'digitalocean-apilib';

const type10 = Type10.Public;
```

