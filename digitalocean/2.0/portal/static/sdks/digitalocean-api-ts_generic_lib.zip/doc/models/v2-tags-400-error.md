
# V2 Tags 400 Error

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2Tags400Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `string` | Required | A message providing information about the error. |
| `messages` | `string[] \| null \| undefined` | Optional | A list of error messages. |
| `rootCauses` | `string[]` | Required | A list of underlying causes for the error, including details to help  resolve it when possible. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof V2Tags400Error) {
    console.log(error.result);
  }
}
```

