
# X Amz Target 44 Enum

## Enumeration

`XAmzTarget44Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget44 := models.XAmzTarget44Enum_ENUMAMAZONATHENALISTTAGSFORRESOURCE

}
```

