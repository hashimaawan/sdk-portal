
# Attach Volume Request

## Structure

`AttachVolumeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `automount` | `?bool` | Optional | Auto-mount the Volume after attaching it | getAutomount(): ?bool | setAutomount(?bool automount): void |
| `server` | `int` | Required | ID of the Server the Volume will be attached to | getServer(): int | setServer(int server): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\AttachVolumeRequestBuilder;

$attachVolumeRequest = AttachVolumeRequestBuilder::init(
    43
)
    ->automount(false)
    ->build();
```

