
# Status 70

## Enumeration

`Status70`

## Fields

| Name |
|  --- |
| `INITIALIZING` |
| `STARTING` |
| `RUNNING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `REBUILDING` |
| `MIGRATING` |
| `UNKNOWN` |

## Example

```ruby
status70 = Status70::MIGRATING
```

