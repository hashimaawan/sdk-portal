
# Result Reuse Information

Contains information about whether the result of a previous query was reused.

## Structure

`ResultReuseInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reusedPreviousResult` | `bool` | Required | - | getReusedPreviousResult(): bool | setReusedPreviousResult(bool reusedPreviousResult): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultReuseInformationBuilder;

$resultReuseInformation = ResultReuseInformationBuilder::init(
    false
)->build();
```

