
# V2 Images Actions Request 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2ImagesActionsRequest1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type15)`](../../doc/models/type-15.md) | Required | The action to be taken on the image. Can be either `convert` or `transfer`. | getType(): string | setType(string type): void |
| `region` | [`string(Region2)`](../../doc/models/region-2.md) | Required | The slug identifier for the region where the resource will initially be  available. | getRegion(): string | setRegion(string region): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2ImagesActionsRequest1Builder;
use DigitalOceanApiLib\Models\Type15;
use DigitalOceanApiLib\Models\Region2;
use DigitalOceanApiLib\ApiHelper;

$v2ImagesActionsRequest1 = V2ImagesActionsRequest1Builder::init(
    Type15::CONVERT,
    Region2::NYC3
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

