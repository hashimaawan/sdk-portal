
# Environment

The environment of the project's resources.

## Enumeration

`Environment`

## Fields

| Name |
|  --- |
| `DEVELOPMENT` |
| `STAGING` |
| `PRODUCTION` |

## Example

```php
use DigitalOceanApiLib\Models\Environment;

$environment = Environment::STAGING;
```

