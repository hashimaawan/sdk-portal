
# Parameters

*This model accepts additional fields of type string.*

## Structure

`Parameters`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `additionalProperties` | `array<string, string>` | Optional | **Constraints**: *Maximum Length*: `51200` | findAdditionalProperty(string key): string | additionalProperty(string key, string value): void |

## Example (as JSON)

```json
{
  "exampleAdditionalProperty": "Parameters_additionalProperties2"
}
```

