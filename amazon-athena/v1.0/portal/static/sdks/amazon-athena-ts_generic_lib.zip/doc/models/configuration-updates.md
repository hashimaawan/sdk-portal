
# Configuration Updates

*This model accepts additional fields of type unknown.*

## Structure

`ConfigurationUpdates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enforceWorkGroupConfiguration` | `boolean \| undefined` | Optional | - |
| `resultConfigurationUpdates` | [`ResultConfigurationUpdates2 \| undefined`](../../doc/models/result-configuration-updates-2.md) | Optional | - |
| `publishCloudWatchMetricsEnabled` | `boolean \| undefined` | Optional | - |
| `bytesScannedCutoffPerQuery` | `number \| undefined` | Optional | **Constraints**: `>= 10000000` |
| `removeBytesScannedCutoffPerQuery` | `boolean \| undefined` | Optional | - |
| `requesterPaysEnabled` | `boolean \| undefined` | Optional | - |
| `engineVersion` | [`EngineVersion1 \| undefined`](../../doc/models/engine-version-1.md) | Optional | - |
| `removeCustomerContentEncryptionConfiguration` | `boolean \| undefined` | Optional | - |
| `additionalConfiguration` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `executionRole` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `20`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:iam::\d{12}:role/?[a-zA-Z_0-9+=,.@\-_/]+$` |
| `customerContentEncryptionConfiguration` | [`CustomerContentEncryptionConfiguration \| undefined`](../../doc/models/customer-content-encryption-configuration.md) | Optional | Specifies the KMS key that is used to encrypt the user's data stores in Athena. |
| `enableMinimumEncryptionConfiguration` | `boolean \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ConfigurationUpdates, EncryptionOption1 } from 'amazon-athenalib';

const configurationUpdates: ConfigurationUpdates = {
  enforceWorkGroupConfiguration: false,
  resultConfigurationUpdates: {
    outputLocation: 'OutputLocation0',
    removeOutputLocation: false,
    encryptionConfiguration: {
      encryptionOption: EncryptionOption1.SseS3,
      kmsKey: 'KmsKey6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    removeEncryptionConfiguration: false,
    expectedBucketOwner: 'ExpectedBucketOwner0',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  publishCloudWatchMetricsEnabled: false,
  bytesScannedCutoffPerQuery: 10000000,
  removeBytesScannedCutoffPerQuery: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

