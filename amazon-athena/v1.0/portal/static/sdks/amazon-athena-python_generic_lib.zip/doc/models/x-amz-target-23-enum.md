
# X Amz Target 23 Enum

## Enumeration

`XAmzTarget23Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_23_enum import XAmzTarget23Enum

x_amz_target_23 = XAmzTarget23Enum.ENUM_AMAZONATHENAGETQUERYEXECUTION
```

