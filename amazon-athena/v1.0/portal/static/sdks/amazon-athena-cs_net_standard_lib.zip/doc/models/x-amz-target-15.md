
# X Amz Target 15

## Enumeration

`XAmzTarget15`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecution` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget15 xAmzTarget15 = XAmzTarget15.EnumAmazonAthenaGetCalculationExecution;
```

