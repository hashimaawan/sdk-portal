
# Encryption Option

## Enumeration

`EncryptionOption`

## Fields

| Name |
|  --- |
| `SSE_S3` |
| `SSE_KMS` |
| `CSE_KMS` |

## Example

```ruby
encryption_option = EncryptionOption::SSE_KMS
```

