
# X Amz Target 21

## Enumeration

`XAmzTarget21`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_21 import XAmzTarget21

x_amz_target_21 = XAmzTarget21.ENUM_AMAZONATHENAGETNOTEBOOKMETADATA
```

