
# X Amz Target 44 Enum

## Enumeration

`XAmzTarget44Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget44Enum;

XAmzTarget44Enum xAmzTarget44 = XAmzTarget44Enum.ENUM_AMAZONATHENALISTTAGSFORRESOURCE;
```

