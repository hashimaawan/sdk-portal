
# X Amz Target 18

## Enumeration

`XAmzTarget18`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATACATALOG` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget18;

XAmzTarget18 xAmzTarget18 = XAmzTarget18.ENUM_AMAZONATHENAGETDATACATALOG;
```

