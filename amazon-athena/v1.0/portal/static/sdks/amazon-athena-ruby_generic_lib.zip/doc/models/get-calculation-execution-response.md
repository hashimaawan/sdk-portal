
# Get Calculation Execution Response

## Structure

`GetCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `session_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `working_directory` | `String` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` |
| `status` | [`Status1`](../../doc/models/status-1.md) | Optional | - |
| `statistics` | [`Statistics1`](../../doc/models/statistics-1.md) | Optional | - |
| `result` | [`Result`](../../doc/models/result.md) | Optional | - |

## Example

```ruby
get_calculation_execution_response = GetCalculationExecutionResponse.new(
  'CalculationExecutionId2',
  'SessionId6',
  'Description4',
  'WorkingDirectory0',
  Status1.new(
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    CalculationExecutionState1Enum::CANCELING,
    'StateChangeReason8'
  ),
  Statistics1.new,
  Result.new
)
```

