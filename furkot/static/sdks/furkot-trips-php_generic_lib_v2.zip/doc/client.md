
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| timeout | `int` | Timeout for API calls in seconds.<br>*Default*: `0` |
| enableRetries | `bool` | Whether to enable retries and backoff feature.<br>*Default*: `false` |
| numberOfRetries | `int` | The number of retries to make.<br>*Default*: `0` |
| retryInterval | `float` | The retry time interval between the endpoint calls.<br>*Default*: `1` |
| backOffFactor | `float` | Exponential backoff factor to increase interval between retries.<br>*Default*: `2` |
| maximumRetryWaitTime | `int` | The maximum wait time in seconds for overall retrying requests.<br>*Default*: `0` |
| retryOnTimeout | `bool` | Whether to retry on request timeout.<br>*Default*: `true` |
| httpStatusCodesToRetry | `array` | Http status codes to retry against.<br>*Default*: `408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524` |
| httpMethodsToRetry | `array` | Http methods to retry against.<br>*Default*: `'GET', 'PUT', 'GET', 'PUT'` |
| proxyConfiguration | [`ProxyConfigurationBuilder`](../doc/proxy-configuration-builder.md) | Represents the proxy configurations for API calls |
| furkotAuthAccessCodeCredentials | [`FurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |
| furkotAuthImplicitCredentials | [`FurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

```php
use FurkotTripsLib\Environment;
use FurkotTripsLib\Authentication\FurkotAuthAccessCodeCredentialsBuilder;
use FurkotTripsLib\Models\OAuthScopeFurkotAuthAccessCodeEnum;
use FurkotTripsLib\Authentication\FurkotAuthImplicitCredentialsBuilder;
use FurkotTripsLib\Models\OAuthScopeFurkotAuthImplicitEnum;
use FurkotTripsLib\FurkotTripsClientBuilder;

$client = FurkotTripsClientBuilder::init()
    ->furkotAuthAccessCodeCredentials(
        FurkotAuthAccessCodeCredentialsBuilder::init(
            'OAuthClientId',
            'OAuthClientSecret',
            'OAuthRedirectUri'
        )
            ->oAuthScopes(
                [
                    OAuthScopeFurkotAuthAccessCodeEnum::READTRIPS
                ]
            )
    )
    ->furkotAuthImplicitCredentials(
        FurkotAuthImplicitCredentialsBuilder::init(
            'OAuthClientId',
            'OAuthRedirectUri'
        )
            ->oAuthScopes(
                [
                    OAuthScopeFurkotAuthImplicitEnum::READTRIPS
                ]
            )
    )
    ->environment(Environment::PRODUCTION)
    ->build();
```

## Furkot Trips Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| getAPIController() | Gets APIController |
| getOAuthAuthorizationController() | Gets OAuthAuthorizationController |

