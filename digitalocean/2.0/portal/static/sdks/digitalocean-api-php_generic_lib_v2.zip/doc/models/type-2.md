
# Type 2

- GENERAL: A plain-text environment variable
- SECRET: A secret encrypted environment variable

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `GENERAL` |
| `SECRET` |

## Example

```php
use DigitalOceanApiLib\Models\Type2;

$type2 = Type2::GENERAL;
```

