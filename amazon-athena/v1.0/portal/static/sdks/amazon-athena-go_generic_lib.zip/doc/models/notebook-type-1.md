
# Notebook Type 1

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1`

## Fields

| Name |
|  --- |
| `Ipynb` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    notebookType1 := models.NotebookType1_Ipynb

}
```

