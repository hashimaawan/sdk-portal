
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `ITEM` |
| `VAULT` |

## Example

```php
use M1PasswordConnectLib\Models\Type;

$type = Type::ITEM;
```

