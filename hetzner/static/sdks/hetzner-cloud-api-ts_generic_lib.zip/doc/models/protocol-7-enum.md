
# Protocol 7 Enum

Protocol of the Load Balancer

## Enumeration

`Protocol7Enum`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |
| `Https` |

## Example

```ts
import { Protocol7Enum } from 'hetzner-cloud-apilib';

const protocol7 = Protocol7Enum.Http;
```

