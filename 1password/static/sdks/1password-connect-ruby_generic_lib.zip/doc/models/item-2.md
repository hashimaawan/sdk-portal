
# Item 2

*This model accepts additional fields of type Object.*

## Structure

`Item2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | **Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
item2 = Item2.new(
  id: 'id2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

