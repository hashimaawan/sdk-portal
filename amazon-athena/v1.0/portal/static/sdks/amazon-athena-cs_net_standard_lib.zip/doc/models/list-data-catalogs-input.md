
# List Data Catalogs Input

*This model accepts additional fields of type object.*

## Structure

`ListDataCatalogsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 2`, `<= 50` |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

ListDataCatalogsInput listDataCatalogsInput = new ListDataCatalogsInput
{
    NextToken = "NextToken8",
    MaxResults = 50,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

