
# V2 Databases Config Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesConfigRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `config` | [`V2DatabasesConfigRequestConfig \| undefined`](../../doc/models/containers/v2-databases-config-request-config.md) | Optional | This is a container for any-of cases. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2DatabasesConfigRequest } from 'digitalocean-apilib';

const v2DatabasesConfigRequest: V2DatabasesConfigRequest = {
  config: {
    backupHour: 23,
    backupMinute: 59,
    binlogRetentionPeriod: 600,
    connectTimeout: 196,
    defaultTimeZone: 'default_time_zone8',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

