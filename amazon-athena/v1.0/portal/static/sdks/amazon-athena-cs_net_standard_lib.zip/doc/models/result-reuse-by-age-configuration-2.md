
# Result Reuse by Age Configuration 2

## Structure

`ResultReuseByAgeConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Enabled` | `bool` | Required | - |
| `MaxAgeInMinutes` | `int?` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ResultReuseByAgeConfiguration2 resultReuseByAgeConfiguration2 = new ResultReuseByAgeConfiguration2
{
    Enabled = false,
    MaxAgeInMinutes = 44,
};
```

