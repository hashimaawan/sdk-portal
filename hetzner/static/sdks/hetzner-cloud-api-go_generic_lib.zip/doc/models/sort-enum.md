
# Sort Enum

## Enumeration

`SortEnum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUMIDASC` |
| `ENUMIDDESC` |
| `NAME` |
| `ENUMNAMEASC` |
| `ENUMNAMEDESC` |
| `CREATED` |
| `ENUMCREATEDASC` |
| `ENUMCREATEDDESC` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    sort := models.SortEnum_ENUMIDASC

}
```

