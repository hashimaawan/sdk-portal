
# List Prepared Statements Input

## Structure

`ListPreparedStatementsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `str` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `int` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```python
from amazonathena.models.list_prepared_statements_input import ListPreparedStatementsInput

list_prepared_statements_input = ListPreparedStatementsInput(
    work_group='WorkGroup2',
    next_token='NextToken0',
    max_results=50
)
```

