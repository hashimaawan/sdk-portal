
# Update Server Request

*This model accepts additional fields of type Object.*

## Structure

`UpdateServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New name to set |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
update_server_request = UpdateServerRequest.new(
  labels: { 'labelkey' => 'value' },
  name: 'my-server',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

