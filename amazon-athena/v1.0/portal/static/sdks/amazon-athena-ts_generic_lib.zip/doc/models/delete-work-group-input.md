
# Delete Work Group Input

*This model accepts additional fields of type unknown.*

## Structure

`DeleteWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `recursiveDeleteOption` | `boolean \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DeleteWorkGroupInput } from 'amazon-athenalib';

const deleteWorkGroupInput: DeleteWorkGroupInput = {
  workGroup: 'WorkGroup0',
  recursiveDeleteOption: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

