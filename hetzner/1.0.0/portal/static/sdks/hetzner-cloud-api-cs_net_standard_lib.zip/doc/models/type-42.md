
# Type 42

Type of Subnetwork

## Enumeration

`Type42`

## Fields

| Name |
|  --- |
| `Cloud` |
| `Server` |
| `Vswitch` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type42 type42 = Type42.Cloud;
```

