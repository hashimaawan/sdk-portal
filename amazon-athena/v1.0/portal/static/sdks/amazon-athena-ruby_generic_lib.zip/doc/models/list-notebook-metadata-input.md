
# List Notebook Metadata Input

## Structure

`ListNotebookMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filters` | [`Filters`](../../doc/models/filters.md) | Optional | - |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 50` |
| `work_group` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```ruby
list_notebook_metadata_input = ListNotebookMetadataInput.new(
  'WorkGroup6',
  Filters.new(
    'Name2'
  ),
  'NextToken4',
  50
)
```

