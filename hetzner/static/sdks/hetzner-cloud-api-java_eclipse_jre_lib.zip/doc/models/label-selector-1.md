
# Label Selector 1

Configuration for type LabelSelector, required if type is `label_selector`

## Structure

`LabelSelector1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Selector` | `String` | Required | Label selector | String getSelector() | setSelector(String selector) |

## Example

```java
import cloud.hetzner.api.models.LabelSelector1;

LabelSelector1 labelSelector1 = new LabelSelector1.Builder(
    "selector2"
)
.build();
```

