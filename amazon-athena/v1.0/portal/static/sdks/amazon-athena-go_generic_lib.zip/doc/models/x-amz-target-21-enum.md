
# X Amz Target 21 Enum

## Enumeration

`XAmzTarget21Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget21 := models.XAmzTarget21Enum_ENUMAMAZONATHENAGETNOTEBOOKMETADATA

}
```

