
# Get Database Output

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | [`Database2`](../../doc/models/database-2.md) | Optional | - |

## Example

```ruby
get_database_output = GetDatabaseOutput.new(
  Database2.new(
    'Name2',
    'Description8',
    Parameters.new
  )
)
```

