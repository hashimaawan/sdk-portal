
# X Amz Target 48

## Enumeration

`XAmzTarget48`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTSESSION` |

## Example

```python
from amazonathena.models.x_amz_target_48 import XAmzTarget48

x_amz_target_48 = XAmzTarget48.ENUM_AMAZONATHENASTARTSESSION
```

