
# V2 Monitoring Alerts Response

*This model accepts additional fields of type Object.*

## Structure

`V2MonitoringAlertsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Policies` | [`List<Policy>`](../../doc/models/policy.md) | Required | - | List<Policy> getPolicies() | setPolicies(List<Policy> policies) |
| `Links` | [`Links`](../../doc/models/links.md) | Optional | - | Links getLinks() | setLinks(Links links) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Required | - | Meta getMeta() | setMeta(Meta meta) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Alerts;
import com.digitalocean.api.models.Compare;
import com.digitalocean.api.models.Links;
import com.digitalocean.api.models.Meta;
import com.digitalocean.api.models.Pages;
import com.digitalocean.api.models.Policy;
import com.digitalocean.api.models.Slack;
import com.digitalocean.api.models.Type17;
import com.digitalocean.api.models.V2MonitoringAlertsResponse;
import com.digitalocean.api.models.Window1;
import com.digitalocean.api.models.containers.LinksPages;
import java.io.IOException;
import java.util.Arrays;

V2MonitoringAlertsResponse v2MonitoringAlertsResponse = new V2MonitoringAlertsResponse.Builder(
    Arrays.asList(
        new Policy.Builder(
            new Alerts.Builder(
                Arrays.asList(
                    "bob@exmaple.com"
                ),
                Arrays.asList(
                    new Slack.Builder(
                        "Production Alerts",
                        "https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ"
                    )
                    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                    .build()
                )
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            Compare.GREATERTHAN,
            "CPU Alert",
            true,
            Arrays.asList(
                "192018292"
            ),
            Arrays.asList(
                "droplet_tag"
            ),
            Type17.ENUM_V1INSIGHTSDROPLETCPU,
            "78b3da62-27e5-49ba-ac70-5db0b5935c64",
            80D,
            Window1.ENUM_5M
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ),
    new Meta.Builder(
        1
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.links(new Links.Builder()
        .pages(LinksPages.fromPages(
            new Pages.Builder()
                .last("last6")
                .next("next2")
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

