
# Statement Type

## Enumeration

`StatementType`

## Fields

| Name |
|  --- |
| `Ddl` |
| `Dml` |
| `Utility` |

## Example

```csharp
using AmazonAthena.Standard.Models;

StatementType statementType = StatementType.Ddl;
```

