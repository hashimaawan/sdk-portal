
# Sort 2

## Enumeration

`Sort2`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `CREATED` |
| `ENUM_CREATEDASC` |
| `ENUM_CREATEDDESC` |

## Example

```python
from hetznercloudapi.models.sort_2 import Sort2

sort_2 = Sort2.ID
```

