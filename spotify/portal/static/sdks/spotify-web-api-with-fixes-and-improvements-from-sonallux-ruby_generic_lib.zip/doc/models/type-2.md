
# Type 2

The object type: "track".

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `TRACK` |

## Example

```ruby
type2 = Type2::TRACK
```

