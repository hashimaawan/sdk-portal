
# X Amz Target 59

## Enumeration

`XAmzTarget59`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEWORKGROUP` |

## Example

```ruby
x_amz_target59 = XAmzTarget59::ENUM_AMAZONATHENAUPDATEWORKGROUP
```

