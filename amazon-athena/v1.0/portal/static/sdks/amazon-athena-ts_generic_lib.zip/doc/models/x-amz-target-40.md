
# X Amz Target 40

## Enumeration

`XAmzTarget40`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListPreparedStatements` |

## Example

```ts
import { XAmzTarget40 } from 'amazon-athenalib';

const xAmzTarget40 = XAmzTarget40.EnumAmazonAthenaListPreparedStatements;
```

