
# Load Balancers Actions Change Algorithm Request

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type39`](../../doc/models/type-39.md) | Required | Algorithm of the Load Balancer |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
load_balancers_actions_change_algorithm_request = LoadBalancersActionsChangeAlgorithmRequest.new(
  type: Type39::ROUND_ROBIN,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

