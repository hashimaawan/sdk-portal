
# List Engine Versions Input

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 10` |

## Example

```ruby
list_engine_versions_input = ListEngineVersionsInput.new(
  'NextToken0',
  10
)
```

