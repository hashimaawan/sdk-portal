
# Price Hourly 7

Hourly costs for a Primary IP type in this Location

*This model accepts additional fields of type interface{}.*

## Structure

`PriceHourly7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    priceHourly7 := models.PriceHourly7{
        Gross:                 "1.1900000000000000",
        Net:                   "1.0000000000",
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

