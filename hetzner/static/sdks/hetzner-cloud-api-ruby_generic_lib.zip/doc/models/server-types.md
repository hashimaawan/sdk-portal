
# Server Types

The Server types the Datacenter can handle

## Structure

`ServerTypes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `available` | `Array[Float]` | Required | IDs of Server types that are supported and for which the Datacenter has enough resources left |
| `available_for_migration` | `Array[Float]` | Required | IDs of Server types that are supported and for which the Datacenter has enough resources left |
| `supported` | `Array[Float]` | Required | IDs of Server types that are supported in the Datacenter |

## Example

```ruby
server_types = ServerTypes.new(
  [
    1,
    2,
    3
  ],
  [
    1,
    2,
    3
  ],
  [
    1,
    2,
    3
  ]
)
```

