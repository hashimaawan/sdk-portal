
# Health Status

*This model accepts additional fields of type Any.*

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listen_port` | `int` | Optional | - |
| `status` | [`Status30`](../../doc/models/status-30.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.health_status import HealthStatus
from hetznercloudapi.models.status_30 import Status30

health_status = HealthStatus(
    listen_port=443,
    status=Status30.HEALTHY,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

