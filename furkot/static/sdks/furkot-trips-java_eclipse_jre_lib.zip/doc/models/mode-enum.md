
# Mode Enum

travel mode

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```java
import com.furkot.trips.models.ModeEnum;

ModeEnum mode = ModeEnum.BICYCLE;
```

