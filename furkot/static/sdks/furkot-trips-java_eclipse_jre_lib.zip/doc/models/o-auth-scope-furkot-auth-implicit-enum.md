
# O Auth Scope Furkot Auth Implicit Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthImplicitEnum`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list users trips info |

## Example

```java
import com.furkot.trips.models.OAuthScopeFurkotAuthImplicitEnum;

OAuthScopeFurkotAuthImplicitEnum oAuthScopeFurkotAuthImplicit = OAuthScopeFurkotAuthImplicitEnum.READTRIPS;
```

