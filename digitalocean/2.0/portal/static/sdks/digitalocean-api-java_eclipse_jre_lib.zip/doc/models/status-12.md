
# Status 12

A status string indicating the current state of the load balancer. This can be `new`, `active`, or `errored`.

## Enumeration

`Status12`

## Fields

| Name |
|  --- |
| `ENUM_NEW` |
| `ACTIVE` |
| `ERRORED` |

## Example

```java
import com.digitalocean.api.models.Status12;

Status12 status12 = Status12.ENUM_NEW;
```

