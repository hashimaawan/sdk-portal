
# Private Net

## Structure

`PrivateNet`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip` | `String` | Optional | - |
| `network` | `Integer` | Optional | - |

## Example

```ruby
private_net = PrivateNet.new(
  '10.0.0.2',
  4711
)
```

