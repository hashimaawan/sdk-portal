
# V2 Vpcs Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2VpcsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpc` | [`Vpc \| undefined`](../../doc/models/vpc.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2VpcsResponse1 } from 'digitalocean-apilib';

const v2VpcsResponse1: V2VpcsResponse1 = {
  vpc: {
    description: 'description8',
    name: 'name2',
    ipRange: 'ip_range4',
    region: 'region8',
    mDefault: false,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

