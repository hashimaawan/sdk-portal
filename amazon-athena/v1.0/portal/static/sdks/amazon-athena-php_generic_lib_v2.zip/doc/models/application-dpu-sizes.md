
# Application DPU Sizes

Contains the application runtime IDs and their supported DPU sizes.

## Structure

`ApplicationDPUSizes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `applicationRuntimeId` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | getApplicationRuntimeId(): ?string | setApplicationRuntimeId(?string applicationRuntimeId): void |
| `supportedDPUSizes` | `?(int[])` | Optional | - | getSupportedDPUSizes(): ?array | setSupportedDPUSizes(?array supportedDPUSizes): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ApplicationDPUSizesBuilder;

$applicationDPUSizes = ApplicationDPUSizesBuilder::init()
    ->applicationRuntimeId('ApplicationRuntimeId2')
    ->supportedDPUSizes(
        [
            57
        ]
    )
    ->build();
```

