# Functions

[Serverless functions](https://docs.digitalocean.com/products/functions) are blocks of code that run on demand without the need to manage any infrastructure.
You can develop functions on your local machine and then deploy them to a namespace using `doctl`, the [official DigitalOcean CLI tool](https://docs.digitalocean.com/reference/doctl).

The Serverless Functions API currently only supports creating and managing namespaces.

```ruby
functions_api = client.functions
```

## Class Name

`FunctionsApi`

## Methods

* [Functions List Namespaces](../../doc/controllers/functions.md#functions-list-namespaces)
* [Functions Create Namespace](../../doc/controllers/functions.md#functions-create-namespace)
* [Functions Delete Namespace](../../doc/controllers/functions.md#functions-delete-namespace)
* [Functions Get Namespace](../../doc/controllers/functions.md#functions-get-namespace)
* [Functions List Triggers](../../doc/controllers/functions.md#functions-list-triggers)
* [Functions Create Trigger](../../doc/controllers/functions.md#functions-create-trigger)
* [Functions Delete Trigger](../../doc/controllers/functions.md#functions-delete-trigger)
* [Functions Get Trigger](../../doc/controllers/functions.md#functions-get-trigger)
* [Functions Update Trigger](../../doc/controllers/functions.md#functions-update-trigger)


# Functions List Namespaces

Returns a list of namespaces associated with the current user. To get all namespaces, send a GET request to `/v2/functions/namespaces`.

```ruby
def functions_list_namespaces
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: An array of JSON objects with a key called `namespaces`.  Each object represents a namespace and contains
the properties associated with it.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FunctionsNamespacesResponse`](../../doc/models/v2-functions-namespaces-response.md).

## Example Usage

```ruby
result = functions_api.functions_list_namespaces

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Functions Create Namespace

Creates a new serverless functions namespace in the desired region and associates it with the provided label. A namespace is a collection of functions and their associated packages, triggers, and project specifications. To create a namespace, send a POST request to `/v2/functions/namespaces` with the `region` and `label` properties.

```ruby
def functions_create_namespace(body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2FunctionsNamespacesRequest`](../../doc/models/v2-functions-namespaces-request.md) | Body, Required | - |

## Response Type

**200**: A JSON response object with a key called `namespace`. The object contains the properties associated
with the namespace.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FunctionsNamespacesResponse1`](../../doc/models/v2-functions-namespaces-response-1.md).

## Example Usage

```ruby
body = V2FunctionsNamespacesRequest.new(
  label: 'my namespace',
  region: 'nyc1'
)

result = functions_api.functions_create_namespace(body)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 422 | Limit Reached | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Functions Delete Namespace

Deletes the given namespace.  When a namespace is deleted all assets, in the namespace are deleted, this includes packages, functions and triggers. Deleting a namespace is a destructive operation and assets in the namespace are not recoverable after deletion. Some metadata is retained, such as activations, or soft deleted for reporting purposes.
To delete namespace, send a DELETE request to `/v2/functions/namespaces/$NAMESPACE_ID`.
A successful deletion returns a 204 response.

```ruby
def functions_delete_namespace(namespace_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace_id` | `String` | Template, Required | The ID of the namespace to be managed. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
namespace_id = 'fn-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

result = functions_api.functions_delete_namespace(namespace_id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Functions Get Namespace

Gets the namespace details for the given namespace UUID. To get namespace details, send a GET request to `/v2/functions/namespaces/$NAMESPACE_ID` with no parameters.

```ruby
def functions_get_namespace(namespace_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace_id` | `String` | Template, Required | The ID of the namespace to be managed. |

## Response Type

**200**: A JSON response object with a key called `namespace`. The object contains the properties associated
with the namespace.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FunctionsNamespacesResponse1`](../../doc/models/v2-functions-namespaces-response-1.md).

## Example Usage

```ruby
namespace_id = 'fn-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

result = functions_api.functions_get_namespace(namespace_id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 403 | Not Allowed. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Functions List Triggers

Returns a list of triggers associated with the current user and namespace. To get all triggers, send a GET request to `/v2/functions/namespaces/$NAMESPACE_ID/triggers`.

```ruby
def functions_list_triggers(namespace_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace_id` | `String` | Template, Required | The ID of the namespace to be managed. |

## Response Type

**200**: An array of JSON objects with a key called `namespaces`.  Each object represents a namespace and contains
the properties associated with it.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FunctionsNamespacesTriggersResponse`](../../doc/models/v2-functions-namespaces-triggers-response.md).

## Example Usage

```ruby
namespace_id = 'fn-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

result = functions_api.functions_list_triggers(namespace_id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Functions Create Trigger

Creates a new trigger for a given function in a namespace. To create a trigger, send a POST request to `/v2/functions/namespaces/$NAMESPACE_ID/triggers` with the `name`, `function`, `type`, `is_enabled` and `scheduled_details` properties.

```ruby
def functions_create_trigger(namespace_id,
                             body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace_id` | `String` | Template, Required | The ID of the namespace to be managed. |
| `body` | [`V2FunctionsNamespacesTriggersRequest`](../../doc/models/v2-functions-namespaces-triggers-request.md) | Body, Required | - |

## Response Type

**200**: A JSON response object with a key called `trigger`. The object contains the properties associated
with the trigger.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FunctionsNamespacesTriggersResponse1`](../../doc/models/v2-functions-namespaces-triggers-response-1.md).

## Example Usage

```ruby
namespace_id = 'fn-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

body = V2FunctionsNamespacesTriggersRequest.new(
  function: 'hello',
  is_enabled: true,
  name: 'my trigger',
  scheduled_details: ScheduledDetails.new(
    cron: '* * * * *'
  ),
  type: 'SCHEDULED'
)

result = functions_api.functions_create_trigger(
  namespace_id,
  body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 422 | Limit Reached | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Functions Delete Trigger

Deletes the given trigger.
To delete trigger, send a DELETE request to `/v2/functions/namespaces/$NAMESPACE_ID/triggers/$TRIGGER_NAME`.
A successful deletion returns a 204 response.

```ruby
def functions_delete_trigger(namespace_id,
                             trigger_name)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace_id` | `String` | Template, Required | The ID of the namespace to be managed. |
| `trigger_name` | `String` | Template, Required | The name of the trigger to be managed. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
namespace_id = 'fn-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

trigger_name = 'my trigger'

result = functions_api.functions_delete_trigger(
  namespace_id,
  trigger_name
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Functions Get Trigger

Gets the trigger details. To get the trigger details, send a GET request to `/v2/functions/namespaces/$NAMESPACE_ID/triggers/$TRIGGER_NAME`.

```ruby
def functions_get_trigger(namespace_id,
                          trigger_name)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace_id` | `String` | Template, Required | The ID of the namespace to be managed. |
| `trigger_name` | `String` | Template, Required | The name of the trigger to be managed. |

## Response Type

**200**: A JSON response object with a key called `trigger`. The object contains the properties associated
with the trigger.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FunctionsNamespacesTriggersResponse1`](../../doc/models/v2-functions-namespaces-triggers-response-1.md).

## Example Usage

```ruby
namespace_id = 'fn-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

trigger_name = 'my trigger'

result = functions_api.functions_get_trigger(
  namespace_id,
  trigger_name
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Functions Update Trigger

Updates the details of the given trigger. To update a trigger, send a PUT request to `/v2/functions/namespaces/$NAMESPACE_ID/triggers/$TRIGGER_NAME` with new values for the `is_enabled ` or `scheduled_details` properties.

```ruby
def functions_update_trigger(namespace_id,
                             trigger_name,
                             body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace_id` | `String` | Template, Required | The ID of the namespace to be managed. |
| `trigger_name` | `String` | Template, Required | The name of the trigger to be managed. |
| `body` | [`V2FunctionsNamespacesTriggersRequest1`](../../doc/models/v2-functions-namespaces-triggers-request-1.md) | Body, Required | - |

## Response Type

**200**: A JSON response object with a key called `trigger`. The object contains the properties associated
with the trigger.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FunctionsNamespacesTriggersResponse1`](../../doc/models/v2-functions-namespaces-triggers-response-1.md).

## Example Usage

```ruby
namespace_id = 'fn-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

trigger_name = 'my trigger'

body = V2FunctionsNamespacesTriggersRequest1.new(
  is_enabled: true
)

result = functions_api.functions_update_trigger(
  namespace_id,
  trigger_name,
  body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | Bad Request. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

