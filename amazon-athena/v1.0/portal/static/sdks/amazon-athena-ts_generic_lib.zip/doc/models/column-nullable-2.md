
# Column Nullable 2

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2`

## Fields

| Name |
|  --- |
| `NotNull` |
| `Nullable` |
| `Unknown` |

## Example

```ts
import { ColumnNullable2 } from 'amazon-athenalib';

const columnNullable2 = ColumnNullable2.NotNull;
```

