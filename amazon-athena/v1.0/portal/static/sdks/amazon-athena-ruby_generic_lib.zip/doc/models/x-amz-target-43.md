
# X Amz Target 43

## Enumeration

`XAmzTarget43`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTABLEMETADATA` |

## Example

```ruby
x_amz_target43 = XAmzTarget43::ENUM_AMAZONATHENALISTTABLEMETADATA
```

