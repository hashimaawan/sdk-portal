
# Update Data Catalog Input

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `type` | [`DataCatalogType3Enum`](../../doc/models/data-catalog-type-3-enum.md) | Required | - |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```ruby
update_data_catalog_input = UpdateDataCatalogInput.new(
  'Name0',
  DataCatalogType3Enum::HIVE,
  'Description6',
  Parameters.new
)
```

