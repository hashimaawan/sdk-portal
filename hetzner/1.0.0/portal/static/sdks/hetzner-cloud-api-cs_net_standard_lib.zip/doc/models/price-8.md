
# Price 8

*This model accepts additional fields of type object.*

## Structure

`Price8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Location` | `string` | Required | Name of the Location the price is for |
| `PriceHourly` | [`PriceHourly7`](../../doc/models/price-hourly-7.md) | Required | Hourly costs for a Primary IP type in this Location |
| `PriceMonthly` | [`PriceMonthly9`](../../doc/models/price-monthly-9.md) | Required | Monthly costs for a Primary IP type in this Location |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

Price8 price8 = new Price8
{
    Location = "fsn1",
    PriceHourly = new PriceHourly7
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    PriceMonthly = new PriceMonthly9
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

