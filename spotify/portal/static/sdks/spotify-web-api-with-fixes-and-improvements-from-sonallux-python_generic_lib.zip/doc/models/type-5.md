
# Type 5

The object type.

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `AUDIO_FEATURES` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.type_5 import Type5

type_5 = Type5.AUDIO_FEATURES
```

