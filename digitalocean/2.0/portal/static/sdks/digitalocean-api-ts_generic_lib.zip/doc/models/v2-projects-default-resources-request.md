
# V2 Projects Default Resources Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ProjectsDefaultResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resources` | `string[] \| undefined` | Optional | A list of uniform resource names (URNs) to be added to a project.<br><br>**Constraints**: *Pattern*: `^do:(dbaas\|domain\|droplet\|floatingip\|loadbalancer\|space\|volume\|kubernetes\|vpc):.*` |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2ProjectsDefaultResourcesRequest } from 'digitalocean-apilib';

const v2ProjectsDefaultResourcesRequest: V2ProjectsDefaultResourcesRequest = {
  resources: [
    'do:droplet:13457723'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

