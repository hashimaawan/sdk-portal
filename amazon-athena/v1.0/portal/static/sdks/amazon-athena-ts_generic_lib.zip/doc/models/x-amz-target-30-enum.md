
# X Amz Target 30 Enum

## Enumeration

`XAmzTarget30Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaImportNotebook` |

## Example

```ts
import { XAmzTarget30Enum } from 'amazon-athenalib';

const xAmzTarget30 = XAmzTarget30Enum.EnumAmazonAthenaImportNotebook;
```

