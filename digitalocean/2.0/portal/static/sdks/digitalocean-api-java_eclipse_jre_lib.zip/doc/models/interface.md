
# Interface

## Enumeration

`Interface`

## Fields

| Name |
|  --- |
| `ENUM_PRIVATE` |
| `ENUM_PUBLIC` |

## Example

```java
import com.digitalocean.api.models.Interface;

Interface mInterface = Interface.ENUM_PRIVATE;
```

