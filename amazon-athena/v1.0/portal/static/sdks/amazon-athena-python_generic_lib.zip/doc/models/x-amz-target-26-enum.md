
# X Amz Target 26 Enum

## Enumeration

`XAmzTarget26Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSION` |

## Example

```python
from amazonathena.models.x_amz_target_26_enum import XAmzTarget26Enum

x_amz_target_26 = XAmzTarget26Enum.ENUM_AMAZONATHENAGETSESSION
```

