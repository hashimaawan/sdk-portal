
# Timescaledb

TimescaleDB extension configuration values

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Timescaledb`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `maxBackgroundWorkers` | `?int` | Optional | The number of background workers for timescaledb operations.  Set to the sum of your number of databases and the total number of concurrent background workers you want running at any given point in time.<br><br>**Constraints**: `>= 1`, `<= 4096` | getMaxBackgroundWorkers(): ?int | setMaxBackgroundWorkers(?int maxBackgroundWorkers): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\TimescaledbBuilder;
use DigitalOceanApiLib\ApiHelper;

$timescaledb = TimescaledbBuilder::init()
    ->maxBackgroundWorkers(8)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

