
# Node

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Node`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `createdAt` | `string \| undefined` | Optional | A time value given in ISO8601 combined date and time format that represents when the node was created. |
| `dropletId` | `string \| undefined` | Optional | The ID of the Droplet used for the worker node. |
| `id` | `string \| undefined` | Optional | A unique ID that can be used to identify and reference the node. |
| `name` | `string \| undefined` | Optional | An automatically generated, human-readable name for the node. |
| `status` | [`Status10 \| undefined`](../../doc/models/status-10.md) | Optional | An object containing a `state` attribute whose value is set to a string indicating the current status of the node. |
| `updatedAt` | `string \| undefined` | Optional | A time value given in ISO8601 combined date and time format that represents when the node was last updated. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Node, State1 } from 'digitalocean-apilib';

const node: Node = {
  createdAt: '2018-11-15T16:00:11Z',
  dropletId: '205545370',
  id: 'e78247f8-b1bb-4f7a-8db9-2a5f8d4b8f8f',
  name: 'adoring-newton-3niq',
  status: {
    state: State1.Provisioning,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  updatedAt: '2018-11-15T16:00:11Z',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

