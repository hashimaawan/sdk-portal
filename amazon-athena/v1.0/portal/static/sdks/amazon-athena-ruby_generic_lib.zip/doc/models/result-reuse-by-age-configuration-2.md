
# Result Reuse by Age Configuration 2

## Structure

`ResultReuseByAgeConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enabled` | `TrueClass \| FalseClass` | Required | - |
| `max_age_in_minutes` | `Integer` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```ruby
result_reuse_by_age_configuration2 = ResultReuseByAgeConfiguration2.new(
  false,
  254
)
```

