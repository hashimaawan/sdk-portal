
# Prepared Statement 1

## Structure

`PreparedStatement1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StatementName` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `QueryStatement` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `WorkGroupName` | `*string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `LastModifiedTime` | `*time.Time` | Optional | - |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonathena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    preparedStatement1 := models.PreparedStatement1{
        StatementName:        models.ToPointer("StatementName6"),
        QueryStatement:       models.ToPointer("QueryStatement0"),
        WorkGroupName:        models.ToPointer("WorkGroupName0"),
        Description:          models.ToPointer("Description8"),
        LastModifiedTime:     models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
    }

}
```

