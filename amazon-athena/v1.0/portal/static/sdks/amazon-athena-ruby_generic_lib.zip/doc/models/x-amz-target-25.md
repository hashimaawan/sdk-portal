
# X Amz Target 25

## Enumeration

`XAmzTarget25`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```ruby
x_amz_target25 = XAmzTarget25::ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS
```

