
# List Notebook Metadata Output

## Structure

`ListNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `notebookMetadataList` | [`NotebookMetadata[] \| undefined`](../../doc/models/notebook-metadata.md) | Optional | - |

## Example

```ts
import {
  ListNotebookMetadataOutput,
  NotebookType1Enum,
} from 'amazon-athenalib';

const listNotebookMetadataOutput: ListNotebookMetadataOutput = {
  nextToken: 'NextToken2',
  notebookMetadataList: [
    {
      notebookId: 'NotebookId4',
      name: 'Name4',
      workGroup: 'WorkGroup6',
      creationTime: '2016-03-13T12:52:32.123Z',
      type: NotebookType1Enum.IPYNB,
    }
  ],
};
```

