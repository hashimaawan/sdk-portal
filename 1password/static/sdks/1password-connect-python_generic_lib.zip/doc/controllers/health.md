# Health

```python
health_api = client.health
```

## Class Name

`HealthApi`

## Methods

* [Get Server Health](../../doc/controllers/health.md#get-server-health)
* [Get Heartbeat](../../doc/controllers/health.md#get-heartbeat)


# Get Server Health

:information_source: **Note** This endpoint does not require authentication.

```python
def get_server_health(self)
```

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`HealthResponse`](../../doc/models/health-response.md).

## Example Usage

```python
result = health_api.get_server_health()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Example Response *(as JSON)*

```json
{
  "dependencies": [
    {
      "service": "sync",
      "status": "TOKEN_NEEDED"
    },
    {
      "message": "Connected to./1password.sqlite",
      "service": "sqlite",
      "status": "ACTIVE"
    }
  ],
  "name": "1Password Connect API",
  "version": "1.2.1"
}
```


# Get Heartbeat

:information_source: **Note** This endpoint does not require authentication.

```python
def get_heartbeat(self)
```

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `str`.

## Example Usage

```python
result = health_api.get_heartbeat()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

