# Load Balancer Actions

```php
$loadBalancerActionsController = $client->getLoadBalancerActionsController();
```

## Class Name

`LoadBalancerActionsController`

## Methods

* [Get All Actions for a Load Balancer](../../doc/controllers/load-balancer-actions.md#get-all-actions-for-a-load-balancer)
* [Add Service](../../doc/controllers/load-balancer-actions.md#add-service)
* [Add Target](../../doc/controllers/load-balancer-actions.md#add-target)
* [Attach a Load Balancer to a Network](../../doc/controllers/load-balancer-actions.md#attach-a-load-balancer-to-a-network)
* [Change Algorithm](../../doc/controllers/load-balancer-actions.md#change-algorithm)
* [Change Reverse DNS Entry for This Load Balancer](../../doc/controllers/load-balancer-actions.md#change-reverse-dns-entry-for-this-load-balancer)
* [Change Load Balancer Protection](../../doc/controllers/load-balancer-actions.md#change-load-balancer-protection)
* [Change the Type of a Load Balancer](../../doc/controllers/load-balancer-actions.md#change-the-type-of-a-load-balancer)
* [Delete Service](../../doc/controllers/load-balancer-actions.md#delete-service)
* [Detach a Load Balancer from a Network](../../doc/controllers/load-balancer-actions.md#detach-a-load-balancer-from-a-network)
* [Disable the Public Interface of a Load Balancer](../../doc/controllers/load-balancer-actions.md#disable-the-public-interface-of-a-load-balancer)
* [Enable the Public Interface of a Load Balancer](../../doc/controllers/load-balancer-actions.md#enable-the-public-interface-of-a-load-balancer)
* [Remove Target](../../doc/controllers/load-balancer-actions.md#remove-target)
* [Update Service](../../doc/controllers/load-balancer-actions.md#update-service)
* [Get an Action for a Load Balancer](../../doc/controllers/load-balancer-actions.md#get-an-action-for-a-load-balancer)


# Get All Actions for a Load Balancer

Returns all Action objects for a Load Balancer. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```php
function getAllActionsForALoadBalancer(int $id, ?string $sort = null, ?string $status = null): ActionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `sort` | [`?string(ParameterSortEnum)`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`?string(ParameterStatusEnum)`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```php
$id = 112;

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->getAllActionsForALoadBalancer($id);
    echo 'ActionsResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "add_service",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 4711,
          "type": "load_balancer"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Add Service

Adds a service to a Load Balancer.

#### Call specific error codes

| Code                       | Description                                             |
|----------------------------|---------------------------------------------------------|
| `source_port_already_used` | The source port you are trying to add is already in use |

```php
function addService(int $id, ?LoadBalancerService $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?LoadBalancerService`](../../doc/models/load-balancer-service.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `add_service` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = LoadBalancerServiceBuilder::init(
    80,
    LoadBalancerServiceHealthCheckBuilder::init(
        15,
        4711,
        Protocol6Enum::HTTP,
        3,
        10
    )->build(),
    443,
    Protocol7Enum::HTTPS,
    false
)->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->addService(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Add Target

Adds a target to a Load Balancer.

#### Call specific error codes

| Code                                    | Description                                                                                           |
|-----------------------------------------|-------------------------------------------------------------------------------------------------------|
| `cloud_resource_ip_not_allowed`         | The IP you are trying to add as a target belongs to a Hetzner Cloud resource                          |
| `ip_not_owned`                          | The IP you are trying to add as a target is not owned by the Project owner                            |
| `load_balancer_not_attached_to_network` | The Load Balancer is not attached to a network                                                        |
| `robot_unavailable`                     | Robot was not available. The caller may retry the operation after a short delay.                      |
| `server_not_attached_to_network`        | The server you are trying to add as a target is not attached to the same network as the Load Balancer |
| `target_already_defined`                | The Load Balancer target you are trying to define is already defined                                  |

```php
function addTarget(int $id, ?AddTargetRequest $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?AddTargetRequest`](../../doc/models/add-target-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `add_target` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = AddTargetRequestBuilder::init(
    Type29Enum::LABEL_SELECTOR
)
    ->usePrivateIp(true)
    ->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->addTarget(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_target",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Attach a Load Balancer to a Network

Attach a Load Balancer to a Network.

**Call specific error codes**

| Code                             | Description                                                           |
|----------------------------------|-----------------------------------------------------------------------|
| `load_balancer_already_attached` | The Load Balancer is already attached to a network                    |
| `ip_not_available`               | The provided Network IP is not available                              |
| `no_subnet_available`            | No Subnet or IP is available for the Load Balancer within the network |

```php
function attachALoadBalancerToANetwork(
    int $id,
    ?LoadBalancersActionsAttachToNetworkRequest $body = null
): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?LoadBalancersActionsAttachToNetworkRequest`](../../doc/models/load-balancers-actions-attach-to-network-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `attach_to_network` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = LoadBalancersActionsAttachToNetworkRequestBuilder::init(
    4711
)
    ->ip('10.0.1.1')
    ->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->attachALoadBalancerToANetwork(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_to_network",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Algorithm

Change the algorithm that determines to which target new requests are sent.

```php
function changeAlgorithm(int $id, ?LoadBalancersActionsChangeAlgorithmRequest $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?LoadBalancersActionsChangeAlgorithmRequest`](../../doc/models/load-balancers-actions-change-algorithm-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_algorithm` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->changeAlgorithm($id);
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_algorithm",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Reverse DNS Entry for This Load Balancer

Changes the hostname that will appear when getting the hostname belonging to the public IPs (IPv4 and IPv6) of this Load Balancer.

Floating IPs assigned to the Server are not affected by this.

```php
function changeReverseDNSEntryForThisLoadBalancer(
    int $id,
    ?ChangeLoadbalancerDnsPtrRequest $body = null
): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?ChangeLoadbalancerDnsPtrRequest`](../../doc/models/change-loadbalancer-dns-ptr-request.md) | Body, Optional | Select the IP address for which to change the DNS entry by passing `ip`. It can be either IPv4 or IPv6. The target hostname is set by passing `dns_ptr`. |

## Response Type

**201**: The `action` key in the reply contains an Action object with this structure

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = ChangeLoadbalancerDnsPtrRequestBuilder::init(
    '1.2.3.4'
)
    ->dnsPtr('lb1.example.com')
    ->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->changeReverseDNSEntryForThisLoadBalancer(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_dns_ptr",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Load Balancer Protection

Changes the protection configuration of a Load Balancer.

```php
function changeLoadBalancerProtection(
    int $id,
    ?LoadBalancersActionsChangeProtectionRequest $body = null
): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?LoadBalancersActionsChangeProtectionRequest`](../../doc/models/load-balancers-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = LoadBalancersActionsChangeProtectionRequestBuilder::init()
    ->delete(true)
    ->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->changeLoadBalancerProtection(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change the Type of a Load Balancer

Changes the type (Max Services, Max Targets and Max Connections) of a Load Balancer.

**Call specific error codes**

| Code                         | Description                                                     |
|------------------------------|-----------------------------------------------------------------|
| `invalid_load_balancer_type` | The Load Balancer type does not fit for the given Load Balancer |

```php
function changeTheTypeOfALoadBalancer(int $id, ?ChangeTypeRequest $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?ChangeTypeRequest`](../../doc/models/change-type-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_load_balancer_type` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = ChangeTypeRequestBuilder::init(
    'lb21'
)->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->changeTheTypeOfALoadBalancer(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_load_balancer_type",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Delete Service

Delete a service of a Load Balancer.

```php
function deleteService(int $id, ?LoadBalancersActionsDeleteServiceRequest $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?LoadBalancersActionsDeleteServiceRequest`](../../doc/models/load-balancers-actions-delete-service-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `delete_service` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = LoadBalancersActionsDeleteServiceRequestBuilder::init(
    4711
)->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->deleteService(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "delete_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Detach a Load Balancer from a Network

Detaches a Load Balancer from a network.

```php
function detachALoadBalancerFromANetwork(
    int $id,
    ?LoadBalancersActionsDetachFromNetworkRequest $body = null
): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?LoadBalancersActionsDetachFromNetworkRequest`](../../doc/models/load-balancers-actions-detach-from-network-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `detach_from_network` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = LoadBalancersActionsDetachFromNetworkRequestBuilder::init(
    4711
)->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->detachALoadBalancerFromANetwork(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "detach_from_network",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Disable the Public Interface of a Load Balancer

Disable the public interface of a Load Balancer. The Load Balancer will be not accessible from the internet via its public IPs.

#### Call specific error codes

| Code                                      | Description                                                                    |
|-------------------------------------------|--------------------------------------------------------------------------------|
| `load_balancer_not_attached_to_network`   |  The Load Balancer is not attached to a network                                |
| `targets_without_use_private_ip`          | The Load Balancer has targets that use the public IP instead of the private IP |

```php
function disableThePublicInterfaceOfALoadBalancer(int $id): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |

## Response Type

**201**: The `action` key contains the `disable_public_interface` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->disableThePublicInterfaceOfALoadBalancer($id);
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "disable_public_interface",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Enable the Public Interface of a Load Balancer

Enable the public interface of a Load Balancer. The Load Balancer will be accessible from the internet via its public IPs.

```php
function enableThePublicInterfaceOfALoadBalancer(int $id): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |

## Response Type

**201**: The `action` key contains the `enable_public_interface` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->enableThePublicInterfaceOfALoadBalancer($id);
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "enable_public_interface",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Remove Target

Removes a target from a Load Balancer.

```php
function removeTarget(int $id, ?RemoveTargetRequest $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?RemoveTargetRequest`](../../doc/models/remove-target-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `remove_target` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->removeTarget($id);
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "remove_target",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Update Service

Updates a Load Balancer Service.

#### Call specific error codes

| Code                       | Description                                             |
|----------------------------|---------------------------------------------------------|
| `source_port_already_used` | The source port you are trying to add is already in use |

```php
function updateService(int $id, ?LoadBalancerService $body = null): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?LoadBalancerService`](../../doc/models/load-balancer-service.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `update_service` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$body = LoadBalancerServiceBuilder::init(
    80,
    LoadBalancerServiceHealthCheckBuilder::init(
        15,
        4711,
        Protocol6Enum::HTTP,
        3,
        10
    )->build(),
    443,
    Protocol7Enum::HTTPS,
    false
)->build();

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->updateService(
        $id,
        $body
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "update_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for a Load Balancer

Returns a specific Action for a Load Balancer.

```php
function getAnActionForALoadBalancer(int $id, int $actionId): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Load Balancer Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$actionId = 224;

$loadBalancerActionsController = $client->getLoadBalancerActionsController();

try {
    $result = $loadBalancerActionsController->getAnActionForALoadBalancer(
        $id,
        $actionId
    );
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

