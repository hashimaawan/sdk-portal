
# Create Image Request

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Optional | Description of the Image, will be auto-generated if not set |
| `labels` | [`Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `mtype` | [`Type63Enum`](../../doc/models/type-63-enum.md) | Optional | Type of Image to create (default: `snapshot`) |

## Example

```python
from hetznercloudapi.models.create_image_request import CreateImageRequest
from hetznercloudapi.models.labels import Labels
from hetznercloudapi.models.type_63_enum import Type63Enum

create_image_request = CreateImageRequest(
    description='my image',
    labels=Labels(
        labelkey='labelkey4'
    ),
    mtype=Type63Enum.SNAPSHOT
)
```

