
# Status 23 Enum

## Enumeration

`Status23Enum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    status23 := models.Status23Enum_AVAILABLE

}
```

