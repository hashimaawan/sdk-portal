
# Type 41 Enum

## Enumeration

`Type41Enum`

## Fields

| Name |
|  --- |
| `OpenConnections` |
| `ConnectionsPerSecond` |
| `RequestsPerSecond` |
| `Bandwidth` |

## Example

```ts
import { Type41Enum } from 'hetzner-cloud-apilib';

const type41 = Type41Enum.RequestsPerSecond;
```

