
# Price Monthly 8

Monthly costs for a Load Balancer type in this network zone

## Structure

`PriceMonthly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `String` | Required | Price with VAT added |
| `net` | `String` | Required | Price without VAT |

## Example

```ruby
price_monthly8 = PriceMonthly8.new(
  '1.1900000000000000',
  '1.0000000000'
)
```

