
# V2 Droplets Actions Request

Specifies the action that will be taken on the Droplet.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type12, V2DropletsActionsRequest } from 'digitalocean-apilib';

const v2DropletsActionsRequest: V2DropletsActionsRequest = {
  type: Type12.Reboot,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

