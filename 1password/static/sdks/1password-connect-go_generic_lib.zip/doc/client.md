
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```go
package main

import (
    "m1PasswordConnect"
)

func main() {
    client := m1PasswordConnect.NewClient(
    m1PasswordConnect.CreateConfiguration(
            m1PasswordConnect.WithHttpConfiguration(
                m1PasswordConnect.CreateHttpConfiguration(
                    m1PasswordConnect.WithTimeout(30),
                ),
            ),
            m1PasswordConnect.WithEnvironment(m1PasswordConnect.PRODUCTION),
            m1PasswordConnect.WithBearerAuthCredentials(
                m1PasswordConnect.NewBearerAuthCredentials("AccessToken"),
            ),
            m1PasswordConnect.WithLoggerConfiguration(
                m1PasswordConnect.WithLevel("info"),
                m1PasswordConnect.WithRequestConfiguration(
                    m1PasswordConnect.WithRequestBody(true),
                ),
                m1PasswordConnect.WithResponseConfiguration(
                    m1PasswordConnect.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## 1Password Connect Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| ItemsApi() | Gets ItemsApi |
| VaultsApi() | Gets VaultsApi |
| ActivityApi() | Gets ActivityApi |
| HealthApi() | Gets HealthApi |
| MetricsApi() | Gets MetricsApi |
| FilesApi() | Gets FilesApi |

