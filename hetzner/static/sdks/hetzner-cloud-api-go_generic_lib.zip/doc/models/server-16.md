
# Server 16

Configuration for type Server, required if type is `server`

## Structure

`Server16`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `float64` | Required | ID of the Server |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    server16 := models.Server16{
        Id: float64(80),
    }

}
```

