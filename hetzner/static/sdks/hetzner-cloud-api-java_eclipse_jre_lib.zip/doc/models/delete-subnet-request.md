
# Delete Subnet Request

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IpRange` | `String` | Required | IP range of subnet to delete | String getIpRange() | setIpRange(String ipRange) |

## Example

```java
import cloud.hetzner.api.models.DeleteSubnetRequest;

DeleteSubnetRequest deleteSubnetRequest = new DeleteSubnetRequest.Builder(
    "10.0.1.0/24"
)
.build();
```

