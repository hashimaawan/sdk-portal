
# Effect

How the node reacts to pods that it won't tolerate. Available effect values are `NoSchedule`, `PreferNoSchedule`, and `NoExecute`.

## Enumeration

`Effect`

## Fields

| Name |
|  --- |
| `NOSCHEDULE` |
| `PREFERNOSCHEDULE` |
| `NOEXECUTE` |

## Example

```ruby
effect = Effect::NOSCHEDULE
```

