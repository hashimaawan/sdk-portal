
# Update Server Request

*This model accepts additional fields of type unknown.*

## Structure

`UpdateServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New name to set |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UpdateServerRequest } from 'hetzner-cloud-apilib';

const updateServerRequest: UpdateServerRequest = {
  labels: { 'labelkey': 'value' },
  name: 'my-server',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

