
# Type 2

- GENERAL: A plain-text environment variable
- SECRET: A secret encrypted environment variable

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `GENERAL` |
| `SECRET` |

## Example

```ruby
type2 = Type2::GENERAL
```

