
# Create Placement Group Request

## Structure

`CreatePlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labels` | `object` | Optional | User-defined labels (key-value pairs) |
| `Name` | `string` | Required | Name of the PlacementGroup |
| `Type` | `string` | Required, Constant | Define the Placement Group Type.<br><br>**Value**: `"spread"` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using HetznerCloudAPI.Standard.Utilities;

CreatePlacementGroupRequest createPlacementGroupRequest = new CreatePlacementGroupRequest
{
    Name = "my Placement Group",
    Type = "spread",
    Labels = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

