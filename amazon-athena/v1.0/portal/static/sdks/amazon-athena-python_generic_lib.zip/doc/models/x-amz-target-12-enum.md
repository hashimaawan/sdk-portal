
# X Amz Target 12 Enum

## Enumeration

`XAmzTarget12Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_12_enum import XAmzTarget12Enum

x_amz_target_12 = XAmzTarget12Enum.ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT
```

