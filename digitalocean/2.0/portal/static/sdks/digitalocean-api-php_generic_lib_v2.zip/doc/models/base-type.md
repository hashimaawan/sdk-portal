
# Base Type

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`BaseType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | - | getType(): ?string | setType(?string type): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\BaseTypeBuilder;
use DigitalOceanApiLib\ApiHelper;

$baseType = BaseTypeBuilder::init()
    ->type('BaseType')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

