
# Filters

## Structure

`Filters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```ts
import { Filters } from 'amazon-athenalib';

const filters: Filters = {
  name: 'Name0',
};
```

