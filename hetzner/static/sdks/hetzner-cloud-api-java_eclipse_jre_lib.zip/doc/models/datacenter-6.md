
# Datacenter 6

Datacenter this Resource is located at

## Structure

`Datacenter6`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Description` | `String` | Required | Description of the Datacenter | String getDescription() | setDescription(String description) |
| `Id` | `int` | Required | ID of the Resource | int getId() | setId(int id) |
| `Location` | [`Location`](../../doc/models/location.md) | Required | - | Location getLocation() | setLocation(Location location) |
| `Name` | `String` | Required | Unique identifier of the Datacenter | String getName() | setName(String name) |
| `ServerTypes` | [`ServerTypes`](../../doc/models/server-types.md) | Required | The Server types the Datacenter can handle | ServerTypes getServerTypes() | setServerTypes(ServerTypes serverTypes) |

## Example

```java
import cloud.hetzner.api.models.Datacenter6;
import cloud.hetzner.api.models.Location;
import cloud.hetzner.api.models.ServerTypes;
import java.util.Arrays;

Datacenter6 datacenter6 = new Datacenter6.Builder(
    "Falkenstein DC Park 8",
    42,
    new Location.Builder(
        "Falkenstein",
        "DE",
        "Falkenstein DC Park 1",
        1D,
        50.47612D,
        12.370071D,
        "fsn1",
        "eu-central"
    )
    .build(),
    "fsn1-dc8",
    new ServerTypes.Builder(
        Arrays.asList(
            1D,
            2D,
            3D
        ),
        Arrays.asList(
            1D,
            2D,
            3D
        ),
        Arrays.asList(
            1D,
            2D,
            3D
        )
    )
    .build()
)
.build();
```

