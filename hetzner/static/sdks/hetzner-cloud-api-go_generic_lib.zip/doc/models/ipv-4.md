
# Ipv 4

IP address (v4)

## Structure

`Ipv4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DnsPtr` | `models.Optional[string]` | Optional | Reverse DNS PTR entry for the IPv4 address of this Load Balancer |
| `Ip` | `models.Optional[string]` | Optional | IP address (v4) of this Load Balancer |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    ipv4 := models.Ipv4{
        DnsPtr:               models.NewOptional(models.ToPointer("lb1.example.com")),
        Ip:                   models.NewOptional(models.ToPointer("1.2.3.4")),
    }

}
```

