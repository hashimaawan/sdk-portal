
# X Amz Target 43 Enum

## Enumeration

`XAmzTarget43Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTABLEMETADATA` |

## Example

```ruby
x_amz_target43 = XAmzTarget43Enum::ENUM_AMAZONATHENALISTTABLEMETADATA
```

