
# Action

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `READ` |
| `CREATE` |
| `UPDATE` |
| `DELETE` |

## Example

```ruby
action = Action::UPDATE
```

