
# Type 21 Enum

## Enumeration

`Type21Enum`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```ruby
type21 = Type21Enum::BACKUP
```

