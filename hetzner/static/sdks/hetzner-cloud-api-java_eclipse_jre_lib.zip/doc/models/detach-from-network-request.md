
# Detach from Network Request

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Network` | `int` | Required | ID of an existing network to detach the Server from | int getNetwork() | setNetwork(int network) |

## Example

```java
import cloud.hetzner.api.models.DetachFromNetworkRequest;

DetachFromNetworkRequest detachFromNetworkRequest = new DetachFromNetworkRequest.Builder(
    4711
)
.build();
```

