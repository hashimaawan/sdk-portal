
# Ssh Keys Request 1

## Structure

`SshKeysRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New name Name to set |

## Example

```ruby
ssh_keys_request1 = SshKeysRequest1.new(
  { 'labelkey' => 'value' },
  'My ssh key'
)
```

