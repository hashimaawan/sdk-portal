
# Session State

## Enumeration

`SessionState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```ruby
session_state = SessionState::IDLE
```

