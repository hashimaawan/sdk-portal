
# Placement Groups Response

## Structure

`PlacementGroupsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |
| `placement_groups` | [`Array[PlacementGroup]`](../../doc/models/placement-group.md) | Required | - |

## Example

```ruby
placement_groups_response = PlacementGroupsResponse.new(
  [
    PlacementGroup.new(
      '2016-01-30T23:55:00+00:00',
      42,
      {
        'key0': 'labels0',
        'key1': 'labels1'
      },
      'my-resource',
      [
        42
      ],
      'spread'
    )
  ],
  Meta.new(
    Pagination.new(
      77.7,
      209.18,
      17.58,
      13.34,
      50.02,
      206.64
    )
  )
)
```

