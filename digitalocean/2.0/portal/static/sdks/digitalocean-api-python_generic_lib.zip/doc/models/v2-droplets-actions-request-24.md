
# V2 Droplets Actions Request 24

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest24`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `kernel` | `int` | Optional | A unique number used to identify and reference a specific kernel. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.type_12 import Type12
from digitaloceanapi.models.v_2_droplets_actions_request_24 import V2DropletsActionsRequest24

v_2_droplets_actions_request_24 = V2DropletsActionsRequest24(
    mtype=Type12.REBOOT,
    kernel=12389723,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

