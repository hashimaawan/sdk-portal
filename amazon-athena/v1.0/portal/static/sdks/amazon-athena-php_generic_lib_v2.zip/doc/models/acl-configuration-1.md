
# Acl Configuration 1

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `s3AclOption` | [`string(S3AclOption1Enum)`](../../doc/models/s3-acl-option-1-enum.md) | Required | - | getS3AclOption(): string | setS3AclOption(string s3AclOption): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\AclConfiguration1Builder;
use AmazonAthenaLib\Models\S3AclOption1Enum;

$aclConfiguration1 = AclConfiguration1Builder::init(
    S3AclOption1Enum::BUCKET_OWNER_FULL_CONTROL
)->build();
```

