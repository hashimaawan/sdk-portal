
# Session State

## Enumeration

`SessionState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```java
import com.amazonaws.useast1.athena.models.SessionState;

SessionState sessionState = SessionState.TERMINATING;
```

