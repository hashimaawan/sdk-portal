
# Create Floating IP Request

## Structure

`CreateFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string \| undefined` | Optional | - |
| `homeLocation` | `string \| undefined` | Optional | Home Location (routing is optimized for that Location). Only optional if Server argument is passed. |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | - |
| `server` | `number \| undefined` | Optional | Server to assign the Floating IP to |
| `type` | [`Type17Enum`](../../doc/models/type-17-enum.md) | Required | Floating IP type |

## Example

```ts
import { CreateFloatingIPRequest, Type17Enum } from 'hetzner-cloud-apilib';

const createFloatingIPRequest: CreateFloatingIPRequest = {
  type: Type17Enum.Ipv4,
  description: 'Web Frontend',
  homeLocation: 'fsn1',
  labels: { 'labelkey': 'value' },
  name: 'Web Frontend',
  server: 42,
};
```

