
# X Amz Target 6 Enum

## Enumeration

`XAmzTarget6Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreatePreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget6Enum xAmzTarget6 = XAmzTarget6Enum.EnumAmazonAthenaCreatePreparedStatement;
```

