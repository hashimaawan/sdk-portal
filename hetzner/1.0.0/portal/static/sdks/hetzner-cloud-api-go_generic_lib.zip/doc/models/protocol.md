
# Protocol

Type of traffic to allow

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Udp` |
| `Icmp` |
| `Esp` |
| `Gre` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    protocol := models.Protocol_Esp

}
```

