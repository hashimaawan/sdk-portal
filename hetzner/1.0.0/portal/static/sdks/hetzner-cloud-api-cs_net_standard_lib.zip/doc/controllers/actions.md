# Actions

Actions show the results and progress of asynchronous requests to the API.

```csharp
ActionsApi actionsApi = client.ActionsApi;
```

## Class Name

`ActionsApi`

## Methods

* [Get All Actions](../../doc/controllers/actions.md#get-all-actions)
* [Get an Action](../../doc/controllers/actions.md#get-an-action)


# Get All Actions

Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```csharp
GetAllActionsAsync(
    int? id = null,
    Models.ParameterSort? sort = null,
    Models.ParameterStatus? status = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int?` | Query, Optional | Can be used multiple times, the response will contain only Actions with specified IDs |
| `sort` | [`ParameterSort?`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatus?`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```csharp
try
{
    ApiResponse<ActionsResponse> result = await actionsApi.GetAllActionsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get an Action

Returns a specific Action object.

```csharp
GetAnActionAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |

## Response Type

**200**: The `action` key in the reply has this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```csharp
int id = 112;
try
{
    ApiResponse<ActionResponse> result = await actionsApi.GetAnActionAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

