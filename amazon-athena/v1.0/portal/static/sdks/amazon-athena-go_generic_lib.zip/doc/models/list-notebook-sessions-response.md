
# List Notebook Sessions Response

## Structure

`ListNotebookSessionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NotebookSessionsList` | [`[]models.NotebookSessionSummary`](../../doc/models/notebook-session-summary.md) | Required | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonathena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    listNotebookSessionsResponse := models.ListNotebookSessionsResponse{
        NotebookSessionsList: []models.NotebookSessionSummary{
            models.NotebookSessionSummary{
                SessionId:            models.ToPointer("SessionId4"),
                CreationTime:         models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
            },
        },
        NextToken:            models.ToPointer("NextToken0"),
    }

}
```

