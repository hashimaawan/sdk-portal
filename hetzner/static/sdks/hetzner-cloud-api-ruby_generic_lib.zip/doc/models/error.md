
# Error

Error message for the Action if error occurred, otherwise null

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Required | Fixed machine readable code |
| `message` | `String` | Required | Humanized error message |

## Example

```ruby
error = Error.new(
  'action_failed',
  'Action failed'
)
```

