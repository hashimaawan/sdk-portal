
# Forbidden Exception

*This model accepts additional fields of type Object.*

## Structure

`ForbiddenException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`ErrorObject`](../../doc/models/error-object.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue ForbiddenException => e
  puts "Caught ForbiddenException: #{e.message}"
end
```

