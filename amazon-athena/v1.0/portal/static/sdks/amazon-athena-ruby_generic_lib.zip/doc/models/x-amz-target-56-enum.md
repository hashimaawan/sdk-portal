
# X Amz Target 56 Enum

## Enumeration

`XAmzTarget56Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOK` |

## Example

```ruby
x_amz_target56 = XAmzTarget56Enum::ENUM_AMAZONATHENAUPDATENOTEBOOK
```

