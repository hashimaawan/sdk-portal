
# Applied To

*This model accepts additional fields of type interface{}.*

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppliedToResources` | [`[]models.AppliedToResource`](../../doc/models/applied-to-resource.md) | Optional | - |
| `LabelSelector` | [`*models.LabelSelector`](../../doc/models/label-selector.md) | Optional | - |
| `Server` | [`*models.Server`](../../doc/models/server.md) | Optional | - |
| `Type` | [`models.Type6`](../../doc/models/type-6.md) | Required | Type of resource referenced |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    appliedTo := models.AppliedTo{
        AppliedToResources:    []models.AppliedToResource{
            models.AppliedToResource{
                Server:                models.ToPointer(models.Server{
                    Id:                    14,
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                }),
                Type:                  models.ToPointer(models.Type5_Server),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            models.AppliedToResource{
                Server:                models.ToPointer(models.Server{
                    Id:                    14,
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                }),
                Type:                  models.ToPointer(models.Type5_Server),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        LabelSelector:         models.ToPointer(models.LabelSelector{
            Selector:              "selector8",
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        Server:                models.ToPointer(models.Server{
            Id:                    14,
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        Type:                  models.Type6_Server,
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

