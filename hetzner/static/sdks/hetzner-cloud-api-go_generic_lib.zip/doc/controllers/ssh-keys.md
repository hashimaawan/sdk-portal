# SSH Keys

```go
sSHKeysController := client.SSHKeysController()
```

## Class Name

`SSHKeysController`

## Methods

* [Get All SSH Keys](../../doc/controllers/ssh-keys.md#get-all-ssh-keys)
* [Create an SSH Key](../../doc/controllers/ssh-keys.md#create-an-ssh-key)
* [Delete an SSH Key](../../doc/controllers/ssh-keys.md#delete-an-ssh-key)
* [Get a SSH Key](../../doc/controllers/ssh-keys.md#get-a-ssh-key)
* [Update an SSH Key](../../doc/controllers/ssh-keys.md#update-an-ssh-key)


# Get All SSH Keys

Returns all SSH key objects.

```go
GetAllSSHKeys(
    ctx context.Context,
    sort *models.Sort8Enum,
    name *string,
    fingerprint *string,
    labelSelector *string) (
    models.ApiResponse[models.SshKeysResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`*models.Sort8Enum`](../../doc/models/sort-8-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `*string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `fingerprint` | `*string` | Query, Optional | Can be used to filter SSH keys by their fingerprint. The response will only contain the SSH key matching the specified fingerprint. |
| `labelSelector` | `*string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `ssh_keys` key in the reply contains an array of SSH key objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.SshKeysResponse](../../doc/models/ssh-keys-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := sSHKeysController.GetAllSSHKeys(ctx, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Create an SSH Key

Creates a new SSH key with the given `name` and `public_key`. Once an SSH key is created, it can be used in other calls such as creating Servers.

```go
CreateAnSSHKey(
    ctx context.Context,
    body *models.SshKeysRequest) (
    models.ApiResponse[models.SshKeysResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`*models.SshKeysRequest`](../../doc/models/ssh-keys-request.md) | Body, Optional | - |

## Response Type

**201**: The `ssh_key` key in the reply contains the object that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.SshKeysResponse1](../../doc/models/ssh-keys-response-1.md).

## Example Usage

```go
ctx := context.Background()

body := models.SshKeysRequest{
    Name:                 "My ssh key",
    PublicKey:            "ssh-rsa AAAjjk76kgf...Xt",
}

apiResponse, err := sSHKeysController.CreateAnSSHKey(ctx, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Delete an SSH Key

Deletes an SSH key. It cannot be used anymore.

```go
DeleteAnSSHKey(
    ctx context.Context,
    id string) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the SSH key |

## Response Type

**204**: SSH key deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

id := "id0"

resp, err := sSHKeysController.DeleteAnSSHKey(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```


# Get a SSH Key

Returns a specific SSH key object.

```go
GetASSHKey(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.SshKeysResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the SSH key |

## Response Type

**200**: The `ssh_key` key in the reply contains an SSH key object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.SshKeysResponse1](../../doc/models/ssh-keys-response-1.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := sSHKeysController.GetASSHKey(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Update an SSH Key

Updates an SSH key. You can update an SSH key name and an SSH key labels.

Please note that when updating labels, the SSH key current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```go
UpdateAnSSHKey(
    ctx context.Context,
    id string,
    body *models.SshKeysRequest1) (
    models.ApiResponse[models.SshKeysResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | ID of the SSH key |
| `body` | [`*models.SshKeysRequest1`](../../doc/models/ssh-keys-request-1.md) | Body, Optional | - |

## Response Type

**200**: The `ssh_key` key in the reply contains the modified SSH key object with the new description

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.SshKeysResponse1](../../doc/models/ssh-keys-response-1.md).

## Example Usage

```go
ctx := context.Background()

id := "id0"

body := models.SshKeysRequest1{
    Labels:               models.ToPointer(interface{}("[labelkey, value]")),
    Name:                 models.ToPointer("My ssh key"),
}

apiResponse, err := sSHKeysController.UpdateAnSSHKey(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "ssh_key": {
    "created": "2016-01-30T23:50:00+00:00",
    "fingerprint": "b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f",
    "id": 2323,
    "labels": {
      "labelkey": "value"
    },
    "name": "My ssh key",
    "public_key": "ssh-rsa AAAjjk76kgf...Xt"
  }
}
```

