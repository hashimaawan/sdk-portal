
# X Amz Target 41 Enum

## Enumeration

`XAmzTarget41Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```ruby
x_amz_target41 = XAmzTarget41Enum::ENUM_AMAZONATHENALISTQUERYEXECUTIONS
```

