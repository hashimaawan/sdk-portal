
# List Engine Versions Input

*This model accepts additional fields of type interface{}.*

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 10` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    listEngineVersionsInput := models.ListEngineVersionsInput{
        NextToken:             models.ToPointer("NextToken6"),
        MaxResults:            models.ToPointer(10),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

