
# X Amz Target 44 Enum

## Enumeration

`XAmzTarget44Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```ruby
x_amz_target44 = XAmzTarget44Enum::ENUM_AMAZONATHENALISTTAGSFORRESOURCE
```

