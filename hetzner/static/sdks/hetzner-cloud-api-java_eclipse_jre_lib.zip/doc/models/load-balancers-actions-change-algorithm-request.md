
# Load Balancers Actions Change Algorithm Request

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`Type39Enum`](../../doc/models/type-39-enum.md) | Required | Algorithm of the Load Balancer | Type39Enum getType() | setType(Type39Enum type) |

## Example

```java
import cloud.hetzner.api.models.LoadBalancersActionsChangeAlgorithmRequest;
import cloud.hetzner.api.models.Type39Enum;

LoadBalancersActionsChangeAlgorithmRequest loadBalancersActionsChangeAlgorithmRequest = new LoadBalancersActionsChangeAlgorithmRequest.Builder(
    Type39Enum.ROUND_ROBIN
)
.build();
```

