
# Get Work Group Input

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `str` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```python
from amazonathena.models.get_work_group_input import GetWorkGroupInput

get_work_group_input = GetWorkGroupInput(
    work_group='WorkGroup0'
)
```

