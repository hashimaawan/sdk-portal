
# X Amz Target 49 Enum

## Enumeration

`XAmzTarget49Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget49Enum;

XAmzTarget49Enum xAmzTarget49 = XAmzTarget49Enum.ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION;
```

