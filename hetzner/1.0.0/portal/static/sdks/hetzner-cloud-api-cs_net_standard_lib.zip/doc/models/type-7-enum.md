
# Type 7 Enum

Type of the resource

## Enumeration

`Type7Enum`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type7Enum type7 = Type7Enum.Server;
```

