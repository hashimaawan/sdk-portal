
# List Tags for Resource Output

*This model accepts additional fields of type Object.*

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | [`Array[Tag]`](../../doc/models/tag.md) | Optional | - |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
list_tags_for_resource_output = ListTagsForResourceOutput.new(
  tags: [
    Tag.new(
      key: 'Key0',
      value: 'Value6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  next_token: 'NextToken4',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

