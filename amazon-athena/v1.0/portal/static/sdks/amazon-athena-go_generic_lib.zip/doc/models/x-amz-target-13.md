
# X Amz Target 13

## Enumeration

`XAmzTarget13`

## Fields

| Name |
|  --- |
| `EnumAmazonathenadeleteworkgroup` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget13 := models.XAmzTarget13_EnumAmazonathenadeleteworkgroup

}
```

