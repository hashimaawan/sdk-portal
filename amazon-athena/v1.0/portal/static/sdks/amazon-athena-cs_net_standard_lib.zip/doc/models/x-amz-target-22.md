
# X Amz Target 22

## Enumeration

`XAmzTarget22`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetPreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget22 xAmzTarget22 = XAmzTarget22.EnumAmazonAthenaGetPreparedStatement;
```

