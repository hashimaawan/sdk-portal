
# Volumes Actions Resize Request

*This model accepts additional fields of type interface{}.*

## Structure

`VolumesActionsResizeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Size` | `float64` | Required | New Volume size in GB (must be greater than current size) |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    volumesActionsResizeRequest := models.VolumesActionsResizeRequest{
        Size:                  float64(50),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

