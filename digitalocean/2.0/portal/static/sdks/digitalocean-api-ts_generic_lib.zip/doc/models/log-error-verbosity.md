
# Log Error Verbosity

Controls the amount of detail written in the server log for each message that is logged.

## Enumeration

`LogErrorVerbosity`

## Fields

| Name |
|  --- |
| `Terse` |
| `Default` |
| `Verbose` |

## Example

```ts
import { LogErrorVerbosity } from 'digitalocean-apilib';

const logErrorVerbosity = LogErrorVerbosity.Default;
```

