
# X Amz Target 13

## Enumeration

`XAmzTarget13`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteWorkGroup` |

## Example

```ts
import { XAmzTarget13 } from 'amazon-athenalib';

const xAmzTarget13 = XAmzTarget13.EnumAmazonAthenaDeleteWorkGroup;
```

