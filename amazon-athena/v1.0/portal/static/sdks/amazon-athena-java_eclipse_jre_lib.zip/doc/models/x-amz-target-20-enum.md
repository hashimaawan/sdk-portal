
# X Amz Target 20 Enum

## Enumeration

`XAmzTarget20Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget20Enum;

XAmzTarget20Enum xAmzTarget20 = XAmzTarget20Enum.ENUM_AMAZONATHENAGETNAMEDQUERY;
```

