
# X Amz Target 48 Enum

## Enumeration

`XAmzTarget48Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTSESSION` |

## Example

```ruby
x_amz_target48 = XAmzTarget48Enum::ENUM_AMAZONATHENASTARTSESSION
```

