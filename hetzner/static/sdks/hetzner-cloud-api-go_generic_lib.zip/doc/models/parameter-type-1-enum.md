
# Parameter Type 1 Enum

## Enumeration

`ParameterType1Enum`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    parameterType1 := models.ParameterType1Enum_SPREAD

}
```

