
# X Amz Target 33

## Enumeration

`XAmzTarget33`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListDataCatalogs` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget33 xAmzTarget33 = XAmzTarget33.EnumAmazonAthenaListDataCatalogs;
```

