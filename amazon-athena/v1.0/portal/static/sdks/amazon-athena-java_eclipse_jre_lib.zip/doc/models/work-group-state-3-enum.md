
# Work Group State 3 Enum

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```java
import com.amazonaws.useast1.athena.models.WorkGroupState3Enum;

WorkGroupState3Enum workGroupState3 = WorkGroupState3Enum.ENABLED;
```

