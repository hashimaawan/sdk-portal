
# X Amz Target 57 Enum

## Enumeration

`XAmzTarget57Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget57Enum;

$xAmzTarget57 = XAmzTarget57Enum::ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA;
```

