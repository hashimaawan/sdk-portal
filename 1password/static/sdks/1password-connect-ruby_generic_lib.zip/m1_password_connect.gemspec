Gem::Specification.new do |s|
  s.name = 'm1_password_connect'
  s.version = '1.5.7'
  s.summary = 'm1_password_connect'
  s.description = 'REST API interface for 1Password Connect.'
  s.authors = ['1Password Integrations']
  s.email = ['support@1password.com']
  s.homepage = 'https://support.1password.com/'
  s.licenses = ['MIT']
  s.add_dependency('apimatic_core_interfaces', '~> 0.2.3')
  s.add_dependency('apimatic_core', '~> 0.3.20')
  s.add_dependency('apimatic_faraday_client_adapter', '~> 0.1.6')
  s.required_ruby_version = ['>= 2.6']
  s.files = Dir['{bin,lib,man,test,spec}/**/*', 'README*', 'LICENSE*']
  s.require_paths = ['lib']
end
