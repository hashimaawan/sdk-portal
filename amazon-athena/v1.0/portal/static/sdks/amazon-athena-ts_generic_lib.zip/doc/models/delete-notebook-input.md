
# Delete Notebook Input

## Structure

`DeleteNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```ts
import { DeleteNotebookInput } from 'amazon-athenalib';

const deleteNotebookInput: DeleteNotebookInput = {
  notebookId: 'NotebookId0',
};
```

