
# X Amz Target 26

## Enumeration

`XAmzTarget26`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSION` |

## Example

```ruby
x_amz_target26 = XAmzTarget26::ENUM_AMAZONATHENAGETSESSION
```

