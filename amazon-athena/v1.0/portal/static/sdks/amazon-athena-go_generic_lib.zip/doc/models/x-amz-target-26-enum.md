
# X Amz Target 26 Enum

## Enumeration

`XAmzTarget26Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETSESSION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget26 := models.XAmzTarget26Enum_ENUMAMAZONATHENAGETSESSION

}
```

