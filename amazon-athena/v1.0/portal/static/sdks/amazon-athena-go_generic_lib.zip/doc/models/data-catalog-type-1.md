
# Data Catalog Type 1

The type of data catalog to create: <code>LAMBDA</code> for a federated catalog, <code>HIVE</code> for an external hive metastore, or <code>GLUE</code> for an Glue Data Catalog.

## Enumeration

`DataCatalogType1`

## Fields

| Name |
|  --- |
| `Lambda` |
| `Glue` |
| `Hive` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    dataCatalogType1 := models.DataCatalogType1_Glue

}
```

