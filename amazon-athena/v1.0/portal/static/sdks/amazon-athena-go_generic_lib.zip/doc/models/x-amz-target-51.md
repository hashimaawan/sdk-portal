
# X Amz Target 51

## Enumeration

`XAmzTarget51`

## Fields

| Name |
|  --- |
| `EnumAmazonathenatagresource` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget51 := models.XAmzTarget51_EnumAmazonathenatagresource

}
```

