
# Type 50 Enum

Type of the Primary IP

## Enumeration

`Type50Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```java
import cloud.hetzner.api.models.Type50Enum;

Type50Enum type50 = Type50Enum.IPV4;
```

