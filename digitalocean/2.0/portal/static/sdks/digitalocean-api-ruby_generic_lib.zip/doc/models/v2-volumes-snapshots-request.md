
# V2 Volumes Snapshots Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2VolumesSnapshotsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | A human-readable name for the volume snapshot. |
| `tags` | `Array[String]` | Optional | A flat array of tag names as strings to be applied to the resource. Tag names may be for either existing or new tags. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_volumes_snapshots_request = V2VolumesSnapshotsRequest.new(
  name: 'big-data-snapshot1475261774',
  tags: [
    'base-image',
    'prod'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

