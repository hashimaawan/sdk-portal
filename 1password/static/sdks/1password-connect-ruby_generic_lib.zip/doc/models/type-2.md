
# Type 2

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `USER_CREATED` |
| `PERSONAL` |
| `EVERYONE` |
| `TRANSFER` |

## Example

```ruby
type2 = Type2::EVERYONE
```

