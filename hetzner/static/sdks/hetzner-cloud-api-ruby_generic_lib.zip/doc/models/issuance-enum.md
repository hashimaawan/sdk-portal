
# Issuance Enum

Status of the issuance process of the Certificate

## Enumeration

`IssuanceEnum`

## Fields

| Name |
|  --- |
| `PENDING` |
| `COMPLETED` |
| `FAILED` |

## Example

```ruby
issuance = IssuanceEnum::FAILED
```

