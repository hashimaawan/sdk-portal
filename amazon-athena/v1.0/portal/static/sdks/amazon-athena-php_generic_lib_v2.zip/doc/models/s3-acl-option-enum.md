
# S3 Acl Option Enum

## Enumeration

`S3AclOptionEnum`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```php
use AmazonAthenaLib\Models\S3AclOptionEnum;

$s3AclOption = S3AclOptionEnum::BUCKET_OWNER_FULL_CONTROL;
```

