
# Work Group State

## Enumeration

`WorkGroupState`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```ts
import { WorkGroupState } from 'amazon-athenalib';

const workGroupState = WorkGroupState.Enabled;
```

