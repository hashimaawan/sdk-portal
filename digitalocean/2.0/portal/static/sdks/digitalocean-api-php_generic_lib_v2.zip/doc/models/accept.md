
# Accept

## Enumeration

`Accept`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONYAML` |

## Example

```php
use DigitalOceanApiLib\Models\Accept;

$accept = Accept::ENUM_APPLICATIONJSON;
```

