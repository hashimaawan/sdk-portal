
# V2 Load Balancers Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2LoadBalancersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `loadBalancers` | [`LoadBalancer1[] \| undefined`](../../doc/models/load-balancer-1.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Algorithm,
  EntryProtocol,
  TargetProtocol,
  V2LoadBalancersResponse,
} from 'digitalocean-apilib';

const v2LoadBalancersResponse: V2LoadBalancersResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  loadBalancers: [
    {
      forwardingRules: [
        {
          entryPort: 220,
          entryProtocol: EntryProtocol.Http2,
          targetPort: 104,
          targetProtocol: TargetProtocol.Https,
          certificateId: 'certificate_id4',
          tlsPassthrough: false,
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      algorithm: Algorithm.RoundRobin,
      createdAt: '2016-03-13T12:52:32.123Z',
      disableLetsEncryptDnsRecords: false,
      enableBackendKeepalive: false,
      enableProxyProtocol: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

