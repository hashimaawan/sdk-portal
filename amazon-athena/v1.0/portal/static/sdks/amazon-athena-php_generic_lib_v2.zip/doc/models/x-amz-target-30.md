
# X Amz Target 30

## Enumeration

`XAmzTarget30`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAIMPORTNOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget30;

$xAmzTarget30 = XAmzTarget30::ENUM_AMAZONATHENAIMPORTNOTEBOOK;
```

