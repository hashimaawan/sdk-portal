
# X Amz Target 55 Enum

## Enumeration

`XAmzTarget55Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENAMEDQUERY` |

## Example

```ruby
x_amz_target55 = XAmzTarget55Enum::ENUM_AMAZONATHENAUPDATENAMEDQUERY
```

