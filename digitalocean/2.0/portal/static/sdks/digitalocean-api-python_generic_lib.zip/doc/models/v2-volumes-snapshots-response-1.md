
# V2 Volumes Snapshots Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2VolumesSnapshotsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `snapshots` | [`List[Snapshot]`](../../doc/models/snapshot.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.resource_type_1 import ResourceType1
from digitaloceanapi.models.snapshot import Snapshot
from digitaloceanapi.models.v_2_volumes_snapshots_response_1 import V2VolumesSnapshotsResponse1

v_2_volumes_snapshots_response_1 = V2VolumesSnapshotsResponse1(
    meta=Meta(
        total=1,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    snapshots=[
        Snapshot(
            id='8eb4d51a-873f-11e6-96bf-000f53315a41',
            created_at=dateutil.parser.parse('2020-09-30T18:56:12Z'),
            min_disk_size=10,
            name='big-data-snapshot1475261752',
            regions=[
                'nyc1'
            ],
            size_gigabytes=0,
            resource_id='82a48a18-873f-11e6-96bf-000f53315a41',
            resource_type=ResourceType1.VOLUME,
            tags=None,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    links=Links(
        pages=Pages(
            last='last6',
            next='next2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

