
# Os Flavor

Flavor of operating system contained in the Image

## Enumeration

`OsFlavor`

## Fields

| Name |
|  --- |
| `Ubuntu` |
| `Centos` |
| `Debian` |
| `Fedora` |
| `Unknown` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    osFlavor := models.OsFlavor_Debian

}
```

