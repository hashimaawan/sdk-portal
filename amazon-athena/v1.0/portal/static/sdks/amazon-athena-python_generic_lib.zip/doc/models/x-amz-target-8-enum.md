
# X Amz Target 8 Enum

## Enumeration

`XAmzTarget8Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEWORKGROUP` |

## Example

```python
from amazonathena.models.x_amz_target_8_enum import XAmzTarget8Enum

x_amz_target_8 = XAmzTarget8Enum.ENUM_AMAZONATHENACREATEWORKGROUP
```

