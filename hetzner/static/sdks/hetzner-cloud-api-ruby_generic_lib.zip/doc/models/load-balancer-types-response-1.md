
# Load Balancer Types Response 1

## Structure

`LoadBalancerTypesResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `load_balancer_type` | [`LoadBalancerType`](../../doc/models/load-balancer-type.md) | Optional | - |

## Example

```ruby
load_balancer_types_response1 = LoadBalancerTypesResponse1.new(
  LoadBalancerType.new(
    'deprecated2',
    'description4',
    205.06,
    211.64,
    136.32,
    199.18,
    152.52,
    'name6',
    [
      Price.new(
        'location8',
        PriceHourly.new(
          'gross4',
          'net2'
        ),
        PriceMonthly.new(
          'gross2',
          'net0'
        )
      ),
      Price.new(
        'location8',
        PriceHourly.new(
          'gross4',
          'net2'
        ),
        PriceMonthly.new(
          'gross2',
          'net0'
        )
      ),
      Price.new(
        'location8',
        PriceHourly.new(
          'gross4',
          'net2'
        ),
        PriceMonthly.new(
          'gross2',
          'net0'
        )
      )
    ]
  )
)
```

