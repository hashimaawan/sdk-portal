
# Type 50 Enum

Type of the Primary IP

## Enumeration

`Type50Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type50Enum type50 = Type50Enum.Ipv4;
```

