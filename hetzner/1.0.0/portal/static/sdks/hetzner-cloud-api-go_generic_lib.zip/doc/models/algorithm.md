
# Algorithm

Algorithm of the Load Balancer

*This model accepts additional fields of type interface{}.*

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`models.Type28`](../../doc/models/type-28.md) | Required | Type of the algorithm |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    algorithm := models.Algorithm{
        Type:                  models.Type28_RoundRobin,
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

