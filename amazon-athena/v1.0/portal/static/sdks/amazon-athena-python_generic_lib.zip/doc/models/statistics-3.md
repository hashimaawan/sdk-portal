
# Statistics 3

## Structure

`Statistics3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `int` | Optional | - |

## Example

```python
from amazonathena.models.statistics_3 import Statistics3

statistics_3 = Statistics3(
    dpu_execution_in_millis=122
)
```

