
# Type 5 Enum

Type of resource referenced

## Enumeration

`Type5Enum`

## Fields

| Name |
|  --- |
| `SERVER` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type5 := models.Type5Enum_SERVER

}
```

