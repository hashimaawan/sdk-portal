
# Sort 2

## Enumeration

`Sort2`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `CREATED` |
| `ENUM_CREATEDASC` |
| `ENUM_CREATEDDESC` |

## Example

```ruby
sort2 = Sort2::ENUM_CREATEDASC
```

