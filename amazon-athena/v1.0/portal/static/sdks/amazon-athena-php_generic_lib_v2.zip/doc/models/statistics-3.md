
# Statistics 3

## Structure

`Statistics3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dpuExecutionInMillis` | `?int` | Optional | - | getDpuExecutionInMillis(): ?int | setDpuExecutionInMillis(?int dpuExecutionInMillis): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\Statistics3Builder;

$statistics3 = Statistics3Builder::init()
    ->dpuExecutionInMillis(130)
    ->build();
```

