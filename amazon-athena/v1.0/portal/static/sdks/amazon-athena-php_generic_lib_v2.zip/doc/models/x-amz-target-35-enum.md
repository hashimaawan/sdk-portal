
# X Amz Target 35 Enum

## Enumeration

`XAmzTarget35Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTENGINEVERSIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget35Enum;

$xAmzTarget35 = XAmzTarget35Enum::ENUM_AMAZONATHENALISTENGINEVERSIONS;
```

