
# Floating Ips Response 2

*This model accepts additional fields of type Object.*

## Structure

`FloatingIpsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floating_ip` | [`FloatingIp`](../../doc/models/floating-ip.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
floating_ips_response2 = FloatingIpsResponse2.new(
  floating_ip: FloatingIp.new(
    blocked: false,
    created: '2016-01-30T23:55:00+00:00',
    description: 'this describes my resource',
    dns_ptr: [
      DnsPtr.new(
        dns_ptr: 'server.example.com',
        ip: '2001:db8::1',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    home_location: HomeLocation.new(
      city: 'Falkenstein',
      country: 'DE',
      description: 'Falkenstein DC Park 1',
      id: 1,
      latitude: 50.47612,
      longitude: 12.370071,
      name: 'fsn1',
      network_zone: 'eu-central',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    id: 42,
    ip: '131.232.99.1',
    labels: {
      'key0' => 'labels4',
      'key1' => 'labels3',
      'key2' => 'labels2'
    },
    name: 'my-resource',
    protection: Protection.new(
      delete: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    server: 42,
    type: Type16::IPV4,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

