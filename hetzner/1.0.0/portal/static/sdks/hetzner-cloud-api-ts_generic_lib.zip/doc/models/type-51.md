
# Type 51

Primary IP type

## Enumeration

`Type51`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type51 } from 'hetzner-cloud-apilib';

const type51 = Type51.Ipv4;
```

