
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `KUBERNETES` |

## Example

```php
use DigitalOceanApiLib\Models\Type;

$type = Type::DROPLET;
```

