
# Registry Digitalocean Com

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`RegistryDigitaloceanCom`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `auth` | `?string` | Optional | A base64 encoded string containing credentials for the container registry. | getAuth(): ?string | setAuth(?string auth): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\RegistryDigitaloceanComBuilder;
use DigitalOceanApiLib\ApiHelper;

$registryDigitaloceanCom = RegistryDigitaloceanComBuilder::init()
    ->auth('YjdkMDNhNjk0N2IyMTdlZmI2ZjNlYzNiZDM1MDQ1ODI6YjdkMDNhNjk0N2IyMTdlZmI2ZjNlYzNiZDM1MDQ1ODIK')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

