
# Character Set

## Enumeration

`CharacterSet`

## Fields

| Name |
|  --- |
| `Letters` |
| `Digits` |
| `Symbols` |

## Example

```ts
import { CharacterSet } from 'm-1-password-connectlib';

const characterSet = CharacterSet.Digits;
```

