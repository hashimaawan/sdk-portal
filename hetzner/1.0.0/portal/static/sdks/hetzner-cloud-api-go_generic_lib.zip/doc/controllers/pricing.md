# Pricing

Returns prices for resources.

```go
pricingApi := client.PricingApi()
```

## Class Name

`PricingApi`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```go
GetAllPrices(
    ctx context.Context) (
    models.ApiResponse[models.PricingResponse],
    error)
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PricingResponse](../../doc/models/pricing-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := pricingApi.GetAllPrices(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

