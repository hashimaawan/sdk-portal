
# Query Stage

Stage statistics such as input and output rows and bytes, execution time and stage state. This information also includes substages and the query stage plan.

## Structure

`QueryStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StageId` | `int?` | Optional | - |
| `State` | `string` | Optional | - |
| `OutputBytes` | `int?` | Optional | - |
| `OutputRows` | `int?` | Optional | - |
| `InputBytes` | `int?` | Optional | - |
| `InputRows` | `int?` | Optional | - |
| `ExecutionTime` | `int?` | Optional | - |
| `QueryStagePlan` | [`QueryStagePlan`](../../doc/models/query-stage-plan.md) | Optional | - |
| `SubStages` | [`List<QueryStage>`](../../doc/models/query-stage.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryStage queryStage = new QueryStage
{
    StageId = 118,
    State = "State0",
    OutputBytes = 120,
    OutputRows = 146,
    InputBytes = 178,
};
```

