
# Traffic

The cost of additional traffic per TB

*This model accepts additional fields of type array.*

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pricePerTb` | [`PricePerTb`](../../doc/models/price-per-tb.md) | Required | - | getPricePerTb(): PricePerTb | setPricePerTb(PricePerTb pricePerTb): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\TrafficBuilder;
use HetznerCloudApiLib\Models\Builders\PricePerTbBuilder;
use HetznerCloudApiLib\ApiHelper;

$traffic = TrafficBuilder::init(
    PricePerTbBuilder::init(
        '1.1900000000000000',
        '1.0000000000'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

