
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| connection | `Faraday::Connection` | The Faraday connection object passed by the SDK user for making requests |
| adapter | `Faraday::Adapter` | The Faraday adapter object passed by the SDK user for performing http requests |
| timeout | `Float` | The value to use for connection timeout. <br> **Default: 30** |
| max_retries | `Integer` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| retry_interval | `Float` | Pause in seconds between retries. <br> **Default: 1** |
| backoff_factor | `Float` | The amount to multiply each successive retry's interval amount by in order to provide backoff. <br> **Default: 2** |
| retry_statuses | `Array` | A list of HTTP statuses to retry. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array` | A list of HTTP methods to retry. <br> **Default: %i[get put get put]** |
| http_callback | `HttpCallBack` | The Http CallBack allows defining callables for pre and post API calls. |
| proxy_settings | [`ProxySettings`](../doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| logging_configuration | [`LoggingConfiguration`](../doc/logging-configuration.md) | The SDK logging configuration for API calls |
| bearer_auth_credentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The credential object for OAuth 2 Bearer token |

The API client can be initialized as follows:

## Code-Based Client Initialization

```ruby
require 'digital_ocean_api'
include DigitalOceanApi

client = Client.new(
  bearer_auth_credentials: BearerAuthCredentials.new(
    access_token: 'AccessToken'
  ),
  logging_configuration: LoggingConfiguration.new(
    log_level: Logger::INFO,
    request_logging_config: RequestLoggingConfiguration.new(
      log_body: true
    ),
    response_logging_config: ResponseLoggingConfiguration.new(
      log_headers: true
    )
  )
)
```

## Environment-Based Client Initialization

```ruby
require 'digital_ocean_api'
include DigitalOceanApi

# Create client from environment
client = Client.from_env
```

See the [`Environment-Based Client Initialization`](../doc/environment-based-client-initialization.md) section for details.

## DigitalOcean API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| m_1_click_applications | Gets M1ClickApplicationsApi |
| account | Gets AccountApi |
| actions | Gets ActionsApi |
| apps | Gets AppsApi |
| billing | Gets BillingApi |
| block_storage | Gets BlockStorageApi |
| block_storage_actions | Gets BlockStorageActionsApi |
| cdn_endpoints | Gets CdnEndpointsApi |
| certificates | Gets CertificatesApi |
| container_registry | Gets ContainerRegistryApi |
| databases | Gets DatabasesApi |
| domain_records | Gets DomainRecordsApi |
| domains | Gets DomainsApi |
| droplet_actions | Gets DropletActionsApi |
| droplets | Gets DropletsApi |
| firewalls | Gets FirewallsApi |
| floating_ip_actions | Gets FloatingIpActionsApi |
| floating_i_ps | Gets FloatingIPsApi |
| functions | Gets FunctionsApi |
| image_actions | Gets ImageActionsApi |
| images | Gets ImagesApi |
| kubernetes | Gets KubernetesApi |
| load_balancers | Gets LoadBalancersApi |
| monitoring | Gets MonitoringApi |
| project_resources | Gets ProjectResourcesApi |
| projects | Gets ProjectsApi |
| regions | Gets RegionsApi |
| reserved_ip_actions | Gets ReservedIpActionsApi |
| reserved_i_ps | Gets ReservedIPsApi |
| sizes | Gets SizesApi |
| snapshots | Gets SnapshotsApi |
| ssh_keys | Gets SshKeysApi |
| tags | Gets TagsApi |
| uptime | Gets UptimeApi |
| vp_cs | Gets VpCsApi |

