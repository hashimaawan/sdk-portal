
# X Amz Target 23 Enum

## Enumeration

`XAmzTarget23Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget23Enum;

XAmzTarget23Enum xAmzTarget23 = XAmzTarget23Enum.ENUM_AMAZONATHENAGETQUERYEXECUTION;
```

