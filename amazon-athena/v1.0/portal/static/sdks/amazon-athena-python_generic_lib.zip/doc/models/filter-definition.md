
# Filter Definition

A string for searching notebook names.

## Structure

`FilterDefinition`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```python
from amazonathena.models.filter_definition import FilterDefinition

filter_definition = FilterDefinition(
    name='Name8'
)
```

