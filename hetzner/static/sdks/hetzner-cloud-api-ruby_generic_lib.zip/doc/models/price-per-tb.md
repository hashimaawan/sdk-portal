
# Price per Tb

## Structure

`PricePerTb`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `String` | Required | Price with VAT added |
| `net` | `String` | Required | Price without VAT |

## Example

```ruby
price_per_tb = PricePerTb.new(
  '1.1900000000000000',
  '1.0000000000'
)
```

