
# X Amz Target 27 Enum

## Enumeration

`XAmzTarget27Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSIONSTATUS` |

## Example

```ruby
x_amz_target27 = XAmzTarget27Enum::ENUM_AMAZONATHENAGETSESSIONSTATUS
```

