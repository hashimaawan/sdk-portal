
# X Amz Target 29

## Enumeration

`XAmzTarget29`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetworkgroup` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget29 := models.XAmzTarget29_EnumAmazonathenagetworkgroup

}
```

