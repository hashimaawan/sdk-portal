
# Load Balancers Actions Detach from Network Request

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Network` | `double` | Required | ID of an existing network to detach the Load Balancer from | double getNetwork() | setNetwork(double network) |

## Example

```java
import cloud.hetzner.api.models.LoadBalancersActionsDetachFromNetworkRequest;

LoadBalancersActionsDetachFromNetworkRequest loadBalancersActionsDetachFromNetworkRequest = new LoadBalancersActionsDetachFromNetworkRequest.Builder(
    4711D
)
.build();
```

