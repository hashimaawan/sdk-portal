
# X Amz Target 3

## Enumeration

`XAmzTarget3`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEDATACATALOG` |

## Example

```ruby
x_amz_target3 = XAmzTarget3::ENUM_AMAZONATHENACREATEDATACATALOG
```

