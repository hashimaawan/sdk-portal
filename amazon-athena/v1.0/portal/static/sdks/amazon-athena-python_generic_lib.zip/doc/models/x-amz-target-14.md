
# X Amz Target 14

## Enumeration

`XAmzTarget14`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAEXPORTNOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_14 import XAmzTarget14

x_amz_target_14 = XAmzTarget14.ENUM_AMAZONATHENAEXPORTNOTEBOOK
```

