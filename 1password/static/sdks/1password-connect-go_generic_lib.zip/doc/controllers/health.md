# Health

```go
healthApi := client.HealthApi()
```

## Class Name

`HealthApi`

## Methods

* [Get Server Health](../../doc/controllers/health.md#get-server-health)
* [Get Heartbeat](../../doc/controllers/health.md#get-heartbeat)


# Get Server Health

:information_source: **Note** This endpoint does not require authentication.

```go
GetServerHealth(
    ctx context.Context) (
    models.ApiResponse[models.HealthResponse],
    error)
```

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.HealthResponse](../../doc/models/health-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := healthApi.GetServerHealth(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "dependencies": [
    {
      "service": "sync",
      "status": "TOKEN_NEEDED"
    },
    {
      "message": "Connected to./1password.sqlite",
      "service": "sqlite",
      "status": "ACTIVE"
    }
  ],
  "name": "1Password Connect API",
  "version": "1.2.1"
}
```


# Get Heartbeat

:information_source: **Note** This endpoint does not require authentication.

```go
GetHeartbeat(
    ctx context.Context) (
    models.ApiResponse[string],
    error)
```

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type string.

## Example Usage

```go
ctx := context.Background()

apiResponse, err := healthApi.GetHeartbeat(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

