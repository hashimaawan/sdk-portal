
# Stop Calculation Execution Response

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`CalculationExecutionState4Enum`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```ruby
stop_calculation_execution_response = StopCalculationExecutionResponse.new(
  CalculationExecutionState4Enum::QUEUED
)
```

