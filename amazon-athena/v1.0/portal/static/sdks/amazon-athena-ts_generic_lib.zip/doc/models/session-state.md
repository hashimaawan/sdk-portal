
# Session State

## Enumeration

`SessionState`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Idle` |
| `Busy` |
| `Terminating` |
| `Terminated` |
| `Degraded` |
| `Failed` |

## Example

```ts
import { SessionState } from 'amazon-athenalib';

const sessionState = SessionState.Terminating;
```

