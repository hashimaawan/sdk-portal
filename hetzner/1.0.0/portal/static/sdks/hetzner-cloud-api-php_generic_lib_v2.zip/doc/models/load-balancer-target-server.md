
# Load Balancer Target Server

Server where the traffic should be routed through

*This model accepts additional fields of type array.*

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Server | getId(): int | setId(int id): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\LoadBalancerTargetServerBuilder;
use HetznerCloudApiLib\ApiHelper;

$loadBalancerTargetServer = LoadBalancerTargetServerBuilder::init(
    80
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

