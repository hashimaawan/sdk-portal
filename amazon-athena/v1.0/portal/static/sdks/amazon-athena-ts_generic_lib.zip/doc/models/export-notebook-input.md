
# Export Notebook Input

## Structure

`ExportNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```ts
import { ExportNotebookInput } from 'amazon-athenalib';

const exportNotebookInput: ExportNotebookInput = {
  notebookId: 'NotebookId2',
};
```

