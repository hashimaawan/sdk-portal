
# X Amz Target 12

## Enumeration

`XAmzTarget12`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeletePreparedStatement` |

## Example

```ts
import { XAmzTarget12 } from 'amazon-athenalib';

const xAmzTarget12 = XAmzTarget12.EnumAmazonAthenaDeletePreparedStatement;
```

