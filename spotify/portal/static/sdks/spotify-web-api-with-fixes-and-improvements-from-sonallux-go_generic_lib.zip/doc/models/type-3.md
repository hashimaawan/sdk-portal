
# Type 3

The object type.

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `User` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    type3 := models.Type3_User

}
```

