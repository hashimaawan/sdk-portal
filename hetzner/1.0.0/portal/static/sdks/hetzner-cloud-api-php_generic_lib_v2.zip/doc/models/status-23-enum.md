
# Status 23 Enum

## Enumeration

`Status23Enum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |

## Example

```php
use HetznerCloudAPILib\Models\Status23Enum;

$status23 = Status23Enum::AVAILABLE;
```

