
# Protocol

Type of traffic to allow

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |
| `ESP` |
| `GRE` |

## Example

```php
use HetznerCloudApiLib\Models\Protocol;

$protocol = Protocol::ESP;
```

