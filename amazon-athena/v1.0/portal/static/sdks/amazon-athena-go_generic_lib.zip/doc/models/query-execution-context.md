
# Query Execution Context

The database and data catalog context in which the query execution occurs.

*This model accepts additional fields of type interface{}.*

## Structure

`QueryExecutionContext`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Database` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `Catalog` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    queryExecutionContext := models.QueryExecutionContext{
        Database:              models.ToPointer("Database0"),
        Catalog:               models.ToPointer("Catalog6"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

