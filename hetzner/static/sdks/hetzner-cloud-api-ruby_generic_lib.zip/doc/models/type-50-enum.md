
# Type 50 Enum

Type of the Primary IP

## Enumeration

`Type50Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```ruby
type50 = Type50Enum::IPV4
```

