
# X Amz Target 42

## Enumeration

`XAmzTarget42`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTSESSIONS` |

## Example

```ruby
x_amz_target42 = XAmzTarget42::ENUM_AMAZONATHENALISTSESSIONS
```

