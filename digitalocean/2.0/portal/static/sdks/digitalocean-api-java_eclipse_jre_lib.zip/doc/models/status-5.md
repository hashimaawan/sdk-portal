
# Status 5

The current status of the migration.

## Enumeration

`Status5`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `CANCELED` |
| `ERROR` |
| `DONE` |

## Example

```java
import com.digitalocean.api.models.Status5;

Status5 status5 = Status5.RUNNING;
```

