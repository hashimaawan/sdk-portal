
# Parameter Sort Enum

## Enumeration

`ParameterSortEnum`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Command` |
| `EnumCommandasc` |
| `EnumCommanddesc` |
| `Status` |
| `EnumStatusasc` |
| `EnumStatusdesc` |
| `Progress` |
| `EnumProgressasc` |
| `EnumProgressdesc` |
| `Started` |
| `EnumStartedasc` |
| `EnumStarteddesc` |
| `Finished` |
| `EnumFinishedasc` |
| `EnumFinisheddesc` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ParameterSortEnum parameterSort = ParameterSortEnum.EnumStatusdesc;
```

