
# Accept

## Enumeration

`Accept`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONYAML` |

## Example

```java
import com.digitalocean.api.models.Accept;

Accept accept = Accept.ENUM_APPLICATIONJSON;
```

