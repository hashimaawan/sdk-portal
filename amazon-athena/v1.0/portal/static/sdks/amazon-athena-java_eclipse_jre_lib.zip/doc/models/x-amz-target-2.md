
# X Amz Target 2

## Enumeration

`XAmzTarget2`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget2;

XAmzTarget2 xAmzTarget2 = XAmzTarget2.ENUM_AMAZONATHENABATCHGETQUERYEXECUTION;
```

