
# List of Txt Validation Record

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`ListOfTxtValidationRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `txt_name` | `str` | Optional, Read-only | - |
| `txt_value` | `str` | Optional, Read-only | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.list_of_txt_validation_record import ListOfTxtValidationRecord

list_of_txt_validation_record = ListOfTxtValidationRecord(
    txt_name='_acme-challenge.app.example.com',
    txt_value='lXLOcN6cPv0nproViNcUHcahD9TrIPlNgdwesj0pYpk',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

