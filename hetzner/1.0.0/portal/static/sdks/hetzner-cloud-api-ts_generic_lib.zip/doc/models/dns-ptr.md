
# Dns Ptr

*This model accepts additional fields of type unknown.*

## Structure

`DnsPtr`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dnsPtr` | `string` | Required | DNS pointer for the specific IP address |
| `ip` | `string` | Required | Single IPv4 or IPv6 address |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DnsPtr } from 'hetzner-cloud-apilib';

const dnsPtr: DnsPtr = {
  dnsPtr: 'server.example.com',
  ip: '2001:db8::1',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

