
# Parameter Status Enum

## Enumeration

`ParameterStatusEnum`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ERROR` |

## Example

```python
from hetznercloudapi.models.parameter_status_enum import ParameterStatusEnum

parameter_status = ParameterStatusEnum.ERROR
```

