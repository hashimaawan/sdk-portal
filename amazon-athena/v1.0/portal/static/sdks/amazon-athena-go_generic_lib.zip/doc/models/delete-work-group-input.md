
# Delete Work Group Input

## Structure

`DeleteWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `RecursiveDeleteOption` | `*bool` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    deleteWorkGroupInput := models.DeleteWorkGroupInput{
        WorkGroup:             "WorkGroup0",
        RecursiveDeleteOption: models.ToPointer(false),
    }

}
```

