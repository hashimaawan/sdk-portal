
# V2 Projects Default Resources Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2ProjectsDefaultResourcesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resources` | [`Array[Resources1]`](../../doc/models/resources-1.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_projects_default_resources_response = V2ProjectsDefaultResourcesResponse.new(
  meta: Meta.new(
    total: 2,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  resources: [
    Resources1.new(
      assigned_at: DateTimeHelper.from_rfc3339('2018-09-28T19:26:37Z'),
      links: Links4.new(
        mself: 'https://api.digitalocean.com/v2/droplets/13457723',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      status: Status14::OK,
      urn: 'do:droplet:13457723',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Resources1.new(
      assigned_at: DateTimeHelper.from_rfc3339('2019-03-31T16:24:14Z'),
      links: Links4.new(
        mself: 'https://api.digitalocean.com/v2/domains/example.com',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      status: Status14::OK,
      urn: 'do:domain:example.com',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'https://api.digitalocean.com/v2/projects/4e1bfbc3-dc3e-41f2-a18f-1b4d7ba71679/resources?page=1',
      mnext: 'next2',
      additional_properties: {
        'first' => JSON.parse('"https://api.digitalocean.com/v2/projects/4e1bfbc3-dc3e-41f2-a18f-1b4d7ba71679/resources?page=1"')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

