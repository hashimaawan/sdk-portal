
# Table Metadata 2

## Structure

`TableMetadata2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `CreateTime` | `DateTime?` | Optional | - |
| `LastAccessTime` | `DateTime?` | Optional | - |
| `TableType` | `string` | Optional | **Constraints**: *Maximum Length*: `255` |
| `Columns` | [`List<Column>`](../../doc/models/column.md) | Optional | - |
| `PartitionKeys` | [`List<Column>`](../../doc/models/column.md) | Optional | - |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;
using System.Globalization;

TableMetadata2 tableMetadata2 = new TableMetadata2
{
    Name = "Name8",
    CreateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    LastAccessTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    TableType = "TableType6",
    Columns = new List<Column>
    {
        new Column
        {
            Name = "Name0",
            Type = "Type0",
            Comment = "Comment4",
        },
        new Column
        {
            Name = "Name0",
            Type = "Type0",
            Comment = "Comment4",
        },
    },
    PartitionKeys = new List<Column>
    {
        new Column
        {
            Name = "Name6",
            Type = "Type6",
            Comment = "Comment0",
        },
        new Column
        {
            Name = "Name6",
            Type = "Type6",
            Comment = "Comment0",
        },
    },
};
```

