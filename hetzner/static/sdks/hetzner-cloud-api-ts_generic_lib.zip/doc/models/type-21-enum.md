
# Type 21 Enum

## Enumeration

`Type21Enum`

## Fields

| Name |
|  --- |
| `System` |
| `Snapshot` |
| `Backup` |
| `App` |

## Example

```ts
import { Type21Enum } from 'hetzner-cloud-apilib';

const type21 = Type21Enum.Backup;
```

