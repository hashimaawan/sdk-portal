
# V2 Kubernetes Clusters Upgrades Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUpgradesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `available_upgrade_versions` | [`Array[AvailableUpgradeVersion]`](../../doc/models/available-upgrade-version.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_kubernetes_clusters_upgrades_response = V2KubernetesClustersUpgradesResponse.new(
  available_upgrade_versions: [
    AvailableUpgradeVersion.new(
      kubernetes_version: 'kubernetes_version0',
      slug: 'slug2',
      supported_features: [
        'supported_features3'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    AvailableUpgradeVersion.new(
      kubernetes_version: 'kubernetes_version0',
      slug: 'slug2',
      supported_features: [
        'supported_features3'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

