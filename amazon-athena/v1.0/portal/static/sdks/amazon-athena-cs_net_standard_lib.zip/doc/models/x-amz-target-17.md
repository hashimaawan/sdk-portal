
# X Amz Target 17

## Enumeration

`XAmzTarget17`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecutionStatus` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget17 xAmzTarget17 = XAmzTarget17.EnumAmazonAthenaGetCalculationExecutionStatus;
```

