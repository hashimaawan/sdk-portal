
# V2 Databases Resize Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesResizeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `numNodes` | `int` | Required | The number of nodes in the database cluster. Valid values are are 1-3. In addition to the primary node, up to two standby nodes may be added for highly available configurations. | getNumNodes(): int | setNumNodes(int numNodes): void |
| `size` | `string` | Required | A slug identifier representing desired the size of the nodes in the database cluster. | getSize(): string | setSize(string size): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesResizeRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesResizeRequest = V2DatabasesResizeRequestBuilder::init(
    3,
    'db-s-4vcpu-8gb'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

