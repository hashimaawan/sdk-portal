
# Get Data Catalog Input

## Structure

`GetDataCatalogInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getName() | setName(String name) |

## Example

```java
import com.amazonaws.useast1.athena.models.GetDataCatalogInput;

GetDataCatalogInput getDataCatalogInput = new GetDataCatalogInput.Builder(
    "Name6"
)
.build();
```

