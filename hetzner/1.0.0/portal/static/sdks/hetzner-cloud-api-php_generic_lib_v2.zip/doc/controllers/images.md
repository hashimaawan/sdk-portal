# Images

Images are blueprints for your VM disks. They can be of different types:

### System Images

Distribution Images maintained by us, e.g. “Ubuntu 20.04”

### Snapshot Images

Maintained by you, for example “Ubuntu 20.04 with my own settings”. These are billed per GB per month.

### Backup Images

Daily Backups of your Server. Will automatically be created for Servers which have backups enabled (`POST /servers/{id}/actions/enable_backup`)

Bound to exactly one Server. If you delete the Server, you also delete all backups bound to it. You may convert backup Images to snapshot Images to keep them.

These are billed at 20% of your instance price for 7 backup slots.

### App Images

Prebuild images with specific software configurations, e.g. “Wordpress”. All app images are created by us.

```php
$imagesController = $client->getImagesController();
```

## Class Name

`ImagesController`

## Methods

* [Get All Images](../../doc/controllers/images.md#get-all-images)
* [Delete an Image](../../doc/controllers/images.md#delete-an-image)
* [Get an Image](../../doc/controllers/images.md#get-an-image)
* [Update an Image](../../doc/controllers/images.md#update-an-image)


# Get All Images

Returns all Image objects. You can select specific Image types only and sort the results by using URI parameters.

```php
function getAllImages(
    ?string $sort = null,
    ?string $type = null,
    ?string $status = null,
    ?string $boundTo = null,
    ?bool $includeDeprecated = null,
    ?string $name = null,
    ?string $labelSelector = null
): ImagesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`?string(SortEnum)`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `type` | [`?string(Type21Enum)`](../../doc/models/type-21-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`?string(Status23Enum)`](../../doc/models/status-23-enum.md) | Query, Optional | Can be used multiple times. The response will only contain Images matching the status. |
| `boundTo` | `?string` | Query, Optional | Can be used multiple times. Server ID linked to the Image. Only available for Images of type `backup` |
| `includeDeprecated` | `?bool` | Query, Optional | Can be used multiple times. |
| `name` | `?string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `?string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `images` key in the reply contains an array of Image objects with this structure

[`ImagesResponse`](../../doc/models/images-response.md)

## Example Usage

```php
$imagesController = $client->getImagesController();

try {
    $result = $imagesController->getAllImages();
    echo 'ImagesResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Delete an Image

Deletes an Image. Only Images of type `snapshot` and `backup` can be deleted.

```php
function deleteAnImage(int $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |

## Response Type

**204**: Image deleted

`void`

## Example Usage

```php
$id = 112;

$imagesController = $client->getImagesController();

try {
    $imagesController->deleteAnImage($id);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get an Image

Returns a specific Image object.

```php
function getAnImage(int $id): ImagesResponse1
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |

## Response Type

**200**: The `image` key in the reply contains an Image object with this structure

[`ImagesResponse1`](../../doc/models/images-response-1.md)

## Example Usage

```php
$id = 112;

$imagesController = $client->getImagesController();

try {
    $result = $imagesController->getAnImage($id);
    echo 'ImagesResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Update an Image

Updates the Image. You may change the description, convert a Backup Image to a Snapshot Image or change the Image labels. Only Images of type `snapshot` and `backup` can be updated.

Note that when updating labels, the current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```php
function updateAnImage(int $id, ?UpdateImageRequest $body = null): ImagesResponse1
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `body` | [`?UpdateImageRequest`](../../doc/models/update-image-request.md) | Body, Optional | - |

## Response Type

**200**: The image key in the reply contains the modified Image object

[`ImagesResponse1`](../../doc/models/images-response-1.md)

## Example Usage

```php
$id = 112;

$body = UpdateImageRequestBuilder::init()
    ->description('My new Image description')
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->build();

$imagesController = $client->getImagesController();

try {
    $result = $imagesController->updateAnImage(
        $id,
        $body
    );
    echo 'ImagesResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "image": {
    "bound_to": null,
    "build_id": "c313fe40383af26094a5a92026054320ab55abc7",
    "created": "2016-01-30T23:50:00+00:00",
    "created_from": {
      "id": 1,
      "name": "Server"
    },
    "deleted": null,
    "deprecated": "2018-02-28T00:00:00+00:00",
    "description": "My new Image description",
    "disk_size": 10,
    "id": 4711,
    "image_size": 2.3,
    "labels": {
      "labelkey": "value"
    },
    "name": null,
    "os_flavor": "ubuntu",
    "os_version": "20.04",
    "protection": {
      "delete": false
    },
    "rapid_deploy": false,
    "status": "available",
    "type": "snapshot"
  }
}
```

