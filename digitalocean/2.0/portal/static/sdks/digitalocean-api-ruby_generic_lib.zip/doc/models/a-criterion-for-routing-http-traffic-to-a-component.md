
# A Criterion for Routing Http Traffic to a Component

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`ACriterionForRoutingHttpTrafficToAComponent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path` | `String` | Optional | An HTTP path prefix. Paths must start with / and must be unique across all components within an app. |
| `preserve_path_prefix` | `TrueClass \| FalseClass` | Optional | An optional flag to preserve the path that is forwarded to the backend service. By default, the HTTP request path will be trimmed from the left when forwarded to the component. For example, a component with `path=/api` will have requests to `/api/list` trimmed to `/list`. If this value is `true`, the path will remain `/api/list`. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
a_criterion_for_routing_http_traffic_to_a_component = ACriterionForRoutingHttpTrafficToAComponent.new(
  path: '/api',
  preserve_path_prefix: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

