
# Error 2

If issuance or renewal reports `failed`, this property contains information about what happened

## Structure

`Error2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | - |

## Example

```ts
import { Error2 } from 'hetzner-cloud-apilib';

const error2: Error2 = {
  code: 'code2',
  message: 'message4',
};
```

