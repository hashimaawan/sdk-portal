
# Status 24

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |
| `Unavailable` |

## Example

```ts
import { Status24 } from 'hetzner-cloud-apilib';

const status24 = Status24.Available;
```

