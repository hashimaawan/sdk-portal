
# Type 6

Type of billing history entry.

## Enumeration

`Type6`

## Fields

| Name |
|  --- |
| `ACHFAILURE` |
| `ADJUSTMENT` |
| `ATTEMPTFAILED` |
| `CHARGEBACK` |
| `CREDIT` |
| `CREDITEXPIRATION` |
| `INVOICE` |
| `PAYMENT` |
| `REFUND` |
| `REVERSAL` |

## Example

```ruby
type6 = Type6::CREDIT
```

