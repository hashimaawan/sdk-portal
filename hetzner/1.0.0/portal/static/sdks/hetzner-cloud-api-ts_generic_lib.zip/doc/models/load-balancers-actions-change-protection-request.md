
# Load Balancers Actions Change Protection Request

*This model accepts additional fields of type unknown.*

## Structure

`LoadBalancersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the Load Balancer from being deleted |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  LoadBalancersActionsChangeProtectionRequest,
} from 'hetzner-cloud-apilib';

const loadBalancersActionsChangeProtectionRequest: LoadBalancersActionsChangeProtectionRequest = {
  mDelete: true,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

