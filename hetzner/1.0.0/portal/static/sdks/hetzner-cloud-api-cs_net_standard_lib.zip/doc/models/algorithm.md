
# Algorithm

Algorithm of the Load Balancer

*This model accepts additional fields of type object.*

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Type28`](../../doc/models/type-28.md) | Required | Type of the algorithm |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

Algorithm algorithm = new Algorithm
{
    Type = Type28.RoundRobin,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

