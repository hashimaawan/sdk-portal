
# Parameter Sort

## Enumeration

`ParameterSort`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Command` |
| `EnumCommandasc` |
| `EnumCommanddesc` |
| `Status` |
| `EnumStatusasc` |
| `EnumStatusdesc` |
| `Progress` |
| `EnumProgressasc` |
| `EnumProgressdesc` |
| `Started` |
| `EnumStartedasc` |
| `EnumStarteddesc` |
| `Finished` |
| `EnumFinishedasc` |
| `EnumFinisheddesc` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    parameterSort := models.ParameterSort_EnumStatusdesc

}
```

