# Forex

```python
forex_api = client.forex
```

## Class Name

`ForexApi`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```python
def get_quotes_for_all_symbols(self)
```

## Response Type

**200**: A list of quotes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```python
result = forex_api.get_quotes_for_all_symbols()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```python
def get_a_list_of_symbols_for_which_we_provide_real_time_quotes(self)
```

## Response Type

**200**: A list of symbols

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `List[str]`.

## Example Usage

```python
result = forex_api.get_a_list_of_symbols_for_which_we_provide_real_time_quotes()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

