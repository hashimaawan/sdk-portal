# Items

Access and manage items inside 1Password Vaults

```php
$itemsApi = $client->getItemsApi();
```

## Class Name

`ItemsApi`

## Methods

* [Get Vault Items](../../doc/controllers/items.md#get-vault-items)
* [Create Vault Item](../../doc/controllers/items.md#create-vault-item)
* [Delete Vault Item](../../doc/controllers/items.md#delete-vault-item)
* [Get Vault Item by Id](../../doc/controllers/items.md#get-vault-item-by-id)
* [Patch Vault Item](../../doc/controllers/items.md#patch-vault-item)
* [Update Vault Item](../../doc/controllers/items.md#update-vault-item)


# Get Vault Items

```php
function getVaultItems(string $vaultUuid, ?string $filter = null): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `filter` | `?string` | Query, Optional | Filter the Item collection based on Item name using SCIM eq filter |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`Item[]`](../../doc/models/item.md).

## Example Usage

```php
$vaultUuid = 'vaultUuid2';

$filter = 'title eq "Some Item Name"';

$itemsApi = $client->getItemsApi();
$apiResponse = $itemsApi->getVaultItems(
    $vaultUuid,
    $filter
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'Item[]:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Vault not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Create Vault Item

```php
function createVaultItem(string $vaultUuid, ?FullItem $body = null): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to create an Item in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`?FullItem`](../../doc/models/full-item.md) | Body, Optional | - |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```php
$vaultUuid = 'vaultUuid2';

$body = FullItemBuilder::init(
    Category::MEMBERSHIP,
    Vault1Builder::init(
        'id6'
    )->build()
)
    ->favorite(false)
    ->urls(
        [
            UrlBuilder::init(
                'https://example.com'
            )
                ->primary(true)
                ->build(),
            UrlBuilder::init(
                'https://example.org'
            )->build()
        ]
    )->build();

$itemsApi = $client->getItemsApi();
$apiResponse = $itemsApi->createVaultItem(
    $vaultUuid,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'FullItem:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Unable to create item due to invalid input | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Delete Vault Item

```php
function deleteVaultItem(string $vaultUuid, string $itemUuid): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault the item is in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**204**: Successfully deleted an item

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$vaultUuid = 'vaultUuid2';

$itemUuid = 'itemUuid6';

$itemsApi = $client->getItemsApi();
$apiResponse = $itemsApi->deleteVaultItem(
    $vaultUuid,
    $itemUuid
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Vault Item by Id

```php
function getVaultItemById(string $vaultUuid, string $itemUuid): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Item from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to fetch<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```php
$vaultUuid = 'vaultUuid2';

$itemUuid = 'itemUuid6';

$itemsApi = $client->getItemsApi();
$apiResponse = $itemsApi->getVaultItemById(
    $vaultUuid,
    $itemUuid
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'FullItem:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Patch Vault Item

Applies a modified [RFC6902 JSON Patch](https://tools.ietf.org/html/rfc6902) document to an Item or ItemField. This endpoint only supports `add`, `remove` and `replace` operations.

When modifying a specific ItemField, the ItemField's ID in the `path` attribute of the operation object: `/fields/{fieldId}`

```php
function patchVaultItem(string $vaultUuid, string $itemUuid, ?array $body = null): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault the item is in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`?(Patch[])`](../../doc/models/patch.md) | Body, Optional | - |

## Response Type

**200**: OK - Item updated. If no Patch operations were provided, Item is unmodified.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```php
$vaultUuid = 'vaultUuid2';

$itemUuid = 'itemUuid6';

$body = [
    PatchBuilder::init(
        Op::ADD,
        '/fields'
    )
        ->value(ApiHelper::deserialize('{"label":"New Field","type":"string","value":"hunter2"}'))
        ->build()
];

$itemsApi = $client->getItemsApi();
$apiResponse = $itemsApi->patchVaultItem(
    $vaultUuid,
    $itemUuid,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'FullItem:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Vault Item

```php
function updateVaultItem(string $vaultUuid, string $itemUuid, ?FullItem $body = null): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Item's Vault<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`?FullItem`](../../doc/models/full-item.md) | Body, Optional | - |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```php
$vaultUuid = 'vaultUuid2';

$itemUuid = 'itemUuid6';

$body = FullItemBuilder::init(
    Category::MEMBERSHIP,
    Vault1Builder::init(
        'id6'
    )->build()
)
    ->favorite(false)
    ->urls(
        [
            UrlBuilder::init(
                'https://example.com'
            )
                ->primary(true)
                ->build(),
            UrlBuilder::init(
                'https://example.org'
            )->build()
        ]
    )->build();

$itemsApi = $client->getItemsApi();
$apiResponse = $itemsApi->updateVaultItem(
    $vaultUuid,
    $itemUuid,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'FullItem:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Unable to create item due to invalid input | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

