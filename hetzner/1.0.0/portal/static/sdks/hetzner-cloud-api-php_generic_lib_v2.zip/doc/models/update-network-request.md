
# Update Network Request

*This model accepts additional fields of type array.*

## Structure

`UpdateNetworkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `labels` | [`?Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) | getLabels(): ?Labels2 | setLabels(?Labels2 labels): void |
| `name` | `?string` | Optional | New network name | getName(): ?string | setName(?string name): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\UpdateNetworkRequestBuilder;
use HetznerCloudApiLib\Models\Builders\Labels2Builder;
use HetznerCloudApiLib\ApiHelper;

$updateNetworkRequest = UpdateNetworkRequestBuilder::init()
    ->labels(
        Labels2Builder::init()
            ->labelkey('labelkey4')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->name('new-name')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

