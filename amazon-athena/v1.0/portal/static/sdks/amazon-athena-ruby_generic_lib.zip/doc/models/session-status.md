
# Session Status

Contains information about the status of a session.

## Structure

`SessionStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `start_date_time` | `DateTime` | Optional | - |
| `last_modified_date_time` | `DateTime` | Optional | - |
| `end_date_time` | `DateTime` | Optional | - |
| `idle_since_date_time` | `DateTime` | Optional | - |
| `state` | [`SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |
| `state_change_reason` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
session_status = SessionStatus.new(
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  SessionState1Enum::IDLE
)
```

