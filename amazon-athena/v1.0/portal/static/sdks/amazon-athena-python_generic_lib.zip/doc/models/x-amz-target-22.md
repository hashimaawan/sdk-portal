
# X Amz Target 22

## Enumeration

`XAmzTarget22`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_22 import XAmzTarget22

x_amz_target_22 = XAmzTarget22.ENUM_AMAZONATHENAGETPREPAREDSTATEMENT
```

