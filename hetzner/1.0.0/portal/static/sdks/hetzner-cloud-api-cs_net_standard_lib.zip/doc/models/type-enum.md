
# Type Enum

Type of the Certificate

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

TypeEnum type = TypeEnum.Uploaded;
```

