
# Os Flavor Enum

Flavor of operating system contained in the Image

## Enumeration

`OsFlavorEnum`

## Fields

| Name |
|  --- |
| `Ubuntu` |
| `Centos` |
| `Debian` |
| `Fedora` |
| `Unknown` |

## Example

```ts
import { OsFlavorEnum } from 'hetzner-cloud-apilib';

const osFlavor = OsFlavorEnum.Debian;
```

