
# Status 30

## Enumeration

`Status30`

## Fields

| Name |
|  --- |
| `HEALTHY` |
| `UNHEALTHY` |
| `UNKNOWN` |

## Example

```ruby
status30 = Status30::HEALTHY
```

