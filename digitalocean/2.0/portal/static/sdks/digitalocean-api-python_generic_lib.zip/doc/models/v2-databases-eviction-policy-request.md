
# V2 Databases Eviction Policy Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DatabasesEvictionPolicyRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `eviction_policy` | [`RedisMaxmemoryPolicy`](../../doc/models/redis-maxmemory-policy.md) | Required | A string specifying the desired eviction policy for the Redis cluster.<br><br>- `noeviction`: Don't evict any data, returns error when memory limit is reached.<br>- `allkeys_lru:` Evict any key, least recently used (LRU) first.<br>- `allkeys_random`: Evict keys in a random order.<br>- `volatile_lru`: Evict keys with expiration only, least recently used (LRU) first.<br>- `volatile_random`: Evict keys with expiration only in a random order.<br>- `volatile_ttl`: Evict keys with expiration only, shortest time-to-live (TTL) first. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.redis_maxmemory_policy import RedisMaxmemoryPolicy
from digitaloceanapi.models.v_2_databases_eviction_policy_request import V2DatabasesEvictionPolicyRequest

v_2_databases_eviction_policy_request = V2DatabasesEvictionPolicyRequest(
    eviction_policy=RedisMaxmemoryPolicy.ALLKEYS_LRU,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

