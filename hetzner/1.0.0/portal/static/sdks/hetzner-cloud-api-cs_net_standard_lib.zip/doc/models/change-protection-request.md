
# Change Protection Request

## Structure

`ChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool?` | Optional | If true, prevents the Floating IP from being deleted |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ChangeProtectionRequest changeProtectionRequest = new ChangeProtectionRequest
{
    Delete = true,
};
```

