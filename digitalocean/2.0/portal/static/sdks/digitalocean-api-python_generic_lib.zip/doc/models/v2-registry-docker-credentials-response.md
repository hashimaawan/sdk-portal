
# V2 Registry Docker Credentials Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2RegistryDockerCredentialsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auths` | [`Auths`](../../doc/models/auths.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.auths import Auths
from digitaloceanapi.models.registry_digitalocean_com import RegistryDigitaloceanCom
from digitaloceanapi.models.v_2_registry_docker_credentials_response import V2RegistryDockerCredentialsResponse

v_2_registry_docker_credentials_response = V2RegistryDockerCredentialsResponse(
    auths=Auths(
        registry_digitalocean_com=RegistryDigitaloceanCom(
            auth='auth0',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

