
# Column Nullable

## Enumeration

`ColumnNullable`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```ruby
column_nullable = ColumnNullable::UNKNOWN
```

