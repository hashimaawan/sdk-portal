
# Status 11

An object containing a `state` attribute whose value is set to a string indicating the current status of the cluster.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Status11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | An optional message providing additional information about the current cluster state. |
| `state` | [`State2 \| undefined`](../../doc/models/state-2.md) | Optional | A string indicating the current status of the cluster. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { State2, Status11 } from 'digitalocean-apilib';

const status11: Status11 = {
  message: 'provisioning',
  state: State2.Provisioning,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

