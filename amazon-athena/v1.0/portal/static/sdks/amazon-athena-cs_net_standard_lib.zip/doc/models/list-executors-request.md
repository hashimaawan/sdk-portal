
# List Executors Request

*This model accepts additional fields of type object.*

## Structure

`ListExecutorsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ExecutorStateFilter` | [`ExecutorState1?`](../../doc/models/executor-state-1.md) | Optional | - |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `string` | Optional | **Constraints**: *Maximum Length*: `2048` |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

ListExecutorsRequest listExecutorsRequest = new ListExecutorsRequest
{
    SessionId = "SessionId0",
    ExecutorStateFilter = ExecutorState1.Creating,
    MaxResults = 100,
    NextToken = "NextToken8",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

