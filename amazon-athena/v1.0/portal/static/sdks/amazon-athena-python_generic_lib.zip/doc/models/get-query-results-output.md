
# Get Query Results Output

*This model accepts additional fields of type Any.*

## Structure

`GetQueryResultsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `update_count` | `int` | Optional | - |
| `result_set` | [`ResultSet2`](../../doc/models/result-set-2.md) | Optional | - |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.column_info import ColumnInfo
from amazonathena.models.datum import Datum
from amazonathena.models.get_query_results_output import GetQueryResultsOutput
from amazonathena.models.result_set_2 import ResultSet2
from amazonathena.models.result_set_metadata_2 import ResultSetMetadata2
from amazonathena.models.row import Row

get_query_results_output = GetQueryResultsOutput(
    update_count=242,
    result_set=ResultSet2(
        rows=[
            Row(
                data=[
                    Datum(
                        var_char_value='VarCharValue8',
                        additional_properties={
                            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                        }
                    ),
                    Datum(
                        var_char_value='VarCharValue8',
                        additional_properties={
                            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                        }
                    )
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Row(
                data=[
                    Datum(
                        var_char_value='VarCharValue8',
                        additional_properties={
                            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                        }
                    ),
                    Datum(
                        var_char_value='VarCharValue8',
                        additional_properties={
                            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                        }
                    )
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        result_set_metadata=ResultSetMetadata2(
            column_info=[
                ColumnInfo(
                    name='Name6',
                    mtype='Type6',
                    catalog_name='CatalogName0',
                    schema_name='SchemaName0',
                    table_name='TableName2',
                    label='Label4',
                    precision=48,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    next_token='NextToken0',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

