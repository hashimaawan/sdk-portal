
# Change Loadbalancer Dns Ptr Request

## Structure

`ChangeLoadbalancerDnsPtrRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DnsPtr` | `string` | Required | Hostname to set as a reverse DNS PTR entry |
| `Ip` | `string` | Required | Public IP address for which the reverse DNS entry should be set |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ChangeLoadbalancerDnsPtrRequest changeLoadbalancerDnsPtrRequest = new ChangeLoadbalancerDnsPtrRequest
{
    DnsPtr = "lb1.example.com",
    Ip = "1.2.3.4",
};
```

