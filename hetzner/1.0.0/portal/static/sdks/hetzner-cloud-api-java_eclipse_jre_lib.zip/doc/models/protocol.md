
# Protocol

Type of traffic to allow

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |
| `ESP` |
| `GRE` |

## Example

```java
import cloud.hetzner.api.models.Protocol;

Protocol protocol = Protocol.ESP;
```

