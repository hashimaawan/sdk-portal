
# List Databases Input

## Structure

`ListDatabasesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalog_name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `int` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```python
from amazonathena.models.list_databases_input import ListDatabasesInput

list_databases_input = ListDatabasesInput(
    catalog_name='CatalogName0',
    next_token='NextToken6',
    max_results=2
)
```

