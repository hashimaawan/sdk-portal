
# Detach from Network Request

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Network` | `int` | Required | ID of an existing network to detach the Server from |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    detachFromNetworkRequest := models.DetachFromNetworkRequest{
        Network:              4711,
    }

}
```

