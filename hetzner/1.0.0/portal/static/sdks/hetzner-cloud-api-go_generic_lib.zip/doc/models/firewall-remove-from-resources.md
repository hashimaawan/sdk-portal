
# Firewall Remove from Resources

*This model accepts additional fields of type interface{}.*

## Structure

`FirewallRemoveFromResources`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LabelSelector` | [`*models.LabelSelector5`](../../doc/models/label-selector-5.md) | Optional | Configuration for type label_selector, required if type is `label_selector` |
| `Server` | [`*models.Server9`](../../doc/models/server-9.md) | Optional | Configuration for type server, required if type is `server` |
| `Type` | [`*models.Type7`](../../doc/models/type-7.md) | Optional | Type of the resource |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    firewallRemoveFromResources := models.FirewallRemoveFromResources{
        LabelSelector:         models.ToPointer(models.LabelSelector5{
            Selector:              "selector8",
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        Server:                models.ToPointer(models.Server9{
            Id:                    14,
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        Type:                  models.ToPointer(models.Type7_Server),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

