
# Mysql Settings

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`MysqlSettings`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auth_plugin` | [`AuthPlugin`](../../doc/models/auth-plugin.md) | Required | A string specifying the authentication method to be used for connections<br>to the MySQL user account. The valid values are `mysql_native_password`<br>or `caching_sha2_password`. If excluded when creating a new user, the<br>default for the version of MySQL in use will be used. As of MySQL 8.0, the<br>default is `caching_sha2_password`. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.auth_plugin import AuthPlugin
from digitaloceanapi.models.mysql_settings import MysqlSettings

mysql_settings = MysqlSettings(
    auth_plugin=AuthPlugin.MYSQL_NATIVE_PASSWORD,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

