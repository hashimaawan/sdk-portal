
# Type 66

## Enumeration

`Type66`

## Fields

| Name |
|  --- |
| `Cpu` |
| `Disk` |
| `Network` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type66 type66 = Type66.Network;
```

