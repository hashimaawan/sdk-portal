
# Item Type 3

The ID type: either `artist` or `user`.

## Enumeration

`ItemType3`

## Fields

| Name |
|  --- |
| `ARTIST` |
| `USER` |

## Example

```ruby
item_type3 = ItemType3::ARTIST
```

