
# V2 Reserved Ips Response 2

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ReservedIpsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservedIp` | [`ReservedIp \| undefined`](../../doc/models/reserved-ip.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2ReservedIpsResponse2 } from 'digitalocean-apilib';

const v2ReservedIpsResponse2: V2ReservedIpsResponse2 = {
  reservedIp: {
    droplet: { 'key1': 'val1', 'key2': 'val2' },
    ip: 'ip6',
    locked: false,
    projectId: '00002548-0000-0000-0000-000000000000',
    region: {
      available: false,
      features: [
        'features7',
        'features8',
        'features9'
      ],
      name: 'name6',
      sizes: [
        'sizes6'
      ],
      slug: 'slug0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

