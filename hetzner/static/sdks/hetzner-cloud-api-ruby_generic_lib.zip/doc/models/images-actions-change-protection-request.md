
# Images Actions Change Protection Request

## Structure

`ImagesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the snapshot from being deleted |

## Example

```ruby
images_actions_change_protection_request = ImagesActionsChangeProtectionRequest.new(
  true
)
```

