
# Health Status

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ListenPort` | `*int` | Optional | - |
| `Status` | [`*models.Status30Enum`](../../doc/models/status-30-enum.md) | Optional | - |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    healthStatus := models.HealthStatus{
        ListenPort:           models.ToPointer(443),
        Status:               models.ToPointer(models.Status30Enum_HEALTHY),
    }

}
```

