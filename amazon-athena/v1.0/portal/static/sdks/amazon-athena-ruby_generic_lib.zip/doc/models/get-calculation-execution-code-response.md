
# Get Calculation Execution Code Response

*This model accepts additional fields of type Object.*

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code_block` | `String` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_calculation_execution_code_response = GetCalculationExecutionCodeResponse.new(
  code_block: 'CodeBlock2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

