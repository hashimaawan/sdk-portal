
# Meta

The Meta Object contains basic information regarding the request, whether it was successful, and the response given by the API.  Check `responses` to see a description of types of response codes the API might give you under different cirumstances.

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `msg` | `string \| undefined` | Optional | HTTP Response Message |
| `responseId` | `string \| undefined` | Optional | A unique ID paired with this response from the API. |
| `status` | `number \| undefined` | Optional | HTTP Response Code |

## Example

```ts
import { Meta } from 'giphy-apilib';

const meta: Meta = {
  msg: 'OK',
  responseId: '57eea03c72381f86e05c35d2',
  status: 200,
};
```

