
# Type 28 Enum

Type of the algorithm

## Enumeration

`Type28Enum`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```ts
import { Type28Enum } from 'hetzner-cloud-apilib';

const type28 = Type28Enum.RoundRobin;
```

