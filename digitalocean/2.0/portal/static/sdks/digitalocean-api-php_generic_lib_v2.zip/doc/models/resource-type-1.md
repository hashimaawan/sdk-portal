
# Resource Type 1

The type of resource that the snapshot originated from.

## Enumeration

`ResourceType1`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `VOLUME` |

## Example

```php
use DigitalOceanApiLib\Models\ResourceType1;

$resourceType1 = ResourceType1::DROPLET;
```

