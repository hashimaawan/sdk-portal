
# Calculation Summary

Summary information for a notebook calculation.

## Structure

`CalculationSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `status` | [`Status1`](../../doc/models/status-1.md) | Optional | - |

## Example

```ruby
calculation_summary = CalculationSummary.new(
  'CalculationExecutionId2',
  'Description4',
  Status1.new(
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    CalculationExecutionState1Enum::CANCELING,
    'StateChangeReason8'
  )
)
```

