
# Storage Type Enum

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageTypeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `NETWORK` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    storageType := models.StorageTypeEnum_LOCAL

}
```

