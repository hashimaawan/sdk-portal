
# Eligibility Reason

## Enumeration

`EligibilityReason`

## Fields

| Name |
|  --- |
| `OVERREPOSITORYLIMIT` |
| `OVERSTORAGELIMIT` |

## Example

```ruby
eligibility_reason = EligibilityReason::OVERREPOSITORYLIMIT
```

