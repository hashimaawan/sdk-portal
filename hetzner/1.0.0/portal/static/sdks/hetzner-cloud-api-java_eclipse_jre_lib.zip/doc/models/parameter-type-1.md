
# Parameter Type 1

## Enumeration

`ParameterType1`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```java
import cloud.hetzner.api.models.ParameterType1;

ParameterType1 parameterType1 = ParameterType1.SPREAD;
```

