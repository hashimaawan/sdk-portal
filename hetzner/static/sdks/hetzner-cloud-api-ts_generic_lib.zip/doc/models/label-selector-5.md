
# Label Selector 5

Configuration for type label_selector, required if type is `label_selector`

## Structure

`LabelSelector5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector |

## Example

```ts
import { LabelSelector5 } from 'hetzner-cloud-apilib';

const labelSelector5: LabelSelector5 = {
  selector: 'env=prod',
};
```

