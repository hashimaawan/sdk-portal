
# Acl Configuration 1

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `S3AclOption` | [`S3AclOption1Enum`](../../doc/models/s3-acl-option-1-enum.md) | Required | - | S3AclOption1Enum getS3AclOption() | setS3AclOption(S3AclOption1Enum s3AclOption) |

## Example

```java
import com.amazonaws.useast1.athena.models.AclConfiguration1;
import com.amazonaws.useast1.athena.models.S3AclOption1Enum;

AclConfiguration1 aclConfiguration1 = new AclConfiguration1.Builder(
    S3AclOption1Enum.BUCKET_OWNER_FULL_CONTROL
)
.build();
```

