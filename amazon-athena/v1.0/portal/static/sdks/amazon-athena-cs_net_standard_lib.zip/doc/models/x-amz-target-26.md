
# X Amz Target 26

## Enumeration

`XAmzTarget26`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetSession` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget26 xAmzTarget26 = XAmzTarget26.EnumAmazonAthenaGetSession;
```

