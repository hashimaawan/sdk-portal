
# Start Query Execution Output

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `queryExecutionId` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getQueryExecutionId(): ?string | setQueryExecutionId(?string queryExecutionId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\StartQueryExecutionOutputBuilder;

$startQueryExecutionOutput = StartQueryExecutionOutputBuilder::init()
    ->queryExecutionId('QueryExecutionId0')
    ->build();
```

