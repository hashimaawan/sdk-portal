
# List Engine Versions Input

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 10` |

## Example

```ts
import { ListEngineVersionsInput } from 'amazon-athenalib';

const listEngineVersionsInput: ListEngineVersionsInput = {
  nextToken: 'NextToken6',
  maxResults: 10,
};
```

