
# V2 Tags Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2TagsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tag` | [`Tag \| undefined`](../../doc/models/tag.md) | Optional | A tag is a label that can be applied to a resource (currently Droplets, Images, Volumes, Volume Snapshots, and Database clusters) in order to better organize or facilitate the lookups and actions on it.<br>Tags have two attributes: a user defined `name` attribute and an embedded `resources` attribute with information about resources that have been tagged. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2TagsResponse1 } from 'digitalocean-apilib';

const v2TagsResponse1: V2TagsResponse1 = {
  tag: {
    name: 'extra-awesome',
    resources: {
      count: 0,
      lastTaggedUri: 'last_tagged_uri6',
      databases: {
        count: 0,
        lastTaggedUri: 'last_tagged_uri2',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      droplets: {
        count: 0,
        lastTaggedUri: 'last_tagged_uri6',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      imgages: {
        count: 158,
        lastTaggedUri: 'last_tagged_uri4',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      volumeSnapshots: {
        count: 0,
      },
      volumes: {
        count: 0,
      },
      additionalProperties: {
        'images': { 'count': 0 }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

