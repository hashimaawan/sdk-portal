
# State

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `Archived` |
| `Deleted` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    state := models.State_Archived

}
```

