
# Type 41

## Enumeration

`Type41`

## Fields

| Name |
|  --- |
| `OPEN_CONNECTIONS` |
| `CONNECTIONS_PER_SECOND` |
| `REQUESTS_PER_SECOND` |
| `BANDWIDTH` |

## Example

```python
from hetznercloudapi.models.type_41 import Type41

type_41 = Type41.OPEN_CONNECTIONS
```

