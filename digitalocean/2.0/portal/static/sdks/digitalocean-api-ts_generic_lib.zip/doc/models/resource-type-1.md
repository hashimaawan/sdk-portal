
# Resource Type 1

The type of resource that the snapshot originated from.

## Enumeration

`ResourceType1`

## Fields

| Name |
|  --- |
| `Droplet` |
| `Volume` |

## Example

```ts
import { ResourceType1 } from 'digitalocean-apilib';

const resourceType1 = ResourceType1.Droplet;
```

