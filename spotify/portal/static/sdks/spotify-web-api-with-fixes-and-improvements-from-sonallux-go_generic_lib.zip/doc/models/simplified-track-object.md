
# Simplified Track Object

*This model accepts additional fields of type interface{}.*

## Structure

`SimplifiedTrackObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Artists` | [`[]models.SimplifiedArtistObject`](../../doc/models/simplified-artist-object.md) | Optional | The artists who performed the track. Each artist object includes a link in `href` to more detailed information about the artist. |
| `AvailableMarkets` | `[]string` | Optional | A list of the countries in which the track can be played, identified by their [ISO 3166-1 alpha-2](http://en.wikipedia.org/wiki/ISO_3166-1_alpha-2) code. |
| `DiscNumber` | `*int` | Optional | The disc number (usually `1` unless the album consists of more than one disc). |
| `DurationMs` | `*int` | Optional | The track length in milliseconds. |
| `Explicit` | `*bool` | Optional | Whether or not the track has explicit lyrics ( `true` = yes it does; `false` = no it does not OR unknown). |
| `ExternalUrls` | [`*models.ExternalUrlObject`](../../doc/models/external-url-object.md) | Optional | External URLs for this track. |
| `Href` | `*string` | Optional | A link to the Web API endpoint providing full details of the track. |
| `Id` | `*string` | Optional | The [Spotify ID](/documentation/web-api/concepts/spotify-uris-ids) for the track. |
| `IsPlayable` | `*bool` | Optional | Part of the response when [Track Relinking](/documentation/web-api/concepts/track-relinking/) is applied. If `true`, the track is playable in the given market. Otherwise `false`. |
| `LinkedFrom` | [`*models.LinkedTrackObject`](../../doc/models/linked-track-object.md) | Optional | Part of the response when [Track Relinking](/documentation/web-api/concepts/track-relinking/) is applied and is only part of the response if the track linking, in fact, exists. The requested track has been replaced with a different track. The track in the `linked_from` object contains information about the originally requested track. |
| `Restrictions` | [`*models.TrackRestrictionObject`](../../doc/models/track-restriction-object.md) | Optional | Included in the response when a content restriction is applied. |
| `Name` | `*string` | Optional | The name of the track. |
| `PreviewUrl` | `models.Optional[string]` | Optional | A URL to a 30 second preview (MP3 format) of the track. |
| `TrackNumber` | `*int` | Optional | The number of the track. If an album has several discs, the track number is the number on the specified disc. |
| `Type` | `*string` | Optional | The object type: "track". |
| `Uri` | `*string` | Optional | The [Spotify URI](/documentation/web-api/concepts/spotify-uris-ids) for the track. |
| `IsLocal` | `*bool` | Optional | Whether or not the track is from a local file. |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    simplifiedTrackObject := models.SimplifiedTrackObject{
        Artists:               []models.SimplifiedArtistObject{
            models.SimplifiedArtistObject{
                ExternalUrls:          models.ToPointer(models.ExternalUrlObject{
                    Spotify:               models.ToPointer("spotify6"),
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                }),
                Href:                  models.ToPointer("href2"),
                Id:                    models.ToPointer("id0"),
                Name:                  models.ToPointer("name0"),
                Type:                  models.ToPointer(models.Type_Artist),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            models.SimplifiedArtistObject{
                ExternalUrls:          models.ToPointer(models.ExternalUrlObject{
                    Spotify:               models.ToPointer("spotify6"),
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                }),
                Href:                  models.ToPointer("href2"),
                Id:                    models.ToPointer("id0"),
                Name:                  models.ToPointer("name0"),
                Type:                  models.ToPointer(models.Type_Artist),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        AvailableMarkets:      []string{
            "available_markets0",
            "available_markets1",
            "available_markets2",
        },
        DiscNumber:            models.ToPointer(180),
        DurationMs:            models.ToPointer(244),
        Explicit:              models.ToPointer(false),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

