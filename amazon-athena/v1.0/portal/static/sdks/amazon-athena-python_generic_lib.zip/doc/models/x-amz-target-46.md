
# X Amz Target 46

## Enumeration

`XAmzTarget46`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_46 import XAmzTarget46

x_amz_target_46 = XAmzTarget46.ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION
```

