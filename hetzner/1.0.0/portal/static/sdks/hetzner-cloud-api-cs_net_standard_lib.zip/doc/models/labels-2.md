
# Labels 2

User-defined labels (key-value pairs)

## Structure

`Labels2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labelkey` | `string` | Optional | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Labels2 labels2 = new Labels2
{
    Labelkey = "value",
};
```

