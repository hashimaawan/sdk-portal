
# Query Execution Context 1

*This model accepts additional fields of type array.*

## Structure

`QueryExecutionContext1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `database` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` | getDatabase(): ?string | setDatabase(?string database): void |
| `catalog` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getCatalog(): ?string | setCatalog(?string catalog): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\QueryExecutionContext1Builder;
use AmazonAthenaLib\ApiHelper;

$queryExecutionContext1 = QueryExecutionContext1Builder::init()
    ->database('Database0')
    ->catalog('Catalog6')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

