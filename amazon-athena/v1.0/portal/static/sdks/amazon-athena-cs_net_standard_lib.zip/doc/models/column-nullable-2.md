
# Column Nullable 2

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2`

## Fields

| Name |
|  --- |
| `NotNull` |
| `Nullable` |
| `Unknown` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ColumnNullable2 columnNullable2 = ColumnNullable2.NotNull;
```

