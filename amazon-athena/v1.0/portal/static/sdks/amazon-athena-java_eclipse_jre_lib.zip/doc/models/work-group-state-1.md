
# Work Group State 1

The state of the workgroup.

## Enumeration

`WorkGroupState1`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```java
import com.amazonaws.useast1.athena.models.WorkGroupState1;

WorkGroupState1 workGroupState1 = WorkGroupState1.ENABLED;
```

