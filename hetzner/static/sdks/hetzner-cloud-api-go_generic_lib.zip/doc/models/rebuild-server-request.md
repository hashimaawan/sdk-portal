
# Rebuild Server Request

## Structure

`RebuildServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Image` | `string` | Required | ID or name of Image to rebuilt from. |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    rebuildServerRequest := models.RebuildServerRequest{
        Image:                "ubuntu-20.04",
    }

}
```

