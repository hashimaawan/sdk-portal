# Vaults

Access 1Password Vaults

```ts
const vaultsApi = new VaultsApi(client);
```

## Class Name

`VaultsApi`

## Methods

* [Get Vaults](../../doc/controllers/vaults.md#get-vaults)
* [Get Vault by Id](../../doc/controllers/vaults.md#get-vault-by-id)


# Get Vaults

```ts
async getVaults(
  filter?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<Vault[]>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filter` | `string \| undefined` | Query, Optional | Filter the Vault collection based on Vault name using SCIM eq filter |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`Vault[]`](../../doc/models/vault.md).

## Example Usage

```ts
const filter = 'name eq "Some Vault Name"';

try {
  const response = await vaultsApi.getVaults(filter);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Get Vault by Id

```ts
async getVaultById(
  vaultUuid: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<Vault>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`Vault`](../../doc/models/vault.md).

## Example Usage

```ts
const vaultUuid = 'vaultUuid2';

try {
  const response = await vaultsApi.getVaultById(vaultUuid);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 403 | Unauthorized access | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | Vault not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

