
# Status 30

## Enumeration

`Status30`

## Fields

| Name |
|  --- |
| `Healthy` |
| `Unhealthy` |
| `Unknown` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Status30 status30 = Status30.Healthy;
```

