
# V2 Volumes Actions Request 2

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2VolumesActionsRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `region` | [`Region2`](../../doc/models/region-2.md) | Optional | The slug identifier for the region where the resource will initially be  available. |
| `mtype` | [`Type21`](../../doc/models/type-21.md) | Required | The volume action to initiate. |
| `size_gigabytes` | `int` | Required | The new size of the block storage volume in GiB (1024^3).<br><br>**Constraints**: `<= 16384` |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.region_2 import Region2
from digitaloceanapi.models.type_21 import Type21
from digitaloceanapi.models.v_2_volumes_actions_request_2 import V2VolumesActionsRequest2

v_2_volumes_actions_request_2 = V2VolumesActionsRequest2(
    mtype=Type21.ATTACH,
    size_gigabytes=15384,
    region=Region2.NYC3,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

