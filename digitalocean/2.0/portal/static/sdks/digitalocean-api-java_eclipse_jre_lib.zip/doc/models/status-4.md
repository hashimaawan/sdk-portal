
# Status 4

A string representing the current status of the database cluster.

## Enumeration

`Status4`

## Fields

| Name |
|  --- |
| `CREATING` |
| `ONLINE` |
| `RESIZING` |
| `MIGRATING` |
| `FORKING` |

## Example

```java
import com.digitalocean.api.models.Status4;

Status4 status4 = Status4.RESIZING;
```

