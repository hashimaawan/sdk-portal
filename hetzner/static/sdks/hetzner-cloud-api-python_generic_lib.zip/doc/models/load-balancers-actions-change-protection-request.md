
# Load Balancers Actions Change Protection Request

## Structure

`LoadBalancersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Optional | If true, prevents the Load Balancer from being deleted |

## Example

```python
from hetznercloudapi.models.load_balancers_actions_change_protection_request import LoadBalancersActionsChangeProtectionRequest

load_balancers_actions_change_protection_request = LoadBalancersActionsChangeProtectionRequest(
    delete=True
)
```

