
# Price Hourly 8

Hourly costs for a Server type in this Location

## Structure

`PriceHourly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `String` | Required | Price with VAT added |
| `net` | `String` | Required | Price without VAT |

## Example

```ruby
price_hourly8 = PriceHourly8.new(
  '1.1900000000000000',
  '1.0000000000'
)
```

