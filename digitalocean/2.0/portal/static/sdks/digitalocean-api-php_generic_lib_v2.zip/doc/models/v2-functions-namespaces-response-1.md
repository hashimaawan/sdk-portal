
# V2 Functions Namespaces Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `namespace` | [`?MNamespace`](../../doc/models/m-namespace.md) | Optional | - | getNamespace(): ?MNamespace | setNamespace(?MNamespace namespace): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FunctionsNamespacesResponse1Builder;
use DigitalOceanApiLib\Models\Builders\MNamespaceBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2FunctionsNamespacesResponse1 = V2FunctionsNamespacesResponse1Builder::init()
    ->namespace(
        MNamespaceBuilder::init()
            ->apiHost('api_host2')
            ->createdAt('created_at0')
            ->key('key2')
            ->label('label2')
            ->namespace('namespace0')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

