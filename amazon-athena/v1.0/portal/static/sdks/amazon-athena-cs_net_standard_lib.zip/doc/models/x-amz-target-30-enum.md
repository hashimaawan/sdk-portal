
# X Amz Target 30 Enum

## Enumeration

`XAmzTarget30Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaImportNotebook` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget30Enum xAmzTarget30 = XAmzTarget30Enum.EnumAmazonAthenaImportNotebook;
```

