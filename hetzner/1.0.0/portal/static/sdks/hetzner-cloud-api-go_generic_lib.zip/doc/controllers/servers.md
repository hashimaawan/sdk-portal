# Servers

Servers are virtual machines that can be provisioned.

```go
serversApi := client.ServersApi()
```

## Class Name

`ServersApi`

## Methods

* [Get All Servers](../../doc/controllers/servers.md#get-all-servers)
* [Create a Server](../../doc/controllers/servers.md#create-a-server)
* [Delete a Server](../../doc/controllers/servers.md#delete-a-server)
* [Get a Server](../../doc/controllers/servers.md#get-a-server)
* [Update a Server](../../doc/controllers/servers.md#update-a-server)
* [Get Metrics for a Server](../../doc/controllers/servers.md#get-metrics-for-a-server)


# Get All Servers

Returns all existing Server objects

```go
GetAllServers(
    ctx context.Context,
    name *string,
    labelSelector *string,
    sort *models.Sort,
    status *models.Status70) (
    models.ApiResponse[models.ServersResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `*string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `*string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `sort` | [`*models.Sort`](../../doc/models/sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`*models.Status70`](../../doc/models/status-70.md) | Query, Optional | Can be used multiple times. The response will only contain Server matching the status |

## Response Type

**200**: A paged array of servers

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ServersResponse](../../doc/models/servers-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := serversApi.GetAllServers(ctx, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Create a Server

Creates a new Server. Returns preliminary information about the Server as well as an Action that covers progress of creation.

```go
CreateAServer(
    ctx context.Context,
    body *models.CreateServerRequest) (
    models.ApiResponse[models.CreateServerResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`*models.CreateServerRequest`](../../doc/models/create-server-request.md) | Body, Optional | Please note that Server names must be unique per Project and valid hostnames as per RFC 1123 (i.e. may only contain letters, digits, periods, and dashes).<br><br>For `server_type` you can either use the ID as listed in `/server_types` or its name.<br><br>For `image` you can either use the ID as listed in `/images` or its name.<br><br>If you want to create the Server in a Location, you must set `location` to the ID or name as listed in `/locations`. This is the recommended way. You can be even more specific by setting `datacenter` to the ID or name as listed in `/datacenters`. However we only recommend this if you want to assign a specific Primary IP to the Server which is located in the specified Datacenter.<br><br>Some properties like `start_after_create` or `automount` will trigger Actions after the Server is created. Those Actions are listed in the `next_actions` field in the response.<br><br>For accessing your Server we strongly recommend to use SSH keys by passing the respective key IDs in `ssh_keys`. If you do not specify any `ssh_keys` we will generate a root password for you and return it in the response.<br><br>Please note that provided user-data is stored in our systems. While we take measures to protect it we highly recommend that you don’t use it to store passwords or other sensitive information.<br><br>#### Call specific error codes<br><br>\| Code                             \| Description                                                \|<br>\|----------------------------------\|------------------------------------------------------------\|<br>\| `placement_error`                \| An error during the placement occurred                     \|<br>\| `primary_ip_assigned`            \| The specified Primary IP is already assigned to a server   \|<br>\| `primary_ip_datacenter_mismatch` \| The specified Primary IP is in a different datacenter      \|<br>\| `primary_ip_version_mismatch`    \| The specified Primary IP has the wrong IP Version          \| |

## Response Type

**201**: The `server` key in the reply contains a Server object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CreateServerResponse](../../doc/models/create-server-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.CreateServerRequest{
    Automount:             models.ToPointer(false),
    Datacenter:            models.ToPointer("nbg1-dc3"),
    Firewalls:             []models.Firewall4{
        models.Firewall4{
            Firewall:              models.ToPointer(38),
        },
    },
    Image:                 "ubuntu-20.04",
    Location:              models.ToPointer("nbg1"),
    Name:                  "my-server",
    Networks:              []int{
        456,
    },
    PlacementGroup:        models.ToPointer(1),
    ServerType:            "cx11",
    SshKeys:               []string{
        "my-ssh-key",
    },
    StartAfterCreate:      models.ToPointer(true),
    UserData:              models.ToPointer("#cloud-config\nruncmd:\n- [touch, /root/cloud-init-worked]\n"),
    Volumes:               []int{
        123,
    },
}

apiResponse, err := serversApi.CreateAServer(ctx, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_server",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 1,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "next_actions": [
    {
      "command": "start_server",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": null,
      "id": 13,
      "progress": 0,
      "resources": [
        {
          "id": 42,
          "type": "server"
        }
      ],
      "started": "2016-01-30T23:50:00+00:00",
      "status": "running"
    }
  ],
  "root_password": "YItygq1v3GYjjMomLaKc",
  "server": {
    "backup_window": "22-02",
    "created": "2016-01-30T23:50:00+00:00",
    "datacenter": {
      "description": "Falkenstein 1 DC 8",
      "id": 1,
      "location": {
        "city": "Falkenstein",
        "country": "DE",
        "description": "Falkenstein DC Park 1",
        "id": 1,
        "latitude": 50.47612,
        "longitude": 12.370071,
        "name": "fsn1",
        "network_zone": "eu-central"
      },
      "name": "fsn1-dc8",
      "server_types": {
        "available": [
          1,
          2,
          3
        ],
        "available_for_migration": [
          1,
          2,
          3
        ],
        "supported": [
          1,
          2,
          3
        ]
      }
    },
    "id": 42,
    "image": {
      "bound_to": null,
      "created": "2016-01-30T23:50:00+00:00",
      "created_from": {
        "id": 1,
        "name": "Server"
      },
      "deleted": null,
      "deprecated": "2018-02-28T00:00:00+00:00",
      "description": "Ubuntu 20.04 Standard 64 bit",
      "disk_size": 10,
      "id": 4711,
      "image_size": 2.3,
      "labels": {
        "env": "dev"
      },
      "name": "ubuntu-20.04",
      "os_flavor": "ubuntu",
      "os_version": "20.04",
      "protection": {
        "delete": false
      },
      "rapid_deploy": false,
      "status": "available",
      "type": "snapshot"
    },
    "included_traffic": 654321,
    "ingoing_traffic": 123456,
    "iso": {
      "deprecated": "2018-02-28T00:00:00+00:00",
      "description": "FreeBSD 11.0 x64",
      "id": 4711,
      "name": "FreeBSD-11.0-RELEASE-amd64-dvd1",
      "type": "public"
    },
    "labels": {
      "env": "dev"
    },
    "load_balancers": [],
    "locked": false,
    "name": "my-server",
    "outgoing_traffic": 123456,
    "primary_disk_size": 50,
    "private_net": [
      {
        "alias_ips": [],
        "ip": "10.0.0.2",
        "mac_address": "86:00:ff:2a:7d:e1",
        "network": 4711
      }
    ],
    "protection": {
      "delete": false,
      "rebuild": false
    },
    "public_net": {
      "firewalls": [
        {
          "id": 38,
          "status": "applied"
        }
      ],
      "floating_ips": [
        478
      ],
      "ipv4": {
        "blocked": false,
        "dns_ptr": "server01.example.com",
        "ip": "1.2.3.4"
      },
      "ipv6": {
        "blocked": false,
        "dns_ptr": [
          {
            "dns_ptr": "server.example.com",
            "ip": "2001:db8::1"
          }
        ],
        "ip": "2001:db8::/64"
      }
    },
    "rescue_enabled": false,
    "server_type": {
      "cores": 1,
      "cpu_type": "shared",
      "deprecated": true,
      "description": "CX11",
      "disk": 25,
      "id": 1,
      "memory": 1,
      "name": "cx11",
      "prices": [
        {
          "location": "fsn1",
          "price_hourly": {
            "gross": "1.1900000000000000",
            "net": "1.0000000000"
          },
          "price_monthly": {
            "gross": "1.1900000000000000",
            "net": "1.0000000000"
          }
        }
      ],
      "storage_type": "local"
    },
    "status": "initializing",
    "volumes": []
  }
}
```


# Delete a Server

Deletes a Server. This immediately removes the Server from your account, and it is no longer accessible.

```go
DeleteAServer(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ServersResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Server |

## Response Type

**200**: The `action` key in the reply contains an Action object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ServersResponse1](../../doc/models/servers-response-1.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := serversApi.DeleteAServer(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get a Server

Returns a specific Server object. The Server must exist inside the Project

```go
GetAServer(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ServersResponse2],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Server |

## Response Type

**200**: The `server` key in the reply contains a Server object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ServersResponse2](../../doc/models/servers-response-2.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := serversApi.GetAServer(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Update a Server

Updates a Server. You can update a Server’s name and a Server’s labels.
Please note that Server names must be unique per Project and valid hostnames as per RFC 1123 (i.e. may only contain letters, digits, periods, and dashes).
Also note that when updating labels, the Server’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```go
UpdateAServer(
    ctx context.Context,
    id int,
    body *models.UpdateServerRequest) (
    models.ApiResponse[models.ServersResponse2],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Server |
| `body` | [`*models.UpdateServerRequest`](../../doc/models/update-server-request.md) | Body, Optional | - |

## Response Type

**200**: The `server` key in the reply contains the updated Server

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ServersResponse2](../../doc/models/servers-response-2.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.UpdateServerRequest{
    Labels:                models.ToPointer(interface{}("[labelkey, value]")),
    Name:                  models.ToPointer("my-server"),
}

apiResponse, err := serversApi.UpdateAServer(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get Metrics for a Server

Get Metrics for specified Server.

You must specify the type of metric to get: cpu, disk or network. You can also specify more than one type by comma separation, e.g. cpu,disk.

Depending on the type you will get different time series data

| Type    | Timeseries              | Unit      | Description                                          |
|---------|-------------------------|-----------|------------------------------------------------------|
| cpu     | cpu                     | percent   | Percent CPU usage                                    |
| disk    | disk.0.iops.read        | iop/s     | Number of read IO operations per second              |
|         | disk.0.iops.write       | iop/s     | Number of write IO operations per second             |
|         | disk.0.bandwidth.read   | bytes/s   | Bytes read per second                                |
|         | disk.0.bandwidth.write  | bytes/s   | Bytes written per second                             |
| network | network.0.pps.in        | packets/s | Public Network interface packets per second received |
|         | network.0.pps.out       | packets/s | Public Network interface packets per second sent     |
|         | network.0.bandwidth.in  | bytes/s   | Public Network interface bytes/s received            |
|         | network.0.bandwidth.out | bytes/s   | Public Network interface bytes/s sent                |

Metrics are available for the last 30 days only.

If you do not provide the step argument we will automatically adjust it so that a maximum of 200 samples are returned.

We limit the number of samples returned to a maximum of 500 and will adjust the step parameter accordingly.

```go
GetMetricsForAServer(
    ctx context.Context,
    id int,
    mType models.Type66,
    start string,
    end string,
    step *string) (
    models.ApiResponse[models.ServersMetricsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Server |
| `mType` | [`models.Type66`](../../doc/models/type-66.md) | Query, Required | Type of metrics to get |
| `start` | `string` | Query, Required | Start of period to get Metrics for (in ISO-8601 format) |
| `end` | `string` | Query, Required | End of period to get Metrics for (in ISO-8601 format) |
| `step` | `*string` | Query, Optional | Resolution of results in seconds |

## Response Type

**200**: The `metrics` key in the reply contains a metrics object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ServersMetricsResponse](../../doc/models/servers-metrics-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

mType := models.Type66_Network

start := "start4"

end := "end8"

apiResponse, err := serversApi.GetMetricsForAServer(ctx, id, mType, start, end, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

