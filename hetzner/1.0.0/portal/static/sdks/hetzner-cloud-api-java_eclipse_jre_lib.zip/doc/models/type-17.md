
# Type 17

Floating IP type

## Enumeration

`Type17`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```java
import cloud.hetzner.api.models.Type17;

Type17 type17 = Type17.IPV4;
```

