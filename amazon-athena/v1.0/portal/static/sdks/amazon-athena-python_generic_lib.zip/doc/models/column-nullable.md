
# Column Nullable

## Enumeration

`ColumnNullable`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```python
from amazonathena.models.column_nullable import ColumnNullable

column_nullable = ColumnNullable.UNKNOWN
```

