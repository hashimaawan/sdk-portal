
# Result Set 2

## Structure

`ResultSet2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `rows` | [`?(Row[])`](../../doc/models/row.md) | Optional | - | getRows(): ?array | setRows(?array rows): void |
| `resultSetMetadata` | [`?ResultSetMetadata2`](../../doc/models/result-set-metadata-2.md) | Optional | - | getResultSetMetadata(): ?ResultSetMetadata2 | setResultSetMetadata(?ResultSetMetadata2 resultSetMetadata): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultSet2Builder;
use AmazonAthenaLib\Models\Builders\RowBuilder;
use AmazonAthenaLib\Models\Builders\DatumBuilder;
use AmazonAthenaLib\Models\Builders\ResultSetMetadata2Builder;
use AmazonAthenaLib\Models\Builders\ColumnInfoBuilder;

$resultSet2 = ResultSet2Builder::init()
    ->rows(
        [
            RowBuilder::init()
                ->data(
                    [
                        DatumBuilder::init()
                            ->varCharValue('VarCharValue8')
                            ->build(),
                        DatumBuilder::init()
                            ->varCharValue('VarCharValue8')
                            ->build()
                    ]
                )
                ->build()
        ]
    )
    ->resultSetMetadata(
        ResultSetMetadata2Builder::init()
            ->columnInfo(
                [
                    ColumnInfoBuilder::init(
                        'Name6',
                        'Type6'
                    )
                        ->catalogName('CatalogName0')
                        ->schemaName('SchemaName0')
                        ->tableName('TableName2')
                        ->label('Label4')
                        ->precision(48)
                        ->build()
                ]
            )
            ->build()
    )
    ->build();
```

