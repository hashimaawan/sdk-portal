
# Result Reuse Information 2

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReusedPreviousResult` | `boolean` | Required | - | boolean getReusedPreviousResult() | setReusedPreviousResult(boolean reusedPreviousResult) |

## Example

```java
import com.amazonaws.useast1.athena.models.ResultReuseInformation2;

ResultReuseInformation2 resultReuseInformation2 = new ResultReuseInformation2.Builder(
    false
)
.build();
```

