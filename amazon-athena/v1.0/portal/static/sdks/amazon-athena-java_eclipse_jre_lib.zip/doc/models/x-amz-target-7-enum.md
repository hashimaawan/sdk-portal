
# X Amz Target 7 Enum

## Enumeration

`XAmzTarget7Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget7Enum;

XAmzTarget7Enum xAmzTarget7 = XAmzTarget7Enum.ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL;
```

