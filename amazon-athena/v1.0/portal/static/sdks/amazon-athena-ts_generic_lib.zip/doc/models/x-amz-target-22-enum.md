
# X Amz Target 22 Enum

## Enumeration

`XAmzTarget22Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetPreparedStatement` |

## Example

```ts
import { XAmzTarget22Enum } from 'amazon-athenalib';

const xAmzTarget22 = XAmzTarget22Enum.EnumAmazonAthenaGetPreparedStatement;
```

