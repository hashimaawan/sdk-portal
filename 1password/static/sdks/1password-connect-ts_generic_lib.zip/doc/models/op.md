
# Op

## Enumeration

`Op`

## Fields

| Name |
|  --- |
| `Add` |
| `Remove` |
| `Replace` |

## Example

```ts
import { Op } from 'm-1-password-connectlib';

const op = Op.Remove;
```

