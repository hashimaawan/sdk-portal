
# Import Notebook Input

## Structure

`ImportNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `payload` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `10485760` |
| `type` | [`NotebookType2Enum`](../../doc/models/notebook-type-2-enum.md) | Required | - |
| `clientRequestToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```ts
import { ImportNotebookInput, NotebookType2Enum } from 'amazon-athenalib';

const importNotebookInput: ImportNotebookInput = {
  workGroup: 'WorkGroup2',
  name: 'Name0',
  payload: 'Payload6',
  type: NotebookType2Enum.IPYNB,
  clientRequestToken: 'ClientRequestToken4',
};
```

