
# X Amz Target 28

## Enumeration

`XAmzTarget28`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagettablemetadata` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget28 := models.XAmzTarget28_EnumAmazonathenagettablemetadata

}
```

