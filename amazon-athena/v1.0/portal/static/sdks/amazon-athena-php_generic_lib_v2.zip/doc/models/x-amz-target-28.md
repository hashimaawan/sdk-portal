
# X Amz Target 28

## Enumeration

`XAmzTarget28`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETTABLEMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget28;

$xAmzTarget28 = XAmzTarget28::ENUM_AMAZONATHENAGETTABLEMETADATA;
```

