
# X Amz Target 54

## Enumeration

`XAmzTarget54`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateDataCatalog` |

## Example

```ts
import { XAmzTarget54 } from 'amazon-athenalib';

const xAmzTarget54 = XAmzTarget54.EnumAmazonAthenaUpdateDataCatalog;
```

