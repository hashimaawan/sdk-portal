
# Update Placement Group Request

## Structure

`UpdatePlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New PlacementGroup name |

## Example

```ruby
update_placement_group_request = UpdatePlacementGroupRequest.new(
  { 'labelkey' => 'value' },
  'my Placement Group'
)
```

