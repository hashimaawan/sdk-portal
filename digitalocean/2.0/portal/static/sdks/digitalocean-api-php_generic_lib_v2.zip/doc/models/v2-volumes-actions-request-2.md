
# V2 Volumes Actions Request 2

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2VolumesActionsRequest2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `region` | [`?string(Region2)`](../../doc/models/region-2.md) | Optional | The slug identifier for the region where the resource will initially be  available. | getRegion(): ?string | setRegion(?string region): void |
| `type` | [`string(Type21)`](../../doc/models/type-21.md) | Required | The volume action to initiate. | getType(): string | setType(string type): void |
| `sizeGigabytes` | `int` | Required | The new size of the block storage volume in GiB (1024^3).<br><br>**Constraints**: `<= 16384` | getSizeGigabytes(): int | setSizeGigabytes(int sizeGigabytes): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2VolumesActionsRequest2Builder;
use DigitalOceanApiLib\Models\Type21;
use DigitalOceanApiLib\Models\Region2;
use DigitalOceanApiLib\ApiHelper;

$v2VolumesActionsRequest2 = V2VolumesActionsRequest2Builder::init(
    Type21::ATTACH,
    15384
)
    ->region(Region2::NYC3)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

