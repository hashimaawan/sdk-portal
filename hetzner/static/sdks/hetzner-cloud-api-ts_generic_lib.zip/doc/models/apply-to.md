
# Apply To

## Structure

`ApplyTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labelSelector` | [`LabelSelector1 \| undefined`](../../doc/models/label-selector-1.md) | Optional | Configuration for type LabelSelector, required if type is `label_selector` |
| `server` | [`Server2 \| undefined`](../../doc/models/server-2.md) | Optional | Configuration for type Server, required if type is `server` |
| `type` | [`Type7Enum`](../../doc/models/type-7-enum.md) | Required | Type of the resource |

## Example

```ts
import { ApplyTo, Type7Enum } from 'hetzner-cloud-apilib';

const applyTo: ApplyTo = {
  type: Type7Enum.Server,
  labelSelector: {
    selector: 'selector8',
  },
  server: {
    id: 14,
  },
};
```

