
# Traffic

The cost of additional traffic per TB

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price_per_tb` | [`PricePerTb`](../../doc/models/price-per-tb.md) | Required | - |

## Example

```python
from hetznercloudapi.models.price_per_tb import PricePerTb
from hetznercloudapi.models.traffic import Traffic

traffic = Traffic(
    price_per_tb=PricePerTb(
        gross='1.1900000000000000',
        net='1.0000000000'
    )
)
```

