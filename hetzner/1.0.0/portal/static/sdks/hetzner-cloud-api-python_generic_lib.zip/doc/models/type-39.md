
# Type 39

Algorithm of the Load Balancer

## Enumeration

`Type39`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```python
from hetznercloudapi.models.type_39 import Type39

type_39 = Type39.ROUND_ROBIN
```

