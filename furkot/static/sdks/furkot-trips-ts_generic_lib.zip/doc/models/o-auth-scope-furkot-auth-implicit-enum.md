
# O Auth Scope Furkot Auth Implicit Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthImplicitEnum`

## Fields

| Name | Description |
|  --- | --- |
| `Readtrips` | list users trips info |

## Example

```ts
import { OAuthScopeFurkotAuthImplicitEnum } from 'furkot-tripslib';

const oAuthScopeFurkotAuthImplicit = OAuthScopeFurkotAuthImplicitEnum.Readtrips;
```

