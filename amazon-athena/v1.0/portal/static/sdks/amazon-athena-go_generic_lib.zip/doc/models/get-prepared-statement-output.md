
# Get Prepared Statement Output

## Structure

`GetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PreparedStatement` | [`*models.PreparedStatement1`](../../doc/models/prepared-statement-1.md) | Optional | - |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonathena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    getPreparedStatementOutput := models.GetPreparedStatementOutput{
        PreparedStatement:    models.ToPointer(models.PreparedStatement1{
            StatementName:        models.ToPointer("StatementName4"),
            QueryStatement:       models.ToPointer("QueryStatement8"),
            WorkGroupName:        models.ToPointer("WorkGroupName8"),
            Description:          models.ToPointer("Description0"),
            LastModifiedTime:     models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        }),
    }

}
```

