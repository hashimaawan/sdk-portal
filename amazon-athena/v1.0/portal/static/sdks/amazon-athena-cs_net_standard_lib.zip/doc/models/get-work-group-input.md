
# Get Work Group Input

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetWorkGroupInput getWorkGroupInput = new GetWorkGroupInput
{
    WorkGroup = "WorkGroup8",
};
```

