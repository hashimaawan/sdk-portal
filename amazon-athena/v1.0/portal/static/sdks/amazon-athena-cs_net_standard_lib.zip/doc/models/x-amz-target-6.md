
# X Amz Target 6

## Enumeration

`XAmzTarget6`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreatePreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget6 xAmzTarget6 = XAmzTarget6.EnumAmazonAthenaCreatePreparedStatement;
```

