
# Status 30 Enum

## Enumeration

`Status30Enum`

## Fields

| Name |
|  --- |
| `Healthy` |
| `Unhealthy` |
| `Unknown` |

## Example

```ts
import { Status30Enum } from 'hetzner-cloud-apilib';

const status30 = Status30Enum.Healthy;
```

