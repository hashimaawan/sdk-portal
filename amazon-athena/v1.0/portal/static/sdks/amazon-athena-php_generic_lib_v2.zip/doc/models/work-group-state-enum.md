
# Work Group State Enum

## Enumeration

`WorkGroupStateEnum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```php
use AmazonAthenaLib\Models\WorkGroupStateEnum;

$workGroupState = WorkGroupStateEnum::ENABLED;
```

