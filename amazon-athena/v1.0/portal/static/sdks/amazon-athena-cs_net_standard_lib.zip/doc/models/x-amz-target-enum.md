
# X Amz Target Enum

## Enumeration

`XAmzTargetEnum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetNamedQuery` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTargetEnum xAmzTarget = XAmzTargetEnum.EnumAmazonAthenaBatchGetNamedQuery;
```

