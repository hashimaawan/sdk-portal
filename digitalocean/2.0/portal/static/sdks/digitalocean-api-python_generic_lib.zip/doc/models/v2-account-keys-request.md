
# V2 Account Keys Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2AccountKeysRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | A human-readable display name for this key, used to easily identify the SSH keys when they are displayed. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_account_keys_request import V2AccountKeysRequest

v_2_account_keys_request = V2AccountKeysRequest(
    name='My SSH Public Key',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

