
# Action

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `READ` |
| `CREATE` |
| `UPDATE` |
| `DELETE` |

## Example

```python
from m1passwordconnect.models.action import Action

action = Action.UPDATE
```

