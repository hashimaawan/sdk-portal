
# Actions Response

## Structure

`ActionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `actions` | [`List[Action]`](../../doc/models/action.md) | Required | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |

## Example

```python
from hetznercloudapi.models.action import Action
from hetznercloudapi.models.actions_response import ActionsResponse
from hetznercloudapi.models.error import Error
from hetznercloudapi.models.meta import Meta
from hetznercloudapi.models.pagination import Pagination
from hetznercloudapi.models.resource import Resource
from hetznercloudapi.models.status_enum import StatusEnum

actions_response = ActionsResponse(
    actions=[
        Action(
            command='start_server',
            error=Error(
                code='action_failed',
                message='Action failed'
            ),
            finished='2016-01-30T23:55:00+00:00',
            id=42,
            progress=100,
            resources=[
                Resource(
                    id=42,
                    mtype='server'
                )
            ],
            started='2016-01-30T23:55:00+00:00',
            status=StatusEnum.SUCCESS
        )
    ],
    meta=Meta(
        pagination=Pagination(
            last_page=77.7,
            next_page=209.18,
            page=17.58,
            per_page=13.34,
            previous_page=50.02,
            total_entries=206.64
        )
    )
)
```

