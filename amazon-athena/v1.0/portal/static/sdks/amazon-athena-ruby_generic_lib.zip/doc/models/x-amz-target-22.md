
# X Amz Target 22

## Enumeration

`XAmzTarget22`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target22 = XAmzTarget22::ENUM_AMAZONATHENAGETPREPAREDSTATEMENT
```

