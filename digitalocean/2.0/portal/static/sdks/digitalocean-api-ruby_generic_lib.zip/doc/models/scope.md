
# Scope

- RUN_TIME: Made available only at run-time
- BUILD_TIME: Made available only at build-time
- RUN_AND_BUILD_TIME: Made available at both build and run-time

## Enumeration

`Scope`

## Fields

| Name |
|  --- |
| `UNSET` |
| `RUN_TIME` |
| `BUILD_TIME` |
| `RUN_AND_BUILD_TIME` |

## Example

```ruby
scope = Scope::BUILD_TIME
```

