
# Server Backup

Will increase base Server costs by specific percentage

## Structure

`ServerBackup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Percentage` | `string` | Required | Percentage by how much the base price will increase |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ServerBackup serverBackup = new ServerBackup
{
    Percentage = "20.0000000000",
};
```

