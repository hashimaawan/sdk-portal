
# X Amz Target 15

## Enumeration

`XAmzTarget15`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget15;

XAmzTarget15 xAmzTarget15 = XAmzTarget15.ENUM_AMAZONATHENAGETCALCULATIONEXECUTION;
```

