
# Type 2

The object type: "track".

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `Track` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

Type2 type2 = Type2.Track;
```

