
# V2 Apps Regions Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2AppsRegionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `regions` | [`?(GeographicalInformationAboutAnAppOrigin[])`](../../doc/models/geographical-information-about-an-app-origin.md) | Optional | - | getRegions(): ?array | setRegions(?array regions): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2AppsRegionsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\GeographicalInformationAboutAnAppOriginBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2AppsRegionsResponse = V2AppsRegionsResponseBuilder::init()
    ->regions(
        [
            GeographicalInformationAboutAnAppOriginBuilder::init()
                ->continent('continent2')
                ->dataCenters(
                    [
                        'data_centers9'
                    ]
                )
                ->default(false)
                ->disabled(false)
                ->flag('flag4')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

