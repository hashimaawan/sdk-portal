
# Statistics 1

## Structure

`Statistics1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `int` | Optional | - |
| `progress` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```python
from amazonathena.models.statistics_1 import Statistics1

statistics_1 = Statistics1(
    dpu_execution_in_millis=138,
    progress='Progress4'
)
```

