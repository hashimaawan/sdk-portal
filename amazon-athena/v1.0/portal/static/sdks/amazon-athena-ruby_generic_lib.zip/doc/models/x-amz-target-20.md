
# X Amz Target 20

## Enumeration

`XAmzTarget20`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNAMEDQUERY` |

## Example

```ruby
x_amz_target20 = XAmzTarget20::ENUM_AMAZONATHENAGETNAMEDQUERY
```

