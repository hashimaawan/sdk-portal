
# Label Selector 1

Configuration for type LabelSelector, required if type is `label_selector`

## Structure

`LabelSelector1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `String` | Required | Label selector |

## Example

```ruby
label_selector1 = LabelSelector1.new(
  'selector2'
)
```

