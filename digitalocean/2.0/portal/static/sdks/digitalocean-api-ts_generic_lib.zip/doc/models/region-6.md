
# Region 6

Slug of the region where registry data is stored. When not provided, a region will be selected.

## Enumeration

`Region6`

## Fields

| Name |
|  --- |
| `Nyc3` |
| `Sfo3` |
| `Ams3` |
| `Sgp1` |
| `Fra1` |

## Example

```ts
import { Region6 } from 'digitalocean-apilib';

const region6 = Region6.Nyc3;
```

