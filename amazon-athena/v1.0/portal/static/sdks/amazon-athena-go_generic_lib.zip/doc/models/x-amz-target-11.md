
# X Amz Target 11

## Enumeration

`XAmzTarget11`

## Fields

| Name |
|  --- |
| `EnumAmazonathenadeletenotebook` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget11 := models.XAmzTarget11_EnumAmazonathenadeletenotebook

}
```

