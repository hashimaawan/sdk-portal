
# Server Type

*This model accepts additional fields of type unknown.*

## Structure

`ServerType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cores` | `number` | Required | Number of cpu cores a Server of this type will have |
| `cpuType` | [`CpuType`](../../doc/models/cpu-type.md) | Required | Type of cpu |
| `deprecated` | `boolean` | Required | True if Server type is deprecated |
| `description` | `string` | Required | Description of the Server type |
| `disk` | `number` | Required | Disk size a Server of this type will have in GB |
| `id` | `number` | Required | ID of the Server type |
| `memory` | `number` | Required | Memory a Server of this type will have in GB |
| `name` | `string` | Required | Unique identifier of the Server type |
| `prices` | [`Price9[]`](../../doc/models/price-9.md) | Required | Prices in different Locations |
| `storageType` | [`StorageType`](../../doc/models/storage-type.md) | Required | Type of Server boot drive. Local has higher speed. Network has better availability. |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { CpuType, ServerType, StorageType } from 'hetzner-cloud-apilib';

const serverType: ServerType = {
  cores: 1,
  cpuType: CpuType.Shared,
  deprecated: false,
  description: 'CX11',
  disk: 24,
  id: 1,
  memory: 1,
  name: 'cx11',
  prices: [
    {
      location: 'fsn1',
      priceHourly: {
        gross: '1.1900000000000000',
        net: '1.0000000000',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      priceMonthly: {
        gross: '1.1900000000000000',
        net: '1.0000000000',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  storageType: StorageType.Local,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

