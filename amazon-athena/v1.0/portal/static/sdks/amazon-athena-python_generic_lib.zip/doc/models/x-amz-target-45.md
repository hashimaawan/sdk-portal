
# X Amz Target 45

## Enumeration

`XAmzTarget45`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTWORKGROUPS` |

## Example

```python
from amazonathena.models.x_amz_target_45 import XAmzTarget45

x_amz_target_45 = XAmzTarget45.ENUM_AMAZONATHENALISTWORKGROUPS
```

