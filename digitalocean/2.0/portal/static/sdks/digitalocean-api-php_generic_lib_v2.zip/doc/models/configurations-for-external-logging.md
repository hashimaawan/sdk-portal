
# Configurations for External Logging

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`ConfigurationsForExternalLogging`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `datadog` | [`?Datadog`](../../doc/models/datadog.md) | Optional | DataDog configuration. | getDatadog(): ?Datadog | setDatadog(?Datadog datadog): void |
| `logtail` | [`?Logtail`](../../doc/models/logtail.md) | Optional | Logtail configuration. | getLogtail(): ?Logtail | setLogtail(?Logtail logtail): void |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `2`, *Maximum Length*: `42`, *Pattern*: `^[A-Za-z0-9()\[\]'"][-A-Za-z0-9_. \/()\[\]]{0,40}[A-Za-z0-9()\[\]'"]$` | getName(): string | setName(string name): void |
| `papertrail` | [`?Papertrail`](../../doc/models/papertrail.md) | Optional | Papertrail configuration. | getPapertrail(): ?Papertrail | setPapertrail(?Papertrail papertrail): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\ConfigurationsForExternalLoggingBuilder;
use DigitalOceanApiLib\Models\Builders\DatadogBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\LogtailBuilder;
use DigitalOceanApiLib\Models\Builders\PapertrailBuilder;

$configurationsForExternalLogging = ConfigurationsForExternalLoggingBuilder::init(
    'my_log_destination'
)
    ->datadog(
        DatadogBuilder::init(
            'api_key2'
        )
            ->endpoint('endpoint8')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->logtail(
        LogtailBuilder::init()
            ->token('token4')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->papertrail(
        PapertrailBuilder::init(
            'endpoint4'
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

