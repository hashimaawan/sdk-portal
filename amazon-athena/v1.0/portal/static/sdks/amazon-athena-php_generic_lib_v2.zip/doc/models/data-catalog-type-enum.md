
# Data Catalog Type Enum

## Enumeration

`DataCatalogTypeEnum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```php
use AmazonAthenaLib\Models\DataCatalogTypeEnum;

$dataCatalogType = DataCatalogTypeEnum::HIVE;
```

