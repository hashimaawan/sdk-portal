
# X Amz Target 18

## Enumeration

`XAmzTarget18`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetDataCatalog` |

## Example

```ts
import { XAmzTarget18 } from 'amazon-athenalib';

const xAmzTarget18 = XAmzTarget18.EnumAmazonAthenaGetDataCatalog;
```

