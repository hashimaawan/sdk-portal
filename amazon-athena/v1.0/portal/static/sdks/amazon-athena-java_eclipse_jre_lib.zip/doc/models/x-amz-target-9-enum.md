
# X Amz Target 9 Enum

## Enumeration

`XAmzTarget9Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEDATACATALOG` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget9Enum;

XAmzTarget9Enum xAmzTarget9 = XAmzTarget9Enum.ENUM_AMAZONATHENADELETEDATACATALOG;
```

