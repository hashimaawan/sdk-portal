
# Work Group State 3

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```php
use AmazonAthenaLib\Models\WorkGroupState3;

$workGroupState3 = WorkGroupState3::ENABLED;
```

