
# Delete Named Query Input

## Structure

`DeleteNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { DeleteNamedQueryInput } from 'amazon-athenalib';

const deleteNamedQueryInput: DeleteNamedQueryInput = {
  namedQueryId: 'NamedQueryId4',
};
```

