
# V21 Clicks 401 Error Exception

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V21Clicks401ErrorException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | A short identifier corresponding to the HTTP status code returned. For  example, the ID for a response returning a 404 status code would be "not_found." | getId(): string | setId(string id): void |
| `message` | `string` | Required | A message providing additional information about the error, including  details to help resolve it when possible. | getMessage(): string | setMessage(string message): void |
| `requestId` | `?string` | Optional | Optionally, some endpoints may include a request ID that should be  provided when reporting bugs or opening support tickets to help  identify the issue. | getRequestId(): ?string | setRequestId(?string requestId): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

