
# X Amz Target 35

## Enumeration

`XAmzTarget35`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTENGINEVERSIONS` |

## Example

```python
from amazonathena.models.x_amz_target_35 import XAmzTarget35

x_amz_target_35 = XAmzTarget35.ENUM_AMAZONATHENALISTENGINEVERSIONS
```

