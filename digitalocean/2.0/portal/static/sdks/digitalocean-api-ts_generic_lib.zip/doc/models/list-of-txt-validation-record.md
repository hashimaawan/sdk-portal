
# List of Txt Validation Record

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`ListOfTxtValidationRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `txtName` | `string \| undefined` | Optional, Read-only | - |
| `txtValue` | `string \| undefined` | Optional, Read-only | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { ListOfTxtValidationRecord } from 'digitalocean-apilib';

const listOfTxtValidationRecord: ListOfTxtValidationRecord = {
  txtName: '_acme-challenge.app.example.com',
  txtValue: 'lXLOcN6cPv0nproViNcUHcahD9TrIPlNgdwesj0pYpk',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

