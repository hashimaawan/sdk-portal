
# X Amz Target 35

## Enumeration

`XAmzTarget35`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTENGINEVERSIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget35;

$xAmzTarget35 = XAmzTarget35::ENUM_AMAZONATHENALISTENGINEVERSIONS;
```

