# Snapshots

[Snapshots](https://www.digitalocean.com/docs/images/snapshots/) are saved
instances of a Droplet or a block storage volume, which is reflected in
the `resource_type` attribute. In order to avoid problems with compressing
filesystems, each defines a `min_disk_size` attribute which is the minimum
size of the Droplet or volume disk when creating a new resource from the
saved snapshot.

To interact with snapshots, you will generally send requests to the
snapshots endpoint at `/v2/snapshots`.

```php
$snapshotsApi = $client->getSnapshotsApi();
```

## Class Name

`SnapshotsApi`

## Methods

* [Snapshots List](../../doc/controllers/snapshots.md#snapshots-list)
* [Snapshots Delete](../../doc/controllers/snapshots.md#snapshots-delete)
* [Snapshots Get](../../doc/controllers/snapshots.md#snapshots-get)


# Snapshots List

To list all of the snapshots available on your account, send a GET request to
`/v2/snapshots`.

The response will be a JSON object with a key called `snapshots`. This will be
set to an array of `snapshot` objects, each of which will contain the standard
snapshot attributes.

### Filtering Results by Resource Type

It's possible to request filtered results by including certain query parameters.

#### List Droplet Snapshots

To retrieve only snapshots based on Droplets, include the `resource_type`
query parameter set to `droplet`. For example, `/v2/snapshots?resource_type=droplet`.

#### List Volume Snapshots

To retrieve only snapshots based on volumes, include the `resource_type`
query parameter set to `volume`. For example, `/v2/snapshots?resource_type=volume`.

```php
function snapshotsList(?int $perPage = 20, ?int $page = 1, ?string $resourceType = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `resourceType` | [`?string(ResourceType)`](../../doc/models/resource-type.md) | Query, Optional | Used to filter snapshots by a resource type. |

## Response Type

**200**: A JSON object with a key of `snapshots`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2SnapshotsResponse`](../../doc/models/v2-snapshots-response.md).

## Example Usage

```php
$perPage = 2;

$page = 1;

$resourceType = ResourceType::DROPLET;

$snapshotsApi = $client->getSnapshotsApi();
$apiResponse = $snapshotsApi->snapshotsList(
    $perPage,
    $page,
    $resourceType
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2SnapshotsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "links": {},
  "meta": {
    "total": 2
  },
  "snapshots": [
    {
      "created_at": "2020-07-28T16:47:44Z",
      "id": "6372321",
      "min_disk_size": 25,
      "name": "web-01-1595954862243",
      "regions": [
        "nyc3",
        "sfo3"
      ],
      "resource_id": "200776916",
      "resource_type": "droplet",
      "size_gigabytes": 2.34,
      "tags": [
        "web",
        "env:prod"
      ]
    },
    {
      "created_at": "2019-09-28T23:14:30Z",
      "id": "fbe805e8-866b-11e6-96bf-000f53315a41",
      "min_disk_size": 2,
      "name": "pvc-01-1595954862243",
      "regions": [
        "nyc1"
      ],
      "resource_id": "89bcc42f-85cf-11e6-a004-000f53315871",
      "resource_type": "volume",
      "size_gigabytes": 0.1008,
      "tags": [
        "k8s"
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Snapshots Delete

Both Droplet and volume snapshots are managed through the `/v2/snapshots/`
endpoint. To delete a snapshot, send a DELETE request to
`/v2/snapshots/$SNAPSHOT_ID`.

A status of 204 will be given. This indicates that the request was processed
successfully, but that no response body is needed.

```php
function snapshotsDelete($snapshotId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `snapshotId` | int\|string | Template, Required | This is a container for any-of cases. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$snapshotId = 6372321;

$snapshotsApi = $client->getSnapshotsApi();
$apiResponse = $snapshotsApi->snapshotsDelete($snapshotId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Snapshots Get

To retrieve information about a snapshot, send a GET request to
`/v2/snapshots/$SNAPSHOT_ID`.

The response will be a JSON object with a key called `snapshot`. The value of
this will be an snapshot object containing the standard snapshot attributes.

```php
function snapshotsGet($snapshotId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `snapshotId` | int\|string | Template, Required | This is a container for any-of cases. |

## Response Type

**200**: A JSON object with a key called `snapshot`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2SnapshotsResponse1`](../../doc/models/v2-snapshots-response-1.md).

## Example Usage

```php
$snapshotId = 6372321;

$snapshotsApi = $client->getSnapshotsApi();
$apiResponse = $snapshotsApi->snapshotsGet($snapshotId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2SnapshotsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

