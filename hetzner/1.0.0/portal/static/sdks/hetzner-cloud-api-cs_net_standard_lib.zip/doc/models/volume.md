
# Volume

The cost of Volume per GB/month

## Structure

`Volume`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PricePerGbMonth` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Volume volume = new Volume
{
    PricePerGbMonth = new PricePerGbMonth
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
    },
};
```

