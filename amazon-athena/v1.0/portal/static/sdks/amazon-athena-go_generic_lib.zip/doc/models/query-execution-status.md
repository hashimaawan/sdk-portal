
# Query Execution Status

The completion date, current state, submission time, and state change reason (if applicable) for the query execution.

*This model accepts additional fields of type interface{}.*

## Structure

`QueryExecutionStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `State` | [`*models.QueryExecutionState1`](../../doc/models/query-execution-state-1.md) | Optional | - |
| `StateChangeReason` | `*string` | Optional | - |
| `SubmissionDateTime` | `*time.Time` | Optional | - |
| `CompletionDateTime` | `*time.Time` | Optional | - |
| `AthenaError` | [`*models.AthenaError2`](../../doc/models/athena-error-2.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonAthena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    queryExecutionStatus := models.QueryExecutionStatus{
        State:                 models.ToPointer(models.QueryExecutionState1_Succeeded),
        StateChangeReason:     models.ToPointer("StateChangeReason0"),
        SubmissionDateTime:    models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        CompletionDateTime:    models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        AthenaError:           models.ToPointer(models.AthenaError2{
            ErrorCategory:         models.ToPointer(3),
            ErrorType:             models.ToPointer(128),
            Retryable:             models.ToPointer(false),
            ErrorMessage:          models.ToPointer("ErrorMessage8"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

