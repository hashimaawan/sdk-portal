
# Work Group Summary

The summary information for the workgroup, which includes its name, state, description, and the date and time it was created.

## Structure

`WorkGroupSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `state` | [`WorkGroupState1Enum`](../../doc/models/work-group-state-1-enum.md) | Optional | - |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `creation_time` | `DateTime` | Optional | - |
| `engine_version` | [`EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - |

## Example

```ruby
work_group_summary = WorkGroupSummary.new(
  'Name2',
  WorkGroupState1Enum::ENABLED,
  'Description4',
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  EngineVersion1.new(
    'SelectedEngineVersion4',
    'EffectiveEngineVersion6'
  )
)
```

