
# Action

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `Read` |
| `Create` |
| `Update` |
| `Delete` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    action := models.Action_Update

}
```

