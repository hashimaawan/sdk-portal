
# Label Selector

## Structure

`LabelSelector`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector | getSelector(): string | setSelector(string selector): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LabelSelectorBuilder;

$labelSelector = LabelSelectorBuilder::init(
    'env=prod'
)->build();
```

