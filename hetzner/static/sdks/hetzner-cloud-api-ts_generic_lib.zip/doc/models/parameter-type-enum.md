
# Parameter Type Enum

## Enumeration

`ParameterTypeEnum`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```ts
import { ParameterTypeEnum } from 'hetzner-cloud-apilib';

const parameterType = ParameterTypeEnum.Uploaded;
```

