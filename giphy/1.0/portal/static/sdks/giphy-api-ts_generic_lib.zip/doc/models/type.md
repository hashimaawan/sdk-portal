
# Type

Type of the gif. By default, this is almost always gif

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Gif` |

## Example

```ts
import { Type } from 'giphy-apilib';

const type = Type.Gif;
```

