
# Delete Named Query Input

## Structure

`DeleteNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    deleteNamedQueryInput := models.DeleteNamedQueryInput{
        NamedQueryId:         "NamedQueryId4",
    }

}
```

