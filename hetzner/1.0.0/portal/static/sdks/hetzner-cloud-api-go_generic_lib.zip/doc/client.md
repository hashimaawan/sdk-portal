
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |

The API client can be initialized as follows:

```go
package main

import (
    "hetznerCloudApi"
)

func main() {
    client := hetznerCloudApi.NewClient(
    hetznerCloudApi.CreateConfiguration(
            hetznerCloudApi.WithHttpConfiguration(
                hetznerCloudApi.CreateHttpConfiguration(
                    hetznerCloudApi.WithTimeout(30),
                ),
            ),
            hetznerCloudApi.WithLoggerConfiguration(
                hetznerCloudApi.WithLevel("info"),
                hetznerCloudApi.WithRequestConfiguration(
                    hetznerCloudApi.WithRequestBody(true),
                ),
                hetznerCloudApi.WithResponseConfiguration(
                    hetznerCloudApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Hetzner Cloud API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| ActionsApi() | Gets ActionsApi |
| CertificatesApi() | Gets CertificatesApi |
| CertificateActionsApi() | Gets CertificateActionsApi |
| DatacentersApi() | Gets DatacentersApi |
| FirewallsApi() | Gets FirewallsApi |
| FirewallActionsApi() | Gets FirewallActionsApi |
| FloatingIPsApi() | Gets FloatingIPsApi |
| FloatingIpActionsApi() | Gets FloatingIpActionsApi |
| ImagesApi() | Gets ImagesApi |
| ImageActionsApi() | Gets ImageActionsApi |
| IsOsApi() | Gets IsOsApi |
| LoadBalancersApi() | Gets LoadBalancersApi |
| LoadBalancerActionsApi() | Gets LoadBalancerActionsApi |
| LoadBalancerTypesApi() | Gets LoadBalancerTypesApi |
| LocationsApi() | Gets LocationsApi |
| PrimaryIPsApi() | Gets PrimaryIPsApi |
| PrimaryIpActionsApi() | Gets PrimaryIpActionsApi |
| NetworksApi() | Gets NetworksApi |
| NetworkActionsApi() | Gets NetworkActionsApi |
| PlacementGroupsApi() | Gets PlacementGroupsApi |
| PricingApi() | Gets PricingApi |
| ServersApi() | Gets ServersApi |
| ServerActionsApi() | Gets ServerActionsApi |
| ServerTypesApi() | Gets ServerTypesApi |
| SshKeysApi() | Gets SshKeysApi |
| VolumesApi() | Gets VolumesApi |
| VolumeActionsApi() | Gets VolumeActionsApi |

