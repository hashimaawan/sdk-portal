
# Notebook Type 1 Enum

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    notebookType1 := models.NotebookType1Enum_IPYNB

}
```

