
# Type 7

Type of the resource

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```php
use HetznerCloudApiLib\Models\Type7;

$type7 = Type7::SERVER;
```

