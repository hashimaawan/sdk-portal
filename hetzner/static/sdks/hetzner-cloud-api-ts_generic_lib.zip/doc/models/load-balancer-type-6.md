
# Load Balancer Type 6

## Structure

`LoadBalancerType6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Load Balancer type the price is for |
| `name` | `string` | Required | Name of the Load Balancer type the price is for |
| `prices` | [`Price7[]`](../../doc/models/price-7.md) | Required | Load Balancer type costs per Location |

## Example

```ts
import { LoadBalancerType6 } from 'hetzner-cloud-apilib';

const loadBalancerType6: LoadBalancerType6 = {
  id: 1,
  name: 'lb11',
  prices: [
    {
      location: 'fsn1',
      priceHourly: {
        gross: '1.1900000000000000',
        net: '1.0000000000',
      },
      priceMonthly: {
        gross: '1.1900000000000000',
        net: '1.0000000000',
      },
    }
  ],
};
```

