
# X Amz Target 43

## Enumeration

`XAmzTarget43`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTABLEMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget43;

$xAmzTarget43 = XAmzTarget43::ENUM_AMAZONATHENALISTTABLEMETADATA;
```

