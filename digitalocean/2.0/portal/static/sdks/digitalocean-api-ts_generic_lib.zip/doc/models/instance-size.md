
# Instance Size

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`InstanceSize`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cpuType` | [`MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores \| undefined`](../../doc/models/m-shared-shared-vcpu-cores-dedicated-dedicated-vcpu-cores.md) | Optional | **Default**: `MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores.Unspecified` |
| `cpus` | `string \| undefined` | Optional | - |
| `memoryBytes` | `string \| undefined` | Optional | - |
| `name` | `string \| undefined` | Optional | - |
| `slug` | `string \| undefined` | Optional | - |
| `tierDowngradeTo` | `string \| undefined` | Optional | - |
| `tierSlug` | `string \| undefined` | Optional | - |
| `tierUpgradeTo` | `string \| undefined` | Optional | - |
| `usdPerMonth` | `string \| undefined` | Optional | - |
| `usdPerSecond` | `string \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  InstanceSize,
  MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores,
} from 'digitalocean-apilib';

const instanceSize: InstanceSize = {
  cpuType: MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores.Shared,
  cpus: '3',
  memoryBytes: '1048',
  name: 'name',
  slug: 'basic',
  tierDowngradeTo: 'basic',
  tierSlug: 'basic',
  tierUpgradeTo: 'basic',
  usdPerMonth: '23',
  usdPerSecond: '0.00000001232',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

