
# X Amz Target 6 Enum

## Enumeration

`XAmzTarget6Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_6_enum import XAmzTarget6Enum

x_amz_target_6 = XAmzTarget6Enum.ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT
```

