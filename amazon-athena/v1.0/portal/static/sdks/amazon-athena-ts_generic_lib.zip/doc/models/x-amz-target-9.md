
# X Amz Target 9

## Enumeration

`XAmzTarget9`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteDataCatalog` |

## Example

```ts
import { XAmzTarget9 } from 'amazon-athenalib';

const xAmzTarget9 = XAmzTarget9.EnumAmazonAthenaDeleteDataCatalog;
```

