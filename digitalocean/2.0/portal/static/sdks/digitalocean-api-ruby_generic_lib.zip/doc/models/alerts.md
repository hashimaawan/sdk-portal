
# Alerts

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Alerts`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `Array[String]` | Required | An email to notify on an alert trigger. |
| `slack` | [`Array[Slack]`](../../doc/models/slack.md) | Required | Slack integration details. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
alerts = Alerts.new(
  email: [
    'bob@exmaple.com'
  ],
  slack: [
    Slack.new(
      channel: 'Production Alerts',
      url: 'https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

