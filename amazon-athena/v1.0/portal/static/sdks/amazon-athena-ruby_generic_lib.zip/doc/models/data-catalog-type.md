
# Data Catalog Type

## Enumeration

`DataCatalogType`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```ruby
data_catalog_type = DataCatalogType::LAMBDA
```

