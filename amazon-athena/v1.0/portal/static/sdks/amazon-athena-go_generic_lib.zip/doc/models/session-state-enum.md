
# Session State Enum

## Enumeration

`SessionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    sessionState := models.SessionStateEnum_TERMINATING

}
```

