
# Acl Configuration 1

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s_3_acl_option` | [`S3AclOption1Enum`](../../doc/models/s3-acl-option-1-enum.md) | Required | - |

## Example

```python
from amazonathena.models.acl_configuration_1 import AclConfiguration1
from amazonathena.models.s_3_acl_option_1_enum import S3AclOption1Enum

acl_configuration_1 = AclConfiguration1(
    s_3_acl_option=S3AclOption1Enum.BUCKET_OWNER_FULL_CONTROL
)
```

