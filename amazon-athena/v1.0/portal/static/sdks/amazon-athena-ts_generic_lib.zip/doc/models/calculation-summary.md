
# Calculation Summary

Summary information for a notebook calculation.

## Structure

`CalculationSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `status` | [`Status1 \| undefined`](../../doc/models/status-1.md) | Optional | - |

## Example

```ts
import {
  CalculationExecutionState1Enum,
  CalculationSummary,
} from 'amazon-athenalib';

const calculationSummary: CalculationSummary = {
  calculationExecutionId: 'CalculationExecutionId4',
  description: 'Description6',
  status: {
    submissionDateTime: '2016-03-13T12:52:32.123Z',
    completionDateTime: '2016-03-13T12:52:32.123Z',
    state: CalculationExecutionState1Enum.CANCELING,
    stateChangeReason: 'StateChangeReason8',
  },
};
```

