# Certificate Actions

```ruby
certificate_actions_api = client.certificate_actions
```

## Class Name

`CertificateActionsApi`

## Methods

* [Get All Actions for a Certificate](../../doc/controllers/certificate-actions.md#get-all-actions-for-a-certificate)
* [Retry Issuance or Renewal](../../doc/controllers/certificate-actions.md#retry-issuance-or-renewal)
* [Get an Action for a Certificate](../../doc/controllers/certificate-actions.md#get-an-action-for-a-certificate)


# Get All Actions for a Certificate

Returns all Action objects for a Certificate. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

Only type `managed` Certificates can have Actions. For type `uploaded` Certificates the `actions` key will always contain an empty array.

```ruby
def get_all_actions_for_a_certificate(id,
                                      sort: nil,
                                      status: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Resource |
| `sort` | [`ParameterSort`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatus`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`ActionsResponse`](../../doc/models/actions-response.md).

## Example Usage

```ruby
id = 112

result = certificate_actions_api.get_all_actions_for_a_certificate(id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "issue_certificate",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2021-01-30T23:57:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 896,
          "type": "certificate"
        }
      ],
      "started": "2021-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Retry Issuance or Renewal

Retry a failed Certificate issuance or renewal.

Only applicable if the type of the Certificate is `managed` and the issuance or renewal status is `failed`.

#### Call specific error codes

| Code                                                    | Description                                                               |
|---------------------------------------------------------|---------------------------------------------------------------------------|
| `caa_record_does_not_allow_ca`                          | CAA record does not allow certificate authority                           |
| `ca_dns_validation_failed`                              | Certificate Authority: DNS validation failed                              |
| `ca_too_many_authorizations_failed_recently`            | Certificate Authority: Too many authorizations failed recently            |
| `ca_too_many_certificates_issued_for_registered_domain` | Certificate Authority: Too many certificates issued for registered domain |
| `ca_too_many_duplicate_certificates`                    | Certificate Authority: Too many duplicate certificates                    |
| `could_not_verify_domain_delegated_to_zone`             | Could not verify domain delegated to zone                                 |
| `dns_zone_not_found`                                    | DNS zone not found                                                        |
| `dns_zone_is_secondary_zone`                            | DNS zone is a secondary zone                                              |

```ruby
def retry_issuance_or_renewal(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Certificate |

## Response Type

**201**: The `action` key contains the resulting Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ruby
id = 112

result = certificate_actions_api.retry_issuance_or_renewal(id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "issue_certificate",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2021-01-30T23:57:00+00:00",
    "id": 14,
    "progress": 100,
    "resources": [
      {
        "id": 896,
        "type": "certificate"
      }
    ],
    "started": "2021-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for a Certificate

Returns a specific Action for a Certificate. Only type `managed` Certificates have Actions.

```ruby
def get_an_action_for_a_certificate(id,
                                    action_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Certificate |
| `action_id` | `Integer` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Certificate Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ruby
id = 112

action_id = 224

result = certificate_actions_api.get_an_action_for_a_certificate(
  id,
  action_id
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "issue_certificate",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2021-01-30T23:57:00+00:00",
    "id": 14,
    "progress": 100,
    "resources": [
      {
        "id": 896,
        "type": "certificate"
      }
    ],
    "started": "2021-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

