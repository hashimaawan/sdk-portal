# Volume Actions

```java
VolumeActionsController volumeActionsController = client.getVolumeActionsController();
```

## Class Name

`VolumeActionsController`

## Methods

* [Get All Actions for a Volume](../../doc/controllers/volume-actions.md#get-all-actions-for-a-volume)
* [Attach Volume to a Server](../../doc/controllers/volume-actions.md#attach-volume-to-a-server)
* [Change Volume Protection](../../doc/controllers/volume-actions.md#change-volume-protection)
* [Detach Volume](../../doc/controllers/volume-actions.md#detach-volume)
* [Resize Volume](../../doc/controllers/volume-actions.md#resize-volume)
* [Get an Action for a Volume](../../doc/controllers/volume-actions.md#get-an-action-for-a-volume)


# Get All Actions for a Volume

Returns all Action objects for a Volume. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```java
CompletableFuture<ActionsResponse> getAllActionsForAVolumeAsync(
    final int id,
    final ParameterSortEnum sort,
    final ParameterStatusEnum status)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `sort` | [`ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```java
int id = 112;

volumeActionsController.getAllActionsForAVolumeAsync(id, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "attach_volume",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 13,
          "type": "volume"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Attach Volume to a Server

Attaches a Volume to a Server. Works only if the Server is in the same Location as the Volume.

```java
CompletableFuture<ActionResponse> attachVolumeToAServerAsync(
    final int id,
    final AttachVolumeRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`AttachVolumeRequest`](../../doc/models/attach-volume-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `attach_volume` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
AttachVolumeRequest body = new AttachVolumeRequest.Builder(
    43
)
.automount(false)
.build();

volumeActionsController.attachVolumeToAServerAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 43,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Volume Protection

Changes the protection configuration of a Volume.

```java
CompletableFuture<ActionResponse> changeVolumeProtectionAsync(
    final int id,
    final VolumesActionsChangeProtectionRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`VolumesActionsChangeProtectionRequest`](../../doc/models/volumes-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
VolumesActionsChangeProtectionRequest body = new VolumesActionsChangeProtectionRequest.Builder()
    .delete(true)
    .build();

volumeActionsController.changeVolumeProtectionAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Detach Volume

Detaches a Volume from the Server it’s attached to. You may attach it to a Server again at a later time.

```java
CompletableFuture<ActionResponse> detachVolumeAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |

## Response Type

**201**: The `action` key contains the `detach_volume` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;

volumeActionsController.detachVolumeAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "detach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Resize Volume

Changes the size of a Volume. Note that downsizing a Volume is not possible.

```java
CompletableFuture<ActionResponse> resizeVolumeAsync(
    final int id,
    final VolumesActionsResizeRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`VolumesActionsResizeRequest`](../../doc/models/volumes-actions-resize-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `resize_volume` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
VolumesActionsResizeRequest body = new VolumesActionsResizeRequest.Builder(
    50D
)
.build();

volumeActionsController.resizeVolumeAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "resize_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Get an Action for a Volume

Returns a specific Action for a Volume.

```java
CompletableFuture<ActionResponse> getAnActionForAVolumeAsync(
    final int id,
    final int actionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Volume Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
int actionId = 224;

volumeActionsController.getAnActionForAVolumeAsync(id, actionId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

