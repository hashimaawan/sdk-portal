
# Row

The rows that make up a query result table.

## Structure

`Row`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`Datum[] \| undefined`](../../doc/models/datum.md) | Optional | - |

## Example

```ts
import { Row } from 'amazon-athenalib';

const row: Row = {
  data: [
    {
      varCharValue: 'VarCharValue8',
    }
  ],
};
```

