
# Data Catalog Type 3

Specifies the type of data catalog to update. Specify <code>LAMBDA</code> for a federated catalog, <code>HIVE</code> for an external hive metastore, or <code>GLUE</code> for an Glue Data Catalog.

## Enumeration

`DataCatalogType3`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```ruby
data_catalog_type3 = DataCatalogType3::LAMBDA
```

