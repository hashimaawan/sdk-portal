
# Parameter Type 1 Enum

## Enumeration

`ParameterType1Enum`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```php
use HetznerCloudAPILib\Models\ParameterType1Enum;

$parameterType1 = ParameterType1Enum::SPREAD;
```

