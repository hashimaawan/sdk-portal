
# Result Configuration

The location in Amazon S3 where query and calculation results are stored and the encryption option, if any, used for query and calculation results. These are known as "client-side settings". If workgroup settings override client-side settings, then the query uses the workgroup settings.

## Structure

`ResultConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `outputLocation` | `string \| undefined` | Optional | - |
| `encryptionConfiguration` | [`EncryptionConfiguration2 \| undefined`](../../doc/models/encryption-configuration-2.md) | Optional | - |
| `expectedBucketOwner` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` |
| `aclConfiguration` | [`AclConfiguration1 \| undefined`](../../doc/models/acl-configuration-1.md) | Optional | - |

## Example

```ts
import {
  EncryptionOption1Enum,
  ResultConfiguration,
  S3AclOption1Enum,
} from 'amazon-athenalib';

const resultConfiguration: ResultConfiguration = {
  outputLocation: 'OutputLocation4',
  encryptionConfiguration: {
    encryptionOption: EncryptionOption1Enum.SSES3,
    kmsKey: 'KmsKey6',
  },
  expectedBucketOwner: 'ExpectedBucketOwner4',
  aclConfiguration: {
    s3AclOption: S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
  },
};
```

