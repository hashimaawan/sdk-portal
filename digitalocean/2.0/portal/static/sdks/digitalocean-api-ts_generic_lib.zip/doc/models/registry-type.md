
# Registry Type

- DOCKER_HUB: The DockerHub container registry type.
- DOCR: The DigitalOcean container registry type.

## Enumeration

`RegistryType`

## Fields

| Name |
|  --- |
| `DockerHub` |
| `Docr` |

## Example

```ts
import { RegistryType } from 'digitalocean-apilib';

const registryType = RegistryType.DockerHub;
```

