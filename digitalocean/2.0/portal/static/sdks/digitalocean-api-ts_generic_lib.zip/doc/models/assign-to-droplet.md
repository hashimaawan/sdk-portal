
# Assign to Droplet

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`AssignToDroplet`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletId` | `number` | Required | The ID of the Droplet that the floating IP will be assigned to. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { AssignToDroplet } from 'digitalocean-apilib';

const assignToDroplet: AssignToDroplet = {
  dropletId: 2457247,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

