
# X Amz Target 25

## Enumeration

`XAmzTarget25`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryRuntimeStatistics` |

## Example

```ts
import { XAmzTarget25 } from 'amazon-athenalib';

const xAmzTarget25 = XAmzTarget25.EnumAmazonAthenaGetQueryRuntimeStatistics;
```

