
# Status 1

The current status of the action. This can be "in-progress", "completed", or "errored".

## Enumeration

`Status1`

## Fields

| Name |
|  --- |
| `Inprogress` |
| `Completed` |
| `Errored` |

## Example

```ts
import { Status1 } from 'digitalocean-apilib';

const status1 = Status1.Inprogress;
```

