
# X Amz Target 11 Enum

## Enumeration

`XAmzTarget11Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENADELETENOTEBOOK` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget11 := models.XAmzTarget11Enum_ENUMAMAZONATHENADELETENOTEBOOK

}
```

