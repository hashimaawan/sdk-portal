
# Price Monthly 8

Monthly costs for a Load Balancer type in this network zone

## Structure

`PriceMonthly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `string` | Required | Price with VAT added |
| `net` | `string` | Required | Price without VAT |

## Example

```ts
import { PriceMonthly8 } from 'hetzner-cloud-apilib';

const priceMonthly8: PriceMonthly8 = {
  gross: '1.1900000000000000',
  net: '1.0000000000',
};
```

