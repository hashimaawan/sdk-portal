
# Get Database Output

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Database` | [`Database2`](../../doc/models/database-2.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetDatabaseOutput getDatabaseOutput = new GetDatabaseOutput
{
    Database = new Database2
    {
        Name = "Name2",
        Description = "Description8",
        Parameters = new Parameters
        {
        },
    },
};
```

