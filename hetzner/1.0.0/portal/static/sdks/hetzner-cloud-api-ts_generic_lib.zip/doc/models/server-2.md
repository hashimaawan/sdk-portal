
# Server 2

Configuration for type Server, required if type is `server`

*This model accepts additional fields of type unknown.*

## Structure

`Server2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Server |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Server2 } from 'hetzner-cloud-apilib';

const server2: Server2 = {
  id: 162,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

