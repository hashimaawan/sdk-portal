
# Column Info

Information about the columns in a query execution result.

## Structure

`ColumnInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalog_name` | `String` | Optional | - |
| `schema_name` | `String` | Optional | - |
| `table_name` | `String` | Optional | - |
| `name` | `String` | Required | - |
| `label` | `String` | Optional | - |
| `type` | `String` | Required | - |
| `precision` | `Integer` | Optional | - |
| `scale` | `Integer` | Optional | - |
| `nullable` | [`ColumnNullable2Enum`](../../doc/models/column-nullable-2-enum.md) | Optional | - |
| `case_sensitive` | `TrueClass \| FalseClass` | Optional | - |

## Example

```ruby
column_info = ColumnInfo.new(
  'Name8',
  'Type8',
  'CatalogName2',
  'SchemaName8',
  'TableName4',
  'Label6',
  110,
  nil,
  envrr
)
```

