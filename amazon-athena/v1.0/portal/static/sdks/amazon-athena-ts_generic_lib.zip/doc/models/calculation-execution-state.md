
# Calculation Execution State

## Enumeration

`CalculationExecutionState`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Queued` |
| `Running` |
| `Canceling` |
| `Canceled` |
| `Completed` |
| `Failed` |

## Example

```ts
import { CalculationExecutionState } from 'amazon-athenalib';

const calculationExecutionState = CalculationExecutionState.Completed;
```

