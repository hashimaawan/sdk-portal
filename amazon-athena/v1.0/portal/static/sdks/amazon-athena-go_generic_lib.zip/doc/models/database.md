
# Database

Contains metadata information for a database in a data catalog.

## Structure

`Database`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Parameters` | [`*models.Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    database := models.Database{
        Name:                 "Name0",
        Description:          models.ToPointer("Description6"),
        Parameters:           models.ToPointer(models.Parameters{
        }),
    }

}
```

