
# X Amz Target 21

## Enumeration

`XAmzTarget21`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetNotebookMetadata` |

## Example

```ts
import { XAmzTarget21 } from 'amazon-athenalib';

const xAmzTarget21 = XAmzTarget21.EnumAmazonAthenaGetNotebookMetadata;
```

