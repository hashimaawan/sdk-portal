
# Target

*This model accepts additional fields of type Object.*

## Structure

`Target`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `health_status` | [`Array[HealthStatus]`](../../doc/models/health-status.md) | Optional | - |
| `server` | [`Server11`](../../doc/models/server-11.md) | Optional | - |
| `type` | `String` | Optional | - |
| `use_private_ip` | `TrueClass \| FalseClass` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
target = Target.new(
  health_status: [
    HealthStatus.new(
      listen_port: 142,
      status: Status30::UNKNOWN,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    HealthStatus.new(
      listen_port: 142,
      status: Status30::UNKNOWN,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    HealthStatus.new(
      listen_port: 142,
      status: Status30::UNKNOWN,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  server: Server11.new(
    id: 14,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  type: 'server',
  use_private_ip: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

