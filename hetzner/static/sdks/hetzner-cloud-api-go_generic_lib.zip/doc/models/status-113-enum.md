
# Status 113 Enum

Current status of the Volume

## Enumeration

`Status113Enum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `AVAILABLE` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    status113 := models.Status113Enum_CREATING

}
```

