
# X Amz Target 19

## Enumeration

`XAmzTarget19`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATABASE` |

## Example

```ruby
x_amz_target19 = XAmzTarget19::ENUM_AMAZONATHENAGETDATABASE
```

