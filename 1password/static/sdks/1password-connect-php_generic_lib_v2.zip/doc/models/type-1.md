
# Type 1

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `STRING` |
| `EMAIL` |
| `CONCEALED` |
| `URL` |
| `TOTP` |
| `DATE` |
| `MONTH_YEAR` |
| `MENU` |

## Example

```php
use M1PasswordConnectLib\Models\Type1;

$type1 = Type1::CONCEALED;
```

