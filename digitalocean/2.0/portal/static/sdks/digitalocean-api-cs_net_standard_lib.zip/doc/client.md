
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(30)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| LogBuilder | [`LogBuilder`](../doc/log-builder.md) | Represents the logging configuration builder for API calls |
| BearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

## Code-Based Initialization

```csharp
using DigitalOceanApi.Standard;
using DigitalOceanApi.Standard.Authentication;
using Microsoft.Extensions.Logging;

namespace ConsoleApp;

DigitalOceanApiClient client = new DigitalOceanApiClient.Builder()
    .BearerAuthCredentials(
        new BearerAuthModel.Builder(
            "AccessToken"
        )
        .Build())
    .HttpClientConfig(httpClientConfig =>
        httpClientConfig.Timeout(TimeSpan.FromSeconds(100)))
    .LoggingConfig(config => config
        .LogLevel(LogLevel.Information)
        .RequestConfig(reqConfig => reqConfig.Body(true))
        .ResponseConfig(respConfig => respConfig.Headers(true))
    )
    .Build();
```

## Configuration-Based Initialization

```csharp
using DigitalOceanApi.Standard;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp;

// Build the IConfiguration using .NET conventions (JSON, environment, etc.)
var configuration = new ConfigurationBuilder()
    .AddJsonFile("config.json")
    .AddEnvironmentVariables() // [optional] read environment variables
    .Build();

// Instantiate your SDK and configure it from IConfiguration
var client = DigitalOceanApiClient
    .FromConfiguration(configuration.GetSection("DigitalOceanApi"));
```

See the [Configuration-Based Initialization](../doc/configuration-based-initialization.md) section for details.

## DigitalOcean APIClient Class

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| M1ClickApplicationsApi | Gets M1ClickApplicationsApi. |
| AccountApi | Gets AccountApi. |
| ActionsApi | Gets ActionsApi. |
| AppsApi | Gets AppsApi. |
| BillingApi | Gets BillingApi. |
| BlockStorageApi | Gets BlockStorageApi. |
| BlockStorageActionsApi | Gets BlockStorageActionsApi. |
| CdnEndpointsApi | Gets CdnEndpointsApi. |
| CertificatesApi | Gets CertificatesApi. |
| ContainerRegistryApi | Gets ContainerRegistryApi. |
| DatabasesApi | Gets DatabasesApi. |
| DomainRecordsApi | Gets DomainRecordsApi. |
| DomainsApi | Gets DomainsApi. |
| DropletActionsApi | Gets DropletActionsApi. |
| DropletsApi | Gets DropletsApi. |
| FirewallsApi | Gets FirewallsApi. |
| FloatingIpActionsApi | Gets FloatingIpActionsApi. |
| FloatingIPsApi | Gets FloatingIPsApi. |
| FunctionsApi | Gets FunctionsApi. |
| ImageActionsApi | Gets ImageActionsApi. |
| ImagesApi | Gets ImagesApi. |
| KubernetesApi | Gets KubernetesApi. |
| LoadBalancersApi | Gets LoadBalancersApi. |
| MonitoringApi | Gets MonitoringApi. |
| ProjectResourcesApi | Gets ProjectResourcesApi. |
| ProjectsApi | Gets ProjectsApi. |
| RegionsApi | Gets RegionsApi. |
| ReservedIpActionsApi | Gets ReservedIpActionsApi. |
| ReservedIPsApi | Gets ReservedIPsApi. |
| SizesApi | Gets SizesApi. |
| SnapshotsApi | Gets SnapshotsApi. |
| SshKeysApi | Gets SshKeysApi. |
| TagsApi | Gets TagsApi. |
| UptimeApi | Gets UptimeApi. |
| VpCsApi | Gets VpCsApi. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| BearerAuthCredentials | Gets the credentials to use with BearerAuth. | [`IBearerAuthCredentials`](auth/oauth-2-bearer-token.md) |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the DigitalOcean APIClient using the values provided for the builder. | `Builder` |

## DigitalOcean APIClient Builder Class

Class to build instances of DigitalOcean APIClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `BearerAuthCredentials(Action<BearerAuthModel.Builder> action)` | Sets credentials for BearerAuth. | `Builder` |

