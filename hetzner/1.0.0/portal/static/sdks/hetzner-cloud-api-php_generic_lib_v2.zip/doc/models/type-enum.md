
# Type Enum

Type of the Certificate

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```php
use HetznerCloudAPILib\Models\TypeEnum;

$type = TypeEnum::UPLOADED;
```

