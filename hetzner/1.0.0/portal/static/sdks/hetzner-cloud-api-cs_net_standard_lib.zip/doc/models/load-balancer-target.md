
# Load Balancer Target

## Structure

`LoadBalancerTarget`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `HealthStatus` | [`List<HealthStatus>`](../../doc/models/health-status.md) | Optional | List of health statuses of the services on this target |
| `Ip` | [`Ip`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. |
| `LabelSelector` | [`LabelSelector7`](../../doc/models/label-selector-7.md) | Optional | Label selector and a list of selected targets |
| `Server` | [`LoadBalancerTargetServer`](../../doc/models/load-balancer-target-server.md) | Optional | Server where the traffic should be routed through |
| `Targets` | [`List<Target>`](../../doc/models/target.md) | Optional | List of selected targets |
| `Type` | [`Type29Enum`](../../doc/models/type-29-enum.md) | Required | Type of the resource |
| `UsePrivateIp` | `bool?` | Optional | Use the private network IP instead of the public IP. Default value is false. |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

LoadBalancerTarget loadBalancerTarget = new LoadBalancerTarget
{
    Type = Type29Enum.LabelSelector,
    HealthStatus = new List<HealthStatus>
    {
        new HealthStatus
        {
            ListenPort = 142,
            Status = Status30Enum.Unknown,
        },
        new HealthStatus
        {
            ListenPort = 142,
            Status = Status30Enum.Unknown,
        },
    },
    Ip = new Ip
    {
        Ip = "ip8",
    },
    LabelSelector = new LabelSelector7
    {
        Selector = "selector8",
    },
    Server = new LoadBalancerTargetServer
    {
        Id = 14,
    },
    Targets = new List<Target>
    {
        new Target
        {
            HealthStatus = new List<HealthStatus>
            {
                new HealthStatus
                {
                    ListenPort = 142,
                    Status = Status30Enum.Unknown,
                },
                new HealthStatus
                {
                    ListenPort = 142,
                    Status = Status30Enum.Unknown,
                },
            },
            Server = new Server11
            {
                Id = 14,
            },
            Type = "type2",
            UsePrivateIp = false,
        },
        new Target
        {
            HealthStatus = new List<HealthStatus>
            {
                new HealthStatus
                {
                    ListenPort = 142,
                    Status = Status30Enum.Unknown,
                },
                new HealthStatus
                {
                    ListenPort = 142,
                    Status = Status30Enum.Unknown,
                },
            },
            Server = new Server11
            {
                Id = 14,
            },
            Type = "type2",
            UsePrivateIp = false,
        },
        new Target
        {
            HealthStatus = new List<HealthStatus>
            {
                new HealthStatus
                {
                    ListenPort = 142,
                    Status = Status30Enum.Unknown,
                },
                new HealthStatus
                {
                    ListenPort = 142,
                    Status = Status30Enum.Unknown,
                },
            },
            Server = new Server11
            {
                Id = 14,
            },
            Type = "type2",
            UsePrivateIp = false,
        },
    },
};
```

