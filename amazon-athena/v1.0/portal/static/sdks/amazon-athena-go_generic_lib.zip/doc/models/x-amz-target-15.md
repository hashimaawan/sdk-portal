
# X Amz Target 15

## Enumeration

`XAmzTarget15`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetcalculationexecution` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget15 := models.XAmzTarget15_EnumAmazonathenagetcalculationexecution

}
```

