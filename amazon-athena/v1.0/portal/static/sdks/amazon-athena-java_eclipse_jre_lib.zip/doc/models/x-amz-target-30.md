
# X Amz Target 30

## Enumeration

`XAmzTarget30`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAIMPORTNOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget30;

XAmzTarget30 xAmzTarget30 = XAmzTarget30.ENUM_AMAZONATHENAIMPORTNOTEBOOK;
```

