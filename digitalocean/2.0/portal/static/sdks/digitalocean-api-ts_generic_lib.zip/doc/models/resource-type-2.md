
# Resource Type 2

The type of the resource.

## Enumeration

`ResourceType2`

## Fields

| Name |
|  --- |
| `Droplet` |
| `Image` |
| `Volume` |
| `VolumeSnapshot` |

## Example

```ts
import { ResourceType2 } from 'digitalocean-apilib';

const resourceType2 = ResourceType2.Volume;
```

