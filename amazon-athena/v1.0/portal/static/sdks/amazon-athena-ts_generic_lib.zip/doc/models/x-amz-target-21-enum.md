
# X Amz Target 21 Enum

## Enumeration

`XAmzTarget21Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetNotebookMetadata` |

## Example

```ts
import { XAmzTarget21Enum } from 'amazon-athenalib';

const xAmzTarget21 = XAmzTarget21Enum.EnumAmazonAthenaGetNotebookMetadata;
```

