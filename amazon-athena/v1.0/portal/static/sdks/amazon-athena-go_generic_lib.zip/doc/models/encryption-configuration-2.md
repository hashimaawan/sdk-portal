
# Encryption Configuration 2

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EncryptionOption` | [`models.EncryptionOption1Enum`](../../doc/models/encryption-option-1-enum.md) | Required | - |
| `KmsKey` | `*string` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    encryptionConfiguration2 := models.EncryptionConfiguration2{
        EncryptionOption:     models.EncryptionOption1Enum_SSES3,
        KmsKey:               models.ToPointer("KmsKey2"),
    }

}
```

