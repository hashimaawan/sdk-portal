
# Column Nullable Enum

## Enumeration

`ColumnNullableEnum`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```python
from amazonathena.models.column_nullable_enum import ColumnNullableEnum

column_nullable = ColumnNullableEnum.UNKNOWN
```

