
# X Amz Target 46

## Enumeration

`XAmzTarget46`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget46;

XAmzTarget46 xAmzTarget46 = XAmzTarget46.ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION;
```

