
# Result Configuration 1

## Structure

`ResultConfiguration1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `outputLocation` | `?string` | Optional | - | getOutputLocation(): ?string | setOutputLocation(?string outputLocation): void |
| `encryptionConfiguration` | [`?EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - | getEncryptionConfiguration(): ?EncryptionConfiguration2 | setEncryptionConfiguration(?EncryptionConfiguration2 encryptionConfiguration): void |
| `expectedBucketOwner` | `?string` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` | getExpectedBucketOwner(): ?string | setExpectedBucketOwner(?string expectedBucketOwner): void |
| `aclConfiguration` | [`?AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - | getAclConfiguration(): ?AclConfiguration1 | setAclConfiguration(?AclConfiguration1 aclConfiguration): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultConfiguration1Builder;
use AmazonAthenaLib\Models\Builders\EncryptionConfiguration2Builder;
use AmazonAthenaLib\Models\EncryptionOption1Enum;
use AmazonAthenaLib\Models\Builders\AclConfiguration1Builder;
use AmazonAthenaLib\Models\S3AclOption1Enum;

$resultConfiguration1 = ResultConfiguration1Builder::init()
    ->outputLocation('OutputLocation4')
    ->encryptionConfiguration(
        EncryptionConfiguration2Builder::init(
            EncryptionOption1Enum::SSE_S3
        )
            ->kmsKey('KmsKey6')
            ->build()
    )
    ->expectedBucketOwner('ExpectedBucketOwner4')
    ->aclConfiguration(
        AclConfiguration1Builder::init(
            S3AclOption1Enum::BUCKET_OWNER_FULL_CONTROL
        )->build()
    )->build();
```

