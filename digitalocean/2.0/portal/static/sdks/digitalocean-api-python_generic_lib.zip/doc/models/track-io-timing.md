
# Track Io Timing

Enables timing of database I/O calls. This parameter is off by default, because it will repeatedly query the operating system for the current time, which may cause significant overhead on some platforms.

## Enumeration

`TrackIoTiming`

## Fields

| Name |
|  --- |
| `OFF` |
| `ON` |

## Example

```python
from digitaloceanapi.models.track_io_timing import TrackIoTiming

track_io_timing = TrackIoTiming.OFF
```

