
# Type Enum

Type of the gif. By default, this is almost always gif

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `GIF` |

## Example

```java
import com.giphy.api.models.TypeEnum;

TypeEnum type = TypeEnum.GIF;
```

