
# Type 48

The type of the Floating IP

## Enumeration

`Type48`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```ruby
type48 = Type48::IPV4
```

