
# X Amz Target 47

## Enumeration

`XAmzTarget47`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTQUERYEXECUTION` |

## Example

```ruby
x_amz_target47 = XAmzTarget47::ENUM_AMAZONATHENASTARTQUERYEXECUTION
```

