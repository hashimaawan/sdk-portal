
# Locations Response 1

*This model accepts additional fields of type interface{}.*

## Structure

`LocationsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Location` | [`models.Location`](../../doc/models/location.md) | Required | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    locationsResponse1 := models.LocationsResponse1{
        Location:              models.Location{
            City:                  "Falkenstein",
            Country:               "DE",
            Description:           "Falkenstein DC Park 1",
            Id:                    float64(1),
            Latitude:              float64(50.47612),
            Longitude:             float64(12.370071),
            Name:                  "fsn1",
            NetworkZone:           "eu-central",
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

