
# Price Hourly 8

Hourly costs for a Server type in this Location

## Structure

`PriceHourly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `string` | Required | Price with VAT added |
| `net` | `string` | Required | Price without VAT |

## Example

```ts
import { PriceHourly8 } from 'hetzner-cloud-apilib';

const priceHourly8: PriceHourly8 = {
  gross: '1.1900000000000000',
  net: '1.0000000000',
};
```

