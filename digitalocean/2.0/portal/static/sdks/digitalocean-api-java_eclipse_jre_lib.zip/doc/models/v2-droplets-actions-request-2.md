
# V2 Droplets Actions Request 2

*This model accepts additional fields of type Object.*

## Structure

`V2DropletsActionsRequest2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. | Type12 getType() | setType(Type12 type) |
| `Image` | `Integer` | Optional | The ID of a backup of the current Droplet instance to restore from. | Integer getImage() | setImage(Integer image) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Type12;
import com.digitalocean.api.models.V2DropletsActionsRequest2;
import java.io.IOException;

V2DropletsActionsRequest2 v2DropletsActionsRequest2 = new V2DropletsActionsRequest2.Builder(
    Type12.REBOOT
)
.image(12389723)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

