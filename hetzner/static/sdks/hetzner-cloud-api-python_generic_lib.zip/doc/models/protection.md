
# Protection

Protection configuration for the Resource

## Structure

`Protection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Required | If true, prevents the Resource from being deleted |

## Example

```python
from hetznercloudapi.models.protection import Protection

protection = Protection(
    delete=False
)
```

