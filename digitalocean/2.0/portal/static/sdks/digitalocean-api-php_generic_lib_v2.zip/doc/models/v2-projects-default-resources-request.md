
# V2 Projects Default Resources Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2ProjectsDefaultResourcesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `resources` | `?(string[])` | Optional | A list of uniform resource names (URNs) to be added to a project.<br><br>**Constraints**: *Pattern*: `^do:(dbaas\|domain\|droplet\|floatingip\|loadbalancer\|space\|volume\|kubernetes\|vpc):.*` | getResources(): ?array | setResources(?array resources): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2ProjectsDefaultResourcesRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2ProjectsDefaultResourcesRequest = V2ProjectsDefaultResourcesRequestBuilder::init()
    ->resources(
        [
            'do:droplet:13457723'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

