
# V2 Customers My Invoices Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2CustomersMyInvoicesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `invoicePreview` | [`?InvoicePreview`](../../doc/models/invoice-preview.md) | Optional | The invoice preview. | getInvoicePreview(): ?InvoicePreview | setInvoicePreview(?InvoicePreview invoicePreview): void |
| `invoices` | [`?(InvoicePreview[])`](../../doc/models/invoice-preview.md) | Optional | - | getInvoices(): ?array | setInvoices(?array invoices): void |
| `links` | [`?Links`](../../doc/models/links.md) | Optional | - | getLinks(): ?Links | setLinks(?Links links): void |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - | getMeta(): Meta | setMeta(Meta meta): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2CustomersMyInvoicesResponseBuilder;
use DigitalOceanApiLib\Models\Builders\MetaBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\InvoicePreviewBuilder;
use DigitalOceanApiLib\Models\Builders\LinksBuilder;
use DigitalOceanApiLib\Models\Builders\PagesBuilder;

$v2CustomersMyInvoicesResponse = V2CustomersMyInvoicesResponseBuilder::init(
    MetaBuilder::init(
        70
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->invoicePreview(
        InvoicePreviewBuilder::init()
            ->amount('34.56')
            ->invoicePeriod('2020-02')
            ->invoiceUuid('1afe95e6-0958-4eb0-8d9a-9c5060d3ef03')
            ->updatedAt('2020-02-23T06:31:50Z')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->invoices(
        [
            InvoicePreviewBuilder::init()
                ->amount('12.34')
                ->invoicePeriod('2019-12')
                ->invoiceUuid('22737513-0ea7-4206-8ceb-98a575af7681')
                ->updatedAt('updated_at8')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            InvoicePreviewBuilder::init()
                ->amount('23.45')
                ->invoicePeriod('2019-11')
                ->invoiceUuid('fdabb512-6faf-443c-ba2e-665452332a9e')
                ->updatedAt('updated_at8')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->links(
        LinksBuilder::init()
            ->pages(
                PagesBuilder::init()
                    ->last('https://api.digitalocean.com/v2/customers/my/invoices?page=35&per_page=2')
                    ->next('https://api.digitalocean.com/v2/customers/my/invoices?page=2&per_page=2')
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

