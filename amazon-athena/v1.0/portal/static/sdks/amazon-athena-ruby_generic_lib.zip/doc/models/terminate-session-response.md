
# Terminate Session Response

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```ruby
terminate_session_response = TerminateSessionResponse.new(
  SessionState1Enum::CREATING
)
```

