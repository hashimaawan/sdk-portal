# Health

```ruby
health_api = client.health
```

## Class Name

`HealthApi`

## Methods

* [Get Server Health](../../doc/controllers/health.md#get-server-health)
* [Get Heartbeat](../../doc/controllers/health.md#get-heartbeat)


# Get Server Health

:information_source: **Note** This endpoint does not require authentication.

```ruby
def get_server_health
```

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`HealthResponse`](../../doc/models/health-response.md).

## Example Usage

```ruby
result = health_api.get_server_health

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "dependencies": [
    {
      "service": "sync",
      "status": "TOKEN_NEEDED"
    },
    {
      "message": "Connected to./1password.sqlite",
      "service": "sqlite",
      "status": "ACTIVE"
    }
  ],
  "name": "1Password Connect API",
  "version": "1.2.1"
}
```


# Get Heartbeat

:information_source: **Note** This endpoint does not require authentication.

```ruby
def get_heartbeat
```

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type `String`.

## Example Usage

```ruby
result = health_api.get_heartbeat

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

