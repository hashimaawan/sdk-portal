
# X Amz Target 27 Enum

## Enumeration

`XAmzTarget27Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETSESSIONSTATUS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget27 := models.XAmzTarget27Enum_ENUMAMAZONATHENAGETSESSIONSTATUS

}
```

