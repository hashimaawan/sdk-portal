
# Get Session Response

## Structure

`GetSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `WorkGroup` | `*string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `EngineVersion` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `EngineConfiguration` | [`*models.EngineConfiguration1`](../../doc/models/engine-configuration-1.md) | Optional | - |
| `NotebookVersion` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `SessionConfiguration` | [`*models.SessionConfiguration2`](../../doc/models/session-configuration-2.md) | Optional | - |
| `Status` | [`*models.Status3`](../../doc/models/status-3.md) | Optional | - |
| `Statistics` | [`*models.Statistics3`](../../doc/models/statistics-3.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getSessionResponse := models.GetSessionResponse{
        SessionId:            models.ToPointer("SessionId6"),
        Description:          models.ToPointer("Description4"),
        WorkGroup:            models.ToPointer("WorkGroup4"),
        EngineVersion:        models.ToPointer("EngineVersion8"),
        EngineConfiguration:  models.ToPointer(models.EngineConfiguration1{
            CoordinatorDpuSize:     models.ToPointer(1),
            MaxConcurrentDpus:      94,
            DefaultExecutorDpuSize: models.ToPointer(1),
            AdditionalConfigs:      models.ToPointer(models.AdditionalConfigs{
            }),
        }),
    }

}
```

