
# List Work Groups Input

## Structure

`ListWorkGroupsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listWorkGroupsInput := models.ListWorkGroupsInput{
        NextToken:            models.ToPointer("NextToken8"),
        MaxResults:           models.ToPointer(50),
    }

}
```

