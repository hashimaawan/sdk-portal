
# X Amz Target 32

## Enumeration

`XAmzTarget32`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```python
from amazonathena.models.x_amz_target_32 import XAmzTarget32

x_amz_target_32 = XAmzTarget32.ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS
```

