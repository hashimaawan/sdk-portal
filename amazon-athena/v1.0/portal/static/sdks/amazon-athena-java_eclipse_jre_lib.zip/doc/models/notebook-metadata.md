
# Notebook Metadata

Contains metadata for notebook, including the notebook name, ID, workgroup, and time created.

## Structure

`NotebookMetadata`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NotebookId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` | String getNotebookId() | setNotebookId(String notebookId) |
| `Name` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` | String getName() | setName(String name) |
| `WorkGroup` | `String` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | String getWorkGroup() | setWorkGroup(String workGroup) |
| `CreationTime` | `LocalDateTime` | Optional | - | LocalDateTime getCreationTime() | setCreationTime(LocalDateTime creationTime) |
| `Type` | [`NotebookType1Enum`](../../doc/models/notebook-type-1-enum.md) | Optional | - | NotebookType1Enum getType() | setType(NotebookType1Enum type) |
| `LastModifiedTime` | `LocalDateTime` | Optional | - | LocalDateTime getLastModifiedTime() | setLastModifiedTime(LocalDateTime lastModifiedTime) |

## Example

```java
import com.amazonaws.useast1.athena.DateTimeHelper;
import com.amazonaws.useast1.athena.models.NotebookMetadata;
import com.amazonaws.useast1.athena.models.NotebookType1Enum;

NotebookMetadata notebookMetadata = new NotebookMetadata.Builder()
    .notebookId("NotebookId0")
    .name("Name0")
    .workGroup("WorkGroup2")
    .creationTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
    .type(NotebookType1Enum.IPYNB)
    .build();
```

