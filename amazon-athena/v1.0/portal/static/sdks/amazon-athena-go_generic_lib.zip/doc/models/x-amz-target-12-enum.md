
# X Amz Target 12 Enum

## Enumeration

`XAmzTarget12Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget12 := models.XAmzTarget12Enum_ENUMAMAZONATHENADELETEPREPAREDSTATEMENT

}
```

