
# OAuth 2 Implicit Grant



Documentation for accessing and setting credentials for furkot_auth_implicit.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| oAuthClientId | `string` | OAuth 2 Client ID | `WithOAuthClientId` | `OAuthClientId()` |
| oAuthRedirectUri | `string` | OAuth 2 Redirection endpoint or Callback Uri | `WithOAuthRedirectUri` | `OAuthRedirectUri()` |
| oAuthToken | `OAuthToken` | Object for storing information about the OAuth token | `WithOAuthToken` | `OAuthToken()` |
| oAuthScopes | `[]OAuthScopeFurkotAuthImplicitEnum` | List of scopes that apply to the OAuth token | `WithOAuthScopes` | `OAuthScopes()` |



**Note:** Required auth credentials can be set using `WithFurkotAuthImplicitCredentials()` by providing a credentials instance with `NewFurkotAuthImplicitCredentials()` in the configuration initialization and accessed using the `FurkotAuthImplicitCredentials()` method in the configuration instance.

## Usage Example



Your application must obtain user authorization before it can execute an endpoint call in case this SDK chooses to use *OAuth 2.0 Implicit Grant* to obtain a user's consent to perform an API request on user's behalf. This authorization includes the following steps

This process requires the presence of a client-side JavaScript code on the redirect URI page to receive the *access token* after the consent step is completed.

### 1\. Obtain user consent

To obtain user's consent, you must redirect the user to the authorization page. The `BuildAuthorizationURL` method creates the URL to the authorization page. You must have initialized the client with scopes for which you need permission to access.

```go
state := "session-state"
url := client.FurkotAuthImplicitManager().BuildAuthorizationURL(state)
// redirect the user to the given URL and get a code after the user consents
```

### 2\. Handle the OAuth server response

Once the user responds to the consent request, the OAuth 2.0 server responds to your application's access request by redirecting the user to the redirect URI specified set in `Configuration`.

The redirect URI will receive the *access token* as the `token` argument in the URL fragment.

```
https://example.com/oauth/callback#token=XXXXXXXXXXXXXXXXXXXXXXXXX
```

The access token must be extracted by the client-side JavaScript code. The access token can be used to authorize any further endpoint calls by the JavaScript code.

### Scopes

Scopes enable your application to only request access to the resources it needs while enabling users to control the amount of access they grant to your application. Available scopes are defined in the [`OAuthScopeFurkotAuthImplicitEnum`](../../doc/models/o-auth-scope-furkot-auth-implicit-enum.md) enumeration.

| Scope Name | Description |
|  --- | --- |
| `READTRIPS` | list users trips info |


