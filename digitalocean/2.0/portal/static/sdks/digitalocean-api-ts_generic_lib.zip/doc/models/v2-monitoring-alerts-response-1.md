
# V2 Monitoring Alerts Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2MonitoringAlertsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `policy` | [`Policy \| undefined`](../../doc/models/policy.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Compare,
  Type17,
  V2MonitoringAlertsResponse1,
  Window1,
} from 'digitalocean-apilib';

const v2MonitoringAlertsResponse1: V2MonitoringAlertsResponse1 = {
  policy: {
    alerts: {
      email: [
        'email2',
        'email3'
      ],
      slack: [
        {
          channel: 'channel6',
          url: 'url2',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          channel: 'channel6',
          url: 'url2',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          channel: 'channel6',
          url: 'url2',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    compare: Compare.GreaterThan,
    description: 'description4',
    enabled: false,
    entities: [
      'entities9'
    ],
    tags: [
      'tags9',
      'tags0',
      'tags1'
    ],
    type: Type17.EnumV1InsightsdropletdiskRead,
    uuid: 'uuid0',
    value: 149.36,
    window: Window1.Enum30M,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

