
# X Amz Target 41

## Enumeration

`XAmzTarget41`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListQueryExecutions` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget41 xAmzTarget41 = XAmzTarget41.EnumAmazonAthenaListQueryExecutions;
```

