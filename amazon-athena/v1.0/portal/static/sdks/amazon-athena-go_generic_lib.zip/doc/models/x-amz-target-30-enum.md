
# X Amz Target 30 Enum

## Enumeration

`XAmzTarget30Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAIMPORTNOTEBOOK` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget30 := models.XAmzTarget30Enum_ENUMAMAZONATHENAIMPORTNOTEBOOK

}
```

