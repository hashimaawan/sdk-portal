
# Price Hourly 8

Hourly costs for a Server type in this Location

## Structure

`PriceHourly8`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Gross` | `String` | Required | Price with VAT added | String getGross() | setGross(String gross) |
| `Net` | `String` | Required | Price without VAT | String getNet() | setNet(String net) |

## Example

```java
import cloud.hetzner.api.models.PriceHourly8;

PriceHourly8 priceHourly8 = new PriceHourly8.Builder(
    "1.1900000000000000",
    "1.0000000000"
)
.build();
```

