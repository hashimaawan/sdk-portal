
# X Amz Target 12 Enum

## Enumeration

`XAmzTarget12Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget12Enum;

$xAmzTarget12 = XAmzTarget12Enum::ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT;
```

