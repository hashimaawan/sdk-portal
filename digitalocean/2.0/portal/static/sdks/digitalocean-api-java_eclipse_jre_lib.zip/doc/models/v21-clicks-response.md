
# V21 Clicks Response

*This model accepts additional fields of type Object.*

## Structure

`V21ClicksResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `M1Clicks` | [`List<M1Click>`](../../doc/models/m1-click.md) | Optional | - | List<M1Click> getM1Clicks() | setM1Clicks(List<M1Click> m1Clicks) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.M1Click;
import com.digitalocean.api.models.V21ClicksResponse;
import java.io.IOException;
import java.util.Arrays;

V21ClicksResponse v21ClicksResponse = new V21ClicksResponse.Builder()
    .m1Clicks(Arrays.asList(
        new M1Click.Builder(
            "slug8",
            "type2"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
        new M1Click.Builder(
            "slug8",
            "type2"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

