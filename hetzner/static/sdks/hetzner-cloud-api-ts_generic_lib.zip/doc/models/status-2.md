
# Status 2

Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates

## Structure

`Status2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`Error2 \| null \| undefined`](../../doc/models/error-2.md) | Optional | If issuance or renewal reports `failed`, this property contains information about what happened |
| `issuance` | [`IssuanceEnum \| undefined`](../../doc/models/issuance-enum.md) | Optional | Status of the issuance process of the Certificate |
| `renewal` | [`RenewalEnum \| undefined`](../../doc/models/renewal-enum.md) | Optional | Status of the renewal process of the Certificate. |

## Example

```ts
import { IssuanceEnum, RenewalEnum, Status2 } from 'hetzner-cloud-apilib';

const status2: Status2 = {
  error: null,
  issuance: IssuanceEnum.Completed,
  renewal: RenewalEnum.Scheduled,
};
```

