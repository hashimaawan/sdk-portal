
# X Amz Target 38 Enum

## Enumeration

`XAmzTarget38Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget38Enum;

$xAmzTarget38 = XAmzTarget38Enum::ENUM_AMAZONATHENALISTNOTEBOOKMETADATA;
```

