
# X Amz Target 36 Enum

## Enumeration

`XAmzTarget36Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTEXECUTORS` |

## Example

```python
from amazonathena.models.x_amz_target_36_enum import XAmzTarget36Enum

x_amz_target_36 = XAmzTarget36Enum.ENUM_AMAZONATHENALISTEXECUTORS
```

