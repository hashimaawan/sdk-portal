
# Remove Target Request

*This model accepts additional fields of type interface{}.*

## Structure

`RemoveTargetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Ip` | [`*models.Ip`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. |
| `LabelSelector` | [`*models.LabelSelector12`](../../doc/models/label-selector-12.md) | Optional | Configuration for label selector targets, required if type is `label_selector` |
| `Server` | [`*models.Server16`](../../doc/models/server-16.md) | Optional | Configuration for type Server, required if type is `server` |
| `Type` | [`models.Type29`](../../doc/models/type-29.md) | Required | Type of the resource |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    removeTargetRequest := models.RemoveTargetRequest{
        Ip:                    models.ToPointer(models.Ip{
            Ip:                    "ip8",
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        LabelSelector:         models.ToPointer(models.LabelSelector12{
            Selector:              "selector8",
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        Server:                models.ToPointer(models.Server16{
            Id: float64(217.74),
        }),
        Type:                  models.Type29_Ip,
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

