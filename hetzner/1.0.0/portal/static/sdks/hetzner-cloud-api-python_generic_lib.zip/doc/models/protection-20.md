
# Protection 20

Protection configuration for the Server

*This model accepts additional fields of type Any.*

## Structure

`Protection20`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Required | If true, prevents the Server from being deleted |
| `rebuild` | `bool` | Required | If true, prevents the Server from being rebuilt |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.protection_20 import Protection20

protection_20 = Protection20(
    delete=False,
    rebuild=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

