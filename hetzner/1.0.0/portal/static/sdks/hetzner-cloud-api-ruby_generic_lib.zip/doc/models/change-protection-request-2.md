
# Change Protection Request 2

*This model accepts additional fields of type Object.*

## Structure

`ChangeProtectionRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Primary IP from being deleted |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
change_protection_request2 = ChangeProtectionRequest2.new(
  delete: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

