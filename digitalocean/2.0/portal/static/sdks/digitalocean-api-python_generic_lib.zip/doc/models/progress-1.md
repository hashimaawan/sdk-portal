
# Progress 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Progress1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `steps` | [`List[Any]`](../../doc/models/object.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.progress_1 import Progress1

progress_1 = Progress1(
    steps=[
        jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

