
# X Amz Target 34 Enum

## Enumeration

`XAmzTarget34Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTDATABASES` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget34 := models.XAmzTarget34Enum_ENUMAMAZONATHENALISTDATABASES

}
```

