
# X Amz Target 25

## Enumeration

`XAmzTarget25`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryRuntimeStatistics` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget25 xAmzTarget25 = XAmzTarget25.EnumAmazonAthenaGetQueryRuntimeStatistics;
```

