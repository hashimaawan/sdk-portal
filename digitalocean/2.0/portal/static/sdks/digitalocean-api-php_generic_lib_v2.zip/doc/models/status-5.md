
# Status 5

The current status of the migration.

## Enumeration

`Status5`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `CANCELED` |
| `ERROR` |
| `DONE` |

## Example

```php
use DigitalOceanApiLib\Models\Status5;

$status5 = Status5::RUNNING;
```

