
# Configurations for External Logging

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`ConfigurationsForExternalLogging`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `datadog` | [`Datadog`](../../doc/models/datadog.md) | Optional | DataDog configuration. |
| `logtail` | [`Logtail`](../../doc/models/logtail.md) | Optional | Logtail configuration. |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `2`, *Maximum Length*: `42`, *Pattern*: `^[A-Za-z0-9()\[\]'"][-A-Za-z0-9_. \/()\[\]]{0,40}[A-Za-z0-9()\[\]'"]$` |
| `papertrail` | [`Papertrail`](../../doc/models/papertrail.md) | Optional | Papertrail configuration. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
configurations_for_external_logging = ConfigurationsForExternalLogging.new(
  name: 'my_log_destination',
  datadog: Datadog.new(
    api_key: 'api_key2',
    endpoint: 'endpoint8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  logtail: Logtail.new(
    token: 'token4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  papertrail: Papertrail.new(
    endpoint: 'endpoint4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

