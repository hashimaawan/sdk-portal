
# Server 11

## Structure

`Server11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    server11 := models.Server11{
        Id:                   85,
    }

}
```

