
# X Amz Target 18

## Enumeration

`XAmzTarget18`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATACATALOG` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget18;

$xAmzTarget18 = XAmzTarget18::ENUM_AMAZONATHENAGETDATACATALOG;
```

