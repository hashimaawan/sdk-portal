
# Floating Ip 4

The cost of one Floating IP per month

## Structure

`FloatingIp4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price_monthly` | [`PriceMonthly6`](../../doc/models/price-monthly-6.md) | Required | - |

## Example

```ruby
floating_ip4 = FloatingIp4.new(
  PriceMonthly6.new(
    '1.1900000000000000',
    '1.0000000000'
  )
)
```

