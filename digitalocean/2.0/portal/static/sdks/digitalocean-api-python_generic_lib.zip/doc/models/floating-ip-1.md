
# Floating Ip 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`FloatingIp1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet` | Any \| None \| [Droplet](../../doc/models/droplet.md) | Optional | This is a container for any-of cases. |
| `ip` | `str` | Optional | The public IP address of the floating IP. It also serves as its identifier. |
| `locked` | `bool` | Optional | A boolean value indicating whether or not the floating IP has pending actions preventing new ones from being submitted. |
| `project_id` | `uuid\|str` | Optional | The UUID of the project to which the reserved IP currently belongs. |
| `region` | [`Region`](../../doc/models/region.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.floating_ip_1 import FloatingIp1
from digitaloceanapi.models.region import Region

floating_ip_1 = FloatingIp1(
    droplet=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    ip='45.55.96.47',
    locked=True,
    project_id='746c6152-2fa2-11ed-92d3-27aaa54e4988',
    region=Region(
        available=False,
        features=[
            'features7',
            'features8',
            'features9'
        ],
        name='name6',
        sizes=[
            'sizes6'
        ],
        slug='slug0',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

