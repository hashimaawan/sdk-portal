
# Change Protection Request 2

## Structure

`ChangeProtectionRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Primary IP from being deleted |

## Example

```ruby
change_protection_request2 = ChangeProtectionRequest2.new(
  true
)
```

