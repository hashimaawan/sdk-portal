
# Pending Deployment

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`PendingDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cause` | `str` | Optional | - |
| `cloned_from` | `str` | Optional | - |
| `created_at` | `datetime` | Optional | - |
| `functions` | [`List[FunctionsComponentsThatArePartOfThisDeployment]`](../../doc/models/functions-components-that-are-part-of-this-deployment.md) | Optional | - |
| `id` | `str` | Optional | - |
| `jobs` | [`List[JobComponentsThatArePartOfThisDeployment]`](../../doc/models/job-components-that-are-part-of-this-deployment.md) | Optional | - |
| `phase` | [`Phase`](../../doc/models/phase.md) | Optional | **Default**: `"UNKNOWN"` |
| `phase_last_updated_at` | `datetime` | Optional | - |
| `progress` | [`Progress`](../../doc/models/progress.md) | Optional | - |
| `services` | [`List[ServiceComponentsThatArePartOfThisDeployment]`](../../doc/models/service-components-that-are-part-of-this-deployment.md) | Optional | - |
| `spec` | [`AppSpec`](../../doc/models/app-spec.md) | Optional | The desired configuration of an application. |
| `static_sites` | [`List[StaticSiteComponentsThatArePartOfThisDeployment]`](../../doc/models/static-site-components-that-are-part-of-this-deployment.md) | Optional | - |
| `tier_slug` | `str` | Optional, Read-only | - |
| `updated_at` | `datetime` | Optional | - |
| `workers` | [`List[WorkerComponentsThatArePartOfThisDeployment]`](../../doc/models/worker-components-that-are-part-of-this-deployment.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.functions_components_that_are_part_of_this_deployment import FunctionsComponentsThatArePartOfThisDeployment
from digitaloceanapi.models.pending_deployment import PendingDeployment
from digitaloceanapi.models.phase import Phase

pending_deployment = PendingDeployment(
    cause='commit 9a4df0b pushed to github/digitalocean/sample-golang',
    cloned_from='3aa4d20e-5527-4c00-b496-601fbd22520a',
    created_at=dateutil.parser.parse('2020-07-28T18:00:00Z'),
    functions=[
        FunctionsComponentsThatArePartOfThisDeployment(
            name='name4',
            namespace='namespace8',
            source_commit_hash='source_commit_hash4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        FunctionsComponentsThatArePartOfThisDeployment(
            name='name4',
            namespace='namespace8',
            source_commit_hash='source_commit_hash4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    id='b6bdf840-2854-4f87-a36c-5f231c617c84',
    phase=Phase.ACTIVE,
    phase_last_updated_at=dateutil.parser.parse('0001-01-01T00:00:00Z'),
    tier_slug='basic',
    updated_at=dateutil.parser.parse('2020-07-28T18:00:00Z'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

