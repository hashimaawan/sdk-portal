
# Type 65

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65`

## Fields

| Name |
|  --- |
| `LINUX64` |
| `LINUX32` |

## Example

```php
use HetznerCloudApiLib\Models\Type65;

$type65 = Type65::LINUX64;
```

