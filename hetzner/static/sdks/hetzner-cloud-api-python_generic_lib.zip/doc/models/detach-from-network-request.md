
# Detach from Network Request

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `int` | Required | ID of an existing network to detach the Server from |

## Example

```python
from hetznercloudapi.models.detach_from_network_request import DetachFromNetworkRequest

detach_from_network_request = DetachFromNetworkRequest(
    network=4711
)
```

