
# Protection 11

Protection configuration for the Network

## Structure

`Protection11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Delete` | `boolean` | Required | If true, prevents the Network from being deleted | boolean getDelete() | setDelete(boolean delete) |

## Example

```java
import cloud.hetzner.api.models.Protection11;

Protection11 protection11 = new Protection11.Builder(
    false
)
.build();
```

