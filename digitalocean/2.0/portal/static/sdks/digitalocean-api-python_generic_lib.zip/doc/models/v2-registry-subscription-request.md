
# V2 Registry Subscription Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2RegistrySubscriptionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tier_slug` | [`TierSlug`](../../doc/models/tier-slug.md) | Optional | The slug of the subscription tier to sign up for. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.tier_slug import TierSlug
from digitaloceanapi.models.v_2_registry_subscription_request import V2RegistrySubscriptionRequest

v_2_registry_subscription_request = V2RegistrySubscriptionRequest(
    tier_slug=TierSlug.BASIC,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

