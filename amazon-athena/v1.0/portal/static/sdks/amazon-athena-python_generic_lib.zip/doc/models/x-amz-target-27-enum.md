
# X Amz Target 27 Enum

## Enumeration

`XAmzTarget27Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSIONSTATUS` |

## Example

```python
from amazonathena.models.x_amz_target_27_enum import XAmzTarget27Enum

x_amz_target_27 = XAmzTarget27Enum.ENUM_AMAZONATHENAGETSESSIONSTATUS
```

