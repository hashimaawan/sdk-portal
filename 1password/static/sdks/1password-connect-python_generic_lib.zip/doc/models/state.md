
# State

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `ARCHIVED` |
| `DELETED` |

## Example

```python
from m1passwordconnect.models.state import State

state = State.ARCHIVED
```

