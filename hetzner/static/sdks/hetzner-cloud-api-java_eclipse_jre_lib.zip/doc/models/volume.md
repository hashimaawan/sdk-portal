
# Volume

The cost of Volume per GB/month

## Structure

`Volume`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PricePerGbMonth` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - | PricePerGbMonth getPricePerGbMonth() | setPricePerGbMonth(PricePerGbMonth pricePerGbMonth) |

## Example

```java
import cloud.hetzner.api.models.PricePerGbMonth;
import cloud.hetzner.api.models.Volume;

Volume volume = new Volume.Builder(
    new PricePerGbMonth.Builder(
        "1.1900000000000000",
        "1.0000000000"
    )
    .build()
)
.build();
```

