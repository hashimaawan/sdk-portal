
# Type 49 Enum

The type of the Primary IP

## Enumeration

`Type49Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type49 := models.Type49Enum_IPV4

}
```

