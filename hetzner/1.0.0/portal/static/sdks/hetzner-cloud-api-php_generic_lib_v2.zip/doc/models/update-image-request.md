
# Update Image Request

## Structure

`UpdateImageRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `description` | `?string` | Optional | New description of Image | getDescription(): ?string | setDescription(?string description): void |
| `labels` | `?array` | Optional | User-defined labels (key-value pairs) | getLabels(): ?array | setLabels(?array labels): void |
| `type` | [`?string(Type24Enum)`](../../doc/models/type-24-enum.md) | Optional | Destination Image type to convert to | getType(): ?string | setType(?string type): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\UpdateImageRequestBuilder;
use HetznerCloudAPILib\ApiHelper;
use HetznerCloudAPILib\Models\Type24Enum;

$updateImageRequest = UpdateImageRequestBuilder::init()
    ->description('My new Image description')
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->type(Type24Enum::SNAPSHOT)
    ->build();
```

