
# V2 Functions Namespaces Triggers Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `triggers` | [`Trigger[] \| undefined`](../../doc/models/trigger.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FunctionsNamespacesTriggersResponse } from 'digitalocean-apilib';

const v2FunctionsNamespacesTriggersResponse: V2FunctionsNamespacesTriggersResponse = {
  triggers: [
    {
      createdAt: 'created_at8',
      mFunction: 'function6',
      isEnabled: false,
      name: 'name0',
      namespace: 'namespace2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

