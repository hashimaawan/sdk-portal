
# X Amz Target 7

## Enumeration

`XAmzTarget7`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL` |

## Example

```python
from amazonathena.models.x_amz_target_7 import XAmzTarget7

x_amz_target_7 = XAmzTarget7.ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL
```

