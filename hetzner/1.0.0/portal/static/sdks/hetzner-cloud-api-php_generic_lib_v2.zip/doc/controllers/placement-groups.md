# Placement Groups

```php
$placementGroupsController = $client->getPlacementGroupsController();
```

## Class Name

`PlacementGroupsController`

## Methods

* [Get All Placement Groups](../../doc/controllers/placement-groups.md#get-all-placement-groups)
* [Create a Placement Group](../../doc/controllers/placement-groups.md#create-a-placement-group)
* [Delete a Placement Group](../../doc/controllers/placement-groups.md#delete-a-placement-group)
* [Get a Placement Group](../../doc/controllers/placement-groups.md#get-a-placement-group)
* [Update a Placement Group](../../doc/controllers/placement-groups.md#update-a-placement-group)


# Get All Placement Groups

Returns all PlacementGroup objects.

```php
function getAllPlacementGroups(
    ?string $sort = null,
    ?string $name = null,
    ?string $labelSelector = null,
    ?string $type = null
): PlacementGroupsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`?string(SortEnum)`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `?string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `?string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `type` | [`?string(ParameterType1Enum)`](../../doc/models/parameter-type-1-enum.md) | Query, Optional | Can be used multiple times. The response will only contain PlacementGroups matching the type. |

## Response Type

**200**: The `placement_groups` key contains an array of PlacementGroup objects

[`PlacementGroupsResponse`](../../doc/models/placement-groups-response.md)

## Example Usage

```php
$placementGroupsController = $client->getPlacementGroupsController();

try {
    $result = $placementGroupsController->getAllPlacementGroups();
    echo 'PlacementGroupsResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "placement_groups": [
    {
      "created": "2019-01-08T12:10:00+00:00",
      "id": 897,
      "labels": {
        "key": "value"
      },
      "name": "my Placement Group",
      "servers": [
        4711,
        4712
      ],
      "type": "spread"
    }
  ]
}
```


# Create a Placement Group

Creates a new PlacementGroup.

```php
function createAPlacementGroup(?CreatePlacementGroupRequest $body = null): CreatePlacementGroupResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?CreatePlacementGroupRequest`](../../doc/models/create-placement-group-request.md) | Body, Optional | - |

## Response Type

**201**: The `PlacementGroup` key contains the PlacementGroup that was just created.

[`CreatePlacementGroupResponse`](../../doc/models/create-placement-group-response.md)

## Example Usage

```php
$body = CreatePlacementGroupRequestBuilder::init(
    'my Placement Group'
)->build();

$placementGroupsController = $client->getPlacementGroupsController();

try {
    $result = $placementGroupsController->createAPlacementGroup($body);
    echo 'CreatePlacementGroupResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [],
    "type": "spread"
  }
}
```


# Delete a Placement Group

Deletes a PlacementGroup.

```php
function deleteAPlacementGroup(int $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: PlacementGroup deleted

`void`

## Example Usage

```php
$id = 112;

$placementGroupsController = $client->getPlacementGroupsController();

try {
    $placementGroupsController->deleteAPlacementGroup($id);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get a Placement Group

Gets a specific PlacementGroup object.

```php
function getAPlacementGroup(int $id): PlacementGroupResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `placement_group` key contains a PlacementGroup object

[`PlacementGroupResponse`](../../doc/models/placement-group-response.md)

## Example Usage

```php
$id = 112;

$placementGroupsController = $client->getPlacementGroupsController();

try {
    $result = $placementGroupsController->getAPlacementGroup($id);
    echo 'PlacementGroupResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```


# Update a Placement Group

Updates the PlacementGroup properties.

Note that when updating labels, the PlacementGroup’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the PlacementGroup object changes during the request, the response will be a “conflict” error.

```php
function updateAPlacementGroup(int $id, ?UpdatePlacementGroupRequest $body = null): PlacementGroupResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`?UpdatePlacementGroupRequest`](../../doc/models/update-placement-group-request.md) | Body, Optional | - |

## Response Type

**200**: The `certificate` key contains the PlacementGroup that was just updated

[`PlacementGroupResponse`](../../doc/models/placement-group-response.md)

## Example Usage

```php
$id = 112;

$body = UpdatePlacementGroupRequestBuilder::init()
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('my Placement Group')
    ->build();

$placementGroupsController = $client->getPlacementGroupsController();

try {
    $result = $placementGroupsController->updateAPlacementGroup(
        $id,
        $body
    );
    echo 'PlacementGroupResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```

