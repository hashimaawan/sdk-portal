
# Work Group State 3 Enum

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ruby
work_group_state3 = WorkGroupState3Enum::ENABLED
```

