
# Narrator Object

*This model accepts additional fields of type Any.*

## Structure

`NarratorObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | The name of the Narrator. |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from spotifywebapiwithfixesandimprovementsfromsonallux.models.narrator_object import NarratorObject

narrator_object = NarratorObject(
    name='name4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

