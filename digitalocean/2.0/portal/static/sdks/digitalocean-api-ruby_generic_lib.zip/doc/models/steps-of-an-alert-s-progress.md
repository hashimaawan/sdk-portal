
# Steps of an Alert S Progress

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`StepsOfAnAlertSProgress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ended_at` | `DateTime` | Optional | - |
| `name` | `String` | Optional | - |
| `reason` | [`Reason`](../../doc/models/reason.md) | Optional | - |
| `started_at` | `DateTime` | Optional | - |
| `status` | [`Status2`](../../doc/models/status-2.md) | Optional | **Default**: `Status2::UNKNOWN` |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
steps_of_an_alert_s_progress = StepsOfAnAlertSProgress.new(
  ended_at: DateTimeHelper.from_rfc3339('2020-11-19T20:27:18Z'),
  name: 'example_step',
  reason: Reason.new(
    code: 'code2',
    message: 'message4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  started_at: DateTimeHelper.from_rfc3339('2020-11-19T20:27:18Z'),
  status: Status2::SUCCESS,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

