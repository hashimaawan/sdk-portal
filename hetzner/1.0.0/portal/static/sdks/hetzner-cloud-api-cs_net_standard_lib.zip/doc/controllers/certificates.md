# Certificates

TLS/SSL Certificates prove the identity of a Server and are used to encrypt client traffic.

```csharp
CertificatesController certificatesController = client.CertificatesController;
```

## Class Name

`CertificatesController`

## Methods

* [Get All Certificates](../../doc/controllers/certificates.md#get-all-certificates)
* [Create a Certificate](../../doc/controllers/certificates.md#create-a-certificate)
* [Delete a Certificate](../../doc/controllers/certificates.md#delete-a-certificate)
* [Get a Certificate](../../doc/controllers/certificates.md#get-a-certificate)
* [Update a Certificate](../../doc/controllers/certificates.md#update-a-certificate)


# Get All Certificates

Returns all Certificate objects.

```csharp
GetAllCertificatesAsync(
    Models.SortEnum? sort = null,
    string name = null,
    string labelSelector = null,
    Models.ParameterTypeEnum? type = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`SortEnum?`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `type` | [`ParameterTypeEnum?`](../../doc/models/parameter-type-enum.md) | Query, Optional | Can be used multiple times. The response will only contain Certificates matching the type. |

## Response Type

**200**: The `certificates` key contains an array of Certificate objects

[`Task<Models.CertificatesResponse>`](../../doc/models/certificates-response.md)

## Example Usage

```csharp
try
{
    CertificatesResponse result = await certificatesController.GetAllCertificatesAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "certificates": [
    {
      "certificate": "-----BEGIN CERTIFICATE-----\n...",
      "created": "2019-01-08T12:10:00+00:00",
      "domain_names": [
        "example.com",
        "webmail.example.com",
        "www.example.com"
      ],
      "fingerprint": "03:c7:55:9b:2a:d1:04:17:09:f6:d0:7f:18:34:63:d4:3e:5f",
      "id": 897,
      "labels": {
        "env": "dev"
      },
      "name": "my website cert",
      "not_valid_after": "2019-07-08T09:59:59+00:00",
      "not_valid_before": "2019-01-08T10:00:00+00:00",
      "status": null,
      "type": "uploaded",
      "used_by": [
        {
          "id": 4711,
          "type": "load_balancer"
        }
      ]
    }
  ]
}
```


# Create a Certificate

Creates a new Certificate.

The default type **uploaded** allows for uploading your existing `certificate` and `private_key` in PEM format. You have to monitor its expiration date and handle renewal yourself.

In contrast, type **managed** requests a new Certificate from *Let's Encrypt* for the specified `domain_names`. Only domains managed by *Hetzner DNS* are supported. We handle renewal and timely alert the project owner via email if problems occur.

For type `managed` Certificates the `action` key of the response contains the Action that allows for tracking the issuance process. For type `uploaded` Certificates the `action` is always null.

```csharp
CreateACertificateAsync(
    Models.CreateCertificateRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateCertificateRequest`](../../doc/models/create-certificate-request.md) | Body, Optional | - |

## Response Type

**201**: The `certificate` key contains the Certificate that was just created. For type `managed` Certificates the `action` key contains the Action that allows for tracking the issuance process. For type `uploaded` Certificates the `action` is always null.

[`Task<Models.CreateCertificateResponse>`](../../doc/models/create-certificate-response.md)

## Example Usage

```csharp
CreateCertificateRequest body = new CreateCertificateRequest
{
    Name = "my website cert",
    DomainNames = new List<string>
    {
        "example.com",
        "webmail.example.com",
        "www.example.com",
    },
    Type = Type1Enum.Managed,
};

try
{
    CreateCertificateResponse result = await certificatesController.CreateACertificateAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_certificate",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 879,
        "type": "certificate"
      }
    ],
    "started": "2019-01-08T12:10:00+00:00",
    "status": "running"
  },
  "certificate": {
    "certificate": null,
    "created": "2019-01-08T12:10:00+00:00",
    "domain_names": [
      "example.com",
      "webmail.example.com",
      "www.example.com"
    ],
    "fingerprint": null,
    "id": 897,
    "labels": {
      "env": "dev"
    },
    "name": "my website cert",
    "not_valid_after": null,
    "not_valid_before": null,
    "status": {
      "error": null,
      "issuance": "pending",
      "renewal": "unavailable"
    },
    "type": "managed",
    "used_by": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ]
  }
}
```


# Delete a Certificate

Deletes a Certificate.

```csharp
DeleteACertificateAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Certificate deleted

`Task`

## Example Usage

```csharp
int id = 112;
try
{
    await certificatesController.DeleteACertificateAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Certificate

Gets a specific Certificate object.

```csharp
GetACertificateAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `certificate` key contains a Certificate object

[`Task<Models.CertificateResponse>`](../../doc/models/certificate-response.md)

## Example Usage

```csharp
int id = 112;
try
{
    CertificateResponse result = await certificatesController.GetACertificateAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "certificate": {
    "certificate": "-----BEGIN CERTIFICATE-----\n...",
    "created": "2019-01-08T12:10:00+00:00",
    "domain_names": [
      "example.com",
      "webmail.example.com",
      "www.example.com"
    ],
    "fingerprint": "03:c7:55:9b:2a:d1:04:17:09:f6:d0:7f:18:34:63:d4:3e:5f",
    "id": 897,
    "labels": {
      "env": "dev"
    },
    "name": "my website cert",
    "not_valid_after": "2019-07-08T09:59:59+00:00",
    "not_valid_before": "2019-01-08T10:00:00+00:00",
    "status": null,
    "type": "uploaded",
    "used_by": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ]
  }
}
```


# Update a Certificate

Updates the Certificate properties.

Note that when updating labels, the Certificate’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the Certificate object changes during the request, the response will be a “conflict” error.

```csharp
UpdateACertificateAsync(
    int id,
    Models.UpdateCertificateRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`UpdateCertificateRequest`](../../doc/models/update-certificate-request.md) | Body, Optional | - |

## Response Type

**200**: The `certificate` key contains the Certificate that was just updated

[`Task<Models.CertificateResponse>`](../../doc/models/certificate-response.md)

## Example Usage

```csharp
int id = 112;
UpdateCertificateRequest body = new UpdateCertificateRequest
{
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "my website cert",
};

try
{
    CertificateResponse result = await certificatesController.UpdateACertificateAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "certificate": {
    "certificate": "-----BEGIN CERTIFICATE-----\n...",
    "created": "2019-01-08T12:10:00+00:00",
    "domain_names": [
      "example.com",
      "webmail.example.com",
      "www.example.com"
    ],
    "fingerprint": "03:c7:55:9b:2a:d1:04:17:09:f6:d0:7f:18:34:63:d4:3e:5f",
    "id": 897,
    "labels": {
      "labelkey": "value"
    },
    "name": "my website cert",
    "not_valid_after": "2019-07-08T09:59:59+00:00",
    "not_valid_before": "2019-01-08T10:00:00+00:00",
    "status": null,
    "type": "uploaded",
    "used_by": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ]
  }
}
```

