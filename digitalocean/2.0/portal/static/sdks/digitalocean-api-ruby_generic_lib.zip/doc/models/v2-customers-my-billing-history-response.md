
# V2 Customers My Billing History Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2CustomersMyBillingHistoryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `billing_history` | [`Array[BillingHistory]`](../../doc/models/billing-history.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta1`](../../doc/models/meta-1.md) | Required | Information about the response itself. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_customers_my_billing_history_response = V2CustomersMyBillingHistoryResponse.new(
  meta: Meta1.new(
    total: 5,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  billing_history: [
    BillingHistory.new(
      amount: '12.34',
      date: DateTimeHelper.from_rfc3339('2018-06-01T08:44:38Z'),
      description: 'Invoice for May 2018',
      invoice_id: '123',
      invoice_uuid: 'example-uuid',
      type: Type6::INVOICE,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    BillingHistory.new(
      amount: '-12.34',
      date: DateTimeHelper.from_rfc3339('2018-06-02T08:44:38Z'),
      description: 'Payment (MC 2018)',
      invoice_id: 'invoice_id6',
      invoice_uuid: 'invoice_uuid4',
      type: Type6::PAYMENT,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'https://api.digitalocean.com/v2/customers/my/billing_history?page=3&per_page=2',
      mnext: 'https://api.digitalocean.com/v2/customers/my/billing_history?page=2&per_page=2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

