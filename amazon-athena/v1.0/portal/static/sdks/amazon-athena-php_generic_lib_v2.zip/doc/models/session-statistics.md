
# Session Statistics

Contains statistics for a session.

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dpuExecutionInMillis` | `?int` | Optional | - | getDpuExecutionInMillis(): ?int | setDpuExecutionInMillis(?int dpuExecutionInMillis): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\SessionStatisticsBuilder;

$sessionStatistics = SessionStatisticsBuilder::init()
    ->dpuExecutionInMillis(188)
    ->build();
```

