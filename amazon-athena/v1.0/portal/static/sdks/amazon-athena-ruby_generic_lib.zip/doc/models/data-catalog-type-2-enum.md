
# Data Catalog Type 2 Enum

The data catalog type.

## Enumeration

`DataCatalogType2Enum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```ruby
data_catalog_type2 = DataCatalogType2Enum::GLUE
```

