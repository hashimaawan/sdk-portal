
# Work Group State 1 Enum

The state of the workgroup.

## Enumeration

`WorkGroupState1Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ruby
work_group_state1 = WorkGroupState1Enum::ENABLED
```

