# Pricing

Returns prices for resources.

```php
$pricingApi = $client->getPricingApi();
```

## Class Name

`PricingApi`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```php
function getAllPrices(): ApiResponse
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`PricingResponse`](../../doc/models/pricing-response.md).

## Example Usage

```php
$pricingApi = $client->getPricingApi();
$apiResponse = $pricingApi->getAllPrices();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'PricingResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

