
# Data Catalog

<p>Contains information about a data catalog in an Amazon Web Services account.</p> <note> <p>In the Athena console, data catalogs are listed as "data sources" on the <b>Data sources</b> page under the <b>Data source name</b> column.</p> </note>


## Structure

`DataCatalog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Type` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

DataCatalog dataCatalog = new DataCatalog
{
    Name = "Name6",
    Type = DataCatalogType1Enum.GLUE,
    Description = "Description0",
    Parameters = new Parameters
    {
    },
};
```

