
# Scope

- RUN_TIME: Made available only at run-time
- BUILD_TIME: Made available only at build-time
- RUN_AND_BUILD_TIME: Made available at both build and run-time

## Enumeration

`Scope`

## Fields

| Name |
|  --- |
| `Unset` |
| `RunTime` |
| `BuildTime` |
| `RunAndBuildTime` |

## Example

```ts
import { Scope } from 'digitalocean-apilib';

const scope = Scope.BuildTime;
```

