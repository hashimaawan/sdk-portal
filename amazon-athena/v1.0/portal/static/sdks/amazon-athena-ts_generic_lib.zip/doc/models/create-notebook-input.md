
# Create Notebook Input

## Structure

`CreateNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `clientRequestToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```ts
import { CreateNotebookInput } from 'amazon-athenalib';

const createNotebookInput: CreateNotebookInput = {
  workGroup: 'WorkGroup2',
  name: 'Name0',
  clientRequestToken: 'ClientRequestToken4',
};
```

