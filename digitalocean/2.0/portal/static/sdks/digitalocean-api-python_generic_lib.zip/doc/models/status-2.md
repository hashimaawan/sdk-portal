
# Status 2

## Enumeration

`Status2`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING` |
| `RUNNING` |
| `ERROR` |
| `SUCCESS` |

## Example

```python
from digitaloceanapi.models.status_2 import Status2

status_2 = Status2.SUCCESS
```

