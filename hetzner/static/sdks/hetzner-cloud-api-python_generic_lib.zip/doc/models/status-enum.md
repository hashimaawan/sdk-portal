
# Status Enum

Status of the Action

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ERROR` |

## Example

```python
from hetznercloudapi.models.status_enum import StatusEnum

status = StatusEnum.ERROR
```

