
# V2 Account Keys Response 1

*This model accepts additional fields of type Object.*

## Structure

`V2AccountKeysResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SshKey` | [`SshKey`](../../doc/models/ssh-key.md) | Optional | - | SshKey getSshKey() | setSshKey(SshKey sshKey) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.SshKey;
import com.digitalocean.api.models.V2AccountKeysResponse1;
import java.io.IOException;

V2AccountKeysResponse1 v2AccountKeysResponse1 = new V2AccountKeysResponse1.Builder()
    .sshKey(new SshKey.Builder(
        "name2",
        "public_key4"
    )
    .fingerprint("fingerprint8")
    .id(204)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

