
# List Tags for Resource Input

## Structure

`ListTagsForResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resourceARN` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 75` |

## Example

```ts
import { ListTagsForResourceInput } from 'amazon-athenalib';

const listTagsForResourceInput: ListTagsForResourceInput = {
  resourceARN: 'ResourceARN0',
  nextToken: 'NextToken0',
  maxResults: 76,
};
```

