
# Too Many Requests Exception

*This model accepts additional fields of type Object.*

## Structure

`TooManyRequestsException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`ErrorObject`](../../doc/models/error-object.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue TooManyRequestsException => e
  puts "Caught TooManyRequestsException: #{e.message}"
end
```

