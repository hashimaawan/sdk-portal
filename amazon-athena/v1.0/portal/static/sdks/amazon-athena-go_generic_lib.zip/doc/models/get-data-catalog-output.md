
# Get Data Catalog Output

*This model accepts additional fields of type interface{}.*

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DataCatalog` | [`*models.DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    getDataCatalogOutput := models.GetDataCatalogOutput{
        DataCatalog:           models.ToPointer(models.DataCatalog2{
            Name:                  "Name4",
            Description:           models.ToPointer("Description2"),
            Type:                  models.DataCatalogType1_Glue,
            Parameters:            models.ToPointer(models.Parameters{
                AdditionalProperties:  map[string]string{
                    "exampleAdditionalProperty": "Parameters_additionalProperties2",
                },
            }),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

