
# Item Type

## Enumeration

`ItemType`

## Fields

| Name |
|  --- |
| `Album` |
| `Artist` |
| `Playlist` |
| `Track` |
| `Show` |
| `Episode` |
| `Audiobook` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

ItemType itemType = ItemType.Artist;
```

