
# Notebook Type Enum

## Enumeration

`NotebookTypeEnum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```ts
import { NotebookTypeEnum } from 'amazon-athenalib';

const notebookType = NotebookTypeEnum.IPYNB;
```

