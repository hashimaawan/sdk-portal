
# Query Runtime Statistics Rows

Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query.

## Structure

`QueryRuntimeStatisticsRows`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InputRows` | `int?` | Optional | - |
| `InputBytes` | `int?` | Optional | - |
| `OutputBytes` | `int?` | Optional | - |
| `OutputRows` | `int?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryRuntimeStatisticsRows queryRuntimeStatisticsRows = new QueryRuntimeStatisticsRows
{
    InputRows = 234,
    InputBytes = 254,
    OutputBytes = 40,
    OutputRows = 226,
};
```

