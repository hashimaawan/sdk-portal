
# Diagnostic

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Diagnostic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkName` | `string \| undefined` | Optional | The clusterlint check that resulted in the diagnostic. |
| `message` | `string \| undefined` | Optional | Feedback about the object for users to fix. |
| `object` | [`Object \| undefined`](../../doc/models/object.md) | Optional | Metadata about the Kubernetes API object the diagnostic is reported on. |
| `severity` | `string \| undefined` | Optional | Can be one of error, warning or suggestion. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Diagnostic } from 'digitalocean-apilib';

const diagnostic: Diagnostic = {
  checkName: 'unused-config-map',
  message: 'Unused config map',
  object: {
    kind: 'kind0',
    name: 'name2',
    namespace: 'namespace0',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  severity: 'warning',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

