
# V2 Vpcs Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2VpcsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `vpc` | [`?Vpc`](../../doc/models/vpc.md) | Optional | - | getVpc(): ?Vpc | setVpc(?Vpc vpc): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2VpcsResponse1Builder;
use DigitalOceanApiLib\Models\Builders\VpcBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2VpcsResponse1 = V2VpcsResponse1Builder::init()
    ->vpc(
        VpcBuilder::init()
            ->description('description8')
            ->name('name2')
            ->ipRange('ip_range4')
            ->region('region8')
            ->default(false)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

