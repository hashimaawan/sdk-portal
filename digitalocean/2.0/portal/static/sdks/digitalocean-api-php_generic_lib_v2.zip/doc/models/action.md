
# Action

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Action`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `completedAt` | `?DateTime` | Optional | A time value given in ISO8601 combined date and time format that represents when the action was completed. | getCompletedAt(): ?\DateTime | setCompletedAt(?\DateTime completedAt): void |
| `id` | `?int` | Optional | A unique numeric ID that can be used to identify and reference an action. | getId(): ?int | setId(?int id): void |
| `region` | [`?Region`](../../doc/models/region.md) | Optional | - | getRegion(): ?Region | setRegion(?Region region): void |
| `regionSlug` | `?string` | Optional | - | getRegionSlug(): ?string | setRegionSlug(?string regionSlug): void |
| `resourceId` | `?int` | Optional | A unique identifier for the resource that the action is associated with. | getResourceId(): ?int | setResourceId(?int resourceId): void |
| `resourceType` | `?string` | Optional | The type of resource that the action is associated with. | getResourceType(): ?string | setResourceType(?string resourceType): void |
| `startedAt` | `?DateTime` | Optional | A time value given in ISO8601 combined date and time format that represents when the action was initiated. | getStartedAt(): ?\DateTime | setStartedAt(?\DateTime startedAt): void |
| `status` | [`?string(Status1)`](../../doc/models/status-1.md) | Optional | The current status of the action. This can be "in-progress", "completed", or "errored".<br><br>**Default**: `Status1::INPROGRESS` | getStatus(): ?string | setStatus(?string status): void |
| `type` | `?string` | Optional | This is the type of action that the object represents. For example, this could be "transfer" to represent the state of an image transfer action. | getType(): ?string | setType(?string type): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\ActionBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\Models\Builders\RegionBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Status1;

$action = ActionBuilder::init()
    ->completedAt(DateTimeHelper::fromRfc3339DateTime('2020-11-14T16:30:06Z'))
    ->id(36804636)
    ->region(
        RegionBuilder::init(
            false,
            [
                'features7',
                'features8',
                'features9'
            ],
            'name6',
            [
                'sizes6'
            ],
            'slug0'
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->regionSlug('region_slug0')
    ->resourceId(3164444)
    ->resourceType('droplet')
    ->startedAt(DateTimeHelper::fromRfc3339DateTime('2020-11-14T16:29:21Z'))
    ->status(Status1::COMPLETED)
    ->type('create')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

