
# Get Calculation Execution Status Request

*This model accepts additional fields of type unknown.*

## Structure

`GetCalculationExecutionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetCalculationExecutionStatusRequest } from 'amazon-athenalib';

const getCalculationExecutionStatusRequest: GetCalculationExecutionStatusRequest = {
  calculationExecutionId: 'CalculationExecutionId8',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

