
# Get Named Query Input

## Structure

`GetNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getNamedQueryInput := models.GetNamedQueryInput{
        NamedQueryId:         "NamedQueryId8",
    }

}
```

