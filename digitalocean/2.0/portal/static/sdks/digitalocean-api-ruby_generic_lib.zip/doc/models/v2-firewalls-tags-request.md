
# V2 Firewalls Tags Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FirewallsTagsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | `Array[String]` | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_firewalls_tags_request = V2FirewallsTagsRequest.new(
  tags: [
    'tags5',
    'tags6',
    'tags7'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

