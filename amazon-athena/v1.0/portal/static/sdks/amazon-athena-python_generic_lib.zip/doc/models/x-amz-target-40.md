
# X Amz Target 40

## Enumeration

`XAmzTarget40`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```python
from amazonathena.models.x_amz_target_40 import XAmzTarget40

x_amz_target_40 = XAmzTarget40.ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS
```

