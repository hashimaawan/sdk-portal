
# X Amz Target 59

## Enumeration

`XAmzTarget59`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateWorkGroup` |

## Example

```ts
import { XAmzTarget59 } from 'amazon-athenalib';

const xAmzTarget59 = XAmzTarget59.EnumAmazonAthenaUpdateWorkGroup;
```

