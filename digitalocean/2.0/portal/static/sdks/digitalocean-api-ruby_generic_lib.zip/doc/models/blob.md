
# Blob

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Blob`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `compressed_size_bytes` | `Integer` | Optional | The compressed size of the blob in bytes. |
| `digest` | `String` | Optional | The digest of the blob |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
blob = Blob.new(
  compressed_size_bytes: 2803255,
  digest: 'sha256:cb8a924afdf0229ef7515d9e5b3024e23b3eb03ddbba287f4a19c6ac90b8d221',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

