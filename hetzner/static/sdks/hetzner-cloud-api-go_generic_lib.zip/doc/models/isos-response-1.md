
# Isos Response 1

## Structure

`IsosResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Iso` | [`models.Iso`](../../doc/models/iso.md) | Required | - |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    isosResponse1 := models.IsosResponse1{
        Iso:                  models.Iso{
            Deprecated:           models.ToPointer("2018-02-28T00:00:00+00:00"),
            Description:          "FreeBSD 11.0 x64",
            Id:                   42,
            Name:                 models.ToPointer("FreeBSD-11.0-RELEASE-amd64-dvd1"),
            Type:                 models.Type26Enum_PUBLIC,
        },
    }

}
```

