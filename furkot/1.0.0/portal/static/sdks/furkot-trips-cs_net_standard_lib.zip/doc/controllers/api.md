# API

```csharp
Api api = client.Api;
```

## Class Name

`Api`

## Methods

* [Trip GET](../../doc/controllers/api.md#trip-get)
* [Trip Stop by Trip Id GET](../../doc/controllers/api.md#trip-stop-by-trip-id-get)


# Trip GET

list user's trips

```csharp
TripGetAsync()
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [List<Models.Trip>](../../doc/models/trip.md).

## Example Usage

```csharp
try
{
    ApiResponse<List<Trip>> result = await api.TripGetAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Trip Stop by Trip Id GET

list stops for a trip identified by {trip_id}

```csharp
TripStopByTripIdGetAsync(
    string tripId)
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tripId` | `string` | Template, Required | id of the trip |

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [List<Models.Step>](../../doc/models/step.md).

## Example Usage

```csharp
string tripId = "trip_id2";
try
{
    ApiResponse<List<Step>> result = await api.TripStopByTripIdGetAsync(tripId);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

