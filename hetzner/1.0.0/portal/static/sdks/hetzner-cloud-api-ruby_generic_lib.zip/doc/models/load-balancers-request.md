
# Load Balancers Request

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New Load Balancer name |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
load_balancers_request = LoadBalancersRequest.new(
  labels: { 'labelkey' => 'value' },
  name: 'new-name',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

