
# X Amz Target 36 Enum

## Enumeration

`XAmzTarget36Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListExecutors` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget36Enum xAmzTarget36 = XAmzTarget36Enum.EnumAmazonAthenaListExecutors;
```

