
# X Amz Target 41

## Enumeration

`XAmzTarget41`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistqueryexecutions` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget41 := models.XAmzTarget41_EnumAmazonathenalistqueryexecutions

}
```

