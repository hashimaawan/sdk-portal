
# Executor State Enum

## Enumeration

`ExecutorStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```php
use AmazonAthenaLib\Models\ExecutorStateEnum;

$executorState = ExecutorStateEnum::TERMINATED;
```

