
# Price 9

*This model accepts additional fields of type interface{}.*

## Structure

`Price9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Location` | `string` | Required | Name of the Location the price is for |
| `PriceHourly` | [`models.PriceHourly8`](../../doc/models/price-hourly-8.md) | Required | Hourly costs for a Server type in this Location |
| `PriceMonthly` | [`models.PriceMonthly10`](../../doc/models/price-monthly-10.md) | Required | Monthly costs for a Server type in this Location |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    price9 := models.Price9{
        Location:              "fsn1",
        PriceHourly:           models.PriceHourly8{
            Gross:                 "1.1900000000000000",
            Net:                   "1.0000000000",
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        },
        PriceMonthly:          models.PriceMonthly10{
            Gross:                 "1.1900000000000000",
            Net:                   "1.0000000000",
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

