
# Status 16

## Enumeration

`Status16`

## Fields

| Name |
|  --- |
| `DOWN` |
| `UP` |
| `CHECKING` |

## Example

```python
from digitaloceanapi.models.status_16 import Status16

status_16 = Status16.UP
```

