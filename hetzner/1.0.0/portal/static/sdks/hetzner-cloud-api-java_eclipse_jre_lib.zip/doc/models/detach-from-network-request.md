
# Detach from Network Request

*This model accepts additional fields of type Object.*

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Network` | `int` | Required | ID of an existing network to detach the Server from | int getNetwork() | setNetwork(int network) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.DetachFromNetworkRequest;
import java.io.IOException;

DetachFromNetworkRequest detachFromNetworkRequest = new DetachFromNetworkRequest.Builder(
    4711
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

