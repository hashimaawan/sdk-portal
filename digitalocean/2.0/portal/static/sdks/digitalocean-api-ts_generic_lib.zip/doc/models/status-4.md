
# Status 4

A string representing the current status of the database cluster.

## Enumeration

`Status4`

## Fields

| Name |
|  --- |
| `Creating` |
| `Online` |
| `Resizing` |
| `Migrating` |
| `Forking` |

## Example

```ts
import { Status4 } from 'digitalocean-apilib';

const status4 = Status4.Resizing;
```

