
# Update Volume Request

## Structure

`UpdateVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Required | New Volume name |

## Example

```ruby
update_volume_request = UpdateVolumeRequest.new(
  'database-storage',
  Labels2.new(
    'labelkey4'
  )
)
```

