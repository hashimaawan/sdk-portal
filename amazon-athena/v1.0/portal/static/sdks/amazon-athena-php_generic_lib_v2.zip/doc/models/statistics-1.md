
# Statistics 1

## Structure

`Statistics1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dpuExecutionInMillis` | `?int` | Optional | - | getDpuExecutionInMillis(): ?int | setDpuExecutionInMillis(?int dpuExecutionInMillis): void |
| `progress` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getProgress(): ?string | setProgress(?string progress): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\Statistics1Builder;

$statistics1 = Statistics1Builder::init()
    ->dpuExecutionInMillis(148)
    ->progress('Progress4')
    ->build();
```

