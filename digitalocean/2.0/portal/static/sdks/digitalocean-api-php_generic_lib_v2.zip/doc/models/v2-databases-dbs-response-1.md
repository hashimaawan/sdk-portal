
# V2 Databases Dbs Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesDbsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `db` | [`Db`](../../doc/models/db.md) | Required | - | getDb(): Db | setDb(Db db): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesDbsResponse1Builder;
use DigitalOceanApiLib\Models\Builders\DbBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesDbsResponse1 = V2DatabasesDbsResponse1Builder::init(
    DbBuilder::init(
        'alpha'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

