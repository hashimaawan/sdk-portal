
# Many Genres

*This model accepts additional fields of type Any.*

## Structure

`ManyGenres`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `genres` | `List[str]` | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from spotifywebapiwithfixesandimprovementsfromsonallux.models.many_genres import ManyGenres

many_genres = ManyGenres(
    genres=[
        'alternative',
        'samba'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

