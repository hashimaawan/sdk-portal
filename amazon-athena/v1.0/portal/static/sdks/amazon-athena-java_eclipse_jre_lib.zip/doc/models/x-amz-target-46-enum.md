
# X Amz Target 46 Enum

## Enumeration

`XAmzTarget46Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget46Enum;

XAmzTarget46Enum xAmzTarget46 = XAmzTarget46Enum.ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION;
```

