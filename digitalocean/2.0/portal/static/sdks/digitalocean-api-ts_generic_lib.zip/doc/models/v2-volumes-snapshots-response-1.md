
# V2 Volumes Snapshots Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2VolumesSnapshotsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `snapshots` | [`Snapshot[] \| undefined`](../../doc/models/snapshot.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  ResourceType1,
  V2VolumesSnapshotsResponse1,
} from 'digitalocean-apilib';

const v2VolumesSnapshotsResponse1: V2VolumesSnapshotsResponse1 = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  snapshots: [
    {
      id: '8eb4d51a-873f-11e6-96bf-000f53315a41',
      createdAt: '2020-09-30T18:56:12Z',
      minDiskSize: 10,
      name: 'big-data-snapshot1475261752',
      regions: [
        'nyc1'
      ],
      sizeGigabytes: 0,
      resourceId: '82a48a18-873f-11e6-96bf-000f53315a41',
      resourceType: ResourceType1.Volume,
      tags: null,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

