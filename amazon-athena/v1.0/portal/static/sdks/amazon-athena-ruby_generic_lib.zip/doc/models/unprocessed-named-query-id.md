
# Unprocessed Named Query Id

Information about a named query ID that could not be processed.

## Structure

`UnprocessedNamedQueryId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `error_code` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `error_message` | `String` | Optional | - |

## Example

```ruby
unprocessed_named_query_id = UnprocessedNamedQueryId.new(
  'NamedQueryId8',
  'ErrorCode6',
  'ErrorMessage6'
)
```

