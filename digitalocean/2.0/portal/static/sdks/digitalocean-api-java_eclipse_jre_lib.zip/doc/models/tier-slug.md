
# Tier Slug

The slug of the subscription tier to sign up for.

## Enumeration

`TierSlug`

## Fields

| Name |
|  --- |
| `STARTER` |
| `BASIC` |
| `PROFESSIONAL` |

## Example

```java
import com.digitalocean.api.models.TierSlug;

TierSlug tierSlug = TierSlug.PROFESSIONAL;
```

