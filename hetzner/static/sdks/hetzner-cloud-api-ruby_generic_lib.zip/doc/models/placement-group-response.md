
# Placement Group Response

## Structure

`PlacementGroupResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placement_group` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - |

## Example

```ruby
placement_group_response = PlacementGroupResponse.new(
  PlacementGroup.new(
    '2016-01-30T23:55:00+00:00',
    42,
    {
      'key0': 'labels4'
    },
    'my-resource',
    [
      42
    ],
    'spread'
  )
)
```

