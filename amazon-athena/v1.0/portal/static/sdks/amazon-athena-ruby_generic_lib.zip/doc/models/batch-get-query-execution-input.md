
# Batch Get Query Execution Input

Contains an array of query execution IDs.

## Structure

`BatchGetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_ids` | `Array[String]` | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ruby
batch_get_query_execution_input = BatchGetQueryExecutionInput.new(
  [
    'QueryExecutionIds7'
  ]
)
```

