# Firewalls

Firewalls can limit the network access to or from your resources.

* When applying a firewall with no `in` rule all inbound traffic will be dropped. The default for `in` is `DROP`.
* When applying a firewall with no `out` rule all outbound traffic will be accepted. The default for `out` is `ACCEPT`.

```java
FirewallsApi firewallsApi = client.getFirewallsApi();
```

## Class Name

`FirewallsApi`

## Methods

* [Get All Firewalls](../../doc/controllers/firewalls.md#get-all-firewalls)
* [Create a Firewall](../../doc/controllers/firewalls.md#create-a-firewall)
* [Delete a Firewall](../../doc/controllers/firewalls.md#delete-a-firewall)
* [Get a Firewall](../../doc/controllers/firewalls.md#get-a-firewall)
* [Update a Firewall](../../doc/controllers/firewalls.md#update-a-firewall)


# Get All Firewalls

Returns all Firewall objects.

```java
CompletableFuture<ApiResponse<FirewallsResponse>> getAllFirewallsAsync(
    final Sort sort,
    final String name,
    final String labelSelector)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`Sort`](../../doc/models/sort.md) | Query, Optional | Can be used multiple times. |
| `name` | `String` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `String` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `firewalls` key contains an array of Firewall objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`FirewallsResponse`](../../doc/models/firewalls-response.md).

## Example Usage

```java
firewallsApi.getAllFirewallsAsync(null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Create a Firewall

Creates a new Firewall.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_already_added`        | Server added more than one time to resource                   |
| `incompatible_network_type`   | The Network type is incompatible for the given resource       |
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```java
CompletableFuture<ApiResponse<CreateFirewallResponse>> createAFirewallAsync(
    final CreateFirewallRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateFirewallRequest`](../../doc/models/create-firewall-request.md) | Body, Optional | - |

## Response Type

**201**: The `firewall` key contains the Firewall that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`CreateFirewallResponse`](../../doc/models/create-firewall-response.md).

## Example Usage

```java
CreateFirewallRequest body = new CreateFirewallRequest.Builder(
    "Corporate Intranet Protection"
)
.applyTo(Arrays.asList(
        new ApplyTo.Builder(
            Type7.SERVER
        )
        .server(new Server2.Builder(
                42
            )
            .build())
        .build()
    ))
.labels(ApiHelper.deserialize("{\"env\":\"dev\"}"))
.rules(Arrays.asList(
        new Rule.Builder(
            Direction.IN,
            Protocol.TCP
        )
        .description("Allow port 80")
        .port("80")
        .sourceIps(Arrays.asList(
                "28.239.13.1/32",
                "28.239.14.0/24",
                "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128"
            ))
        .build()
    ))
.build();

firewallsApi.createAFirewallAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Delete a Firewall

Deletes a Firewall.

#### Call specific error codes

| Code                 | Description                               |
|--------------------- |-------------------------------------------|
| `resource_in_use`    | Firewall must not be in use to be deleted |

```java
CompletableFuture<ApiResponse<Void>> deleteAFirewallAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Firewall deleted

`void`

## Example Usage

```java
int id = 112;

firewallsApi.deleteAFirewallAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a Firewall

Gets a specific Firewall object.

```java
CompletableFuture<ApiResponse<FirewallResponse>> getAFirewallAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `firewall` key contains a Firewall object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`FirewallResponse`](../../doc/models/firewall-response.md).

## Example Usage

```java
int id = 112;

firewallsApi.getAFirewallAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Update a Firewall

Updates the Firewall.

Note that when updating labels, the Firewall's current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the Firewall object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ApiResponse<FirewallResponse>> updateAFirewallAsync(
    final int id,
    final UpdateFirewallRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`UpdateFirewallRequest`](../../doc/models/update-firewall-request.md) | Body, Optional | - |

## Response Type

**200**: The `firewall` key contains the Firewall that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`FirewallResponse`](../../doc/models/firewall-response.md).

## Example Usage

```java
int id = 112;
UpdateFirewallRequest body = new UpdateFirewallRequest.Builder()
    .labels(ApiHelper.deserialize("{\"labelkey\":\"value\"}"))
    .name("new-name")
    .build();

firewallsApi.updateAFirewallAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

