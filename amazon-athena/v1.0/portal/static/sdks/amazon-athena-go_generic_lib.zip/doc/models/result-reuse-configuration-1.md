
# Result Reuse Configuration 1

## Structure

`ResultReuseConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResultReuseByAgeConfiguration` | [`*models.ResultReuseByAgeConfiguration2`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    resultReuseConfiguration1 := models.ResultReuseConfiguration1{
        ResultReuseByAgeConfiguration: models.ToPointer(models.ResultReuseByAgeConfiguration2{
            Enabled:              false,
            MaxAgeInMinutes:      models.ToPointer(26),
        }),
    }

}
```

