
# Status

Status of the Action

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ERROR` |

## Example

```php
use HetznerCloudApiLib\Models\Status;

$status = Status::ERROR;
```

