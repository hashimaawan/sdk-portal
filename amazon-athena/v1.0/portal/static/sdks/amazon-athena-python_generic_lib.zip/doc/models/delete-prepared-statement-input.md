
# Delete Prepared Statement Input

## Structure

`DeletePreparedStatementInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statement_name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `work_group` | `str` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```python
from amazonathena.models.delete_prepared_statement_input import DeletePreparedStatementInput

delete_prepared_statement_input = DeletePreparedStatementInput(
    statement_name='StatementName6',
    work_group='WorkGroup0'
)
```

