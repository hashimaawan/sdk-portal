
# X Amz Target 2 Enum

## Enumeration

`XAmzTarget2Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget2 := models.XAmzTarget2Enum_ENUMAMAZONATHENABATCHGETQUERYEXECUTION

}
```

