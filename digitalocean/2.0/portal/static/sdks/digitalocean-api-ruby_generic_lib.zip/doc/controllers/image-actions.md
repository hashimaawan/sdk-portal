# Image Actions

```ruby
image_actions_api = client.image_actions
```

## Class Name

`ImageActionsApi`

## Methods

* [Image Actions List](../../doc/controllers/image-actions.md#image-actions-list)
* [Image Actions Post](../../doc/controllers/image-actions.md#image-actions-post)
* [Image Actions Get](../../doc/controllers/image-actions.md#image-actions-get)


# Image Actions List

To retrieve all actions that have been executed on an image, send a GET request to `/v2/images/$IMAGE_ID/actions`.

```ruby
def image_actions_list(image_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image_id` | `Integer` | Template, Required | A unique number that can be used to identify and reference a specific image. |

## Response Type

**200**: The results will be returned as a JSON object with an `actions` key. This will be set to an array filled with action objects containing the standard action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2ImagesActionsResponse`](../../doc/models/v2-images-actions-response.md).

## Example Usage

```ruby
image_id = 62137902

result = image_actions_api.image_actions_list(image_id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "completed_at": "2014-07-25T15:10:20Z",
      "id": 29410565,
      "region": {
        "available": true,
        "features": [
          "private_networking",
          "backups",
          "ipv6",
          "metadata",
          "server_id",
          "install_agent",
          "storage",
          "image_transfer"
        ],
        "name": "New York 2",
        "sizes": [
          "s-1vcpu-3gb",
          "m-1vcpu-8gb",
          "s-3vcpu-1gb",
          "s-1vcpu-2gb",
          "s-2vcpu-2gb",
          "s-2vcpu-4gb",
          "s-4vcpu-8gb",
          "s-6vcpu-16gb",
          "s-8vcpu-32gb",
          "s-12vcpu-48gb",
          "s-16vcpu-64gb",
          "s-20vcpu-96gb",
          "s-1vcpu-1gb",
          "c-1vcpu-2gb",
          "s-24vcpu-128gb"
        ],
        "slug": "nyc2"
      },
      "region_slug": "nyc2",
      "resource_id": 7555620,
      "resource_type": "image",
      "started_at": "2014-07-25T15:04:21Z",
      "status": "completed",
      "type": "transfer"
    }
  ],
  "links": {
    "pages": {
      "last": "https://api.digitalocean.com/v2/images/7555620/actions?page=5&per_page=1",
      "next": "https://api.digitalocean.com/v2/images/7555620/actions?page=2&per_page=1"
    }
  },
  "meta": {
    "total": 5
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Image Actions Post

The following actions are available on an Image.

## Convert an Image to a Snapshot

To convert an image, for example, a backup to a snapshot, send a POST request
to `/v2/images/$IMAGE_ID/actions`. Set the `type` attribute to `convert`.

## Transfer an Image

To transfer an image to another region, send a POST request to
`/v2/images/$IMAGE_ID/actions`. Set the `type` attribute to `transfer` and set
`region` attribute to the slug identifier of the region you wish to transfer
to.

```ruby
def image_actions_post(image_id,
                       body: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image_id` | `Integer` | Template, Required | A unique number that can be used to identify and reference a specific image. |
| `body` | [V2 Images Actions Request](../../doc/models/v2-images-actions-request.md) \| [V2 Images Actions Request1](../../doc/models/v2-images-actions-request-1.md) \| nil | Body, Optional | This is a container for any-of cases. |

## Response Type

**201**: The response will be a JSON object with a key called `action`. The value of this will be an object containing the standard image action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`Action`](../../doc/models/action.md).

## Example Usage

```ruby
image_id = 62137902

body = V2ImagesActionsRequest.new(
  type: Type15::CONVERT
)

result = image_actions_api.image_actions_post(
  image_id,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "completed_at": null,
    "id": 36805527,
    "region": {
      "available": true,
      "features": [
        "private_networking",
        "backups",
        "ipv6",
        "metadata",
        "server_id",
        "install_agent",
        "storage",
        "image_transfer"
      ],
      "name": "New York 3",
      "sizes": [
        "s-1vcpu-3gb",
        "m-1vcpu-8gb",
        "s-3vcpu-1gb",
        "s-1vcpu-2gb",
        "s-2vcpu-2gb",
        "s-2vcpu-4gb",
        "s-4vcpu-8gb",
        "s-6vcpu-16gb",
        "s-8vcpu-32gb",
        "s-12vcpu-48gb",
        "s-16vcpu-64gb",
        "s-20vcpu-96gb",
        "s-1vcpu-1gb",
        "c-1vcpu-2gb",
        "s-24vcpu-128gb"
      ],
      "slug": "nyc3"
    },
    "region_slug": "nyc3",
    "resource_id": 7938269,
    "resource_type": "image",
    "started_at": "2014-11-14T16:42:45Z",
    "status": "in-progress",
    "type": "transfer"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Image Actions Get

To retrieve the status of an image action, send a GET request to `/v2/images/$IMAGE_ID/actions/$IMAGE_ACTION_ID`.

```ruby
def image_actions_get(image_id,
                      action_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image_id` | `Integer` | Template, Required | A unique number that can be used to identify and reference a specific image. |
| `action_id` | `Integer` | Template, Required | A unique numeric ID that can be used to identify and reference an action.<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be an object with a key called `action`. The value of this will be an object that contains the standard image action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`Action`](../../doc/models/action.md).

## Example Usage

```ruby
image_id = 62137902

action_id = 36804636

result = image_actions_api.image_actions_get(
  image_id,
  action_id
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "completed_at": null,
    "id": 36805527,
    "region": {
      "available": true,
      "features": [
        "private_networking",
        "backups",
        "ipv6",
        "metadata",
        "server_id",
        "install_agent",
        "storage",
        "image_transfer"
      ],
      "name": "New York 3",
      "sizes": [
        "s-1vcpu-3gb",
        "m-1vcpu-8gb",
        "s-3vcpu-1gb",
        "s-1vcpu-2gb",
        "s-2vcpu-2gb",
        "s-2vcpu-4gb",
        "s-4vcpu-8gb",
        "s-6vcpu-16gb",
        "s-8vcpu-32gb",
        "s-12vcpu-48gb",
        "s-16vcpu-64gb",
        "s-20vcpu-96gb",
        "s-1vcpu-1gb",
        "c-1vcpu-2gb",
        "s-24vcpu-128gb"
      ],
      "slug": "nyc3"
    },
    "region_slug": "nyc3",
    "resource_id": 7938269,
    "resource_type": "image",
    "started_at": "2014-11-14T16:42:45Z",
    "status": "in-progress",
    "type": "transfer"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

