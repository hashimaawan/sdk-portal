
# X Amz Target 10 Enum

## Enumeration

`XAmzTarget10Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget10Enum;

$xAmzTarget10 = XAmzTarget10Enum::ENUM_AMAZONATHENADELETENAMEDQUERY;
```

