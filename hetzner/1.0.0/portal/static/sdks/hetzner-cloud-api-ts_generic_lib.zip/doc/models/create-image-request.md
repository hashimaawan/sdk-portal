
# Create Image Request

*This model accepts additional fields of type unknown.*

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string \| undefined` | Optional | Description of the Image, will be auto-generated if not set |
| `labels` | [`Labels \| undefined`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `type` | [`Type63 \| undefined`](../../doc/models/type-63.md) | Optional | Type of Image to create (default: `snapshot`) |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { CreateImageRequest, Type63 } from 'hetzner-cloud-apilib';

const createImageRequest: CreateImageRequest = {
  description: 'my image',
  labels: {
    labelkey: 'labelkey4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  type: Type63.Snapshot,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

