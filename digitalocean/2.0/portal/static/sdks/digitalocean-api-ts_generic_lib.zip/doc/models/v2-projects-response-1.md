
# V2 Projects Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ProjectsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `project` | [`Project \| undefined`](../../doc/models/project.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { MEnvironment, V2ProjectsResponse1 } from 'digitalocean-apilib';

const v2ProjectsResponse1: V2ProjectsResponse1 = {
  project: {
    createdAt: '2016-03-13T12:52:32.123Z',
    description: 'description4',
    environment: MEnvironment.Development,
    id: '000026e4-0000-0000-0000-000000000000',
    name: 'name6',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

