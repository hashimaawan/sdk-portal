
# List Data Catalogs Output

## Structure

`ListDataCatalogsOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dataCatalogsSummary` | [`?(DataCatalogSummary[])`](../../doc/models/data-catalog-summary.md) | Optional | - | getDataCatalogsSummary(): ?array | setDataCatalogsSummary(?array dataCatalogsSummary): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListDataCatalogsOutputBuilder;
use AmazonAthenaLib\Models\Builders\DataCatalogSummaryBuilder;
use AmazonAthenaLib\Models\DataCatalogType2Enum;

$listDataCatalogsOutput = ListDataCatalogsOutputBuilder::init()
    ->dataCatalogsSummary(
        [
            DataCatalogSummaryBuilder::init()
                ->catalogName('CatalogName4')
                ->type(DataCatalogType2Enum::HIVE)
                ->build(),
            DataCatalogSummaryBuilder::init()
                ->catalogName('CatalogName4')
                ->type(DataCatalogType2Enum::HIVE)
                ->build(),
            DataCatalogSummaryBuilder::init()
                ->catalogName('CatalogName4')
                ->type(DataCatalogType2Enum::HIVE)
                ->build()
        ]
    )
    ->nextToken('NextToken0')
    ->build();
```

