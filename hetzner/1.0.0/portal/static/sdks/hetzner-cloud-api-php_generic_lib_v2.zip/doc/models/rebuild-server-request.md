
# Rebuild Server Request

## Structure

`RebuildServerRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `image` | `string` | Required | ID or name of Image to rebuilt from. | getImage(): string | setImage(string image): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\RebuildServerRequestBuilder;

$rebuildServerRequest = RebuildServerRequestBuilder::init(
    'ubuntu-20.04'
)->build();
```

