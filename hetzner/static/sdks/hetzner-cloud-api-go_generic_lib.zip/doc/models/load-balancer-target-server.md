
# Load Balancer Target Server

Server where the traffic should be routed through

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    loadBalancerTargetServer := models.LoadBalancerTargetServer{
        Id:                   80,
    }

}
```

