
# Get Data Catalog Input

## Structure

`GetDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getDataCatalogInput := models.GetDataCatalogInput{
        Name:                 "Name6",
    }

}
```

