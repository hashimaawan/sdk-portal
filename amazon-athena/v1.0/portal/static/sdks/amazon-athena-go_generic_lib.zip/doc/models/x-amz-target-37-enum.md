
# X Amz Target 37 Enum

## Enumeration

`XAmzTarget37Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTNAMEDQUERIES` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget37 := models.XAmzTarget37Enum_ENUMAMAZONATHENALISTNAMEDQUERIES

}
```

