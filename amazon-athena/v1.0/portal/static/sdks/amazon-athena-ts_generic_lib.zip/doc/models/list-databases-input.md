
# List Databases Input

*This model accepts additional fields of type unknown.*

## Structure

`ListDatabasesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalogName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 50` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ListDatabasesInput } from 'amazon-athenalib';

const listDatabasesInput: ListDatabasesInput = {
  catalogName: 'CatalogName4',
  nextToken: 'NextToken0',
  maxResults: 50,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

