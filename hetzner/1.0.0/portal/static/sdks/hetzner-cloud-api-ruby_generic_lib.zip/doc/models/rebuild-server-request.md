
# Rebuild Server Request

*This model accepts additional fields of type Object.*

## Structure

`RebuildServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image` | `String` | Required | ID or name of Image to rebuilt from. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
rebuild_server_request = RebuildServerRequest.new(
  image: 'ubuntu-20.04',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

