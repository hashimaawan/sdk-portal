
# Data Catalog Type

## Enumeration

`DataCatalogType`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```python
from amazonathena.models.data_catalog_type import DataCatalogType

data_catalog_type = DataCatalogType.LAMBDA
```

