
# Size 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Size1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | A Droplet size available for use in a Kubernetes node pool. | getName(): ?string | setName(?string name): void |
| `slug` | `?string` | Optional | The identifier for a size for use when creating a new cluster. | getSlug(): ?string | setSlug(?string slug): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Size1Builder;
use DigitalOceanApiLib\ApiHelper;

$size1 = Size1Builder::init()
    ->name('s-1vcpu-2gb')
    ->slug('s-1vcpu-2gb')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

