
# Parameters

*This model accepts additional fields of type str.*

## Structure

`Parameters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `additional_properties` | `Dict[str, str]` | Optional | **Constraints**: *Maximum Length*: `51200` |

## Example (as JSON)

```json
{
  "exampleAdditionalProperty": "Parameters_additionalProperties2"
}
```

