
# X Amz Target 29

## Enumeration

`XAmzTarget29`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETWORKGROUP` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget29;

XAmzTarget29 xAmzTarget29 = XAmzTarget29.ENUM_AMAZONATHENAGETWORKGROUP;
```

