
# X Amz Target 34

## Enumeration

`XAmzTarget34`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATABASES` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget34;

XAmzTarget34 xAmzTarget34 = XAmzTarget34.ENUM_AMAZONATHENALISTDATABASES;
```

