
# X Amz Target 16

## Enumeration

`XAmzTarget16`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecutionCode` |

## Example

```ts
import { XAmzTarget16 } from 'amazon-athenalib';

const xAmzTarget16 = XAmzTarget16.EnumAmazonAthenaGetCalculationExecutionCode;
```

