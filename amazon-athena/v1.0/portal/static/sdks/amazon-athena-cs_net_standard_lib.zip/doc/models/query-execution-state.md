
# Query Execution State

## Enumeration

`QueryExecutionState`

## Fields

| Name |
|  --- |
| `Queued` |
| `Running` |
| `Succeeded` |
| `Failed` |
| `Cancelled` |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryExecutionState queryExecutionState = QueryExecutionState.Cancelled;
```

