
# Get Session Response

*This model accepts additional fields of type Object.*

## Structure

`GetSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `work_group` | `String` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `engine_version` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `engine_configuration` | [`EngineConfiguration1`](../../doc/models/engine-configuration-1.md) | Optional | - |
| `notebook_version` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `session_configuration` | [`SessionConfiguration2`](../../doc/models/session-configuration-2.md) | Optional | - |
| `status` | [`Status3`](../../doc/models/status-3.md) | Optional | - |
| `statistics` | [`Statistics3`](../../doc/models/statistics-3.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_session_response = GetSessionResponse.new(
  session_id: 'SessionId6',
  description: 'Description4',
  work_group: 'WorkGroup4',
  engine_version: 'EngineVersion8',
  engine_configuration: EngineConfiguration1.new(
    max_concurrent_dpus: 94,
    coordinator_dpu_size: 1,
    default_executor_dpu_size: 1,
    additional_configs: AdditionalConfigs.new(
      additional_properties: {
        'exampleAdditionalProperty' => 'AdditionalConfigs_additionalProperties5'
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

