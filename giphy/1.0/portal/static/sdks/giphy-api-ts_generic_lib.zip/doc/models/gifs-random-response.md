
# Gifs Random Response

*This model accepts additional fields of type unknown.*

## Structure

`GifsRandomResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`Gif \| undefined`](../../doc/models/gif.md) | Optional | - |
| `meta` | [`Meta \| undefined`](../../doc/models/meta.md) | Optional | The Meta Object contains basic information regarding the request, whether it was successful, and the response given by the API.  Check `responses` to see a description of types of response codes the API might give you under different cirumstances. |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GifsRandomResponse } from 'giphy-apilib';

const gifsRandomResponse: GifsRandomResponse = {
  data: {
    bitlyUrl: 'bitly_url0',
    contentUrl: 'content_url4',
    createDatetime: '2016-03-13T12:52:32.123Z',
    embdedUrl: 'embded_url8',
    featuredTags: [
      'featured_tags0'
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  meta: {
    msg: 'msg8',
    responseId: 'response_id0',
    status: 98,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

