
# Type 28

Type of the algorithm

## Enumeration

`Type28`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```java
import cloud.hetzner.api.models.Type28;

Type28 type28 = Type28.ROUND_ROBIN;
```

