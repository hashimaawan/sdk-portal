
# Time Series

## Structure

`TimeSeries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `values` | Array[Array[Float \| String]] | Required | This is 2d Array of a container for one-of cases. |

## Example

```ruby
time_series = TimeSeries.new(
  [
    [
      161.02,
      161.03
    ],
    [
      161.02,
      161.03
    ]
  ]
)
```

