
# Type 48 Enum

The type of the Floating IP

## Enumeration

`Type48Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type48Enum type48 = Type48Enum.Ipv4;
```

