
# Update Work Group Input

*This model accepts additional fields of type Any.*

## Structure

`UpdateWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `str` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `configuration_updates` | [`ConfigurationUpdates`](../../doc/models/configuration-updates.md) | Optional | - |
| `state` | [`WorkGroupState2`](../../doc/models/work-group-state-2.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.configuration_updates import ConfigurationUpdates
from amazonathena.models.encryption_configuration_2 import EncryptionConfiguration2
from amazonathena.models.encryption_option_1 import EncryptionOption1
from amazonathena.models.result_configuration_updates_2 import ResultConfigurationUpdates2
from amazonathena.models.update_work_group_input import UpdateWorkGroupInput
from amazonathena.models.work_group_state_2 import WorkGroupState2

update_work_group_input = UpdateWorkGroupInput(
    work_group='WorkGroup0',
    description='Description8',
    configuration_updates=ConfigurationUpdates(
        enforce_work_group_configuration=False,
        result_configuration_updates=ResultConfigurationUpdates2(
            output_location='OutputLocation0',
            remove_output_location=False,
            encryption_configuration=EncryptionConfiguration2(
                encryption_option=EncryptionOption1.SSE_S3,
                kms_key='KmsKey6',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            remove_encryption_configuration=False,
            expected_bucket_owner='ExpectedBucketOwner0',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        publish_cloud_watch_metrics_enabled=False,
        bytes_scanned_cutoff_per_query=10000000,
        remove_bytes_scanned_cutoff_per_query=False,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    state=WorkGroupState2.ENABLED,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

