
# Get Session Status Request

*This model accepts additional fields of type unknown.*

## Structure

`GetSessionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetSessionStatusRequest } from 'amazon-athenalib';

const getSessionStatusRequest: GetSessionStatusRequest = {
  sessionId: 'SessionId6',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

