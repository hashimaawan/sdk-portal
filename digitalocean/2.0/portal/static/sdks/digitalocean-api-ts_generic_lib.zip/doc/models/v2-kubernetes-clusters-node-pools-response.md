
# V2 Kubernetes Clusters Node Pools Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersNodePoolsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nodePools` | [`NodePool[] \| undefined`](../../doc/models/node-pool.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2KubernetesClustersNodePoolsResponse } from 'digitalocean-apilib';

const v2KubernetesClustersNodePoolsResponse: V2KubernetesClustersNodePoolsResponse = {
  nodePools: [
    {
      size: 'size6',
      count: 206,
      name: 'name4',
      autoScale: false,
      id: '000013be-0000-0000-0000-000000000000',
      labels: { 'key1': 'val1', 'key2': 'val2' },
      maxNodes: 118,
      minNodes: 54,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

