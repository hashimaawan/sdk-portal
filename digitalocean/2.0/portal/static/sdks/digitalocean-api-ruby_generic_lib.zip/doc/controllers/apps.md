# Apps

App Platform is a Platform-as-a-Service (PaaS) offering from DigitalOcean that allows
developers to publish code directly to DigitalOcean servers without worrying about the
underlying infrastructure.

Most API operations are centered around a few core object types. Following are the
definitions of these types. These definitions will be omitted from the operation-specific
documentation.

For documentation on app specifications (`AppSpec` objects), please refer to the
[product documentation](https://docs.digitalocean.com/products/app-platform/reference/app-spec/)).

```ruby
apps_api = client.apps
```

## Class Name

`AppsApi`

## Methods

* [Apps List](../../doc/controllers/apps.md#apps-list)
* [Apps Create](../../doc/controllers/apps.md#apps-create)
* [Apps List Metrics Bandwidth Daily](../../doc/controllers/apps.md#apps-list-metrics-bandwidth-daily)
* [Apps Validate App Spec](../../doc/controllers/apps.md#apps-validate-app-spec)
* [Apps List Regions](../../doc/controllers/apps.md#apps-list-regions)
* [Apps List Tiers](../../doc/controllers/apps.md#apps-list-tiers)
* [Apps List Instance Sizes](../../doc/controllers/apps.md#apps-list-instance-sizes)
* [Apps Get Instance Size](../../doc/controllers/apps.md#apps-get-instance-size)
* [Apps Get Tier](../../doc/controllers/apps.md#apps-get-tier)
* [Apps List Alerts](../../doc/controllers/apps.md#apps-list-alerts)
* [Apps Assign Alert Destinations](../../doc/controllers/apps.md#apps-assign-alert-destinations)
* [Apps Get Logs Active Deployment](../../doc/controllers/apps.md#apps-get-logs-active-deployment)
* [Apps List Deployments](../../doc/controllers/apps.md#apps-list-deployments)
* [Apps Create Deployment](../../doc/controllers/apps.md#apps-create-deployment)
* [Apps Get Deployment](../../doc/controllers/apps.md#apps-get-deployment)
* [Apps Cancel Deployment](../../doc/controllers/apps.md#apps-cancel-deployment)
* [Apps Get Logs](../../doc/controllers/apps.md#apps-get-logs)
* [Apps Get Logs Aggregate](../../doc/controllers/apps.md#apps-get-logs-aggregate)
* [Apps Get Logs Active Deployment Aggregate](../../doc/controllers/apps.md#apps-get-logs-active-deployment-aggregate)
* [Apps Get Metrics Bandwidth Daily](../../doc/controllers/apps.md#apps-get-metrics-bandwidth-daily)
* [Apps Create Rollback](../../doc/controllers/apps.md#apps-create-rollback)
* [Apps Commit Rollback](../../doc/controllers/apps.md#apps-commit-rollback)
* [Apps Revert Rollback](../../doc/controllers/apps.md#apps-revert-rollback)
* [Apps Validate Rollback](../../doc/controllers/apps.md#apps-validate-rollback)
* [Apps Delete](../../doc/controllers/apps.md#apps-delete)
* [Apps Get](../../doc/controllers/apps.md#apps-get)
* [Apps Update](../../doc/controllers/apps.md#apps-update)


# Apps List

List all apps on your account. Information about the current active deployment as well as any in progress ones will also be included for each app.

```ruby
def apps_list(page: 1,
              per_page: 20,
              with_projects: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | `Integer` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `per_page` | `Integer` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `with_projects` | `TrueClass \| FalseClass` | Query, Optional | Whether the project_id of listed apps should be fetched and included. |

## Response Type

**200**: A JSON object with a `apps` key. This is list of object `apps`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsResponse`](../../doc/models/v2-apps-response.md).

## Example Usage

```ruby
page = 1

per_page = 2

with_projects = true

result = apps_api.apps_list(
  page: page,
  per_page: per_page,
  with_projects: with_projects
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "apps": [
    {
      "active_deployment": {
        "created_at": "2020-12-01T00:40:05Z",
        "id": "3aa4d20e-5527-4c00-b496-601fbd22520a",
        "phase_last_updated_at": "2020-12-01T00:42:12Z",
        "services": [
          {
            "name": "sample-php",
            "source_commit_hash": "54d4a727f457231062439895000d45437c7bb405"
          }
        ],
        "spec": {
          "domains": [
            {
              "domain": "sample-php.example.com",
              "minimum_tls_version": "1.3",
              "type": "PRIMARY",
              "zone": "example.com"
            }
          ],
          "name": "sample-php",
          "region": "fra",
          "services": [
            {
              "environment_slug": "php",
              "git": {
                "branch": "main",
                "repo_clone_url": "https://github.com/digitalocean/sample-php.git"
              },
              "http_port": 8080,
              "instance_count": 1,
              "instance_size_slug": "basic-xxs",
              "name": "sample-php",
              "routes": [
                {
                  "path": "/"
                }
              ],
              "run_command": "heroku-php-apache2"
            }
          ]
        },
        "updated_at": "2020-12-01T00:42:12Z"
      },
      "cause": "app spec updated",
      "created_at": "2020-11-19T20:27:18Z",
      "default_ingress": "https://sample-php-iaj87.ondigitalocean.app",
      "domains": [
        {
          "certificate_expires_at": "2024-01-29T23:59:59Z",
          "id": "0831f444-a1a7-11ed-828c-ef59494480b5",
          "phase": "ACTIVE",
          "progress": {
            "steps": [
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "default-ingress-ready",
                "started_at": "2023-01-30T22:15:45.021896292Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "ensure-zone",
                "started_at": "2023-01-30T22:15:45.022017004Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:42:28.50752065Z",
                "name": "ensure-ns-records",
                "started_at": "2023-01-30T22:15:45.025567874Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "verify-nameservers",
                "started_at": "2023-01-30T22:15:45.033591906Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "ensure-record",
                "started_at": "2023-01-30T22:15:45.156750604Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.258626422Z",
                "name": "ensure-alias-record",
                "started_at": "2023-01-30T22:15:45.165933869Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.258808279Z",
                "name": "ensure-wildcard-record",
                "started_at": "2023-01-30T22:15:45.166093422Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "verify-cname",
                "started_at": "2023-01-30T22:15:45.166205559Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.475903785Z",
                "name": "ensure-ssl-txt-record-saved",
                "started_at": "2023-01-30T22:15:45.295237186Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.476017236Z",
                "name": "ensure-ssl-txt-record",
                "started_at": "2023-01-30T22:15:45.295315291Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:30.476094058Z",
                "name": "ensure-renewal-email",
                "started_at": "2023-01-30T22:15:45.295374087Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "ensure-CA-authorization",
                "started_at": "2023-01-30T22:15:45.295428101Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "0001-01-01T00:00:00Z",
                "name": "ensure-certificate",
                "started_at": "2023-01-30T22:15:45.978756406Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:52.570612857Z",
                "name": "create-deployment",
                "started_at": "0001-01-01T00:00:00Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2023-01-30T15:43:31.333582377Z",
                "name": "configuration-alert",
                "started_at": "2023-01-30T22:15:46.278987808Z",
                "status": "SUCCESS"
              }
            ]
          },
          "rotate_validation_records": false,
          "spec": {
            "domain": "sample-php.example.com",
            "minimum_tls_version": "1.3",
            "type": "PRIMARY",
            "zone": "example.com"
          }
        }
      ],
      "id": "4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf",
      "last_deployment_created_at": "2020-12-01T00:40:05Z",
      "live_domain": "sample-php.example.com",
      "live_url": "https://sample-php.example.com",
      "live_url_base": "https://sample-php.example.com",
      "owner_uuid": "ff36cbc6fd350fe12577f5123133bb5ba01a2419",
      "pending_deployment": {
        "created_at": "2020-12-01T00:40:05Z",
        "id": "3aa4d20e-5527-4c00-b496-601fbd22520a",
        "phase_last_updated_at": "2020-12-01T00:42:12Z",
        "services": [
          {
            "name": "sample-php",
            "source_commit_hash": "54d4a727f457231062439895000d45437c7bb405"
          }
        ],
        "spec": {
          "domains": [
            {
              "domain": "sample-php.example.com",
              "minimum_tls_version": "1.3",
              "type": "PRIMARY",
              "zone": "example.com"
            }
          ],
          "name": "sample-php",
          "region": "fra",
          "services": [
            {
              "environment_slug": "php",
              "git": {
                "branch": "main",
                "repo_clone_url": "https://github.com/digitalocean/sample-php.git"
              },
              "http_port": 8080,
              "instance_count": 1,
              "instance_size_slug": "basic-xxs",
              "name": "sample-php",
              "routes": [
                {
                  "path": "/"
                }
              ],
              "run_command": "heroku-php-apache2"
            }
          ]
        },
        "updated_at": "2020-12-01T00:42:12Z"
      },
      "progress": {
        "phase": "ACTIVE",
        "steps": [
          {
            "ended_at": "2020-12-01T00:41:26.653989756Z",
            "name": "build",
            "started_at": "2020-12-01T00:40:11.979257919Z",
            "status": "SUCCESS",
            "steps": [
              {
                "ended_at": "2020-12-01T00:40:12.470972033Z",
                "name": "initialize",
                "started_at": "2020-12-01T00:40:11.979305214Z",
                "status": "SUCCESS"
              },
              {
                "ended_at": "2020-12-01T00:41:26.180360487Z",
                "name": "components",
                "started_at": "2020-12-01T00:40:12.470996857Z",
                "status": "SUCCESS",
                "steps": [
                  {
                    "component_name": "sample-php",
                    "ended_at": "0001-01-01T00:00:00Z",
                    "message_base": "Building service",
                    "name": "sample-php",
                    "started_at": "0001-01-01T00:00:00Z",
                    "status": "SUCCESS"
                  }
                ]
              }
            ]
          }
        ],
        "success_steps": 6,
        "tier_slug": "basic",
        "total_steps": 6
      },
      "region": {
        "continent": "Europe",
        "data_centers": [
          "fra1"
        ],
        "flag": "germany",
        "label": "Frankfurt",
        "slug": "fra"
      },
      "spec": {
        "domains": [
          {
            "domain": "sample-php.example.com",
            "minimum_tls_version": "1.3",
            "type": "PRIMARY",
            "zone": "example.com"
          }
        ],
        "name": "sample-php",
        "services": [
          {
            "environment_slug": "php",
            "git": {
              "branch": "main",
              "repo_clone_url": "https://github.com/digitalocean/sample-php.git"
            },
            "http_port": 8080,
            "instance_count": 1,
            "instance_size_slug": "basic-xxs",
            "name": "sample-php",
            "routes": [
              {
                "path": "/"
              }
            ],
            "run_command": "heroku-php-apache2"
          }
        ]
      },
      "tier_slug": "basic",
      "updated_at": "2020-12-01T00:42:16Z"
    }
  ],
  "links": {
    "pages": {}
  },
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Create

Create a new app by submitting an app specification. For documentation on app specifications (`AppSpec` objects), please refer to [the product documentation](https://docs.digitalocean.com/products/app-platform/reference/app-spec/).

```ruby
def apps_create(body,
                accept: nil,
                content_type: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2AppsRequest`](../../doc/models/v2-apps-request.md) | Body, Required | - |
| `accept` | [`Accept`](../../doc/models/accept.md) | Header, Optional | The content-type that should be used by the response. By default, the response will be `application/json`. `application/yaml` is also supported. |
| `content_type` | [`ContentType`](../../doc/models/content-type.md) | Header, Optional | The content-type used for the request. By default, the requests are assumed to use `application/json`. `application/yaml` is also supported. |

## Response Type

**200**: A JSON or YAML of a `spec` object.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsResponse1`](../../doc/models/v2-apps-response-1.md).

## Example Usage

```ruby
body = V2AppsRequest.new(
  spec: AppSpec.new(
    name: 'web-app',
    region: Region1::NYC,
    services: [
      Service.new(
        name: 'api',
        environment_slug: 'node-js',
        github: Github.new(
          branch: 'main',
          deploy_on_push: true,
          repo: 'digitalocean/sample-golang'
        ),
        run_command: 'bin/api',
        instance_count: 2,
        instance_size_slug: InstanceSizeSlug::BASICXXS,
        routes: [
          ACriterionForRoutingHttpTrafficToAComponent.new(
            path: '/api'
          )
        ]
      )
    ]
  )
)

accept = Accept::ENUM_APPLICATIONJSON

content_type = ContentType::ENUM_APPLICATIONJSON

result = apps_api.apps_create(
  body,
  accept: accept,
  content_type: content_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Metrics Bandwidth Daily

Retrieve daily bandwidth usage metrics for multiple apps.

```ruby
def apps_list_metrics_bandwidth_daily(body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2AppsMetricsBandwidthDailyRequest`](../../doc/models/v2-apps-metrics-bandwidth-daily-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with a `app_bandwidth_usage` key

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsMetricsBandwidthDailyResponse`](../../doc/models/v2-apps-metrics-bandwidth-daily-response.md).

## Example Usage

```ruby
body = V2AppsMetricsBandwidthDailyRequest.new(
  app_ids: [
    '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf',
    'c2a93513-8d9b-4223-9d61-5e7272c81cf5'
  ],
  date: DateTimeHelper.from_rfc3339('2023-01-17T00:00:00Z')
)

result = apps_api.apps_list_metrics_bandwidth_daily(body)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "app_bandwidth_usage": [
    {
      "app_id": "4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf",
      "bandwidth_bytes": "513668"
    },
    {
      "app_id": "c2a93513-8d9b-4223-9d61-5e7272c81cf5",
      "bandwidth_bytes": "254847"
    }
  ],
  "date": "2023-01-17T00:00:00Z"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Validate App Spec

To propose and validate a spec for a new or existing app, send a POST request to the `/v2/apps/propose` endpoint. The request returns some information about the proposed app, including app cost and upgrade cost. If an existing app ID is specified, the app spec is treated as a proposed update to the existing app.

```ruby
def apps_validate_app_spec(body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2AppsProposeRequest`](../../doc/models/v2-apps-propose-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsProposeResponse`](../../doc/models/v2-apps-propose-response.md).

## Example Usage

```ruby
body = V2AppsProposeRequest.new(
  spec: AppSpec.new(
    name: 'web-app',
    region: Region1::NYC,
    services: [
      Service.new(
        name: 'api',
        environment_slug: 'node-js',
        github: Github.new(
          branch: 'main',
          deploy_on_push: true,
          repo: 'digitalocean/sample-golang'
        ),
        run_command: 'bin/api',
        instance_count: 2,
        instance_size_slug: InstanceSizeSlug::BASICXXS,
        routes: [
          ACriterionForRoutingHttpTrafficToAComponent.new(
            path: '/api'
          )
        ]
      )
    ]
  ),
  app_id: 'b6bdf840-2854-4f87-a36c-5f231c617c84'
)

result = apps_api.apps_validate_app_spec(body)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "app_cost": 5,
  "app_name_available": true,
  "app_tier_upgrade_cost": 17,
  "existing_static_apps": "2",
  "max_free_static_apps": "3",
  "spec": {
    "name": "sample-golang",
    "region": "ams",
    "services": [
      {
        "environment_slug": "go",
        "github": {
          "branch": "branch",
          "repo": "digitalocean/sample-golang"
        },
        "http_port": 8080,
        "instance_count": 1,
        "instance_size_slug": "basic-xxs",
        "name": "web",
        "routes": [
          {
            "path": "/"
          }
        ],
        "run_command": "bin/sample-golang"
      }
    ]
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Regions

List all regions supported by App Platform.

```ruby
def apps_list_regions
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: A JSON object with key `regions`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsRegionsResponse`](../../doc/models/v2-apps-regions-response.md).

## Example Usage

```ruby
result = apps_api.apps_list_regions

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "regions": [
    {
      "continent": "Europe",
      "data_centers": [
        "ams3"
      ],
      "flag": "netherlands",
      "label": "Amsterdam",
      "slug": "ams"
    },
    {
      "continent": "North America",
      "data_centers": [
        "nyc1",
        "nyc3"
      ],
      "default": true,
      "flag": "usa",
      "label": "New York",
      "slug": "nyc"
    },
    {
      "continent": "Europe",
      "data_centers": [
        "fra1"
      ],
      "flag": "germany",
      "label": "Frankfurt",
      "slug": "fra"
    },
    {
      "continent": "North America",
      "data_centers": [
        "sfo3"
      ],
      "flag": "usa",
      "label": "San Francisco",
      "slug": "sfo"
    },
    {
      "continent": "Asia",
      "data_centers": [
        "sgp1"
      ],
      "flag": "singapore",
      "label": "Singapore",
      "slug": "sgp"
    },
    {
      "continent": "Asia",
      "data_centers": [
        "blr1"
      ],
      "flag": "india",
      "label": "Bangalore",
      "slug": "blr"
    },
    {
      "continent": "North America",
      "data_centers": [
        "tor1"
      ],
      "flag": "canada",
      "label": "Toronto",
      "slug": "tor"
    },
    {
      "continent": "Europe",
      "data_centers": [
        "lon1"
      ],
      "flag": "uk",
      "label": "London",
      "slug": "lon"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Tiers

List all app tiers.

```ruby
def apps_list_tiers
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: A JSON object with a `tiers` key. This will be a list of all app tiers

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsTiersResponse`](../../doc/models/v2-apps-tiers-response.md).

## Example Usage

```ruby
result = apps_api.apps_list_tiers

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "tiers": [
    {
      "build_seconds": "6000",
      "egress_bandwidth_bytes": "1073741824",
      "name": "Starter",
      "slug": "starter"
    },
    {
      "build_seconds": "24000",
      "egress_bandwidth_bytes": "42949672960",
      "name": "Basic",
      "slug": "basic"
    },
    {
      "build_seconds": "60000",
      "egress_bandwidth_bytes": "107374182400",
      "name": "Professional",
      "slug": "professional"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Instance Sizes

List all instance sizes for `service`, `worker`, and `job` components.

```ruby
def apps_list_instance_sizes
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: A JSON with key `instance_sizes`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsTiersInstanceSizesResponse`](../../doc/models/v2-apps-tiers-instance-sizes-response.md).

## Example Usage

```ruby
result = apps_api.apps_list_instance_sizes

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "instance_sizes": [
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "536870912",
      "name": "Basic XXS",
      "slug": "basic-xxs",
      "tier_slug": "basic",
      "tier_upgrade_to": "professional-xs",
      "usd_per_month": "5.00",
      "usd_per_second": "0.000002066799"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "1073741824",
      "name": "Basic XS",
      "slug": "basic-xs",
      "tier_slug": "basic",
      "tier_upgrade_to": "professional-xs",
      "usd_per_month": "10.00",
      "usd_per_second": "0.000004133598"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "2147483648",
      "name": "Basic S",
      "slug": "basic-s",
      "tier_slug": "basic",
      "tier_upgrade_to": "professional-s",
      "usd_per_month": "20.00",
      "usd_per_second": "0.000008267196"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "2",
      "memory_bytes": "4294967296",
      "name": "Basic M",
      "slug": "basic-m",
      "tier_slug": "basic",
      "tier_upgrade_to": "professional-m",
      "usd_per_month": "40.00",
      "usd_per_second": "0.000016534392"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "1073741824",
      "name": "Professional XS",
      "slug": "professional-xs",
      "tier_downgrade_to": "basic-xs",
      "tier_slug": "professional",
      "usd_per_month": "12.00",
      "usd_per_second": "0.000004960317"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "1",
      "memory_bytes": "2147483648",
      "name": "Professional S",
      "slug": "professional-s",
      "tier_downgrade_to": "basic-s",
      "tier_slug": "professional",
      "usd_per_month": "25.00",
      "usd_per_second": "0.000010333995"
    },
    {
      "cpu_type": "SHARED",
      "cpus": "2",
      "memory_bytes": "4294967296",
      "name": "Professional M",
      "slug": "professional-m",
      "tier_downgrade_to": "basic-s",
      "tier_slug": "professional",
      "usd_per_month": "50.00",
      "usd_per_second": "0.000020667989"
    },
    {
      "cpu_type": "DEDICATED",
      "cpus": "1",
      "memory_bytes": "4294967296",
      "name": "Professional 1L",
      "slug": "professional-1l",
      "tier_downgrade_to": "basic-m",
      "tier_slug": "professional",
      "usd_per_month": "75.00",
      "usd_per_second": "0.000031001984"
    },
    {
      "cpu_type": "DEDICATED",
      "cpus": "2",
      "memory_bytes": "8589934592",
      "name": "Professional L",
      "slug": "professional-l",
      "tier_downgrade_to": "basic-s",
      "tier_slug": "professional",
      "usd_per_month": "150.00",
      "usd_per_second": "0.000062003968"
    },
    {
      "cpu_type": "DEDICATED",
      "cpus": "4",
      "memory_bytes": "17179869184",
      "name": "Professional XL",
      "slug": "professional-xl",
      "tier_downgrade_to": "basic-s",
      "tier_slug": "professional",
      "usd_per_month": "300.00",
      "usd_per_second": "0.000124007937"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Instance Size

Retrieve information about a specific instance size for `service`, `worker`, and `job` components.

```ruby
def apps_get_instance_size(slug)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `String` | Template, Required | The slug of the instance size |

## Response Type

**200**: A JSON with key `instance_size`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsTiersInstanceSizesResponse1`](../../doc/models/v2-apps-tiers-instance-sizes-response-1.md).

## Example Usage

```ruby
slug = 'basic-xxs'

result = apps_api.apps_get_instance_size(slug)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "instance_size": {
    "cpu_type": "SHARED",
    "cpus": "1",
    "memory_bytes": "536870912",
    "name": "Basic XXS",
    "slug": "basic-xxs",
    "tier_slug": "basic",
    "tier_upgrade_to": "professional-xs",
    "usd_per_month": "5.00",
    "usd_per_second": "0.000002066799"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Tier

Retrieve information about a specific app tier.

```ruby
def apps_get_tier(slug)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `String` | Template, Required | The slug of the tier |

## Response Type

**200**: A JSON with the key `tier`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsTiersResponse1`](../../doc/models/v2-apps-tiers-response-1.md).

## Example Usage

```ruby
slug = 'basic'

result = apps_api.apps_get_tier(slug)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "tier": {
    "build_seconds": "24000",
    "egress_bandwidth_bytes": "42949672960",
    "name": "Basic",
    "slug": "basic"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Alerts

List alerts associated to the app and any components. This includes configuration information about the alerts including emails, slack webhooks, and triggering events or conditions.

```ruby
def apps_list_alerts(app_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |

## Response Type

**200**: A JSON object with a `alerts` key. This is list of object `alerts`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsAlertsResponse`](../../doc/models/v2-apps-alerts-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

result = apps_api.apps_list_alerts(app_id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "alerts": [
    {
      "emails": [
        "sammy@digitalocean.com"
      ],
      "id": "e552e1f9-c1b0-4e6d-8777-ad6f27767306",
      "phase": "ACTIVE",
      "progress": {
        "steps": [
          {
            "ended_at": "2020-07-28T18:00:00Z",
            "name": "alert-configure-insight-alert",
            "started_at": "2020-07-28T18:00:00Z",
            "status": "SUCCESS"
          }
        ]
      },
      "spec": {
        "rule": "DEPLOYMENT_FAILED"
      }
    },
    {
      "emails": [
        "sammy@digitalocean.com"
      ],
      "id": "b58cc9d4-0702-4ffd-ab45-4c2a8d979527",
      "phase": "ACTIVE",
      "progress": {
        "steps": [
          {
            "ended_at": "2020-07-28T18:00:00Z",
            "name": "alert-configure-insight-alert",
            "started_at": "2020-07-28T18:00:00Z",
            "status": "SUCCESS"
          }
        ]
      },
      "spec": {
        "operator": "GREATER_THAN",
        "rule": "CPU_UTILIZATION",
        "value": 85,
        "window": "FIVE_MINUTES"
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Assign Alert Destinations

Updates the emails and slack webhook destinations for app alerts. Emails must be associated to a user with access to the app.

```ruby
def apps_assign_alert_destinations(app_id,
                                   alert_id,
                                   body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `alert_id` | `String` | Template, Required | The alert ID |
| `body` | [`V2AppsAlertsDestinationsRequest`](../../doc/models/v2-apps-alerts-destinations-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with an `alert` key. This is an object of type `alert`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsAlertsDestinationsResponse`](../../doc/models/v2-apps-alerts-destinations-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

alert_id = '5a624ab5-dd58-4b39-b7dd-8b7c36e8a91d'

body = V2AppsAlertsDestinationsRequest.new(
  emails: [
    'sammy@digitalocean.com'
  ]
)

result = apps_api.apps_assign_alert_destinations(
  app_id,
  alert_id,
  body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "alert": {
    "emails": [
      "sammy@digitalocean.com"
    ],
    "id": "e552e1f9-c1b0-4e6d-8777-ad6f27767306",
    "phase": "ACTIVE",
    "progress": {
      "steps": [
        {
          "ended_at": "2020-07-28T18:00:00Z",
          "name": "alert-configure-insight-alert",
          "started_at": "2020-07-28T18:00:00Z",
          "status": "SUCCESS"
        }
      ]
    },
    "spec": {
      "rule": "DEPLOYMENT_FAILED"
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Logs Active Deployment

Retrieve the logs of the active deployment if one exists. The response will include links to either real-time logs of an in-progress or active deployment or archived logs of a past deployment. Note log_type=BUILD logs will return logs associated with the current active deployment (being served). To view build logs associated with in-progress build, the query must explicitly reference the deployment id.

```ruby
def apps_get_logs_active_deployment(app_id,
                                    component_name,
                                    type,
                                    follow: nil,
                                    pod_connection_timeout: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `component_name` | `String` | Template, Required | An optional component name. If set, logs will be limited to this component only. |
| `type` | [`Type3`](../../doc/models/type-3.md) | Query, Required | The type of logs to retrieve<br><br>- BUILD: Build-time logs<br>- DEPLOY: Deploy-time logs<br>- RUN: Live run-time logs |
| `follow` | `TrueClass \| FalseClass` | Query, Optional | Whether the logs should follow live updates. |
| `pod_connection_timeout` | `String` | Query, Optional | An optional time duration to wait if the underlying component instance is not immediately available. Default: `3m`. |

## Response Type

**200**: A JSON object with urls that point to archived logs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsComponentsLogsResponse`](../../doc/models/v2-apps-components-logs-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

component_name = 'component'

type = Type3::BUILD

follow = true

pod_connection_timeout = '3m'

result = apps_api.apps_get_logs_active_deployment(
  app_id,
  component_name,
  type,
  follow: follow,
  pod_connection_timeout: pod_connection_timeout
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "historic_logs": [
    "https://logs-example/archive/build.log"
  ],
  "live_url": "https://logs-example/build.log",
  "url": "https://logs/build.log"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps List Deployments

List all deployments of an app.

```ruby
def apps_list_deployments(app_id,
                          page: 1,
                          per_page: 20)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `page` | `Integer` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `per_page` | `Integer` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |

## Response Type

**200**: A JSON object with a `deployments` key. This will be a list of all app deployments

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsDeploymentsResponse`](../../doc/models/v2-apps-deployments-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

page = 1

per_page = 2

result = apps_api.apps_list_deployments(
  app_id,
  page: page,
  per_page: per_page
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "deployments": [
    {
      "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
      "created_at": "2020-07-28T18:00:00Z",
      "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
      "phase": "PENDING_BUILD",
      "phase_last_updated_at": "0001-01-01T00:00:00Z",
      "progress": {
        "pending_steps": 6,
        "steps": [
          {
            "name": "build",
            "status": "PENDING",
            "steps": [
              {
                "name": "initialize",
                "status": "PENDING"
              },
              {
                "name": "components",
                "status": "PENDING",
                "steps": [
                  {
                    "component_name": "web",
                    "message_base": "Building service",
                    "name": "web",
                    "status": "PENDING"
                  }
                ]
              }
            ]
          },
          {
            "name": "deploy",
            "status": "PENDING",
            "steps": [
              {
                "name": "initialize",
                "status": "PENDING"
              },
              {
                "name": "components",
                "status": "PENDING",
                "steps": [
                  {
                    "component_name": "web",
                    "name": "web",
                    "status": "PENDING",
                    "steps": [
                      {
                        "component_name": "web",
                        "message_base": "Deploying service",
                        "name": "deploy",
                        "status": "PENDING"
                      },
                      {
                        "component_name": "web",
                        "message_base": "Waiting for service",
                        "name": "wait",
                        "status": "PENDING"
                      }
                    ]
                  }
                ]
              },
              {
                "name": "finalize",
                "status": "PENDING"
              }
            ]
          }
        ],
        "total_steps": 6
      },
      "services": [
        {
          "name": "web",
          "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
        }
      ],
      "spec": {
        "name": "sample-golang",
        "region": "ams",
        "services": [
          {
            "environment_slug": "go",
            "github": {
              "branch": "branch",
              "repo": "digitalocean/sample-golang"
            },
            "instance_count": 2,
            "instance_size_slug": "basic-xxs",
            "name": "web",
            "routes": [
              {
                "path": "/"
              }
            ],
            "run_command": "bin/sample-golang"
          }
        ]
      },
      "tier_slug": "basic",
      "updated_at": "2020-07-28T18:00:00Z"
    }
  ],
  "links": {
    "pages": {}
  },
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Create Deployment

Creating an app deployment will pull the latest changes from your repository and schedule a new deployment for your app.

```ruby
def apps_create_deployment(app_id,
                           body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `body` | [`V2AppsDeploymentsRequest`](../../doc/models/v2-apps-deployments-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with a `deployment` key.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

body = V2AppsDeploymentsRequest.new(
  force_build: true
)

result = apps_api.apps_create_deployment(
  app_id,
  body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Deployment

Retrieve information about an app deployment.

```ruby
def apps_get_deployment(app_id,
                        deployment_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `deployment_id` | `String` | Template, Required | The deployment ID |

## Response Type

**200**: A JSON of the requested deployment

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

deployment_id = '3aa4d20e-5527-4c00-b496-601fbd22520a'

result = apps_api.apps_get_deployment(
  app_id,
  deployment_id
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Cancel Deployment

Immediately cancel an in-progress deployment.

```ruby
def apps_cancel_deployment(app_id,
                           deployment_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `deployment_id` | `String` | Template, Required | The deployment ID |

## Response Type

**200**: A JSON the `deployment` that was just cancelled.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

deployment_id = '3aa4d20e-5527-4c00-b496-601fbd22520a'

result = apps_api.apps_cancel_deployment(
  app_id,
  deployment_id
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Logs

Retrieve the logs of a past, in-progress, or active deployment. The response will include links to either real-time logs of an in-progress or active deployment or archived logs of a past deployment.

```ruby
def apps_get_logs(app_id,
                  deployment_id,
                  component_name,
                  type,
                  follow: nil,
                  pod_connection_timeout: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `deployment_id` | `String` | Template, Required | The deployment ID |
| `component_name` | `String` | Template, Required | An optional component name. If set, logs will be limited to this component only. |
| `type` | [`Type3`](../../doc/models/type-3.md) | Query, Required | The type of logs to retrieve<br><br>- BUILD: Build-time logs<br>- DEPLOY: Deploy-time logs<br>- RUN: Live run-time logs |
| `follow` | `TrueClass \| FalseClass` | Query, Optional | Whether the logs should follow live updates. |
| `pod_connection_timeout` | `String` | Query, Optional | An optional time duration to wait if the underlying component instance is not immediately available. Default: `3m`. |

## Response Type

**200**: A JSON object with urls that point to archived logs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsComponentsLogsResponse`](../../doc/models/v2-apps-components-logs-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

deployment_id = '3aa4d20e-5527-4c00-b496-601fbd22520a'

component_name = 'component'

type = Type3::BUILD

follow = true

pod_connection_timeout = '3m'

result = apps_api.apps_get_logs(
  app_id,
  deployment_id,
  component_name,
  type,
  follow: follow,
  pod_connection_timeout: pod_connection_timeout
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "historic_logs": [
    "https://logs-example/archive/build.log"
  ],
  "live_url": "https://logs-example/build.log",
  "url": "https://logs/build.log"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Logs Aggregate

Retrieve the logs of a past, in-progress, or active deployment. If a component name is specified, the logs will be limited to only that component. The response will include links to either real-time logs of an in-progress or active deployment or archived logs of a past deployment.

```ruby
def apps_get_logs_aggregate(app_id,
                            deployment_id,
                            type,
                            follow: nil,
                            pod_connection_timeout: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `deployment_id` | `String` | Template, Required | The deployment ID |
| `type` | [`Type3`](../../doc/models/type-3.md) | Query, Required | The type of logs to retrieve<br><br>- BUILD: Build-time logs<br>- DEPLOY: Deploy-time logs<br>- RUN: Live run-time logs |
| `follow` | `TrueClass \| FalseClass` | Query, Optional | Whether the logs should follow live updates. |
| `pod_connection_timeout` | `String` | Query, Optional | An optional time duration to wait if the underlying component instance is not immediately available. Default: `3m`. |

## Response Type

**200**: A JSON object with urls that point to archived logs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsComponentsLogsResponse`](../../doc/models/v2-apps-components-logs-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

deployment_id = '3aa4d20e-5527-4c00-b496-601fbd22520a'

type = Type3::BUILD

follow = true

pod_connection_timeout = '3m'

result = apps_api.apps_get_logs_aggregate(
  app_id,
  deployment_id,
  type,
  follow: follow,
  pod_connection_timeout: pod_connection_timeout
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "historic_logs": [
    "https://logs-example/archive/build.log"
  ],
  "live_url": "https://logs-example/build.log",
  "url": "https://logs/build.log"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Logs Active Deployment Aggregate

Retrieve the logs of the active deployment if one exists. The response will include links to either real-time logs of an in-progress or active deployment or archived logs of a past deployment. Note log_type=BUILD logs will return logs associated with the current active deployment (being served). To view build logs associated with in-progress build, the query must explicitly reference the deployment id.

```ruby
def apps_get_logs_active_deployment_aggregate(app_id,
                                              type,
                                              follow: nil,
                                              pod_connection_timeout: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `type` | [`Type3`](../../doc/models/type-3.md) | Query, Required | The type of logs to retrieve<br><br>- BUILD: Build-time logs<br>- DEPLOY: Deploy-time logs<br>- RUN: Live run-time logs |
| `follow` | `TrueClass \| FalseClass` | Query, Optional | Whether the logs should follow live updates. |
| `pod_connection_timeout` | `String` | Query, Optional | An optional time duration to wait if the underlying component instance is not immediately available. Default: `3m`. |

## Response Type

**200**: A JSON object with urls that point to archived logs

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsComponentsLogsResponse`](../../doc/models/v2-apps-components-logs-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

type = Type3::BUILD

follow = true

pod_connection_timeout = '3m'

result = apps_api.apps_get_logs_active_deployment_aggregate(
  app_id,
  type,
  follow: follow,
  pod_connection_timeout: pod_connection_timeout
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "historic_logs": [
    "https://logs-example/archive/build.log"
  ],
  "live_url": "https://logs-example/build.log",
  "url": "https://logs/build.log"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get Metrics Bandwidth Daily

Retrieve daily bandwidth usage metrics for a single app.

```ruby
def apps_get_metrics_bandwidth_daily(app_id,
                                     date: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `date` | `DateTime` | Query, Optional | Optional day to query. Only the date component of the timestamp will be considered. Default: yesterday. |

## Response Type

**200**: A JSON object with a `app_bandwidth_usage` key

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsMetricsBandwidthDailyResponse`](../../doc/models/v2-apps-metrics-bandwidth-daily-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

date = DateTimeHelper.from_rfc3339('01/17/2023 00:00:00')

result = apps_api.apps_get_metrics_bandwidth_daily(
  app_id,
  date: date
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "app_bandwidth_usage": [
    {
      "app_id": "4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf",
      "bandwidth_bytes": "513668"
    }
  ],
  "date": "2023-01-17T00:00:00Z"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Create Rollback

Rollback an app to a previous deployment. A new deployment will be created to perform the rollback.
The app will be pinned to the rollback deployment preventing any new deployments from being created,
either manually or through Auto Deploy on Push webhooks. To resume deployments, the rollback must be
either committed or reverted.

It is recommended to use the Validate App Rollback endpoint to double check if the rollback is
valid and if there are any warnings.

```ruby
def apps_create_rollback(app_id,
                         body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `body` | [`V2AppsRollbackRequest`](../../doc/models/v2-apps-rollback-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with a `deployment` key.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

body = V2AppsRollbackRequest.new(
  deployment_id: '3aa4d20e-5527-4c00-b496-601fbd22520a',
  skip_pin: false
)

result = apps_api.apps_create_rollback(
  app_id,
  body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Commit Rollback

Commit an app rollback. This action permanently applies the rollback and unpins the app to resume new deployments.

```ruby
def apps_commit_rollback(app_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |

## Response Type

**200**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

result = apps_api.apps_commit_rollback(app_id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Revert Rollback

Revert an app rollback. This action reverts the active rollback by creating a new deployment from the
latest app spec prior to the rollback and unpins the app to resume new deployments.

```ruby
def apps_revert_rollback(app_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |

## Response Type

**200**: A JSON object with a `deployment` key.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsDeploymentsResponse1`](../../doc/models/v2-apps-deployments-response-1.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

result = apps_api.apps_revert_rollback(app_id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "deployment": {
    "cause": "commit 9a4df0b pushed to github/digitalocean/sample-golang",
    "created_at": "2020-07-28T18:00:00Z",
    "id": "b6bdf840-2854-4f87-a36c-5f231c617c84",
    "phase": "PENDING_BUILD",
    "phase_last_updated_at": "0001-01-01T00:00:00Z",
    "progress": {
      "pending_steps": 6,
      "steps": [
        {
          "name": "build",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "message_base": "Building service",
                  "name": "web",
                  "status": "PENDING"
                }
              ]
            }
          ]
        },
        {
          "name": "deploy",
          "status": "PENDING",
          "steps": [
            {
              "name": "initialize",
              "status": "PENDING"
            },
            {
              "name": "components",
              "status": "PENDING",
              "steps": [
                {
                  "component_name": "web",
                  "name": "web",
                  "status": "PENDING",
                  "steps": [
                    {
                      "component_name": "web",
                      "message_base": "Deploying service",
                      "name": "deploy",
                      "status": "PENDING"
                    },
                    {
                      "component_name": "web",
                      "message_base": "Waiting for service",
                      "name": "wait",
                      "status": "PENDING"
                    }
                  ]
                }
              ]
            },
            {
              "name": "finalize",
              "status": "PENDING"
            }
          ]
        }
      ],
      "total_steps": 6
    },
    "services": [
      {
        "name": "web",
        "source_commit_hash": "9a4df0b8e161e323bc3cdf1dc71878080fe144fa"
      }
    ],
    "spec": {
      "name": "sample-golang",
      "region": "ams",
      "services": [
        {
          "environment_slug": "go",
          "github": {
            "branch": "branch",
            "repo": "digitalocean/sample-golang"
          },
          "instance_count": 2,
          "instance_size_slug": "basic-xxs",
          "name": "web",
          "routes": [
            {
              "path": "/"
            }
          ],
          "run_command": "bin/sample-golang"
        }
      ]
    },
    "tier_slug": "basic",
    "updated_at": "2020-07-28T18:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Validate Rollback

Check whether an app can be rolled back to a specific deployment. This endpoint can also be used
to check if there are any warnings or validation conditions that will cause the rollback to proceed
under unideal circumstances. For example, if a component must be rebuilt as part of the rollback
causing it to take longer than usual.

```ruby
def apps_validate_rollback(app_id,
                           body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_id` | `String` | Template, Required | The app ID |
| `body` | [`V2AppsRollbackRequest`](../../doc/models/v2-apps-rollback-request.md) | Body, Required | - |

## Response Type

**200**: A JSON object with the validation results.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsRollbackValidateResponse`](../../doc/models/v2-apps-rollback-validate-response.md).

## Example Usage

```ruby
app_id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

body = V2AppsRollbackRequest.new(
  deployment_id: '3aa4d20e-5527-4c00-b496-601fbd22520a',
  skip_pin: false
)

result = apps_api.apps_validate_rollback(
  app_id,
  body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "error": {
    "code": "incompatible_result",
    "message": "deployment result \"failed\" is unsuitable for rollback"
  },
  "valid": false
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Delete

Delete an existing app. Once deleted, all active deployments will be permanently shut down and the app deleted. If needed, be sure to back up your app specification so that you may re-create it at a later time.

```ruby
def apps_delete(id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Template, Required | The ID of the app |

## Response Type

**200**: the ID of the app deleted.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsResponse2`](../../doc/models/v2-apps-response-2.md).

## Example Usage

```ruby
id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

result = apps_api.apps_delete(id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "id": "b7d64052-3706-4cb7-b21a-c5a2f44e63b3"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Get

Retrieve details about an existing app by either its ID or name. To retrieve an app by its name, do not include an ID in the request path. Information about the current active deployment as well as any in progress ones will also be included in the response.

```ruby
def apps_get(id,
             name: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Template, Required | The ID of the app |
| `name` | `String` | Query, Optional | The name of the app to retrieve. |

## Response Type

**200**: A JSON with key `app`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsResponse1`](../../doc/models/v2-apps-response-1.md).

## Example Usage

```ruby
id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

name = 'myApp'

result = apps_api.apps_get(
  id,
  name: name
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Apps Update

Update an existing app by submitting a new app specification. For documentation on app specifications (`AppSpec` objects), please refer to [the product documentation](https://docs.digitalocean.com/products/app-platform/reference/app-spec/).

```ruby
def apps_update(id,
                body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Template, Required | The ID of the app |
| `body` | [`V2AppsRequest1`](../../doc/models/v2-apps-request-1.md) | Body, Required | - |

## Response Type

**200**: A JSON object of the updated `app`

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2AppsResponse1`](../../doc/models/v2-apps-response-1.md).

## Example Usage

```ruby
id = '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf'

body = V2AppsRequest1.new(
  spec: AppSpec.new(
    name: 'web-app-01',
    region: Region1::NYC
  )
)

result = apps_api.apps_update(
  id,
  body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

