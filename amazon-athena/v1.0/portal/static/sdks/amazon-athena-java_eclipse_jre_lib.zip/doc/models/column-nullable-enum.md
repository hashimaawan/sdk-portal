
# Column Nullable Enum

## Enumeration

`ColumnNullableEnum`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```java
import com.amazonaws.useast1.athena.models.ColumnNullableEnum;

ColumnNullableEnum columnNullable = ColumnNullableEnum.NOT_NULL;
```

