
# Calculation Configuration

Contains configuration information for the calculation.

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `codeBlock` | `?string` | Optional | **Constraints**: *Maximum Length*: `68000` | getCodeBlock(): ?string | setCodeBlock(?string codeBlock): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\CalculationConfigurationBuilder;

$calculationConfiguration = CalculationConfigurationBuilder::init()
    ->codeBlock('CodeBlock2')
    ->build();
```

