
# Reserve to Region 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`ReserveToRegion1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `projectId` | `?string` | Optional | The UUID of the project to which the reserved IP will be assigned. | getProjectId(): ?string | setProjectId(?string projectId): void |
| `region` | `string` | Required | The slug identifier for the region the reserved IP will be reserved to. | getRegion(): string | setRegion(string region): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\ReserveToRegion1Builder;
use DigitalOceanApiLib\ApiHelper;

$reserveToRegion1 = ReserveToRegion1Builder::init(
    'nyc3'
)
    ->projectId('746c6152-2fa2-11ed-92d3-27aaa54e4988')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

