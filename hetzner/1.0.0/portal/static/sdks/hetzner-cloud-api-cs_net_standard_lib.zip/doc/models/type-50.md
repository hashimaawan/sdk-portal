
# Type 50

Type of the Primary IP

## Enumeration

`Type50`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type50 type50 = Type50.Ipv4;
```

