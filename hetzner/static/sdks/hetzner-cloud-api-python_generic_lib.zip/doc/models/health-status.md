
# Health Status

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listen_port` | `int` | Optional | - |
| `status` | [`Status30Enum`](../../doc/models/status-30-enum.md) | Optional | - |

## Example

```python
from hetznercloudapi.models.health_status import HealthStatus
from hetznercloudapi.models.status_30_enum import Status30Enum

health_status = HealthStatus(
    listen_port=443,
    status=Status30Enum.HEALTHY
)
```

