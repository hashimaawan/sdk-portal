
# Type 50 Enum

Type of the Primary IP

## Enumeration

`Type50Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type50Enum } from 'hetzner-cloud-apilib';

const type50 = Type50Enum.Ipv4;
```

