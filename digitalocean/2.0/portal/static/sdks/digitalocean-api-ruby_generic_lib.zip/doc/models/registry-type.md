
# Registry Type

- DOCKER_HUB: The DockerHub container registry type.
- DOCR: The DigitalOcean container registry type.

## Enumeration

`RegistryType`

## Fields

| Name |
|  --- |
| `DOCKER_HUB` |
| `DOCR` |

## Example

```ruby
registry_type = RegistryType::DOCKER_HUB
```

