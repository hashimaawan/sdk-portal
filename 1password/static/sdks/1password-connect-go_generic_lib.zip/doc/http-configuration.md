
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`m1PasswordConnectRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `m1PasswordConnect.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "m1PasswordConnect"
    "net/http"
)

func main() {
    httpConfiguration := m1PasswordConnect.CreateHttpConfiguration(
        m1PasswordConnect.WithTimeout(30),
        m1PasswordConnect.WithTransport(http.DefaultTransport),
        m1PasswordConnect.WithRetryConfiguration(m1PasswordConnect.DefaultRetryConfiguration()),
    )
}
```

