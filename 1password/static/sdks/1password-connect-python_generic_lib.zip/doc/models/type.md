
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `ITEM` |
| `VAULT` |

## Example

```python
from m1passwordconnect.models.mtype import Type

mtype = Type.ITEM
```

