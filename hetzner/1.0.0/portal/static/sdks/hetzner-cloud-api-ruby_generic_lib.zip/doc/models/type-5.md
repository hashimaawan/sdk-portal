
# Type 5

Type of resource referenced

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `SERVER` |

## Example

```ruby
type5 = Type5::SERVER
```

