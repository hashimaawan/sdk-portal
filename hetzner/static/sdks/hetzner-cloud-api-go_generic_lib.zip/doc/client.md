
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |

The API client can be initialized as follows:

```go
package main

import (
    "hetznercloudapi"
)

func main() {
    client := hetznercloudapi.NewClient(
    hetznercloudapi.CreateConfiguration(
            hetznercloudapi.WithHttpConfiguration(
                hetznercloudapi.CreateHttpConfiguration(
                    hetznercloudapi.WithTimeout(0),
                ),
            ),
        ),
    )
}
```

## Hetzner Cloud API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| ActionsController() | Gets ActionsController |
| CertificatesController() | Gets CertificatesController |
| CertificateActionsController() | Gets CertificateActionsController |
| DatacentersController() | Gets DatacentersController |
| FirewallsController() | Gets FirewallsController |
| FirewallActionsController() | Gets FirewallActionsController |
| FloatingIPsController() | Gets FloatingIPsController |
| FloatingIPActionsController() | Gets FloatingIPActionsController |
| ImagesController() | Gets ImagesController |
| ImageActionsController() | Gets ImageActionsController |
| ISOsController() | Gets ISOsController |
| LoadBalancersController() | Gets LoadBalancersController |
| LoadBalancerActionsController() | Gets LoadBalancerActionsController |
| LoadBalancerTypesController() | Gets LoadBalancerTypesController |
| LocationsController() | Gets LocationsController |
| PrimaryIPsController() | Gets PrimaryIPsController |
| PrimaryIPActionsController() | Gets PrimaryIPActionsController |
| NetworksController() | Gets NetworksController |
| NetworkActionsController() | Gets NetworkActionsController |
| PlacementGroupsController() | Gets PlacementGroupsController |
| PricingController() | Gets PricingController |
| ServersController() | Gets ServersController |
| ServerActionsController() | Gets ServerActionsController |
| ServerTypesController() | Gets ServerTypesController |
| SSHKeysController() | Gets SSHKeysController |
| VolumesController() | Gets VolumesController |
| VolumeActionsController() | Gets VolumeActionsController |

