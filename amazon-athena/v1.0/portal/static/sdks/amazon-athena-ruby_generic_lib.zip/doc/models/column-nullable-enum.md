
# Column Nullable Enum

## Enumeration

`ColumnNullableEnum`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```ruby
column_nullable = ColumnNullableEnum::UNKNOWN
```

