
# V2 Uptime Checks Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2UptimeChecksResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checks` | [`Check[] \| undefined`](../../doc/models/check.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Region8, V2UptimeChecksResponse } from 'digitalocean-apilib';

const v2UptimeChecksResponse: V2UptimeChecksResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  checks: [
    {
      id: '00000820-0000-0000-0000-000000000000',
      enabled: false,
      name: 'name0',
      regions: [
        Region8.UsWest,
        Region8.EuWest,
        Region8.SeAsia
      ],
      target: 'target2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      id: '00000820-0000-0000-0000-000000000000',
      enabled: false,
      name: 'name0',
      regions: [
        Region8.UsWest,
        Region8.EuWest,
        Region8.SeAsia
      ],
      target: 'target2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

