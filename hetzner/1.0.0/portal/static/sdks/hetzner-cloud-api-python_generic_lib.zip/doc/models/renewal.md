
# Renewal

Status of the renewal process of the Certificate.

## Enumeration

`Renewal`

## Fields

| Name |
|  --- |
| `SCHEDULED` |
| `PENDING` |
| `FAILED` |
| `UNAVAILABLE` |

## Example

```python
from hetznercloudapi.models.renewal import Renewal

renewal = Renewal.FAILED
```

