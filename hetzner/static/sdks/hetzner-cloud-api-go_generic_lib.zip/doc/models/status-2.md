
# Status 2

Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates

## Structure

`Status2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`models.Optional[models.Error2]`](../../doc/models/error-2.md) | Optional | If issuance or renewal reports `failed`, this property contains information about what happened |
| `Issuance` | [`*models.IssuanceEnum`](../../doc/models/issuance-enum.md) | Optional | Status of the issuance process of the Certificate |
| `Renewal` | [`*models.RenewalEnum`](../../doc/models/renewal-enum.md) | Optional | Status of the renewal process of the Certificate. |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    status2 := models.Status2{
        Error:                models.NewOptional[models.Error2](nil),
        Issuance:             models.ToPointer(models.IssuanceEnum_COMPLETED),
        Renewal:              models.ToPointer(models.RenewalEnum_SCHEDULED),
    }

}
```

