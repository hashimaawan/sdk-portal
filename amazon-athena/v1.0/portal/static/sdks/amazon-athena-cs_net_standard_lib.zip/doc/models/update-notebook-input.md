
# Update Notebook Input

## Structure

`UpdateNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NotebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `Payload` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `10485760` |
| `Type` | [`NotebookType2Enum`](../../doc/models/notebook-type-2-enum.md) | Required | - |
| `SessionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ClientRequestToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```csharp
using AmazonAthena.Standard.Models;

UpdateNotebookInput updateNotebookInput = new UpdateNotebookInput
{
    NotebookId = "NotebookId8",
    Payload = "Payload4",
    Type = NotebookType2Enum.IPYNB,
    SessionId = "SessionId0",
    ClientRequestToken = "ClientRequestToken2",
};
```

