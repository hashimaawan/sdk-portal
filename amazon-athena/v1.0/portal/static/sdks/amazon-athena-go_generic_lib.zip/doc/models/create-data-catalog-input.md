
# Create Data Catalog Input

## Structure

`CreateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Type` | [`models.DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Parameters` | [`*models.Parameters`](../../doc/models/parameters.md) | Optional | - |
| `Tags` | [`[]models.Tag`](../../doc/models/tag.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    createDataCatalogInput := models.CreateDataCatalogInput{
        Name:                 "Name6",
        Type:                 models.DataCatalogType1Enum_GLUE,
        Description:          models.ToPointer("Description2"),
        Parameters:           models.ToPointer(models.Parameters{
        }),
        Tags:                 []models.Tag{
            models.Tag{
                Key:                  models.ToPointer("Key0"),
                Value:                models.ToPointer("Value6"),
            },
            models.Tag{
                Key:                  models.ToPointer("Key0"),
                Value:                models.ToPointer("Value6"),
            },
            models.Tag{
                Key:                  models.ToPointer("Key0"),
                Value:                models.ToPointer("Value6"),
            },
        },
    }

}
```

