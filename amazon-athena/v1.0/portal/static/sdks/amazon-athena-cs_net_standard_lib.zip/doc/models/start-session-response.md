
# Start Session Response

*This model accepts additional fields of type object.*

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `State` | [`SessionState1?`](../../doc/models/session-state-1.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

StartSessionResponse startSessionResponse = new StartSessionResponse
{
    SessionId = "SessionId4",
    State = SessionState1.Creating,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

