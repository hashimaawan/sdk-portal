
# X Amz Target 1

## Enumeration

`XAmzTarget1`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetPreparedStatement` |

## Example

```ts
import { XAmzTarget1 } from 'amazon-athenalib';

const xAmzTarget1 = XAmzTarget1.EnumAmazonAthenaBatchGetPreparedStatement;
```

