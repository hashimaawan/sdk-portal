
# X Amz Target 20 Enum

## Enumeration

`XAmzTarget20Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetNamedQuery` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget20Enum xAmzTarget20 = XAmzTarget20Enum.EnumAmazonAthenaGetNamedQuery;
```

