
# Change Protection Request 1

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the Network from being deleted |

## Example

```ts
import { ChangeProtectionRequest1 } from 'hetzner-cloud-apilib';

const changeProtectionRequest1: ChangeProtectionRequest1 = {
  mDelete: true,
};
```

