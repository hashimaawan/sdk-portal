
# List Engine Versions Input

*This model accepts additional fields of type unknown.*

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 10` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ListEngineVersionsInput } from 'amazon-athenalib';

const listEngineVersionsInput: ListEngineVersionsInput = {
  nextToken: 'NextToken6',
  maxResults: 10,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

