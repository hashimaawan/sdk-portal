
# Type 63 Enum

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63Enum`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |
| `BACKUP` |

## Example

```php
use HetznerCloudAPILib\Models\Type63Enum;

$type63 = Type63Enum::SNAPSHOT;
```

