
# Query Stage

Stage statistics such as input and output rows and bytes, execution time and stage state. This information also includes substages and the query stage plan.

## Structure

`QueryStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stage_id` | `Integer` | Optional | - |
| `state` | `String` | Optional | - |
| `output_bytes` | `Integer` | Optional | - |
| `output_rows` | `Integer` | Optional | - |
| `input_bytes` | `Integer` | Optional | - |
| `input_rows` | `Integer` | Optional | - |
| `execution_time` | `Integer` | Optional | - |
| `query_stage_plan` | [`QueryStagePlan`](../../doc/models/query-stage-plan.md) | Optional | - |
| `sub_stages` | [`Array[QueryStage]`](../../doc/models/query-stage.md) | Optional | - |

## Example

```ruby
query_stage = QueryStage.new(
  162,
  'State0',
  76,
  190,
  222,
  nil,
  nil,
  QueryStagePlan.new(
    nil,
    nil,
    [],
    []
  ),
  []
)
```

