
# Work Group State

## Enumeration

`WorkGroupState`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ruby
work_group_state = WorkGroupState::ENABLED
```

