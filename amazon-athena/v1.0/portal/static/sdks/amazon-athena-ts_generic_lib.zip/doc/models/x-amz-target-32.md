
# X Amz Target 32

## Enumeration

`XAmzTarget32`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListCalculationExecutions` |

## Example

```ts
import { XAmzTarget32 } from 'amazon-athenalib';

const xAmzTarget32 = XAmzTarget32.EnumAmazonAthenaListCalculationExecutions;
```

