
# Type 10

The type of the IPv4 network interface.

## Enumeration

`Type10`

## Fields

| Name |
|  --- |
| `PUBLIC_` |
| `PRIVATE_` |

## Example

```php
use DigitalOceanApiLib\Models\Type10;

$type10 = Type10::PUBLIC_;
```

