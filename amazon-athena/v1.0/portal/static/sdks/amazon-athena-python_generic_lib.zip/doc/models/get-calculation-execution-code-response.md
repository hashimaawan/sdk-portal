
# Get Calculation Execution Code Response

*This model accepts additional fields of type Any.*

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code_block` | `str` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.get_calculation_execution_code_response import GetCalculationExecutionCodeResponse

get_calculation_execution_code_response = GetCalculationExecutionCodeResponse(
    code_block='CodeBlock2',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

