
# Terminate Session Response

*This model accepts additional fields of type Object.*

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`SessionState1`](../../doc/models/session-state-1.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
terminate_session_response = TerminateSessionResponse.new(
  state: SessionState1::CREATING,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

