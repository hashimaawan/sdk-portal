
# Change Protection Request 2

## Structure

`ChangeProtectionRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool?` | Optional | If true, prevents the Primary IP from being deleted |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ChangeProtectionRequest2 changeProtectionRequest2 = new ChangeProtectionRequest2
{
    Delete = true,
};
```

