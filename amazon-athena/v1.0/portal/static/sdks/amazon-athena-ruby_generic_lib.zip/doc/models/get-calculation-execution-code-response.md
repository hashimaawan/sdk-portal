
# Get Calculation Execution Code Response

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code_block` | `String` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```ruby
get_calculation_execution_code_response = GetCalculationExecutionCodeResponse.new(
  'CodeBlock2'
)
```

