
# Price Monthly 8

Monthly costs for a Load Balancer type in this network zone

*This model accepts additional fields of type unknown.*

## Structure

`PriceMonthly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `string` | Required | Price with VAT added |
| `net` | `string` | Required | Price without VAT |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { PriceMonthly8 } from 'hetzner-cloud-apilib';

const priceMonthly8: PriceMonthly8 = {
  gross: '1.1900000000000000',
  net: '1.0000000000',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

