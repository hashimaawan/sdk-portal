# Server Types

```java
ServerTypesController serverTypesController = client.getServerTypesController();
```

## Class Name

`ServerTypesController`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```java
CompletableFuture<ServerTypesResponse> getAllServerTypesAsync(
    final String name)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

[`ServerTypesResponse`](../../doc/models/server-types-response.md)

## Example Usage

```java
serverTypesController.getAllServerTypesAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a Server Type

Gets a specific Server type object.

```java
CompletableFuture<ServerTypesResponse1> getAServerTypeAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Server Type |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

[`ServerTypesResponse1`](../../doc/models/server-types-response-1.md)

## Example Usage

```java
int id = 112;

serverTypesController.getAServerTypeAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

