
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| furkotAuthAccessCodeCredentials | [`FurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |
| furkotAuthImplicitCredentials | [`FurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

```go
package main

import (
    "furkotTrips"
    "furkotTrips/models"
)

func main() {
    client := furkotTrips.NewClient(
    furkotTrips.CreateConfiguration(
            furkotTrips.WithHttpConfiguration(
                furkotTrips.CreateHttpConfiguration(
                    furkotTrips.WithTimeout(30),
                ),
            ),
            furkotTrips.WithEnvironment(furkotTrips.PRODUCTION),
            furkotTrips.WithFurkotAuthAccessCodeCredentials(
                furkotTrips.NewFurkotAuthAccessCodeCredentials(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScopeFurkotAuthAccessCode{
        models.OauthScopeFurkotAuthAccessCode_Readtrips,
    }),
            ),
            furkotTrips.WithFurkotAuthImplicitCredentials(
                furkotTrips.NewFurkotAuthImplicitCredentials(
                    "OAuthClientId",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScopeFurkotAuthImplicit{
        models.OauthScopeFurkotAuthImplicit_Readtrips,
    }),
            ),
            furkotTrips.WithLoggerConfiguration(
                furkotTrips.WithLevel("info"),
                furkotTrips.WithRequestConfiguration(
                    furkotTrips.WithRequestBody(true),
                ),
                furkotTrips.WithResponseConfiguration(
                    furkotTrips.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Furkot Trips Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| Api() | Gets Api |
| OauthAuthorizationApi() | Gets OauthAuthorizationApi |

