
# Start Calculation Execution Response

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `State` | [`CalculationExecutionState4Enum?`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

StartCalculationExecutionResponse startCalculationExecutionResponse = new StartCalculationExecutionResponse
{
    CalculationExecutionId = "CalculationExecutionId0",
    State = CalculationExecutionState4Enum.CANCELING,
};
```

