
# Label Selector 7

Label selector and a list of selected targets

## Structure

`LabelSelector7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    labelSelector7 := models.LabelSelector7{
        Selector:             "env=prod",
    }

}
```

