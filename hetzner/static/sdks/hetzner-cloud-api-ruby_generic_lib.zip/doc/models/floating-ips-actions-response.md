
# Floating Ips Actions Response

## Structure

`FloatingIpsActionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `actions` | [`Array[Action]`](../../doc/models/action.md) | Required | - |

## Example

```ruby
floating_ips_actions_response = FloatingIpsActionsResponse.new(
  [
    Action.new(
      'start_server',
      Error.new(
        'action_failed',
        'Action failed'
      ),
      '2016-01-30T23:55:00+00:00',
      42,
      100,
      [
        Resource.new(
          42,
          'server'
        )
      ],
      '2016-01-30T23:55:00+00:00',
      StatusEnum::SUCCESS
    )
  ]
)
```

