
# List Databases Output

## Structure

`ListDatabasesOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `databaseList` | [`?(Database[])`](../../doc/models/database.md) | Optional | - | getDatabaseList(): ?array | setDatabaseList(?array databaseList): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListDatabasesOutputBuilder;
use AmazonAthenaLib\Models\Builders\DatabaseBuilder;
use AmazonAthenaLib\Models\Builders\ParametersBuilder;

$listDatabasesOutput = ListDatabasesOutputBuilder::init()
    ->databaseList(
        [
            DatabaseBuilder::init(
                'Name4'
            )
                ->description('Description8')
                ->parameters(
                    ParametersBuilder::init()->build()
                )->build(),
            DatabaseBuilder::init(
                'Name4'
            )
                ->description('Description8')
                ->parameters(
                    ParametersBuilder::init()->build()
                )->build(),
            DatabaseBuilder::init(
                'Name4'
            )
                ->description('Description8')
                ->parameters(
                    ParametersBuilder::init()->build()
                )->build()
        ]
    )
    ->nextToken('NextToken6')
    ->build();
```

