
# Price Monthly 9

Monthly costs for a Primary IP type in this Location

## Structure

`PriceMonthly9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `str` | Required | Price with VAT added |
| `net` | `str` | Required | Price without VAT |

## Example

```python
from hetznercloudapi.models.price_monthly_9 import PriceMonthly9

price_monthly_9 = PriceMonthly9(
    gross='1.1900000000000000',
    net='1.0000000000'
)
```

