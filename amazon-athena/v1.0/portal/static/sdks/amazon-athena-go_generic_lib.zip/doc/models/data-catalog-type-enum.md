
# Data Catalog Type Enum

## Enumeration

`DataCatalogTypeEnum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    dataCatalogType := models.DataCatalogTypeEnum_HIVE

}
```

