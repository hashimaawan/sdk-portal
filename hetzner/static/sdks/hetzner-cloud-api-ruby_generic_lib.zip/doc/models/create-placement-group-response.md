
# Create Placement Group Response

## Structure

`CreatePlacementGroupResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`NullableAction`](../../doc/models/nullable-action.md) | Optional | - |
| `placement_group` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - |

## Example

```ruby
create_placement_group_response = CreatePlacementGroupResponse.new(
  PlacementGroup.new(
    '2016-01-30T23:55:00+00:00',
    42,
    {
      'key0': 'labels4'
    },
    'my-resource',
    [
      42
    ],
    'spread'
  ),
  NullableAction.new(
    'command6',
    Error.new(
      'code2',
      'message4'
    ),
    'finished0',
    238,
    143.26,
    [
      Resource.new(
        198,
        'type0'
      ),
      Resource.new(
        198,
        'type0'
      ),
      Resource.new(
        198,
        'type0'
      )
    ],
    'started8',
    StatusEnum::RUNNING
  )
)
```

