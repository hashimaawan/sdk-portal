
# X Amz Target 2

## Enumeration

`XAmzTarget2`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetQueryExecution` |

## Example

```ts
import { XAmzTarget2 } from 'amazon-athenalib';

const xAmzTarget2 = XAmzTarget2.EnumAmazonAthenaBatchGetQueryExecution;
```

