
# Result Reuse Information

Contains information about whether the result of a previous query was reused.

## Structure

`ResultReuseInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reused_previous_result` | `bool` | Required | - |

## Example

```python
from amazonathena.models.result_reuse_information import ResultReuseInformation

result_reuse_information = ResultReuseInformation(
    reused_previous_result=False
)
```

