
# Status 10

An object containing a `state` attribute whose value is set to a string indicating the current status of the node.

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Status10`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `state` | [`?string(State1)`](../../doc/models/state-1.md) | Optional | A string indicating the current status of the node. | getState(): ?string | setState(?string state): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Status10Builder;
use DigitalOceanApiLib\Models\State1;
use DigitalOceanApiLib\ApiHelper;

$status10 = Status10Builder::init()
    ->state(State1::PROVISIONING)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

