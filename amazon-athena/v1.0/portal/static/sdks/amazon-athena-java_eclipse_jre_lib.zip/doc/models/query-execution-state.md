
# Query Execution State

## Enumeration

`QueryExecutionState`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```java
import com.amazonaws.useast1.athena.models.QueryExecutionState;

QueryExecutionState queryExecutionState = QueryExecutionState.CANCELLED;
```

