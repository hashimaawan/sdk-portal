
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`digitalOceanApiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `digitalOceanApi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "digitalOceanApi"
    "net/http"
)

func main() {
    httpConfiguration := digitalOceanApi.CreateHttpConfiguration(
        digitalOceanApi.WithTimeout(30),
        digitalOceanApi.WithTransport(http.DefaultTransport),
        digitalOceanApi.WithRetryConfiguration(digitalOceanApi.DefaultRetryConfiguration()),
    )
}
```

