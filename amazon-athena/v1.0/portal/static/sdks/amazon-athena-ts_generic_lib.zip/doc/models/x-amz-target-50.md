
# X Amz Target 50

## Enumeration

`XAmzTarget50`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStopQueryExecution` |

## Example

```ts
import { XAmzTarget50 } from 'amazon-athenalib';

const xAmzTarget50 = XAmzTarget50.EnumAmazonAthenaStopQueryExecution;
```

