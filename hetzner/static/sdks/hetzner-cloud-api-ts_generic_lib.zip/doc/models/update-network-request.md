
# Update Network Request

## Structure

`UpdateNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2 \| undefined`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New network name |

## Example

```ts
import { UpdateNetworkRequest } from 'hetzner-cloud-apilib';

const updateNetworkRequest: UpdateNetworkRequest = {
  labels: {
    labelkey: 'labelkey4',
  },
  name: 'new-name',
};
```

