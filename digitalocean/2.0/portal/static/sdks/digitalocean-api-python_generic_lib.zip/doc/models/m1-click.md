
# M1 Click

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`M1Click`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `str` | Required | The slug identifier for the 1-Click application. |
| `mtype` | `str` | Required | The type of the 1-Click application. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.m_1_click import M1Click

m_1_click = M1Click(
    slug='monitoring',
    mtype='kubernetes',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

