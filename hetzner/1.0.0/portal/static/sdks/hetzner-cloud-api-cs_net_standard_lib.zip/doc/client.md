
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(30)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| LogBuilder | [`LogBuilder`](../doc/log-builder.md) | Represents the logging configuration builder for API calls |

The API client can be initialized as follows:

## Code-Based Initialization

```csharp
using HetznerCloudApi.Standard;
using Microsoft.Extensions.Logging;

namespace ConsoleApp;

HetznerCloudApiClient client = new HetznerCloudApiClient.Builder()
    .HttpClientConfig(httpClientConfig =>
        httpClientConfig.Timeout(TimeSpan.FromSeconds(100)))
    .LoggingConfig(config => config
        .LogLevel(LogLevel.Information)
        .RequestConfig(reqConfig => reqConfig.Body(true))
        .ResponseConfig(respConfig => respConfig.Headers(true))
    )
    .Build();
```

## Configuration-Based Initialization

```csharp
using HetznerCloudApi.Standard;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp;

// Build the IConfiguration using .NET conventions (JSON, environment, etc.)
var configuration = new ConfigurationBuilder()
    .AddJsonFile("config.json")
    .AddEnvironmentVariables() // [optional] read environment variables
    .Build();

// Instantiate your SDK and configure it from IConfiguration
var client = HetznerCloudApiClient
    .FromConfiguration(configuration.GetSection("HetznerCloudApi"));
```

See the [Configuration-Based Initialization](../doc/configuration-based-initialization.md) section for details.

## Hetzner Cloud APIClient Class

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| ActionsApi | Gets ActionsApi. |
| CertificatesApi | Gets CertificatesApi. |
| CertificateActionsApi | Gets CertificateActionsApi. |
| DatacentersApi | Gets DatacentersApi. |
| FirewallsApi | Gets FirewallsApi. |
| FirewallActionsApi | Gets FirewallActionsApi. |
| FloatingIPsApi | Gets FloatingIPsApi. |
| FloatingIpActionsApi | Gets FloatingIpActionsApi. |
| ImagesApi | Gets ImagesApi. |
| ImageActionsApi | Gets ImageActionsApi. |
| IsOsApi | Gets IsOsApi. |
| LoadBalancersApi | Gets LoadBalancersApi. |
| LoadBalancerActionsApi | Gets LoadBalancerActionsApi. |
| LoadBalancerTypesApi | Gets LoadBalancerTypesApi. |
| LocationsApi | Gets LocationsApi. |
| PrimaryIPsApi | Gets PrimaryIPsApi. |
| PrimaryIpActionsApi | Gets PrimaryIpActionsApi. |
| NetworksApi | Gets NetworksApi. |
| NetworkActionsApi | Gets NetworkActionsApi. |
| PlacementGroupsApi | Gets PlacementGroupsApi. |
| PricingApi | Gets PricingApi. |
| ServersApi | Gets ServersApi. |
| ServerActionsApi | Gets ServerActionsApi. |
| ServerTypesApi | Gets ServerTypesApi. |
| SshKeysApi | Gets SshKeysApi. |
| VolumesApi | Gets VolumesApi. |
| VolumeActionsApi | Gets VolumeActionsApi. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the Hetzner Cloud APIClient using the values provided for the builder. | `Builder` |

## Hetzner Cloud APIClient Builder Class

Class to build instances of Hetzner Cloud APIClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |

