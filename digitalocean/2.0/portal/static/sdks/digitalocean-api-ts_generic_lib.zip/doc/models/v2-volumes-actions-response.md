
# V2 Volumes Actions Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2VolumesActionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action4 \| undefined`](../../doc/models/action-4.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2VolumesActionsResponse } from 'digitalocean-apilib';

const v2VolumesActionsResponse: V2VolumesActionsResponse = {
  action: {
    resourceId: 66,
    type: 'type2',
    completedAt: '2016-03-13T12:52:32.123Z',
    id: 238,
    region: {
      available: false,
      features: [
        'features7',
        'features8',
        'features9'
      ],
      name: 'name6',
      sizes: [
        'sizes6'
      ],
      slug: 'slug0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

