
# Terminate Session Request

*This model accepts additional fields of type unknown.*

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { TerminateSessionRequest } from 'amazon-athenalib';

const terminateSessionRequest: TerminateSessionRequest = {
  sessionId: 'SessionId0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

