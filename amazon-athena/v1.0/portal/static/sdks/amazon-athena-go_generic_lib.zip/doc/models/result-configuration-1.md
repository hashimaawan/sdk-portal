
# Result Configuration 1

*This model accepts additional fields of type interface{}.*

## Structure

`ResultConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OutputLocation` | `*string` | Optional | - |
| `EncryptionConfiguration` | [`*models.EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - |
| `ExpectedBucketOwner` | `*string` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` |
| `AclConfiguration` | [`*models.AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    resultConfiguration1 := models.ResultConfiguration1{
        OutputLocation:          models.ToPointer("OutputLocation4"),
        EncryptionConfiguration: models.ToPointer(models.EncryptionConfiguration2{
            EncryptionOption:      models.EncryptionOption1_SseS3,
            KmsKey:                models.ToPointer("KmsKey6"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        ExpectedBucketOwner:     models.ToPointer("ExpectedBucketOwner4"),
        AclConfiguration:        models.ToPointer(models.AclConfiguration1{
            S3AclOption:           models.S3AclOption1_BucketOwnerFullControl,
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        AdditionalProperties:    map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

