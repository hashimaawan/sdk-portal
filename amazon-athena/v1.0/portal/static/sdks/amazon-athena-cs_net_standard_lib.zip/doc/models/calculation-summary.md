
# Calculation Summary

Summary information for a notebook calculation.

## Structure

`CalculationSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Status` | [`Status1`](../../doc/models/status-1.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Globalization;

CalculationSummary calculationSummary = new CalculationSummary
{
    CalculationExecutionId = "CalculationExecutionId4",
    Description = "Description6",
    Status = new Status1
    {
        SubmissionDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
            provider: CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind),
        CompletionDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
            provider: CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind),
        State = CalculationExecutionState1Enum.CANCELING,
        StateChangeReason = "StateChangeReason8",
    },
};
```

