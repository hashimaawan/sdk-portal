
# X Amz Target 22 Enum

## Enumeration

`XAmzTarget22Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget22 := models.XAmzTarget22Enum_ENUMAMAZONATHENAGETPREPAREDSTATEMENT

}
```

