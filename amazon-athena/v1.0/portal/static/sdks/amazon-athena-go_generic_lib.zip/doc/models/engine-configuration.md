
# Engine Configuration

Contains data processing unit (DPU) configuration settings and parameter mappings for a notebook engine.

## Structure

`EngineConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CoordinatorDpuSize` | `*int` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `MaxConcurrentDpus` | `int` | Required | **Constraints**: `>= 2`, `<= 5000` |
| `DefaultExecutorDpuSize` | `*int` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `AdditionalConfigs` | [`*models.AdditionalConfigs`](../../doc/models/additional-configs.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    engineConfiguration := models.EngineConfiguration{
        CoordinatorDpuSize:     models.ToPointer(1),
        MaxConcurrentDpus:      194,
        DefaultExecutorDpuSize: models.ToPointer(1),
        AdditionalConfigs:      models.ToPointer(models.AdditionalConfigs{
        }),
    }

}
```

