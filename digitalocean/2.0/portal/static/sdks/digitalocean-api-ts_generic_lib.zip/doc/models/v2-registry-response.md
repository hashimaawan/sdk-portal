
# V2 Registry Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2RegistryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registry` | [`Registry \| undefined`](../../doc/models/registry.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2RegistryResponse } from 'digitalocean-apilib';

const v2RegistryResponse: V2RegistryResponse = {
  registry: {
    createdAt: '2016-03-13T12:52:32.123Z',
    name: 'name2',
    region: 'region8',
    storageUsageBytes: 50,
    storageUsageBytesUpdatedAt: '2016-03-13T12:52:32.123Z',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

