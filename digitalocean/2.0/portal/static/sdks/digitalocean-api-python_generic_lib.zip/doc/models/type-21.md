
# Type 21

The volume action to initiate.

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `ATTACH` |
| `DETACH` |
| `RESIZE` |

## Example

```python
from digitaloceanapi.models.type_21 import Type21

type_21 = Type21.ATTACH
```

