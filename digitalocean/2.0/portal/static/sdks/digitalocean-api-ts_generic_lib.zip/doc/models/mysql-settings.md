
# Mysql Settings

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`MysqlSettings`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authPlugin` | [`AuthPlugin`](../../doc/models/auth-plugin.md) | Required | A string specifying the authentication method to be used for connections<br>to the MySQL user account. The valid values are `mysql_native_password`<br>or `caching_sha2_password`. If excluded when creating a new user, the<br>default for the version of MySQL in use will be used. As of MySQL 8.0, the<br>default is `caching_sha2_password`. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { AuthPlugin, MysqlSettings } from 'digitalocean-apilib';

const mysqlSettings: MysqlSettings = {
  authPlugin: AuthPlugin.MysqlNativePassword,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

