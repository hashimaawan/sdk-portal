
# V2 Droplets Actions Request 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `name` | `string \| undefined` | Optional | The name to give the new snapshot of the Droplet. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type12, V2DropletsActionsRequest1 } from 'digitalocean-apilib';

const v2DropletsActionsRequest1: V2DropletsActionsRequest1 = {
  type: Type12.Reboot,
  name: 'Nifty New Snapshot',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

