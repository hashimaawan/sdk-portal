
# V2 Databases Users Reset Auth Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResetAuthRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mysql_settings` | [`MysqlSettings`](../../doc/models/mysql-settings.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_users_reset_auth_request = V2DatabasesUsersResetAuthRequest.new(
  mysql_settings: MysqlSettings.new(
    auth_plugin: AuthPlugin::MYSQL_NATIVE_PASSWORD,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

