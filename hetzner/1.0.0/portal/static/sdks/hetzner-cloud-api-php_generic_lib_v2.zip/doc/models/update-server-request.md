
# Update Server Request

## Structure

`UpdateServerRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `labels` | `?array` | Optional | User-defined labels (key-value pairs) | getLabels(): ?array | setLabels(?array labels): void |
| `name` | `?string` | Optional | New name to set | getName(): ?string | setName(?string name): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\UpdateServerRequestBuilder;
use HetznerCloudAPILib\ApiHelper;

$updateServerRequest = UpdateServerRequestBuilder::init()
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('my-server')
    ->build();
```

