
# Server 11

## Structure

`Server11`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server | int getId() | setId(int id) |

## Example

```java
import cloud.hetzner.api.models.Server11;

Server11 server11 = new Server11.Builder(
    85
)
.build();
```

