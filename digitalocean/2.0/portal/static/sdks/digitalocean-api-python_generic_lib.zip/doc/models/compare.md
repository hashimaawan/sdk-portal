
# Compare

## Enumeration

`Compare`

## Fields

| Name |
|  --- |
| `GREATERTHAN` |
| `LESSTHAN` |

## Example

```python
from digitaloceanapi.models.compare import Compare

compare = Compare.GREATERTHAN
```

