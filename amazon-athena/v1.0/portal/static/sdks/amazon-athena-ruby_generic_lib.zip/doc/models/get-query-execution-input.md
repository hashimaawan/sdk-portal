
# Get Query Execution Input

## Structure

`GetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ruby
get_query_execution_input = GetQueryExecutionInput.new(
  'QueryExecutionId6'
)
```

