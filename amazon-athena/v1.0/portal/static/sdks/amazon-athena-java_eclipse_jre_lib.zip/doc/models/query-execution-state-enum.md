
# Query Execution State Enum

## Enumeration

`QueryExecutionStateEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```java
import com.amazonaws.useast1.athena.models.QueryExecutionStateEnum;

QueryExecutionStateEnum queryExecutionState = QueryExecutionStateEnum.CANCELLED;
```

