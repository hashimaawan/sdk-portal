
# V2 Firewalls Droplets Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FirewallsDropletsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletIds` | `number[]` | Required | An array containing the IDs of the Droplets to be removed from the firewall. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FirewallsDropletsRequest } from 'digitalocean-apilib';

const v2FirewallsDropletsRequest: V2FirewallsDropletsRequest = {
  dropletIds: [
    49696269
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

