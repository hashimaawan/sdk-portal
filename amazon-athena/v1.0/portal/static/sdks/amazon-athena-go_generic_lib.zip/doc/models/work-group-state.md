
# Work Group State

## Enumeration

`WorkGroupState`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    workGroupState := models.WorkGroupState_Enabled

}
```

