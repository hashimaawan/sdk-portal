
# Route

route leading to the stop

## Structure

`Route`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Distance` | `long?` | Optional | route distance in meters |
| `Duration` | `long?` | Optional | route duration in seconds |
| `Mode` | [`ModeEnum?`](../../doc/models/mode-enum.md) | Optional | travel mode |
| `Polyline` | `string` | Optional | route path compatible with Google polyline encoding algorithm |

## Example

```csharp
using FurkotTrips.Standard.Models;

Route route = new Route
{
    Distance = 134L,
    Duration = 168L,
    Mode = ModeEnum.Car,
    Polyline = "polyline0",
};
```

