
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`nbaStatsApiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `nbaStatsApi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "nbaStatsApi"
    "net/http"
)

func main() {
    httpConfiguration := nbaStatsApi.CreateHttpConfiguration(
        nbaStatsApi.WithTimeout(30),
        nbaStatsApi.WithTransport(http.DefaultTransport),
        nbaStatsApi.WithRetryConfiguration(nbaStatsApi.DefaultRetryConfiguration()),
    )
}
```

