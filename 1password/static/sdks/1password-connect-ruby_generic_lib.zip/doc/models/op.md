
# Op

## Enumeration

`Op`

## Fields

| Name |
|  --- |
| `ADD` |
| `REMOVE` |
| `REPLACE` |

## Example

```ruby
op = Op::REMOVE
```

