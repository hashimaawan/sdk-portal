
# Type 16

Type of the Floating IP

## Enumeration

`Type16`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type16 type16 = Type16.Ipv4;
```

