
# Get Database Input

*This model accepts additional fields of type interface{}.*

## Structure

`GetDatabaseInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `DatabaseName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    getDatabaseInput := models.GetDatabaseInput{
        CatalogName:           "CatalogName2",
        DatabaseName:          "DatabaseName2",
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

