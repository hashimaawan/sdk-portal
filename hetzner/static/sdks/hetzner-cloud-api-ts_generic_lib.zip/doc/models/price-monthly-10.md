
# Price Monthly 10

Monthly costs for a Server type in this Location

## Structure

`PriceMonthly10`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `string` | Required | Price with VAT added |
| `net` | `string` | Required | Price without VAT |

## Example

```ts
import { PriceMonthly10 } from 'hetzner-cloud-apilib';

const priceMonthly10: PriceMonthly10 = {
  gross: '1.1900000000000000',
  net: '1.0000000000',
};
```

