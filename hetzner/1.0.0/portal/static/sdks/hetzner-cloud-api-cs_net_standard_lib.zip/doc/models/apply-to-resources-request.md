
# Apply to Resources Request

## Structure

`ApplyToResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ApplyTo` | [`List<FirewallApplyToResources>`](../../doc/models/firewall-apply-to-resources.md) | Required | Resources the Firewall should be applied to |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

ApplyToResourcesRequest applyToResourcesRequest = new ApplyToResourcesRequest
{
    ApplyTo = new List<FirewallApplyToResources>
    {
        new FirewallApplyToResources
        {
            LabelSelector = new LabelSelector5
            {
                Selector = "selector8",
            },
            Server = new Server9
            {
                Id = 14,
            },
            Type = Type7Enum.Server,
        },
    },
};
```

