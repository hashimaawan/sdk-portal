
# X Amz Target 10

## Enumeration

`XAmzTarget10`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_10 import XAmzTarget10

x_amz_target_10 = XAmzTarget10.ENUM_AMAZONATHENADELETENAMEDQUERY
```

