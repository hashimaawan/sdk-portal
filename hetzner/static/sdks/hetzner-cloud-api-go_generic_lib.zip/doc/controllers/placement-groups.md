# Placement Groups

```go
placementGroupsController := client.PlacementGroupsController()
```

## Class Name

`PlacementGroupsController`

## Methods

* [Get All Placement Groups](../../doc/controllers/placement-groups.md#get-all-placement-groups)
* [Create a Placement Group](../../doc/controllers/placement-groups.md#create-a-placement-group)
* [Delete a Placement Group](../../doc/controllers/placement-groups.md#delete-a-placement-group)
* [Get a Placement Group](../../doc/controllers/placement-groups.md#get-a-placement-group)
* [Update a Placement Group](../../doc/controllers/placement-groups.md#update-a-placement-group)


# Get All Placement Groups

Returns all PlacementGroup objects.

```go
GetAllPlacementGroups(
    ctx context.Context,
    sort *models.SortEnum,
    name *string,
    labelSelector *string,
    mType *models.ParameterType1Enum) (
    models.ApiResponse[models.PlacementGroupsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`*models.SortEnum`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `*string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `*string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `mType` | [`*models.ParameterType1Enum`](../../doc/models/parameter-type-1-enum.md) | Query, Optional | Can be used multiple times. The response will only contain PlacementGroups matching the type. |

## Response Type

**200**: The `placement_groups` key contains an array of PlacementGroup objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PlacementGroupsResponse](../../doc/models/placement-groups-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := placementGroupsController.GetAllPlacementGroups(ctx, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "placement_groups": [
    {
      "created": "2019-01-08T12:10:00+00:00",
      "id": 897,
      "labels": {
        "key": "value"
      },
      "name": "my Placement Group",
      "servers": [
        4711,
        4712
      ],
      "type": "spread"
    }
  ]
}
```


# Create a Placement Group

Creates a new PlacementGroup.

```go
CreateAPlacementGroup(
    ctx context.Context,
    body *models.CreatePlacementGroupRequest) (
    models.ApiResponse[models.CreatePlacementGroupResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`*models.CreatePlacementGroupRequest`](../../doc/models/create-placement-group-request.md) | Body, Optional | - |

## Response Type

**201**: The `PlacementGroup` key contains the PlacementGroup that was just created.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CreatePlacementGroupResponse](../../doc/models/create-placement-group-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.CreatePlacementGroupRequest{
    Name:                 "my Placement Group",
    Type:                 "spread",
}

apiResponse, err := placementGroupsController.CreateAPlacementGroup(ctx, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [],
    "type": "spread"
  }
}
```


# Delete a Placement Group

Deletes a PlacementGroup.

```go
DeleteAPlacementGroup(
    ctx context.Context,
    id int) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: PlacementGroup deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

id := 112

resp, err := placementGroupsController.DeleteAPlacementGroup(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```


# Get a Placement Group

Gets a specific PlacementGroup object.

```go
GetAPlacementGroup(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.PlacementGroupResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `placement_group` key contains a PlacementGroup object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PlacementGroupResponse](../../doc/models/placement-group-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := placementGroupsController.GetAPlacementGroup(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```


# Update a Placement Group

Updates the PlacementGroup properties.

Note that when updating labels, the PlacementGroup’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the PlacementGroup object changes during the request, the response will be a “conflict” error.

```go
UpdateAPlacementGroup(
    ctx context.Context,
    id int,
    body *models.UpdatePlacementGroupRequest) (
    models.ApiResponse[models.PlacementGroupResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`*models.UpdatePlacementGroupRequest`](../../doc/models/update-placement-group-request.md) | Body, Optional | - |

## Response Type

**200**: The `certificate` key contains the PlacementGroup that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PlacementGroupResponse](../../doc/models/placement-group-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.UpdatePlacementGroupRequest{
    Labels:               models.ToPointer(interface{}("[labelkey, value]")),
    Name:                 models.ToPointer("my Placement Group"),
}

apiResponse, err := placementGroupsController.UpdateAPlacementGroup(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```

