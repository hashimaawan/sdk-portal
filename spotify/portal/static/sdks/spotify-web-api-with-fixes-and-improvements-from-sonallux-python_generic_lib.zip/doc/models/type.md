
# Type

The object type.

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `ARTIST` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.mtype import Type

mtype = Type.ARTIST
```

