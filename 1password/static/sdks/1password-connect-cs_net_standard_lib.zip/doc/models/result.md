
# Result

## Enumeration

`Result`

## Fields

| Name |
|  --- |
| `Success` |
| `Deny` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

Result result = Result.Success;
```

