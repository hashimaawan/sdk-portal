
# Protocol 6 Enum

Type of the health check

## Enumeration

`Protocol6Enum`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |

## Example

```ts
import { Protocol6Enum } from 'hetzner-cloud-apilib';

const protocol6 = Protocol6Enum.Tcp;
```

