
# Result Reuse Information

Contains information about whether the result of a previous query was reused.

## Structure

`ResultReuseInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reused_previous_result` | `TrueClass \| FalseClass` | Required | - |

## Example

```ruby
result_reuse_information = ResultReuseInformation.new(
  false
)
```

