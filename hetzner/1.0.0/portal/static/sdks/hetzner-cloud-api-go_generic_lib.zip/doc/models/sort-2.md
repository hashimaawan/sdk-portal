
# Sort 2

## Enumeration

`Sort2`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    sort2 := models.Sort2_EnumCreatedasc

}
```

