# Load Balancer Types

```php
$loadBalancerTypesApi = $client->getLoadBalancerTypesApi();
```

## Class Name

`LoadBalancerTypesApi`

## Methods

* [Get All Load Balancer Types](../../doc/controllers/load-balancer-types.md#get-all-load-balancer-types)
* [Get a Load Balancer Type](../../doc/controllers/load-balancer-types.md#get-a-load-balancer-type)


# Get All Load Balancer Types

Gets all Load Balancer type objects.

```php
function getAllLoadBalancerTypes(?string $name = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `?string` | Query, Optional | Can be used to filter Load Balancer types by their name. The response will only contain the Load Balancer type matching the specified name. |

## Response Type

**200**: The `load_balancer_types` key in the reply contains an array of Load Balancer type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`LoadBalancerTypesResponse`](../../doc/models/load-balancer-types-response.md).

## Example Usage

```php
$loadBalancerTypesApi = $client->getLoadBalancerTypesApi();
$apiResponse = $loadBalancerTypesApi->getAllLoadBalancerTypes();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'LoadBalancerTypesResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Get a Load Balancer Type

Gets a specific Load Balancer type object.

```php
function getALoadBalancerType(int $id): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Load Balancer type |

## Response Type

**200**: The `load_balancer_type` key in the reply contains a Load Balancer type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`LoadBalancerTypesResponse1`](../../doc/models/load-balancer-types-response-1.md).

## Example Usage

```php
$id = 112;

$loadBalancerTypesApi = $client->getLoadBalancerTypesApi();
$apiResponse = $loadBalancerTypesApi->getALoadBalancerType($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'LoadBalancerTypesResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

