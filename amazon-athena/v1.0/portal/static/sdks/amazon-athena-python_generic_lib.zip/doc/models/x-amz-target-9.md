
# X Amz Target 9

## Enumeration

`XAmzTarget9`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEDATACATALOG` |

## Example

```python
from amazonathena.models.x_amz_target_9 import XAmzTarget9

x_amz_target_9 = XAmzTarget9.ENUM_AMAZONATHENADELETEDATACATALOG
```

