
# List Query Executions Output

## Structure

`ListQueryExecutionsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionIds` | `List<string>` | Optional | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

ListQueryExecutionsOutput listQueryExecutionsOutput = new ListQueryExecutionsOutput
{
    QueryExecutionIds = new List<string>
    {
        "QueryExecutionIds9",
    },
    NextToken = "NextToken2",
};
```

