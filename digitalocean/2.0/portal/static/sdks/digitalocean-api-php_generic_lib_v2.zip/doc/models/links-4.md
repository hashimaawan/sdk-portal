
# Links 4

The links object contains the `self` object, which contains the resource relationship.

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Links4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `self` | `?string` | Optional | A URI that can be used to retrieve the resource. | getSelf(): ?string | setSelf(?string self): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Links4Builder;
use DigitalOceanApiLib\ApiHelper;

$links4 = Links4Builder::init()
    ->self('https://api.digitalocean.com/v2/droplets/13457723')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

