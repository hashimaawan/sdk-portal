
# List Data Catalogs Input

## Structure

`ListDataCatalogsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 2`, `<= 50` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ListDataCatalogsInput listDataCatalogsInput = new ListDataCatalogsInput
{
    NextToken = "NextToken8",
    MaxResults = 50,
};
```

