
# Purpose

Some item types, Login and Password, have fields used for autofill. This property indicates that purpose and is required for some item types.

## Enumeration

`Purpose`

## Fields

| Name |
|  --- |
| `Username` |
| `Password` |
| `Notes` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

Purpose purpose = Purpose.Password;
```

