
# Labels 2

User-defined labels (key-value pairs)

## Structure

`Labels2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labelkey` | `String` | Optional | - |

## Example

```ruby
labels2 = Labels2.new(
  'value'
)
```

