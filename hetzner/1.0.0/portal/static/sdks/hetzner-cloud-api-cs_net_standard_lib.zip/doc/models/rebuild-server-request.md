
# Rebuild Server Request

## Structure

`RebuildServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Image` | `string` | Required | ID or name of Image to rebuilt from. |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

RebuildServerRequest rebuildServerRequest = new RebuildServerRequest
{
    Image = "ubuntu-20.04",
};
```

