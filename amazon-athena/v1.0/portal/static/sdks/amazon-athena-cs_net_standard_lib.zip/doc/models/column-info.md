
# Column Info

Information about the columns in a query execution result.

## Structure

`ColumnInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `string` | Optional | - |
| `SchemaName` | `string` | Optional | - |
| `TableName` | `string` | Optional | - |
| `Name` | `string` | Required | - |
| `Label` | `string` | Optional | - |
| `Type` | `string` | Required | - |
| `Precision` | `int?` | Optional | - |
| `Scale` | `int?` | Optional | - |
| `Nullable` | [`ColumnNullable2Enum?`](../../doc/models/column-nullable-2-enum.md) | Optional | - |
| `CaseSensitive` | `bool?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

ColumnInfo columnInfo = new ColumnInfo
{
    Name = "Name8",
    Type = "Type8",
    CatalogName = "CatalogName2",
    SchemaName = "SchemaName2",
    TableName = "TableName4",
    Label = "Label6",
    Precision = 196,
};
```

