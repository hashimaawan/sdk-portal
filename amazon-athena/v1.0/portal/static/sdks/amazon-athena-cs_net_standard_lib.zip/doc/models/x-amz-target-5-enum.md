
# X Amz Target 5 Enum

## Enumeration

`XAmzTarget5Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateNotebook` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget5Enum xAmzTarget5 = XAmzTarget5Enum.EnumAmazonAthenaCreateNotebook;
```

