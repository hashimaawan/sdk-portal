
# V2 Apps Rollback Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsRollbackRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deploymentId` | `string \| undefined` | Optional | The ID of the deployment to rollback to. |
| `skipPin` | `boolean \| undefined` | Optional | Whether to skip pinning the rollback deployment. If false, the rollback deployment will be pinned and any new deployments including Auto Deploy on Push hooks will be disabled until the rollback is either manually committed or reverted via the CommitAppRollback or RevertAppRollback endpoints respectively. If true, the rollback will be immediately committed and the app will remain unpinned. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AppsRollbackRequest } from 'digitalocean-apilib';

const v2AppsRollbackRequest: V2AppsRollbackRequest = {
  deploymentId: '3aa4d20e-5527-4c00-b496-601fbd22520a',
  skipPin: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

