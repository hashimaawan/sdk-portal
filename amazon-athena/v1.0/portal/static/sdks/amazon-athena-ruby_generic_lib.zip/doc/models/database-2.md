
# Database 2

## Structure

`Database2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```ruby
database2 = Database2.new(
  'Name4',
  'Description2',
  Parameters.new
)
```

