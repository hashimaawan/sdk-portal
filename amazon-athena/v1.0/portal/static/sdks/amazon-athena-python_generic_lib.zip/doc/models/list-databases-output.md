
# List Databases Output

## Structure

`ListDatabasesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database_list` | [`List[Database]`](../../doc/models/database.md) | Optional | - |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```python
from amazonathena.models.database import Database
from amazonathena.models.list_databases_output import ListDatabasesOutput
from amazonathena.models.parameters import Parameters

list_databases_output = ListDatabasesOutput(
    database_list=[
        Database(
            name='Name4',
            description='Description8',
            parameters=Parameters()
        )
    ],
    next_token='NextToken8'
)
```

