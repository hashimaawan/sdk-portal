# Files

```java
FilesApi filesApi = client.getFilesApi();
```

## Class Name

`FilesApi`

## Methods

* [Get Item Files](../../doc/controllers/files.md#get-item-files)
* [Get Details of File by Id](../../doc/controllers/files.md#get-details-of-file-by-id)
* [Download File by ID](../../doc/controllers/files.md#download-file-by-id)


# Get Item Files

```java
CompletableFuture<ApiResponse<List<File>>> getItemFilesAsync(
    final UUID vaultUuid,
    final UUID itemUuid,
    final Boolean inlineFiles)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `UUID` | Template, Required | The UUID of the Vault to fetch Items from |
| `itemUuid` | `UUID` | Template, Required | The UUID of the Item to fetch files from |
| `inlineFiles` | `Boolean` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`List<File>`](../../doc/models/file.md).

## Example Usage

```java
UUID vaultUuid = UUID.fromString("00002186-0000-0000-0000-000000000000");
UUID itemUuid = UUID.fromString("0000141a-0000-0000-0000-000000000000");
Boolean inlineFiles = true;

filesApi.getItemFilesAsync(vaultUuid, itemUuid, inlineFiles).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorResponseException) {
        ErrorResponseException errorResponseException = (ErrorResponseException) cause;
        errorResponseException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Details of File by Id

```java
CompletableFuture<ApiResponse<File>> getDetailsOfFileByIdAsync(
    final UUID vaultUuid,
    final UUID itemUuid,
    final UUID fileUuid,
    final Boolean inlineFiles)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `UUID` | Template, Required | The UUID of the Vault to fetch Item from |
| `itemUuid` | `UUID` | Template, Required | The UUID of the Item to fetch File from |
| `fileUuid` | `UUID` | Template, Required | The UUID of the File to fetch |
| `inlineFiles` | `Boolean` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`File`](../../doc/models/file.md).

## Example Usage

```java
UUID vaultUuid = UUID.fromString("00002186-0000-0000-0000-000000000000");
UUID itemUuid = UUID.fromString("0000141a-0000-0000-0000-000000000000");
UUID fileUuid = UUID.fromString("000008e0-0000-0000-0000-000000000000");
Boolean inlineFiles = true;

filesApi.getDetailsOfFileByIdAsync(vaultUuid, itemUuid, fileUuid, inlineFiles).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorResponseException) {
        ErrorResponseException errorResponseException = (ErrorResponseException) cause;
        errorResponseException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Download File by ID

```java
CompletableFuture<ApiResponse<InputStream>> downloadFileByIdAsync(
    final UUID vaultUuid,
    final UUID itemUuid,
    final String fileUuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `UUID` | Template, Required | The UUID of the Vault the item is in |
| `itemUuid` | `UUID` | Template, Required | The UUID of the Item the File is in |
| `fileUuid` | `String` | Template, Required | UUID of the file to get content from |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type `InputStream`.

## Example Usage

```java
UUID vaultUuid = UUID.fromString("00002186-0000-0000-0000-000000000000");
UUID itemUuid = UUID.fromString("0000141a-0000-0000-0000-000000000000");
String fileUuid = "fileUuid2";

filesApi.downloadFileByIdAsync(vaultUuid, itemUuid, fileUuid).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorResponseException) {
        ErrorResponseException errorResponseException = (ErrorResponseException) cause;
        errorResponseException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

