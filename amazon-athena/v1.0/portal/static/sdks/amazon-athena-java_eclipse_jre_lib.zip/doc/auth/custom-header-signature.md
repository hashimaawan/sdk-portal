
# Custom Header Signature



Documentation for accessing and setting credentials for hmac.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| Authorization | `String` | Amazon Signature authorization v4 | `authorization` | `getAuthorization()` |



**Note:** Auth credentials can be set using `customHeaderAuthenticationCredentials` in the client builder and accessed through `getCustomHeaderAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```java
import com.amazonaws.useast1.athena.AmazonAthenaClient;
import com.amazonaws.useast1.athena.authentication.CustomHeaderAuthenticationModel;

public class Program {
    public static void main(String[] args) {
        AmazonAthenaClient client = new AmazonAthenaClient.Builder()
            .customHeaderAuthenticationCredentials(new CustomHeaderAuthenticationModel.Builder(
                    "Authorization"
                )
                .build())
            .build();
    }
}
```


