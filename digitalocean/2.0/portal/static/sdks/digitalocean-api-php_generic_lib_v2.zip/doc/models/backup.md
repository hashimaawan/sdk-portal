
# Backup

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Backup`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `createdAt` | `DateTime` | Required | A time value given in ISO8601 combined date and time format at which the backup was created. | getCreatedAt(): \DateTime | setCreatedAt(\DateTime createdAt): void |
| `sizeGigabytes` | `float` | Required | The size of the database backup in GBs. | getSizeGigabytes(): float | setSizeGigabytes(float sizeGigabytes): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\BackupBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\ApiHelper;

$backup = BackupBuilder::init(
    DateTimeHelper::fromRfc3339DateTimeRequired('2019-01-31T19:25:22Z'),
    0.03364864
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

