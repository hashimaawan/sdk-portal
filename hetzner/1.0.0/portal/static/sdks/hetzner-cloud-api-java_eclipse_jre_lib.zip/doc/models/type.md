
# Type

Type of the Certificate

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```java
import cloud.hetzner.api.models.Type;

Type type = Type.UPLOADED;
```

