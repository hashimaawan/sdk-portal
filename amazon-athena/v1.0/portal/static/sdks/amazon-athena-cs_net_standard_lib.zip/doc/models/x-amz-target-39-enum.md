
# X Amz Target 39 Enum

## Enumeration

`XAmzTarget39Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNotebookSessions` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget39Enum xAmzTarget39 = XAmzTarget39Enum.EnumAmazonAthenaListNotebookSessions;
```

