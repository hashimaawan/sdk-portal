
# Applied to Resource

*This model accepts additional fields of type Object.*

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `type` | [`Type5`](../../doc/models/type-5.md) | Optional | Type of resource referenced |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
applied_to_resource = AppliedToResource.new(
  server: Server.new(
    id: 14,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  type: Type5::SERVER,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

