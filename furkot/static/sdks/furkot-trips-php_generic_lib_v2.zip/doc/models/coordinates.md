
# Coordinates

geographical coordinates of the stop

## Structure

`Coordinates`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `lat` | `?float` | Optional | latitude | getLat(): ?float | setLat(?float lat): void |
| `lon` | `?float` | Optional | longitude | getLon(): ?float | setLon(?float lon): void |

## Example

```php
use FurkotTripsLib\Models\Builders\CoordinatesBuilder;

$coordinates = CoordinatesBuilder::init()
    ->lat(182.98)
    ->lon(16.08)
    ->build();
```

