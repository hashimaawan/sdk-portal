
# Status 72

Status of the Firewall on the Server

## Enumeration

`Status72`

## Fields

| Name |
|  --- |
| `APPLIED` |
| `PENDING` |

## Example

```ruby
status72 = Status72::APPLIED
```

