
# Result Reuse Information 2

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reused_previous_result` | `bool` | Required | - |

## Example

```python
from amazonathena.models.result_reuse_information_2 import ResultReuseInformation2

result_reuse_information_2 = ResultReuseInformation2(
    reused_previous_result=False
)
```

