
# X Amz Target 7

## Enumeration

`XAmzTarget7`

## Fields

| Name |
|  --- |
| `EnumAmazonathenacreatepresignednotebookurl` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget7 := models.XAmzTarget7_EnumAmazonathenacreatepresignednotebookurl

}
```

