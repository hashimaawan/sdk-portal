
# Placement Group Response

## Structure

`PlacementGroupResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `placementGroup` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - | getPlacementGroup(): PlacementGroup | setPlacementGroup(PlacementGroup placementGroup): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\PlacementGroupResponseBuilder;
use HetznerCloudAPILib\Models\Builders\PlacementGroupBuilder;

$placementGroupResponse = PlacementGroupResponseBuilder::init(
    PlacementGroupBuilder::init(
        '2016-01-30T23:55:00+00:00',
        42,
        [
            'key0' => 'labels4'
        ],
        'my-resource',
        [
            42
        ]
    )->build()
)->build();
```

