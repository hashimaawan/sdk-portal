
# Servers Actions Change Protection Request

## Structure

`ServersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool?` | Optional | If true, prevents the Server from being deleted (currently delete and rebuild attribute needs to have the same value) |
| `Rebuild` | `bool?` | Optional | If true, prevents the Server from being rebuilt (currently delete and rebuild attribute needs to have the same value) |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ServersActionsChangeProtectionRequest serversActionsChangeProtectionRequest = new ServersActionsChangeProtectionRequest
{
    Delete = true,
    Rebuild = true,
};
```

