
# Item Type 2

The ID type.

## Enumeration

`ItemType2`

## Fields

| Name |
|  --- |
| `Artist` |
| `User` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    itemType2 := models.ItemType2_Artist

}
```

