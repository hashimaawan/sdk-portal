
# X Amz Target 50 Enum

## Enumeration

`XAmzTarget50Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStopQueryExecution` |

## Example

```ts
import { XAmzTarget50Enum } from 'amazon-athenalib';

const xAmzTarget50 = XAmzTarget50Enum.EnumAmazonAthenaStopQueryExecution;
```

