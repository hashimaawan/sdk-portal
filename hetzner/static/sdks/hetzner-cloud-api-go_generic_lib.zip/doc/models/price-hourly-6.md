
# Price Hourly 6

Hourly costs for a Load Balancer type in this network zone

## Structure

`PriceHourly6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    priceHourly6 := models.PriceHourly6{
        Gross:                "1.1900000000000000",
        Net:                  "1.0000000000",
    }

}
```

