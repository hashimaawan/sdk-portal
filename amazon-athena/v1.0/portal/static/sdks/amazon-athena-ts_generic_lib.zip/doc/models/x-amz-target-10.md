
# X Amz Target 10

## Enumeration

`XAmzTarget10`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteNamedQuery` |

## Example

```ts
import { XAmzTarget10 } from 'amazon-athenalib';

const xAmzTarget10 = XAmzTarget10.EnumAmazonAthenaDeleteNamedQuery;
```

