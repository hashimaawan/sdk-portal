
# Images Actions Change Protection Request

## Structure

`ImagesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Optional | If true, prevents the snapshot from being deleted |

## Example

```python
from hetznercloudapi.models.images_actions_change_protection_request import ImagesActionsChangeProtectionRequest

images_actions_change_protection_request = ImagesActionsChangeProtectionRequest(
    delete=True
)
```

