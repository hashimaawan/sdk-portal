
# X Amz Target 21 Enum

## Enumeration

`XAmzTarget21Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget21Enum;

$xAmzTarget21 = XAmzTarget21Enum::ENUM_AMAZONATHENAGETNOTEBOOKMETADATA;
```

