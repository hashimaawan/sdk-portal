
# Status 24

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |
| `UNAVAILABLE` |

## Example

```python
from hetznercloudapi.models.status_24 import Status24

status_24 = Status24.UNAVAILABLE
```

