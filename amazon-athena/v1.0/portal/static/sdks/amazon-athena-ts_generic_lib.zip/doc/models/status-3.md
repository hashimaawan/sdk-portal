
# Status 3

## Structure

`Status3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `startDateTime` | `string \| undefined` | Optional | - |
| `lastModifiedDateTime` | `string \| undefined` | Optional | - |
| `endDateTime` | `string \| undefined` | Optional | - |
| `idleSinceDateTime` | `string \| undefined` | Optional | - |
| `state` | [`SessionState1Enum \| undefined`](../../doc/models/session-state-1-enum.md) | Optional | - |
| `stateChangeReason` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { SessionState1Enum, Status3 } from 'amazon-athenalib';

const status3: Status3 = {
  startDateTime: '2016-03-13T12:52:32.123Z',
  lastModifiedDateTime: '2016-03-13T12:52:32.123Z',
  endDateTime: '2016-03-13T12:52:32.123Z',
  idleSinceDateTime: '2016-03-13T12:52:32.123Z',
  state: SessionState1Enum.CREATING,
};
```

