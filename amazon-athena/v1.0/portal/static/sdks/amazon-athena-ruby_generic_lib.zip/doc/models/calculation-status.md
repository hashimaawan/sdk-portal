
# Calculation Status

Contains information about the status of a notebook calculation.

## Structure

`CalculationStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `submission_date_time` | `DateTime` | Optional | - |
| `completion_date_time` | `DateTime` | Optional | - |
| `state` | [`CalculationExecutionState1Enum`](../../doc/models/calculation-execution-state-1-enum.md) | Optional | - |
| `state_change_reason` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
calculation_status = CalculationStatus.new(
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  CalculationExecutionState1Enum::CREATING,
  'StateChangeReason4'
)
```

