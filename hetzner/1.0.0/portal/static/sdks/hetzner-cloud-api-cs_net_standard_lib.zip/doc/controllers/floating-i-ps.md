# Floating I Ps

```csharp
FloatingIPsApi floatingIPsApi = client.FloatingIPsApi;
```

## Class Name

`FloatingIPsApi`

## Methods

* [Get All Floating I Ps](../../doc/controllers/floating-i-ps.md#get-all-floating-i-ps)
* [Create a Floating IP](../../doc/controllers/floating-i-ps.md#create-a-floating-ip)
* [Delete a Floating IP](../../doc/controllers/floating-i-ps.md#delete-a-floating-ip)
* [Get a Floating IP](../../doc/controllers/floating-i-ps.md#get-a-floating-ip)
* [Update a Floating IP](../../doc/controllers/floating-i-ps.md#update-a-floating-ip)


# Get All Floating I Ps

Returns all Floating IP objects.

```csharp
GetAllFloatingIPsAsync(
    string name = null,
    string labelSelector = null,
    Models.Sort2? sort = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Query, Optional | Can be used to filter Floating IPs by their name. The response will only contain the Floating IP matching the specified name. |
| `labelSelector` | `string` | Query, Optional | Can be used to filter Floating IPs by labels. The response will only contain Floating IPs matching the label selector. |
| `sort` | [`Sort2?`](../../doc/models/sort-2.md) | Query, Optional | Can be used multiple times. Choices id id:asc id:desc created created:asc created:desc |

## Response Type

**200**: The `floating_ips` key in the reply contains an array of Floating IP objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.FloatingIpsResponse](../../doc/models/floating-ips-response.md).

## Example Usage

```csharp
try
{
    ApiResponse<FloatingIpsResponse> result = await floatingIPsApi.GetAllFloatingIPsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Create a Floating IP

Creates a new Floating IP assigned to a Server. If you want to create a Floating IP that is not bound to a Server, you need to provide the `home_location` key instead of `server`. This can be either the ID or the name of the Location this IP shall be created in. Note that a Floating IP can be assigned to a Server in any Location later on. For optimal routing it is advised to use the Floating IP in the same Location it was created in.

```csharp
CreateAFloatingIpAsync(
    Models.CreateFloatingIpRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateFloatingIpRequest`](../../doc/models/create-floating-ip-request.md) | Body, Optional | The `type` argument is required while `home_location` and `server` are mutually exclusive. |

## Response Type

**201**: The `floating_ip` key in the reply contains the object that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.FloatingIpsResponse1](../../doc/models/floating-ips-response-1.md).

## Example Usage

```csharp
CreateFloatingIpRequest body = new CreateFloatingIpRequest
{
    Type = Type17.Ipv4,
    Description = "Web Frontend",
    HomeLocation = "fsn1",
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "Web Frontend",
    Server = 42,
};

try
{
    ApiResponse<FloatingIpsResponse1> result = await floatingIPsApi.CreateAFloatingIpAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_floating_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "floating_ip": {
    "blocked": false,
    "created": "2016-01-30T23:50:00+00:00",
    "description": "Web Frontend",
    "dns_ptr": [
      {
        "dns_ptr": "server.example.com",
        "ip": "2001:db8::1"
      }
    ],
    "home_location": {
      "city": "Falkenstein",
      "country": "DE",
      "description": "Falkenstein DC Park 1",
      "id": 1,
      "latitude": 50.47612,
      "longitude": 12.370071,
      "name": "fsn1",
      "network_zone": "eu-central"
    },
    "id": 4711,
    "ip": "131.232.99.1",
    "labels": {
      "env": "dev"
    },
    "name": "Web Frontend",
    "protection": {
      "delete": false
    },
    "server": 42,
    "type": "ipv4"
  }
}
```


# Delete a Floating IP

Deletes a Floating IP. If it is currently assigned to a Server it will automatically get unassigned.

```csharp
DeleteAFloatingIpAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |

## Response Type

**204**: Floating IP deleted

`Task`

## Example Usage

```csharp
int id = 112;
try
{
    await floatingIPsApi.DeleteAFloatingIpAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Floating IP

Returns a specific Floating IP object.

```csharp
GetAFloatingIpAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |

## Response Type

**200**: The `floating_ip` key in the reply contains a Floating IP object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.FloatingIpsResponse2](../../doc/models/floating-ips-response-2.md).

## Example Usage

```csharp
int id = 112;
try
{
    ApiResponse<FloatingIpsResponse2> result = await floatingIPsApi.GetAFloatingIpAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Update a Floating IP

Updates the description or labels of a Floating IP.
Also note that when updating labels, the Floating IP’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```csharp
UpdateAFloatingIpAsync(
    int id,
    Models.UpdateFloatingIpRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `body` | [`UpdateFloatingIpRequest`](../../doc/models/update-floating-ip-request.md) | Body, Optional | - |

## Response Type

**200**: The `floating_ip` key in the reply contains the modified Floating IP object with the new description

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.FloatingIpsResponse2](../../doc/models/floating-ips-response-2.md).

## Example Usage

```csharp
int id = 112;
UpdateFloatingIpRequest body = new UpdateFloatingIpRequest
{
    Description = "Web Frontend",
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "Web Frontend",
};

try
{
    ApiResponse<FloatingIpsResponse2> result = await floatingIPsApi.UpdateAFloatingIpAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "floating_ip": {
    "blocked": false,
    "created": "2016-01-30T23:50:00+00:00",
    "description": "Web Frontend",
    "dns_ptr": [
      {
        "dns_ptr": "server.example.com",
        "ip": "2001:db8::1"
      }
    ],
    "home_location": {
      "city": "Falkenstein",
      "country": "DE",
      "description": "Falkenstein DC Park 1",
      "id": 1,
      "latitude": 50.47612,
      "longitude": 12.370071,
      "name": "fsn1",
      "network_zone": "eu-central"
    },
    "id": 4711,
    "ip": "131.232.99.1",
    "labels": {
      "labelkey": "value"
    },
    "name": "Web Frontend",
    "protection": {
      "delete": false
    },
    "server": 42,
    "type": "ipv4"
  }
}
```

