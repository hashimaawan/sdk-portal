
# V2 Floating Ips Actions Request

*This model accepts additional fields of type Object.*

## Structure

`V2FloatingIpsActionsRequest`

## Inherits From

[`BaseType`](../../doc/models/base-type.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DropletId` | `int` | Required | The ID of the Droplet that the floating IP will be assigned to. | int getDropletId() | setDropletId(int dropletId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.V2FloatingIpsActionsRequest;
import java.io.IOException;

V2FloatingIpsActionsRequest v2FloatingIpsActionsRequest = new V2FloatingIpsActionsRequest.Builder(
    758604968
)
.type("V2 Floating Ips Actions Request")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

