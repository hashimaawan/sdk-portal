
# Encryption Option Enum

## Enumeration

`EncryptionOptionEnum`

## Fields

| Name |
|  --- |
| `SSE_S3` |
| `SSE_KMS` |
| `CSE_KMS` |

## Example

```java
import com.amazonaws.useast1.athena.models.EncryptionOptionEnum;

EncryptionOptionEnum encryptionOption = EncryptionOptionEnum.SSE_S3;
```

