
# Type 66

## Enumeration

`Type66`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```java
import cloud.hetzner.api.models.Type66;

Type66 type66 = Type66.NETWORK;
```

