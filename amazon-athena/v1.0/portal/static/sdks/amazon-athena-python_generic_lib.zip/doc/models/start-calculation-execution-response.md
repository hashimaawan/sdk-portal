
# Start Calculation Execution Response

*This model accepts additional fields of type Any.*

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `state` | [`CalculationExecutionState4`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.calculation_execution_state_4 import CalculationExecutionState4
from amazonathena.models.start_calculation_execution_response import StartCalculationExecutionResponse

start_calculation_execution_response = StartCalculationExecutionResponse(
    calculation_execution_id='CalculationExecutionId0',
    state=CalculationExecutionState4.CANCELING,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

