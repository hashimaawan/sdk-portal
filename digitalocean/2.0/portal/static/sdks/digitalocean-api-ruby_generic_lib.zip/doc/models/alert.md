
# Alert

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Alert`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `disabled` | `TrueClass \| FalseClass` | Optional | Is the alert disabled? |
| `operator` | [`Operator`](../../doc/models/operator.md) | Optional | **Default**: `Operator::UNSPECIFIED_OPERATOR` |
| `rule` | [`Rule`](../../doc/models/rule.md) | Optional | **Default**: `Rule::UNSPECIFIED_RULE` |
| `value` | `Float` | Optional | Threshold value for alert |
| `window` | [`Window`](../../doc/models/window.md) | Optional | **Default**: `Window::UNSPECIFIED_WINDOW` |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
alert = Alert.new(
  disabled: false,
  operator: Operator::GREATER_THAN,
  rule: Rule::CPU_UTILIZATION,
  value: 2.32,
  window: Window::FIVE_MINUTES,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

