
# Server 9

Configuration for type server, required if type is `server`

## Structure

`Server9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Server |

## Example

```ts
import { Server9 } from 'hetzner-cloud-apilib';

const server9: Server9 = {
  id: 216,
};
```

