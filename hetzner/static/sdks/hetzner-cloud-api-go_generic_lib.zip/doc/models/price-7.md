
# Price 7

## Structure

`Price7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Location` | `string` | Required | Name of the Location the price is for |
| `PriceHourly` | [`models.PriceHourly6`](../../doc/models/price-hourly-6.md) | Required | Hourly costs for a Load Balancer type in this network zone |
| `PriceMonthly` | [`models.PriceMonthly8`](../../doc/models/price-monthly-8.md) | Required | Monthly costs for a Load Balancer type in this network zone |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    price7 := models.Price7{
        Location:             "fsn1",
        PriceHourly:          models.PriceHourly6{
            Gross:                "1.1900000000000000",
            Net:                  "1.0000000000",
        },
        PriceMonthly:         models.PriceMonthly8{
            Gross:                "1.1900000000000000",
            Net:                  "1.0000000000",
        },
    }

}
```

