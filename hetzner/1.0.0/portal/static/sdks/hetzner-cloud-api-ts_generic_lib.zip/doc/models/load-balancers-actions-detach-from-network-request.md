
# Load Balancers Actions Detach from Network Request

*This model accepts additional fields of type unknown.*

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `number` | Required | ID of an existing network to detach the Load Balancer from |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  LoadBalancersActionsDetachFromNetworkRequest,
} from 'hetzner-cloud-apilib';

const loadBalancersActionsDetachFromNetworkRequest: LoadBalancersActionsDetachFromNetworkRequest = {
  network: 4711,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

