
# Status 13

## Enumeration

`Status13`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `ERROR` |

## Example

```php
use DigitalOceanApiLib\Models\Status13;

$status13 = Status13::SUCCESS;
```

