
# X Amz Target 7

## Enumeration

`XAmzTarget7`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget7;

XAmzTarget7 xAmzTarget7 = XAmzTarget7.ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL;
```

