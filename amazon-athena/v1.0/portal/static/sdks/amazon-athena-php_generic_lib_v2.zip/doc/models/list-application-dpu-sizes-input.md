
# List Application DPU Sizes Input

## Structure

`ListApplicationDPUSizesInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `maxResults` | `?int` | Optional | **Constraints**: `>= 1`, `<= 100` | getMaxResults(): ?int | setMaxResults(?int maxResults): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListApplicationDPUSizesInputBuilder;

$listApplicationDPUSizesInput = ListApplicationDPUSizesInputBuilder::init()
    ->maxResults(100)
    ->nextToken('NextToken8')
    ->build();
```

