
# Type 21

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `System` |
| `Snapshot` |
| `Backup` |
| `App` |

## Example

```ts
import { Type21 } from 'hetzner-cloud-apilib';

const type21 = Type21.Backup;
```

