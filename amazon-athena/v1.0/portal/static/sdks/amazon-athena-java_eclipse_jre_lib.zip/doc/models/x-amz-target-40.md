
# X Amz Target 40

## Enumeration

`XAmzTarget40`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget40;

XAmzTarget40 xAmzTarget40 = XAmzTarget40.ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS;
```

