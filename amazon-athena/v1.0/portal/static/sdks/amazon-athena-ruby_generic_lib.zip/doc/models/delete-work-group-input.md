
# Delete Work Group Input

## Structure

`DeleteWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `recursive_delete_option` | `TrueClass \| FalseClass` | Optional | - |

## Example

```ruby
delete_work_group_input = DeleteWorkGroupInput.new(
  'WorkGroup8',
  false
)
```

