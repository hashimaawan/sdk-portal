
# X Amz Target 5

## Enumeration

`XAmzTarget5`

## Fields

| Name |
|  --- |
| `EnumAmazonathenacreatenotebook` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget5 := models.XAmzTarget5_EnumAmazonathenacreatenotebook

}
```

