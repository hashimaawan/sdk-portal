
# Isos Response 1

*This model accepts additional fields of type object.*

## Structure

`IsosResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Iso` | [`Iso`](../../doc/models/iso.md) | Required | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

IsosResponse1 isosResponse1 = new IsosResponse1
{
    Iso = new Iso
    {
        Deprecated = "2018-02-28T00:00:00+00:00",
        Description = "FreeBSD 11.0 x64",
        Id = 42,
        Name = "FreeBSD-11.0-RELEASE-amd64-dvd1",
        Type = Type26.Public,
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

