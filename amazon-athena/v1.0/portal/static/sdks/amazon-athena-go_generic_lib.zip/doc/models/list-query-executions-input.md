
# List Query Executions Input

## Structure

`ListQueryExecutionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 0`, `<= 50` |
| `WorkGroup` | `*string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listQueryExecutionsInput := models.ListQueryExecutionsInput{
        NextToken:            models.ToPointer("NextToken2"),
        MaxResults:           models.ToPointer(34),
        WorkGroup:            models.ToPointer("WorkGroup4"),
    }

}
```

