
# Notebook Type

## Enumeration

`NotebookType`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```php
use AmazonAthenaLib\Models\NotebookType;

$notebookType = NotebookType::IPYNB;
```

