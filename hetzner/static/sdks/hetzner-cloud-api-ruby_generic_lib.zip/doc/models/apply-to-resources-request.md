
# Apply to Resources Request

## Structure

`ApplyToResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `apply_to` | [`Array[FirewallApplyToResources]`](../../doc/models/firewall-apply-to-resources.md) | Required | Resources the Firewall should be applied to |

## Example

```ruby
apply_to_resources_request = ApplyToResourcesRequest.new(
  [
    FirewallApplyToResources.new(
      LabelSelector5.new(
        'selector8'
      ),
      Server9.new(
        14
      ),
      Type7Enum::SERVER
    )
  ]
)
```

