# Vaults

Access 1Password Vaults

```python
vaults_api = client.vaults
```

## Class Name

`VaultsApi`

## Methods

* [Get Vaults](../../doc/controllers/vaults.md#get-vaults)
* [Get Vault by Id](../../doc/controllers/vaults.md#get-vault-by-id)


# Get Vaults

```python
def get_vaults(self,
              filter=None)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filter` | `str` | Query, Optional | Filter the Vault collection based on Vault name using SCIM eq filter |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`List[Vault]`](../../doc/models/vault.md).

## Example Usage

```python
filter = 'name eq "Some Vault Name"'

result = vaults_api.get_vaults(
    filter=filter
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Vault by Id

```python
def get_vault_by_id(self,
                   vault_uuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `str` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`Vault`](../../doc/models/vault.md).

## Example Usage

```python
vault_uuid = 'vaultUuid2'

result = vaults_api.get_vault_by_id(vault_uuid)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Vault not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

