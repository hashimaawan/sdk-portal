
# V2 Uptime Checks Alerts Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2UptimeChecksAlertsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alert` | [`Alerts1 \| undefined`](../../doc/models/alerts-1.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Comparison,
  Period,
  V2UptimeChecksAlertsResponse1,
} from 'digitalocean-apilib';

const v2UptimeChecksAlertsResponse1: V2UptimeChecksAlertsResponse1 = {
  alert: {
    id: '00002454-0000-0000-0000-000000000000',
    comparison: Comparison.GreaterThan,
    name: 'name0',
    notifications: {
      email: [
        'email4',
        'email3'
      ],
      slack: [
        {
          channel: 'channel6',
          url: 'url2',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          channel: 'channel6',
          url: 'url2',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        {
          channel: 'channel6',
          url: 'url2',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    period: Period.Enum30M,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

