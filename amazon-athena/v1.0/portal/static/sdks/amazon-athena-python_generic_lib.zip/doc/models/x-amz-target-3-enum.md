
# X Amz Target 3 Enum

## Enumeration

`XAmzTarget3Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEDATACATALOG` |

## Example

```python
from amazonathena.models.x_amz_target_3_enum import XAmzTarget3Enum

x_amz_target_3 = XAmzTarget3Enum.ENUM_AMAZONATHENACREATEDATACATALOG
```

