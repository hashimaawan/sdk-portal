
# Status 113

Current status of the Volume

## Enumeration

`Status113`

## Fields

| Name |
|  --- |
| `CREATING` |
| `AVAILABLE` |

## Example

```python
from hetznercloudapi.models.status_113 import Status113

status_113 = Status113.CREATING
```

