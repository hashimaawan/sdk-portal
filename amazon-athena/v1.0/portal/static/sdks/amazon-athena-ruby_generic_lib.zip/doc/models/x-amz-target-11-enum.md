
# X Amz Target 11 Enum

## Enumeration

`XAmzTarget11Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENOTEBOOK` |

## Example

```ruby
x_amz_target11 = XAmzTarget11Enum::ENUM_AMAZONATHENADELETENOTEBOOK
```

