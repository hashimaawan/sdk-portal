
# Session Statistics

Contains statistics for a session.

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `int` | Optional | - |

## Example

```python
from amazonathena.models.session_statistics import SessionStatistics

session_statistics = SessionStatistics(
    dpu_execution_in_millis=136
)
```

