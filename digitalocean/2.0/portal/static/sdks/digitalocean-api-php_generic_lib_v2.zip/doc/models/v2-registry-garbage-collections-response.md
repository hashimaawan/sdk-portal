
# V2 Registry Garbage Collections Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `garbageCollections` | [`?(GarbageCollection[])`](../../doc/models/garbage-collection.md) | Optional | - | getGarbageCollections(): ?array | setGarbageCollections(?array garbageCollections): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2RegistryGarbageCollectionsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\GarbageCollectionBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\Models\Status15;
use DigitalOceanApiLib\ApiHelper;

$v2RegistryGarbageCollectionsResponse = V2RegistryGarbageCollectionsResponseBuilder::init()
    ->garbageCollections(
        [
            GarbageCollectionBuilder::init()
                ->blobsDeleted(26)
                ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->freedBytes(100)
                ->registryName('registry_name2')
                ->status(Status15::REQUESTED)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

