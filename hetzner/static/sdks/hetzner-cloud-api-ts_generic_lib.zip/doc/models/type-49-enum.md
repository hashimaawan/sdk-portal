
# Type 49 Enum

The type of the Primary IP

## Enumeration

`Type49Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type49Enum } from 'hetzner-cloud-apilib';

const type49 = Type49Enum.Ipv4;
```

