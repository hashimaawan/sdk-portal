
# Delete Data Catalog Input

## Structure

`DeleteDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    deleteDataCatalogInput := models.DeleteDataCatalogInput{
        Name:                 "Name2",
    }

}
```

