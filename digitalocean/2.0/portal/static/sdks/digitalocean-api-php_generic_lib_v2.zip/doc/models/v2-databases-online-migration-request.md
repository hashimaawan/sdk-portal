
# V2 Databases Online Migration Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesOnlineMigrationRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `disableSsl` | `?bool` | Optional | Enables SSL encryption when connecting to the source database. | getDisableSsl(): ?bool | setDisableSsl(?bool disableSsl): void |
| `source` | [`?Source`](../../doc/models/source.md) | Optional | - | getSource(): ?Source | setSource(?Source source): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesOnlineMigrationRequestBuilder;
use DigitalOceanApiLib\Models\Builders\SourceBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesOnlineMigrationRequest = V2DatabasesOnlineMigrationRequestBuilder::init()
    ->disableSsl(false)
    ->source(
        SourceBuilder::init()
            ->database('database4')
            ->host('host4')
            ->password('password8')
            ->port(180)
            ->ssl(false)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

