
# Load Balancers Metrics Response

## Structure

`LoadBalancersMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `metrics` | [`Metrics`](../../doc/models/metrics.md) | Required | - |

## Example

```ruby
load_balancers_metrics_response = LoadBalancersMetricsResponse.new(
  Metrics.new(
    '2017-01-01T23:00:00+00:00',
    '2017-01-01T00:00:00+00:00',
    60,
    {
      'name_of_timeseries': TimeSeries.new(
        [
          [
            1435781470.622,
            '42'
          ],
          [
            1435781471.622,
            '43'
          ]
        ]
      )
    }
  )
)
```

