
# Get Calculation Execution Code Request

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```ruby
get_calculation_execution_code_request = GetCalculationExecutionCodeRequest.new(
  'CalculationExecutionId0'
)
```

