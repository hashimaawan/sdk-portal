
# Servers Actions Rebuild Response

## Structure

`ServersActionsRebuildResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `action` | [`?Action`](../../doc/models/action.md) | Optional | - | getAction(): ?Action | setAction(?Action action): void |
| `rootPassword` | `?string` | Optional | New root password when not using SSH keys | getRootPassword(): ?string | setRootPassword(?string rootPassword): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ServersActionsRebuildResponseBuilder;
use HetznerCloudAPILib\Models\Builders\ActionBuilder;
use HetznerCloudAPILib\Models\Builders\Resource2Builder;
use HetznerCloudAPILib\Models\StatusEnum;
use HetznerCloudAPILib\Models\Builders\ErrorBuilder;

$serversActionsRebuildResponse = ServersActionsRebuildResponseBuilder::init()
    ->action(
        ActionBuilder::init(
            'command6',
            238,
            143.26,
            [
                Resource2Builder::init(
                    198,
                    'type0'
                )->build(),
                Resource2Builder::init(
                    198,
                    'type0'
                )->build(),
                Resource2Builder::init(
                    198,
                    'type0'
                )->build()
            ],
            'started8',
            StatusEnum::RUNNING
        )
            ->error(
                ErrorBuilder::init(
                    'code2',
                    'message4'
                )->build()
            )
            ->finished('finished0')
            ->build()
    )
    ->rootPassword('root_password6')
    ->build();
```

