
# X Amz Target 46 Enum

## Enumeration

`XAmzTarget46Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartCalculationExecution` |

## Example

```ts
import { XAmzTarget46Enum } from 'amazon-athenalib';

const xAmzTarget46 = XAmzTarget46Enum.EnumAmazonAthenaStartCalculationExecution;
```

