
# Character Set

## Enumeration

`CharacterSet`

## Fields

| Name |
|  --- |
| `LETTERS` |
| `DIGITS` |
| `SYMBOLS` |

## Example

```ruby
character_set = CharacterSet::DIGITS
```

