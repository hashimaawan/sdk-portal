
# X Amz Target 10 Enum

## Enumeration

`XAmzTarget10Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENAMEDQUERY` |

## Example

```ruby
x_amz_target10 = XAmzTarget10Enum::ENUM_AMAZONATHENADELETENAMEDQUERY
```

