# Metrics

```csharp
MetricsApi metricsApi = client.MetricsApi;
```

## Class Name

`MetricsApi`


# Get Prometheus Metrics

See Prometheus documentation for a complete data model.

:information_source: **Note** This endpoint does not require authentication.

```csharp
GetPrometheusMetricsAsync()
```

## Response Type

**200**: Successfully returned Prometheus metrics

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type string.

## Example Usage

```csharp
try
{
    ApiResponse<string> result = await metricsApi.GetPrometheusMetricsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

