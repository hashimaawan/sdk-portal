
# X Amz Target 11 Enum

## Enumeration

`XAmzTarget11Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteNotebook` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget11Enum xAmzTarget11 = XAmzTarget11Enum.EnumAmazonAthenaDeleteNotebook;
```

