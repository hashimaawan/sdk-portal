
# Load Balancers Actions Change Protection Request

## Structure

`LoadBalancersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Delete` | `Boolean` | Optional | If true, prevents the Load Balancer from being deleted | Boolean getDelete() | setDelete(Boolean delete) |

## Example

```java
import cloud.hetzner.api.models.LoadBalancersActionsChangeProtectionRequest;

LoadBalancersActionsChangeProtectionRequest loadBalancersActionsChangeProtectionRequest = new LoadBalancersActionsChangeProtectionRequest.Builder()
    .delete(true)
    .build();
```

