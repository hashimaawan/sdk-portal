
# Status 2

## Enumeration

`Status2`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING` |
| `RUNNING` |
| `ERROR` |
| `SUCCESS` |

## Example

```php
use DigitalOceanApiLib\Models\Status2;

$status2 = Status2::PENDING;
```

