
# Size 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Size1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | A Droplet size available for use in a Kubernetes node pool. |
| `slug` | `string \| undefined` | Optional | The identifier for a size for use when creating a new cluster. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Size1 } from 'digitalocean-apilib';

const size1: Size1 = {
  name: 's-1vcpu-2gb',
  slug: 's-1vcpu-2gb',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

