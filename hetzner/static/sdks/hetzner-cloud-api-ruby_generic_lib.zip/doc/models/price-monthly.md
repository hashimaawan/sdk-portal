
# Price Monthly

Monthly costs for a Resource in this Location

## Structure

`PriceMonthly`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `String` | Required | Price with VAT added |
| `net` | `String` | Required | Price without VAT |

## Example

```ruby
price_monthly = PriceMonthly.new(
  '1.1900000000000000',
  '1.0000000000'
)
```

