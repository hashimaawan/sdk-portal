
# X Amz Target 56 Enum

## Enumeration

`XAmzTarget56Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNotebook` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget56Enum xAmzTarget56 = XAmzTarget56Enum.EnumAmazonAthenaUpdateNotebook;
```

