
# Datacenter 2

Datacenter this Primary IP is located at

*This model accepts additional fields of type Any.*

## Structure

`Datacenter2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Required | Description of the Datacenter |
| `id` | `int` | Required | ID of the Resource |
| `location` | [`Location`](../../doc/models/location.md) | Required | - |
| `name` | `str` | Required | Unique identifier of the Datacenter |
| `server_types` | [`ServerTypes`](../../doc/models/server-types.md) | Required | The Server types the Datacenter can handle |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.datacenter_2 import Datacenter2
from hetznercloudapi.models.location import Location
from hetznercloudapi.models.server_types import ServerTypes

datacenter_2 = Datacenter2(
    description='Falkenstein DC Park 8',
    id=42,
    location=Location(
        city='Falkenstein',
        country='DE',
        description='Falkenstein DC Park 1',
        id=1,
        latitude=50.47612,
        longitude=12.370071,
        name='fsn1',
        network_zone='eu-central',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    name='fsn1-dc8',
    server_types=ServerTypes(
        available=[
            1,
            2,
            3
        ],
        available_for_migration=[
            1,
            2,
            3
        ],
        supported=[
            1,
            2,
            3
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

