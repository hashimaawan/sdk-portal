
# Work Group State 1

The state of the workgroup.

## Enumeration

`WorkGroupState1`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```ts
import { WorkGroupState1 } from 'amazon-athenalib';

const workGroupState1 = WorkGroupState1.Enabled;
```

