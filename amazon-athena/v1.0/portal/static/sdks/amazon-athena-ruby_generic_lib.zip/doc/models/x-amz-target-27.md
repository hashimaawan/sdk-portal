
# X Amz Target 27

## Enumeration

`XAmzTarget27`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSIONSTATUS` |

## Example

```ruby
x_amz_target27 = XAmzTarget27::ENUM_AMAZONATHENAGETSESSIONSTATUS
```

