
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| furkotAuthAccessCodeCredentials | [`FurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |
| furkotAuthImplicitCredentials | [`FurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

```java
import com.furkot.trips.Environment;
import com.furkot.trips.FurkotTripsClient;
import com.furkot.trips.authentication.FurkotAuthAccessCodeModel;
import com.furkot.trips.authentication.FurkotAuthImplicitModel;
import com.furkot.trips.exceptions.ApiException;
import com.furkot.trips.models.OAuthScopeFurkotAuthAccessCodeEnum;
import com.furkot.trips.models.OAuthScopeFurkotAuthImplicitEnum;
import com.furkot.trips.models.OAuthToken;
import java.io.IOException;
import java.util.Arrays;

public class Program {
    public static void main(String[] args) {
        FurkotTripsClient client = new FurkotTripsClient.Builder()
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .furkotAuthAccessCodeCredentials(new FurkotAuthAccessCodeModel.Builder(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri"
                )
                .oAuthScopes(Arrays.asList(
                        OAuthScopeFurkotAuthAccessCodeEnum.READTRIPS
                    ))
                .build())
            .furkotAuthImplicitCredentials(new FurkotAuthImplicitModel.Builder(
                    "OAuthClientId",
                    "OAuthRedirectUri"
                )
                .oAuthScopes(Arrays.asList(
                        OAuthScopeFurkotAuthImplicitEnum.READTRIPS
                    ))
                .build())
            .environment(Environment.PRODUCTION)
            .build();

    }
}
```

## Furkot TripsClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getAPIController()` | Provides access to Client controller. | `APIController` |
| `getOAuthAuthorizationController()` | Provides access to OAuthAuthorization controller. | `OAuthAuthorizationController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getFurkotAuthAccessCodeCredentials()` | The credentials to use with FurkotAuthAccessCode. | [`FurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) |
| `getFurkotAuthImplicitCredentials()` | The credentials to use with FurkotAuthImplicit. | [`FurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

