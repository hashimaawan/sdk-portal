
# Os Flavor

Flavor of operating system contained in the Image

## Enumeration

`OsFlavor`

## Fields

| Name |
|  --- |
| `UBUNTU` |
| `CENTOS` |
| `DEBIAN` |
| `FEDORA` |
| `UNKNOWN` |

## Example

```python
from hetznercloudapi.models.os_flavor import OsFlavor

os_flavor = OsFlavor.UNKNOWN
```

