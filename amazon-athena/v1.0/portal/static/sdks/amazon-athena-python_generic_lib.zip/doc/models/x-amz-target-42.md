
# X Amz Target 42

## Enumeration

`XAmzTarget42`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTSESSIONS` |

## Example

```python
from amazonathena.models.x_amz_target_42 import XAmzTarget42

x_amz_target_42 = XAmzTarget42.ENUM_AMAZONATHENALISTSESSIONS
```

