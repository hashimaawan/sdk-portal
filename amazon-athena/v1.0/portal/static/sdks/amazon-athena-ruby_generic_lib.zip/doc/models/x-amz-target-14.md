
# X Amz Target 14

## Enumeration

`XAmzTarget14`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAEXPORTNOTEBOOK` |

## Example

```ruby
x_amz_target14 = XAmzTarget14::ENUM_AMAZONATHENAEXPORTNOTEBOOK
```

