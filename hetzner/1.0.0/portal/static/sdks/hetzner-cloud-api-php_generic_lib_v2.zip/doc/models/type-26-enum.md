
# Type 26 Enum

Type of the ISO

## Enumeration

`Type26Enum`

## Fields

| Name |
|  --- |
| `PUBLIC_` |
| `PRIVATE_` |

## Example

```php
use HetznerCloudAPILib\Models\Type26Enum;

$type26 = Type26Enum::PUBLIC_;
```

