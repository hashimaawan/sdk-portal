
# X Amz Target 9 Enum

## Enumeration

`XAmzTarget9Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEDATACATALOG` |

## Example

```ruby
x_amz_target9 = XAmzTarget9Enum::ENUM_AMAZONATHENADELETEDATACATALOG
```

