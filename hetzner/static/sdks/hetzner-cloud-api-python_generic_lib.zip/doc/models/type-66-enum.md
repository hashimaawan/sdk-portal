
# Type 66 Enum

## Enumeration

`Type66Enum`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```python
from hetznercloudapi.models.type_66_enum import Type66Enum

type_66 = Type66Enum.DISK
```

