
# Type 6

Type of resource referenced

## Enumeration

`Type6`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type6 := models.Type6_Server

}
```

