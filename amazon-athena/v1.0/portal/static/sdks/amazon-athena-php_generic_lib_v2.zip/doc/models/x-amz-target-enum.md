
# X Amz Target Enum

## Enumeration

`XAmzTargetEnum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTargetEnum;

$xAmzTarget = XAmzTargetEnum::ENUM_AMAZONATHENABATCHGETNAMEDQUERY;
```

