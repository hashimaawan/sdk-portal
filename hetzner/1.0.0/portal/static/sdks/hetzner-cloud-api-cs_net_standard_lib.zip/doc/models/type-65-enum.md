
# Type 65 Enum

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65Enum`

## Fields

| Name |
|  --- |
| `Linux64` |
| `Linux32` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type65Enum type65 = Type65Enum.Linux64;
```

