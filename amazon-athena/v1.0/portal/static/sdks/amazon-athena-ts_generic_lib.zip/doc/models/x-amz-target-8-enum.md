
# X Amz Target 8 Enum

## Enumeration

`XAmzTarget8Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateWorkGroup` |

## Example

```ts
import { XAmzTarget8Enum } from 'amazon-athenalib';

const xAmzTarget8 = XAmzTarget8Enum.EnumAmazonAthenaCreateWorkGroup;
```

