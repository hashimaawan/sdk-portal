
# Load Balancers Metrics Response

## Structure

`LoadBalancersMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Metrics` | [`Metrics`](../../doc/models/metrics.md) | Required | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using HetznerCloudAPI.Standard.Models.Containers;
using System.Collections.Generic;

LoadBalancersMetricsResponse loadBalancersMetricsResponse = new LoadBalancersMetricsResponse
{
    Metrics = new Metrics
    {
        End = "2017-01-01T23:00:00+00:00",
        Start = "2017-01-01T00:00:00+00:00",
        Step = 60,
        TimeSeries = new Dictionary<string, TimeSeries>
        {
            ["name_of_timeseries"] = new TimeSeries
            {
                Values = new List<List<TimeSeriesValues>>
                {
                    new List<TimeSeriesValues>
                    {
                        TimeSeriesValues.FromPrecision(1435781470.622),
                        TimeSeriesValues.FromString("42"),
                    },
                    new List<TimeSeriesValues>
                    {
                        TimeSeriesValues.FromPrecision(1435781471.622),
                        TimeSeriesValues.FromString("43"),
                    },
                },
            },
        },
    },
};
```

