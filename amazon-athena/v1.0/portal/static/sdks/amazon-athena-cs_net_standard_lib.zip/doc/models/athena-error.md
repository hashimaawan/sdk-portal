
# Athena Error

Provides information about an Athena query error. The <code>AthenaError</code> feature provides standardized error information to help you understand failed queries and take steps after a query failure occurs. <code>AthenaError</code> includes an <code>ErrorCategory</code> field that specifies whether the cause of the failed query is due to system error, user error, or other error.

*This model accepts additional fields of type object.*

## Structure

`AthenaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorCategory` | `int?` | Optional | **Constraints**: `>= 1`, `<= 3` |
| `ErrorType` | `int?` | Optional | **Constraints**: `>= 0`, `<= 9999` |
| `Retryable` | `bool?` | Optional | - |
| `ErrorMessage` | `string` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

AthenaError athenaError = new AthenaError
{
    ErrorCategory = 3,
    ErrorType = 238,
    Retryable = false,
    ErrorMessage = "ErrorMessage0",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

