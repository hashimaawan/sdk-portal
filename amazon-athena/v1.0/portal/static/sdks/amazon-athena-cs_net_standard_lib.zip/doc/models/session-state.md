
# Session State

## Enumeration

`SessionState`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Idle` |
| `Busy` |
| `Terminating` |
| `Terminated` |
| `Degraded` |
| `Failed` |

## Example

```csharp
using AmazonAthena.Standard.Models;

SessionState sessionState = SessionState.Terminating;
```

