
# Executor State

## Enumeration

`ExecutorState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```java
import com.amazonaws.useast1.athena.models.ExecutorState;

ExecutorState executorState = ExecutorState.TERMINATED;
```

