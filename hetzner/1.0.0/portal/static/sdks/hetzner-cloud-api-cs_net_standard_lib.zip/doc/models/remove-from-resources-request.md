
# Remove from Resources Request

## Structure

`RemoveFromResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RemoveFrom` | [`List<FirewallRemoveFromResources>`](../../doc/models/firewall-remove-from-resources.md) | Required | Resources the Firewall should be removed from |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

RemoveFromResourcesRequest removeFromResourcesRequest = new RemoveFromResourcesRequest
{
    RemoveFrom = new List<FirewallRemoveFromResources>
    {
        new FirewallRemoveFromResources
        {
            LabelSelector = new LabelSelector5
            {
                Selector = "selector8",
            },
            Server = new Server9
            {
                Id = 14,
            },
            Type = Type7Enum.Server,
        },
    },
};
```

