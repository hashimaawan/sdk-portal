
# Overages

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Overages`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `str` | Optional | Total amount charged in USD |
| `name` | `str` | Optional | Name of the charge |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.overages import Overages

overages = Overages(
    amount='3.45',
    name='Overages',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

