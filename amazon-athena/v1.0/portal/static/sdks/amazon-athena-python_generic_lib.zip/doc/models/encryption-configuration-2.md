
# Encryption Configuration 2

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryption_option` | [`EncryptionOption1Enum`](../../doc/models/encryption-option-1-enum.md) | Required | - |
| `kms_key` | `str` | Optional | - |

## Example

```python
from amazonathena.models.encryption_configuration_2 import EncryptionConfiguration2
from amazonathena.models.encryption_option_1_enum import EncryptionOption1Enum

encryption_configuration_2 = EncryptionConfiguration2(
    encryption_option=EncryptionOption1Enum.CSE_KMS,
    kms_key='KmsKey4'
)
```

