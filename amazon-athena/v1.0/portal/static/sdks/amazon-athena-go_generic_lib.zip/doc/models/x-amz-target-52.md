
# X Amz Target 52

## Enumeration

`XAmzTarget52`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaterminatesession` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget52 := models.XAmzTarget52_EnumAmazonathenaterminatesession

}
```

