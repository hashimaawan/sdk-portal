# Load Balancer Types

```csharp
LoadBalancerTypesApi loadBalancerTypesApi = client.LoadBalancerTypesApi;
```

## Class Name

`LoadBalancerTypesApi`

## Methods

* [Get All Load Balancer Types](../../doc/controllers/load-balancer-types.md#get-all-load-balancer-types)
* [Get a Load Balancer Type](../../doc/controllers/load-balancer-types.md#get-a-load-balancer-type)


# Get All Load Balancer Types

Gets all Load Balancer type objects.

```csharp
GetAllLoadBalancerTypesAsync(
    string name = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Query, Optional | Can be used to filter Load Balancer types by their name. The response will only contain the Load Balancer type matching the specified name. |

## Response Type

**200**: The `load_balancer_types` key in the reply contains an array of Load Balancer type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.LoadBalancerTypesResponse](../../doc/models/load-balancer-types-response.md).

## Example Usage

```csharp
try
{
    ApiResponse<LoadBalancerTypesResponse> result = await loadBalancerTypesApi.GetAllLoadBalancerTypesAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Load Balancer Type

Gets a specific Load Balancer type object.

```csharp
GetALoadBalancerTypeAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Load Balancer type |

## Response Type

**200**: The `load_balancer_type` key in the reply contains a Load Balancer type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.LoadBalancerTypesResponse1](../../doc/models/load-balancer-types-response-1.md).

## Example Usage

```csharp
int id = 112;
try
{
    ApiResponse<LoadBalancerTypesResponse1> result = await loadBalancerTypesApi.GetALoadBalancerTypeAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

