
# X Amz Target 55 Enum

## Enumeration

`XAmzTarget55Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNamedQuery` |

## Example

```ts
import { XAmzTarget55Enum } from 'amazon-athenalib';

const xAmzTarget55 = XAmzTarget55Enum.EnumAmazonAthenaUpdateNamedQuery;
```

