
# V2 Volumes Actions Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2VolumesActionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action4`](../../doc/models/action-4.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_volumes_actions_response = V2VolumesActionsResponse.new(
  action: Action4.new(
    resource_id: 66,
    type: 'type2',
    completed_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    id: 238,
    region: Region.new(
      available: false,
      features: [
        'features7',
        'features8',
        'features9'
      ],
      name: 'name6',
      sizes: [
        'sizes6'
      ],
      slug: 'slug0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

