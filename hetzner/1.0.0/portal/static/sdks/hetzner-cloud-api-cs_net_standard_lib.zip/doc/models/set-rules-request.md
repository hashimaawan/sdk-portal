
# Set Rules Request

## Structure

`SetRulesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rules` | [`List<Rule>`](../../doc/models/rule.md) | Required | Array of rules<br><br>**Constraints**: *Maximum Items*: `50` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

SetRulesRequest setRulesRequest = new SetRulesRequest
{
    Rules = new List<Rule>
    {
        new Rule
        {
            Direction = DirectionEnum.In,
            Protocol = ProtocolEnum.Udp,
            Description = "description2",
            DestinationIps = new List<string>
            {
                "28.239.13.1/32",
                "28.239.14.0/24",
                "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
            },
            Port = "80",
            SourceIps = new List<string>
            {
                "28.239.13.1/32",
                "28.239.14.0/24",
                "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
            },
        },
    },
};
```

