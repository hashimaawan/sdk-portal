
# Type 51 Enum

Primary IP type

## Enumeration

`Type51Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_51_enum import Type51Enum

type_51 = Type51Enum.IPV4
```

