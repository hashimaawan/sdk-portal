
# Update Image Request

## Structure

`UpdateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string \| undefined` | Optional | New description of Image |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `type` | [`Type24Enum \| undefined`](../../doc/models/type-24-enum.md) | Optional | Destination Image type to convert to |

## Example

```ts
import { Type24Enum, UpdateImageRequest } from 'hetzner-cloud-apilib';

const updateImageRequest: UpdateImageRequest = {
  description: 'My new Image description',
  labels: { 'labelkey': 'value' },
  type: Type24Enum.Snapshot,
};
```

