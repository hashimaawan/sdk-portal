
# Op

## Enumeration

`Op`

## Fields

| Name |
|  --- |
| `Add` |
| `Remove` |
| `Replace` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

Op op = Op.Remove;
```

