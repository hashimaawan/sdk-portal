
# Parameter Status

## Enumeration

`ParameterStatus`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ERROR` |

## Example

```php
use HetznerCloudApiLib\Models\ParameterStatus;

$parameterStatus = ParameterStatus::ERROR;
```

