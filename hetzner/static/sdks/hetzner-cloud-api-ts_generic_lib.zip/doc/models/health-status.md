
# Health Status

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listenPort` | `number \| undefined` | Optional | - |
| `status` | [`Status30Enum \| undefined`](../../doc/models/status-30-enum.md) | Optional | - |

## Example

```ts
import { HealthStatus, Status30Enum } from 'hetzner-cloud-apilib';

const healthStatus: HealthStatus = {
  listenPort: 443,
  status: Status30Enum.Healthy,
};
```

