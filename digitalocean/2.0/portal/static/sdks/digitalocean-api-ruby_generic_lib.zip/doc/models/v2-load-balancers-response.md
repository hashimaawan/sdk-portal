
# V2 Load Balancers Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2LoadBalancersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `load_balancers` | [`Array[LoadBalancer1]`](../../doc/models/load-balancer-1.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_load_balancers_response = V2LoadBalancersResponse.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  load_balancers: [
    LoadBalancer1.new(
      forwarding_rules: [
        ForwardingRule.new(
          entry_port: 220,
          entry_protocol: EntryProtocol::HTTP2,
          target_port: 104,
          target_protocol: TargetProtocol::HTTPS,
          certificate_id: 'certificate_id4',
          tls_passthrough: false,
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      algorithm: Algorithm::ROUND_ROBIN,
      created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      disable_lets_encrypt_dns_records: false,
      enable_backend_keepalive: false,
      enable_proxy_protocol: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    LoadBalancer1.new(
      forwarding_rules: [
        ForwardingRule.new(
          entry_port: 220,
          entry_protocol: EntryProtocol::HTTP2,
          target_port: 104,
          target_protocol: TargetProtocol::HTTPS,
          certificate_id: 'certificate_id4',
          tls_passthrough: false,
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      algorithm: Algorithm::ROUND_ROBIN,
      created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      disable_lets_encrypt_dns_records: false,
      enable_backend_keepalive: false,
      enable_proxy_protocol: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    LoadBalancer1.new(
      forwarding_rules: [
        ForwardingRule.new(
          entry_port: 220,
          entry_protocol: EntryProtocol::HTTP2,
          target_port: 104,
          target_protocol: TargetProtocol::HTTPS,
          certificate_id: 'certificate_id4',
          tls_passthrough: false,
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      algorithm: Algorithm::ROUND_ROBIN,
      created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      disable_lets_encrypt_dns_records: false,
      enable_backend_keepalive: false,
      enable_proxy_protocol: false,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

