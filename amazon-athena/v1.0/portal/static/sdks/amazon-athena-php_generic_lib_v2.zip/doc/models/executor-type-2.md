
# Executor Type 2

The type of executor used for the application (<code>COORDINATOR</code>, <code>GATEWAY</code>, or <code>WORKER</code>).

## Enumeration

`ExecutorType2`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```php
use AmazonAthenaLib\Models\ExecutorType2;

$executorType2 = ExecutorType2::COORDINATOR;
```

