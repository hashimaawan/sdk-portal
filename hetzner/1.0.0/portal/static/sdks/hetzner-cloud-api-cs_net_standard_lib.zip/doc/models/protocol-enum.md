
# Protocol Enum

Type of traffic to allow

## Enumeration

`ProtocolEnum`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Udp` |
| `Icmp` |
| `Esp` |
| `Gre` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ProtocolEnum protocol = ProtocolEnum.Esp;
```

