
# Sort 2 Enum

## Enumeration

`Sort2Enum`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```ts
import { Sort2Enum } from 'hetzner-cloud-apilib';

const sort2 = Sort2Enum.EnumCreatedasc;
```

