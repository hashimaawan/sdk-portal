
# X Amz Target 19

## Enumeration

`XAmzTarget19`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATABASE` |

## Example

```python
from amazonathena.models.x_amz_target_19 import XAmzTarget19

x_amz_target_19 = XAmzTarget19.ENUM_AMAZONATHENAGETDATABASE
```

