
# Unprocessed Prepared Statement Name

The name of a prepared statement that could not be returned.

## Structure

`UnprocessedPreparedStatementName`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statement_name` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `error_code` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `error_message` | `str` | Optional | - |

## Example

```python
from amazonathena.models.unprocessed_prepared_statement_name import UnprocessedPreparedStatementName

unprocessed_prepared_statement_name = UnprocessedPreparedStatementName(
    statement_name='StatementName8',
    error_code='ErrorCode0',
    error_message='ErrorMessage0'
)
```

