
# Firewall 4

## Structure

`Firewall4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewall` | `int` | Optional | ID of the Firewall |

## Example

```python
from hetznercloudapi.models.firewall_4 import Firewall4

firewall_4 = Firewall4(
    firewall=108
)
```

