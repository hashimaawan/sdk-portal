
# Get Named Query Output

*This model accepts additional fields of type Object.*

## Structure

`GetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query` | [`NamedQuery1`](../../doc/models/named-query-1.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_named_query_output = GetNamedQueryOutput.new(
  named_query: NamedQuery1.new(
    name: 'Name0',
    database: 'Database8',
    query_string: 'QueryString2',
    description: 'Description6',
    named_query_id: 'NamedQueryId2',
    work_group: 'WorkGroup2',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

