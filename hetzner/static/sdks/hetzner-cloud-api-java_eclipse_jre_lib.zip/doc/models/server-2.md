
# Server 2

Configuration for type Server, required if type is `server`

## Structure

`Server2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server | int getId() | setId(int id) |

## Example

```java
import cloud.hetzner.api.models.Server2;

Server2 server2 = new Server2.Builder(
    162
)
.build();
```

