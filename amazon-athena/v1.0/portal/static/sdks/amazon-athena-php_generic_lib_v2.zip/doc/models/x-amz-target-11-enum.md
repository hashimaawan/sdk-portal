
# X Amz Target 11 Enum

## Enumeration

`XAmzTarget11Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget11Enum;

$xAmzTarget11 = XAmzTarget11Enum::ENUM_AMAZONATHENADELETENOTEBOOK;
```

