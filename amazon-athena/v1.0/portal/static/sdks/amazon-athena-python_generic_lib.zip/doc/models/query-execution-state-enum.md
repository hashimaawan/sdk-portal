
# Query Execution State Enum

## Enumeration

`QueryExecutionStateEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```python
from amazonathena.models.query_execution_state_enum import QueryExecutionStateEnum

query_execution_state = QueryExecutionStateEnum.SUCCEEDED
```

