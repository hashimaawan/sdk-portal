
# Get Session Status Request

## Structure

`GetSessionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ts
import { GetSessionStatusRequest } from 'amazon-athenalib';

const getSessionStatusRequest: GetSessionStatusRequest = {
  sessionId: 'SessionId6',
};
```

