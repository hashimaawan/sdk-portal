
# Label Selector 5

Configuration for type label_selector, required if type is `label_selector`

## Structure

`LabelSelector5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LabelSelector5 labelSelector5 = new LabelSelector5
{
    Selector = "env=prod",
};
```

