
# Start Calculation Execution Response

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `state` | [`CalculationExecutionState4Enum \| undefined`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```ts
import {
  CalculationExecutionState4Enum,
  StartCalculationExecutionResponse,
} from 'amazon-athenalib';

const startCalculationExecutionResponse: StartCalculationExecutionResponse = {
  calculationExecutionId: 'CalculationExecutionId0',
  state: CalculationExecutionState4Enum.CANCELING,
};
```

