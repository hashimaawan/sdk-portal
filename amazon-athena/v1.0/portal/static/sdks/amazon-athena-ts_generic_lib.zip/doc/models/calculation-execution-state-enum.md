
# Calculation Execution State Enum

## Enumeration

`CalculationExecutionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```ts
import { CalculationExecutionStateEnum } from 'amazon-athenalib';

const calculationExecutionState = CalculationExecutionStateEnum.COMPLETED;
```

