# Certificates

TLS/SSL Certificates prove the identity of a Server and are used to encrypt client traffic.

```php
$certificatesController = $client->getCertificatesController();
```

## Class Name

`CertificatesController`

## Methods

* [Get All Certificates](../../doc/controllers/certificates.md#get-all-certificates)
* [Create a Certificate](../../doc/controllers/certificates.md#create-a-certificate)
* [Delete a Certificate](../../doc/controllers/certificates.md#delete-a-certificate)
* [Get a Certificate](../../doc/controllers/certificates.md#get-a-certificate)
* [Update a Certificate](../../doc/controllers/certificates.md#update-a-certificate)


# Get All Certificates

Returns all Certificate objects.

```php
function getAllCertificates(
    ?string $sort = null,
    ?string $name = null,
    ?string $labelSelector = null,
    ?string $type = null
): CertificatesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`?string(SortEnum)`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `?string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `?string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `type` | [`?string(ParameterTypeEnum)`](../../doc/models/parameter-type-enum.md) | Query, Optional | Can be used multiple times. The response will only contain Certificates matching the type. |

## Response Type

**200**: The `certificates` key contains an array of Certificate objects

[`CertificatesResponse`](../../doc/models/certificates-response.md)

## Example Usage

```php
$certificatesController = $client->getCertificatesController();

try {
    $result = $certificatesController->getAllCertificates();
    echo 'CertificatesResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "certificates": [
    {
      "certificate": "-----BEGIN CERTIFICATE-----\n...",
      "created": "2019-01-08T12:10:00+00:00",
      "domain_names": [
        "example.com",
        "webmail.example.com",
        "www.example.com"
      ],
      "fingerprint": "03:c7:55:9b:2a:d1:04:17:09:f6:d0:7f:18:34:63:d4:3e:5f",
      "id": 897,
      "labels": {
        "env": "dev"
      },
      "name": "my website cert",
      "not_valid_after": "2019-07-08T09:59:59+00:00",
      "not_valid_before": "2019-01-08T10:00:00+00:00",
      "status": null,
      "type": "uploaded",
      "used_by": [
        {
          "id": 4711,
          "type": "load_balancer"
        }
      ]
    }
  ]
}
```


# Create a Certificate

Creates a new Certificate.

The default type **uploaded** allows for uploading your existing `certificate` and `private_key` in PEM format. You have to monitor its expiration date and handle renewal yourself.

In contrast, type **managed** requests a new Certificate from *Let's Encrypt* for the specified `domain_names`. Only domains managed by *Hetzner DNS* are supported. We handle renewal and timely alert the project owner via email if problems occur.

For type `managed` Certificates the `action` key of the response contains the Action that allows for tracking the issuance process. For type `uploaded` Certificates the `action` is always null.

```php
function createACertificate(?CreateCertificateRequest $body = null): CreateCertificateResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?CreateCertificateRequest`](../../doc/models/create-certificate-request.md) | Body, Optional | - |

## Response Type

**201**: The `certificate` key contains the Certificate that was just created. For type `managed` Certificates the `action` key contains the Action that allows for tracking the issuance process. For type `uploaded` Certificates the `action` is always null.

[`CreateCertificateResponse`](../../doc/models/create-certificate-response.md)

## Example Usage

```php
$body = CreateCertificateRequestBuilder::init(
    'my website cert'
)
    ->domainNames(
        [
            'example.com',
            'webmail.example.com',
            'www.example.com'
        ]
    )
    ->type(Type1Enum::MANAGED)
    ->build();

$certificatesController = $client->getCertificatesController();

try {
    $result = $certificatesController->createACertificate($body);
    echo 'CreateCertificateResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_certificate",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 879,
        "type": "certificate"
      }
    ],
    "started": "2019-01-08T12:10:00+00:00",
    "status": "running"
  },
  "certificate": {
    "certificate": null,
    "created": "2019-01-08T12:10:00+00:00",
    "domain_names": [
      "example.com",
      "webmail.example.com",
      "www.example.com"
    ],
    "fingerprint": null,
    "id": 897,
    "labels": {
      "env": "dev"
    },
    "name": "my website cert",
    "not_valid_after": null,
    "not_valid_before": null,
    "status": {
      "error": null,
      "issuance": "pending",
      "renewal": "unavailable"
    },
    "type": "managed",
    "used_by": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ]
  }
}
```


# Delete a Certificate

Deletes a Certificate.

```php
function deleteACertificate(int $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Certificate deleted

`void`

## Example Usage

```php
$id = 112;

$certificatesController = $client->getCertificatesController();

try {
    $certificatesController->deleteACertificate($id);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get a Certificate

Gets a specific Certificate object.

```php
function getACertificate(int $id): CertificateResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `certificate` key contains a Certificate object

[`CertificateResponse`](../../doc/models/certificate-response.md)

## Example Usage

```php
$id = 112;

$certificatesController = $client->getCertificatesController();

try {
    $result = $certificatesController->getACertificate($id);
    echo 'CertificateResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "certificate": {
    "certificate": "-----BEGIN CERTIFICATE-----\n...",
    "created": "2019-01-08T12:10:00+00:00",
    "domain_names": [
      "example.com",
      "webmail.example.com",
      "www.example.com"
    ],
    "fingerprint": "03:c7:55:9b:2a:d1:04:17:09:f6:d0:7f:18:34:63:d4:3e:5f",
    "id": 897,
    "labels": {
      "env": "dev"
    },
    "name": "my website cert",
    "not_valid_after": "2019-07-08T09:59:59+00:00",
    "not_valid_before": "2019-01-08T10:00:00+00:00",
    "status": null,
    "type": "uploaded",
    "used_by": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ]
  }
}
```


# Update a Certificate

Updates the Certificate properties.

Note that when updating labels, the Certificate’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the Certificate object changes during the request, the response will be a “conflict” error.

```php
function updateACertificate(int $id, ?UpdateCertificateRequest $body = null): CertificateResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`?UpdateCertificateRequest`](../../doc/models/update-certificate-request.md) | Body, Optional | - |

## Response Type

**200**: The `certificate` key contains the Certificate that was just updated

[`CertificateResponse`](../../doc/models/certificate-response.md)

## Example Usage

```php
$id = 112;

$body = UpdateCertificateRequestBuilder::init()
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('my website cert')
    ->build();

$certificatesController = $client->getCertificatesController();

try {
    $result = $certificatesController->updateACertificate(
        $id,
        $body
    );
    echo 'CertificateResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "certificate": {
    "certificate": "-----BEGIN CERTIFICATE-----\n...",
    "created": "2019-01-08T12:10:00+00:00",
    "domain_names": [
      "example.com",
      "webmail.example.com",
      "www.example.com"
    ],
    "fingerprint": "03:c7:55:9b:2a:d1:04:17:09:f6:d0:7f:18:34:63:d4:3e:5f",
    "id": 897,
    "labels": {
      "labelkey": "value"
    },
    "name": "my website cert",
    "not_valid_after": "2019-07-08T09:59:59+00:00",
    "not_valid_before": "2019-01-08T10:00:00+00:00",
    "status": null,
    "type": "uploaded",
    "used_by": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ]
  }
}
```

