
# Algorithm

Algorithm of the Load Balancer

*This model accepts additional fields of type Any.*

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type28`](../../doc/models/type-28.md) | Required | Type of the algorithm |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.algorithm import Algorithm
from hetznercloudapi.models.type_28 import Type28

algorithm = Algorithm(
    mtype=Type28.ROUND_ROBIN,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

