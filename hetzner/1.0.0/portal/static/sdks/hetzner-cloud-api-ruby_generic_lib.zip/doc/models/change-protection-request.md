
# Change Protection Request

*This model accepts additional fields of type Object.*

## Structure

`ChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Floating IP from being deleted |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
change_protection_request = ChangeProtectionRequest.new(
  delete: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

