
# Executors Summary

Contains summary information about an executor.

## Structure

`ExecutorsSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ExecutorId` | `String` | Required | **Constraints**: *Maximum Length*: `100000`, *Pattern*: `.*` | String getExecutorId() | setExecutorId(String executorId) |
| `ExecutorType` | [`ExecutorType2Enum`](../../doc/models/executor-type-2-enum.md) | Optional | - | ExecutorType2Enum getExecutorType() | setExecutorType(ExecutorType2Enum executorType) |
| `StartDateTime` | `Integer` | Optional | - | Integer getStartDateTime() | setStartDateTime(Integer startDateTime) |
| `TerminationDateTime` | `Integer` | Optional | - | Integer getTerminationDateTime() | setTerminationDateTime(Integer terminationDateTime) |
| `ExecutorState` | [`ExecutorState3Enum`](../../doc/models/executor-state-3-enum.md) | Optional | - | ExecutorState3Enum getExecutorState() | setExecutorState(ExecutorState3Enum executorState) |
| `ExecutorSize` | `Integer` | Optional | - | Integer getExecutorSize() | setExecutorSize(Integer executorSize) |

## Example

```java
import com.amazonaws.useast1.athena.models.ExecutorState3Enum;
import com.amazonaws.useast1.athena.models.ExecutorType2Enum;
import com.amazonaws.useast1.athena.models.ExecutorsSummary;

ExecutorsSummary executorsSummary = new ExecutorsSummary.Builder(
    "ExecutorId8"
)
.executorType(ExecutorType2Enum.WORKER)
.startDateTime(52)
.terminationDateTime(56)
.executorState(ExecutorState3Enum.CREATING)
.executorSize(222)
.build();
```

