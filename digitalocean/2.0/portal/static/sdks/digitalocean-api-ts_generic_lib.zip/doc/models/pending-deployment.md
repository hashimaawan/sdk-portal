
# Pending Deployment

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`PendingDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cause` | `string \| undefined` | Optional | - |
| `clonedFrom` | `string \| undefined` | Optional | - |
| `createdAt` | `string \| undefined` | Optional | - |
| `functions` | [`FunctionsComponentsThatArePartOfThisDeployment[] \| undefined`](../../doc/models/functions-components-that-are-part-of-this-deployment.md) | Optional | - |
| `id` | `string \| undefined` | Optional | - |
| `jobs` | [`JobComponentsThatArePartOfThisDeployment[] \| undefined`](../../doc/models/job-components-that-are-part-of-this-deployment.md) | Optional | - |
| `phase` | [`Phase \| undefined`](../../doc/models/phase.md) | Optional | **Default**: `Phase.Unknown` |
| `phaseLastUpdatedAt` | `string \| undefined` | Optional | - |
| `progress` | [`Progress \| undefined`](../../doc/models/progress.md) | Optional | - |
| `services` | [`ServiceComponentsThatArePartOfThisDeployment[] \| undefined`](../../doc/models/service-components-that-are-part-of-this-deployment.md) | Optional | - |
| `spec` | [`AppSpec \| undefined`](../../doc/models/app-spec.md) | Optional | The desired configuration of an application. |
| `staticSites` | [`StaticSiteComponentsThatArePartOfThisDeployment[] \| undefined`](../../doc/models/static-site-components-that-are-part-of-this-deployment.md) | Optional | - |
| `tierSlug` | `string \| undefined` | Optional, Read-only | - |
| `updatedAt` | `string \| undefined` | Optional | - |
| `workers` | [`WorkerComponentsThatArePartOfThisDeployment[] \| undefined`](../../doc/models/worker-components-that-are-part-of-this-deployment.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { PendingDeployment, Phase } from 'digitalocean-apilib';

const pendingDeployment: PendingDeployment = {
  cause: 'commit 9a4df0b pushed to github/digitalocean/sample-golang',
  clonedFrom: '3aa4d20e-5527-4c00-b496-601fbd22520a',
  createdAt: '2020-07-28T18:00:00Z',
  functions: [
    {
      name: 'name4',
      namespace: 'namespace8',
      sourceCommitHash: 'source_commit_hash4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  id: 'b6bdf840-2854-4f87-a36c-5f231c617c84',
  phase: Phase.Active,
  phaseLastUpdatedAt: '0001-01-01T00:00:00Z',
  tierSlug: 'basic',
  updatedAt: '2020-07-28T18:00:00Z',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

