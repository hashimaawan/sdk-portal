
# State 2

A string indicating the current status of the cluster.

## Enumeration

`State2`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `PROVISIONING` |
| `DEGRADED` |
| `ERROR` |
| `DELETED` |
| `UPGRADING` |
| `DELETING` |

## Example

```php
use DigitalOceanApiLib\Models\State2;

$state2 = State2::DELETING;
```

