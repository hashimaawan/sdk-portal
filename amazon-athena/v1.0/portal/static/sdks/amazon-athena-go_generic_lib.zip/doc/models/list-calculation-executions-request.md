
# List Calculation Executions Request

## Structure

`ListCalculationExecutionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `StateFilter` | [`*models.CalculationExecutionState3Enum`](../../doc/models/calculation-execution-state-3-enum.md) | Optional | - |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `*string` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listCalculationExecutionsRequest := models.ListCalculationExecutionsRequest{
        SessionId:            "SessionId2",
        StateFilter:          models.ToPointer(models.CalculationExecutionState3Enum_QUEUED),
        MaxResults:           models.ToPointer(100),
        NextToken:            models.ToPointer("NextToken0"),
    }

}
```

