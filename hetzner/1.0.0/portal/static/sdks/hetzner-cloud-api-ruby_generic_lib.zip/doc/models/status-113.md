
# Status 113

Current status of the Volume

## Enumeration

`Status113`

## Fields

| Name |
|  --- |
| `CREATING` |
| `AVAILABLE` |

## Example

```ruby
status113 = Status113::CREATING
```

