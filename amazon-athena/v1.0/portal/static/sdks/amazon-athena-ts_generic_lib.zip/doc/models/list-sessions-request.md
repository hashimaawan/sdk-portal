
# List Sessions Request

## Structure

`ListSessionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `stateFilter` | [`SessionState3Enum \| undefined`](../../doc/models/session-state-3-enum.md) | Optional | - |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```ts
import { ListSessionsRequest, SessionState3Enum } from 'amazon-athenalib';

const listSessionsRequest: ListSessionsRequest = {
  workGroup: 'WorkGroup8',
  stateFilter: SessionState3Enum.CREATING,
  maxResults: 100,
  nextToken: 'NextToken6',
};
```

