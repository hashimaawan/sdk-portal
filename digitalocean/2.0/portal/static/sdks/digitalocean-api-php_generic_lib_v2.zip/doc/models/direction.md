
# Direction

## Enumeration

`Direction`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```php
use DigitalOceanApiLib\Models\Direction;

$direction = Direction::INBOUND;
```

