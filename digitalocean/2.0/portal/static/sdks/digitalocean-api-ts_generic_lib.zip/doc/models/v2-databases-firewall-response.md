
# V2 Databases Firewall Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesFirewallResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rules` | [`Rule1[] \| undefined`](../../doc/models/rule-1.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type7, V2DatabasesFirewallResponse } from 'digitalocean-apilib';

const v2DatabasesFirewallResponse: V2DatabasesFirewallResponse = {
  rules: [
    {
      type: Type7.IpAddr,
      value: 'value0',
      clusterUuid: 'cluster_uuid4',
      createdAt: '2016-03-13T12:52:32.123Z',
      uuid: 'uuid4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

