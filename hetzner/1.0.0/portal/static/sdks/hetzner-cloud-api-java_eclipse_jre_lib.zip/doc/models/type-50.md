
# Type 50

Type of the Primary IP

## Enumeration

`Type50`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```java
import cloud.hetzner.api.models.Type50;

Type50 type50 = Type50.IPV4;
```

