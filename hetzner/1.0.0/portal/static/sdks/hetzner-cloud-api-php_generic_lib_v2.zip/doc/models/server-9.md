
# Server 9

Configuration for type server, required if type is `server`

## Structure

`Server9`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Server | getId(): int | setId(int id): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\Server9Builder;

$server9 = Server9Builder::init(
    216
)->build();
```

