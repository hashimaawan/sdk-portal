
# V2 Apps Alerts Destinations Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsAlertsDestinationsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `emails` | `string[] \| undefined` | Optional | - |
| `slackWebhooks` | [`SlackWebhooksToSendAlertsTo[] \| undefined`](../../doc/models/slack-webhooks-to-send-alerts-to.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AppsAlertsDestinationsRequest } from 'digitalocean-apilib';

const v2AppsAlertsDestinationsRequest: V2AppsAlertsDestinationsRequest = {
  emails: [
    'sammy@digitalocean.com'
  ],
  slackWebhooks: [
    {
      channel: 'channel8',
      url: 'url0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

