
# Sort 8 Enum

## Enumeration

`Sort8Enum`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Sort8Enum sort8 = Sort8Enum.EnumNameasc;
```

