
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `ITEM` |
| `VAULT` |

## Example

```ruby
type = Type::ITEM
```

