
# Applied To

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppliedToResources` | [`List<AppliedToResource>`](../../doc/models/applied-to-resource.md) | Optional | - |
| `LabelSelector` | [`LabelSelector`](../../doc/models/label-selector.md) | Optional | - |
| `Server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `Type` | [`Type6Enum`](../../doc/models/type-6-enum.md) | Required | Type of resource referenced |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

AppliedTo appliedTo = new AppliedTo
{
    Type = Type6Enum.Server,
    AppliedToResources = new List<AppliedToResource>
    {
        new AppliedToResource
        {
            Server = new Server
            {
                Id = 14,
            },
            Type = Type5Enum.Server,
        },
        new AppliedToResource
        {
            Server = new Server
            {
                Id = 14,
            },
            Type = Type5Enum.Server,
        },
    },
    LabelSelector = new LabelSelector
    {
        Selector = "selector8",
    },
    Server = new Server
    {
        Id = 14,
    },
};
```

