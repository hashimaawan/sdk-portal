
# Servers Metrics Response

*This model accepts additional fields of type Object.*

## Structure

`ServersMetricsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Metrics` | [`Metrics`](../../doc/models/metrics.md) | Required | - | Metrics getMetrics() | setMetrics(Metrics metrics) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.Metrics;
import cloud.hetzner.api.models.ServersMetricsResponse;
import cloud.hetzner.api.models.TimeSeries;
import cloud.hetzner.api.models.containers.TimeSeriesValues;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedHashMap;

ServersMetricsResponse serversMetricsResponse = new ServersMetricsResponse.Builder(
    new Metrics.Builder(
        "2017-01-01T23:00:00+00:00",
        "2017-01-01T00:00:00+00:00",
        60D,
        new LinkedHashMap<String, TimeSeries>() {{
            put("name_of_timeseries", new TimeSeries.Builder(
                Arrays.asList(
                    Arrays.asList(
                        TimeSeriesValues.fromPrecision(
                            1435781470.622D
                        ),
                        TimeSeriesValues.fromString(
                            "42"
                        )
                    ),
                    Arrays.asList(
                        TimeSeriesValues.fromPrecision(
                            1435781471.622D
                        ),
                        TimeSeriesValues.fromString(
                            "43"
                        )
                    )
                )
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build());
        }}
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

