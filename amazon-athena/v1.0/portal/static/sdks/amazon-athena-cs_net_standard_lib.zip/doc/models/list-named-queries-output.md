
# List Named Queries Output

*This model accepts additional fields of type object.*

## Structure

`ListNamedQueriesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueryIds` | `List<string>` | Optional | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;
using System.Collections.Generic;

ListNamedQueriesOutput listNamedQueriesOutput = new ListNamedQueriesOutput
{
    NamedQueryIds = new List<string>
    {
        "NamedQueryIds5",
        "NamedQueryIds4",
        "NamedQueryIds3",
    },
    NextToken = "NextToken2",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

