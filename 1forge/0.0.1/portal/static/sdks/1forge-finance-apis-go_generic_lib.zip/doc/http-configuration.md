
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`m1ForgeFinanceApIsRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `m1ForgeFinanceApIs.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "m1ForgeFinanceApIs"
    "net/http"
)

func main() {
    httpConfiguration := m1ForgeFinanceApIs.CreateHttpConfiguration(
        m1ForgeFinanceApIs.WithTimeout(30),
        m1ForgeFinanceApIs.WithTransport(http.DefaultTransport),
        m1ForgeFinanceApIs.WithRetryConfiguration(m1ForgeFinanceApIs.DefaultRetryConfiguration()),
    )
}
```

