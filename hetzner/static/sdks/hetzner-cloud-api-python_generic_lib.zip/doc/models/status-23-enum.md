
# Status 23 Enum

## Enumeration

`Status23Enum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |

## Example

```python
from hetznercloudapi.models.status_23_enum import Status23Enum

status_23 = Status23Enum.AVAILABLE
```

