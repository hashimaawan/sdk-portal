
# Statement Type

## Enumeration

`StatementType`

## Fields

| Name |
|  --- |
| `Ddl` |
| `Dml` |
| `Utility` |

## Example

```ts
import { StatementType } from 'amazon-athenalib';

const statementType = StatementType.Ddl;
```

