
# Query Runtime Statistics Rows

Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query.

## Structure

`QueryRuntimeStatisticsRows`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `inputRows` | `number \| undefined` | Optional | - |
| `inputBytes` | `number \| undefined` | Optional | - |
| `outputBytes` | `number \| undefined` | Optional | - |
| `outputRows` | `number \| undefined` | Optional | - |

## Example

```ts
import { QueryRuntimeStatisticsRows } from 'amazon-athenalib';

const queryRuntimeStatisticsRows: QueryRuntimeStatisticsRows = {
  inputRows: 234,
  inputBytes: 254,
  outputBytes: 40,
  outputRows: 226,
};
```

