
# Firewall Remove from Resources

## Structure

`FirewallRemoveFromResources`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LabelSelector` | [`LabelSelector5`](../../doc/models/label-selector-5.md) | Optional | Configuration for type label_selector, required if type is `label_selector` |
| `Server` | [`Server9`](../../doc/models/server-9.md) | Optional | Configuration for type server, required if type is `server` |
| `Type` | [`Type7Enum?`](../../doc/models/type-7-enum.md) | Optional | Type of the resource |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

FirewallRemoveFromResources firewallRemoveFromResources = new FirewallRemoveFromResources
{
    LabelSelector = new LabelSelector5
    {
        Selector = "selector8",
    },
    Server = new Server9
    {
        Id = 14,
    },
    Type = Type7Enum.Server,
};
```

