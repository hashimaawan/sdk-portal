
# X Amz Target 46 Enum

## Enumeration

`XAmzTarget46Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_46_enum import XAmzTarget46Enum

x_amz_target_46 = XAmzTarget46Enum.ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION
```

