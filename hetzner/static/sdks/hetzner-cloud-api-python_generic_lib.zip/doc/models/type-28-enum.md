
# Type 28 Enum

Type of the algorithm

## Enumeration

`Type28Enum`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```python
from hetznercloudapi.models.type_28_enum import Type28Enum

type_28 = Type28Enum.ROUND_ROBIN
```

