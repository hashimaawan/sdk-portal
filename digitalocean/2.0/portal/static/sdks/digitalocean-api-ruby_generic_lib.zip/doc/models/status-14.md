
# Status 14

The status of assigning and fetching the resources.

## Enumeration

`Status14`

## Fields

| Name |
|  --- |
| `OK` |
| `NOT_FOUND` |
| `ASSIGNED` |
| `ALREADY_ASSIGNED` |
| `SERVICE_DOWN` |

## Example

```ruby
status14 = Status14::NOT_FOUND
```

