
# Query Execution

Information about a single instance of a query execution.

## Structure

`QueryExecution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `query` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `statementType` | [`StatementType1Enum \| undefined`](../../doc/models/statement-type-1-enum.md) | Optional | - |
| `resultConfiguration` | [`ResultConfiguration1 \| undefined`](../../doc/models/result-configuration-1.md) | Optional | - |
| `resultReuseConfiguration` | [`ResultReuseConfiguration1 \| undefined`](../../doc/models/result-reuse-configuration-1.md) | Optional | - |
| `queryExecutionContext` | [`QueryExecutionContext1 \| undefined`](../../doc/models/query-execution-context-1.md) | Optional | - |
| `status` | [`Status \| undefined`](../../doc/models/status.md) | Optional | - |
| `statistics` | [`Statistics \| undefined`](../../doc/models/statistics.md) | Optional | - |
| `workGroup` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `engineVersion` | [`EngineVersion1 \| undefined`](../../doc/models/engine-version-1.md) | Optional | - |
| `executionParameters` | `string[] \| undefined` | Optional | **Constraints**: *Minimum Items*: `1`, *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `substatementType` | `string \| undefined` | Optional | - |

## Example

```ts
import {
  EncryptionOption1Enum,
  QueryExecution,
  S3AclOption1Enum,
  StatementType1Enum,
} from 'amazon-athenalib';

const queryExecution: QueryExecution = {
  queryExecutionId: 'QueryExecutionId4',
  query: 'Query2',
  statementType: StatementType1Enum.DML,
  resultConfiguration: {
    outputLocation: 'OutputLocation0',
    encryptionConfiguration: {
      encryptionOption: EncryptionOption1Enum.SSES3,
      kmsKey: 'KmsKey6',
    },
    expectedBucketOwner: 'ExpectedBucketOwner0',
    aclConfiguration: {
      s3AclOption: S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
    },
  },
  resultReuseConfiguration: {
    resultReuseByAgeConfiguration: {
      enabled: false,
      maxAgeInMinutes: 26,
    },
  },
};
```

