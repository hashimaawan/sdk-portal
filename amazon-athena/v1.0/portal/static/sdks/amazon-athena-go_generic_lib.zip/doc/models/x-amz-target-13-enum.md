
# X Amz Target 13 Enum

## Enumeration

`XAmzTarget13Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENADELETEWORKGROUP` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget13 := models.XAmzTarget13Enum_ENUMAMAZONATHENADELETEWORKGROUP

}
```

