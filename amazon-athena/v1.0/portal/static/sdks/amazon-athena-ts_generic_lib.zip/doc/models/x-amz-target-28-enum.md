
# X Amz Target 28 Enum

## Enumeration

`XAmzTarget28Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetTableMetadata` |

## Example

```ts
import { XAmzTarget28Enum } from 'amazon-athenalib';

const xAmzTarget28 = XAmzTarget28Enum.EnumAmazonAthenaGetTableMetadata;
```

