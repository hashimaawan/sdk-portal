
# Window

## Enumeration

`Window`

## Fields

| Name |
|  --- |
| `UNSPECIFIED_WINDOW` |
| `FIVE_MINUTES` |
| `TEN_MINUTES` |
| `THIRTY_MINUTES` |
| `ONE_HOUR` |

## Example

```java
import com.digitalocean.api.models.Window;

Window window = Window.ONE_HOUR;
```

