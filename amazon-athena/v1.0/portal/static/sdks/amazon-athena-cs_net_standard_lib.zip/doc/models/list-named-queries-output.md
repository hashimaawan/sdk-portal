
# List Named Queries Output

## Structure

`ListNamedQueriesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueryIds` | `List<string>` | Optional | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

ListNamedQueriesOutput listNamedQueriesOutput = new ListNamedQueriesOutput
{
    NamedQueryIds = new List<string>
    {
        "NamedQueryIds5",
        "NamedQueryIds4",
        "NamedQueryIds3",
    },
    NextToken = "NextToken2",
};
```

