
# Firewalls Response

## Structure

`FirewallsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Firewalls` | [`List<Firewall>`](../../doc/models/firewall.md) | Required | - |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

FirewallsResponse firewallsResponse = new FirewallsResponse
{
    Firewalls = new List<Firewall>
    {
        new Firewall
        {
            AppliedTo = new List<AppliedTo>
            {
                new AppliedTo
                {
                    Type = Type6Enum.Server,
                    AppliedToResources = new List<AppliedToResource>
                    {
                        new AppliedToResource
                        {
                            Server = new Server
                            {
                                Id = 14,
                            },
                            Type = Type5Enum.Server,
                        },
                    },
                    LabelSelector = new LabelSelector
                    {
                        Selector = "selector8",
                    },
                    Server = new Server
                    {
                        Id = 14,
                    },
                },
            },
            Created = "2016-01-30T23:55:00+00:00",
            Id = 42,
            Name = "my-resource",
            Rules = new List<Rule>
            {
                new Rule
                {
                    Direction = DirectionEnum.In,
                    Protocol = ProtocolEnum.Udp,
                    Description = "description2",
                    DestinationIps = new List<string>
                    {
                        "28.239.13.1/32",
                        "28.239.14.0/24",
                        "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
                    },
                    Port = "80",
                    SourceIps = new List<string>
                    {
                        "28.239.13.1/32",
                        "28.239.14.0/24",
                        "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
                    },
                },
            },
            Labels = new Dictionary<string, string>
            {
                ["key0"] = "labels4",
                ["key1"] = "labels5",
            },
        },
    },
    Meta = new Meta
    {
        Pagination = new Pagination
        {
            LastPage = 77.7,
            NextPage = 209.18,
            Page = 17.58,
            PerPage = 13.34,
            PreviousPage = 50.02,
            TotalEntries = 206.64,
        },
    },
};
```

