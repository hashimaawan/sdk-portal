
# Meta

*This model accepts additional fields of type array.*

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pagination` | [`Pagination`](../../doc/models/pagination.md) | Required | - | getPagination(): Pagination | setPagination(Pagination pagination): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\MetaBuilder;
use HetznerCloudApiLib\Models\Builders\PaginationBuilder;
use HetznerCloudApiLib\ApiHelper;

$meta = MetaBuilder::init(
    PaginationBuilder::init(
        3,
        25
    )
        ->lastPage(4)
        ->nextPage(4)
        ->previousPage(2)
        ->totalEntries(100)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

