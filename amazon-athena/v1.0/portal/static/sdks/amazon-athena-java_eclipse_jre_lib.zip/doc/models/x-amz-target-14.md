
# X Amz Target 14

## Enumeration

`XAmzTarget14`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAEXPORTNOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget14;

XAmzTarget14 xAmzTarget14 = XAmzTarget14.ENUM_AMAZONATHENAEXPORTNOTEBOOK;
```

