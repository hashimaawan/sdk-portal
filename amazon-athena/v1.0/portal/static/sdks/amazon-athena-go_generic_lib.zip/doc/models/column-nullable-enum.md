
# Column Nullable Enum

## Enumeration

`ColumnNullableEnum`

## Fields

| Name |
|  --- |
| `NOTNULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    columnNullable := models.ColumnNullableEnum_NOTNULL

}
```

