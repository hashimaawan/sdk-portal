
# Item Type 1

The ID type: currently only `artist` is supported.

## Enumeration

`ItemType1`

## Fields

| Name |
|  --- |
| `ARTIST` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.item_type_1 import ItemType1

item_type_1 = ItemType1.ARTIST
```

