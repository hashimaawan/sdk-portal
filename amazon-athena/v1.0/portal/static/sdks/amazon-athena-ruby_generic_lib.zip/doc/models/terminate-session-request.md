
# Terminate Session Request

*This model accepts additional fields of type Object.*

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
terminate_session_request = TerminateSessionRequest.new(
  session_id: 'SessionId8',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

