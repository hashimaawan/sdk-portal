
# Stop Calculation Execution Request

## Structure

`StopCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```ruby
stop_calculation_execution_request = StopCalculationExecutionRequest.new(
  'CalculationExecutionId2'
)
```

