
# Type 29 Enum

Type of the resource

## Enumeration

`Type29Enum`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |
| `Ip` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type29Enum type29 = Type29Enum.Server;
```

