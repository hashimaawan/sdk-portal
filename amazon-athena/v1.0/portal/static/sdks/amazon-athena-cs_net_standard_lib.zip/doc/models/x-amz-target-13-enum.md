
# X Amz Target 13 Enum

## Enumeration

`XAmzTarget13Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteWorkGroup` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget13Enum xAmzTarget13 = XAmzTarget13Enum.EnumAmazonAthenaDeleteWorkGroup;
```

