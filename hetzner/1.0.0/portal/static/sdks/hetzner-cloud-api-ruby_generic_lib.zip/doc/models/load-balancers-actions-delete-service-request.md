
# Load Balancers Actions Delete Service Request

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listen_port` | `Float` | Required | The listen port of the service you want to delete |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
load_balancers_actions_delete_service_request = LoadBalancersActionsDeleteServiceRequest.new(
  listen_port: 4711,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

