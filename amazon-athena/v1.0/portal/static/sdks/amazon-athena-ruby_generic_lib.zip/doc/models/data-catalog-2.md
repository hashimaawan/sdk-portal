
# Data Catalog 2

*This model accepts additional fields of type Object.*

## Structure

`DataCatalog2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `type` | [`DataCatalogType1`](../../doc/models/data-catalog-type-1.md) | Required | - |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
data_catalog2 = DataCatalog2.new(
  name: 'Name4',
  type: DataCatalogType1::LAMBDA,
  description: 'Description2',
  parameters: Parameters.new(
    additional_properties: {
      'exampleAdditionalProperty' => 'Parameters_additionalProperties2'
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

