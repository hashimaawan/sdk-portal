
# Type Enum

Type of the Certificate

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```ruby
type = TypeEnum::UPLOADED
```

