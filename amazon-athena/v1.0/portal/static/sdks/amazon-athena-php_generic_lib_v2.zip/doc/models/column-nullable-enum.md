
# Column Nullable Enum

## Enumeration

`ColumnNullableEnum`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```php
use AmazonAthenaLib\Models\ColumnNullableEnum;

$columnNullable = ColumnNullableEnum::NOT_NULL;
```

