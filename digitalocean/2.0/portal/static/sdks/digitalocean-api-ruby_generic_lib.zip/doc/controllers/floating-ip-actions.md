# Floating IP Actions

```ruby
floating_ip_actions_api = client.floating_ip_actions
```

## Class Name

`FloatingIpActionsApi`

## Methods

* [Floating I Ps Action List](../../doc/controllers/floating-ip-actions.md#floating-i-ps-action-list)
* [Floating I Ps Action Post](../../doc/controllers/floating-ip-actions.md#floating-i-ps-action-post)
* [Floating I Ps Action Get](../../doc/controllers/floating-ip-actions.md#floating-i-ps-action-get)


# Floating I Ps Action List

To retrieve all actions that have been executed on a floating IP, send a GET request to `/v2/floating_ips/$FLOATING_IP/actions`.

```ruby
def floating_i_ps_action_list(floating_ip)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floating_ip` | `String` | Template, Required | A floating IP address. |

## Response Type

**200**: The results will be returned as a JSON object with an `actions` key. This will be set to an array filled with action objects containing the standard floating IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FloatingIpsActionsResponse`](../../doc/models/v2-floating-ips-actions-response.md).

## Example Usage

```ruby
floating_ip = '45.55.96.47'

result = floating_ip_actions_api.floating_i_ps_action_list(floating_ip)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Floating I Ps Action Post

To initiate an action on a floating IP send a POST request to
`/v2/floating_ips/$FLOATING_IP/actions`. In the JSON body to the request,
set the `type` attribute to on of the supported action types:

| Action     | Details
|------------|--------
| `assign`   | Assigns a floating IP to a Droplet
| `unassign` | Unassign a floating IP from a Droplet

```ruby
def floating_i_ps_action_post(floating_ip,
                              body: nil)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floating_ip` | `String` | Template, Required | A floating IP address. |
| `body` | [BaseType](../../doc/models/base-type.md) \| [V2 Floating Ips Actions Request](../../doc/models/v2-floating-ips-actions-request.md) \| nil | Body, Optional | This is a container for any-of cases. |

## Response Type

**201**: The response will be an object with a key called `action`. The value of this will be an object that contains the standard floating IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FloatingIpsActionsResponse1`](../../doc/models/v2-floating-ips-actions-response-1.md).

## Example Usage

```ruby
floating_ip = '45.55.96.47'

body = V2ReservedIpsActionsRequest.new(
  droplet_id: 758604968,
  type: 'V2 Reserved Ips Actions Request'
)

result = floating_ip_actions_api.floating_i_ps_action_post(
  floating_ip,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Floating I Ps Action Get

To retrieve the status of a floating IP action, send a GET request to `/v2/floating_ips/$FLOATING_IP/actions/$ACTION_ID`.

```ruby
def floating_i_ps_action_get(floating_ip,
                             action_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floating_ip` | `String` | Template, Required | A floating IP address. |
| `action_id` | `Integer` | Template, Required | A unique numeric ID that can be used to identify and reference an action.<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be an object with a key called `action`. The value of this will be an object that contains the standard floating IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`V2FloatingIpsActionsResponse1`](../../doc/models/v2-floating-ips-actions-response-1.md).

## Example Usage

```ruby
floating_ip = '45.55.96.47'

action_id = 36804636

result = floating_ip_actions_api.floating_i_ps_action_get(
  floating_ip,
  action_id
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

