
# Unprocessed Prepared Statement Name

The name of a prepared statement that could not be returned.

## Structure

`UnprocessedPreparedStatementName`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `StatementName` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` | String getStatementName() | setStatementName(String statementName) |
| `ErrorCode` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getErrorCode() | setErrorCode(String errorCode) |
| `ErrorMessage` | `String` | Optional | - | String getErrorMessage() | setErrorMessage(String errorMessage) |

## Example

```java
import com.amazonaws.useast1.athena.models.UnprocessedPreparedStatementName;

UnprocessedPreparedStatementName unprocessedPreparedStatementName = new UnprocessedPreparedStatementName.Builder()
    .statementName("StatementName8")
    .errorCode("ErrorCode6")
    .errorMessage("ErrorMessage6")
    .build();
```

