
# Notebook Type 1 Enum

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```python
from amazonathena.models.notebook_type_1_enum import NotebookType1Enum

notebook_type_1 = NotebookType1Enum.IPYNB
```

