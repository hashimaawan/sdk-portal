
# Server Public Net Firewall

*This model accepts additional fields of type Object.*

## Structure

`ServerPublicNetFirewall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | ID of the Resource |
| `status` | [`Status72`](../../doc/models/status-72.md) | Optional | Status of the Firewall on the Server |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
server_public_net_firewall = ServerPublicNetFirewall.new(
  id: 42,
  status: Status72::APPLIED,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

