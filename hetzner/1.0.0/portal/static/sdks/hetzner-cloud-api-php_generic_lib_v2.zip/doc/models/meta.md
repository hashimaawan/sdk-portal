
# Meta

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pagination` | [`Pagination`](../../doc/models/pagination.md) | Required | - | getPagination(): Pagination | setPagination(Pagination pagination): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\MetaBuilder;
use HetznerCloudAPILib\Models\Builders\PaginationBuilder;

$meta = MetaBuilder::init(
    PaginationBuilder::init(
        3,
        25
    )
        ->lastPage(4)
        ->nextPage(4)
        ->previousPage(2)
        ->totalEntries(100)
        ->build()
)->build();
```

