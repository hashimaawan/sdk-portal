
# List Sessions Request

## Structure

`ListSessionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): string | setWorkGroup(string workGroup): void |
| `stateFilter` | [`?string(SessionState3Enum)`](../../doc/models/session-state-3-enum.md) | Optional | - | getStateFilter(): ?string | setStateFilter(?string stateFilter): void |
| `maxResults` | `?int` | Optional | **Constraints**: `>= 1`, `<= 100` | getMaxResults(): ?int | setMaxResults(?int maxResults): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Maximum Length*: `2048` | getNextToken(): ?string | setNextToken(?string nextToken): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListSessionsRequestBuilder;
use AmazonAthenaLib\Models\SessionState3Enum;

$listSessionsRequest = ListSessionsRequestBuilder::init(
    'WorkGroup8'
)
    ->stateFilter(SessionState3Enum::CREATING)
    ->maxResults(100)
    ->nextToken('NextToken6')
    ->build();
```

