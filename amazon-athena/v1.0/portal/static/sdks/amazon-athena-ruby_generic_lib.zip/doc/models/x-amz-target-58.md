
# X Amz Target 58

## Enumeration

`XAmzTarget58`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target58 = XAmzTarget58::ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT
```

