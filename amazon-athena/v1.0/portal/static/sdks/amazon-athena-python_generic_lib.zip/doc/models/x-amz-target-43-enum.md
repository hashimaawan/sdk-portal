
# X Amz Target 43 Enum

## Enumeration

`XAmzTarget43Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTABLEMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_43_enum import XAmzTarget43Enum

x_amz_target_43 = XAmzTarget43Enum.ENUM_AMAZONATHENALISTTABLEMETADATA
```

