
# X Amz Target 40 Enum

## Enumeration

`XAmzTarget40Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListPreparedStatements` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget40Enum xAmzTarget40 = XAmzTarget40Enum.EnumAmazonAthenaListPreparedStatements;
```

