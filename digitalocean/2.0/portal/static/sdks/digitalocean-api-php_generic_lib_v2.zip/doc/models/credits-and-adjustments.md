
# Credits and Adjustments

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`CreditsAndAdjustments`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `?string` | Optional | Total amount charged in USD | getAmount(): ?string | setAmount(?string amount): void |
| `name` | `?string` | Optional | Name of the charge | getName(): ?string | setName(?string name): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\CreditsAndAdjustmentsBuilder;
use DigitalOceanApiLib\ApiHelper;

$creditsAndAdjustments = CreditsAndAdjustmentsBuilder::init()
    ->amount('3.45')
    ->name('Overages')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

