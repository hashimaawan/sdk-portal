
# Firewall Apply to Resources

## Structure

`FirewallApplyToResources`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label_selector` | [`LabelSelector5`](../../doc/models/label-selector-5.md) | Optional | Configuration for type label_selector, required if type is `label_selector` |
| `server` | [`Server9`](../../doc/models/server-9.md) | Optional | Configuration for type server, required if type is `server` |
| `type` | [`Type7Enum`](../../doc/models/type-7-enum.md) | Optional | Type of the resource |

## Example

```ruby
firewall_apply_to_resources = FirewallApplyToResources.new(
  LabelSelector5.new(
    'selector8'
  ),
  Server9.new(
    14
  ),
  Type7Enum::SERVER
)
```

