
# Result Reuse Information 2

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReusedPreviousResult` | `bool` | Required | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

ResultReuseInformation2 resultReuseInformation2 = new ResultReuseInformation2
{
    ReusedPreviousResult = false,
};
```

