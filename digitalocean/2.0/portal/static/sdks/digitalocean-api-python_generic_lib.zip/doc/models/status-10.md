
# Status 10

An object containing a `state` attribute whose value is set to a string indicating the current status of the node.

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Status10`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`State1`](../../doc/models/state-1.md) | Optional | A string indicating the current status of the node. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.state_1 import State1
from digitaloceanapi.models.status_10 import Status10

status_10 = Status10(
    state=State1.PROVISIONING,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

