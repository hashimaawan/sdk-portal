
# X Amz Target 57

## Enumeration

`XAmzTarget57`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget57;

$xAmzTarget57 = XAmzTarget57::ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA;
```

