
# X Amz Target 53 Enum

## Enumeration

`XAmzTarget53Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUNTAGRESOURCE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget53Enum;

$xAmzTarget53 = XAmzTarget53Enum::ENUM_AMAZONATHENAUNTAGRESOURCE;
```

