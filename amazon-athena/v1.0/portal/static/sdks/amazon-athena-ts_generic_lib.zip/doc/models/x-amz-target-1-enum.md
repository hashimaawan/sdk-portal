
# X Amz Target 1 Enum

## Enumeration

`XAmzTarget1Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetPreparedStatement` |

## Example

```ts
import { XAmzTarget1Enum } from 'amazon-athenalib';

const xAmzTarget1 = XAmzTarget1Enum.EnumAmazonAthenaBatchGetPreparedStatement;
```

