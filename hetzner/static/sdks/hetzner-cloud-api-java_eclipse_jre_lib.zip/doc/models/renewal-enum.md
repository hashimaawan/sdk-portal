
# Renewal Enum

Status of the renewal process of the Certificate.

## Enumeration

`RenewalEnum`

## Fields

| Name |
|  --- |
| `SCHEDULED` |
| `PENDING` |
| `FAILED` |
| `UNAVAILABLE` |

## Example

```java
import cloud.hetzner.api.models.RenewalEnum;

RenewalEnum renewal = RenewalEnum.FAILED;
```

