
# X Amz Target 51 Enum

## Enumeration

`XAmzTarget51Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaTagResource` |

## Example

```ts
import { XAmzTarget51Enum } from 'amazon-athenalib';

const xAmzTarget51 = XAmzTarget51Enum.EnumAmazonAthenaTagResource;
```

