
# Type 28

Type of the algorithm

## Enumeration

`Type28`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```python
from hetznercloudapi.models.type_28 import Type28

type_28 = Type28.ROUND_ROBIN
```

