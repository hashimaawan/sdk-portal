
# Query Execution Context 1

## Structure

`QueryExecutionContext1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `catalog` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```python
from amazonathena.models.query_execution_context_1 import QueryExecutionContext1

query_execution_context_1 = QueryExecutionContext1(
    database='Database6',
    catalog='Catalog2'
)
```

