
# Terminate Session Request

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ts
import { TerminateSessionRequest } from 'amazon-athenalib';

const terminateSessionRequest: TerminateSessionRequest = {
  sessionId: 'SessionId0',
};
```

