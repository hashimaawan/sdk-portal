
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |

The API client can be initialized as follows:

```go
package main

import (
    "nbaStatsApi"
)

func main() {
    client := nbaStatsApi.NewClient(
    nbaStatsApi.CreateConfiguration(
            nbaStatsApi.WithHttpConfiguration(
                nbaStatsApi.CreateHttpConfiguration(
                    nbaStatsApi.WithTimeout(30),
                ),
            ),
            nbaStatsApi.WithLoggerConfiguration(
                nbaStatsApi.WithLevel("info"),
                nbaStatsApi.WithRequestConfiguration(
                    nbaStatsApi.WithRequestBody(true),
                ),
                nbaStatsApi.WithResponseConfiguration(
                    nbaStatsApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## NBA Stats API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| Api() | Gets Api |

