
# Pagination

The Pagination Object contains information relating to the number of total results available as well as the number of results fetched and their relative positions.

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `Integer` | Optional | Total number of items returned. |
| `offset` | `Integer` | Optional | Position in pagination. |
| `total_count` | `Integer` | Optional | Total number of items available. |

## Example

```ruby
pagination = Pagination.new(
  25,
  75,
  250
)
```

