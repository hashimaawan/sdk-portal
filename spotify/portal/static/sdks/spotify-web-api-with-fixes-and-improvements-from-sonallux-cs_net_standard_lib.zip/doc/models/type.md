
# Type

The object type.

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Artist` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models.Type type = SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models.Type.Artist;
```

