# Networks

Networks is a private networks feature. These Networks are optional and they coexist with the public network that every Server has by default.

They allow Servers to talk to each other over a dedicated network interface using private IP addresses not available publicly.

The IP addresses are allocated and managed via the API, they must conform to [RFC1918](https://tools.ietf.org/html/rfc1918#section-3) standard. IPs and network interfaces defined under Networks do not provide public internet connectivity, you will need to use the already existing public network interface for that.

Each network has a user selected `ip_range` which defines all available IP addresses which can be used for Subnets within the Network.

To assign individual IPs to Servers you will need to create Network Subnets, described below.

Currently Networks support IPv4 only.

### Subnets

Subnets divide the `ip_range` from the parent Network object into multiple Subnetworks that you can use for different specific purposes.

For each subnet you need to specify its own `ip_range` which must be contained within the parent Network’s `ip_range`. Additionally each subnet must belong to one of the available Network Zones described below. Subnets can not have overlapping IP ranges.

Currently there are three types of subnet:

* type `cloud` is used to connect cloud Resources into your Network.
* type `server` was used to connect only cloud Servers into your Network. This type is deprecated and is replaced by type cloud.
* type `vswitch` allows you to connect [Dedicated Server vSwitch](https://docs.hetzner.com/robot/dedicated-server/network/vswitch) - and all Dedicated Servers attached to it - into your Network

Subnets of type `vswitch` must set a `vswitch_id` which is the ID of the existing vSwitch in Hetzner Robot that should be coupled.

### Network Zones

Network Zones are groups of Locations which have special high-speed network connections between them. The [Location object](https://docs.hetzner.cloud/#locations-get-a-location) contains the `network_zone` property each Location belongs to. Currently these network zones exist:

|Network Zone|Contains Locations|
|------------|------------------|
|eu-central  | nbg1, fsn1, hel1 |
|us-east     | ash              |

### IP address management

When a cloud Server is attached to a network without the user specifying an IP it automatically gets an IP address assigned from a subnet of type `server` in the same network zone. If you specify the optional `ip` parameter when attaching then we will try to assign that IP. Keep in mind that the Server’s location must be covered by the Subnet’s Network Zone if you specify an IP, or that at least one Subnet with the zone covering Server’s location must exist.

A cloud Server can also have more than one IP address in a Network by specifying aliases. For details see the [attach to network action](https://docs.hetzner.cloud/#server-actions-attach-a-server-to-a-network).

The following IP addresses are reserved in networks and can not be used:

* the first IP of the network `ip_range` as it will be used as a default gateway for the private Network interface.
* `172.31.1.1` as it is being used as default gateway for our public Network interfaces.

### Coupling Dedicated Servers

By using subnets of type `vswitch` you can couple the Cloud Networks with an existing [Dedicated Server vSwitch](https://docs.hetzner.com/robot/dedicated-server/network/vswitch) and enable dedicated and cloud servers to
talk to each other over the Network.
In order for this to work the dedicated servers may only use IPs from the subnet and must have a special network configuration. Please refer to [FAQ](https://docs.hetzner.com/cloud/networks/connect-dedi-vswitch). vSwitch Layer 2 features are not supported.

### Routes

Networks also support the notion of routes which are automatically applied to private traffic. A route makes sure that all packets for a given `destination` IP prefix will be sent to the address specified in its `gateway`.

```csharp
NetworksController networksController = client.NetworksController;
```

## Class Name

`NetworksController`

## Methods

* [Get All Networks](../../doc/controllers/networks.md#get-all-networks)
* [Create a Network](../../doc/controllers/networks.md#create-a-network)
* [Delete a Network](../../doc/controllers/networks.md#delete-a-network)
* [Get a Network](../../doc/controllers/networks.md#get-a-network)
* [Update a Network](../../doc/controllers/networks.md#update-a-network)


# Get All Networks

Gets all existing networks that you have available.

```csharp
GetAllNetworksAsync(
    string name = null,
    string labelSelector = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Query, Optional | Can be used to filter networks by their name. The response will only contain the networks matching the specified name. |
| `labelSelector` | `string` | Query, Optional | Can be used to filter networks by labels. The response will only contain networks with a matching label selector pattern. |

## Response Type

**200**: The `networks` key contains a list of networks

[`Task<Models.NetworksResponse>`](../../doc/models/networks-response.md)

## Example Usage

```csharp
try
{
    NetworksResponse result = await networksController.GetAllNetworksAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Create a Network

Creates a network with the specified `ip_range`.

You may specify one or more `subnets`. You can also add more Subnets later by using the [add subnet action](https://docs.hetzner.cloud/#network-actions-add-a-subnet-to-a-network). If you do not specify an `ip_range` in the subnet we will automatically pick the first available /24 range for you.

You may specify one or more routes in `routes`. You can also add more routes later by using the [add route action](https://docs.hetzner.cloud/#network-actions-add-a-route-to-a-network).

```csharp
CreateANetworkAsync(
    Models.CreateNetworkRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateNetworkRequest`](../../doc/models/create-network-request.md) | Body, Optional | - |

## Response Type

**201**: The `network` key contains the network that was just created

[`Task<Models.NetworksResponse1>`](../../doc/models/networks-response-1.md)

## Example Usage

```csharp
CreateNetworkRequest body = new CreateNetworkRequest
{
    IpRange = "10.0.0.0/16",
    Name = "mynet",
};

try
{
    NetworksResponse1 result = await networksController.CreateANetworkAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Delete a Network

Deletes a network. If there are Servers attached they will be detached in the background.

Note: if the network object changes during the request, the response will be a “conflict” error.

```csharp
DeleteANetworkAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the network |

## Response Type

**204**: Network deleted

`Task`

## Example Usage

```csharp
int id = 112;
try
{
    await networksController.DeleteANetworkAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Network

Gets a specific network object.

```csharp
GetANetworkAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the network |

## Response Type

**200**: The `network` key contains the network

[`Task<Models.NetworksResponse1>`](../../doc/models/networks-response-1.md)

## Example Usage

```csharp
int id = 112;
try
{
    NetworksResponse1 result = await networksController.GetANetworkAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Update a Network

Updates the network properties.

Note that when updating labels, the network’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the network object changes during the request, the response will be a “conflict” error.

```csharp
UpdateANetworkAsync(
    int id,
    Models.UpdateNetworkRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the network |
| `body` | [`UpdateNetworkRequest`](../../doc/models/update-network-request.md) | Body, Optional | - |

## Response Type

**200**: The `network` key contains the updated network

[`Task<Models.NetworksResponse1>`](../../doc/models/networks-response-1.md)

## Example Usage

```csharp
int id = 112;
UpdateNetworkRequest body = new UpdateNetworkRequest
{
    Name = "new-name",
};

try
{
    NetworksResponse1 result = await networksController.UpdateANetworkAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "network": {
    "created": "2016-01-30T23:50:00+00:00",
    "id": 4711,
    "ip_range": "10.0.0.0/16",
    "labels": {
      "labelkey": "value"
    },
    "load_balancers": [
      42
    ],
    "name": "new-name",
    "protection": {
      "delete": false
    },
    "routes": [
      {
        "destination": "10.100.1.0/24",
        "gateway": "10.0.1.1"
      }
    ],
    "servers": [
      42
    ],
    "subnets": [
      {
        "gateway": "10.0.0.1",
        "ip_range": "10.0.1.0/24",
        "network_zone": "eu-central",
        "type": "cloud"
      }
    ]
  }
}
```

