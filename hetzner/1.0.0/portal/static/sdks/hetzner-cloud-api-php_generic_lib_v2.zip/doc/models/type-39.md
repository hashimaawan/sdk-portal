
# Type 39

Algorithm of the Load Balancer

## Enumeration

`Type39`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```php
use HetznerCloudApiLib\Models\Type39;

$type39 = Type39::ROUND_ROBIN;
```

