
# Create Placement Group Request

*This model accepts additional fields of type array.*

## Structure

`CreatePlacementGroupRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `labels` | `?array` | Optional | User-defined labels (key-value pairs) | getLabels(): ?array | setLabels(?array labels): void |
| `name` | `string` | Required | Name of the PlacementGroup | getName(): string | setName(string name): void |
| `type` | `string` | Required, Constant | Define the Placement Group Type.<br><br>**Value**: `'spread'` | getType(): string | setType(string type): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\CreatePlacementGroupRequestBuilder;
use HetznerCloudApiLib\ApiHelper;

$createPlacementGroupRequest = CreatePlacementGroupRequestBuilder::init(
    'my Placement Group'
)
    ->labels(ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

