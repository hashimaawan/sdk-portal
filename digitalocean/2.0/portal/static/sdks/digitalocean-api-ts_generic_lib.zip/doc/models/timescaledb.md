
# Timescaledb

TimescaleDB extension configuration values

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Timescaledb`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `maxBackgroundWorkers` | `number \| undefined` | Optional | The number of background workers for timescaledb operations.  Set to the sum of your number of databases and the total number of concurrent background workers you want running at any given point in time.<br><br>**Constraints**: `>= 1`, `<= 4096` |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Timescaledb } from 'digitalocean-apilib';

const timescaledb: Timescaledb = {
  maxBackgroundWorkers: 8,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

