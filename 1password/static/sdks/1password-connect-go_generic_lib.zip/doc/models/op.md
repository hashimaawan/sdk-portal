
# Op

## Enumeration

`Op`

## Fields

| Name |
|  --- |
| `Add` |
| `Remove` |
| `Replace` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    op := models.Op_Remove

}
```

