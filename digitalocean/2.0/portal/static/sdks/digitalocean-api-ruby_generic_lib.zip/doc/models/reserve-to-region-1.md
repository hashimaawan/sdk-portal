
# Reserve to Region 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`ReserveToRegion1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `project_id` | `UUID \| String` | Optional | The UUID of the project to which the reserved IP will be assigned. |
| `region` | `String` | Required | The slug identifier for the region the reserved IP will be reserved to. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
reserve_to_region1 = ReserveToRegion1.new(
  region: 'nyc3',
  project_id: '746c6152-2fa2-11ed-92d3-27aaa54e4988',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

