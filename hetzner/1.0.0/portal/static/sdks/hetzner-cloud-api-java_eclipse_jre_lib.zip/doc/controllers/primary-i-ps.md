# Primary I Ps

```java
PrimaryIPsApi primaryIPsApi = client.getPrimaryIPsApi();
```

## Class Name

`PrimaryIPsApi`

## Methods

* [Get All Primary I Ps](../../doc/controllers/primary-i-ps.md#get-all-primary-i-ps)
* [Create a Primary IP](../../doc/controllers/primary-i-ps.md#create-a-primary-ip)
* [Delete a Primary IP](../../doc/controllers/primary-i-ps.md#delete-a-primary-ip)
* [Get a Primary IP](../../doc/controllers/primary-i-ps.md#get-a-primary-ip)
* [Update a Primary IP](../../doc/controllers/primary-i-ps.md#update-a-primary-ip)


# Get All Primary I Ps

Returns all Primary IP objects.

```java
CompletableFuture<ApiResponse<PrimaryIPsResponse>> getAllPrimaryIPsAsync(
    final String name,
    final String labelSelector,
    final String ip,
    final Sort2 sort)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `String` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `ip` | `String` | Query, Optional | Can be used to filter resources by their ip. The response will only contain the resources matching the specified ip. |
| `sort` | [`Sort2`](../../doc/models/sort-2.md) | Query, Optional | Can be used multiple times. Choices id id:asc id:desc created created:asc created:desc |

## Response Type

**200**: The `primary_ips` key contains an array of Primary IP objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PrimaryIPsResponse`](../../doc/models/primary-i-ps-response.md).

## Example Usage

```java
String ip = "127.0.0.1";

primaryIPsApi.getAllPrimaryIPsAsync(null, null, ip, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Create a Primary IP

Creates a new Primary IP, optionally assigned to a Server.

If you want to create a Primary IP that is not assigned to a Server, you need to provide the `datacenter` key instead of `assignee_id`. This can be either the ID or the name of the Datacenter this Primary IP shall be created in.

Note that a Primary IP can only be assigned to a Server in the same Datacenter later on.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_not_stopped`          | The specified server is running, but needs to be powered off  |
| `server_has_ipv4`             | The server already has an ipv4 address                        |
| `server_has_ipv6`             | The server already has an ipv6 address                        |

```java
CompletableFuture<ApiResponse<CreatePrimaryIpResponse>> createAPrimaryIpAsync(
    final CreatePrimaryIpRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreatePrimaryIpRequest`](../../doc/models/create-primary-ip-request.md) | Body, Optional | The `type` argument is required while `datacenter` and `assignee_id` are mutually exclusive. |

## Response Type

**201**: The `primary_ip` key contains the Primary IP that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`CreatePrimaryIpResponse`](../../doc/models/create-primary-ip-response.md).

## Example Usage

```java
CreatePrimaryIpRequest body = new CreatePrimaryIpRequest.Builder(
    "server",
    "my-ip",
    Type51.IPV4
)
.assigneeId(17)
.autoDelete(false)
.datacenter("fsn1-dc8")
.labels(ApiHelper.deserialize("{\"labelkey\":\"value\"}"))
.build();

primaryIPsApi.createAPrimaryIpAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_primary_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 17,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "primary_ip": {
    "assignee_id": 17,
    "assignee_type": "server",
    "auto_delete": true,
    "blocked": false,
    "created": "2016-01-30T23:50:00+00:00",
    "datacenter": {
      "description": "Falkenstein DC Park 8",
      "id": 42,
      "location": {
        "city": "Falkenstein",
        "country": "DE",
        "description": "Falkenstein DC Park 1",
        "id": 1,
        "latitude": 50.47612,
        "longitude": 12.370071,
        "name": "fsn1",
        "network_zone": "eu-central"
      },
      "name": "fsn1-dc8",
      "server_types": {
        "available": [
          1,
          2,
          3
        ],
        "available_for_migration": [
          1,
          2,
          3
        ],
        "supported": [
          1,
          2,
          3
        ]
      }
    },
    "dns_ptr": [
      {
        "dns_ptr": "server.example.com",
        "ip": "2001:db8::1"
      }
    ],
    "id": 42,
    "ip": "131.232.99.1",
    "labels": {
      "labelkey": "value"
    },
    "name": "my-ip",
    "protection": {
      "delete": false
    },
    "type": "ipv4"
  }
}
```


# Delete a Primary IP

Deletes a Primary IP.

The Primary IP may be assigned to a Server. In this case it is unassigned automatically. The Server must be powered off (status `off`) in order for this operation to succeed.

```java
CompletableFuture<ApiResponse<Void>> deleteAPrimaryIpAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Primary IP deleted

`void`

## Example Usage

```java
int id = 112;

primaryIPsApi.deleteAPrimaryIpAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a Primary IP

Returns a specific Primary IP object.

```java
CompletableFuture<ApiResponse<PrimaryIpResponse>> getAPrimaryIpAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `primary_ip` key contains a Primary IP object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PrimaryIpResponse`](../../doc/models/primary-ip-response.md).

## Example Usage

```java
int id = 112;

primaryIPsApi.getAPrimaryIpAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Update a Primary IP

Updates the Primary IP.

Note that when updating labels, the Primary IP's current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

If the Primary IP object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ApiResponse<PrimaryIpResponse>> updateAPrimaryIpAsync(
    final int id,
    final UpdatePrimaryIpRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`UpdatePrimaryIpRequest`](../../doc/models/update-primary-ip-request.md) | Body, Optional | - |

## Response Type

**200**: The `primary_ip` key contains the Primary IP that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PrimaryIpResponse`](../../doc/models/primary-ip-response.md).

## Example Usage

```java
int id = 112;
UpdatePrimaryIpRequest body = new UpdatePrimaryIpRequest.Builder()
    .autoDelete(true)
    .labels(ApiHelper.deserialize("{\"labelkey\":\"value\"}"))
    .name("my-ip")
    .build();

primaryIPsApi.updateAPrimaryIpAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

