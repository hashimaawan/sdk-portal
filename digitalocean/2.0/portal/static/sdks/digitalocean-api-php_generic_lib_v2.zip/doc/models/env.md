
# Env

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Env`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `string` | Required | The variable name<br><br>**Constraints**: *Pattern*: `^[_A-Za-z][_A-Za-z0-9]*$` | getKey(): string | setKey(string key): void |
| `scope` | [`?string(Scope)`](../../doc/models/scope.md) | Optional | - RUN_TIME: Made available only at run-time<br>- BUILD_TIME: Made available only at build-time<br>- RUN_AND_BUILD_TIME: Made available at both build and run-time<br><br>**Default**: `Scope::RUN_AND_BUILD_TIME` | getScope(): ?string | setScope(?string scope): void |
| `type` | [`?string(Type2)`](../../doc/models/type-2.md) | Optional | - GENERAL: A plain-text environment variable<br>- SECRET: A secret encrypted environment variable<br><br>**Default**: `Type2::GENERAL` | getType(): ?string | setType(?string type): void |
| `value` | `?string` | Optional | The value. If the type is `SECRET`, the value will be encrypted on first submission. On following submissions, the encrypted value should be used. | getValue(): ?string | setValue(?string value): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\EnvBuilder;
use DigitalOceanApiLib\Models\Scope;
use DigitalOceanApiLib\Models\Type2;
use DigitalOceanApiLib\ApiHelper;

$env = EnvBuilder::init(
    'BASE_URL'
)
    ->scope(Scope::BUILD_TIME)
    ->type(Type2::GENERAL)
    ->value('http://example.com')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

