
# V2 Volumes Actions Request 2

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2VolumesActionsRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `region` | [`Region2`](../../doc/models/region-2.md) | Optional | The slug identifier for the region where the resource will initially be  available. |
| `type` | [`Type21`](../../doc/models/type-21.md) | Required | The volume action to initiate. |
| `size_gigabytes` | `Integer` | Required | The new size of the block storage volume in GiB (1024^3).<br><br>**Constraints**: `<= 16384` |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_volumes_actions_request2 = V2VolumesActionsRequest2.new(
  type: Type21::ATTACH,
  size_gigabytes: 15384,
  region: Region2::NYC3,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

