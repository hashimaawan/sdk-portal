
# Status 1

The current status of the action. This can be "in-progress", "completed", or "errored".

## Enumeration

`Status1`

## Fields

| Name |
|  --- |
| `INPROGRESS` |
| `COMPLETED` |
| `ERRORED` |

## Example

```java
import com.digitalocean.api.models.Status1;

Status1 status1 = Status1.INPROGRESS;
```

