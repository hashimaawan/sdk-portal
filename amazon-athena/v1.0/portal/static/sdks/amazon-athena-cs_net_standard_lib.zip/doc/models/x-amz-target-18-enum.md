
# X Amz Target 18 Enum

## Enumeration

`XAmzTarget18Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetDataCatalog` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget18Enum xAmzTarget18 = XAmzTarget18Enum.EnumAmazonAthenaGetDataCatalog;
```

