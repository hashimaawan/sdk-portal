
# V2 Uptime Checks Response

*This model accepts additional fields of type Object.*

## Structure

`V2UptimeChecksResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Checks` | [`List<Check>`](../../doc/models/check.md) | Optional | - | List<Check> getChecks() | setChecks(List<Check> checks) |
| `Links` | [`Links`](../../doc/models/links.md) | Optional | - | Links getLinks() | setLinks(Links links) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Required | - | Meta getMeta() | setMeta(Meta meta) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Check;
import com.digitalocean.api.models.Links;
import com.digitalocean.api.models.Meta;
import com.digitalocean.api.models.Pages;
import com.digitalocean.api.models.Region8;
import com.digitalocean.api.models.V2UptimeChecksResponse;
import com.digitalocean.api.models.containers.LinksPages;
import java.io.IOException;
import java.util.Arrays;
import java.util.UUID;

V2UptimeChecksResponse v2UptimeChecksResponse = new V2UptimeChecksResponse.Builder(
    new Meta.Builder(
        1
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.checks(Arrays.asList(
        new Check.Builder()
            .id(UUID.fromString("00000820-0000-0000-0000-000000000000"))
            .enabled(false)
            .name("name0")
            .regions(Arrays.asList(
                Region8.US_WEST,
                Region8.EU_WEST,
                Region8.SE_ASIA
            ))
            .target("target2")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
        new Check.Builder()
            .id(UUID.fromString("00000820-0000-0000-0000-000000000000"))
            .enabled(false)
            .name("name0")
            .regions(Arrays.asList(
                Region8.US_WEST,
                Region8.EU_WEST,
                Region8.SE_ASIA
            ))
            .target("target2")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ))
.links(new Links.Builder()
        .pages(LinksPages.fromPages(
            new Pages.Builder()
                .last("last6")
                .next("next2")
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

