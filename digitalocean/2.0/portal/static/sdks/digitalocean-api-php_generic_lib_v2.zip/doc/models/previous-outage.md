
# Previous Outage

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`PreviousOutage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `durationSeconds` | `?int` | Optional | - | getDurationSeconds(): ?int | setDurationSeconds(?int durationSeconds): void |
| `endedAt` | `?string` | Optional | - | getEndedAt(): ?string | setEndedAt(?string endedAt): void |
| `region` | `?string` | Optional | - | getRegion(): ?string | setRegion(?string region): void |
| `startedAt` | `?string` | Optional | - | getStartedAt(): ?string | setStartedAt(?string startedAt): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\PreviousOutageBuilder;
use DigitalOceanApiLib\ApiHelper;

$previousOutage = PreviousOutageBuilder::init()
    ->durationSeconds(120)
    ->endedAt('2022-03-17T18:06:55Z')
    ->region('us_east')
    ->startedAt('2022-03-17T18:04:55Z')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

