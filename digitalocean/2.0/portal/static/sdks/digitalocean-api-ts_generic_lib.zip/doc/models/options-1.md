
# Options 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Options1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `regions` | [`Region4[] \| undefined`](../../doc/models/region-4.md) | Optional | - |
| `sizes` | [`Size1[] \| undefined`](../../doc/models/size-1.md) | Optional | - |
| `versions` | [`AvailableUpgradeVersion[] \| undefined`](../../doc/models/available-upgrade-version.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Options1 } from 'digitalocean-apilib';

const options1: Options1 = {
  regions: [
    {
      name: 'name0',
      slug: 'slug6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  sizes: [
    {
      name: 'name0',
      slug: 'slug6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      name: 'name0',
      slug: 'slug6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  versions: [
    {
      kubernetesVersion: 'kubernetes_version6',
      slug: 'slug4',
      supportedFeatures: [
        'supported_features7',
        'supported_features8'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

