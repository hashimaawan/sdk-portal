
# Item

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Item`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `String` | Optional | Amount of the charge |
| `count` | `String` | Optional | Number of times the charge was applied |
| `name` | `String` | Optional | Description of the charge |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
item = Item.new(
  amount: '10.00',
  count: '1',
  name: 'Spaces Subscription',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

