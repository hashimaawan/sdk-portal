
# V2 Kubernetes Clusters Upgrades Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUpgradesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `available_upgrade_versions` | [`List[AvailableUpgradeVersion]`](../../doc/models/available-upgrade-version.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.available_upgrade_version import AvailableUpgradeVersion
from digitaloceanapi.models.v_2_kubernetes_clusters_upgrades_response import V2KubernetesClustersUpgradesResponse

v_2_kubernetes_clusters_upgrades_response = V2KubernetesClustersUpgradesResponse(
    available_upgrade_versions=[
        AvailableUpgradeVersion(
            kubernetes_version='kubernetes_version0',
            slug='slug2',
            supported_features=[
                'supported_features3'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        AvailableUpgradeVersion(
            kubernetes_version='kubernetes_version0',
            slug='slug2',
            supported_features=[
                'supported_features3'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        AvailableUpgradeVersion(
            kubernetes_version='kubernetes_version0',
            slug='slug2',
            supported_features=[
                'supported_features3'
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

