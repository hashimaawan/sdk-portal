
# Update Floating IP Request

## Structure

`UpdateFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string \| undefined` | Optional | New Description to set |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New unique name to set |

## Example

```ts
import { UpdateFloatingIPRequest } from 'hetzner-cloud-apilib';

const updateFloatingIPRequest: UpdateFloatingIPRequest = {
  description: 'Web Frontend',
  labels: { 'labelkey': 'value' },
  name: 'Web Frontend',
};
```

