
# X Amz Target 39 Enum

## Enumeration

`XAmzTarget39Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget39 := models.XAmzTarget39Enum_ENUMAMAZONATHENALISTNOTEBOOKSESSIONS

}
```

