# Floating IP Actions

```csharp
FloatingIPActionsController floatingIPActionsController = client.FloatingIPActionsController;
```

## Class Name

`FloatingIPActionsController`

## Methods

* [Get All Actions for a Floating IP](../../doc/controllers/floating-ip-actions.md#get-all-actions-for-a-floating-ip)
* [Assign a Floating IP to a Server](../../doc/controllers/floating-ip-actions.md#assign-a-floating-ip-to-a-server)
* [Change Reverse DNS Entry for a Floating IP](../../doc/controllers/floating-ip-actions.md#change-reverse-dns-entry-for-a-floating-ip)
* [Change Floating IP Protection](../../doc/controllers/floating-ip-actions.md#change-floating-ip-protection)
* [Unassign a Floating IP](../../doc/controllers/floating-ip-actions.md#unassign-a-floating-ip)
* [Get an Action for a Floating IP](../../doc/controllers/floating-ip-actions.md#get-an-action-for-a-floating-ip)


# Get All Actions for a Floating IP

Returns all Action objects for a Floating IP. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```csharp
GetAllActionsForAFloatingIPAsync(
    int id,
    Models.ParameterSortEnum? sort = null,
    Models.ParameterStatusEnum? status = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `sort` | [`ParameterSortEnum?`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum?`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`Task<Models.FloatingIpsActionsResponse>`](../../doc/models/floating-ips-actions-response.md)

## Example Usage

```csharp
int id = 112;
try
{
    FloatingIpsActionsResponse result = await floatingIPActionsController.GetAllActionsForAFloatingIPAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "assign_floating_ip",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 4711,
          "type": "server"
        },
        {
          "id": 4712,
          "type": "floating_ip"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Assign a Floating IP to a Server

Assigns a Floating IP to a Server.

```csharp
AssignAFloatingIPToAServerAsync(
    int id,
    Models.AssignFloatingIPRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `body` | [`AssignFloatingIPRequest`](../../doc/models/assign-floating-ip-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `assign` Action

[`Task<Models.ActionResponse>`](../../doc/models/action-response.md)

## Example Usage

```csharp
int id = 112;
AssignFloatingIPRequest body = new AssignFloatingIPRequest
{
    Server = 42,
};

try
{
    ActionResponse result = await floatingIPActionsController.AssignAFloatingIPToAServerAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "assign_floating_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Reverse DNS Entry for a Floating IP

Changes the hostname that will appear when getting the hostname belonging to this Floating IP.

```csharp
ChangeReverseDNSEntryForAFloatingIPAsync(
    int id,
    Models.ChangeDNSPTRRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `body` | [`ChangeDNSPTRRequest`](../../doc/models/change-dnsptr-request.md) | Body, Optional | Select the IP address for which to change the DNS entry by passing `ip`. For a Floating IP of type `ipv4` this must exactly match the IP address of the Floating IP. For a Floating IP of type `ipv6` this must be a single IP within the IPv6 /64 range that belongs to this Floating IP.<br><br>The target hostname is set by passing `dns_ptr`. |

## Response Type

**201**: The `action` key contains the `change_dns_ptr` Action

[`Task<Models.ActionResponse>`](../../doc/models/action-response.md)

## Example Usage

```csharp
int id = 112;
ChangeDNSPTRRequest body = new ChangeDNSPTRRequest
{
    DnsPtr = "server02.example.com",
    Ip = "1.2.3.4",
};

try
{
    ActionResponse result = await floatingIPActionsController.ChangeReverseDNSEntryForAFloatingIPAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_dns_ptr",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Floating IP Protection

Changes the protection configuration of the Floating IP.

```csharp
ChangeFloatingIPProtectionAsync(
    int id,
    Models.ChangeProtectionRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `body` | [`ChangeProtectionRequest`](../../doc/models/change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`Task<Models.ActionResponse>`](../../doc/models/action-response.md)

## Example Usage

```csharp
int id = 112;
ChangeProtectionRequest body = new ChangeProtectionRequest
{
    Delete = true,
};

try
{
    ActionResponse result = await floatingIPActionsController.ChangeFloatingIPProtectionAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Unassign a Floating IP

Unassigns a Floating IP, resulting in it being unreachable. You may assign it to a Server again at a later time.

```csharp
UnassignAFloatingIPAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |

## Response Type

**201**: The `action` key contains the `unassign` Action

[`Task<Models.ActionResponse>`](../../doc/models/action-response.md)

## Example Usage

```csharp
int id = 112;
try
{
    ActionResponse result = await floatingIPActionsController.UnassignAFloatingIPAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "unassign_floating_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for a Floating IP

Returns a specific Action object for a Floating IP.

```csharp
GetAnActionForAFloatingIPAsync(
    int id,
    int actionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key in the reply has this structure

[`Task<Models.ActionResponse>`](../../doc/models/action-response.md)

## Example Usage

```csharp
int id = 112;
int actionId = 224;
try
{
    ActionResponse result = await floatingIPActionsController.GetAnActionForAFloatingIPAsync(
        id,
        actionId
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "assign_floating_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "floating_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

