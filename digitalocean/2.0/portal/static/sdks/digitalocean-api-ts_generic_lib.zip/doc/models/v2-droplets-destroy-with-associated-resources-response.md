
# V2 Droplets Destroy with Associated Resources Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DropletsDestroyWithAssociatedResourcesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floatingIps` | [`FloatingIp[] \| undefined`](../../doc/models/floating-ip.md) | Optional | - |
| `reservedIps` | [`FloatingIp[] \| undefined`](../../doc/models/floating-ip.md) | Optional | - |
| `snapshots` | [`FloatingIp[] \| undefined`](../../doc/models/floating-ip.md) | Optional | - |
| `volumeSnapshots` | [`FloatingIp[] \| undefined`](../../doc/models/floating-ip.md) | Optional | - |
| `volumes` | [`FloatingIp[] \| undefined`](../../doc/models/floating-ip.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  V2DropletsDestroyWithAssociatedResourcesResponse,
} from 'digitalocean-apilib';

const v2DropletsDestroyWithAssociatedResourcesResponse: V2DropletsDestroyWithAssociatedResourcesResponse = {
  floatingIps: [
    {
      cost: 'cost0',
      id: 'id2',
      name: 'name2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      cost: 'cost0',
      id: 'id2',
      name: 'name2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  reservedIps: [
    {
      cost: 'cost8',
      id: 'id0',
      name: 'name0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  snapshots: [
    {
      cost: 'cost0',
      id: 'id2',
      name: 'name2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      cost: 'cost0',
      id: 'id2',
      name: 'name2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  volumeSnapshots: [
    {
      cost: 'cost6',
      id: 'id8',
      name: 'name8',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  volumes: [
    {
      cost: 'cost4',
      id: 'id6',
      name: 'name6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      cost: 'cost4',
      id: 'id6',
      name: 'name6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

