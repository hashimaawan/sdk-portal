
# V2 Databases Users Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `users` | [`Array[User]`](../../doc/models/user.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_users_response = V2DatabasesUsersResponse.new(
  users: [
    User.new(
      name: 'name6',
      mysql_settings: MysqlSettings.new(
        auth_plugin: AuthPlugin::MYSQL_NATIVE_PASSWORD,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      password: 'password0',
      role: Role::PRIMARY,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    User.new(
      name: 'name6',
      mysql_settings: MysqlSettings.new(
        auth_plugin: AuthPlugin::MYSQL_NATIVE_PASSWORD,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      password: 'password0',
      role: Role::PRIMARY,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

