
# V2 Load Balancers Droplets Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2LoadBalancersDropletsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_ids` | `Array[Integer]` | Optional | An array containing the IDs of the Droplets assigned to the load balancer. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_load_balancers_droplets_request = V2LoadBalancersDropletsRequest.new(
  droplet_ids: [
    3164444,
    3164445
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

