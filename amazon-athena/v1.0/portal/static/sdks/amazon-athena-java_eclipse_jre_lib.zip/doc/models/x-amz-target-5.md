
# X Amz Target 5

## Enumeration

`XAmzTarget5`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget5;

XAmzTarget5 xAmzTarget5 = XAmzTarget5.ENUM_AMAZONATHENACREATENOTEBOOK;
```

