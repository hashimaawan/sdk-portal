
# Create Floating IP Request

## Structure

`CreateFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Optional | - |
| `HomeLocation` | `string` | Optional | Home Location (routing is optimized for that Location). Only optional if Server argument is passed. |
| `Labels` | `object` | Optional | User-defined labels (key-value pairs) |
| `Name` | `string` | Optional | - |
| `Server` | `int?` | Optional | Server to assign the Floating IP to |
| `Type` | [`Type17Enum`](../../doc/models/type-17-enum.md) | Required | Floating IP type |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using HetznerCloudAPI.Standard.Utilities;

CreateFloatingIPRequest createFloatingIPRequest = new CreateFloatingIPRequest
{
    Type = Type17Enum.Ipv4,
    Description = "Web Frontend",
    HomeLocation = "fsn1",
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "Web Frontend",
    Server = 42,
};
```

