
# Parameter Status

## Enumeration

`ParameterStatus`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ERROR` |

## Example

```python
from hetznercloudapi.models.parameter_status import ParameterStatus

parameter_status = ParameterStatus.ERROR
```

