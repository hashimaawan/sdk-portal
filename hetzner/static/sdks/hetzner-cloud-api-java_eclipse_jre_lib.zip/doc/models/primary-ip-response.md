
# Primary IP Response

## Structure

`PrimaryIPResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PrimaryIp` | [`PrimaryIP1`](../../doc/models/primary-ip-1.md) | Required | - | PrimaryIP1 getPrimaryIp() | setPrimaryIp(PrimaryIP1 primaryIp) |

## Example

```java
import cloud.hetzner.api.models.Datacenter2;
import cloud.hetzner.api.models.DnsPtr;
import cloud.hetzner.api.models.Location;
import cloud.hetzner.api.models.PrimaryIP1;
import cloud.hetzner.api.models.PrimaryIPResponse;
import cloud.hetzner.api.models.Protection;
import cloud.hetzner.api.models.ServerTypes;
import cloud.hetzner.api.models.Type50Enum;
import java.util.Arrays;
import java.util.LinkedHashMap;

PrimaryIPResponse primaryIPResponse = new PrimaryIPResponse.Builder(
    new PrimaryIP1.Builder(
        17,
        "server",
        true,
        false,
        "2016-01-30T23:55:00+00:00",
        new Datacenter2.Builder(
            "Falkenstein DC Park 8",
            42,
            new Location.Builder(
                "Falkenstein",
                "DE",
                "Falkenstein DC Park 1",
                1D,
                50.47612D,
                12.370071D,
                "fsn1",
                "eu-central"
            )
            .build(),
            "fsn1-dc8",
            new ServerTypes.Builder(
                Arrays.asList(
                    1D,
                    2D,
                    3D
                ),
                Arrays.asList(
                    1D,
                    2D,
                    3D
                ),
                Arrays.asList(
                    1D,
                    2D,
                    3D
                )
            )
            .build()
        )
        .build(),
        Arrays.asList(
            new DnsPtr.Builder(
                "server.example.com",
                "2001:db8::1"
            )
            .build()
        ),
        42,
        "131.232.99.1",
        new LinkedHashMap<String, String>() {{
            put("key0", "labels2");
            put("key1", "labels1");
        }},
        "my-resource",
        new Protection.Builder(
            false
        )
        .build(),
        Type50Enum.IPV4
    )
    .build()
)
.build();
```

