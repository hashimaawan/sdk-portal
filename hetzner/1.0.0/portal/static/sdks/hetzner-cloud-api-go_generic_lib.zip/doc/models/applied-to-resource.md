
# Applied to Resource

*This model accepts additional fields of type interface{}.*

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Server` | [`*models.Server`](../../doc/models/server.md) | Optional | - |
| `Type` | [`*models.Type5`](../../doc/models/type-5.md) | Optional | Type of resource referenced |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    appliedToResource := models.AppliedToResource{
        Server:                models.ToPointer(models.Server{
            Id:                    14,
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        Type:                  models.ToPointer(models.Type5_Server),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

