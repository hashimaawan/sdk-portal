
# Table Metadata

Contains metadata for a table.

## Structure

`TableMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `create_time` | `DateTime` | Optional | - |
| `last_access_time` | `DateTime` | Optional | - |
| `table_type` | `String` | Optional | **Constraints**: *Maximum Length*: `255` |
| `columns` | [`Array[Column]`](../../doc/models/column.md) | Optional | - |
| `partition_keys` | [`Array[Column]`](../../doc/models/column.md) | Optional | - |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```ruby
table_metadata = TableMetadata.new(
  'Name0',
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  'TableType4',
  [
    Column.new(
      'Name0',
      'Type0',
      'Comment4'
    ),
    Column.new(
      'Name0',
      'Type0',
      'Comment4'
    )
  ],
  [
    Column.new(
      'Name6',
      'Type6',
      'Comment0'
    ),
    Column.new(
      'Name6',
      'Type6',
      'Comment0'
    )
  ],
  Parameters.new
)
```

