
# Notebook Type Enum

## Enumeration

`NotebookTypeEnum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```ruby
notebook_type = NotebookTypeEnum::IPYNB
```

