
# Calculation Execution State

## Enumeration

`CalculationExecutionState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```php
use AmazonAthenaLib\Models\CalculationExecutionState;

$calculationExecutionState = CalculationExecutionState::COMPLETED;
```

