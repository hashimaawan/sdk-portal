
# Status 5

The current status of the migration.

## Enumeration

`Status5`

## Fields

| Name |
|  --- |
| `Running` |
| `Canceled` |
| `Error` |
| `Done` |

## Example

```ts
import { Status5 } from 'digitalocean-apilib';

const status5 = Status5.Running;
```

