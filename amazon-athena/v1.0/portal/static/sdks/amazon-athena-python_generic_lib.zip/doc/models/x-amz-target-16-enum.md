
# X Amz Target 16 Enum

## Enumeration

`XAmzTarget16Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```python
from amazonathena.models.x_amz_target_16_enum import XAmzTarget16Enum

x_amz_target_16 = XAmzTarget16Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE
```

