
# X Amz Target 43 Enum

## Enumeration

`XAmzTarget43Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTABLEMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget43Enum;

XAmzTarget43Enum xAmzTarget43 = XAmzTarget43Enum.ENUM_AMAZONATHENALISTTABLEMETADATA;
```

