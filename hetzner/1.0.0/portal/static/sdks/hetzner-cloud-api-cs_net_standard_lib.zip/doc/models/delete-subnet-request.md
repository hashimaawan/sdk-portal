
# Delete Subnet Request

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IpRange` | `string` | Required | IP range of subnet to delete |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

DeleteSubnetRequest deleteSubnetRequest = new DeleteSubnetRequest
{
    IpRange = "10.0.1.0/24",
};
```

