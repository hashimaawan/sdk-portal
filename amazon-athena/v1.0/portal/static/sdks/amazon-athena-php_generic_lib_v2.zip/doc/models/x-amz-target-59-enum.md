
# X Amz Target 59 Enum

## Enumeration

`XAmzTarget59Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEWORKGROUP` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget59Enum;

$xAmzTarget59 = XAmzTarget59Enum::ENUM_AMAZONATHENAUPDATEWORKGROUP;
```

