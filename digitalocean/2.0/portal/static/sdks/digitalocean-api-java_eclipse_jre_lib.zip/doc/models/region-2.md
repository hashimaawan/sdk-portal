
# Region 2

The slug identifier for the region where the resource will initially be  available.

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `AMS1` |
| `AMS2` |
| `AMS3` |
| `BLR1` |
| `FRA1` |
| `LON1` |
| `NYC1` |
| `NYC2` |
| `NYC3` |
| `SFO1` |
| `SFO2` |
| `SFO3` |
| `SGP1` |
| `TOR1` |

## Example

```java
import com.digitalocean.api.models.Region2;

Region2 region2 = Region2.NYC1;
```

