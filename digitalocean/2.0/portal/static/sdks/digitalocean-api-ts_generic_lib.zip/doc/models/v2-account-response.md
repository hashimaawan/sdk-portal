
# V2 Account Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AccountResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account` | [`Account \| undefined`](../../doc/models/account.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Status, V2AccountResponse } from 'digitalocean-apilib';

const v2AccountResponse: V2AccountResponse = {
  account: {
    dropletLimit: 248,
    email: 'email6',
    emailVerified: false,
    floatingIpLimit: 164,
    status: Status.Warning,
    statusMessage: 'status_message8',
    uuid: 'uuid6',
    team: {
      name: 'name0',
      uuid: 'uuid6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

