
# Protocol 7

Protocol of the Load Balancer

## Enumeration

`Protocol7`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |
| `Https` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    protocol7 := models.Protocol7_Http

}
```

