
# Stop Query Execution Input

## Structure

`StopQueryExecutionInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `QueryExecutionId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | String getQueryExecutionId() | setQueryExecutionId(String queryExecutionId) |

## Example

```java
import com.amazonaws.useast1.athena.models.StopQueryExecutionInput;

StopQueryExecutionInput stopQueryExecutionInput = new StopQueryExecutionInput.Builder(
    "QueryExecutionId4"
)
.build();
```

