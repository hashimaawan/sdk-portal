
# Status 72 Enum

Status of the Firewall on the Server

## Enumeration

`Status72Enum`

## Fields

| Name |
|  --- |
| `APPLIED` |
| `PENDING` |

## Example

```java
import cloud.hetzner.api.models.Status72Enum;

Status72Enum status72 = Status72Enum.APPLIED;
```

