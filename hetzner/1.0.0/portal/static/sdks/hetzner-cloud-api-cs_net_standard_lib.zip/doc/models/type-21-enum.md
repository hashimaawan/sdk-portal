
# Type 21 Enum

## Enumeration

`Type21Enum`

## Fields

| Name |
|  --- |
| `MSystem` |
| `Snapshot` |
| `Backup` |
| `App` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type21Enum type21 = Type21Enum.Backup;
```

