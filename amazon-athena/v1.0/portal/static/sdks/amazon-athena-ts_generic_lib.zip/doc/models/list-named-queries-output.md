
# List Named Queries Output

## Structure

`ListNamedQueriesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namedQueryIds` | `string[] \| undefined` | Optional | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListNamedQueriesOutput } from 'amazon-athenalib';

const listNamedQueriesOutput: ListNamedQueriesOutput = {
  namedQueryIds: [
    'NamedQueryIds5',
    'NamedQueryIds4',
    'NamedQueryIds3'
  ],
  nextToken: 'NextToken2',
};
```

