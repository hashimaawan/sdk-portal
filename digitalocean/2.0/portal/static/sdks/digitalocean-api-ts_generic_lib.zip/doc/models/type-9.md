
# Type 9

Describes the kind of image. It may be one of `base`, `snapshot`, `backup`, `custom`, or `admin`. Respectively, this specifies whether an image is a DigitalOcean base OS image, user-generated Droplet snapshot, automatically created Droplet backup, user-provided virtual machine image, or an image used for DigitalOcean managed resources (e.g. DOKS worker nodes).

## Enumeration

`Type9`

## Fields

| Name |
|  --- |
| `Base` |
| `Snapshot` |
| `Backup` |
| `Custom` |
| `Admin` |

## Example

```ts
import { Type9 } from 'digitalocean-apilib';

const type9 = Type9.Custom;
```

