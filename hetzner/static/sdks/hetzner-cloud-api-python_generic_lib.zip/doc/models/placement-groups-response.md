
# Placement Groups Response

## Structure

`PlacementGroupsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |
| `placement_groups` | [`List[PlacementGroup]`](../../doc/models/placement-group.md) | Required | - |

## Example

```python
from hetznercloudapi.models.meta import Meta
from hetznercloudapi.models.pagination import Pagination
from hetznercloudapi.models.placement_group import PlacementGroup
from hetznercloudapi.models.placement_groups_response import PlacementGroupsResponse

placement_groups_response = PlacementGroupsResponse(
    placement_groups=[
        PlacementGroup(
            created='2016-01-30T23:55:00+00:00',
            id=42,
            labels={
                'key0': 'labels0',
                'key1': 'labels1'
            },
            name='my-resource',
            servers=[
                42
            ]
        )
    ],
    meta=Meta(
        pagination=Pagination(
            last_page=77.7,
            next_page=209.18,
            page=17.58,
            per_page=13.34,
            previous_page=50.02,
            total_entries=206.64
        )
    )
)
```

