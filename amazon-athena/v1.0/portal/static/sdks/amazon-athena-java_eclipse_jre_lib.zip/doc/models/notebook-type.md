
# Notebook Type

## Enumeration

`NotebookType`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```java
import com.amazonaws.useast1.athena.models.NotebookType;

NotebookType notebookType = NotebookType.IPYNB;
```

