
# S3 Acl Option Enum

## Enumeration

`S3AclOptionEnum`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```ruby
s3_acl_option = S3AclOptionEnum::BUCKET_OWNER_FULL_CONTROL
```

