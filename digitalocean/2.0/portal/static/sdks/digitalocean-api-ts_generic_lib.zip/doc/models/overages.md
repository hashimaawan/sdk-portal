
# Overages

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Overages`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `string \| undefined` | Optional | Total amount charged in USD |
| `name` | `string \| undefined` | Optional | Name of the charge |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Overages } from 'digitalocean-apilib';

const overages: Overages = {
  amount: '3.45',
  name: 'Overages',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

