
# Type 48 Enum

The type of the Floating IP

## Enumeration

`Type48Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```ruby
type48 = Type48Enum::IPV4
```

