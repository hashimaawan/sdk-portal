
# Applied To

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appliedToResources` | [`AppliedToResource[] \| undefined`](../../doc/models/applied-to-resource.md) | Optional | - |
| `labelSelector` | [`LabelSelector \| undefined`](../../doc/models/label-selector.md) | Optional | - |
| `server` | [`Server \| undefined`](../../doc/models/server.md) | Optional | - |
| `type` | [`Type6Enum`](../../doc/models/type-6-enum.md) | Required | Type of resource referenced |

## Example

```ts
import { AppliedTo, Type5Enum, Type6Enum } from 'hetzner-cloud-apilib';

const appliedTo: AppliedTo = {
  type: Type6Enum.Server,
  appliedToResources: [
    {
      server: {
        id: 14,
      },
      type: Type5Enum.Server,
    },
    {
      server: {
        id: 14,
      },
      type: Type5Enum.Server,
    }
  ],
  labelSelector: {
    selector: 'selector8',
  },
  server: {
    id: 14,
  },
};
```

