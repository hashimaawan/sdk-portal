
# Notebook Type 2 Enum

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```ts
import { NotebookType2Enum } from 'amazon-athenalib';

const notebookType2 = NotebookType2Enum.IPYNB;
```

