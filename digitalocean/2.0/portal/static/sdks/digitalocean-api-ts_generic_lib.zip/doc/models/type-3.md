
# Type 3

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `Unspecified` |
| `Build` |
| `Deploy` |
| `Run` |

## Example

```ts
import { Type3 } from 'digitalocean-apilib';

const type3 = Type3.Deploy;
```

