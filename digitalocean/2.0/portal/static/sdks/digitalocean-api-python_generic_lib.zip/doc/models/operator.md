
# Operator

## Enumeration

`Operator`

## Fields

| Name |
|  --- |
| `UNSPECIFIED_OPERATOR` |
| `GREATER_THAN` |
| `LESS_THAN` |

## Example

```python
from digitaloceanapi.models.operator import Operator

operator = Operator.LESS_THAN
```

