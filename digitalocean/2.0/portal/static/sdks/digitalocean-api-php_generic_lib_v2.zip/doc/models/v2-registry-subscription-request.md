
# V2 Registry Subscription Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2RegistrySubscriptionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `tierSlug` | [`?string(TierSlug)`](../../doc/models/tier-slug.md) | Optional | The slug of the subscription tier to sign up for. | getTierSlug(): ?string | setTierSlug(?string tierSlug): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2RegistrySubscriptionRequestBuilder;
use DigitalOceanApiLib\Models\TierSlug;
use DigitalOceanApiLib\ApiHelper;

$v2RegistrySubscriptionRequest = V2RegistrySubscriptionRequestBuilder::init()
    ->tierSlug(TierSlug::BASIC)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

