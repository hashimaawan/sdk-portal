
# X Amz Target 55

## Enumeration

`XAmzTarget55`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_55 import XAmzTarget55

x_amz_target_55 = XAmzTarget55.ENUM_AMAZONATHENAUPDATENAMEDQUERY
```

