# Load Balancer Types

```php
$loadBalancerTypesController = $client->getLoadBalancerTypesController();
```

## Class Name

`LoadBalancerTypesController`

## Methods

* [Get All Load Balancer Types](../../doc/controllers/load-balancer-types.md#get-all-load-balancer-types)
* [Get a Load Balancer Type](../../doc/controllers/load-balancer-types.md#get-a-load-balancer-type)


# Get All Load Balancer Types

Gets all Load Balancer type objects.

```php
function getAllLoadBalancerTypes(?string $name = null): LoadBalancerTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `?string` | Query, Optional | Can be used to filter Load Balancer types by their name. The response will only contain the Load Balancer type matching the specified name. |

## Response Type

**200**: The `load_balancer_types` key in the reply contains an array of Load Balancer type objects with this structure

[`LoadBalancerTypesResponse`](../../doc/models/load-balancer-types-response.md)

## Example Usage

```php
$loadBalancerTypesController = $client->getLoadBalancerTypesController();

try {
    $result = $loadBalancerTypesController->getAllLoadBalancerTypes();
    echo 'LoadBalancerTypesResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get a Load Balancer Type

Gets a specific Load Balancer type object.

```php
function getALoadBalancerType(int $id): LoadBalancerTypesResponse1
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Load Balancer type |

## Response Type

**200**: The `load_balancer_type` key in the reply contains a Load Balancer type object with this structure

[`LoadBalancerTypesResponse1`](../../doc/models/load-balancer-types-response-1.md)

## Example Usage

```php
$id = 112;

$loadBalancerTypesController = $client->getLoadBalancerTypesController();

try {
    $result = $loadBalancerTypesController->getALoadBalancerType($id);
    echo 'LoadBalancerTypesResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

