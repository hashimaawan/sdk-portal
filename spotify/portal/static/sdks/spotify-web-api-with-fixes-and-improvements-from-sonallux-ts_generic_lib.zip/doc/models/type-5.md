
# Type 5

The object type.

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `AudioFeatures` |

## Example

```ts
import {
  Type5,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const type5 = Type5.AudioFeatures;
```

