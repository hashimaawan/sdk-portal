
# Update Image Request

## Structure

`UpdateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `*string` | Optional | New description of Image |
| `Labels` | `*interface{}` | Optional | User-defined labels (key-value pairs) |
| `Type` | [`*models.Type24Enum`](../../doc/models/type-24-enum.md) | Optional | Destination Image type to convert to |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    updateImageRequest := models.UpdateImageRequest{
        Description:          models.ToPointer("My new Image description"),
        Labels:               models.ToPointer(interface{}("[labelkey, value]")),
        Type:                 models.ToPointer(models.Type24Enum_SNAPSHOT),
    }

}
```

