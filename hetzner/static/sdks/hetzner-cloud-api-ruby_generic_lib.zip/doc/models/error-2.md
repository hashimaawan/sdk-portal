
# Error 2

If issuance or renewal reports `failed`, this property contains information about what happened

## Structure

`Error2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Optional | - |
| `message` | `String` | Optional | - |

## Example

```ruby
error2 = Error2.new(
  'code2',
  'message4'
)
```

