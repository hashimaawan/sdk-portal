
# Terminate Session Request

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getSessionId(): string | setSessionId(string sessionId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\TerminateSessionRequestBuilder;

$terminateSessionRequest = TerminateSessionRequestBuilder::init(
    'SessionId0'
)->build();
```

