
# Region 2

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `Cnnorth1` |
| `Cnnorthwest1` |

## Example

```ts
import { Region2 } from 'amazon-athenalib';

const region2 = Region2.Cnnorth1;
```

