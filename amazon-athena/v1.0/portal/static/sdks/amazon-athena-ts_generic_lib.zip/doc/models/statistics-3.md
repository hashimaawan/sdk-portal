
# Statistics 3

*This model accepts additional fields of type unknown.*

## Structure

`Statistics3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpuExecutionInMillis` | `number \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Statistics3 } from 'amazon-athenalib';

const statistics3: Statistics3 = {
  dpuExecutionInMillis: 130,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

