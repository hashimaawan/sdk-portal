
# Type 7

The type of resource that the firewall rule allows to access the database cluster.

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `K8S` |
| `IP_ADDR` |
| `TAG` |
| `APP` |

## Example

```python
from digitaloceanapi.models.type_7 import Type7

type_7 = Type7.TAG
```

