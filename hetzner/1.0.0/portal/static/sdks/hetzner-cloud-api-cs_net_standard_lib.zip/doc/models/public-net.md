
# Public Net

Public network information

## Structure

`PublicNet`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Enabled` | `bool` | Required | Public Interface enabled or not |
| `Ipv4` | [`Ipv4`](../../doc/models/ipv-4.md) | Required | IP address (v4) |
| `Ipv6` | [`Ipv6`](../../doc/models/ipv-6.md) | Required | IP address (v6) |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

PublicNet publicNet = new PublicNet
{
    Enabled = false,
    Ipv4 = new Ipv4
    {
        DnsPtr = "lb1.example.com",
        Ip = "1.2.3.4",
    },
    Ipv6 = new Ipv6
    {
        DnsPtr = "lb1.example.com",
        Ip = "2001:db8::1",
    },
};
```

