
# Query Runtime Statistics Rows

Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query.

## Structure

`QueryRuntimeStatisticsRows`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `input_rows` | `int` | Optional | - |
| `input_bytes` | `int` | Optional | - |
| `output_bytes` | `int` | Optional | - |
| `output_rows` | `int` | Optional | - |

## Example

```python
from amazonathena.models.query_runtime_statistics_rows import QueryRuntimeStatisticsRows

query_runtime_statistics_rows = QueryRuntimeStatisticsRows(
    input_rows=100,
    input_bytes=136,
    output_bytes=94,
    output_rows=104
)
```

