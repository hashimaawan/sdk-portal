
# Type 48

The type of the Floating IP

## Enumeration

`Type48`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type48 := models.Type48_Ipv4

}
```

