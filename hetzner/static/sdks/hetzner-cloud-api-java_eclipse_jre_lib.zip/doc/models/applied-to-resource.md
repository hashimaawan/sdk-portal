
# Applied to Resource

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Server` | [`Server`](../../doc/models/server.md) | Optional | - | Server getServer() | setServer(Server server) |
| `Type` | [`Type5Enum`](../../doc/models/type-5-enum.md) | Optional | Type of resource referenced | Type5Enum getType() | setType(Type5Enum type) |

## Example

```java
import cloud.hetzner.api.models.AppliedToResource;
import cloud.hetzner.api.models.Server;
import cloud.hetzner.api.models.Type5Enum;

AppliedToResource appliedToResource = new AppliedToResource.Builder()
    .server(new Server.Builder(
        14
    )
    .build())
    .type(Type5Enum.SERVER)
    .build();
```

