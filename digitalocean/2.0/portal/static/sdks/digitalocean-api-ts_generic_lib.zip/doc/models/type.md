
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Droplet` |
| `Kubernetes` |

## Example

```ts
import { Type } from 'digitalocean-apilib';

const type = Type.Droplet;
```

