
# Session Statistics

Contains statistics for a session.

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpuExecutionInMillis` | `number \| undefined` | Optional | - |

## Example

```ts
import { SessionStatistics } from 'amazon-athenalib';

const sessionStatistics: SessionStatistics = {
  dpuExecutionInMillis: 188,
};
```

