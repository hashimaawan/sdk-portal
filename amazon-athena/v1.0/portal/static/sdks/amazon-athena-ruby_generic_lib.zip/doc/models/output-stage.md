
# Output Stage

## Structure

`OutputStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stage_id` | `Integer` | Optional | - |
| `state` | `String` | Optional | - |
| `output_bytes` | `Integer` | Optional | - |
| `output_rows` | `Integer` | Optional | - |
| `input_bytes` | `Integer` | Optional | - |
| `input_rows` | `Integer` | Optional | - |
| `execution_time` | `Integer` | Optional | - |
| `query_stage_plan` | [`QueryStagePlan`](../../doc/models/query-stage-plan.md) | Optional | - |
| `sub_stages` | [`Array[QueryStage]`](../../doc/models/query-stage.md) | Optional | - |

## Example

```ruby
output_stage = OutputStage.new(
  152,
  'State2',
  86,
  180,
  44,
  nil,
  nil,
  QueryStagePlan.new(
    nil,
    nil,
    [],
    []
  ),
  []
)
```

