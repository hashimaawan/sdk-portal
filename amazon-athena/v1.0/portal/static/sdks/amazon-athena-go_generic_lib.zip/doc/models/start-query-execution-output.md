
# Start Query Execution Output

*This model accepts additional fields of type interface{}.*

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    startQueryExecutionOutput := models.StartQueryExecutionOutput{
        QueryExecutionId:      models.ToPointer("QueryExecutionId0"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

