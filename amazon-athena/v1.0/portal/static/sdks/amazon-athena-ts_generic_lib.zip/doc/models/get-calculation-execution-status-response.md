
# Get Calculation Execution Status Response

*This model accepts additional fields of type unknown.*

## Structure

`GetCalculationExecutionStatusResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`Status1 \| undefined`](../../doc/models/status-1.md) | Optional | - |
| `statistics` | [`Statistics1 \| undefined`](../../doc/models/statistics-1.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  CalculationExecutionState1,
  GetCalculationExecutionStatusResponse,
} from 'amazon-athenalib';

const getCalculationExecutionStatusResponse: GetCalculationExecutionStatusResponse = {
  status: {
    submissionDateTime: '2016-03-13T12:52:32.123Z',
    completionDateTime: '2016-03-13T12:52:32.123Z',
    state: CalculationExecutionState1.Canceling,
    stateChangeReason: 'StateChangeReason8',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  statistics: {
    dpuExecutionInMillis: 164,
    progress: 'Progress6',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

