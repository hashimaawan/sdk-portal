
# X Amz Target 57 Enum

## Enumeration

`XAmzTarget57Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNotebookMetadata` |

## Example

```ts
import { XAmzTarget57Enum } from 'amazon-athenalib';

const xAmzTarget57 = XAmzTarget57Enum.EnumAmazonAthenaUpdateNotebookMetadata;
```

