
# Character Set

## Enumeration

`CharacterSet`

## Fields

| Name |
|  --- |
| `Letters` |
| `Digits` |
| `Symbols` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    characterSet := models.CharacterSet_Digits

}
```

