
# Work Group State 2

The workgroup state that will be updated for the given workgroup.

## Enumeration

`WorkGroupState2`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```ts
import { WorkGroupState2 } from 'amazon-athenalib';

const workGroupState2 = WorkGroupState2.Enabled;
```

