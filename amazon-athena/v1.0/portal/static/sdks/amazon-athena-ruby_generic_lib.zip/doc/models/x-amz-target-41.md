
# X Amz Target 41

## Enumeration

`XAmzTarget41`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```ruby
x_amz_target41 = XAmzTarget41::ENUM_AMAZONATHENALISTQUERYEXECUTIONS
```

