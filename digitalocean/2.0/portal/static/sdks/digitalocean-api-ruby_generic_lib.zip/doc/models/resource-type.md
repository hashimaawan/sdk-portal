
# Resource Type

## Enumeration

`ResourceType`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `VOLUME` |

## Example

```ruby
resource_type = ResourceType::DROPLET
```

