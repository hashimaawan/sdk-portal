
# Delete Subnet Request

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IpRange` | `string` | Required | IP range of subnet to delete |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    deleteSubnetRequest := models.DeleteSubnetRequest{
        IpRange:              "10.0.1.0/24",
    }

}
```

