
# Sort 8 Enum

## Enumeration

`Sort8Enum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `NAME` |
| `ENUM_NAMEASC` |
| `ENUM_NAMEDESC` |

## Example

```python
from hetznercloudapi.models.sort_8_enum import Sort8Enum

sort_8 = Sort8Enum.ENUM_IDDESC
```

