
# Server

## Structure

`Server`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Resource |

## Example

```python
from hetznercloudapi.models.server import Server

server = Server(
    id=42
)
```

