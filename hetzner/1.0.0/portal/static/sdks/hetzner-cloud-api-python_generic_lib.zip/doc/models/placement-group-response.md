
# Placement Group Response

*This model accepts additional fields of type Any.*

## Structure

`PlacementGroupResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placement_group` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.placement_group import PlacementGroup
from hetznercloudapi.models.placement_group_response import PlacementGroupResponse

placement_group_response = PlacementGroupResponse(
    placement_group=PlacementGroup(
        created='2016-01-30T23:55:00+00:00',
        id=42,
        labels={
            'key0': 'labels4'
        },
        name='my-resource',
        servers=[
            42
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

