
# Log Line Prefix

Selects one of the available log-formats. These can support popular log analyzers like pgbadger, pganalyze, etc.

## Enumeration

`LogLinePrefix`

## Fields

| Name |
|  --- |
| `ENUM_PIDPUSERUDBDAPPACLIENTH` |
| `ENUM_M_P_QUSERUDBDAPPA` |
| `ENUM_T_P_L1_USERUDBDAPPACLIENTH` |

## Example

```php
use DigitalOceanApiLib\Models\LogLinePrefix;

$logLinePrefix = LogLinePrefix::ENUM_T_P_L1_USERUDBDAPPACLIENTH;
```

