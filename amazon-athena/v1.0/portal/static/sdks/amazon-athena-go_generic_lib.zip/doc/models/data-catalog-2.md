
# Data Catalog 2

## Structure

`DataCatalog2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Type` | [`models.DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `Parameters` | [`*models.Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    dataCatalog2 := models.DataCatalog2{
        Name:                 "Name6",
        Description:          models.ToPointer("Description0"),
        Type:                 models.DataCatalogType1Enum_LAMBDA,
        Parameters:           models.ToPointer(models.Parameters{
        }),
    }

}
```

