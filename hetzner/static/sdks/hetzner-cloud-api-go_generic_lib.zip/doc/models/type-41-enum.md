
# Type 41 Enum

## Enumeration

`Type41Enum`

## Fields

| Name |
|  --- |
| `OPENCONNECTIONS` |
| `CONNECTIONSPERSECOND` |
| `REQUESTSPERSECOND` |
| `BANDWIDTH` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type41 := models.Type41Enum_REQUESTSPERSECOND

}
```

