
# Error 2

If issuance or renewal reports `failed`, this property contains information about what happened

## Structure

`Error2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `str` | Optional | - |
| `message` | `str` | Optional | - |

## Example

```python
from hetznercloudapi.models.error_2 import Error2

error_2 = Error2(
    code='code8',
    message='message0'
)
```

