
# X Amz Target 53

## Enumeration

`XAmzTarget53`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUntagResource` |

## Example

```ts
import { XAmzTarget53 } from 'amazon-athenalib';

const xAmzTarget53 = XAmzTarget53.EnumAmazonAthenaUntagResource;
```

