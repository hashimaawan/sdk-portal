
# Type 29

Type of the resource

## Enumeration

`Type29`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |
| `Ip` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type29 := models.Type29_Server

}
```

