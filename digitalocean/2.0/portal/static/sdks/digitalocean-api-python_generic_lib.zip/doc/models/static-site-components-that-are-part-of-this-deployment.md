
# Static Site Components that Are Part of This Deployment

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`StaticSiteComponentsThatArePartOfThisDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | - |
| `source_commit_hash` | `str` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.static_site_components_that_are_part_of_this_deployment import StaticSiteComponentsThatArePartOfThisDeployment

static_site_components_that_are_part_of_this_deployment = StaticSiteComponentsThatArePartOfThisDeployment(
    name='web',
    source_commit_hash='54d4a727f457231062439895000d45437c7bb405',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

