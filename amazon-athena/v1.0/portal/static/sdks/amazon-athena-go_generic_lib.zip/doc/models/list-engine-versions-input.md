
# List Engine Versions Input

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 10` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listEngineVersionsInput := models.ListEngineVersionsInput{
        NextToken:            models.ToPointer("NextToken6"),
        MaxResults:           models.ToPointer(10),
    }

}
```

