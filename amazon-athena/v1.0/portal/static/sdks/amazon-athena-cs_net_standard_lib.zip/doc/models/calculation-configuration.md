
# Calculation Configuration

Contains configuration information for the calculation.

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CodeBlock` | `string` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```csharp
using AmazonAthena.Standard.Models;

CalculationConfiguration calculationConfiguration = new CalculationConfiguration
{
    CodeBlock = "CodeBlock2",
};
```

