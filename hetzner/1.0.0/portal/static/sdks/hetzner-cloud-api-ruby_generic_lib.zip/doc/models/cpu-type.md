
# Cpu Type

Type of cpu

## Enumeration

`CpuType`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```ruby
cpu_type = CpuType::SHARED
```

