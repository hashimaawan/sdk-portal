
# V21 Clicks Kubernetes Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V21ClicksKubernetesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `str` | Optional | A message about the result of the request. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_21_clicks_kubernetes_response import V21ClicksKubernetesResponse

v_2_1_clicks_kubernetes_response = V21ClicksKubernetesResponse(
    message='Successfully kicked off addon job.',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

