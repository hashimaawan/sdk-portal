
# Status 16

## Enumeration

`Status16`

## Fields

| Name |
|  --- |
| `DOWN` |
| `UP` |
| `CHECKING` |

## Example

```java
import com.digitalocean.api.models.Status16;

Status16 status16 = Status16.DOWN;
```

