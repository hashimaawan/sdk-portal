
# Result Set

The metadata and rows that make up a query result set. The metadata describes the column structure and data types. To return a <code>ResultSet</code> object, use <a>GetQueryResults</a>.

*This model accepts additional fields of type Object.*

## Structure

`ResultSet`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rows` | [`Array[Row]`](../../doc/models/row.md) | Optional | - |
| `result_set_metadata` | [`ResultSetMetadata2`](../../doc/models/result-set-metadata-2.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
result_set = ResultSet.new(
  rows: [
    Row.new(
      data: [
        Datum.new(
          var_char_value: 'VarCharValue8',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        Datum.new(
          var_char_value: 'VarCharValue8',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Row.new(
      data: [
        Datum.new(
          var_char_value: 'VarCharValue8',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        Datum.new(
          var_char_value: 'VarCharValue8',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Row.new(
      data: [
        Datum.new(
          var_char_value: 'VarCharValue8',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        Datum.new(
          var_char_value: 'VarCharValue8',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  result_set_metadata: ResultSetMetadata2.new(
    column_info: [
      ColumnInfo.new(
        name: 'Name6',
        type: 'Type6',
        catalog_name: 'CatalogName0',
        schema_name: 'SchemaName0',
        table_name: 'TableName2',
        label: 'Label4',
        precision: 48,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

