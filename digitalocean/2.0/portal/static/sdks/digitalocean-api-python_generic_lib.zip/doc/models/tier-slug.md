
# Tier Slug

The slug of the subscription tier to sign up for.

## Enumeration

`TierSlug`

## Fields

| Name |
|  --- |
| `STARTER` |
| `BASIC` |
| `PROFESSIONAL` |

## Example

```python
from digitaloceanapi.models.tier_slug import TierSlug

tier_slug = TierSlug.PROFESSIONAL
```

