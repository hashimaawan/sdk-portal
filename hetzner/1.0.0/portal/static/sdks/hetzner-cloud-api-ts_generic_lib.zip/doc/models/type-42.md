
# Type 42

Type of Subnetwork

## Enumeration

`Type42`

## Fields

| Name |
|  --- |
| `Cloud` |
| `Server` |
| `Vswitch` |

## Example

```ts
import { Type42 } from 'hetzner-cloud-apilib';

const type42 = Type42.Cloud;
```

