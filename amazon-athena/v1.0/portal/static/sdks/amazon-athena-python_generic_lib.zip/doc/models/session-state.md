
# Session State

## Enumeration

`SessionState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```python
from amazonathena.models.session_state import SessionState

session_state = SessionState.IDLE
```

