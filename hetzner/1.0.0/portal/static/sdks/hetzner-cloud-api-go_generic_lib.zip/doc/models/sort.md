
# Sort

## Enumeration

`Sort`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    sort := models.Sort_EnumIdasc

}
```

