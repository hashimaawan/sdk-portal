
# List Application Dpu Sizes Output

*This model accepts additional fields of type array.*

## Structure

`ListApplicationDpuSizesOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `applicationDpuSizes` | [`?(ApplicationDpuSizes[])`](../../doc/models/application-dpu-sizes.md) | Optional | - | getApplicationDpuSizes(): ?array | setApplicationDpuSizes(?array applicationDpuSizes): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListApplicationDpuSizesOutputBuilder;
use AmazonAthenaLib\Models\Builders\ApplicationDpuSizesBuilder;
use AmazonAthenaLib\ApiHelper;

$listApplicationDpuSizesOutput = ListApplicationDpuSizesOutputBuilder::init()
    ->applicationDpuSizes(
        [
            ApplicationDpuSizesBuilder::init()
                ->applicationRuntimeId('ApplicationRuntimeId0')
                ->supportedDpuSizes(
                    [
                        113,
                        114
                    ]
                )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            ApplicationDpuSizesBuilder::init()
                ->applicationRuntimeId('ApplicationRuntimeId0')
                ->supportedDpuSizes(
                    [
                        113,
                        114
                    ]
                )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->nextToken('NextToken0')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

