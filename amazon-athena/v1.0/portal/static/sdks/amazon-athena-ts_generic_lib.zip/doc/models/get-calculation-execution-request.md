
# Get Calculation Execution Request

## Structure

`GetCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```ts
import { GetCalculationExecutionRequest } from 'amazon-athenalib';

const getCalculationExecutionRequest: GetCalculationExecutionRequest = {
  calculationExecutionId: 'CalculationExecutionId2',
};
```

