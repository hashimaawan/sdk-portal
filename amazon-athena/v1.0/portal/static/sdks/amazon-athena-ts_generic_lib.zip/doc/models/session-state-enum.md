
# Session State Enum

## Enumeration

`SessionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```ts
import { SessionStateEnum } from 'amazon-athenalib';

const sessionState = SessionStateEnum.TERMINATING;
```

