
# Resource Type

## Enumeration

`ResourceType`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `VOLUME` |

## Example

```php
use DigitalOceanApiLib\Models\ResourceType;

$resourceType = ResourceType::DROPLET;
```

