
# Forbidden Exception

*This model accepts additional fields of type object.*

## Structure

`ForbiddenException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`ErrorObject`](../../doc/models/error-object.md) | Required | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
try
{
    // make the API call
}
catch (ApiException e)
{
    if (e is ForbiddenException)
    {
        // TODO: Handle ForbiddenException
        Console.WriteLine(e.Message);
    }
}
```

