
# Get Named Query Output

## Structure

`GetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query` | [`NamedQuery1`](../../doc/models/named-query-1.md) | Optional | - |

## Example

```python
from amazonathena.models.get_named_query_output import GetNamedQueryOutput
from amazonathena.models.named_query_1 import NamedQuery1

get_named_query_output = GetNamedQueryOutput(
    named_query=NamedQuery1(
        name='Name0',
        database='Database8',
        query_string='QueryString2',
        description='Description6',
        named_query_id='NamedQueryId2',
        work_group='WorkGroup2'
    )
)
```

