
# X Amz Target 33 Enum

## Enumeration

`XAmzTarget33Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATACATALOGS` |

## Example

```ruby
x_amz_target33 = XAmzTarget33Enum::ENUM_AMAZONATHENALISTDATACATALOGS
```

