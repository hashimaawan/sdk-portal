
# Instance Size Slug

The instance size to use for this component. Default: `basic-xxs`

## Enumeration

`InstanceSizeSlug`

## Fields

| Name |
|  --- |
| `Basicxxs` |
| `Basicxs` |
| `Basics` |
| `Basicm` |
| `Professionalxs` |
| `Professionals` |
| `Professionalm` |
| `Professional1L` |
| `Professionall` |
| `Professionalxl` |

## Example

```ts
import { InstanceSizeSlug } from 'digitalocean-apilib';

const instanceSizeSlug = InstanceSizeSlug.Professionall;
```

