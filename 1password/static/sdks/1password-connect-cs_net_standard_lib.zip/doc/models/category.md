
# Category

## Enumeration

`Category`

## Fields

| Name |
|  --- |
| `Login` |
| `Password` |
| `ApiCredential` |
| `Server` |
| `Database` |
| `CreditCard` |
| `Membership` |
| `Passport` |
| `SoftwareLicense` |
| `OutdoorLicense` |
| `SecureNote` |
| `WirelessRouter` |
| `BankAccount` |
| `DriverLicense` |
| `Identity` |
| `RewardProgram` |
| `Document` |
| `EmailAccount` |
| `SocialSecurityNumber` |
| `MedicalRecord` |
| `SshKey` |
| `Custom` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

Category category = Category.SocialSecurityNumber;
```

