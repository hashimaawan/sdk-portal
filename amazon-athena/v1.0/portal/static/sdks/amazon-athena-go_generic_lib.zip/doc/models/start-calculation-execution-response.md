
# Start Calculation Execution Response

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `State` | [`*models.CalculationExecutionState4Enum`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    startCalculationExecutionResponse := models.StartCalculationExecutionResponse{
        CalculationExecutionId: models.ToPointer("CalculationExecutionId0"),
        State:                  models.ToPointer(models.CalculationExecutionState4Enum_CANCELING),
    }

}
```

