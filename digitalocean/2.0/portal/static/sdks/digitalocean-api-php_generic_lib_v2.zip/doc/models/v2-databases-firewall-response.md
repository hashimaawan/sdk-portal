
# V2 Databases Firewall Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesFirewallResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `rules` | [`?(Rule1[])`](../../doc/models/rule-1.md) | Optional | - | getRules(): ?array | setRules(?array rules): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesFirewallResponseBuilder;
use DigitalOceanApiLib\Models\Builders\Rule1Builder;
use DigitalOceanApiLib\Models\Type7;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesFirewallResponse = V2DatabasesFirewallResponseBuilder::init()
    ->rules(
        [
            Rule1Builder::init(
                Type7::IP_ADDR,
                'value0'
            )
                ->clusterUuid('cluster_uuid4')
                ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->uuid('uuid4')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

