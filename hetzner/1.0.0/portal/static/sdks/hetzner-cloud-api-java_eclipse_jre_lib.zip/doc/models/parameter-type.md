
# Parameter Type

## Enumeration

`ParameterType`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```java
import cloud.hetzner.api.models.ParameterType;

ParameterType parameterType = ParameterType.UPLOADED;
```

