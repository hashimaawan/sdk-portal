
# Server Public Net Firewall

## Structure

`ServerPublicNetFirewall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | ID of the Resource |
| `status` | [`Status72Enum`](../../doc/models/status-72-enum.md) | Optional | Status of the Firewall on the Server |

## Example

```python
from hetznercloudapi.models.server_public_net_firewall import ServerPublicNetFirewall
from hetznercloudapi.models.status_72_enum import Status72Enum

server_public_net_firewall = ServerPublicNetFirewall(
    id=42,
    status=Status72Enum.APPLIED
)
```

