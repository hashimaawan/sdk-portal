
# Batch Get Prepared Statement Output

*This model accepts additional fields of type unknown.*

## Structure

`BatchGetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preparedStatements` | [`PreparedStatement[] \| undefined`](../../doc/models/prepared-statement.md) | Optional | - |
| `unprocessedPreparedStatementNames` | [`UnprocessedPreparedStatementName[] \| undefined`](../../doc/models/unprocessed-prepared-statement-name.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { BatchGetPreparedStatementOutput } from 'amazon-athenalib';

const batchGetPreparedStatementOutput: BatchGetPreparedStatementOutput = {
  preparedStatements: [
    {
      statementName: 'StatementName2',
      queryStatement: 'QueryStatement6',
      workGroupName: 'WorkGroupName6',
      description: 'Description2',
      lastModifiedTime: '2016-03-13T12:52:32.123Z',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      statementName: 'StatementName2',
      queryStatement: 'QueryStatement6',
      workGroupName: 'WorkGroupName6',
      description: 'Description2',
      lastModifiedTime: '2016-03-13T12:52:32.123Z',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  unprocessedPreparedStatementNames: [
    {
      statementName: 'StatementName0',
      errorCode: 'ErrorCode2',
      errorMessage: 'ErrorMessage8',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      statementName: 'StatementName0',
      errorCode: 'ErrorCode2',
      errorMessage: 'ErrorMessage8',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      statementName: 'StatementName0',
      errorCode: 'ErrorCode2',
      errorMessage: 'ErrorMessage8',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

