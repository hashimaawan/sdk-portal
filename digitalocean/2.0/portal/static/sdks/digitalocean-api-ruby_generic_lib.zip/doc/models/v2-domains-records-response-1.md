
# V2 Domains Records Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DomainsRecordsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `domain_record` | [`DomainRecord`](../../doc/models/domain-record.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_domains_records_response1 = V2DomainsRecordsResponse1.new(
  domain_record: DomainRecord.new(
    type: 'A',
    data: '162.10.66.0',
    flags: nil,
    id: 28448433,
    name: 'www',
    port: nil,
    priority: nil,
    tag: nil,
    ttl: 1800,
    weight: nil,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

