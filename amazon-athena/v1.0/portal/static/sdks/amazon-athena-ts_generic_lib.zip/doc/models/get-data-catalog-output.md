
# Get Data Catalog Output

*This model accepts additional fields of type unknown.*

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dataCatalog` | [`DataCatalog2 \| undefined`](../../doc/models/data-catalog-2.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DataCatalogType1, GetDataCatalogOutput } from 'amazon-athenalib';

const getDataCatalogOutput: GetDataCatalogOutput = {
  dataCatalog: {
    name: 'Name4',
    type: DataCatalogType1.Glue,
    description: 'Description2',
    parameters: {
      additionalProperties: {
        'exampleAdditionalProperty': 'Parameters_additionalProperties2'
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

