
# X Amz Target 31 Enum

## Enumeration

`XAmzTarget31Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget31Enum;

$xAmzTarget31 = XAmzTarget31Enum::ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES;
```

