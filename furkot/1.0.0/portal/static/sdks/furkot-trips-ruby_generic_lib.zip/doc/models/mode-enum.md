
# Mode Enum

travel mode

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```ruby
mode = ModeEnum::BICYCLE
```

