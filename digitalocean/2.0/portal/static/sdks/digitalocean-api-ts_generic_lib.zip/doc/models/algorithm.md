
# Algorithm

This field has been deprecated. You can no longer specify an algorithm for load balancers.

## Enumeration

`Algorithm`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```ts
import { Algorithm } from 'digitalocean-apilib';

const algorithm = Algorithm.RoundRobin;
```

