
# V2 Account Keys Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2AccountKeysResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sshKey` | [`?SshKey`](../../doc/models/ssh-key.md) | Optional | - | getSshKey(): ?SshKey | setSshKey(?SshKey sshKey): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2AccountKeysResponse1Builder;
use DigitalOceanApiLib\Models\Builders\SshKeyBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2AccountKeysResponse1 = V2AccountKeysResponse1Builder::init()
    ->sshKey(
        SshKeyBuilder::init(
            'name2',
            'public_key4'
        )
            ->fingerprint('fingerprint8')
            ->id(204)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

