
# Status 70 Enum

## Enumeration

`Status70Enum`

## Fields

| Name |
|  --- |
| `INITIALIZING` |
| `STARTING` |
| `RUNNING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `REBUILDING` |
| `MIGRATING` |
| `UNKNOWN` |

## Example

```java
import cloud.hetzner.api.models.Status70Enum;

Status70Enum status70 = Status70Enum.MIGRATING;
```

