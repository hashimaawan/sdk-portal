
# Type 51 Enum

Primary IP type

## Enumeration

`Type51Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type51 := models.Type51Enum_IPV4

}
```

