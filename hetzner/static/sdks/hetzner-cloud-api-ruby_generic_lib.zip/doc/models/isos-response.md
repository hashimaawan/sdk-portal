
# Isos Response

## Structure

`IsosResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isos` | [`Array[Iso]`](../../doc/models/iso.md) | Required | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |

## Example

```ruby
isos_response = IsosResponse.new(
  [
    Iso.new(
      '2018-02-28T00:00:00+00:00',
      'FreeBSD 11.0 x64',
      42,
      'FreeBSD-11.0-RELEASE-amd64-dvd1',
      Type26Enum::PUBLIC
    )
  ],
  Meta.new(
    Pagination.new(
      77.7,
      209.18,
      17.58,
      13.34,
      50.02,
      206.64
    )
  )
)
```

