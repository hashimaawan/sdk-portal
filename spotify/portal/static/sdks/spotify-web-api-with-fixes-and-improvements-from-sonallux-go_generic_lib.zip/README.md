
# Getting Started with Spotify Web API with fixes and improvements from sonallux

## Introduction

You can use Spotify's Web API to discover music and podcasts, manage your Spotify library, control audio playback, and much more. Browse our available Web API endpoints using the sidebar at left, or via the navigation bar on top of this page on smaller screens.

In order to make successful Web API requests your app will need a valid access token. One can be obtained through <a href="https://developer.spotify.com/documentation/general/guides/authorization-guide/">OAuth 2.0</a>.

The base URI for all Web API requests is `https://api.spotify.com/v1`.

Need help? See our <a href="https://developer.spotify.com/documentation/web-api/guides/">Web API guides</a> for more information, or visit the <a href="https://community.spotify.com/t5/Spotify-for-Developers/bd-p/Spotify_Developer">Spotify for Developers community forum</a> to ask questions and connect with other developers.

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the spotifyWebApiWithFixesAndImprovementsFromSonallux library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace spotifyWebApiWithFixesAndImprovementsFromSonallux => ".\\spotify-web-api-with-fixes-and-improvements-from-sonallux-go_generic_lib" // local path to the SDK

require spotifyWebApiWithFixesAndImprovementsFromSonallux v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |
| authorizationCodeAuth | [`AuthorizationCodeAuth`](doc/auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux"
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    client := spotifyWebApiWithFixesAndImprovementsFromSonallux.NewClient(
    spotifyWebApiWithFixesAndImprovementsFromSonallux.CreateConfiguration(
            spotifyWebApiWithFixesAndImprovementsFromSonallux.WithHttpConfiguration(
                spotifyWebApiWithFixesAndImprovementsFromSonallux.CreateHttpConfiguration(
                    spotifyWebApiWithFixesAndImprovementsFromSonallux.WithTimeout(30),
                ),
            ),
            spotifyWebApiWithFixesAndImprovementsFromSonallux.WithEnvironment(spotifyWebApiWithFixesAndImprovementsFromSonallux.PRODUCTION),
            spotifyWebApiWithFixesAndImprovementsFromSonallux.WithAuthorizationCodeAuthCredentials(
                spotifyWebApiWithFixesAndImprovementsFromSonallux.NewAuthorizationCodeAuthCredentials(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScope{
        models.OauthScope_AppRemoteControl,
        models.OauthScope_PlaylistReadPrivate,
    }),
            ),
            spotifyWebApiWithFixesAndImprovementsFromSonallux.WithLoggerConfiguration(
                spotifyWebApiWithFixesAndImprovementsFromSonallux.WithLevel("info"),
                spotifyWebApiWithFixesAndImprovementsFromSonallux.WithRequestConfiguration(
                    spotifyWebApiWithFixesAndImprovementsFromSonallux.WithRequestBody(true),
                ),
                spotifyWebApiWithFixesAndImprovementsFromSonallux.WithResponseConfiguration(
                    spotifyWebApiWithFixesAndImprovementsFromSonallux.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| Production | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`oauth_2_0 (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Albums](doc/controllers/albums.md)
* [Artists](doc/controllers/artists.md)
* [Audiobooks](doc/controllers/audiobooks.md)
* [Categories](doc/controllers/categories.md)
* [Chapters](doc/controllers/chapters.md)
* [Episodes](doc/controllers/episodes.md)
* [Genres](doc/controllers/genres.md)
* [Markets](doc/controllers/markets.md)
* [Player](doc/controllers/player.md)
* [Playlists](doc/controllers/playlists.md)
* [Search](doc/controllers/search.md)
* [Shows](doc/controllers/shows.md)
* [Tracks](doc/controllers/tracks.md)
* [Users](doc/controllers/users.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

