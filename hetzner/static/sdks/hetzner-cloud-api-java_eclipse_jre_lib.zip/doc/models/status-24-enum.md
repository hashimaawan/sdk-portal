
# Status 24 Enum

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24Enum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |
| `UNAVAILABLE` |

## Example

```java
import cloud.hetzner.api.models.Status24Enum;

Status24Enum status24 = Status24Enum.AVAILABLE;
```

