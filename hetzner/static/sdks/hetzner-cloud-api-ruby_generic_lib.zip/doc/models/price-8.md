
# Price 8

## Structure

`Price8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location` | `String` | Required | Name of the Location the price is for |
| `price_hourly` | [`PriceHourly7`](../../doc/models/price-hourly-7.md) | Required | Hourly costs for a Primary IP type in this Location |
| `price_monthly` | [`PriceMonthly9`](../../doc/models/price-monthly-9.md) | Required | Monthly costs for a Primary IP type in this Location |

## Example

```ruby
price8 = Price8.new(
  'fsn1',
  PriceHourly7.new(
    '1.1900000000000000',
    '1.0000000000'
  ),
  PriceMonthly9.new(
    '1.1900000000000000',
    '1.0000000000'
  )
)
```

