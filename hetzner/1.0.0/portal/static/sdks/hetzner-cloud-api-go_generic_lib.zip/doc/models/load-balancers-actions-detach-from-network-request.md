
# Load Balancers Actions Detach from Network Request

*This model accepts additional fields of type interface{}.*

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Network` | `float64` | Required | ID of an existing network to detach the Load Balancer from |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    loadBalancersActionsDetachFromNetworkRequest := models.LoadBalancersActionsDetachFromNetworkRequest{
        Network:               float64(4711),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

