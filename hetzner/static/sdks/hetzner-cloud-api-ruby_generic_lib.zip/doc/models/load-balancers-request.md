
# Load Balancers Request

## Structure

`LoadBalancersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New Load Balancer name |

## Example

```ruby
load_balancers_request = LoadBalancersRequest.new(
  { 'labelkey' => 'value' },
  'new-name'
)
```

