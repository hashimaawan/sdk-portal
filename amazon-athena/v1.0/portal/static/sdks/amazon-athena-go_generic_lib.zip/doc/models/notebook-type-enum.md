
# Notebook Type Enum

## Enumeration

`NotebookTypeEnum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    notebookType := models.NotebookTypeEnum_IPYNB

}
```

