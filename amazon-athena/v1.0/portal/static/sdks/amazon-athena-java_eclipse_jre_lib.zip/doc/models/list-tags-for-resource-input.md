
# List Tags for Resource Input

## Structure

`ListTagsForResourceInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ResourceARN` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` | String getResourceARN() | setResourceARN(String resourceARN) |
| `NextToken` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getNextToken() | setNextToken(String nextToken) |
| `MaxResults` | `Integer` | Optional | **Constraints**: `>= 75` | Integer getMaxResults() | setMaxResults(Integer maxResults) |

## Example

```java
import com.amazonaws.useast1.athena.models.ListTagsForResourceInput;

ListTagsForResourceInput listTagsForResourceInput = new ListTagsForResourceInput.Builder(
    "ResourceARN0"
)
.nextToken("NextToken0")
.maxResults(76)
.build();
```

