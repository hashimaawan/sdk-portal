
# Filter Definition

A string for searching notebook names.

## Structure

`FilterDefinition`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```ruby
filter_definition = FilterDefinition.new(
  'Name8'
)
```

