
# Work Group State 1 Enum

The state of the workgroup.

## Enumeration

`WorkGroupState1Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```python
from amazonathena.models.work_group_state_1_enum import WorkGroupState1Enum

work_group_state_1 = WorkGroupState1Enum.ENABLED
```

