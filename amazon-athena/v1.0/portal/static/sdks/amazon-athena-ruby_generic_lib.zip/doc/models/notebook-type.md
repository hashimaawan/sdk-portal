
# Notebook Type

## Enumeration

`NotebookType`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```ruby
notebook_type = NotebookType::IPYNB
```

