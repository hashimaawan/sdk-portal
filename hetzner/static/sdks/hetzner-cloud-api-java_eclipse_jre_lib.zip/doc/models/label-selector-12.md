
# Label Selector 12

Configuration for label selector targets, required if type is `label_selector`

## Structure

`LabelSelector12`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Selector` | `String` | Required | Label selector | String getSelector() | setSelector(String selector) |

## Example

```java
import cloud.hetzner.api.models.LabelSelector12;

LabelSelector12 labelSelector12 = new LabelSelector12.Builder(
    "env=prod"
)
.build();
```

