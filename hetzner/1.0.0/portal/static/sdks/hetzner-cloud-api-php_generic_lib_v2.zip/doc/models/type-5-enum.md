
# Type 5 Enum

Type of resource referenced

## Enumeration

`Type5Enum`

## Fields

| Name |
|  --- |
| `SERVER` |

## Example

```php
use HetznerCloudAPILib\Models\Type5Enum;

$type5 = Type5Enum::SERVER;
```

