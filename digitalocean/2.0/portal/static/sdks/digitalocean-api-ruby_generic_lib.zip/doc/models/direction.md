
# Direction

## Enumeration

`Direction`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```ruby
direction = Direction::INBOUND
```

