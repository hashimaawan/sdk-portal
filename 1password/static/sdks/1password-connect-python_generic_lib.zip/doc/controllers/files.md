# Files

```python
files_api = client.files
```

## Class Name

`FilesApi`

## Methods

* [Get Item Files](../../doc/controllers/files.md#get-item-files)
* [Get Details of File by Id](../../doc/controllers/files.md#get-details-of-file-by-id)
* [Download File by ID](../../doc/controllers/files.md#download-file-by-id)


# Get Item Files

```python
def get_item_files(self,
                  vault_uuid,
                  item_uuid,
                  inline_files=None)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `uuid\|str` | Template, Required | The UUID of the Vault to fetch Items from |
| `item_uuid` | `uuid\|str` | Template, Required | The UUID of the Item to fetch files from |
| `inline_files` | `bool` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`List[File]`](../../doc/models/file.md).

## Example Usage

```python
vault_uuid = '00002186-0000-0000-0000-000000000000'

item_uuid = '0000141a-0000-0000-0000-000000000000'

inline_files = True

result = files_api.get_item_files(
    vault_uuid,
    item_uuid,
    inline_files=inline_files
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Details of File by Id

```python
def get_details_of_file_by_id(self,
                             vault_uuid,
                             item_uuid,
                             file_uuid,
                             inline_files=None)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `uuid\|str` | Template, Required | The UUID of the Vault to fetch Item from |
| `item_uuid` | `uuid\|str` | Template, Required | The UUID of the Item to fetch File from |
| `file_uuid` | `uuid\|str` | Template, Required | The UUID of the File to fetch |
| `inline_files` | `bool` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`File`](../../doc/models/file.md).

## Example Usage

```python
vault_uuid = '00002186-0000-0000-0000-000000000000'

item_uuid = '0000141a-0000-0000-0000-000000000000'

file_uuid = '000008e0-0000-0000-0000-000000000000'

inline_files = True

result = files_api.get_details_of_file_by_id(
    vault_uuid,
    item_uuid,
    file_uuid,
    inline_files=inline_files
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Download File by ID

```python
def download_file_by_id(self,
                       vault_uuid,
                       item_uuid,
                       file_uuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `uuid\|str` | Template, Required | The UUID of the Vault the item is in |
| `item_uuid` | `uuid\|str` | Template, Required | The UUID of the Item the File is in |
| `file_uuid` | `str` | Template, Required | UUID of the file to get content from |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `binary`.

## Example Usage

```python
vault_uuid = '00002186-0000-0000-0000-000000000000'

item_uuid = '0000141a-0000-0000-0000-000000000000'

file_uuid = 'fileUuid2'

result = files_api.download_file_by_id(
    vault_uuid,
    item_uuid,
    file_uuid
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

