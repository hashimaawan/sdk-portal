
# Type 20

The type of alert.

## Enumeration

`Type20`

## Fields

| Name |
|  --- |
| `Latency` |
| `Down` |
| `DownGlobal` |
| `SslExpiry` |

## Example

```ts
import { Type20 } from 'digitalocean-apilib';

const type20 = Type20.DownGlobal;
```

