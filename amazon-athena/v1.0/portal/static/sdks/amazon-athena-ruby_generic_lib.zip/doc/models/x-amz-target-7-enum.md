
# X Amz Target 7 Enum

## Enumeration

`XAmzTarget7Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL` |

## Example

```ruby
x_amz_target7 = XAmzTarget7Enum::ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL
```

