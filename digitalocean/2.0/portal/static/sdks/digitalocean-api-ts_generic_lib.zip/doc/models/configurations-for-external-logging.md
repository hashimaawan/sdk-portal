
# Configurations for External Logging

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`ConfigurationsForExternalLogging`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `datadog` | [`Datadog \| undefined`](../../doc/models/datadog.md) | Optional | DataDog configuration. |
| `logtail` | [`Logtail \| undefined`](../../doc/models/logtail.md) | Optional | Logtail configuration. |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `2`, *Maximum Length*: `42`, *Pattern*: `^[A-Za-z0-9()\[\]'"][-A-Za-z0-9_. \/()\[\]]{0,40}[A-Za-z0-9()\[\]'"]$` |
| `papertrail` | [`Papertrail \| undefined`](../../doc/models/papertrail.md) | Optional | Papertrail configuration. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { ConfigurationsForExternalLogging } from 'digitalocean-apilib';

const configurationsForExternalLogging: ConfigurationsForExternalLogging = {
  name: 'my_log_destination',
  datadog: {
    apiKey: 'api_key2',
    endpoint: 'endpoint8',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  logtail: {
    token: 'token4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  papertrail: {
    endpoint: 'endpoint4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

