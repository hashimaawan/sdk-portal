
# X Amz Target 18 Enum

## Enumeration

`XAmzTarget18Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetDataCatalog` |

## Example

```ts
import { XAmzTarget18Enum } from 'amazon-athenalib';

const xAmzTarget18 = XAmzTarget18Enum.EnumAmazonAthenaGetDataCatalog;
```

