
# Scheduled Details

Trigger details for SCHEDULED type, where body is optional.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`ScheduledDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Body \| null \| undefined`](../../doc/models/body.md) | Optional | Optional data to be sent to function while triggering the function. |
| `cron` | `string` | Required | valid cron expression string which is required for SCHEDULED type triggers. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { ScheduledDetails } from 'digitalocean-apilib';

const scheduledDetails: ScheduledDetails = {
  cron: '* * * * *',
  body: {
    name: 'name6',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

