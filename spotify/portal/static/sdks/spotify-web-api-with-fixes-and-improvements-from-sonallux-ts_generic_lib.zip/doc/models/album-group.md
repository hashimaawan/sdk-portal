
# Album Group

This field describes the relationship between the artist and the album.

## Enumeration

`AlbumGroup`

## Fields

| Name |
|  --- |
| `Album` |
| `Single` |
| `Compilation` |
| `AppearsOn` |

## Example

```ts
import {
  AlbumGroup,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const albumGroup = AlbumGroup.Compilation;
```

