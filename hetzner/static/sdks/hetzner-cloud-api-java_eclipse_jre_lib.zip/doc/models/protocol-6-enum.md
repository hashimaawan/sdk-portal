
# Protocol 6 Enum

Type of the health check

## Enumeration

`Protocol6Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |

## Example

```java
import cloud.hetzner.api.models.Protocol6Enum;

Protocol6Enum protocol6 = Protocol6Enum.TCP;
```

