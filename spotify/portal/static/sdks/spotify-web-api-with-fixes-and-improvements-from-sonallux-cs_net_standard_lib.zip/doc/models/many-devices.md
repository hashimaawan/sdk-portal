
# Many Devices

*This model accepts additional fields of type object.*

## Structure

`ManyDevices`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Devices` | [`List<DeviceObject>`](../../doc/models/device-object.md) | Required | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Utilities;
using System.Collections.Generic;

ManyDevices manyDevices = new ManyDevices
{
    Devices = new List<DeviceObject>
    {
        new DeviceObject
        {
            Id = "id4",
            IsActive = false,
            IsPrivateSession = false,
            IsRestricted = false,
            Name = "Kitchen speaker",
            Type = "computer",
            VolumePercent = 59,
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

