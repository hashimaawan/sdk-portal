
# Work Group State 2

The workgroup state that will be updated for the given workgroup.

## Enumeration

`WorkGroupState2`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    workGroupState2 := models.WorkGroupState2_Enabled

}
```

