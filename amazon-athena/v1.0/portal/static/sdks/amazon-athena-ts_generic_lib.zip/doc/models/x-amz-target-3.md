
# X Amz Target 3

## Enumeration

`XAmzTarget3`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateDataCatalog` |

## Example

```ts
import { XAmzTarget3 } from 'amazon-athenalib';

const xAmzTarget3 = XAmzTarget3.EnumAmazonAthenaCreateDataCatalog;
```

