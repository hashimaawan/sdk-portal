
# Os Flavor

Flavor of operating system contained in the Image

## Enumeration

`OsFlavor`

## Fields

| Name |
|  --- |
| `UBUNTU` |
| `CENTOS` |
| `DEBIAN` |
| `FEDORA` |
| `UNKNOWN` |

## Example

```java
import cloud.hetzner.api.models.OsFlavor;

OsFlavor osFlavor = OsFlavor.DEBIAN;
```

