
# Pg Stat Statements Track

Controls which statements are counted. Specify 'top' to track top-level statements (those issued directly by clients), 'all' to also track nested statements (such as statements invoked within functions), or 'none' to disable statement statistics collection. The default value is top.

## Enumeration

`PgStatStatementsTrack`

## Fields

| Name |
|  --- |
| `All` |
| `Top` |
| `None` |

## Example

```ts
import { PgStatStatementsTrack } from 'digitalocean-apilib';

const pgStatStatementsTrack = PgStatStatementsTrack.Top;
```

