
# Delete Work Group Input

## Structure

`DeleteWorkGroupInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `WorkGroup` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | String getWorkGroup() | setWorkGroup(String workGroup) |
| `RecursiveDeleteOption` | `Boolean` | Optional | - | Boolean getRecursiveDeleteOption() | setRecursiveDeleteOption(Boolean recursiveDeleteOption) |

## Example

```java
import com.amazonaws.useast1.athena.models.DeleteWorkGroupInput;

DeleteWorkGroupInput deleteWorkGroupInput = new DeleteWorkGroupInput.Builder(
    "WorkGroup0"
)
.recursiveDeleteOption(false)
.build();
```

