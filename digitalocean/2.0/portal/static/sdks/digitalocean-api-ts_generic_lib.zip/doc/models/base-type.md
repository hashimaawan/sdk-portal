
# Base Type

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`BaseType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { BaseType } from 'digitalocean-apilib';

const baseType: BaseType = {
  type: 'BaseType',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

