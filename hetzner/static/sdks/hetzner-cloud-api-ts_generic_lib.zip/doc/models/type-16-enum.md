
# Type 16 Enum

Type of the Floating IP

## Enumeration

`Type16Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type16Enum } from 'hetzner-cloud-apilib';

const type16 = Type16Enum.Ipv4;
```

