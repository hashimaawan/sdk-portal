
# Tier Slug

The slug of the subscription tier to sign up for.

## Enumeration

`TierSlug`

## Fields

| Name |
|  --- |
| `Starter` |
| `Basic` |
| `Professional` |

## Example

```ts
import { TierSlug } from 'digitalocean-apilib';

const tierSlug = TierSlug.Professional;
```

