
# Query Runtime Statistics 2

## Structure

`QueryRuntimeStatistics2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Timeline` | [`QueryRuntimeStatisticsTimeline`](../../doc/models/query-runtime-statistics-timeline.md) | Optional | Timeline statistics such as query queue time, planning time, execution time, service processing time, and total execution time. | QueryRuntimeStatisticsTimeline getTimeline() | setTimeline(QueryRuntimeStatisticsTimeline timeline) |
| `Rows` | [`QueryRuntimeStatisticsRows`](../../doc/models/query-runtime-statistics-rows.md) | Optional | Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query. | QueryRuntimeStatisticsRows getRows() | setRows(QueryRuntimeStatisticsRows rows) |
| `OutputStage` | [`OutputStage`](../../doc/models/output-stage.md) | Optional | - | OutputStage getOutputStage() | setOutputStage(OutputStage outputStage) |

## Example

```java
import com.amazonaws.useast1.athena.models.OutputStage;
import com.amazonaws.useast1.athena.models.QueryRuntimeStatistics2;
import com.amazonaws.useast1.athena.models.QueryRuntimeStatisticsRows;
import com.amazonaws.useast1.athena.models.QueryRuntimeStatisticsTimeline;

QueryRuntimeStatistics2 queryRuntimeStatistics2 = new QueryRuntimeStatistics2.Builder()
    .timeline(new QueryRuntimeStatisticsTimeline.Builder()
        .queryQueueTimeInMillis(156)
        .queryPlanningTimeInMillis(82)
        .engineExecutionTimeInMillis(112)
        .serviceProcessingTimeInMillis(126)
        .totalExecutionTimeInMillis(106)
        .build())
    .rows(new QueryRuntimeStatisticsRows.Builder()
        .inputRows(230)
        .inputBytes(250)
        .outputBytes(36)
        .outputRows(230)
        .build())
    .outputStage(new OutputStage.Builder()
        .stageId(130)
        .state("State0")
        .outputBytes(108)
        .outputRows(158)
        .inputBytes(190)
        .build())
    .build();
```

