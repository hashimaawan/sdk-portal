# Primary I Ps

```go
primaryIPsController := client.PrimaryIPsController()
```

## Class Name

`PrimaryIPsController`

## Methods

* [Get All Primary I Ps](../../doc/controllers/primary-i-ps.md#get-all-primary-i-ps)
* [Create a Primary IP](../../doc/controllers/primary-i-ps.md#create-a-primary-ip)
* [Delete a Primary IP](../../doc/controllers/primary-i-ps.md#delete-a-primary-ip)
* [Get a Primary IP](../../doc/controllers/primary-i-ps.md#get-a-primary-ip)
* [Update a Primary IP](../../doc/controllers/primary-i-ps.md#update-a-primary-ip)


# Get All Primary I Ps

Returns all Primary IP objects.

```go
GetAllPrimaryIPs(
    ctx context.Context,
    name *string,
    labelSelector *string,
    ip *string,
    sort *models.Sort2Enum) (
    models.ApiResponse[models.PrimaryIPsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `*string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `*string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `ip` | `*string` | Query, Optional | Can be used to filter resources by their ip. The response will only contain the resources matching the specified ip. |
| `sort` | [`*models.Sort2Enum`](../../doc/models/sort-2-enum.md) | Query, Optional | Can be used multiple times. Choices id id:asc id:desc created created:asc created:desc |

## Response Type

**200**: The `primary_ips` key contains an array of Primary IP objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PrimaryIPsResponse](../../doc/models/primary-i-ps-response.md).

## Example Usage

```go
ctx := context.Background()

ip := "127.0.0.1"

apiResponse, err := primaryIPsController.GetAllPrimaryIPs(ctx, nil, nil, &ip, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Create a Primary IP

Creates a new Primary IP, optionally assigned to a Server.

If you want to create a Primary IP that is not assigned to a Server, you need to provide the `datacenter` key instead of `assignee_id`. This can be either the ID or the name of the Datacenter this Primary IP shall be created in.

Note that a Primary IP can only be assigned to a Server in the same Datacenter later on.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_not_stopped`          | The specified server is running, but needs to be powered off  |
| `server_has_ipv4`             | The server already has an ipv4 address                        |
| `server_has_ipv6`             | The server already has an ipv6 address                        |

```go
CreateAPrimaryIP(
    ctx context.Context,
    body *models.CreatePrimaryIPRequest) (
    models.ApiResponse[models.CreatePrimaryIPResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`*models.CreatePrimaryIPRequest`](../../doc/models/create-primary-ip-request.md) | Body, Optional | The `type` argument is required while `datacenter` and `assignee_id` are mutually exclusive. |

## Response Type

**201**: The `primary_ip` key contains the Primary IP that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CreatePrimaryIPResponse](../../doc/models/create-primary-ip-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.CreatePrimaryIPRequest{
    AssigneeId:           models.ToPointer(17),
    AssigneeType:         "server",
    AutoDelete:           models.ToPointer(false),
    Datacenter:           models.ToPointer("fsn1-dc8"),
    Labels:               models.ToPointer(interface{}("[labelkey, value]")),
    Name:                 "my-ip",
    Type:                 models.Type51Enum_IPV4,
}

apiResponse, err := primaryIPsController.CreateAPrimaryIP(ctx, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_primary_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 17,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "primary_ip": {
    "assignee_id": 17,
    "assignee_type": "server",
    "auto_delete": true,
    "blocked": false,
    "created": "2016-01-30T23:50:00+00:00",
    "datacenter": {
      "description": "Falkenstein DC Park 8",
      "id": 42,
      "location": {
        "city": "Falkenstein",
        "country": "DE",
        "description": "Falkenstein DC Park 1",
        "id": 1,
        "latitude": 50.47612,
        "longitude": 12.370071,
        "name": "fsn1",
        "network_zone": "eu-central"
      },
      "name": "fsn1-dc8",
      "server_types": {
        "available": [
          1,
          2,
          3
        ],
        "available_for_migration": [
          1,
          2,
          3
        ],
        "supported": [
          1,
          2,
          3
        ]
      }
    },
    "dns_ptr": [
      {
        "dns_ptr": "server.example.com",
        "ip": "2001:db8::1"
      }
    ],
    "id": 42,
    "ip": "131.232.99.1",
    "labels": {
      "labelkey": "value"
    },
    "name": "my-ip",
    "protection": {
      "delete": false
    },
    "type": "ipv4"
  }
}
```


# Delete a Primary IP

Deletes a Primary IP.

The Primary IP may be assigned to a Server. In this case it is unassigned automatically. The Server must be powered off (status `off`) in order for this operation to succeed.

```go
DeleteAPrimaryIP(
    ctx context.Context,
    id int) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Primary IP deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

id := 112

resp, err := primaryIPsController.DeleteAPrimaryIP(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```


# Get a Primary IP

Returns a specific Primary IP object.

```go
GetAPrimaryIP(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.PrimaryIPResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `primary_ip` key contains a Primary IP object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PrimaryIPResponse](../../doc/models/primary-ip-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := primaryIPsController.GetAPrimaryIP(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Update a Primary IP

Updates the Primary IP.

Note that when updating labels, the Primary IP's current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

If the Primary IP object changes during the request, the response will be a “conflict” error.

```go
UpdateAPrimaryIP(
    ctx context.Context,
    id int,
    body *models.UpdatePrimaryIPRequest) (
    models.ApiResponse[models.PrimaryIPResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`*models.UpdatePrimaryIPRequest`](../../doc/models/update-primary-ip-request.md) | Body, Optional | - |

## Response Type

**200**: The `primary_ip` key contains the Primary IP that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PrimaryIPResponse](../../doc/models/primary-ip-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.UpdatePrimaryIPRequest{
    AutoDelete:           models.ToPointer(true),
    Labels:               models.ToPointer(interface{}("[labelkey, value]")),
    Name:                 models.ToPointer("my-ip"),
}

apiResponse, err := primaryIPsController.UpdateAPrimaryIP(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

