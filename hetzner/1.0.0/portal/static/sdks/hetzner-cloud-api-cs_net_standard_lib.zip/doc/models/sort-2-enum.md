
# Sort 2 Enum

## Enumeration

`Sort2Enum`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Sort2Enum sort2 = Sort2Enum.EnumCreatedasc;
```

