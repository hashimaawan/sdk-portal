
# Protection 20

Protection configuration for the Server

## Structure

`Protection20`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Delete` | `boolean` | Required | If true, prevents the Server from being deleted | boolean getDelete() | setDelete(boolean delete) |
| `Rebuild` | `boolean` | Required | If true, prevents the Server from being rebuilt | boolean getRebuild() | setRebuild(boolean rebuild) |

## Example

```java
import cloud.hetzner.api.models.Protection20;

Protection20 protection20 = new Protection20.Builder(
    false,
    false
)
.build();
```

