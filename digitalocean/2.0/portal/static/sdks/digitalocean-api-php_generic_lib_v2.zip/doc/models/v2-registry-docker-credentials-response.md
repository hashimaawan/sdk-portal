
# V2 Registry Docker Credentials Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2RegistryDockerCredentialsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `auths` | [`?Auths`](../../doc/models/auths.md) | Optional | - | getAuths(): ?Auths | setAuths(?Auths auths): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2RegistryDockerCredentialsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\AuthsBuilder;
use DigitalOceanApiLib\Models\Builders\RegistryDigitaloceanComBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2RegistryDockerCredentialsResponse = V2RegistryDockerCredentialsResponseBuilder::init()
    ->auths(
        AuthsBuilder::init()
            ->registryDigitaloceanCom(
                RegistryDigitaloceanComBuilder::init()
                    ->auth('auth0')
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

