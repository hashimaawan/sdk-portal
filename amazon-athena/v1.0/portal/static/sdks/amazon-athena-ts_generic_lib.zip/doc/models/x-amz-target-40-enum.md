
# X Amz Target 40 Enum

## Enumeration

`XAmzTarget40Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListPreparedStatements` |

## Example

```ts
import { XAmzTarget40Enum } from 'amazon-athenalib';

const xAmzTarget40 = XAmzTarget40Enum.EnumAmazonAthenaListPreparedStatements;
```

