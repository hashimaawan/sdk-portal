# Server Types

```python
server_types_api = client.server_types
```

## Class Name

`ServerTypesApi`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```python
def get_all_server_types(self,
                        name=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ServerTypesResponse`](../../doc/models/server-types-response.md).

## Example Usage

```python
result = server_types_api.get_all_server_types()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Get a Server Type

Gets a specific Server type object.

```python
def get_a_server_type(self,
                     id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Server Type |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ServerTypesResponse1`](../../doc/models/server-types-response-1.md).

## Example Usage

```python
id = 112

result = server_types_api.get_a_server_type(id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

