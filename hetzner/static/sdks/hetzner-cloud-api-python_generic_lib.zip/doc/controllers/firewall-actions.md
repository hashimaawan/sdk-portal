# Firewall Actions

```python
firewall_actions_controller = client.firewall_actions
```

## Class Name

`FirewallActionsController`

## Methods

* [Get All Actions for a Firewall](../../doc/controllers/firewall-actions.md#get-all-actions-for-a-firewall)
* [Apply to Resources](../../doc/controllers/firewall-actions.md#apply-to-resources)
* [Remove from Resources](../../doc/controllers/firewall-actions.md#remove-from-resources)
* [Set Rules](../../doc/controllers/firewall-actions.md#set-rules)
* [Get an Action for a Firewall](../../doc/controllers/firewall-actions.md#get-an-action-for-a-firewall)


# Get All Actions for a Firewall

Returns all Action objects for a Firewall. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```python
def get_all_actions_for_a_firewall(self,
                                  id,
                                  sort=None,
                                  status=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |
| `sort` | [`ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```python
id = 112

result = firewall_actions_controller.get_all_actions_for_a_firewall(id)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "set_firewall_rules",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Apply to Resources

Applies one Firewall to multiple resources.

Currently servers (public network interface) and label selectors are supported.

#### Call specific error codes

| Code                          | Description                                                   |
|-------------------------------|---------------------------------------------------------------|
| `firewall_already_applied`    | Firewall was already applied on resource                      |
| `incompatible_network_type`   | The Network type is incompatible for the given resource       |
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```python
def apply_to_resources(self,
                      id,
                      body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`ApplyToResourcesRequest`](../../doc/models/apply-to-resources-request.md) | Body, Optional | - |

## Response Type

**201**: The `actions` key contains multiple `apply_firewall` Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```python
id = 112

body = ApplyToResourcesRequest(
    apply_to=[
        FirewallApplyToResources(
            server=Server9(
                id=42
            ),
            mtype=Type7Enum.SERVER
        )
    ]
)

result = firewall_actions_controller.apply_to_resources(
    id,
    body=body
)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "apply_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Remove from Resources

Removes one Firewall from multiple resources.

Currently only Servers (and their public network interfaces) are supported.

#### Call specific error codes

| Code                                  | Description                                                            |
|---------------------------------------|------------------------------------------------------------------------|
| `firewall_already_removed`            | Firewall was already removed from the resource                         |
| `firewall_resource_not_found`         | The resource the Firewall should be attached to was not found          |
| `firewall_managed_by_label_selector`  | Firewall was applied via label selector and cannot be removed manually |

```python
def remove_from_resources(self,
                         id,
                         body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`RemoveFromResourcesRequest`](../../doc/models/remove-from-resources-request.md) | Body, Optional | - |

## Response Type

**201**: The `actions` key contains multiple `remove_firewall` Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```python
id = 112

body = RemoveFromResourcesRequest(
    remove_from=[
        FirewallRemoveFromResources(
            server=Server9(
                id=42
            ),
            mtype=Type7Enum.SERVER
        )
    ]
)

result = firewall_actions_controller.remove_from_resources(
    id,
    body=body
)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "remove_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Set Rules

Sets the rules of a Firewall.

All existing rules will be overwritten. Pass an empty `rules` array to remove all rules.
The maximum amount of rules that can be defined is 50.

#### Call specific error codes

| Code                          | Description                                                   |
|-------------------------------|---------------------------------------------------------------|
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```python
def set_rules(self,
             id,
             body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`SetRulesRequest`](../../doc/models/set-rules-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains one `set_firewall_rules` Action plus one `apply_firewall` Action per resource where the Firewall is active

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```python
id = 112

body = SetRulesRequest(
    rules=[
        Rule(
            direction=DirectionEnum.ENUM_IN,
            protocol=ProtocolEnum.TCP,
            description='Allow port 80',
            port='80',
            source_ips=[
                '28.239.13.1/32',
                '28.239.14.0/24',
                'ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128'
            ]
        )
    ]
)

result = firewall_actions_controller.set_rules(
    id,
    body=body
)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "set_firewall_rules",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    },
    {
      "command": "apply_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        },
        {
          "id": 42,
          "type": "server"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Get an Action for a Firewall

Returns a specific Action for a Firewall.

```python
def get_an_action_for_a_firewall(self,
                                id,
                                action_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `action_id` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Firewall Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```python
id = 112

action_id = 224

result = firewall_actions_controller.get_an_action_for_a_firewall(
    id,
    action_id
)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "set_firewall_rules",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 38,
        "type": "firewall"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

