
# X Amz Target 40 Enum

## Enumeration

`XAmzTarget40Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```ruby
x_amz_target40 = XAmzTarget40Enum::ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS
```

