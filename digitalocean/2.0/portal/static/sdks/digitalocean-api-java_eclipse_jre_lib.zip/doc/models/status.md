
# Status

This value is one of "active", "warning" or "locked".

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `WARNING` |
| `LOCKED` |

## Example

```java
import com.digitalocean.api.models.Status;

Status status = Status.LOCKED;
```

