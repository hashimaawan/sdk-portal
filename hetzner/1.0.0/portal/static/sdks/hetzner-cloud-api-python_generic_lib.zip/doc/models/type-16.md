
# Type 16

Type of the Floating IP

## Enumeration

`Type16`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_16 import Type16

type_16 = Type16.IPV4
```

