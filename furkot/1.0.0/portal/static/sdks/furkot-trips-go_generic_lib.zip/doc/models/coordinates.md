
# Coordinates

geographical coordinates of the stop

## Structure

`Coordinates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Lat` | `*float64` | Optional | latitude |
| `Lon` | `*float64` | Optional | longitude |

## Example

```go
package main

import (
    "furkottrips/models"
)

func main() {
    coordinates := models.Coordinates{
        Lat:                  models.ToPointer(float64(182.98)),
        Lon:                  models.ToPointer(float64(16.08)),
    }

}
```

