
# Change Protection Request

## Structure

`ChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Floating IP from being deleted |

## Example

```ruby
change_protection_request = ChangeProtectionRequest.new(
  true
)
```

