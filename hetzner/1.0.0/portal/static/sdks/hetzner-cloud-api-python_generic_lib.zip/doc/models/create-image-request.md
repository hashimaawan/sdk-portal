
# Create Image Request

*This model accepts additional fields of type Any.*

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Optional | Description of the Image, will be auto-generated if not set |
| `labels` | [`Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `mtype` | [`Type63`](../../doc/models/type-63.md) | Optional | Type of Image to create (default: `snapshot`) |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.create_image_request import CreateImageRequest
from hetznercloudapi.models.labels import Labels
from hetznercloudapi.models.type_63 import Type63

create_image_request = CreateImageRequest(
    description='my image',
    labels=Labels(
        labelkey='labelkey4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    mtype=Type63.SNAPSHOT,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

