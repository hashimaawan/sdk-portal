
# List Named Queries Input

## Structure

`ListNamedQueriesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 0`, `<= 50` |
| `work_group` | `String` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```ruby
list_named_queries_input = ListNamedQueriesInput.new(
  'NextToken0',
  50,
  'WorkGroup2'
)
```

