
# V2 Cdn Endpoints Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endpoints` | [`List[Endpoint]`](../../doc/models/endpoint.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.endpoint import Endpoint
from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.ttl import Ttl
from digitaloceanapi.models.v_2_cdn_endpoints_response import V2CdnEndpointsResponse

v_2_cdn_endpoints_response = V2CdnEndpointsResponse(
    meta=Meta(
        total=1,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    endpoints=[
        Endpoint(
            origin='static-images.nyc3.digitaloceanspaces.com',
            certificate_id='892071a0-bb95-49bc-8021-3afd67a210bf',
            created_at=dateutil.parser.parse('2018-07-19T15:04:16Z'),
            custom_domain='static.example.com',
            endpoint='static-images.nyc3.cdn.digitaloceanspaces.com',
            id='19f06b6a-3ace-4315-b086-499a0e521b76',
            ttl=Ttl.ENUM_3600,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    links=Links(
        pages=Pages(
            last='last6',
            next='next2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

