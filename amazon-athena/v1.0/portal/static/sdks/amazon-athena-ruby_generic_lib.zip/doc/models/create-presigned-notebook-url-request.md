
# Create Presigned Notebook Url Request

## Structure

`CreatePresignedNotebookUrlRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ruby
create_presigned_notebook_url_request = CreatePresignedNotebookUrlRequest.new(
  'SessionId4'
)
```

