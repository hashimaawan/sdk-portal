
# V2 Registry Validate Name Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2RegistryValidateNameRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | A globally unique name for the container registry. Must be lowercase and be composed only of numbers, letters and `-`, up to a limit of 63 characters.<br><br>**Constraints**: *Maximum Length*: `63`, *Pattern*: `^[a-z0-9-]{1,63}$` |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_registry_validate_name_request import V2RegistryValidateNameRequest

v_2_registry_validate_name_request = V2RegistryValidateNameRequest(
    name='example',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

