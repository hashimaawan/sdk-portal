
# Get Data Catalog Input

*This model accepts additional fields of type Object.*

## Structure

`GetDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_data_catalog_input = GetDataCatalogInput.new(
  name: 'Name2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

