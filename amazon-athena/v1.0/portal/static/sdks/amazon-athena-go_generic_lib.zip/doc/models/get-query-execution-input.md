
# Get Query Execution Input

## Structure

`GetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getQueryExecutionInput := models.GetQueryExecutionInput{
        QueryExecutionId:     "QueryExecutionId8",
    }

}
```

