
# Work Group State 1

The state of the workgroup.

## Enumeration

`WorkGroupState1`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```php
use AmazonAthenaLib\Models\WorkGroupState1;

$workGroupState1 = WorkGroupState1::ENABLED;
```

