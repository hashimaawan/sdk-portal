# Actions

Actions show the results and progress of asynchronous requests to the API.

```csharp
ActionsController actionsController = client.ActionsController;
```

## Class Name

`ActionsController`

## Methods

* [Get All Actions](../../doc/controllers/actions.md#get-all-actions)
* [Get an Action](../../doc/controllers/actions.md#get-an-action)


# Get All Actions

Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```csharp
GetAllActionsAsync(
    int? id = null,
    Models.ParameterSortEnum? sort = null,
    Models.ParameterStatusEnum? status = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int?` | Query, Optional | Can be used multiple times, the response will contain only Actions with specified IDs |
| `sort` | [`ParameterSortEnum?`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum?`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`Task<Models.ActionsResponse>`](../../doc/models/actions-response.md)

## Example Usage

```csharp
try
{
    ActionsResponse result = await actionsController.GetAllActionsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get an Action

Returns a specific Action object.

```csharp
GetAnActionAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |

## Response Type

**200**: The `action` key in the reply has this structure

[`Task<Models.ActionResponse>`](../../doc/models/action-response.md)

## Example Usage

```csharp
int id = 112;
try
{
    ActionResponse result = await actionsController.GetAnActionAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

