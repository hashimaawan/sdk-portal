
# Result Reuse by Age Configuration 2

## Structure

`ResultReuseByAgeConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enabled` | `boolean` | Required | - |
| `maxAgeInMinutes` | `number \| undefined` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```ts
import { ResultReuseByAgeConfiguration2 } from 'amazon-athenalib';

const resultReuseByAgeConfiguration2: ResultReuseByAgeConfiguration2 = {
  enabled: false,
  maxAgeInMinutes: 44,
};
```

