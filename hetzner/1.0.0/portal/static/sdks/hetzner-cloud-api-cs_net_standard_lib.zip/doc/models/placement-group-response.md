
# Placement Group Response

## Structure

`PlacementGroupResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PlacementGroup` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

PlacementGroupResponse placementGroupResponse = new PlacementGroupResponse
{
    PlacementGroup = new PlacementGroup
    {
        Created = "2016-01-30T23:55:00+00:00",
        Id = 42,
        Labels = new Dictionary<string, string>
        {
            ["key0"] = "labels4",
        },
        Name = "my-resource",
        Servers = new List<int>
        {
            42,
        },
        Type = "spread",
    },
};
```

