
# Type 7

Type of the resource

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type7 := models.Type7_Server

}
```

