
# Algorithm

Algorithm of the Load Balancer

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```ruby
algorithm = Algorithm.new(
  Type28Enum::ROUND_ROBIN
)
```

