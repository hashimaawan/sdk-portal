
# Type 21

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```java
import cloud.hetzner.api.models.Type21;

Type21 type21 = Type21.BACKUP;
```

