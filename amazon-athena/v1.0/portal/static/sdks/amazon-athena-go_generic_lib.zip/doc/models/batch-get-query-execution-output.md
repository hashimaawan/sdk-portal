
# Batch Get Query Execution Output

## Structure

`BatchGetQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutions` | [`[]models.QueryExecution`](../../doc/models/query-execution.md) | Optional | - |
| `UnprocessedQueryExecutionIds` | [`[]models.UnprocessedQueryExecutionId`](../../doc/models/unprocessed-query-execution-id.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    batchGetQueryExecutionOutput := models.BatchGetQueryExecutionOutput{
        QueryExecutions:              []models.QueryExecution{
            models.QueryExecution{
                QueryExecutionId:         models.ToPointer("QueryExecutionId6"),
                Query:                    models.ToPointer("Query0"),
                StatementType:            models.ToPointer(models.StatementType1Enum_UTILITY),
                ResultConfiguration:      models.ToPointer(models.ResultConfiguration1{
                    OutputLocation:          models.ToPointer("OutputLocation0"),
                    EncryptionConfiguration: models.ToPointer(models.EncryptionConfiguration2{
                        EncryptionOption:     models.EncryptionOption1Enum_SSES3,
                        KmsKey:               models.ToPointer("KmsKey6"),
                    }),
                    ExpectedBucketOwner:     models.ToPointer("ExpectedBucketOwner0"),
                    AclConfiguration:        models.ToPointer(models.AclConfiguration1{
                        S3AclOption:          models.S3AclOption1Enum_BUCKETOWNERFULLCONTROL,
                    }),
                }),
                ResultReuseConfiguration: models.ToPointer(models.ResultReuseConfiguration1{
                    ResultReuseByAgeConfiguration: models.ToPointer(models.ResultReuseByAgeConfiguration2{
                        Enabled:              false,
                        MaxAgeInMinutes:      models.ToPointer(26),
                    }),
                }),
            },
            models.QueryExecution{
                QueryExecutionId:         models.ToPointer("QueryExecutionId6"),
                Query:                    models.ToPointer("Query0"),
                StatementType:            models.ToPointer(models.StatementType1Enum_UTILITY),
                ResultConfiguration:      models.ToPointer(models.ResultConfiguration1{
                    OutputLocation:          models.ToPointer("OutputLocation0"),
                    EncryptionConfiguration: models.ToPointer(models.EncryptionConfiguration2{
                        EncryptionOption:     models.EncryptionOption1Enum_SSES3,
                        KmsKey:               models.ToPointer("KmsKey6"),
                    }),
                    ExpectedBucketOwner:     models.ToPointer("ExpectedBucketOwner0"),
                    AclConfiguration:        models.ToPointer(models.AclConfiguration1{
                        S3AclOption:          models.S3AclOption1Enum_BUCKETOWNERFULLCONTROL,
                    }),
                }),
                ResultReuseConfiguration: models.ToPointer(models.ResultReuseConfiguration1{
                    ResultReuseByAgeConfiguration: models.ToPointer(models.ResultReuseByAgeConfiguration2{
                        Enabled:              false,
                        MaxAgeInMinutes:      models.ToPointer(26),
                    }),
                }),
            },
        },
        UnprocessedQueryExecutionIds: []models.UnprocessedQueryExecutionId{
            models.UnprocessedQueryExecutionId{
                QueryExecutionId:     models.ToPointer("QueryExecutionId6"),
                ErrorCode:            models.ToPointer("ErrorCode2"),
                ErrorMessage:         models.ToPointer("ErrorMessage8"),
            },
            models.UnprocessedQueryExecutionId{
                QueryExecutionId:     models.ToPointer("QueryExecutionId6"),
                ErrorCode:            models.ToPointer("ErrorCode2"),
                ErrorMessage:         models.ToPointer("ErrorMessage8"),
            },
            models.UnprocessedQueryExecutionId{
                QueryExecutionId:     models.ToPointer("QueryExecutionId6"),
                ErrorCode:            models.ToPointer("ErrorCode2"),
                ErrorMessage:         models.ToPointer("ErrorMessage8"),
            },
        },
    }

}
```

