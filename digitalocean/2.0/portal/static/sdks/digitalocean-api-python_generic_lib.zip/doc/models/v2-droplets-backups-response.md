
# V2 Droplets Backups Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DropletsBackupsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `backups` | [`List[Backup1]`](../../doc/models/backup-1.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.backup_1 import Backup1
from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.type_13 import Type13
from digitaloceanapi.models.v_2_droplets_backups_response import V2DropletsBackupsResponse

v_2_droplets_backups_response = V2DropletsBackupsResponse(
    meta=Meta(
        total=1,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    backups=[
        Backup1(
            id=196,
            created_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            min_disk_size=242,
            name='name4',
            regions=[
                'regions9',
                'regions0',
                'regions1'
            ],
            size_gigabytes=180.5,
            mtype=Type13.SNAPSHOT,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    links=Links(
        pages=Pages(
            last='last6',
            next='next2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

