
# X Amz Target 17

## Enumeration

`XAmzTarget17`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetcalculationexecutionstatus` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget17 := models.XAmzTarget17_EnumAmazonathenagetcalculationexecutionstatus

}
```

