
# Category

## Enumeration

`Category`

## Fields

| Name |
|  --- |
| `Login` |
| `Password` |
| `ApiCredential` |
| `Server` |
| `Database` |
| `CreditCard` |
| `Membership` |
| `Passport` |
| `SoftwareLicense` |
| `OutdoorLicense` |
| `SecureNote` |
| `WirelessRouter` |
| `BankAccount` |
| `DriverLicense` |
| `Identity` |
| `RewardProgram` |
| `Document` |
| `EmailAccount` |
| `SocialSecurityNumber` |
| `MedicalRecord` |
| `SshKey` |
| `Custom` |

## Example

```ts
import { Category } from 'm-1-password-connectlib';

const category = Category.SocialSecurityNumber;
```

