
# State

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `ARCHIVED` |
| `DELETED` |

## Example

```java
import local.m1password.models.State;

State state = State.ARCHIVED;
```

