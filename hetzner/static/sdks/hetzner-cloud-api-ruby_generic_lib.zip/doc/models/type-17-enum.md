
# Type 17 Enum

Floating IP type

## Enumeration

`Type17Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```ruby
type17 = Type17Enum::IPV4
```

