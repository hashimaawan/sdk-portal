
# Export Notebook Input

## Structure

`ExportNotebookInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NotebookId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` | String getNotebookId() | setNotebookId(String notebookId) |

## Example

```java
import com.amazonaws.useast1.athena.models.ExportNotebookInput;

ExportNotebookInput exportNotebookInput = new ExportNotebookInput.Builder(
    "NotebookId2"
)
.build();
```

