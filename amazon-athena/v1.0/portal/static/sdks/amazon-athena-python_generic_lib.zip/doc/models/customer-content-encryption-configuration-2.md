
# Customer Content Encryption Configuration 2

## Structure

`CustomerContentEncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kms_key` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:kms:([a-z0-9\-]+):\d{12}:key/?[a-zA-Z_0-9+=,.@\-_/]+$\|^arn:aws[a-z\-]*:kms:([a-z0-9\-]+):\d{12}:alias/?[a-zA-Z_0-9+=,.@\-_/]+$\|^alias/[a-zA-Z0-9/_-]+$\|[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```python
from amazonathena.models.customer_content_encryption_configuration_2 import CustomerContentEncryptionConfiguration2

customer_content_encryption_configuration_2 = CustomerContentEncryptionConfiguration2(
    kms_key='KmsKey6'
)
```

