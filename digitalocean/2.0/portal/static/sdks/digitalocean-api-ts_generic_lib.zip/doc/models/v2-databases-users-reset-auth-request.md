
# V2 Databases Users Reset Auth Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResetAuthRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mysqlSettings` | [`MysqlSettings \| undefined`](../../doc/models/mysql-settings.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  AuthPlugin,
  V2DatabasesUsersResetAuthRequest,
} from 'digitalocean-apilib';

const v2DatabasesUsersResetAuthRequest: V2DatabasesUsersResetAuthRequest = {
  mysqlSettings: {
    authPlugin: AuthPlugin.MysqlNativePassword,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

