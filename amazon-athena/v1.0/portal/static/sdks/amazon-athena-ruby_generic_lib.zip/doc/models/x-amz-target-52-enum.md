
# X Amz Target 52 Enum

## Enumeration

`XAmzTarget52Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATERMINATESESSION` |

## Example

```ruby
x_amz_target52 = XAmzTarget52Enum::ENUM_AMAZONATHENATERMINATESESSION
```

