
# X Amz Target 59 Enum

## Enumeration

`XAmzTarget59Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateWorkGroup` |

## Example

```ts
import { XAmzTarget59Enum } from 'amazon-athenalib';

const xAmzTarget59 = XAmzTarget59Enum.EnumAmazonAthenaUpdateWorkGroup;
```

