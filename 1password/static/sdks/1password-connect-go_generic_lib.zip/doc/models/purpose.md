
# Purpose

Some item types, Login and Password, have fields used for autofill. This property indicates that purpose and is required for some item types.

## Enumeration

`Purpose`

## Fields

| Name |
|  --- |
| `Username` |
| `Password` |
| `Notes` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    purpose := models.Purpose_Password

}
```

