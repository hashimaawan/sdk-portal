
# Service Dependency

The state of a registered server dependency.

*This model accepts additional fields of type Object.*

## Structure

`ServiceDependency`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | Human-readable message for explaining the current state. |
| `service` | `String` | Optional | - |
| `status` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
service_dependency = ServiceDependency.new(
  message: 'message0',
  service: 'service0',
  status: 'status2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

