
# X Amz Target 37 Enum

## Enumeration

`XAmzTarget37Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNAMEDQUERIES` |

## Example

```python
from amazonathena.models.x_amz_target_37_enum import XAmzTarget37Enum

x_amz_target_37 = XAmzTarget37Enum.ENUM_AMAZONATHENALISTNAMEDQUERIES
```

