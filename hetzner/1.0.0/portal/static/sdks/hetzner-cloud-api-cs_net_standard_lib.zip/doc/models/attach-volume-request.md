
# Attach Volume Request

## Structure

`AttachVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Automount` | `bool?` | Optional | Auto-mount the Volume after attaching it |
| `Server` | `int` | Required | ID of the Server the Volume will be attached to |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

AttachVolumeRequest attachVolumeRequest = new AttachVolumeRequest
{
    Server = 43,
    Automount = false,
};
```

