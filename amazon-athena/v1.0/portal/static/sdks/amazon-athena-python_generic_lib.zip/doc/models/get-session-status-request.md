
# Get Session Status Request

## Structure

`GetSessionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```python
from amazonathena.models.get_session_status_request import GetSessionStatusRequest

get_session_status_request = GetSessionStatusRequest(
    session_id='SessionId4'
)
```

