
# X Amz Target 9

## Enumeration

`XAmzTarget9`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEDATACATALOG` |

## Example

```ruby
x_amz_target9 = XAmzTarget9::ENUM_AMAZONATHENADELETEDATACATALOG
```

