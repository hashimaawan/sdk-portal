
# Parameter Type Enum

## Enumeration

`ParameterTypeEnum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```java
import cloud.hetzner.api.models.ParameterTypeEnum;

ParameterTypeEnum parameterType = ParameterTypeEnum.UPLOADED;
```

