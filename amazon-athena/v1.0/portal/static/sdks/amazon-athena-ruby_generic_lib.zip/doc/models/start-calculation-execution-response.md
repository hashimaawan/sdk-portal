
# Start Calculation Execution Response

*This model accepts additional fields of type Object.*

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `state` | [`CalculationExecutionState4`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
start_calculation_execution_response = StartCalculationExecutionResponse.new(
  calculation_execution_id: 'CalculationExecutionId0',
  state: CalculationExecutionState4::CANCELING,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

