
# Type 24 Enum

Destination Image type to convert to

## Enumeration

`Type24Enum`

## Fields

| Name |
|  --- |
| `Snapshot` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type24Enum type24 = Type24Enum.Snapshot;
```

