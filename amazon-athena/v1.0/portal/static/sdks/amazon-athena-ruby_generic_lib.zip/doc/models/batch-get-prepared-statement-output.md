
# Batch Get Prepared Statement Output

*This model accepts additional fields of type Object.*

## Structure

`BatchGetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prepared_statements` | [`Array[PreparedStatement]`](../../doc/models/prepared-statement.md) | Optional | - |
| `unprocessed_prepared_statement_names` | [`Array[UnprocessedPreparedStatementName]`](../../doc/models/unprocessed-prepared-statement-name.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
batch_get_prepared_statement_output = BatchGetPreparedStatementOutput.new(
  prepared_statements: [
    PreparedStatement.new(
      statement_name: 'StatementName2',
      query_statement: 'QueryStatement6',
      work_group_name: 'WorkGroupName6',
      description: 'Description2',
      last_modified_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    PreparedStatement.new(
      statement_name: 'StatementName2',
      query_statement: 'QueryStatement6',
      work_group_name: 'WorkGroupName6',
      description: 'Description2',
      last_modified_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    PreparedStatement.new(
      statement_name: 'StatementName2',
      query_statement: 'QueryStatement6',
      work_group_name: 'WorkGroupName6',
      description: 'Description2',
      last_modified_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  unprocessed_prepared_statement_names: [
    UnprocessedPreparedStatementName.new(
      statement_name: 'StatementName0',
      error_code: 'ErrorCode2',
      error_message: 'ErrorMessage8',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

