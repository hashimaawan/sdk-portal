
# List Data Catalogs Output

## Structure

`ListDataCatalogsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DataCatalogsSummary` | [`[]models.DataCatalogSummary`](../../doc/models/data-catalog-summary.md) | Optional | - |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listDataCatalogsOutput := models.ListDataCatalogsOutput{
        DataCatalogsSummary:  []models.DataCatalogSummary{
            models.DataCatalogSummary{
                CatalogName:          models.ToPointer("CatalogName4"),
                Type:                 models.ToPointer(models.DataCatalogType2Enum_HIVE),
            },
            models.DataCatalogSummary{
                CatalogName:          models.ToPointer("CatalogName4"),
                Type:                 models.ToPointer(models.DataCatalogType2Enum_HIVE),
            },
            models.DataCatalogSummary{
                CatalogName:          models.ToPointer("CatalogName4"),
                Type:                 models.ToPointer(models.DataCatalogType2Enum_HIVE),
            },
        },
        NextToken:            models.ToPointer("NextToken0"),
    }

}
```

