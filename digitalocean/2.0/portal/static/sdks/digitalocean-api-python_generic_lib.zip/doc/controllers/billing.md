# Billing

The billing endpoints allow you to retrieve your account balance, invoices
and billing history.

**Balance:** By sending requests to the `/v2/customers/my/balance` endpoint, you can
retrieve the balance information for the requested customer account.

**Invoices:** [Invoices](https://www.digitalocean.com/docs/accounts/billing/invoices/)
are generated on the first of each month for every DigitalOcean
customer. An invoice preview is generated daily, which can be accessed
with the `preview` keyword in place of `$INVOICE_UUID`. To interact with
invoices, you will generally send requests to the invoices endpoint at
`/v2/customers/my/invoices`.

**Billing History:** Billing history is a record of billing events for your account.
For example, entries may include events like payments made, invoices
issued, or credits granted. To interact with invoices, you
will generally send requests to the invoices endpoint at
`/v2/customers/my/billing_history`.

```python
billing_api = client.billing
```

## Class Name

`BillingApi`

## Methods

* [Balance Get](../../doc/controllers/billing.md#balance-get)
* [Billing History List](../../doc/controllers/billing.md#billing-history-list)
* [Invoices List](../../doc/controllers/billing.md#invoices-list)
* [Invoices Get by UUID](../../doc/controllers/billing.md#invoices-get-by-uuid)
* [Invoices Get Csv by UUID](../../doc/controllers/billing.md#invoices-get-csv-by-uuid)
* [Invoices Get Pdf by UUID](../../doc/controllers/billing.md#invoices-get-pdf-by-uuid)
* [Invoices Get Summary by UUID](../../doc/controllers/billing.md#invoices-get-summary-by-uuid)


# Balance Get

To retrieve the balances on a customer's account, send a GET request to `/v2/customers/my/balance`.

```python
def balance_get(self)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: The response will be a JSON object that contains the following attributes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2CustomersMyBalanceResponse`](../../doc/models/v2-customers-my-balance-response.md).

## Example Usage

```python
result = billing_api.balance_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Example Response *(as JSON)*

```json
{
  "account_balance": "12.23",
  "generated_at": "2019-07-09T15:01:12Z",
  "month_to_date_balance": "23.44",
  "month_to_date_usage": "11.21"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Billing History List

To retrieve a list of all billing history entries, send a GET request to `/v2/customers/my/billing_history`.

```python
def billing_history_list(self)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: The response will be a JSON object that contains the following attributes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2CustomersMyBillingHistoryResponse`](../../doc/models/v2-customers-my-billing-history-response.md).

## Example Usage

```python
result = billing_api.billing_history_list()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Invoices List

To retrieve a list of all invoices, send a GET request to `/v2/customers/my/invoices`.

```python
def invoices_list(self,
                 per_page=20,
                 page=1)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_page` | `int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object contains that contains a list of invoices under the `invoices` key, and the invoice preview under the `invoice_preview` key.
Each element contains the invoice summary attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2CustomersMyInvoicesResponse`](../../doc/models/v2-customers-my-invoices-response.md).

## Example Usage

```python
per_page = 2

page = 1

result = billing_api.invoices_list(
    per_page=per_page,
    page=page
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Invoices Get by UUID

To retrieve the invoice items for an invoice, send a GET request to `/v2/customers/my/invoices/$INVOICE_UUID`.

```python
def invoices_get_by_uuid(self,
                        invoice_uuid)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `invoice_uuid` | `str` | Template, Required | UUID of the invoice |

## Response Type

**200**: The response will be a JSON object with a key called `invoice_items`. This will be set to an array of invoice item objects.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2CustomersMyInvoicesResponse1`](../../doc/models/v2-customers-my-invoices-response-1.md).

## Example Usage

```python
invoice_uuid = '22737513-0ea7-4206-8ceb-98a575af7681'

result = billing_api.invoices_get_by_uuid(invoice_uuid)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Invoices Get Csv by UUID

To retrieve a CSV for an invoice, send a GET request to `/v2/customers/my/invoices/$INVOICE_UUID/csv`.

```python
def invoices_get_csv_by_uuid(self,
                            invoice_uuid)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `invoice_uuid` | `str` | Template, Required | UUID of the invoice |

## Response Type

**200**: The response will be a CSV file.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `str`.

## Example Usage

```python
invoice_uuid = '22737513-0ea7-4206-8ceb-98a575af7681'

result = billing_api.invoices_get_csv_by_uuid(invoice_uuid)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Example Response

```
"product,group_description,description,hours,start,end,USD,project_name,category\nFloating IPs,,Unused Floating IP - 1.1.1.1,100,2020-07-01 00:00:00 +0000,2020-07-22 18:14:39 +0000,$3.11,,iaas\nTaxes,,STATE SALES TAX (6.25%),,2020-07-01 00:00:00 +0000,2020-07-31 23:59:59 +0000,$0.16,,iaas\n"
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Invoices Get Pdf by UUID

To retrieve a PDF for an invoice, send a GET request to `/v2/customers/my/invoices/$INVOICE_UUID/pdf`.

```python
def invoices_get_pdf_by_uuid(self,
                            invoice_uuid)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `invoice_uuid` | `str` | Template, Required | UUID of the invoice |

## Response Type

**200**: The response will be a PDF file.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
invoice_uuid = '22737513-0ea7-4206-8ceb-98a575af7681'

result = billing_api.invoices_get_pdf_by_uuid(invoice_uuid)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Invoices Get Summary by UUID

To retrieve a summary for an invoice, send a GET request to `/v2/customers/my/invoices/$INVOICE_UUID/summary`.

```python
def invoices_get_summary_by_uuid(self,
                                invoice_uuid)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `invoice_uuid` | `str` | Template, Required | UUID of the invoice |

## Response Type

**200**: To retrieve a summary for an invoice, send a GET request to  `/v2/customers/my/invoices/$INVOICE_UUID/summary`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2CustomersMyInvoicesSummaryResponse`](../../doc/models/v2-customers-my-invoices-summary-response.md).

## Example Usage

```python
invoice_uuid = '22737513-0ea7-4206-8ceb-98a575af7681'

result = billing_api.invoices_get_summary_by_uuid(invoice_uuid)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Example Response *(as JSON)*

```json
{
  "amount": "27.13",
  "billing_period": "2020-01",
  "credits_and_adjustments": {
    "amount": "6.78",
    "name": "Credits & adjustments"
  },
  "invoice_uuid": "22737513-0ea7-4206-8ceb-98a575af7681",
  "overages": {
    "amount": "3.45",
    "name": "Overages"
  },
  "product_charges": {
    "amount": "12.34",
    "items": [
      {
        "amount": "10.00",
        "count": "1",
        "name": "Spaces Subscription"
      },
      {
        "amount": "2.34",
        "count": "1",
        "name": "Database Clusters"
      }
    ],
    "name": "Product usage charges"
  },
  "taxes": {
    "amount": "4.56",
    "name": "Taxes"
  },
  "user_billing_address": {
    "address_line1": "101 Shark Row",
    "city": "Atlantis",
    "country_iso2_code": "US",
    "created_at": "2019-09-03T16:34:46.000+00:00",
    "postal_code": "12345",
    "region": "OC",
    "updated_at": "2019-09-03T16:34:46.000+00:00"
  },
  "user_company": "DigitalOcean",
  "user_email": "sammy@digitalocean.com",
  "user_name": "Sammy Shark"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

