
# Status 70 Enum

## Enumeration

`Status70Enum`

## Fields

| Name |
|  --- |
| `INITIALIZING` |
| `STARTING` |
| `RUNNING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `REBUILDING` |
| `MIGRATING` |
| `UNKNOWN` |

## Example

```python
from hetznercloudapi.models.status_70_enum import Status70Enum

status_70 = Status70Enum.DELETING
```

