
# X Amz Target 36

## Enumeration

`XAmzTarget36`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListExecutors` |

## Example

```ts
import { XAmzTarget36 } from 'amazon-athenalib';

const xAmzTarget36 = XAmzTarget36.EnumAmazonAthenaListExecutors;
```

