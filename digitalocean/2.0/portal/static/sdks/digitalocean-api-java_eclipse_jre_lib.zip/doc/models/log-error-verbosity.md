
# Log Error Verbosity

Controls the amount of detail written in the server log for each message that is logged.

## Enumeration

`LogErrorVerbosity`

## Fields

| Name |
|  --- |
| `TERSE` |
| `DEFAULT` |
| `VERBOSE` |

## Example

```java
import com.digitalocean.api.models.LogErrorVerbosity;

LogErrorVerbosity logErrorVerbosity = LogErrorVerbosity.DEFAULT;
```

