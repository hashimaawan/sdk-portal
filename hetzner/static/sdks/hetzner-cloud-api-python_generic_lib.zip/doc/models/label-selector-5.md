
# Label Selector 5

Configuration for type label_selector, required if type is `label_selector`

## Structure

`LabelSelector5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `str` | Required | Label selector |

## Example

```python
from hetznercloudapi.models.label_selector_5 import LabelSelector5

label_selector_5 = LabelSelector5(
    selector='env=prod'
)
```

