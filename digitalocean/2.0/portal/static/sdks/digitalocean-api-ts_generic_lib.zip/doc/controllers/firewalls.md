# Firewalls

[DigitalOcean Cloud Firewalls](https://www.digitalocean.com/docs/networking/firewalls/)
provide the ability to restrict network access to and from a Droplet
allowing you to define which ports will accept inbound or outbound
connections. By sending requests to the `/v2/firewalls` endpoint, you can
list, create, or delete firewalls as well as modify access rules.

```ts
const firewallsApi = new FirewallsApi(client);
```

## Class Name

`FirewallsApi`

## Methods

* [Firewalls List](../../doc/controllers/firewalls.md#firewalls-list)
* [Firewalls Create](../../doc/controllers/firewalls.md#firewalls-create)
* [Firewalls Delete](../../doc/controllers/firewalls.md#firewalls-delete)
* [Firewalls Get](../../doc/controllers/firewalls.md#firewalls-get)
* [Firewalls Update](../../doc/controllers/firewalls.md#firewalls-update)
* [Firewalls Delete Droplets](../../doc/controllers/firewalls.md#firewalls-delete-droplets)
* [Firewalls Assign Droplets](../../doc/controllers/firewalls.md#firewalls-assign-droplets)
* [Firewalls Delete Rules](../../doc/controllers/firewalls.md#firewalls-delete-rules)
* [Firewalls Add Rules](../../doc/controllers/firewalls.md#firewalls-add-rules)
* [Firewalls Delete Tags](../../doc/controllers/firewalls.md#firewalls-delete-tags)
* [Firewalls Add Tags](../../doc/controllers/firewalls.md#firewalls-add-tags)


# Firewalls List

To list all of the firewalls available on your account, send a GET request to `/v2/firewalls`.

```ts
async firewallsList(
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2FirewallsResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: To list all of the firewalls available on your account, send a GET request to `/v2/firewalls`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2FirewallsResponse`](../../doc/models/v2-firewalls-response.md).

## Example Usage

```ts
const perPage = 2;

const page = 1;

try {
  const response = await firewallsApi.firewallsList(
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "firewalls": [
    {
      "created_at": "2017-05-23T21:23:59Z",
      "droplet_ids": [
        8043964
      ],
      "id": "fb6045f1-cf1d-4ca3-bfac-18832663025b",
      "inbound_rules": [
        {
          "ports": "80",
          "protocol": "tcp",
          "sources": {
            "load_balancer_uids": [
              "4de7ac8b-495b-4884-9a69-1050c6793cd6"
            ]
          }
        },
        {
          "ports": "22",
          "protocol": "tcp",
          "sources": {
            "addresses": [
              "18.0.0.0/8"
            ],
            "tags": [
              "gateway"
            ]
          }
        }
      ],
      "name": "firewall",
      "outbound_rules": [
        {
          "destinations": {
            "addresses": [
              "0.0.0.0/0",
              "::/0"
            ]
          },
          "ports": "80",
          "protocol": "tcp"
        }
      ],
      "pending_changes": [],
      "status": "succeeded",
      "tags": []
    }
  ],
  "links": {},
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Create

To create a new firewall, send a POST request to `/v2/firewalls`. The request
must contain at least one inbound or outbound access rule.

```ts
async firewallsCreate(
  body?: V2FirewallsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2FirewallsResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2FirewallsRequest \| undefined`](../../doc/models/v2-firewalls-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**202**: The response will be a JSON object with a firewall key. This will be set to an object containing the standard firewall attributes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```ts
const body: V2FirewallsRequest = {
  name: 'firewall',
  inboundRules: [
    {
      ports: '80',
      protocol: Protocol.Tcp,
      sources: {
        loadBalancerUids: [
          '4de7ac8b-495b-4884-9a69-1050c6793cd6'
        ],
      },
    },
    {
      ports: '22',
      protocol: Protocol.Tcp,
      sources: {
        addresses: [
          '18.0.0.0/8'
        ],
        tags: [
          'gateway'
        ],
      },
    }
  ],
  outboundRules: [
    {
      ports: '80',
      protocol: Protocol.Tcp,
      destinations: {
        addresses: [
          '0.0.0.0/0',
          '::/0'
        ],
      },
    }
  ],
  dropletIds: [
    8043964
  ],
};

try {
  const response = await firewallsApi.firewallsCreate(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2017-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [
      {
        "droplet_id": 8043964,
        "removing": false,
        "status": "waiting"
      }
    ],
    "status": "waiting",
    "tags": []
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Delete

To delete a firewall send a DELETE request to `/v2/firewalls/$FIREWALL_ID`.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```ts
async firewallsDelete(
  firewallId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

try {
  const response = await firewallsApi.firewallsDelete(firewallId);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Get

To show information about an existing firewall, send a GET request to `/v2/firewalls/$FIREWALL_ID`.

```ts
async firewallsGet(
  firewallId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2FirewallsResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a firewall key. This will be set to an object containing the standard firewall attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

try {
  const response = await firewallsApi.firewallsGet(firewallId);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2017-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [],
    "status": "succeeded",
    "tags": []
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Update

To update the configuration of an existing firewall, send a PUT request to
`/v2/firewalls/$FIREWALL_ID`. The request should contain a full representation
of the firewall including existing attributes. **Note that any attributes that
are not provided will be reset to their default values.**

```ts
async firewallsUpdate(
  firewallId: string,
  body?: V2FirewallsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2FirewallsResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsRequest \| undefined`](../../doc/models/v2-firewalls-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a `firewall` key. This will be set to an object containing the standard firewall attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

const body: V2FirewallsRequest = {
  name: 'frontend-firewall',
  inboundRules: [
    {
      ports: '8080',
      protocol: Protocol.Tcp,
      sources: {
        loadBalancerUids: [
          '4de7ac8b-495b-4884-9a69-1050c6793cd6'
        ],
      },
    },
    {
      ports: '22',
      protocol: Protocol.Tcp,
      sources: {
        addresses: [
          '18.0.0.0/8'
        ],
        tags: [
          'gateway'
        ],
      },
    }
  ],
  outboundRules: [
    {
      ports: '8080',
      protocol: Protocol.Tcp,
      destinations: {
        addresses: [
          '0.0.0.0/0',
          '::/0'
        ],
      },
    }
  ],
  dropletIds: [
    8043964
  ],
  tags: [
    'frontend'
  ],
};

try {
  const response = await firewallsApi.firewallsUpdate(
    firewallId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2020-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "frontend-firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [
      {
        "droplet_id": 8043964,
        "removing": false,
        "status": "waiting"
      }
    ],
    "status": "waiting",
    "tags": [
      "frontend"
    ]
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Delete Droplets

To remove a Droplet from a firewall, send a DELETE request to
`/v2/firewalls/$FIREWALL_ID/droplets`. In the body of the request, there should
be a `droplet_ids` attribute containing a list of Droplet IDs.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```ts
async firewallsDeleteDroplets(
  firewallId: string,
  body?: V2FirewallsDropletsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsDropletsRequest \| undefined`](../../doc/models/v2-firewalls-droplets-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

const body: V2FirewallsDropletsRequest = {
  dropletIds: [
    49696269
  ],
};

try {
  const response = await firewallsApi.firewallsDeleteDroplets(
    firewallId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Assign Droplets

To assign a Droplet to a firewall, send a POST request to
`/v2/firewalls/$FIREWALL_ID/droplets`. In the body of the request, there
should be a `droplet_ids` attribute containing a list of Droplet IDs.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```ts
async firewallsAssignDroplets(
  firewallId: string,
  body?: V2FirewallsDropletsRequest1,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsDropletsRequest1 \| undefined`](../../doc/models/v2-firewalls-droplets-request-1.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

const body: V2FirewallsDropletsRequest1 = {
  dropletIds: [
    49696269
  ],
};

try {
  const response = await firewallsApi.firewallsAssignDroplets(
    firewallId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Delete Rules

To remove access rules from a firewall, send a DELETE request to
`/v2/firewalls/$FIREWALL_ID/rules`. The body of the request may include an
`inbound_rules` and/or `outbound_rules` attribute containing an array of rules
to be removed.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```ts
async firewallsDeleteRules(
  firewallId: string,
  body?: V2FirewallsRulesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsRulesRequest \| undefined`](../../doc/models/v2-firewalls-rules-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

const body: V2FirewallsRulesRequest = {
  inboundRules: [
    {
      ports: '3306',
      protocol: Protocol.Tcp,
      sources: {
        dropletIds: [
          49696269
        ],
      },
    }
  ],
  outboundRules: [
    {
      ports: '3306',
      protocol: Protocol.Tcp,
      destinations: {
        dropletIds: [
          49696269
        ],
      },
    }
  ],
};

try {
  const response = await firewallsApi.firewallsDeleteRules(
    firewallId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Add Rules

To add additional access rules to a firewall, send a POST request to
`/v2/firewalls/$FIREWALL_ID/rules`. The body of the request may include an
inbound_rules and/or outbound_rules attribute containing an array of rules to
be added.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```ts
async firewallsAddRules(
  firewallId: string,
  body?: V2FirewallsRulesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsRulesRequest \| undefined`](../../doc/models/v2-firewalls-rules-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

const body: V2FirewallsRulesRequest = {
  inboundRules: [
    {
      ports: '3306',
      protocol: Protocol.Tcp,
      sources: {
        dropletIds: [
          49696269
        ],
      },
    }
  ],
  outboundRules: [
    {
      ports: '3306',
      protocol: Protocol.Tcp,
      destinations: {
        dropletIds: [
          49696269
        ],
      },
    }
  ],
};

try {
  const response = await firewallsApi.firewallsAddRules(
    firewallId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Delete Tags

To remove a tag representing a group of Droplets from a firewall, send a
DELETE request to `/v2/firewalls/$FIREWALL_ID/tags`. In the body of the
request, there should be a `tags` attribute containing a list of tag names.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```ts
async firewallsDeleteTags(
  firewallId: string,
  body?: V2FirewallsTagsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsTagsRequest \| undefined`](../../doc/models/v2-firewalls-tags-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

const body: V2FirewallsTagsRequest = {
  tags: [
    'frontend'
  ],
};

try {
  const response = await firewallsApi.firewallsDeleteTags(
    firewallId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Firewalls Add Tags

To assign a tag representing a group of Droplets to a firewall, send a POST
request to `/v2/firewalls/$FIREWALL_ID/tags`. In the body of the request,
there should be a `tags` attribute containing a list of tag names.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```ts
async firewallsAddTags(
  firewallId: string,
  body?: V2FirewallsTagsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `string` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsTagsRequest \| undefined`](../../doc/models/v2-firewalls-tags-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const firewallId = 'bb4b2611-3d72-467b-8602-280330ecd65c';

const body: V2FirewallsTagsRequest = {
  tags: [
    'frontend'
  ],
};

try {
  const response = await firewallsApi.firewallsAddTags(
    firewallId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |

