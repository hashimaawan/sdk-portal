
# Day

The day of the maintenance window policy. May be one of `monday` through `sunday`, or `any` to indicate an arbitrary week day.

## Enumeration

`Day`

## Fields

| Name |
|  --- |
| `ANY` |
| `MONDAY` |
| `TUESDAY` |
| `WEDNESDAY` |
| `THURSDAY` |
| `FRIDAY` |
| `SATURDAY` |
| `SUNDAY` |

## Example

```python
from digitaloceanapi.models.day import Day

day = Day.THURSDAY
```

