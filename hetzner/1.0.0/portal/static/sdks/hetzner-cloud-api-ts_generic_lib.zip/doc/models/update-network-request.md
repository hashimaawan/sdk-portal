
# Update Network Request

*This model accepts additional fields of type unknown.*

## Structure

`UpdateNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2 \| undefined`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New network name |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UpdateNetworkRequest } from 'hetzner-cloud-apilib';

const updateNetworkRequest: UpdateNetworkRequest = {
  labels: {
    labelkey: 'labelkey4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  name: 'new-name',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

