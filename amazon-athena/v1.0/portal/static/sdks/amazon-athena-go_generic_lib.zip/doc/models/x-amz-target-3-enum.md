
# X Amz Target 3 Enum

## Enumeration

`XAmzTarget3Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENACREATEDATACATALOG` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget3 := models.XAmzTarget3Enum_ENUMAMAZONATHENACREATEDATACATALOG

}
```

