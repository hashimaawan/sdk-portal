
# List Table Metadata Input

## Structure

`ListTableMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalogName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `databaseName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `expression` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `256` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```ts
import { ListTableMetadataInput } from 'amazon-athenalib';

const listTableMetadataInput: ListTableMetadataInput = {
  catalogName: 'CatalogName2',
  databaseName: 'DatabaseName2',
  expression: 'Expression0',
  nextToken: 'NextToken8',
  maxResults: 50,
};
```

