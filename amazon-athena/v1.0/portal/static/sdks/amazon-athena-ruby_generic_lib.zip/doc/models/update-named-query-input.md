
# Update Named Query Input

*This model accepts additional fields of type Object.*

## Structure

`UpdateNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `query_string` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
update_named_query_input = UpdateNamedQueryInput.new(
  named_query_id: 'NamedQueryId8',
  name: 'Name4',
  query_string: 'QueryString6',
  description: 'Description2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

