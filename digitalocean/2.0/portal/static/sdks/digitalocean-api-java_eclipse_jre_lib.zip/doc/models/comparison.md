
# Comparison

The comparison operator used against the alert's threshold.

## Enumeration

`Comparison`

## Fields

| Name |
|  --- |
| `GREATER_THAN` |
| `LESS_THAN` |

## Example

```java
import com.digitalocean.api.models.Comparison;

Comparison comparison = Comparison.GREATER_THAN;
```

