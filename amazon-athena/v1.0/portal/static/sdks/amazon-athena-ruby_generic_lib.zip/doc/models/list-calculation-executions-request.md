
# List Calculation Executions Request

## Structure

`ListCalculationExecutionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `state_filter` | [`CalculationExecutionState3Enum`](../../doc/models/calculation-execution-state-3-enum.md) | Optional | - |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `next_token` | `String` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```ruby
list_calculation_executions_request = ListCalculationExecutionsRequest.new(
  'SessionId2',
  CalculationExecutionState3Enum::CREATING,
  100,
  'NextToken0'
)
```

