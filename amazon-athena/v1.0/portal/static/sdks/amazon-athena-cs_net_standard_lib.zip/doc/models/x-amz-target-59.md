
# X Amz Target 59

## Enumeration

`XAmzTarget59`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateWorkGroup` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget59 xAmzTarget59 = XAmzTarget59.EnumAmazonAthenaUpdateWorkGroup;
```

