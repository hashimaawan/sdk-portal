
# X Amz Target 21 Enum

## Enumeration

`XAmzTarget21Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget21Enum;

XAmzTarget21Enum xAmzTarget21 = XAmzTarget21Enum.ENUM_AMAZONATHENAGETNOTEBOOKMETADATA;
```

