
# Get Data Catalog Output

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DataCatalog` | [`*models.DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getDataCatalogOutput := models.GetDataCatalogOutput{
        DataCatalog:          models.ToPointer(models.DataCatalog2{
            Name:                 "Name4",
            Description:          models.ToPointer("Description2"),
            Type:                 models.DataCatalogType1Enum_GLUE,
            Parameters:           models.ToPointer(models.Parameters{
            }),
        }),
    }

}
```

