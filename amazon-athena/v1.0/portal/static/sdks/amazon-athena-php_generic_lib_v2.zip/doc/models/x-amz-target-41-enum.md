
# X Amz Target 41 Enum

## Enumeration

`XAmzTarget41Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget41Enum;

$xAmzTarget41 = XAmzTarget41Enum::ENUM_AMAZONATHENALISTQUERYEXECUTIONS;
```

