
# Create Notebook Output

## Structure

`CreateNotebookOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NotebookId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    createNotebookOutput := models.CreateNotebookOutput{
        NotebookId:           models.ToPointer("NotebookId6"),
    }

}
```

