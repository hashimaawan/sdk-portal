
# Get Query Results Input

*This model accepts additional fields of type Object.*

## Structure

`GetQueryResultsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 1000` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_query_results_input = GetQueryResultsInput.new(
  query_execution_id: 'QueryExecutionId4',
  next_token: 'NextToken0',
  max_results: 116,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

