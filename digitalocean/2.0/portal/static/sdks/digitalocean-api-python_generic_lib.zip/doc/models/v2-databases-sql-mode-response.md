
# V2 Databases Sql Mode Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DatabasesSqlModeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sql_mode` | `str` | Required | A string specifying the configured SQL modes for the MySQL cluster. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_databases_sql_mode_response import V2DatabasesSqlModeResponse

v_2_databases_sql_mode_response = V2DatabasesSqlModeResponse(
    sql_mode='ANSI,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION,NO_ZERO_DATE,NO_ZERO_IN_DATE,STRICT_ALL_TABLES',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

