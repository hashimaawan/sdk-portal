
# X Amz Target 57 Enum

## Enumeration

`XAmzTarget57Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_57_enum import XAmzTarget57Enum

x_amz_target_57 = XAmzTarget57Enum.ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA
```

