
# X Amz Target 39

## Enumeration

`XAmzTarget39`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNotebookSessions` |

## Example

```ts
import { XAmzTarget39 } from 'amazon-athenalib';

const xAmzTarget39 = XAmzTarget39.EnumAmazonAthenaListNotebookSessions;
```

