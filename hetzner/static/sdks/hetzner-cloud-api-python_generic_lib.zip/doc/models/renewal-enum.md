
# Renewal Enum

Status of the renewal process of the Certificate.

## Enumeration

`RenewalEnum`

## Fields

| Name |
|  --- |
| `SCHEDULED` |
| `PENDING` |
| `FAILED` |
| `UNAVAILABLE` |

## Example

```python
from hetznercloudapi.models.renewal_enum import RenewalEnum

renewal = RenewalEnum.FAILED
```

