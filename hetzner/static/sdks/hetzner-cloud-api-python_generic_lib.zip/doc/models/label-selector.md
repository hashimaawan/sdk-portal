
# Label Selector

## Structure

`LabelSelector`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `str` | Required | Label selector |

## Example

```python
from hetznercloudapi.models.label_selector import LabelSelector

label_selector = LabelSelector(
    selector='env=prod'
)
```

