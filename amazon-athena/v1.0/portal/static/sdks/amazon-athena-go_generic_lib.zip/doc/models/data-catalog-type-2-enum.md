
# Data Catalog Type 2 Enum

The data catalog type.

## Enumeration

`DataCatalogType2Enum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    dataCatalogType2 := models.DataCatalogType2Enum_LAMBDA

}
```

