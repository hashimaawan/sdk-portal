
# X Amz Target 49 Enum

## Enumeration

`XAmzTarget49Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_49_enum import XAmzTarget49Enum

x_amz_target_49 = XAmzTarget49Enum.ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION
```

