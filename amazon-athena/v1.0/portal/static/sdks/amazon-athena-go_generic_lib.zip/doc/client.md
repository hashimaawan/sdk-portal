
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| region | `models.RegionEnum` | The AWS region<br>*Default*: `"us-east-1"` |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| customHeaderAuthenticationCredentials | [`CustomHeaderAuthenticationCredentials`](auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
package main

import (
    "amazonathena"
)

func main() {
    client := amazonathena.NewClient(
    amazonathena.CreateConfiguration(
            amazonathena.WithHttpConfiguration(
                amazonathena.CreateHttpConfiguration(
                    amazonathena.WithTimeout(0),
                ),
            ),
            amazonathena.WithEnvironment(amazonathena.PRODUCTION),
            amazonathena.WithCustomHeaderAuthenticationCredentials(
                amazonathena.NewCustomHeaderAuthenticationCredentials("Authorization"),
            ),
            amazonathena.WithRegion("us-east-1"),
        ),
    )
}
```

## Amazon Athena Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| APIController() | Gets APIController |

