
# Result Reuse Information 2

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reusedPreviousResult` | `bool` | Required | - | getReusedPreviousResult(): bool | setReusedPreviousResult(bool reusedPreviousResult): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultReuseInformation2Builder;

$resultReuseInformation2 = ResultReuseInformation2Builder::init(
    false
)->build();
```

