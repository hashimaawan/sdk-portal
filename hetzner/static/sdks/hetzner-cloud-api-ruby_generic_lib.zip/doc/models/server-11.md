
# Server 11

## Structure

`Server11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the Server |

## Example

```ruby
server11 = Server11.new(
  85
)
```

