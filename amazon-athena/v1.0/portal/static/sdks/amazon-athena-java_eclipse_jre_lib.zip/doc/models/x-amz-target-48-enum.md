
# X Amz Target 48 Enum

## Enumeration

`XAmzTarget48Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTSESSION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget48Enum;

XAmzTarget48Enum xAmzTarget48 = XAmzTarget48Enum.ENUM_AMAZONATHENASTARTSESSION;
```

