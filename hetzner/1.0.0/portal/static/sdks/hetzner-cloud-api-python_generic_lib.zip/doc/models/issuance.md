
# Issuance

Status of the issuance process of the Certificate

## Enumeration

`Issuance`

## Fields

| Name |
|  --- |
| `PENDING` |
| `COMPLETED` |
| `FAILED` |

## Example

```python
from hetznercloudapi.models.issuance import Issuance

issuance = Issuance.FAILED
```

