
# Coordinates

geographical coordinates of the stop

## Structure

`Coordinates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lat` | `float` | Optional | latitude |
| `lon` | `float` | Optional | longitude |

## Example

```python
from furkottrips.models.coordinates import Coordinates

coordinates = Coordinates(
    lat=182.98,
    lon=16.08
)
```

