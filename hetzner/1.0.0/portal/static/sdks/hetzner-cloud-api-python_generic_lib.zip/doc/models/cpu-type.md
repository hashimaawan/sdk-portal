
# Cpu Type

Type of cpu

## Enumeration

`CpuType`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```python
from hetznercloudapi.models.cpu_type import CpuType

cpu_type = CpuType.SHARED
```

