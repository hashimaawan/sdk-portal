
# X Amz Target 31 Enum

## Enumeration

`XAmzTarget31Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```python
from amazonathena.models.x_amz_target_31_enum import XAmzTarget31Enum

x_amz_target_31 = XAmzTarget31Enum.ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES
```

