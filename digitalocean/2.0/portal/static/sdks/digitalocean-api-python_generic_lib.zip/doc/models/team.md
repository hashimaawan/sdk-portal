
# Team

When authorized in a team context, includes information about the current team.

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Team`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | The name for the current team. |
| `uuid` | `str` | Optional | The unique universal identifier for the current team. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.team import Team

team = Team(
    name='My Team',
    uuid='5df3e3004a17e242b7c20ca6c9fc25b701a47ece',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

