
# X Amz Target 3 Enum

## Enumeration

`XAmzTarget3Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateDataCatalog` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget3Enum xAmzTarget3 = XAmzTarget3Enum.EnumAmazonAthenaCreateDataCatalog;
```

