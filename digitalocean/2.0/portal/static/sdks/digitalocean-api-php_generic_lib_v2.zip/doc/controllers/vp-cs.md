# VP Cs

[VPCs (virtual private clouds)](https://www.digitalocean.com/docs/networking/vpc/)
allow you to create virtual networks containing resources that can
communicate with each other in full isolation using private IP addresses.

By sending requests to the `/v2/vpcs` endpoint, you can create, configure,
list, and delete custom VPCs as well as retrieve information about the
resources assigned to them.

```php
$vpCsApi = $client->getVpCsApi();
```

## Class Name

`VpCsApi`

## Methods

* [Vpcs List](../../doc/controllers/vp-cs.md#vpcs-list)
* [Vpcs Create](../../doc/controllers/vp-cs.md#vpcs-create)
* [Vpcs Delete](../../doc/controllers/vp-cs.md#vpcs-delete)
* [Vpcs Get](../../doc/controllers/vp-cs.md#vpcs-get)
* [Vpcs Patch](../../doc/controllers/vp-cs.md#vpcs-patch)
* [Vpcs Update](../../doc/controllers/vp-cs.md#vpcs-update)
* [Vpcs List Members](../../doc/controllers/vp-cs.md#vpcs-list-members)


# Vpcs List

To list all of the VPCs on your account, send a GET request to `/v2/vpcs`.

```php
function vpcsList(?int $perPage = 20, ?int $page = 1): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object with a key called `vpcs`. This will be set to an array of objects, each of which will contain the standard attributes associated with a VPC

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2VpcsResponse`](../../doc/models/v2-vpcs-response.md).

## Example Usage

```php
$perPage = 2;

$page = 1;

$vpCsApi = $client->getVpCsApi();
$apiResponse = $vpCsApi->vpcsList(
    $perPage,
    $page
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2VpcsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Vpcs Create

To create a VPC, send a POST request to `/v2/vpcs` specifying the attributes
in the table below in the JSON body.

**Note:** If you do not currently have a VPC network in a specific datacenter
region, the first one that you create will be set as the default for that
region. The default VPC for a region cannot be changed or deleted.

```php
function vpcsCreate(V2VpcsRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2VpcsRequest`](../../doc/models/v2-vpcs-request.md) | Body, Required | - |

## Response Type

**201**: The response will be a JSON object with a key called `vpc`. The value of this will be an object that contains the standard attributes associated with a VPC.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2VpcsResponse1`](../../doc/models/v2-vpcs-response-1.md).

## Example Usage

```php
$body = V2VpcsRequestBuilder::init(
    'env.prod-vpc',
    'nyc1'
)
    ->description('VPC for production environment')
    ->ipRange('10.10.10.0/24')
    ->build();

$vpCsApi = $client->getVpCsApi();
$apiResponse = $vpCsApi->vpcsCreate($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2VpcsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Vpcs Delete

To delete a VPC, send a DELETE request to `/v2/vpcs/$VPC_ID`. A 204 status
code with no body will be returned in response to a successful request.

The default VPC for a region can not be deleted. Additionally, a VPC can only
be deleted if it does not contain any member resources. Attempting to delete
a region's default VPC or a VPC that still has members will result in a
403 Forbidden error response.

```php
function vpcsDelete(string $vpcId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpcId` | `string` | Template, Required | A unique identifier for a VPC. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$vpcId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$vpCsApi = $client->getVpCsApi();
$apiResponse = $vpCsApi->vpcsDelete($vpcId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Vpcs Get

To show information about an existing VPC, send a GET request to `/v2/vpcs/$VPC_ID`.

```php
function vpcsGet(string $vpcId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpcId` | `string` | Template, Required | A unique identifier for a VPC. |

## Response Type

**200**: The response will be a JSON object with a key called `vpc`. The value of this will be an object that contains the standard attributes associated with a VPC.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2VpcsResponse1`](../../doc/models/v2-vpcs-response-1.md).

## Example Usage

```php
$vpcId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$vpCsApi = $client->getVpCsApi();
$apiResponse = $vpCsApi->vpcsGet($vpcId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2VpcsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Vpcs Patch

To update a subset of information about a VPC, send a PATCH request to
`/v2/vpcs/$VPC_ID`.

```php
function vpcsPatch(string $vpcId, V2VpcsRequest1 $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpcId` | `string` | Template, Required | A unique identifier for a VPC. |
| `body` | [`V2VpcsRequest1`](../../doc/models/v2-vpcs-request-1.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `vpc`. The value of this will be an object that contains the standard attributes associated with a VPC.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2VpcsResponse1`](../../doc/models/v2-vpcs-response-1.md).

## Example Usage

```php
$vpcId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$body = V2VpcsRequest1Builder::init()
    ->description('VPC for production environment')
    ->name('env.prod-vpc')
    ->default(true)
    ->build();

$vpCsApi = $client->getVpCsApi();
$apiResponse = $vpCsApi->vpcsPatch(
    $vpcId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2VpcsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Vpcs Update

To update information about a VPC, send a PUT request to `/v2/vpcs/$VPC_ID`.

```php
function vpcsUpdate(string $vpcId, V2VpcsRequest2 $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpcId` | `string` | Template, Required | A unique identifier for a VPC. |
| `body` | [`V2VpcsRequest2`](../../doc/models/v2-vpcs-request-2.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `vpc`. The value of this will be an object that contains the standard attributes associated with a VPC.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2VpcsResponse1`](../../doc/models/v2-vpcs-response-1.md).

## Example Usage

```php
$vpcId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$body = V2VpcsRequest2Builder::init(
    'env.prod-vpc'
)
    ->description('VPC for production environment')
    ->default(true)
    ->build();

$vpCsApi = $client->getVpCsApi();
$apiResponse = $vpCsApi->vpcsUpdate(
    $vpcId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2VpcsResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Vpcs List Members

To list all of the resources that are members of a VPC, send a GET request to
`/v2/vpcs/$VPC_ID/members`.

To only list resources of a specific type that are members of the VPC,
included a `resource_type` query parameter. For example, to only list Droplets
in the VPC, send a GET request to `/v2/vpcs/$VPC_ID/members?resource_type=droplet`.

```php
function vpcsListMembers(
    string $vpcId,
    ?string $resourceType = null,
    ?int $perPage = 20,
    ?int $page = 1
): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpcId` | `string` | Template, Required | A unique identifier for a VPC. |
| `resourceType` | `?string` | Query, Optional | Used to filter VPC members by a resource type. |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object with a key called members. This will be set to an array of objects, each of which will contain the standard attributes associated with a VPC member.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2VpcsMembersResponse`](../../doc/models/v2-vpcs-members-response.md).

## Example Usage

```php
$vpcId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$resourceType = 'droplet';

$perPage = 2;

$page = 1;

$vpCsApi = $client->getVpCsApi();
$apiResponse = $vpCsApi->vpcsListMembers(
    $vpcId,
    $resourceType,
    $perPage,
    $page
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2VpcsMembersResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

