
# Load Balancer Target Server

Server where the traffic should be routed through

*This model accepts additional fields of type interface{}.*

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    loadBalancerTargetServer := models.LoadBalancerTargetServer{
        Id:                    80,
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

