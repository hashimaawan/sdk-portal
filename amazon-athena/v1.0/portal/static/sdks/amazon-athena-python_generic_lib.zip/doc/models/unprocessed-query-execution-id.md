
# Unprocessed Query Execution Id

Describes a query execution that failed to process.

## Structure

`UnprocessedQueryExecutionId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `error_code` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `error_message` | `str` | Optional | - |

## Example

```python
from amazonathena.models.unprocessed_query_execution_id import UnprocessedQueryExecutionId

unprocessed_query_execution_id = UnprocessedQueryExecutionId(
    query_execution_id='QueryExecutionId8',
    error_code='ErrorCode4',
    error_message='ErrorMessage6'
)
```

