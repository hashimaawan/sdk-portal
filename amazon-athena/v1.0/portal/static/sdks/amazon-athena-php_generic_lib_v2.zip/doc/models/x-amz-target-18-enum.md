
# X Amz Target 18 Enum

## Enumeration

`XAmzTarget18Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATACATALOG` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget18Enum;

$xAmzTarget18 = XAmzTarget18Enum::ENUM_AMAZONATHENAGETDATACATALOG;
```

