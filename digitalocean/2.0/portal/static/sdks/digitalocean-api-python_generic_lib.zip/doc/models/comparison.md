
# Comparison

The comparison operator used against the alert's threshold.

## Enumeration

`Comparison`

## Fields

| Name |
|  --- |
| `GREATER_THAN` |
| `LESS_THAN` |

## Example

```python
from digitaloceanapi.models.comparison import Comparison

comparison = Comparison.GREATER_THAN
```

