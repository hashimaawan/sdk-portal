
# X Amz Target 38 Enum

## Enumeration

`XAmzTarget38Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget38Enum;

XAmzTarget38Enum xAmzTarget38 = XAmzTarget38Enum.ENUM_AMAZONATHENALISTNOTEBOOKMETADATA;
```

