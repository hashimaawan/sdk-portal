
# Labels

User-defined labels (key-value pairs)

*This model accepts additional fields of type Object.*

## Structure

`Labels`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labelkey` | `String` | Optional | New label |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
labels = Labels.new(
  labelkey: 'value',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

