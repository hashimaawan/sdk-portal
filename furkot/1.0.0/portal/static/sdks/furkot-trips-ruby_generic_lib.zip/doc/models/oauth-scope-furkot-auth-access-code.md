
# Oauth Scope Furkot Auth Access Code

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthAccessCode`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list trips and stops info |

## Example

```ruby
oauth_scope_furkot_auth_access_code = OauthScopeFurkotAuthAccessCode::READTRIPS
```

