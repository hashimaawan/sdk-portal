
# X Amz Target

## Enumeration

`XAmzTarget`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target import XAmzTarget

x_amz_target = XAmzTarget.ENUM_AMAZONATHENABATCHGETNAMEDQUERY
```

