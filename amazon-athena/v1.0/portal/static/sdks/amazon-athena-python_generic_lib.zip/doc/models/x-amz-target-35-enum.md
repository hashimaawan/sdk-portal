
# X Amz Target 35 Enum

## Enumeration

`XAmzTarget35Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTENGINEVERSIONS` |

## Example

```python
from amazonathena.models.x_amz_target_35_enum import XAmzTarget35Enum

x_amz_target_35 = XAmzTarget35Enum.ENUM_AMAZONATHENALISTENGINEVERSIONS
```

