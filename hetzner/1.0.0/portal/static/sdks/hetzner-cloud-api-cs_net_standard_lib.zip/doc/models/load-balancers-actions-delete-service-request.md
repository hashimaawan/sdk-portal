
# Load Balancers Actions Delete Service Request

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ListenPort` | `double` | Required | The listen port of the service you want to delete |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LoadBalancersActionsDeleteServiceRequest loadBalancersActionsDeleteServiceRequest = new LoadBalancersActionsDeleteServiceRequest
{
    ListenPort = 4711,
};
```

