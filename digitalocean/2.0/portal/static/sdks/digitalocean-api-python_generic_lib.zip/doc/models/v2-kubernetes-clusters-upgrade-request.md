
# V2 Kubernetes Clusters Upgrade Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUpgradeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `str` | Optional | The slug identifier for the version of Kubernetes that the cluster will be upgraded to. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_kubernetes_clusters_upgrade_request import V2KubernetesClustersUpgradeRequest

v_2_kubernetes_clusters_upgrade_request = V2KubernetesClustersUpgradeRequest(
    version='1.16.13-do.0',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

