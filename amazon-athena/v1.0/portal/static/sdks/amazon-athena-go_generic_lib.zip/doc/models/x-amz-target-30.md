
# X Amz Target 30

## Enumeration

`XAmzTarget30`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaimportnotebook` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget30 := models.XAmzTarget30_EnumAmazonathenaimportnotebook

}
```

