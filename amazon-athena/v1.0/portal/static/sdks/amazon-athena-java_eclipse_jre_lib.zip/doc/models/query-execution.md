
# Query Execution

Information about a single instance of a query execution.

## Structure

`QueryExecution`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `QueryExecutionId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | String getQueryExecutionId() | setQueryExecutionId(String queryExecutionId) |
| `Query` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` | String getQuery() | setQuery(String query) |
| `StatementType` | [`StatementType1Enum`](../../doc/models/statement-type-1-enum.md) | Optional | - | StatementType1Enum getStatementType() | setStatementType(StatementType1Enum statementType) |
| `ResultConfiguration` | [`ResultConfiguration1`](../../doc/models/result-configuration-1.md) | Optional | - | ResultConfiguration1 getResultConfiguration() | setResultConfiguration(ResultConfiguration1 resultConfiguration) |
| `ResultReuseConfiguration` | [`ResultReuseConfiguration1`](../../doc/models/result-reuse-configuration-1.md) | Optional | - | ResultReuseConfiguration1 getResultReuseConfiguration() | setResultReuseConfiguration(ResultReuseConfiguration1 resultReuseConfiguration) |
| `QueryExecutionContext` | [`QueryExecutionContext1`](../../doc/models/query-execution-context-1.md) | Optional | - | QueryExecutionContext1 getQueryExecutionContext() | setQueryExecutionContext(QueryExecutionContext1 queryExecutionContext) |
| `Status` | [`Status`](../../doc/models/status.md) | Optional | - | Status getStatus() | setStatus(Status status) |
| `Statistics` | [`Statistics`](../../doc/models/statistics.md) | Optional | - | Statistics getStatistics() | setStatistics(Statistics statistics) |
| `WorkGroup` | `String` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | String getWorkGroup() | setWorkGroup(String workGroup) |
| `EngineVersion` | [`EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - | EngineVersion1 getEngineVersion() | setEngineVersion(EngineVersion1 engineVersion) |
| `ExecutionParameters` | `List<String>` | Optional | **Constraints**: *Minimum Items*: `1`, *Minimum Length*: `1`, *Maximum Length*: `1024` | List<String> getExecutionParameters() | setExecutionParameters(List<String> executionParameters) |
| `SubstatementType` | `String` | Optional | - | String getSubstatementType() | setSubstatementType(String substatementType) |

## Example

```java
import com.amazonaws.useast1.athena.models.AclConfiguration1;
import com.amazonaws.useast1.athena.models.EncryptionConfiguration2;
import com.amazonaws.useast1.athena.models.EncryptionOption1Enum;
import com.amazonaws.useast1.athena.models.QueryExecution;
import com.amazonaws.useast1.athena.models.ResultConfiguration1;
import com.amazonaws.useast1.athena.models.ResultReuseByAgeConfiguration2;
import com.amazonaws.useast1.athena.models.ResultReuseConfiguration1;
import com.amazonaws.useast1.athena.models.S3AclOption1Enum;
import com.amazonaws.useast1.athena.models.StatementType1Enum;

QueryExecution queryExecution = new QueryExecution.Builder()
    .queryExecutionId("QueryExecutionId4")
    .query("Query2")
    .statementType(StatementType1Enum.DML)
    .resultConfiguration(new ResultConfiguration1.Builder()
        .outputLocation("OutputLocation0")
        .encryptionConfiguration(new EncryptionConfiguration2.Builder(
            EncryptionOption1Enum.SSE_S3
        )
        .kmsKey("KmsKey6")
        .build())
        .expectedBucketOwner("ExpectedBucketOwner0")
        .aclConfiguration(new AclConfiguration1.Builder(
            S3AclOption1Enum.BUCKET_OWNER_FULL_CONTROL
        )
        .build())
        .build())
    .resultReuseConfiguration(new ResultReuseConfiguration1.Builder()
        .resultReuseByAgeConfiguration(new ResultReuseByAgeConfiguration2.Builder(
            false
        )
        .maxAgeInMinutes(26)
        .build())
        .build())
    .build();
```

