
# Encryption Configuration

If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information.

*This model accepts additional fields of type Any.*

## Structure

`EncryptionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryption_option` | [`EncryptionOption1`](../../doc/models/encryption-option-1.md) | Required | - |
| `kms_key` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.encryption_configuration import EncryptionConfiguration
from amazonathena.models.encryption_option_1 import EncryptionOption1

encryption_configuration = EncryptionConfiguration(
    encryption_option=EncryptionOption1.SSE_KMS,
    kms_key='KmsKey4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

