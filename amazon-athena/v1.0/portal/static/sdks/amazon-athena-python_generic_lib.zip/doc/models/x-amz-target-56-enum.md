
# X Amz Target 56 Enum

## Enumeration

`XAmzTarget56Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_56_enum import XAmzTarget56Enum

x_amz_target_56 = XAmzTarget56Enum.ENUM_AMAZONATHENAUPDATENOTEBOOK
```

