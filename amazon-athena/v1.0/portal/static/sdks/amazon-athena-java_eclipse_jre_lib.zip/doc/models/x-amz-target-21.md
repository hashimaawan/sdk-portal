
# X Amz Target 21

## Enumeration

`XAmzTarget21`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget21;

XAmzTarget21 xAmzTarget21 = XAmzTarget21.ENUM_AMAZONATHENAGETNOTEBOOKMETADATA;
```

