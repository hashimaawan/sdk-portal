
# X Amz Target 20 Enum

## Enumeration

`XAmzTarget20Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_20_enum import XAmzTarget20Enum

x_amz_target_20 = XAmzTarget20Enum.ENUM_AMAZONATHENAGETNAMEDQUERY
```

