
# X Amz Target 44

## Enumeration

`XAmzTarget44`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```python
from amazonathena.models.x_amz_target_44 import XAmzTarget44

x_amz_target_44 = XAmzTarget44.ENUM_AMAZONATHENALISTTAGSFORRESOURCE
```

