
# X Amz Target 26 Enum

## Enumeration

`XAmzTarget26Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSION` |

## Example

```ruby
x_amz_target26 = XAmzTarget26Enum::ENUM_AMAZONATHENAGETSESSION
```

