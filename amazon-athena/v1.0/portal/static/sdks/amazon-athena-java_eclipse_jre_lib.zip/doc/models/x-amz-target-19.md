
# X Amz Target 19

## Enumeration

`XAmzTarget19`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATABASE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget19;

XAmzTarget19 xAmzTarget19 = XAmzTarget19.ENUM_AMAZONATHENAGETDATABASE;
```

