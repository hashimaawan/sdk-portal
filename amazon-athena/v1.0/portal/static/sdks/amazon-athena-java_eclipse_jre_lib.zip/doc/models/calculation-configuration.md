
# Calculation Configuration

Contains configuration information for the calculation.

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CodeBlock` | `String` | Optional | **Constraints**: *Maximum Length*: `68000` | String getCodeBlock() | setCodeBlock(String codeBlock) |

## Example

```java
import com.amazonaws.useast1.athena.models.CalculationConfiguration;

CalculationConfiguration calculationConfiguration = new CalculationConfiguration.Builder()
    .codeBlock("CodeBlock2")
    .build();
```

