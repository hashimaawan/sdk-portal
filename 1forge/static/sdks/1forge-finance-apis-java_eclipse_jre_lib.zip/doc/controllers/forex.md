# Forex

```java
ForexController forexController = client.getForexController();
```

## Class Name

`ForexController`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```java
CompletableFuture<Void> getQuotesForAllSymbolsAsync()
```

## Response Type

**200**: A list of quotes

`void`

## Example Usage

```java
forexController.getQuotesForAllSymbolsAsync().thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```java
CompletableFuture<List<String>> getAListOfSymbolsForWhichWeProvideRealTimeQuotesAsync()
```

## Response Type

**200**: A list of symbols

`List<String>`

## Example Usage

```java
forexController.getAListOfSymbolsForWhichWeProvideRealTimeQuotesAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

