
# X Amz Target 53

## Enumeration

`XAmzTarget53`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUNTAGRESOURCE` |

## Example

```ruby
x_amz_target53 = XAmzTarget53::ENUM_AMAZONATHENAUNTAGRESOURCE
```

