
# Delete Subnet Request

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ipRange` | `string` | Required | IP range of subnet to delete |

## Example

```ts
import { DeleteSubnetRequest } from 'hetzner-cloud-apilib';

const deleteSubnetRequest: DeleteSubnetRequest = {
  ipRange: '10.0.1.0/24',
};
```

