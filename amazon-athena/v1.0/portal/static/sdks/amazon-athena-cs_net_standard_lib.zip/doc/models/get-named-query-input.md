
# Get Named Query Input

## Structure

`GetNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetNamedQueryInput getNamedQueryInput = new GetNamedQueryInput
{
    NamedQueryId = "NamedQueryId8",
};
```

