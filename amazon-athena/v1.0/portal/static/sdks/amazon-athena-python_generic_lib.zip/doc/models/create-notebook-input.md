
# Create Notebook Input

## Structure

`CreateNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `str` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `client_request_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```python
from amazonathena.models.create_notebook_input import CreateNotebookInput

create_notebook_input = CreateNotebookInput(
    work_group='WorkGroup4',
    name='Name2',
    client_request_token='ClientRequestToken6'
)
```

