
# Status 113 Enum

Current status of the Volume

## Enumeration

`Status113Enum`

## Fields

| Name |
|  --- |
| `Creating` |
| `Available` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Status113Enum status113 = Status113Enum.Creating;
```

