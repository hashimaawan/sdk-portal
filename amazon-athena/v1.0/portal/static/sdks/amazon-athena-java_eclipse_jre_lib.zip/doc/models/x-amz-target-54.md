
# X Amz Target 54

## Enumeration

`XAmzTarget54`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEDATACATALOG` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget54;

XAmzTarget54 xAmzTarget54 = XAmzTarget54.ENUM_AMAZONATHENAUPDATEDATACATALOG;
```

