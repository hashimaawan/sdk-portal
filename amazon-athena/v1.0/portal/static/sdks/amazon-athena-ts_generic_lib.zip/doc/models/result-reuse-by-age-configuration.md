
# Result Reuse by Age Configuration

Specifies whether previous query results are reused, and if so, their maximum age.

## Structure

`ResultReuseByAgeConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enabled` | `boolean` | Required | - |
| `maxAgeInMinutes` | `number \| undefined` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```ts
import { ResultReuseByAgeConfiguration } from 'amazon-athenalib';

const resultReuseByAgeConfiguration: ResultReuseByAgeConfiguration = {
  enabled: false,
  maxAgeInMinutes: 134,
};
```

