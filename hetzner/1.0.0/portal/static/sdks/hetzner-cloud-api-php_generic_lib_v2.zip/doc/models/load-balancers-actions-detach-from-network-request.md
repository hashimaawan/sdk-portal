
# Load Balancers Actions Detach from Network Request

*This model accepts additional fields of type array.*

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `network` | `float` | Required | ID of an existing network to detach the Load Balancer from | getNetwork(): float | setNetwork(float network): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\LoadBalancersActionsDetachFromNetworkRequestBuilder;
use HetznerCloudApiLib\ApiHelper;

$loadBalancersActionsDetachFromNetworkRequest = LoadBalancersActionsDetachFromNetworkRequestBuilder::init(
    4711
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

