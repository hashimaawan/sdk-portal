
# Status 2

## Enumeration

`Status2`

## Fields

| Name |
|  --- |
| `Unknown` |
| `Pending` |
| `Running` |
| `Error` |
| `Success` |

## Example

```ts
import { Status2 } from 'digitalocean-apilib';

const status2 = Status2.Pending;
```

