
# X Amz Target 54 Enum

## Enumeration

`XAmzTarget54Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEDATACATALOG` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget54Enum;

XAmzTarget54Enum xAmzTarget54 = XAmzTarget54Enum.ENUM_AMAZONATHENAUPDATEDATACATALOG;
```

