
# V2 Reserved Ips Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2ReservedIpsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `links` | [`Links3`](../../doc/models/links-3.md) | Optional | - |
| `reserved_ip` | [`ReservedIp`](../../doc/models/reserved-ip.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.action_1 import Action1
from digitaloceanapi.models.links_3 import Links3
from digitaloceanapi.models.region import Region
from digitaloceanapi.models.reserved_ip import ReservedIp
from digitaloceanapi.models.v_2_reserved_ips_response_1 import V2ReservedIpsResponse1

v_2_reserved_ips_response_1 = V2ReservedIpsResponse1(
    links=Links3(
        actions=[
            Action1(
                href='href0',
                id=154,
                rel='rel4',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        droplets=[
            Action1(
                href='href2',
                id=232,
                rel='rel6',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Action1(
                href='href2',
                id=232,
                rel='rel6',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    reserved_ip=ReservedIp(
        droplet=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
        ip='ip6',
        locked=False,
        project_id='00002548-0000-0000-0000-000000000000',
        region=Region(
            available=False,
            features=[
                'features7',
                'features8',
                'features9'
            ],
            name='name6',
            sizes=[
                'sizes6'
            ],
            slug='slug0',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

