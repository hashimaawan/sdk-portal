
# Floating Ip

## Structure

`FloatingIp`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `blocked` | `bool` | Required | Whether the IP is blocked | getBlocked(): bool | setBlocked(bool blocked): void |
| `created` | `string` | Required | Point in time when the Resource was created (in ISO-8601 format) | getCreated(): string | setCreated(string created): void |
| `description` | `?string` | Required | Description of the Resource | getDescription(): ?string | setDescription(?string description): void |
| `dnsPtr` | [`DnsPtr[]`](../../doc/models/dns-ptr.md) | Required | Array of reverse DNS entries | getDnsPtr(): array | setDnsPtr(array dnsPtr): void |
| `homeLocation` | [`HomeLocation`](../../doc/models/home-location.md) | Required | Location the Floating IP was created in. Routing is optimized for this Location. | getHomeLocation(): HomeLocation | setHomeLocation(HomeLocation homeLocation): void |
| `id` | `int` | Required | ID of the Resource | getId(): int | setId(int id): void |
| `ip` | `string` | Required | IP address | getIp(): string | setIp(string ip): void |
| `labels` | `array<string,string>` | Required | User-defined labels (key-value pairs) | getLabels(): array | setLabels(array labels): void |
| `name` | `string` | Required | Name of the Resource. Must be unique per Project. | getName(): string | setName(string name): void |
| `protection` | [`Protection`](../../doc/models/protection.md) | Required | Protection configuration for the Resource | getProtection(): Protection | setProtection(Protection protection): void |
| `server` | `?int` | Required | ID of the Server the Floating IP is assigned to, null if it is not assigned at all | getServer(): ?int | setServer(?int server): void |
| `type` | [`string(Type16Enum)`](../../doc/models/type-16-enum.md) | Required | Type of the Floating IP | getType(): string | setType(string type): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\FloatingIpBuilder;
use HetznerCloudAPILib\Models\Builders\DnsPtrBuilder;
use HetznerCloudAPILib\Models\Builders\HomeLocationBuilder;
use HetznerCloudAPILib\Models\Builders\ProtectionBuilder;
use HetznerCloudAPILib\Models\Type16Enum;

$floatingIp = FloatingIpBuilder::init(
    false,
    '2016-01-30T23:55:00+00:00',
    [
        DnsPtrBuilder::init(
            'server.example.com',
            '2001:db8::1'
        )->build()
    ],
    HomeLocationBuilder::init(
        'Falkenstein',
        'DE',
        'Falkenstein DC Park 1',
        1,
        50.47612,
        12.370071,
        'fsn1',
        'eu-central'
    )->build(),
    42,
    '131.232.99.1',
    [
        'key0' => 'labels6'
    ],
    'my-resource',
    ProtectionBuilder::init(
        false
    )->build(),
    Type16Enum::IPV4
)
    ->description('this describes my resource')
    ->server(42)
    ->build();
```

