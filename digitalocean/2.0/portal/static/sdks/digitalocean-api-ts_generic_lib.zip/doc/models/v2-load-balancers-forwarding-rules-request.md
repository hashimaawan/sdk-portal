
# V2 Load Balancers Forwarding Rules Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2LoadBalancersForwardingRulesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `forwardingRules` | [`ForwardingRule[]`](../../doc/models/forwarding-rule.md) | Required | **Constraints**: *Minimum Items*: `1` |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  EntryProtocol,
  TargetProtocol,
  V2LoadBalancersForwardingRulesRequest,
} from 'digitalocean-apilib';

const v2LoadBalancersForwardingRulesRequest: V2LoadBalancersForwardingRulesRequest = {
  forwardingRules: [
    {
      entryPort: 443,
      entryProtocol: EntryProtocol.Https,
      targetPort: 80,
      targetProtocol: TargetProtocol.Http,
      certificateId: '892071a0-bb95-49bc-8021-3afd67a210bf',
      tlsPassthrough: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

