
# Window

## Enumeration

`Window`

## Fields

| Name |
|  --- |
| `UnspecifiedWindow` |
| `FiveMinutes` |
| `TenMinutes` |
| `ThirtyMinutes` |
| `OneHour` |

## Example

```ts
import { Window } from 'digitalocean-apilib';

const window = Window.OneHour;
```

