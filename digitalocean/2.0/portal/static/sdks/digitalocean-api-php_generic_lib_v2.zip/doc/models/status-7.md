
# Status 7

A status string indicating the state of a custom image. This may be `NEW`,
`available`, `pending`, `deleted`, or `retired`.

## Enumeration

`Status7`

## Fields

| Name |
|  --- |
| `NEW_` |
| `AVAILABLE` |
| `PENDING` |
| `DELETED` |
| `RETIRED` |

## Example

```php
use DigitalOceanApiLib\Models\Status7;

$status7 = Status7::NEW_;
```

