
# Result Reuse Configuration

Specifies the query result reuse behavior for the query.

## Structure

`ResultReuseConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResultReuseByAgeConfiguration` | [`*models.ResultReuseByAgeConfiguration2`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    resultReuseConfiguration := models.ResultReuseConfiguration{
        ResultReuseByAgeConfiguration: models.ToPointer(models.ResultReuseByAgeConfiguration2{
            Enabled:              false,
            MaxAgeInMinutes:      models.ToPointer(26),
        }),
    }

}
```

