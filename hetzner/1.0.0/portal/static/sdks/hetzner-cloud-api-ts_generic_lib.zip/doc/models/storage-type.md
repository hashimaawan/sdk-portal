
# Storage Type

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageType`

## Fields

| Name |
|  --- |
| `Local` |
| `Network` |

## Example

```ts
import { StorageType } from 'hetzner-cloud-apilib';

const storageType = StorageType.Local;
```

