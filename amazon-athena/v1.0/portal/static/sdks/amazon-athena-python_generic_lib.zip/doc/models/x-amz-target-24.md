
# X Amz Target 24

## Enumeration

`XAmzTarget24`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRESULTS` |

## Example

```python
from amazonathena.models.x_amz_target_24 import XAmzTarget24

x_amz_target_24 = XAmzTarget24.ENUM_AMAZONATHENAGETQUERYRESULTS
```

