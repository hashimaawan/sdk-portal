
# Type 14

## Enumeration

`Type14`

## Fields

| Name |
|  --- |
| `APPLICATION` |
| `DISTRIBUTION` |

## Example

```php
use DigitalOceanApiLib\Models\Type14;

$type14 = Type14::APPLICATION;
```

