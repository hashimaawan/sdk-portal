
# Executor Type 2

The type of executor used for the application (<code>COORDINATOR</code>, <code>GATEWAY</code>, or <code>WORKER</code>).

## Enumeration

`ExecutorType2`

## Fields

| Name |
|  --- |
| `Coordinator` |
| `Gateway` |
| `Worker` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    executorType2 := models.ExecutorType2_Coordinator

}
```

