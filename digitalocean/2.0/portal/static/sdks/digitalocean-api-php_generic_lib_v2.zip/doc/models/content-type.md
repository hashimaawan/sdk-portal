
# Content Type

## Enumeration

`ContentType`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONYAML` |

## Example

```php
use DigitalOceanApiLib\Models\ContentType;

$contentType = ContentType::ENUM_APPLICATIONJSON;
```

