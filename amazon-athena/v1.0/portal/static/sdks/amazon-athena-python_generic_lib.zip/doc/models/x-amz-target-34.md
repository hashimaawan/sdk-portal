
# X Amz Target 34

## Enumeration

`XAmzTarget34`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATABASES` |

## Example

```python
from amazonathena.models.x_amz_target_34 import XAmzTarget34

x_amz_target_34 = XAmzTarget34.ENUM_AMAZONATHENALISTDATABASES
```

