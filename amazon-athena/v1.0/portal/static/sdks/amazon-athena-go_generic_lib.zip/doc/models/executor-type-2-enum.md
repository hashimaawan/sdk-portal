
# Executor Type 2 Enum

The type of executor used for the application (<code>COORDINATOR</code>, <code>GATEWAY</code>, or <code>WORKER</code>).

## Enumeration

`ExecutorType2Enum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    executorType2 := models.ExecutorType2Enum_COORDINATOR

}
```

