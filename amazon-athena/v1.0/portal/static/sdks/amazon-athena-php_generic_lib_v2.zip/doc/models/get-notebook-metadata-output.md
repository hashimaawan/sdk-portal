
# Get Notebook Metadata Output

*This model accepts additional fields of type array.*

## Structure

`GetNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notebookMetadata` | [`?NotebookMetadata1`](../../doc/models/notebook-metadata-1.md) | Optional | - | getNotebookMetadata(): ?NotebookMetadata1 | setNotebookMetadata(?NotebookMetadata1 notebookMetadata): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetNotebookMetadataOutputBuilder;
use AmazonAthenaLib\Models\Builders\NotebookMetadata1Builder;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\Models\NotebookType1;
use AmazonAthenaLib\ApiHelper;

$getNotebookMetadataOutput = GetNotebookMetadataOutputBuilder::init()
    ->notebookMetadata(
        NotebookMetadata1Builder::init()
            ->notebookId('NotebookId0')
            ->name('Name0')
            ->workGroup('WorkGroup2')
            ->creationTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->type(NotebookType1::IPYNB)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

