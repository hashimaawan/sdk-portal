
# Assign to Droplet

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`AssignToDroplet`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_id` | `Integer` | Required | The ID of the Droplet that the floating IP will be assigned to. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
assign_to_droplet = AssignToDroplet.new(
  droplet_id: 2457247,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

