
# Parameters

*This model accepts additional fields of type string.*

## Structure

`Parameters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AdditionalProperties` | `map[string]string` | Optional | **Constraints**: *Maximum Length*: `51200` |

## Example (as JSON)

```json
{
  "exampleAdditionalProperty": "Parameters_additionalProperties2"
}
```

