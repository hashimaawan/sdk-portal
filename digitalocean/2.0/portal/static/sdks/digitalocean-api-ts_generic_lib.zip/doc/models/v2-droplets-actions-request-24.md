
# V2 Droplets Actions Request 24

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest24`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `kernel` | `number \| undefined` | Optional | A unique number used to identify and reference a specific kernel. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type12, V2DropletsActionsRequest24 } from 'digitalocean-apilib';

const v2DropletsActionsRequest24: V2DropletsActionsRequest24 = {
  type: Type12.Reboot,
  kernel: 12389723,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

