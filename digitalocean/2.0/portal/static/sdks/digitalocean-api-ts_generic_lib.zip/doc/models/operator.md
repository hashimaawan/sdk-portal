
# Operator

## Enumeration

`Operator`

## Fields

| Name |
|  --- |
| `UnspecifiedOperator` |
| `GreaterThan` |
| `LessThan` |

## Example

```ts
import { Operator } from 'digitalocean-apilib';

const operator = Operator.LessThan;
```

