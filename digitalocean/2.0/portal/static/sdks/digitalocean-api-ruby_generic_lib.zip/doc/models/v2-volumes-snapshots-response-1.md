
# V2 Volumes Snapshots Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2VolumesSnapshotsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `snapshots` | [`Array[Snapshot]`](../../doc/models/snapshot.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_volumes_snapshots_response1 = V2VolumesSnapshotsResponse1.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  snapshots: [
    Snapshot.new(
      id: '8eb4d51a-873f-11e6-96bf-000f53315a41',
      created_at: DateTimeHelper.from_rfc3339('2020-09-30T18:56:12Z'),
      min_disk_size: 10,
      name: 'big-data-snapshot1475261752',
      regions: [
        'nyc1'
      ],
      size_gigabytes: 0,
      resource_id: '82a48a18-873f-11e6-96bf-000f53315a41',
      resource_type: ResourceType1::VOLUME,
      tags: nil,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

