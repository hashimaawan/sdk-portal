
# X Amz Target 32

## Enumeration

`XAmzTarget32`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget32;

XAmzTarget32 xAmzTarget32 = XAmzTarget32.ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS;
```

