
# Links 3

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Links3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `actions` | [`Action1[] \| undefined`](../../doc/models/action-1.md) | Optional | - |
| `droplets` | [`Action1[] \| undefined`](../../doc/models/action-1.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Links3 } from 'digitalocean-apilib';

const links3: Links3 = {
  actions: [
    {
      href: 'href0',
      id: 154,
      rel: 'rel4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      href: 'href0',
      id: 154,
      rel: 'rel4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  droplets: [
    {
      href: 'href2',
      id: 232,
      rel: 'rel6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      href: 'href2',
      id: 232,
      rel: 'rel6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      href: 'href2',
      id: 232,
      rel: 'rel6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

