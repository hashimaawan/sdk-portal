
# Type 2

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `UserCreated` |
| `Personal` |
| `Everyone` |
| `Transfer` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    type2 := models.Type2_Everyone

}
```

