
# Start Calculation Execution Request

*This model accepts additional fields of type Object.*

## Structure

`StartCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `calculation_configuration` | [`GetCalculationExecutionCodeResponse`](../../doc/models/get-calculation-execution-code-response.md) | Optional | - |
| `code_block` | `String` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `client_request_token` | `String` | Optional | **Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
start_calculation_execution_request = StartCalculationExecutionRequest.new(
  session_id: 'SessionId8',
  description: 'Description6',
  calculation_configuration: GetCalculationExecutionCodeResponse.new(
    code_block: 'CodeBlock4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  code_block: 'CodeBlock2',
  client_request_token: 'ClientRequestToken4',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

