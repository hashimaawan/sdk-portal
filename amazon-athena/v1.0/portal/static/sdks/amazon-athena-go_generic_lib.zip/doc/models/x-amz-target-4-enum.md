
# X Amz Target 4 Enum

## Enumeration

`XAmzTarget4Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENACREATENAMEDQUERY` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget4 := models.XAmzTarget4Enum_ENUMAMAZONATHENACREATENAMEDQUERY

}
```

