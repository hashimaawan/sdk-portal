# Items

Access and manage items inside 1Password Vaults

```ts
const itemsApi = new ItemsApi(client);
```

## Class Name

`ItemsApi`

## Methods

* [Get Vault Items](../../doc/controllers/items.md#get-vault-items)
* [Create Vault Item](../../doc/controllers/items.md#create-vault-item)
* [Delete Vault Item](../../doc/controllers/items.md#delete-vault-item)
* [Get Vault Item by Id](../../doc/controllers/items.md#get-vault-item-by-id)
* [Patch Vault Item](../../doc/controllers/items.md#patch-vault-item)
* [Update Vault Item](../../doc/controllers/items.md#update-vault-item)


# Get Vault Items

```ts
async getVaultItems(
  vaultUuid: string,
  filter?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<Item[]>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `filter` | `string \| undefined` | Query, Optional | Filter the Item collection based on Item name using SCIM eq filter |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`Item[]`](../../doc/models/item.md).

## Example Usage

```ts
const vaultUuid = 'vaultUuid2';

const filter = 'title eq "Some Item Name"';

try {
  const response = await itemsApi.getVaultItems(
    vaultUuid,
    filter
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | Vault not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Create Vault Item

```ts
async createVaultItem(
  vaultUuid: string,
  body?: FullItem,
  requestOptions?: RequestOptions
): Promise<ApiResponse<FullItem>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to create an Item in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`FullItem \| undefined`](../../doc/models/full-item.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```ts
const vaultUuid = 'vaultUuid2';

const body: FullItem = {
  category: Category.Membership,
  vault: {
    id: 'id6',
  },
  favorite: false,
  urls: [
    {
      href: 'https://example.com',
      primary: true,
    },
    {
      href: 'https://example.org',
    }
  ],
};

try {
  const response = await itemsApi.createVaultItem(
    vaultUuid,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Unable to create item due to invalid input | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 403 | Unauthorized access | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | Item not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Delete Vault Item

```ts
async deleteVaultItem(
  vaultUuid: string,
  itemUuid: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault the item is in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: Successfully deleted an item

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const vaultUuid = 'vaultUuid2';

const itemUuid = 'itemUuid6';

try {
  const response = await itemsApi.deleteVaultItem(
    vaultUuid,
    itemUuid
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 403 | Unauthorized access | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | Item not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Get Vault Item by Id

```ts
async getVaultItemById(
  vaultUuid: string,
  itemUuid: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<FullItem>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Item from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to fetch<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```ts
const vaultUuid = 'vaultUuid2';

const itemUuid = 'itemUuid6';

try {
  const response = await itemsApi.getVaultItemById(
    vaultUuid,
    itemUuid
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 403 | Unauthorized access | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | Item not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Patch Vault Item

Applies a modified [RFC6902 JSON Patch](https://tools.ietf.org/html/rfc6902) document to an Item or ItemField. This endpoint only supports `add`, `remove` and `replace` operations.

When modifying a specific ItemField, the ItemField's ID in the `path` attribute of the operation object: `/fields/{fieldId}`

```ts
async patchVaultItem(
  vaultUuid: string,
  itemUuid: string,
  body?: Patch[],
  requestOptions?: RequestOptions
): Promise<ApiResponse<FullItem>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault the item is in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`Patch[] \| undefined`](../../doc/models/patch.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK - Item updated. If no Patch operations were provided, Item is unmodified.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```ts
const vaultUuid = 'vaultUuid2';

const itemUuid = 'itemUuid6';

const body: Patch[] = [
  {
    op: Op.Add,
    path: '/fields',
    value: { 'label': 'New Field', 'type': 'string', 'value': 'hunter2' },
  }
];

try {
  const response = await itemsApi.patchVaultItem(
    vaultUuid,
    itemUuid,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 403 | Unauthorized access | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | Item not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Update Vault Item

```ts
async updateVaultItem(
  vaultUuid: string,
  itemUuid: string,
  body?: FullItem,
  requestOptions?: RequestOptions
): Promise<ApiResponse<FullItem>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Item's Vault<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`FullItem \| undefined`](../../doc/models/full-item.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```ts
const vaultUuid = 'vaultUuid2';

const itemUuid = 'itemUuid6';

const body: FullItem = {
  category: Category.Membership,
  vault: {
    id: 'id6',
  },
  favorite: false,
  urls: [
    {
      href: 'https://example.com',
      primary: true,
    },
    {
      href: 'https://example.org',
    }
  ],
};

try {
  const response = await itemsApi.updateVaultItem(
    vaultUuid,
    itemUuid,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Unable to create item due to invalid input | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 403 | Unauthorized access | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | Item not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

