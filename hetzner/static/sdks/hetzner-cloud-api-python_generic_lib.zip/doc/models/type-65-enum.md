
# Type 65 Enum

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65Enum`

## Fields

| Name |
|  --- |
| `LINUX64` |
| `LINUX32` |

## Example

```python
from hetznercloudapi.models.type_65_enum import Type65Enum

type_65 = Type65Enum.LINUX64
```

