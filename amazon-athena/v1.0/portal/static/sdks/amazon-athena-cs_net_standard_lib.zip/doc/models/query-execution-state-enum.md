
# Query Execution State Enum

## Enumeration

`QueryExecutionStateEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryExecutionStateEnum queryExecutionState = QueryExecutionStateEnum.CANCELLED;
```

