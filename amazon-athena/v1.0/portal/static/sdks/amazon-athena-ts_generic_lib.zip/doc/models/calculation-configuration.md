
# Calculation Configuration

Contains configuration information for the calculation.

*This model accepts additional fields of type unknown.*

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `codeBlock` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { CalculationConfiguration } from 'amazon-athenalib';

const calculationConfiguration: CalculationConfiguration = {
  codeBlock: 'CodeBlock2',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

