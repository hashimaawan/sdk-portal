
# Getting Started with 1Forge Finance APIs

## Introduction

Stock and Forex Data and Realtime Quotes

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the m1ForgeFinanceApIs library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace m1ForgeFinanceApIs => ".\\1forge-finance-apis-go_generic_lib" // local path to the SDK

require m1ForgeFinanceApIs v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |

The API client can be initialized as follows:

```go
package main

import (
    "m1ForgeFinanceApIs"
)

func main() {
    client := m1ForgeFinanceApIs.NewClient(
    m1ForgeFinanceApIs.CreateConfiguration(
            m1ForgeFinanceApIs.WithHttpConfiguration(
                m1ForgeFinanceApIs.CreateHttpConfiguration(
                    m1ForgeFinanceApIs.WithTimeout(30),
                ),
            ),
            m1ForgeFinanceApIs.WithEnvironment(m1ForgeFinanceApIs.PRODUCTION),
            m1ForgeFinanceApIs.WithLoggerConfiguration(
                m1ForgeFinanceApIs.WithLevel("info"),
                m1ForgeFinanceApIs.WithRequestConfiguration(
                    m1ForgeFinanceApIs.WithRequestBody(true),
                ),
                m1ForgeFinanceApIs.WithResponseConfiguration(
                    m1ForgeFinanceApIs.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| Production | **Default** |

## List of APIs

* [Forex](doc/controllers/forex.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

