
# V2 Volumes Actions Request 2

*This model accepts additional fields of type Object.*

## Structure

`V2VolumesActionsRequest2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Region` | [`Region2`](../../doc/models/region-2.md) | Optional | The slug identifier for the region where the resource will initially be  available. | Region2 getRegion() | setRegion(Region2 region) |
| `Type` | [`Type21`](../../doc/models/type-21.md) | Required | The volume action to initiate. | Type21 getType() | setType(Type21 type) |
| `SizeGigabytes` | `int` | Required | The new size of the block storage volume in GiB (1024^3).<br><br>**Constraints**: `<= 16384` | int getSizeGigabytes() | setSizeGigabytes(int sizeGigabytes) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Region2;
import com.digitalocean.api.models.Type21;
import com.digitalocean.api.models.V2VolumesActionsRequest2;
import java.io.IOException;

V2VolumesActionsRequest2 v2VolumesActionsRequest2 = new V2VolumesActionsRequest2.Builder(
    Type21.ATTACH,
    15384
)
.region(Region2.NYC3)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

