
# Type 65

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65`

## Fields

| Name |
|  --- |
| `Linux64` |
| `Linux32` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type65 := models.Type65_Linux64

}
```

