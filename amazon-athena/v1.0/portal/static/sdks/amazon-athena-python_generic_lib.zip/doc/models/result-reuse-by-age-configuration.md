
# Result Reuse by Age Configuration

Specifies whether previous query results are reused, and if so, their maximum age.

## Structure

`ResultReuseByAgeConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enabled` | `bool` | Required | - |
| `max_age_in_minutes` | `int` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```python
from amazonathena.models.result_reuse_by_age_configuration import ResultReuseByAgeConfiguration

result_reuse_by_age_configuration = ResultReuseByAgeConfiguration(
    enabled=False,
    max_age_in_minutes=32
)
```

