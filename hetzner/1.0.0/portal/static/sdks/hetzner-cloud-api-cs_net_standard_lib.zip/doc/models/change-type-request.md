
# Change Type Request

## Structure

`ChangeTypeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LoadBalancerType` | `string` | Required | ID or name of Load Balancer type the Load Balancer should migrate to |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ChangeTypeRequest changeTypeRequest = new ChangeTypeRequest
{
    LoadBalancerType = "lb21",
};
```

