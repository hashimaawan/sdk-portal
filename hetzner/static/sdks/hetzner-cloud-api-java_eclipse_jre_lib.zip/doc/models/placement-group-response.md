
# Placement Group Response

## Structure

`PlacementGroupResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PlacementGroup` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - | PlacementGroup getPlacementGroup() | setPlacementGroup(PlacementGroup placementGroup) |

## Example

```java
import cloud.hetzner.api.models.PlacementGroup;
import cloud.hetzner.api.models.PlacementGroupResponse;
import java.util.Arrays;
import java.util.LinkedHashMap;

PlacementGroupResponse placementGroupResponse = new PlacementGroupResponse.Builder(
    new PlacementGroup.Builder(
        "2016-01-30T23:55:00+00:00",
        42,
        new LinkedHashMap<String, String>() {{
            put("key0", "labels4");
        }},
        "my-resource",
        Arrays.asList(
            42
        ),
        "spread"
    )
    .build()
)
.build();
```

