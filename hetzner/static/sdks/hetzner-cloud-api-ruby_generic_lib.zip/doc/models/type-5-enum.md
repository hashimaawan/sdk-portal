
# Type 5 Enum

Type of resource referenced

## Enumeration

`Type5Enum`

## Fields

| Name |
|  --- |
| `SERVER` |

## Example

```ruby
type5 = Type5Enum::SERVER
```

