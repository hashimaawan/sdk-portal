
# Type 12

The type of action to initiate for the Droplet.

## Enumeration

`Type12`

## Fields

| Name |
|  --- |
| `ENABLE_BACKUPS` |
| `DISABLE_BACKUPS` |
| `REBOOT` |
| `POWER_CYCLE` |
| `SHUTDOWN` |
| `POWER_OFF` |
| `POWER_ON` |
| `RESTORE` |
| `PASSWORD_RESET` |
| `RESIZE` |
| `REBUILD` |
| `RENAME` |
| `CHANGE_KERNEL` |
| `ENABLE_IPV6` |
| `SNAPSHOT` |

## Example

```php
use DigitalOceanApiLib\Models\Type12;

$type12 = Type12::REBOOT;
```

