
# Batch Get Prepared Statement Input

*This model accepts additional fields of type interface{}.*

## Structure

`BatchGetPreparedStatementInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PreparedStatementNames` | `[]string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    batchGetPreparedStatementInput := models.BatchGetPreparedStatementInput{
        PreparedStatementNames: []string{
            "PreparedStatementNames8",
            "PreparedStatementNames9",
            "PreparedStatementNames0",
        },
        WorkGroup:              "WorkGroup6",
        AdditionalProperties:   map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

