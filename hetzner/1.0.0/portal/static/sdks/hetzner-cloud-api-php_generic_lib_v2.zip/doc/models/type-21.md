
# Type 21

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```php
use HetznerCloudApiLib\Models\Type21;

$type21 = Type21::BACKUP;
```

