
# Oauth Scope Furkot Auth Implicit

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthImplicit`

## Fields

| Name | Description |
|  --- | --- |
| `Readtrips` | list users trips info |

## Example

```ts
import { OauthScopeFurkotAuthImplicit } from 'furkot-tripslib';

const oauthScopeFurkotAuthImplicit = OauthScopeFurkotAuthImplicit.Readtrips;
```

