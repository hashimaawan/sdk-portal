
# Server 9

Configuration for type server, required if type is `server`

## Structure

`Server9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    server9 := models.Server9{
        Id:                   216,
    }

}
```

