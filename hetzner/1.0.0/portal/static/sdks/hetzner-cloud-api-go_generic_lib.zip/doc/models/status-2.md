
# Status 2

Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates

*This model accepts additional fields of type interface{}.*

## Structure

`Status2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`models.Optional[models.Error2]`](../../doc/models/error-2.md) | Optional | If issuance or renewal reports `failed`, this property contains information about what happened |
| `Issuance` | [`*models.Issuance`](../../doc/models/issuance.md) | Optional | Status of the issuance process of the Certificate |
| `Renewal` | [`*models.Renewal`](../../doc/models/renewal.md) | Optional | Status of the renewal process of the Certificate. |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    status2 := models.Status2{
        Error:                 models.NewOptional[models.Error2](nil),
        Issuance:              models.ToPointer(models.Issuance_Completed),
        Renewal:               models.ToPointer(models.Renewal_Scheduled),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

