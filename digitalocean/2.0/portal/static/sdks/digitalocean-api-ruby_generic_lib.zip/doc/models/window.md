
# Window

## Enumeration

`Window`

## Fields

| Name |
|  --- |
| `UNSPECIFIED_WINDOW` |
| `FIVE_MINUTES` |
| `TEN_MINUTES` |
| `THIRTY_MINUTES` |
| `ONE_HOUR` |

## Example

```ruby
window = Window::ONE_HOUR
```

