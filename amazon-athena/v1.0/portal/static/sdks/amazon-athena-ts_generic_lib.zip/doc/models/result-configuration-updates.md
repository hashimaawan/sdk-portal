
# Result Configuration Updates

The information about the updates in the query results, such as output location and encryption configuration for the query results.

## Structure

`ResultConfigurationUpdates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `outputLocation` | `string \| undefined` | Optional | - |
| `removeOutputLocation` | `boolean \| undefined` | Optional | - |
| `encryptionConfiguration` | [`EncryptionConfiguration2 \| undefined`](../../doc/models/encryption-configuration-2.md) | Optional | - |
| `removeEncryptionConfiguration` | `boolean \| undefined` | Optional | - |
| `expectedBucketOwner` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` |
| `removeExpectedBucketOwner` | `boolean \| undefined` | Optional | - |
| `aclConfiguration` | [`AclConfiguration1 \| undefined`](../../doc/models/acl-configuration-1.md) | Optional | - |
| `removeAclConfiguration` | `boolean \| undefined` | Optional | - |

## Example

```ts
import {
  EncryptionOption1Enum,
  ResultConfigurationUpdates,
} from 'amazon-athenalib';

const resultConfigurationUpdates: ResultConfigurationUpdates = {
  outputLocation: 'OutputLocation6',
  removeOutputLocation: false,
  encryptionConfiguration: {
    encryptionOption: EncryptionOption1Enum.SSES3,
    kmsKey: 'KmsKey6',
  },
  removeEncryptionConfiguration: false,
  expectedBucketOwner: 'ExpectedBucketOwner6',
};
```

