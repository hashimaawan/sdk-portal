
# Load Balancers Actions Change Protection Request

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Load Balancer from being deleted |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
load_balancers_actions_change_protection_request = LoadBalancersActionsChangeProtectionRequest.new(
  delete: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

