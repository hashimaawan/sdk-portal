
# Create Certificate Response

*This model accepts additional fields of type array.*

## Structure

`CreateCertificateResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `action` | [`?NullableAction`](../../doc/models/nullable-action.md) | Optional | - | getAction(): ?NullableAction | setAction(?NullableAction action): void |
| `certificate` | [`Certificate`](../../doc/models/certificate.md) | Required | - | getCertificate(): Certificate | setCertificate(Certificate certificate): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\CreateCertificateResponseBuilder;
use HetznerCloudApiLib\Models\Builders\CertificateBuilder;
use HetznerCloudApiLib\Models\Builders\UsedByBuilder;
use HetznerCloudApiLib\ApiHelper;
use HetznerCloudApiLib\Models\Builders\Status2Builder;
use HetznerCloudApiLib\Models\Issuance;
use HetznerCloudApiLib\Models\Renewal;
use HetznerCloudApiLib\Models\Type;
use HetznerCloudApiLib\Models\Builders\NullableActionBuilder;
use HetznerCloudApiLib\Models\Builders\Resource2Builder;
use HetznerCloudApiLib\Models\Status;
use HetznerCloudApiLib\Models\Builders\ErrorBuilder;

$createCertificateResponse = CreateCertificateResponseBuilder::init(
    CertificateBuilder::init(
        '2016-01-30T23:55:00+00:00',
        [
            'example.com',
            'webmail.example.com',
            'www.example.com'
        ],
        42,
        [
            'key0' => 'labels8',
            'key1' => 'labels7',
            'key2' => 'labels6'
        ],
        'my-resource',
        [
            UsedByBuilder::init(
                4711,
                'load_balancer'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
        ->certificate('-----BEGIN CERTIFICATE-----
...')
        ->fingerprint('03:c7:55:9b:2a:d1:04:17:09:f6:d0:7f:18:34:63:d4:3e:5f')
        ->notValidAfter('2019-07-08T09:59:59+00:00')
        ->notValidBefore('2019-01-08T10:00:00+00:00')
        ->status(
            Status2Builder::init()
                ->error(
                    null
                )
                ->issuance(Issuance::COMPLETED)
                ->renewal(Renewal::FAILED)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->type(Type::UPLOADED)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->action(
        NullableActionBuilder::init(
            'command6',
            238,
            143.26,
            [
                Resource2Builder::init(
                    198,
                    'type0'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                Resource2Builder::init(
                    198,
                    'type0'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                Resource2Builder::init(
                    198,
                    'type0'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            ],
            'started8',
            Status::RUNNING
        )
            ->error(
                ErrorBuilder::init(
                    'code2',
                    'message4'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->finished('finished0')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

