
# Phase

## Enumeration

`Phase`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING_BUILD` |
| `BUILDING` |
| `PENDING_DEPLOY` |
| `DEPLOYING` |
| `ACTIVE` |
| `SUPERSEDED` |
| `ERROR` |
| `CANCELED` |

## Example

```ruby
phase = Phase::BUILDING
```

