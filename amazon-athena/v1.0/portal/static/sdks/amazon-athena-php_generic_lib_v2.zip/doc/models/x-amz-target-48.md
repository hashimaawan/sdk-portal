
# X Amz Target 48

## Enumeration

`XAmzTarget48`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTSESSION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget48;

$xAmzTarget48 = XAmzTarget48::ENUM_AMAZONATHENASTARTSESSION;
```

