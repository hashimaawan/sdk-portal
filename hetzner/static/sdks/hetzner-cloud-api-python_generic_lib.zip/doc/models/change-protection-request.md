
# Change Protection Request

## Structure

`ChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Optional | If true, prevents the Floating IP from being deleted |

## Example

```python
from hetznercloudapi.models.change_protection_request import ChangeProtectionRequest

change_protection_request = ChangeProtectionRequest(
    delete=True
)
```

