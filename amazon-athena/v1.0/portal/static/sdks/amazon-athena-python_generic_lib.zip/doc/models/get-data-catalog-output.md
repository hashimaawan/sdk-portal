
# Get Data Catalog Output

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data_catalog` | [`DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - |

## Example

```python
from amazonathena.models.data_catalog_2 import DataCatalog2
from amazonathena.models.data_catalog_type_1_enum import DataCatalogType1Enum
from amazonathena.models.get_data_catalog_output import GetDataCatalogOutput
from amazonathena.models.parameters import Parameters

get_data_catalog_output = GetDataCatalogOutput(
    data_catalog=DataCatalog2(
        name='Name4',
        mtype=DataCatalogType1Enum.GLUE,
        description='Description2',
        parameters=Parameters()
    )
)
```

