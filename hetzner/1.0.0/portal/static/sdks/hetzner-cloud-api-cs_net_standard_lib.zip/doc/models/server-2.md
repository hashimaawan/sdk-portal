
# Server 2

Configuration for type Server, required if type is `server`

## Structure

`Server2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Server2 server2 = new Server2
{
    Id = 162,
};
```

