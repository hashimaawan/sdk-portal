
# X Amz Target 33

## Enumeration

`XAmzTarget33`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistdatacatalogs` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget33 := models.XAmzTarget33_EnumAmazonathenalistdatacatalogs

}
```

