
# Ssh Keys Request 1

## Structure

`SshKeysRequest1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Labels` | `Object` | Optional | User-defined labels (key-value pairs) | Object getLabels() | setLabels(Object labels) |
| `Name` | `String` | Optional | New name Name to set | String getName() | setName(String name) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.SshKeysRequest1;
import java.io.IOException;

SshKeysRequest1 sshKeysRequest1 = new SshKeysRequest1.Builder()
    .labels(ApiHelper.deserialize("{\"labelkey\":\"value\"}"))
    .name("My ssh key")
    .build();
```

