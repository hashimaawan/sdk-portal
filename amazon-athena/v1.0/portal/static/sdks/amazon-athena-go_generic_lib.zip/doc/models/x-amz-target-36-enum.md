
# X Amz Target 36 Enum

## Enumeration

`XAmzTarget36Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTEXECUTORS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget36 := models.XAmzTarget36Enum_ENUMAMAZONATHENALISTEXECUTORS

}
```

