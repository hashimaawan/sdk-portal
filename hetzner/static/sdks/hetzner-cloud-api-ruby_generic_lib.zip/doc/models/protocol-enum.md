
# Protocol Enum

Type of traffic to allow

## Enumeration

`ProtocolEnum`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |
| `ESP` |
| `GRE` |

## Example

```ruby
protocol = ProtocolEnum::ESP
```

