
# Protocol 6

Type of the health check

## Enumeration

`Protocol6`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |

## Example

```php
use HetznerCloudApiLib\Models\Protocol6;

$protocol6 = Protocol6::TCP;
```

