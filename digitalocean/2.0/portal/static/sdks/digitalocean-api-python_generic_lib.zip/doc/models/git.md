
# Git

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Git`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `branch` | `str` | Optional | The name of the branch to use |
| `repo_clone_url` | `str` | Optional | The clone URL of the repo. Example: `https://github.com/digitalocean/sample-golang.git` |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.git import Git

git = Git(
    branch='main',
    repo_clone_url='https://github.com/digitalocean/sample-golang.git',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

