
# Change Protection Request 2

## Structure

`ChangeProtectionRequest2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `delete` | `?bool` | Optional | If true, prevents the Primary IP from being deleted | getDelete(): ?bool | setDelete(?bool delete): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ChangeProtectionRequest2Builder;

$changeProtectionRequest2 = ChangeProtectionRequest2Builder::init()
    ->delete(true)
    ->build();
```

