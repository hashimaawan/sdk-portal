
# Status 23

## Enumeration

`Status23`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |

## Example

```ts
import { Status23 } from 'hetzner-cloud-apilib';

const status23 = Status23.Available;
```

