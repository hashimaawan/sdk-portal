
# Batch Get Query Execution Input

Contains an array of query execution IDs.

## Structure

`BatchGetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `queryExecutionIds` | `string[]` | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getQueryExecutionIds(): array | setQueryExecutionIds(array queryExecutionIds): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\BatchGetQueryExecutionInputBuilder;

$batchGetQueryExecutionInput = BatchGetQueryExecutionInputBuilder::init(
    [
        'QueryExecutionIds7',
        'QueryExecutionIds8',
        'QueryExecutionIds9'
    ]
)->build();
```

