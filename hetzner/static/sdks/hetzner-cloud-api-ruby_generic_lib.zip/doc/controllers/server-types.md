# Server Types

```ruby
server_types_controller = client.server_types
```

## Class Name

`ServerTypesController`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```ruby
def get_all_server_types(name: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

[`ServerTypesResponse`](../../doc/models/server-types-response.md)

## Example Usage

```ruby
result = server_types_controller.get_all_server_types
puts result
```


# Get a Server Type

Gets a specific Server type object.

```ruby
def get_a_server_type(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of Server Type |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

[`ServerTypesResponse1`](../../doc/models/server-types-response-1.md)

## Example Usage

```ruby
id = 112

result = server_types_controller.get_a_server_type(id)
puts result
```

