
# Get Data Catalog Output

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DataCatalog` | [`DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - | DataCatalog2 getDataCatalog() | setDataCatalog(DataCatalog2 dataCatalog) |

## Example

```java
import com.amazonaws.useast1.athena.models.DataCatalog2;
import com.amazonaws.useast1.athena.models.DataCatalogType1Enum;
import com.amazonaws.useast1.athena.models.GetDataCatalogOutput;
import com.amazonaws.useast1.athena.models.Parameters;

GetDataCatalogOutput getDataCatalogOutput = new GetDataCatalogOutput.Builder()
    .dataCatalog(new DataCatalog2.Builder(
        "Name4",
        DataCatalogType1Enum.GLUE
    )
    .description("Description2")
    .parameters(new Parameters.Builder()
            .build())
    .build())
    .build();
```

