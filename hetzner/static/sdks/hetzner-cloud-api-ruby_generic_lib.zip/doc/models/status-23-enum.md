
# Status 23 Enum

## Enumeration

`Status23Enum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |

## Example

```ruby
status23 = Status23Enum::AVAILABLE
```

