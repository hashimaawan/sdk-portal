
# Volume

The cost of Volume per GB/month

*This model accepts additional fields of type Object.*

## Structure

`Volume`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PricePerGbMonth` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - | PricePerGbMonth getPricePerGbMonth() | setPricePerGbMonth(PricePerGbMonth pricePerGbMonth) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.PricePerGbMonth;
import cloud.hetzner.api.models.Volume;
import java.io.IOException;

Volume volume = new Volume.Builder(
    new PricePerGbMonth.Builder(
        "1.1900000000000000",
        "1.0000000000"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

