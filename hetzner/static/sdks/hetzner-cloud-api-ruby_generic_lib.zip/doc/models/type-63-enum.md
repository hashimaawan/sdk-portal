
# Type 63 Enum

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63Enum`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |
| `BACKUP` |

## Example

```ruby
type63 = Type63Enum::SNAPSHOT
```

