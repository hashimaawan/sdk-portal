
# Character Set

## Enumeration

`CharacterSet`

## Fields

| Name |
|  --- |
| `LETTERS` |
| `DIGITS` |
| `SYMBOLS` |

## Example

```php
use M1PasswordConnectLib\Models\CharacterSet;

$characterSet = CharacterSet::DIGITS;
```

