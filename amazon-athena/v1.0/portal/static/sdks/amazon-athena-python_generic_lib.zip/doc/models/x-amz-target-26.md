
# X Amz Target 26

## Enumeration

`XAmzTarget26`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSION` |

## Example

```python
from amazonathena.models.x_amz_target_26 import XAmzTarget26

x_amz_target_26 = XAmzTarget26.ENUM_AMAZONATHENAGETSESSION
```

