
# X Amz Target 43

## Enumeration

`XAmzTarget43`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListTableMetadata` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget43 xAmzTarget43 = XAmzTarget43.EnumAmazonAthenaListTableMetadata;
```

