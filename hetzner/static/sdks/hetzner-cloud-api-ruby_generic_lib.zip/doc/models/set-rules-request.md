
# Set Rules Request

## Structure

`SetRulesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rules` | [`Array[Rule]`](../../doc/models/rule.md) | Required | Array of rules<br><br>**Constraints**: *Maximum Items*: `50` |

## Example

```ruby
set_rules_request = SetRulesRequest.new(
  [
    Rule.new(
      DirectionEnum::ENUM_IN,
      ProtocolEnum::UDP,
      'description2',
      [
        '28.239.13.1/32',
        '28.239.14.0/24',
        'ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128'
      ],
      '80',
      [
        '28.239.13.1/32',
        '28.239.14.0/24',
        'ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128'
      ]
    )
  ]
)
```

