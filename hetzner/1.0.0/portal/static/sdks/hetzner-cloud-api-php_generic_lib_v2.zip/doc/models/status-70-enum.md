
# Status 70 Enum

## Enumeration

`Status70Enum`

## Fields

| Name |
|  --- |
| `INITIALIZING` |
| `STARTING` |
| `RUNNING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `REBUILDING` |
| `MIGRATING` |
| `UNKNOWN` |

## Example

```php
use HetznerCloudAPILib\Models\Status70Enum;

$status70 = Status70Enum::MIGRATING;
```

