
# Work Group State 2 Enum

The workgroup state that will be updated for the given workgroup.

## Enumeration

`WorkGroupState2Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    workGroupState2 := models.WorkGroupState2Enum_ENABLED

}
```

