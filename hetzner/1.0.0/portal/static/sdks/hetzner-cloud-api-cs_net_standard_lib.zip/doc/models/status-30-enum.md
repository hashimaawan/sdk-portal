
# Status 30 Enum

## Enumeration

`Status30Enum`

## Fields

| Name |
|  --- |
| `Healthy` |
| `Unhealthy` |
| `Unknown` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Status30Enum status30 = Status30Enum.Healthy;
```

