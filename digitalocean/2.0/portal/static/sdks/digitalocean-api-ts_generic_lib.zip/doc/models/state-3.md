
# State 3

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`State3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `previousOutage` | [`PreviousOutage \| undefined`](../../doc/models/previous-outage.md) | Optional | - |
| `regions` | [`Regions \| undefined`](../../doc/models/regions.md) | Optional | A map of region to regional state |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { State3, Status16 } from 'digitalocean-apilib';

const state3: State3 = {
  previousOutage: {
    durationSeconds: 16,
    endedAt: 'ended_at4',
    region: 'region8',
    startedAt: 'started_at4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  regions: {
    euWest: {
      status: Status16.Down,
      statusChangedAt: 'status_changed_at4',
      thirtyDayUptimePercentage: 227.78,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    usEast: {
      status: Status16.Down,
      statusChangedAt: 'status_changed_at4',
      thirtyDayUptimePercentage: 121.56,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

