
# Get Query Execution Input

## Structure

`GetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { GetQueryExecutionInput } from 'amazon-athenalib';

const getQueryExecutionInput: GetQueryExecutionInput = {
  queryExecutionId: 'QueryExecutionId8',
};
```

