
# Tag Resource Input

## Structure

`TagResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResourceARN` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `Tags` | [`List<Tag>`](../../doc/models/tag.md) | Required | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

TagResourceInput tagResourceInput = new TagResourceInput
{
    ResourceARN = "ResourceARN6",
    Tags = new List<Tag>
    {
        new Tag
        {
            Key = "Key0",
            MValue = "Value6",
        },
    },
};
```

