
# X Amz Target 51 Enum

## Enumeration

`XAmzTarget51Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATAGRESOURCE` |

## Example

```python
from amazonathena.models.x_amz_target_51_enum import XAmzTarget51Enum

x_amz_target_51 = XAmzTarget51Enum.ENUM_AMAZONATHENATAGRESOURCE
```

