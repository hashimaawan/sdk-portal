
# Statement Type

## Enumeration

`StatementType`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```php
use AmazonAthenaLib\Models\StatementType;

$statementType = StatementType::DDL;
```

