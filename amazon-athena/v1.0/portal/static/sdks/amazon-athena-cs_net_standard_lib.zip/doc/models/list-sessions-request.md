
# List Sessions Request

## Structure

`ListSessionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `StateFilter` | [`SessionState3Enum?`](../../doc/models/session-state-3-enum.md) | Optional | - |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `string` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ListSessionsRequest listSessionsRequest = new ListSessionsRequest
{
    WorkGroup = "WorkGroup8",
    StateFilter = SessionState3Enum.CREATING,
    MaxResults = 100,
    NextToken = "NextToken6",
};
```

