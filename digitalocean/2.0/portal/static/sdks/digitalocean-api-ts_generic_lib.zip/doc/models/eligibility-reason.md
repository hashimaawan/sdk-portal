
# Eligibility Reason

## Enumeration

`EligibilityReason`

## Fields

| Name |
|  --- |
| `OverRepositoryLimit` |
| `OverStorageLimit` |

## Example

```ts
import { EligibilityReason } from 'digitalocean-apilib';

const eligibilityReason = EligibilityReason.OverRepositoryLimit;
```

