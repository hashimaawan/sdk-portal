
# Get Work Group Input

*This model accepts additional fields of type Any.*

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `str` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.get_work_group_input import GetWorkGroupInput

get_work_group_input = GetWorkGroupInput(
    work_group='WorkGroup0',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

