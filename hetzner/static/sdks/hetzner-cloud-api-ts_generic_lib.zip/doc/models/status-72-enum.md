
# Status 72 Enum

Status of the Firewall on the Server

## Enumeration

`Status72Enum`

## Fields

| Name |
|  --- |
| `Applied` |
| `Pending` |

## Example

```ts
import { Status72Enum } from 'hetzner-cloud-apilib';

const status72 = Status72Enum.Applied;
```

