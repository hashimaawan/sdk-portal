
# Batch Get Named Query Output

## Structure

`BatchGetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_queries` | [`Array[NamedQuery]`](../../doc/models/named-query.md) | Optional | - |
| `unprocessed_named_query_ids` | [`Array[UnprocessedNamedQueryId]`](../../doc/models/unprocessed-named-query-id.md) | Optional | - |

## Example

```ruby
batch_get_named_query_output = BatchGetNamedQueryOutput.new(
  [
    NamedQuery.new(
      'Name2',
      'Database0',
      'QueryString4',
      'Description4',
      'NamedQueryId0',
      'WorkGroup4'
    ),
    NamedQuery.new(
      'Name2',
      'Database0',
      'QueryString4',
      'Description4',
      'NamedQueryId0',
      'WorkGroup4'
    ),
    NamedQuery.new(
      'Name2',
      'Database0',
      'QueryString4',
      'Description4',
      'NamedQueryId0',
      'WorkGroup4'
    )
  ],
  [
    UnprocessedNamedQueryId.new(
      'NamedQueryId4',
      'ErrorCode6',
      'ErrorMessage4'
    ),
    UnprocessedNamedQueryId.new(
      'NamedQueryId4',
      'ErrorCode6',
      'ErrorMessage4'
    )
  ]
)
```

