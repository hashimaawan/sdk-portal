
# Servers Actions Change Alias Ips Request

## Structure

`ServersActionsChangeAliasIpsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AliasIps` | `List<String>` | Required | New alias IPs to set for this Server | List<String> getAliasIps() | setAliasIps(List<String> aliasIps) |
| `Network` | `int` | Required | ID of an existing Network already attached to the Server | int getNetwork() | setNetwork(int network) |

## Example

```java
import cloud.hetzner.api.models.ServersActionsChangeAliasIpsRequest;
import java.util.Arrays;

ServersActionsChangeAliasIpsRequest serversActionsChangeAliasIpsRequest = new ServersActionsChangeAliasIpsRequest.Builder(
    Arrays.asList(
        "10.0.1.2"
    ),
    4711
)
.build();
```

