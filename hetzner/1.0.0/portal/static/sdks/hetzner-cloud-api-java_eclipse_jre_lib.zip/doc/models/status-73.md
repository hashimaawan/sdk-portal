
# Status 73

Status of the Server

## Enumeration

`Status73`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `INITIALIZING` |
| `STARTING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `MIGRATING` |
| `REBUILDING` |
| `UNKNOWN` |

## Example

```java
import cloud.hetzner.api.models.Status73;

Status73 status73 = Status73.STARTING;
```

