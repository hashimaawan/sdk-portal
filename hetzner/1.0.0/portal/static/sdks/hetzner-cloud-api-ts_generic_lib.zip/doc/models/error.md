
# Error

Error message for the Action if error occurred, otherwise null

*This model accepts additional fields of type unknown.*

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string` | Required | Fixed machine readable code |
| `message` | `string` | Required | Humanized error message |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Error } from 'hetzner-cloud-apilib';

const error: Error = {
  code: 'action_failed',
  message: 'Action failed',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

