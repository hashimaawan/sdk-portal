
# Get Query Execution Input

*This model accepts additional fields of type Object.*

## Structure

`GetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_query_execution_input = GetQueryExecutionInput.new(
  query_execution_id: 'QueryExecutionId6',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

