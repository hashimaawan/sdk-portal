
# Status 23 Enum

## Enumeration

`Status23Enum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |

## Example

```java
import cloud.hetzner.api.models.Status23Enum;

Status23Enum status23 = Status23Enum.AVAILABLE;
```

