
# V2 Account Keys Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AccountKeysResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ssh_key` | [`SshKey`](../../doc/models/ssh-key.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_account_keys_response1 = V2AccountKeysResponse1.new(
  ssh_key: SshKey.new(
    name: 'name2',
    public_key: 'public_key4',
    fingerprint: 'fingerprint8',
    id: 204,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

