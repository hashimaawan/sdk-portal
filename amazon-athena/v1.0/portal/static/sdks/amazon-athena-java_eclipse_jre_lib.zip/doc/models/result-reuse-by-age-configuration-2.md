
# Result Reuse by Age Configuration 2

## Structure

`ResultReuseByAgeConfiguration2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Enabled` | `boolean` | Required | - | boolean getEnabled() | setEnabled(boolean enabled) |
| `MaxAgeInMinutes` | `Integer` | Optional | **Constraints**: `>= 0`, `<= 10080` | Integer getMaxAgeInMinutes() | setMaxAgeInMinutes(Integer maxAgeInMinutes) |

## Example

```java
import com.amazonaws.useast1.athena.models.ResultReuseByAgeConfiguration2;

ResultReuseByAgeConfiguration2 resultReuseByAgeConfiguration2 = new ResultReuseByAgeConfiguration2.Builder(
    false
)
.maxAgeInMinutes(44)
.build();
```

