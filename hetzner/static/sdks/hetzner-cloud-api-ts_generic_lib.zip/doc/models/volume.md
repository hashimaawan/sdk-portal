
# Volume

The cost of Volume per GB/month

## Structure

`Volume`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pricePerGbMonth` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - |

## Example

```ts
import { Volume } from 'hetzner-cloud-apilib';

const volume: Volume = {
  pricePerGbMonth: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
  },
};
```

