
# X Amz Target 9

## Enumeration

`XAmzTarget9`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEDATACATALOG` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget9;

XAmzTarget9 xAmzTarget9 = XAmzTarget9.ENUM_AMAZONATHENADELETEDATACATALOG;
```

