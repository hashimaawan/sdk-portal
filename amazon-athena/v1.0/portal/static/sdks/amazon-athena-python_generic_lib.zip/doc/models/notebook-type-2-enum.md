
# Notebook Type 2 Enum

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```python
from amazonathena.models.notebook_type_2_enum import NotebookType2Enum

notebook_type_2 = NotebookType2Enum.IPYNB
```

