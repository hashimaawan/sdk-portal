
# Executor Type 2 Enum

The type of executor used for the application (<code>COORDINATOR</code>, <code>GATEWAY</code>, or <code>WORKER</code>).

## Enumeration

`ExecutorType2Enum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```java
import com.amazonaws.useast1.athena.models.ExecutorType2Enum;

ExecutorType2Enum executorType2 = ExecutorType2Enum.COORDINATOR;
```

