
# Query Execution Context 1

## Structure

`QueryExecutionContext1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Database` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `Catalog` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryExecutionContext1 queryExecutionContext1 = new QueryExecutionContext1
{
    Database = "Database0",
    Catalog = "Catalog6",
};
```

