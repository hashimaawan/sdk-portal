
# Column Nullable

## Enumeration

`ColumnNullable`

## Fields

| Name |
|  --- |
| `NotNull` |
| `Nullable` |
| `Unknown` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ColumnNullable columnNullable = ColumnNullable.NotNull;
```

