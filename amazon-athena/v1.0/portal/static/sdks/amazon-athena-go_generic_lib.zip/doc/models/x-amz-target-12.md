
# X Amz Target 12

## Enumeration

`XAmzTarget12`

## Fields

| Name |
|  --- |
| `EnumAmazonathenadeletepreparedstatement` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget12 := models.XAmzTarget12_EnumAmazonathenadeletepreparedstatement

}
```

