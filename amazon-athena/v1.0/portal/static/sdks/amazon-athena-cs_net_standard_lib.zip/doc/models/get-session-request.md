
# Get Session Request

## Structure

`GetSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetSessionRequest getSessionRequest = new GetSessionRequest
{
    SessionId = "SessionId2",
};
```

