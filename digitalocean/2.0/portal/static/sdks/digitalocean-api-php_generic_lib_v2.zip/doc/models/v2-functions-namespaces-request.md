
# V2 Functions Namespaces Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `label` | `string` | Required | The namespace's unique name. | getLabel(): string | setLabel(string label): void |
| `region` | `string` | Required | The [datacenter region](https://docs.digitalocean.com/products/platform/availability-matrix/#available-datacenters) in which to create the namespace. | getRegion(): string | setRegion(string region): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FunctionsNamespacesRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2FunctionsNamespacesRequest = V2FunctionsNamespacesRequestBuilder::init(
    'my namespace',
    'nyc1'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

