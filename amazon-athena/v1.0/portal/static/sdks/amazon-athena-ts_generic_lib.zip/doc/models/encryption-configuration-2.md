
# Encryption Configuration 2

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryptionOption` | [`EncryptionOption1Enum`](../../doc/models/encryption-option-1-enum.md) | Required | - |
| `kmsKey` | `string \| undefined` | Optional | - |

## Example

```ts
import {
  EncryptionConfiguration2,
  EncryptionOption1Enum,
} from 'amazon-athenalib';

const encryptionConfiguration2: EncryptionConfiguration2 = {
  encryptionOption: EncryptionOption1Enum.SSES3,
  kmsKey: 'KmsKey2',
};
```

