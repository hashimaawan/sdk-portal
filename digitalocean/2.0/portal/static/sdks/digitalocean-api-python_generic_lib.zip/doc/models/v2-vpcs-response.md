
# V2 Vpcs Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2VpcsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpcs` | [`List[Vpc]`](../../doc/models/vpc.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.v_2_vpcs_response import V2VpcsResponse
from digitaloceanapi.models.vpc import Vpc

v_2_vpcs_response = V2VpcsResponse(
    meta=Meta(
        total=1,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    vpcs=[
        Vpc(
            description='description8',
            name='name2',
            ip_range='ip_range4',
            region='region8',
            default=False,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Vpc(
            description='description8',
            name='name2',
            ip_range='ip_range4',
            region='region8',
            default=False,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    links=Links(
        pages=Pages(
            last='last6',
            next='next2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

