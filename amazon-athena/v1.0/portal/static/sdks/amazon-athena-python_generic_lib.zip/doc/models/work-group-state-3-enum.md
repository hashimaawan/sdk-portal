
# Work Group State 3 Enum

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```python
from amazonathena.models.work_group_state_3_enum import WorkGroupState3Enum

work_group_state_3 = WorkGroupState3Enum.ENABLED
```

