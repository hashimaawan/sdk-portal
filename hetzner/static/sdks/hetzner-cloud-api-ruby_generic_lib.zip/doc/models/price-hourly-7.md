
# Price Hourly 7

Hourly costs for a Primary IP type in this Location

## Structure

`PriceHourly7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `String` | Required | Price with VAT added |
| `net` | `String` | Required | Price without VAT |

## Example

```ruby
price_hourly7 = PriceHourly7.new(
  '1.1900000000000000',
  '1.0000000000'
)
```

