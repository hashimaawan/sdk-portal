
# Unprocessed Query Execution Id

Describes a query execution that failed to process.

*This model accepts additional fields of type object.*

## Structure

`UnprocessedQueryExecutionId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `ErrorCode` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ErrorMessage` | `string` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

UnprocessedQueryExecutionId unprocessedQueryExecutionId = new UnprocessedQueryExecutionId
{
    QueryExecutionId = "QueryExecutionId6",
    ErrorCode = "ErrorCode2",
    ErrorMessage = "ErrorMessage8",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

