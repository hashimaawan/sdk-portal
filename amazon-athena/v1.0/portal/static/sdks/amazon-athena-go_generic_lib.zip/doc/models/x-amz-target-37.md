
# X Amz Target 37

## Enumeration

`XAmzTarget37`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistnamedqueries` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget37 := models.XAmzTarget37_EnumAmazonathenalistnamedqueries

}
```

