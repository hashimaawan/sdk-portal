
# Type 51

Primary IP type

## Enumeration

`Type51`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```ruby
type51 = Type51::IPV4
```

