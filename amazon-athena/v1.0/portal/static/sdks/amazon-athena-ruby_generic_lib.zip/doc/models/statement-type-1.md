
# Statement Type 1

The type of query statement that was run. <code>DDL</code> indicates DDL query statements. <code>DML</code> indicates DML (Data Manipulation Language) query statements, such as <code>CREATE TABLE AS SELECT</code>. <code>UTILITY</code> indicates query statements other than DDL and DML, such as <code>SHOW CREATE TABLE</code>, or <code>DESCRIBE TABLE</code>.

## Enumeration

`StatementType1`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```ruby
statement_type1 = StatementType1::DDL
```

