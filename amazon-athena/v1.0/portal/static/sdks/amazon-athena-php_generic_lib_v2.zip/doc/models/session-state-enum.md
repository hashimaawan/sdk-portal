
# Session State Enum

## Enumeration

`SessionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```php
use AmazonAthenaLib\Models\SessionStateEnum;

$sessionState = SessionStateEnum::TERMINATING;
```

