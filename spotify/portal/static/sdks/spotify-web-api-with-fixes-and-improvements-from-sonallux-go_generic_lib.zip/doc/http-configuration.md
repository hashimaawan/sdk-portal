
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`spotifyWebApiWithFixesAndImprovementsFromSonalluxRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `spotifyWebApiWithFixesAndImprovementsFromSonallux.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux"
    "net/http"
)

func main() {
    httpConfiguration := spotifyWebApiWithFixesAndImprovementsFromSonallux.CreateHttpConfiguration(
        spotifyWebApiWithFixesAndImprovementsFromSonallux.WithTimeout(30),
        spotifyWebApiWithFixesAndImprovementsFromSonallux.WithTransport(http.DefaultTransport),
        spotifyWebApiWithFixesAndImprovementsFromSonallux.WithRetryConfiguration(spotifyWebApiWithFixesAndImprovementsFromSonallux.DefaultRetryConfiguration()),
    )
}
```

