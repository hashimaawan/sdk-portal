
# X Amz Target 37

## Enumeration

`XAmzTarget37`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNamedQueries` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget37 xAmzTarget37 = XAmzTarget37.EnumAmazonAthenaListNamedQueries;
```

