
# Column Nullable Enum

## Enumeration

`ColumnNullableEnum`

## Fields

| Name |
|  --- |
| `NOTNULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ColumnNullableEnum columnNullable = ColumnNullableEnum.NOTNULL;
```

