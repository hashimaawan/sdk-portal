
# X Amz Target 24

## Enumeration

`XAmzTarget24`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryResults` |

## Example

```ts
import { XAmzTarget24 } from 'amazon-athenalib';

const xAmzTarget24 = XAmzTarget24.EnumAmazonAthenaGetQueryResults;
```

