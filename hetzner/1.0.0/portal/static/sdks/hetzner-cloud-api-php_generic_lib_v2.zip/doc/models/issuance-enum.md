
# Issuance Enum

Status of the issuance process of the Certificate

## Enumeration

`IssuanceEnum`

## Fields

| Name |
|  --- |
| `PENDING` |
| `COMPLETED` |
| `FAILED` |

## Example

```php
use HetznerCloudAPILib\Models\IssuanceEnum;

$issuance = IssuanceEnum::FAILED;
```

