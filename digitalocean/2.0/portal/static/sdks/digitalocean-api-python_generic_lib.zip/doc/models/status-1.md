
# Status 1

The current status of the action. This can be "in-progress", "completed", or "errored".

## Enumeration

`Status1`

## Fields

| Name |
|  --- |
| `INPROGRESS` |
| `COMPLETED` |
| `ERRORED` |

## Example

```python
from digitaloceanapi.models.status_1 import Status1

status_1 = Status1.INPROGRESS
```

