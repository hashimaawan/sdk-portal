
# Data Catalog Type 2

The data catalog type.

## Enumeration

`DataCatalogType2`

## Fields

| Name |
|  --- |
| `Lambda` |
| `Glue` |
| `Hive` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    dataCatalogType2 := models.DataCatalogType2_Lambda

}
```

