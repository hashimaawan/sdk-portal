
# Sort Enum

## Enumeration

`SortEnum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `NAME` |
| `ENUM_NAMEASC` |
| `ENUM_NAMEDESC` |
| `CREATED` |
| `ENUM_CREATEDASC` |
| `ENUM_CREATEDDESC` |

## Example

```ruby
sort = SortEnum::ENUM_IDASC
```

