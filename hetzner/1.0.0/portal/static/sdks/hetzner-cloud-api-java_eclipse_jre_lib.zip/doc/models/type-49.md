
# Type 49

The type of the Primary IP

## Enumeration

`Type49`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```java
import cloud.hetzner.api.models.Type49;

Type49 type49 = Type49.IPV4;
```

