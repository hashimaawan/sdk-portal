
# Query Execution State

## Enumeration

`QueryExecutionState`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```ruby
query_execution_state = QueryExecutionState::SUCCEEDED
```

