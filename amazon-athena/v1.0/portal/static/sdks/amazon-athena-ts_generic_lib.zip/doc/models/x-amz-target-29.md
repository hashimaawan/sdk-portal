
# X Amz Target 29

## Enumeration

`XAmzTarget29`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetWorkGroup` |

## Example

```ts
import { XAmzTarget29 } from 'amazon-athenalib';

const xAmzTarget29 = XAmzTarget29.EnumAmazonAthenaGetWorkGroup;
```

