
# X Amz Target 14 Enum

## Enumeration

`XAmzTarget14Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaExportNotebook` |

## Example

```ts
import { XAmzTarget14Enum } from 'amazon-athenalib';

const xAmzTarget14 = XAmzTarget14Enum.EnumAmazonAthenaExportNotebook;
```

