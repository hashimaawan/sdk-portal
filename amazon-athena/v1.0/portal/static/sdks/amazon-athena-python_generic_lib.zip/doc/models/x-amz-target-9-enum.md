
# X Amz Target 9 Enum

## Enumeration

`XAmzTarget9Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEDATACATALOG` |

## Example

```python
from amazonathena.models.x_amz_target_9_enum import XAmzTarget9Enum

x_amz_target_9 = XAmzTarget9Enum.ENUM_AMAZONATHENADELETEDATACATALOG
```

