
# Type 24

Destination Image type to convert to

## Enumeration

`Type24`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |

## Example

```java
import cloud.hetzner.api.models.Type24;

Type24 type24 = Type24.SNAPSHOT;
```

