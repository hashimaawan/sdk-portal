
# V2 Kubernetes Clusters Node Pools Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersNodePoolsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `node_pools` | [`List[NodePool]`](../../doc/models/node-pool.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.node_pool import NodePool
from digitaloceanapi.models.v_2_kubernetes_clusters_node_pools_response import V2KubernetesClustersNodePoolsResponse

v_2_kubernetes_clusters_node_pools_response = V2KubernetesClustersNodePoolsResponse(
    node_pools=[
        NodePool(
            size='size6',
            count=206,
            name='name4',
            auto_scale=False,
            id='000013be-0000-0000-0000-000000000000',
            labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
            max_nodes=118,
            min_nodes=54,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        NodePool(
            size='size6',
            count=206,
            name='name4',
            auto_scale=False,
            id='000013be-0000-0000-0000-000000000000',
            labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
            max_nodes=118,
            min_nodes=54,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

