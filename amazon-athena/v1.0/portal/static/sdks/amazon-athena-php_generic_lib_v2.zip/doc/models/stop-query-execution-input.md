
# Stop Query Execution Input

## Structure

`StopQueryExecutionInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `queryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getQueryExecutionId(): string | setQueryExecutionId(string queryExecutionId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\StopQueryExecutionInputBuilder;

$stopQueryExecutionInput = StopQueryExecutionInputBuilder::init(
    'QueryExecutionId4'
)->build();
```

