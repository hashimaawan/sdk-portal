
# Work Group State Enum

## Enumeration

`WorkGroupStateEnum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```python
from amazonathena.models.work_group_state_enum import WorkGroupStateEnum

work_group_state = WorkGroupStateEnum.ENABLED
```

