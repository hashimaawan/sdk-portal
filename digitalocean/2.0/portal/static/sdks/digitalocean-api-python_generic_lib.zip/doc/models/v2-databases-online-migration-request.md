
# V2 Databases Online Migration Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DatabasesOnlineMigrationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `disable_ssl` | `bool` | Optional | Enables SSL encryption when connecting to the source database. |
| `source` | [`Source`](../../doc/models/source.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.source import Source
from digitaloceanapi.models.v_2_databases_online_migration_request import V2DatabasesOnlineMigrationRequest

v_2_databases_online_migration_request = V2DatabasesOnlineMigrationRequest(
    disable_ssl=False,
    source=Source(
        database='database4',
        host='host4',
        password='password8',
        port=180,
        ssl=False,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

