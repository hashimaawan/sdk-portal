
# X Amz Target 21

## Enumeration

`XAmzTarget21`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetnotebookmetadata` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget21 := models.XAmzTarget21_EnumAmazonathenagetnotebookmetadata

}
```

