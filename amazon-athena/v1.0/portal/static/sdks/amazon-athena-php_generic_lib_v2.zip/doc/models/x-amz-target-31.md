
# X Amz Target 31

## Enumeration

`XAmzTarget31`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget31;

$xAmzTarget31 = XAmzTarget31::ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES;
```

