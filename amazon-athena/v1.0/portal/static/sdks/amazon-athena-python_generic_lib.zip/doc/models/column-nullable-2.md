
# Column Nullable 2

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```python
from amazonathena.models.column_nullable_2 import ColumnNullable2

column_nullable_2 = ColumnNullable2.NOT_NULL
```

