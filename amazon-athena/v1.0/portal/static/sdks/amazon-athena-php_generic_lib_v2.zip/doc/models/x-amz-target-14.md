
# X Amz Target 14

## Enumeration

`XAmzTarget14`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAEXPORTNOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget14;

$xAmzTarget14 = XAmzTarget14::ENUM_AMAZONATHENAEXPORTNOTEBOOK;
```

