# Reserved IP Actions

```python
reserved_ip_actions_api = client.reserved_ip_actions
```

## Class Name

`ReservedIpActionsApi`

## Methods

* [Reserved I Ps Actions List](../../doc/controllers/reserved-ip-actions.md#reserved-i-ps-actions-list)
* [Reserved I Ps Actions Post](../../doc/controllers/reserved-ip-actions.md#reserved-i-ps-actions-post)
* [Reserved I Ps Actions Get](../../doc/controllers/reserved-ip-actions.md#reserved-i-ps-actions-get)


# Reserved I Ps Actions List

To retrieve all actions that have been executed on a reserved IP, send a GET request to `/v2/reserved_ips/$RESERVED_IP/actions`.

```python
def reserved_i_ps_actions_list(self,
                              reserved_ip)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reserved_ip` | `str` | Template, Required | A reserved IP address. |

## Response Type

**200**: The results will be returned as a JSON object with an `actions` key. This will be set to an array filled with action objects containing the standard reserved IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ReservedIpsActionsResponse`](../../doc/models/v2-reserved-ips-actions-response.md).

## Example Usage

```python
reserved_ip = '45.55.96.47'

result = reserved_ip_actions_api.reserved_i_ps_actions_list(reserved_ip)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Reserved I Ps Actions Post

To initiate an action on a reserved IP send a POST request to
`/v2/reserved_ips/$RESERVED_IP/actions`. In the JSON body to the request,
set the `type` attribute to on of the supported action types:

| Action     | Details
|------------|--------
| `assign`   | Assigns a reserved IP to a Droplet
| `unassign` | Unassign a reserved IP from a Droplet

```python
def reserved_i_ps_actions_post(self,
                              reserved_ip,
                              body=None)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reserved_ip` | `str` | Template, Required | A reserved IP address. |
| `body` | [BaseType](../../doc/models/base-type.md) \| [V2 Reserved Ips Actions Request](../../doc/models/v2-reserved-ips-actions-request.md) \| None | Body, Optional | This is a container for any-of cases. |

## Response Type

**201**: The response will be an object with a key called `action`. The value of this will be an object that contains the standard reserved IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ReservedIpsActionsResponse1`](../../doc/models/v2-reserved-ips-actions-response-1.md).

## Example Usage

```python
reserved_ip = '45.55.96.47'

body = V2ReservedIpsActionsRequest(
    droplet_id=758604968,
    mtype='V2 Reserved Ips Actions Request'
)

result = reserved_ip_actions_api.reserved_i_ps_actions_post(
    reserved_ip,
    body=body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Reserved I Ps Actions Get

To retrieve the status of a reserved IP action, send a GET request to `/v2/reserved_ips/$RESERVED_IP/actions/$ACTION_ID`.

```python
def reserved_i_ps_actions_get(self,
                             reserved_ip,
                             action_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reserved_ip` | `str` | Template, Required | A reserved IP address. |
| `action_id` | `int` | Template, Required | A unique numeric ID that can be used to identify and reference an action.<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be an object with a key called `action`. The value of this will be an object that contains the standard reserved IP action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ReservedIpsActionsResponse1`](../../doc/models/v2-reserved-ips-actions-response-1.md).

## Example Usage

```python
reserved_ip = '45.55.96.47'

action_id = 36804636

result = reserved_ip_actions_api.reserved_i_ps_actions_get(
    reserved_ip,
    action_id
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

