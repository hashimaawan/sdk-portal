
# X Amz Target 41 Enum

## Enumeration

`XAmzTarget41Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListQueryExecutions` |

## Example

```ts
import { XAmzTarget41Enum } from 'amazon-athenalib';

const xAmzTarget41 = XAmzTarget41Enum.EnumAmazonAthenaListQueryExecutions;
```

