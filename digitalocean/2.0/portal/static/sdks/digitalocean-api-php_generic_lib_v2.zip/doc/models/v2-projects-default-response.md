
# V2 Projects Default Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2ProjectsDefaultResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `project` | [`?Project`](../../doc/models/project.md) | Optional | - | getProject(): ?Project | setProject(?Project project): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2ProjectsDefaultResponseBuilder;
use DigitalOceanApiLib\Models\Builders\ProjectBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\Models\Environment;
use DigitalOceanApiLib\ApiHelper;

$v2ProjectsDefaultResponse = V2ProjectsDefaultResponseBuilder::init()
    ->project(
        ProjectBuilder::init()
            ->createdAt(DateTimeHelper::fromRfc3339DateTime('2017-10-19T21:44:20Z'))
            ->description('Default project')
            ->environment(Environment::DEVELOPMENT)
            ->id('addb4547-6bab-419a-8542-76263a033cf6')
            ->name('Default')
            ->ownerId(258992)
            ->ownerUuid('99525febec065ca37b2ffe4f852fd2b2581895e7')
            ->purpose('Just trying out DigitalOcean')
            ->updatedAt(DateTimeHelper::fromRfc3339DateTime('2019-11-05T18:50:03Z'))
            ->isDefault(true)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

