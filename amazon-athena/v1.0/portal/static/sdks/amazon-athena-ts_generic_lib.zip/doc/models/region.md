
# Region

## Enumeration

`Region`

## Fields

| Name |
|  --- |
| `Useast1` |
| `Useast2` |
| `Uswest1` |
| `Uswest2` |
| `Usgovwest1` |
| `Usgoveast1` |
| `Cacentral1` |
| `Eunorth1` |
| `Euwest1` |
| `Euwest2` |
| `Euwest3` |
| `Eucentral1` |
| `Eusouth1` |
| `Afsouth1` |
| `Apnortheast1` |
| `Apnortheast2` |
| `Apnortheast3` |
| `Apsoutheast1` |
| `Apsoutheast2` |
| `Apeast1` |
| `Apsouth1` |
| `Saeast1` |
| `Mesouth1` |

## Example

```ts
import { Region } from 'amazon-athenalib';

const region = Region.Euwest3;
```

