
# Notebook Type 1 Enum

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```php
use AmazonAthenaLib\Models\NotebookType1Enum;

$notebookType1 = NotebookType1Enum::IPYNB;
```

