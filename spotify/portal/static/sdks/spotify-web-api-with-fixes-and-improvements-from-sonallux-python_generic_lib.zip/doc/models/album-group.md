
# Album Group

This field describes the relationship between the artist and the album.

## Enumeration

`AlbumGroup`

## Fields

| Name |
|  --- |
| `ALBUM` |
| `SINGLE` |
| `COMPILATION` |
| `APPEARS_ON` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.album_group import AlbumGroup

album_group = AlbumGroup.ALBUM
```

