
# Type

The object type.

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `ARTIST` |

## Example

```php
use SpotifyWebApiWithFixesAndImprovementsFromSonalluxLib\Models\Type;

$type = Type::ARTIST;
```

