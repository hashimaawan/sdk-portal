
# Create Placement Group Request

## Structure

`CreatePlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Required | Name of the PlacementGroup |
| `type` | `String` | Required, Constant | Define the Placement Group Type.<br><br>**Value**: `'spread'` |

## Example

```ruby
create_placement_group_request = CreatePlacementGroupRequest.new(
  'my Placement Group',
  'spread',
  { 'key1' => 'val1', 'key2' => 'val2' }
)
```

