
# Calculation Result

Contains information about an application-specific calculation result.

## Structure

`CalculationResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StdOutS3Uri` | `string` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` |
| `StdErrorS3Uri` | `string` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` |
| `ResultS3Uri` | `string` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` |
| `ResultType` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `\w+\/[-+.\w]+` |

## Example

```csharp
using AmazonAthena.Standard.Models;

CalculationResult calculationResult = new CalculationResult
{
    StdOutS3Uri = "StdOutS3Uri4",
    StdErrorS3Uri = "StdErrorS3Uri6",
    ResultS3Uri = "ResultS3Uri0",
    ResultType = "ResultType2",
};
```

