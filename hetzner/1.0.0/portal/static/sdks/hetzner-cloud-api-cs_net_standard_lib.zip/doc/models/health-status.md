
# Health Status

*This model accepts additional fields of type object.*

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ListenPort` | `int?` | Optional | - |
| `Status` | [`Status30?`](../../doc/models/status-30.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

HealthStatus healthStatus = new HealthStatus
{
    ListenPort = 443,
    Status = Status30.Healthy,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

