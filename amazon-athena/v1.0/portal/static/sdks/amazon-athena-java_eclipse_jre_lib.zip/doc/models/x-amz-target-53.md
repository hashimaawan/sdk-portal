
# X Amz Target 53

## Enumeration

`XAmzTarget53`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUNTAGRESOURCE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget53;

XAmzTarget53 xAmzTarget53 = XAmzTarget53.ENUM_AMAZONATHENAUNTAGRESOURCE;
```

