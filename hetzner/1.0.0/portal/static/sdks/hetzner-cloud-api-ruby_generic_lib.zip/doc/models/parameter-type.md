
# Parameter Type

## Enumeration

`ParameterType`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```ruby
parameter_type = ParameterType::UPLOADED
```

