
# Sort 2 Enum

## Enumeration

`Sort2Enum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUMIDASC` |
| `ENUMIDDESC` |
| `CREATED` |
| `ENUMCREATEDASC` |
| `ENUMCREATEDDESC` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    sort2 := models.Sort2Enum_ENUMCREATEDASC

}
```

