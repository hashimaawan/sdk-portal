
# V2 Volumes Snapshots Response 1

*This model accepts additional fields of type Object.*

## Structure

`V2VolumesSnapshotsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Snapshots` | [`List<Snapshot>`](../../doc/models/snapshot.md) | Optional | - | List<Snapshot> getSnapshots() | setSnapshots(List<Snapshot> snapshots) |
| `Links` | [`Links`](../../doc/models/links.md) | Optional | - | Links getLinks() | setLinks(Links links) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Required | - | Meta getMeta() | setMeta(Meta meta) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.DateTimeHelper;
import com.digitalocean.api.models.Links;
import com.digitalocean.api.models.Meta;
import com.digitalocean.api.models.Pages;
import com.digitalocean.api.models.ResourceType1;
import com.digitalocean.api.models.Snapshot;
import com.digitalocean.api.models.V2VolumesSnapshotsResponse1;
import com.digitalocean.api.models.containers.LinksPages;
import java.io.IOException;
import java.util.Arrays;

V2VolumesSnapshotsResponse1 v2VolumesSnapshotsResponse1 = new V2VolumesSnapshotsResponse1.Builder(
    new Meta.Builder(
        1
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.snapshots(Arrays.asList(
        new Snapshot.Builder(
            "8eb4d51a-873f-11e6-96bf-000f53315a41",
            DateTimeHelper.fromRfc8601DateTime("2020-09-30T18:56:12Z"),
            10,
            "big-data-snapshot1475261752",
            Arrays.asList(
                "nyc1"
            ),
            0D,
            "82a48a18-873f-11e6-96bf-000f53315a41",
            ResourceType1.VOLUME,
            null
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ))
.links(new Links.Builder()
        .pages(LinksPages.fromPages(
            new Pages.Builder()
                .last("last6")
                .next("next2")
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

