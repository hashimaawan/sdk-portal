
# Renewal Enum

Status of the renewal process of the Certificate.

## Enumeration

`RenewalEnum`

## Fields

| Name |
|  --- |
| `SCHEDULED` |
| `PENDING` |
| `FAILED` |
| `UNAVAILABLE` |

## Example

```ruby
renewal = RenewalEnum::FAILED
```

