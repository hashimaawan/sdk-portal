
# X Amz Target 19 Enum

## Enumeration

`XAmzTarget19Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATABASE` |

## Example

```python
from amazonathena.models.x_amz_target_19_enum import XAmzTarget19Enum

x_amz_target_19 = XAmzTarget19Enum.ENUM_AMAZONATHENAGETDATABASE
```

