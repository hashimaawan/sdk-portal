
# Query Runtime Statistics Timeline

Timeline statistics such as query queue time, planning time, execution time, service processing time, and total execution time.

## Structure

`QueryRuntimeStatisticsTimeline`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryQueueTimeInMillis` | `int?` | Optional | - |
| `QueryPlanningTimeInMillis` | `int?` | Optional | - |
| `EngineExecutionTimeInMillis` | `int?` | Optional | - |
| `ServiceProcessingTimeInMillis` | `int?` | Optional | - |
| `TotalExecutionTimeInMillis` | `int?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryRuntimeStatisticsTimeline queryRuntimeStatisticsTimeline = new QueryRuntimeStatisticsTimeline
{
    QueryQueueTimeInMillis = 122,
    QueryPlanningTimeInMillis = 48,
    EngineExecutionTimeInMillis = 78,
    ServiceProcessingTimeInMillis = 96,
    TotalExecutionTimeInMillis = 140,
};
```

