
# Get Calculation Execution Request

## Structure

`GetCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetCalculationExecutionRequest getCalculationExecutionRequest = new GetCalculationExecutionRequest
{
    CalculationExecutionId = "CalculationExecutionId2",
};
```

