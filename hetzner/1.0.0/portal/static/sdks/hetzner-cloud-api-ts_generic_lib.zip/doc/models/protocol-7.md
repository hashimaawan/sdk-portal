
# Protocol 7

Protocol of the Load Balancer

## Enumeration

`Protocol7`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |
| `Https` |

## Example

```ts
import { Protocol7 } from 'hetzner-cloud-apilib';

const protocol7 = Protocol7.Http;
```

