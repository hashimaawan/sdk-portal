
# Git

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Git`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `branch` | `String` | Optional | The name of the branch to use |
| `repo_clone_url` | `String` | Optional | The clone URL of the repo. Example: `https://github.com/digitalocean/sample-golang.git` |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
git = Git.new(
  branch: 'main',
  repo_clone_url: 'https://github.com/digitalocean/sample-golang.git',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

