
# Remove from Resources Request

## Structure

`RemoveFromResourcesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `removeFrom` | [`FirewallRemoveFromResources[]`](../../doc/models/firewall-remove-from-resources.md) | Required | Resources the Firewall should be removed from | getRemoveFrom(): array | setRemoveFrom(array removeFrom): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\RemoveFromResourcesRequestBuilder;
use HetznerCloudAPILib\Models\Builders\FirewallRemoveFromResourcesBuilder;
use HetznerCloudAPILib\Models\Builders\LabelSelector5Builder;
use HetznerCloudAPILib\Models\Builders\Server9Builder;
use HetznerCloudAPILib\Models\Type7Enum;

$removeFromResourcesRequest = RemoveFromResourcesRequestBuilder::init(
    [
        FirewallRemoveFromResourcesBuilder::init()
            ->labelSelector(
                LabelSelector5Builder::init(
                    'selector8'
                )->build()
            )
            ->server(
                Server9Builder::init(
                    14
                )->build()
            )
            ->type(Type7Enum::SERVER)
            ->build()
    ]
)->build();
```

