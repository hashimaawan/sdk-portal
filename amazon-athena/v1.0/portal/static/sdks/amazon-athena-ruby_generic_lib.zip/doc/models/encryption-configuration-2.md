
# Encryption Configuration 2

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryption_option` | [`EncryptionOption1Enum`](../../doc/models/encryption-option-1-enum.md) | Required | - |
| `kms_key` | `String` | Optional | - |

## Example

```ruby
encryption_configuration2 = EncryptionConfiguration2.new(
  EncryptionOption1Enum::SSE_KMS,
  'KmsKey2'
)
```

