
# X Amz Target 29

## Enumeration

`XAmzTarget29`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETWORKGROUP` |

## Example

```ruby
x_amz_target29 = XAmzTarget29::ENUM_AMAZONATHENAGETWORKGROUP
```

