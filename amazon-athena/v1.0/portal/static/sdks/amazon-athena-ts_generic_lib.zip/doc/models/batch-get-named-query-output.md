
# Batch Get Named Query Output

## Structure

`BatchGetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namedQueries` | [`NamedQuery[] \| undefined`](../../doc/models/named-query.md) | Optional | - |
| `unprocessedNamedQueryIds` | [`UnprocessedNamedQueryId[] \| undefined`](../../doc/models/unprocessed-named-query-id.md) | Optional | - |

## Example

```ts
import { BatchGetNamedQueryOutput } from 'amazon-athenalib';

const batchGetNamedQueryOutput: BatchGetNamedQueryOutput = {
  namedQueries: [
    {
      name: 'Name2',
      database: 'Database0',
      queryString: 'QueryString4',
      description: 'Description4',
      namedQueryId: 'NamedQueryId0',
      workGroup: 'WorkGroup4',
    },
    {
      name: 'Name2',
      database: 'Database0',
      queryString: 'QueryString4',
      description: 'Description4',
      namedQueryId: 'NamedQueryId0',
      workGroup: 'WorkGroup4',
    },
    {
      name: 'Name2',
      database: 'Database0',
      queryString: 'QueryString4',
      description: 'Description4',
      namedQueryId: 'NamedQueryId0',
      workGroup: 'WorkGroup4',
    }
  ],
  unprocessedNamedQueryIds: [
    {
      namedQueryId: 'NamedQueryId4',
      errorCode: 'ErrorCode6',
      errorMessage: 'ErrorMessage4',
    },
    {
      namedQueryId: 'NamedQueryId4',
      errorCode: 'ErrorCode6',
      errorMessage: 'ErrorMessage4',
    }
  ],
};
```

