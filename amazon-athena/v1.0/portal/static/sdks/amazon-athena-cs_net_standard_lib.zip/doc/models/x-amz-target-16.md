
# X Amz Target 16

## Enumeration

`XAmzTarget16`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecutionCode` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget16 xAmzTarget16 = XAmzTarget16.EnumAmazonAthenaGetCalculationExecutionCode;
```

