
# External Url Object

*This model accepts additional fields of type object.*

## Structure

`ExternalUrlObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Spotify` | `string` | Optional | The [Spotify URL](/documentation/web-api/concepts/spotify-uris-ids) for the object. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Utilities;

ExternalUrlObject externalUrlObject = new ExternalUrlObject
{
    Spotify = "spotify0",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

