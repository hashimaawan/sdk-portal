
# Status

This value is one of "active", "warning" or "locked".

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `WARNING` |
| `LOCKED` |

## Example

```php
use DigitalOceanApiLib\Models\Status;

$status = Status::LOCKED;
```

