
# Images

An object containing data for various available formats and sizes of this GIF.

*This model accepts additional fields of type Any.*

## Structure

`Images`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `downsized` | [`Image`](../../doc/models/image.md) | Optional | - |
| `downsized_large` | [`Image`](../../doc/models/image.md) | Optional | - |
| `downsized_medium` | [`Image`](../../doc/models/image.md) | Optional | - |
| `downsized_small` | [`Image`](../../doc/models/image.md) | Optional | - |
| `downsized_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height_downsampled` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height_small` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height_small_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_height_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width_downsampled` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width_small` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width_small_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `fixed_width_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `looping` | [`Image`](../../doc/models/image.md) | Optional | - |
| `original` | [`Image`](../../doc/models/image.md) | Optional | - |
| `original_still` | [`Image`](../../doc/models/image.md) | Optional | - |
| `preview` | [`Image`](../../doc/models/image.md) | Optional | - |
| `preview_gif` | [`Image`](../../doc/models/image.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from giphyapi.models.image import Image
from giphyapi.models.images import Images

images = Images(
    downsized=Image(
        frames='frames0',
        height='height8',
        mp_4='mp40',
        mp_4_size='mp4_size2',
        size='size2',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    downsized_large=Image(
        frames='frames6',
        height='height4',
        mp_4='mp46',
        mp_4_size='mp4_size8',
        size='size8',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    downsized_medium=Image(
        frames='frames2',
        height='height0',
        mp_4='mp42',
        mp_4_size='mp4_size4',
        size='size4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    downsized_small=Image(
        frames='frames0',
        height='height8',
        mp_4='mp40',
        mp_4_size='mp4_size2',
        size='size2',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    downsized_still=Image(
        frames='frames4',
        height='height4',
        mp_4='mp46',
        mp_4_size='mp4_size8',
        size='size2',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

