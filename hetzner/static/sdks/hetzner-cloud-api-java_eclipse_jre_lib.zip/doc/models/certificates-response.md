
# Certificates Response

## Structure

`CertificatesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Certificates` | [`List<Certificate>`](../../doc/models/certificate.md) | Required | - | List<Certificate> getCertificates() | setCertificates(List<Certificate> certificates) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Optional | - | Meta getMeta() | setMeta(Meta meta) |

## Example

```java
import cloud.hetzner.api.models.Certificate;
import cloud.hetzner.api.models.CertificatesResponse;
import cloud.hetzner.api.models.IssuanceEnum;
import cloud.hetzner.api.models.Meta;
import cloud.hetzner.api.models.Pagination;
import cloud.hetzner.api.models.RenewalEnum;
import cloud.hetzner.api.models.Status2;
import cloud.hetzner.api.models.TypeEnum;
import cloud.hetzner.api.models.UsedBy;
import java.util.Arrays;
import java.util.LinkedHashMap;

CertificatesResponse certificatesResponse = new CertificatesResponse.Builder(
    Arrays.asList(
        new Certificate.Builder(
            "-----BEGIN CERTIFICATE-----\n...",
            "2016-01-30T23:55:00+00:00",
            Arrays.asList(
                "example.com",
                "webmail.example.com",
                "www.example.com"
            ),
            "03:c7:55:9b:2a:d1:04:17:09:f6:d0:7f:18:34:63:d4:3e:5f",
            42,
            new LinkedHashMap<String, String>() {{
                put("key0", "labels2");
                put("key1", "labels1");
                put("key2", "labels0");
            }},
            "my-resource",
            "2019-07-08T09:59:59+00:00",
            "2019-01-08T10:00:00+00:00",
            Arrays.asList(
                new UsedBy.Builder(
                    4711,
                    "load_balancer"
                )
                .build()
            )
        )
        .status(new Status2.Builder()
                .error(null)
                .issuance(IssuanceEnum.COMPLETED)
                .renewal(RenewalEnum.FAILED)
                .build())
        .type(TypeEnum.UPLOADED)
        .build()
    )
)
.meta(new Meta.Builder(
        new Pagination.Builder(
            77.7D,
            209.18D,
            17.58D,
            13.34D,
            50.02D,
            206.64D
        )
        .build()
    )
    .build())
.build();
```

