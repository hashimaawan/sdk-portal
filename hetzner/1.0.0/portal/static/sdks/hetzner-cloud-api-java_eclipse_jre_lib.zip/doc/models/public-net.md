
# Public Net

Public network information

*This model accepts additional fields of type Object.*

## Structure

`PublicNet`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Enabled` | `boolean` | Required | Public Interface enabled or not | boolean getEnabled() | setEnabled(boolean enabled) |
| `Ipv4` | [`Ipv4`](../../doc/models/ipv-4.md) | Required | IP address (v4) | Ipv4 getIpv4() | setIpv4(Ipv4 ipv4) |
| `Ipv6` | [`Ipv6`](../../doc/models/ipv-6.md) | Required | IP address (v6) | Ipv6 getIpv6() | setIpv6(Ipv6 ipv6) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.Ipv4;
import cloud.hetzner.api.models.Ipv6;
import cloud.hetzner.api.models.PublicNet;
import java.io.IOException;

PublicNet publicNet = new PublicNet.Builder(
    false,
    new Ipv4.Builder()
        .dnsPtr("lb1.example.com")
        .ip("1.2.3.4")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
    new Ipv6.Builder()
        .dnsPtr("lb1.example.com")
        .ip("2001:db8::1")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

