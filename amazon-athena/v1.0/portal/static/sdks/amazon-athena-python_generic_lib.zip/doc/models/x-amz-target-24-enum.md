
# X Amz Target 24 Enum

## Enumeration

`XAmzTarget24Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRESULTS` |

## Example

```python
from amazonathena.models.x_amz_target_24_enum import XAmzTarget24Enum

x_amz_target_24 = XAmzTarget24Enum.ENUM_AMAZONATHENAGETQUERYRESULTS
```

