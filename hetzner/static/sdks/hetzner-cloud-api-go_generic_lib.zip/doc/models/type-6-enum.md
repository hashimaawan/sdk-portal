
# Type 6 Enum

Type of resource referenced

## Enumeration

`Type6Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABELSELECTOR` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type6 := models.Type6Enum_SERVER

}
```

