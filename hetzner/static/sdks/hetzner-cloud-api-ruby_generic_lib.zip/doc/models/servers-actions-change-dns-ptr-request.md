
# Servers Actions Change Dns Ptr Request

## Structure

`ServersActionsChangeDnsPtrRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dns_ptr` | `String` | Required | Hostname to set as a reverse DNS PTR entry, reset to original value if `null` |
| `ip` | `String` | Required | Primary IP address for which the reverse DNS entry should be set |

## Example

```ruby
servers_actions_change_dns_ptr_request = ServersActionsChangeDnsPtrRequest.new(
  'server01.example.com',
  '1.2.3.4'
)
```

