
# X Amz Target 16 Enum

## Enumeration

`XAmzTarget16Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```ruby
x_amz_target16 = XAmzTarget16Enum::ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE
```

