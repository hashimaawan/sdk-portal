# Volume Actions

```ts
const volumeActionsController = new VolumeActionsController(client);
```

## Class Name

`VolumeActionsController`

## Methods

* [Get All Actions for a Volume](../../doc/controllers/volume-actions.md#get-all-actions-for-a-volume)
* [Attach Volume to a Server](../../doc/controllers/volume-actions.md#attach-volume-to-a-server)
* [Change Volume Protection](../../doc/controllers/volume-actions.md#change-volume-protection)
* [Detach Volume](../../doc/controllers/volume-actions.md#detach-volume)
* [Resize Volume](../../doc/controllers/volume-actions.md#resize-volume)
* [Get an Action for a Volume](../../doc/controllers/volume-actions.md#get-an-action-for-a-volume)


# Get All Actions for a Volume

Returns all Action objects for a Volume. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```ts
async getAllActionsForAVolume(
  id: number,
  sort?: ParameterSortEnum,
  status?: ParameterStatusEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionsResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Volume |
| `sort` | [`ParameterSortEnum \| undefined`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum \| undefined`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionsResponse`](../../doc/models/actions-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await volumeActionsController.getAllActionsForAVolume(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "attach_volume",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 13,
          "type": "volume"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Attach Volume to a Server

Attaches a Volume to a Server. Works only if the Server is in the same Location as the Volume.

```ts
async attachVolumeToAServer(
  id: number,
  body?: AttachVolumeRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Volume |
| `body` | [`AttachVolumeRequest \| undefined`](../../doc/models/attach-volume-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `attach_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: AttachVolumeRequest = {
  server: 43,
  automount: false,
};

try {
  const response = await volumeActionsController.attachVolumeToAServer(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 43,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Volume Protection

Changes the protection configuration of a Volume.

```ts
async changeVolumeProtection(
  id: number,
  body?: VolumesActionsChangeProtectionRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Volume |
| `body` | [`VolumesActionsChangeProtectionRequest \| undefined`](../../doc/models/volumes-actions-change-protection-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `change_protection` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: VolumesActionsChangeProtectionRequest = {
  mDelete: true,
};

try {
  const response = await volumeActionsController.changeVolumeProtection(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Detach Volume

Detaches a Volume from the Server it’s attached to. You may attach it to a Server again at a later time.

```ts
async detachVolume(
  id: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Volume |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `detach_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await volumeActionsController.detachVolume(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "detach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Resize Volume

Changes the size of a Volume. Note that downsizing a Volume is not possible.

```ts
async resizeVolume(
  id: number,
  body?: VolumesActionsResizeRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Volume |
| `body` | [`VolumesActionsResizeRequest \| undefined`](../../doc/models/volumes-actions-resize-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `resize_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: VolumesActionsResizeRequest = {
  size: 50,
};

try {
  const response = await volumeActionsController.resizeVolume(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "resize_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Get an Action for a Volume

Returns a specific Action for a Volume.

```ts
async getAnActionForAVolume(
  id: number,
  actionId: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Volume |
| `actionId` | `number` | Template, Required | ID of the Action |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `action` key contains the Volume Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const actionId = 224;

try {
  const response = await volumeActionsController.getAnActionForAVolume(
    id,
    actionId
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

