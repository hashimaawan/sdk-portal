
# List Databases Input

## Structure

`ListDatabasesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalog_name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```ruby
list_databases_input = ListDatabasesInput.new(
  'CatalogName0',
  'NextToken6',
  2
)
```

