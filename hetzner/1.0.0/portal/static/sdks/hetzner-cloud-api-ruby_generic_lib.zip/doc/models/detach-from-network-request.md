
# Detach from Network Request

*This model accepts additional fields of type Object.*

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `Integer` | Required | ID of an existing network to detach the Server from |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
detach_from_network_request = DetachFromNetworkRequest.new(
  network: 4711,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

