
# V2 Databases Users Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `user` | [`User`](../../doc/models/user.md) | Required | - | getUser(): User | setUser(User user): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesUsersResponse1Builder;
use DigitalOceanApiLib\Models\Builders\UserBuilder;
use DigitalOceanApiLib\Models\Builders\MysqlSettingsBuilder;
use DigitalOceanApiLib\Models\AuthPlugin;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Role;

$v2DatabasesUsersResponse1 = V2DatabasesUsersResponse1Builder::init(
    UserBuilder::init(
        'app-01'
    )
        ->mysqlSettings(
            MysqlSettingsBuilder::init(
                AuthPlugin::MYSQL_NATIVE_PASSWORD
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
        ->password('jge5lfxtzhx42iff')
        ->role(Role::NORMAL)
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

