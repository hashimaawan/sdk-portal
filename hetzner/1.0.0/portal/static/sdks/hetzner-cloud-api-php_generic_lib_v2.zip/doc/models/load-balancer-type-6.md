
# Load Balancer Type 6

*This model accepts additional fields of type array.*

## Structure

`LoadBalancerType6`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `float` | Required | ID of the Load Balancer type the price is for | getId(): float | setId(float id): void |
| `name` | `string` | Required | Name of the Load Balancer type the price is for | getName(): string | setName(string name): void |
| `prices` | [`Price7[]`](../../doc/models/price-7.md) | Required | Load Balancer type costs per Location | getPrices(): array | setPrices(array prices): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\LoadBalancerType6Builder;
use HetznerCloudApiLib\Models\Builders\Price7Builder;
use HetznerCloudApiLib\Models\Builders\PriceHourly6Builder;
use HetznerCloudApiLib\ApiHelper;
use HetznerCloudApiLib\Models\Builders\PriceMonthly8Builder;

$loadBalancerType6 = LoadBalancerType6Builder::init(
    1,
    'lb11',
    [
        Price7Builder::init(
            'fsn1',
            PriceHourly6Builder::init(
                '1.1900000000000000',
                '1.0000000000'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            PriceMonthly8Builder::init(
                '1.1900000000000000',
                '1.0000000000'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

