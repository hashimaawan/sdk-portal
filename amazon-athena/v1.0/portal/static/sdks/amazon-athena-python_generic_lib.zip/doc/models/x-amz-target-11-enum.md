
# X Amz Target 11 Enum

## Enumeration

`XAmzTarget11Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_11_enum import XAmzTarget11Enum

x_amz_target_11 = XAmzTarget11Enum.ENUM_AMAZONATHENADELETENOTEBOOK
```

