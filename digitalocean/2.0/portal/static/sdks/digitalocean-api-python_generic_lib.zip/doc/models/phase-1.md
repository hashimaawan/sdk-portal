
# Phase 1

## Enumeration

`Phase1`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING` |
| `CONFIGURING` |
| `ACTIVE` |
| `ERROR` |

## Example

```python
from digitaloceanapi.models.phase_1 import Phase1

phase_1 = Phase1.ACTIVE
```

