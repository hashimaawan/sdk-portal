
# Start Session Request

## Structure

`StartSessionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `description` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getDescription(): ?string | setDescription(?string description): void |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): string | setWorkGroup(string workGroup): void |
| `engineConfiguration` | [`EngineConfiguration1`](../../doc/models/engine-configuration-1.md) | Required | - | getEngineConfiguration(): EngineConfiguration1 | setEngineConfiguration(EngineConfiguration1 engineConfiguration): void |
| `notebookVersion` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | getNotebookVersion(): ?string | setNotebookVersion(?string notebookVersion): void |
| `sessionIdleTimeoutInMinutes` | `?int` | Optional | **Constraints**: `>= 1`, `<= 480` | getSessionIdleTimeoutInMinutes(): ?int | setSessionIdleTimeoutInMinutes(?int sessionIdleTimeoutInMinutes): void |
| `clientRequestToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128` | getClientRequestToken(): ?string | setClientRequestToken(?string clientRequestToken): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\StartSessionRequestBuilder;
use AmazonAthenaLib\Models\Builders\EngineConfiguration1Builder;
use AmazonAthenaLib\Models\Builders\AdditionalConfigsBuilder;

$startSessionRequest = StartSessionRequestBuilder::init(
    'WorkGroup2',
    EngineConfiguration1Builder::init(
        94
    )
        ->coordinatorDpuSize(1)
        ->defaultExecutorDpuSize(1)
        ->additionalConfigs(
            AdditionalConfigsBuilder::init()->build()
        )->build()
)
    ->description('Description4')
    ->notebookVersion('NotebookVersion4')
    ->sessionIdleTimeoutInMinutes(172)
    ->clientRequestToken('ClientRequestToken4')
    ->build();
```

