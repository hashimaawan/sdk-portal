
# Calculation Execution State

## Enumeration

`CalculationExecutionState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```java
import com.amazonaws.useast1.athena.models.CalculationExecutionState;

CalculationExecutionState calculationExecutionState = CalculationExecutionState.COMPLETED;
```

