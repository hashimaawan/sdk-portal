
# X Amz Target 42

## Enumeration

`XAmzTarget42`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistsessions` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget42 := models.XAmzTarget42_EnumAmazonathenalistsessions

}
```

