
# Create Presigned Notebook Url Response

*This model accepts additional fields of type unknown.*

## Structure

`CreatePresignedNotebookUrlResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookUrl` | `string` | Required | - |
| `authToken` | `string` | Required | **Constraints**: *Maximum Length*: `2048` |
| `authTokenExpirationTime` | `number` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { CreatePresignedNotebookUrlResponse } from 'amazon-athenalib';

const createPresignedNotebookUrlResponse: CreatePresignedNotebookUrlResponse = {
  notebookUrl: 'NotebookUrl0',
  authToken: 'AuthToken4',
  authTokenExpirationTime: 240,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

