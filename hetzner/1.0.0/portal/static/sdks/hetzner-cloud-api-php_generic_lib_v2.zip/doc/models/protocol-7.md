
# Protocol 7

Protocol of the Load Balancer

## Enumeration

`Protocol7`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```php
use HetznerCloudApiLib\Models\Protocol7;

$protocol7 = Protocol7::HTTP;
```

