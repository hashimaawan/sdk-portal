
# Notebook Session Summary

Contains the notebook session ID and notebook session creation time.

*This model accepts additional fields of type Object.*

## Structure

`NotebookSessionSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `creation_time` | `DateTime` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
notebook_session_summary = NotebookSessionSummary.new(
  session_id: 'SessionId2',
  creation_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

