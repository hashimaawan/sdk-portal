
# Pending Change

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`PendingChange`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_id` | `Integer` | Optional | - |
| `removing` | `TrueClass \| FalseClass` | Optional | - |
| `status` | `String` | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
pending_change = PendingChange.new(
  droplet_id: 8043964,
  removing: false,
  status: 'waiting',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

