
# Session Configuration 2

## Structure

`SessionConfiguration2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ExecutionRole` | `String` | Optional | **Constraints**: *Minimum Length*: `20`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:iam::\d{12}:role/?[a-zA-Z_0-9+=,.@\-_/]+$` | String getExecutionRole() | setExecutionRole(String executionRole) |
| `WorkingDirectory` | `String` | Optional | - | String getWorkingDirectory() | setWorkingDirectory(String workingDirectory) |
| `IdleTimeoutSeconds` | `Integer` | Optional | - | Integer getIdleTimeoutSeconds() | setIdleTimeoutSeconds(Integer idleTimeoutSeconds) |
| `EncryptionConfiguration` | [`EncryptionConfiguration`](../../doc/models/encryption-configuration.md) | Optional | If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information. | EncryptionConfiguration getEncryptionConfiguration() | setEncryptionConfiguration(EncryptionConfiguration encryptionConfiguration) |

## Example

```java
import com.amazonaws.useast1.athena.models.EncryptionConfiguration;
import com.amazonaws.useast1.athena.models.EncryptionOption1Enum;
import com.amazonaws.useast1.athena.models.SessionConfiguration2;

SessionConfiguration2 sessionConfiguration2 = new SessionConfiguration2.Builder()
    .executionRole("ExecutionRole0")
    .workingDirectory("WorkingDirectory4")
    .idleTimeoutSeconds(82)
    .encryptionConfiguration(new EncryptionConfiguration.Builder(
        EncryptionOption1Enum.SSE_S3
    )
    .kmsKey("KmsKey6")
    .build())
    .build();
```

