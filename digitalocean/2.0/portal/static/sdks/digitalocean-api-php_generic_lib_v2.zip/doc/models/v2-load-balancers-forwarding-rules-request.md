
# V2 Load Balancers Forwarding Rules Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2LoadBalancersForwardingRulesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `forwardingRules` | [`ForwardingRule[]`](../../doc/models/forwarding-rule.md) | Required | **Constraints**: *Minimum Items*: `1` | getForwardingRules(): array | setForwardingRules(array forwardingRules): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2LoadBalancersForwardingRulesRequestBuilder;
use DigitalOceanApiLib\Models\Builders\ForwardingRuleBuilder;
use DigitalOceanApiLib\Models\EntryProtocol;
use DigitalOceanApiLib\Models\TargetProtocol;
use DigitalOceanApiLib\ApiHelper;

$v2LoadBalancersForwardingRulesRequest = V2LoadBalancersForwardingRulesRequestBuilder::init(
    [
        ForwardingRuleBuilder::init(
            443,
            EntryProtocol::HTTPS,
            80,
            TargetProtocol::HTTP
        )
            ->certificateId('892071a0-bb95-49bc-8021-3afd67a210bf')
            ->tlsPassthrough(false)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

