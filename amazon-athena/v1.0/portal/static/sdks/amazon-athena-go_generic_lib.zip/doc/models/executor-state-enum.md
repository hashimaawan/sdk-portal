
# Executor State Enum

## Enumeration

`ExecutorStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    executorState := models.ExecutorStateEnum_TERMINATED

}
```

