
# X Amz Target 10 Enum

## Enumeration

`XAmzTarget10Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENADELETENAMEDQUERY` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget10 := models.XAmzTarget10Enum_ENUMAMAZONATHENADELETENAMEDQUERY

}
```

