
# Notebook Type 1

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1`

## Fields

| Name |
|  --- |
| `Ipynb` |

## Example

```ts
import { NotebookType1 } from 'amazon-athenalib';

const notebookType1 = NotebookType1.Ipynb;
```

