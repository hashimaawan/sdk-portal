
# Type 11

The type of the IPv6 network interface.

**Note**: IPv6 private  networking is not currently supported.

## Enumeration

`Type11`

## Fields

| Name |
|  --- |
| `PUBLIC_` |

## Example

```php
use DigitalOceanApiLib\Models\Type11;

$type11 = Type11::PUBLIC_;
```

