
# Type 3

The object type.

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `User` |

## Example

```ts
import {
  Type3,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const type3 = Type3.User;
```

