
# Labels 2

User-defined labels (key-value pairs)

## Structure

`Labels2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labelkey` | `str` | Optional | - |

## Example

```python
from hetznercloudapi.models.labels_2 import Labels2

labels_2 = Labels2(
    labelkey='value'
)
```

