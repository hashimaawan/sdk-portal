
# Create Named Query Output

## Structure

`CreateNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namedQueryId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { CreateNamedQueryOutput } from 'amazon-athenalib';

const createNamedQueryOutput: CreateNamedQueryOutput = {
  namedQueryId: 'NamedQueryId0',
};
```

