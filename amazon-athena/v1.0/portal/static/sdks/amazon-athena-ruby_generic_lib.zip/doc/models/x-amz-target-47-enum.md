
# X Amz Target 47 Enum

## Enumeration

`XAmzTarget47Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTQUERYEXECUTION` |

## Example

```ruby
x_amz_target47 = XAmzTarget47Enum::ENUM_AMAZONATHENASTARTQUERYEXECUTION
```

