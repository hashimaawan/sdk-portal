
# Os Flavor Enum

Flavor of operating system contained in the Image

## Enumeration

`OsFlavorEnum`

## Fields

| Name |
|  --- |
| `UBUNTU` |
| `CENTOS` |
| `DEBIAN` |
| `FEDORA` |
| `UNKNOWN` |

## Example

```java
import cloud.hetzner.api.models.OsFlavorEnum;

OsFlavorEnum osFlavor = OsFlavorEnum.DEBIAN;
```

