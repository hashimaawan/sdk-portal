
# Type 24

Destination Image type to convert to

## Enumeration

`Type24`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |

## Example

```python
from hetznercloudapi.models.type_24 import Type24

type_24 = Type24.SNAPSHOT
```

