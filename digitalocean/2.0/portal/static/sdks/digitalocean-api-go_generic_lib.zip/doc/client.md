
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```go
package main

import (
    "digitalOceanApi"
)

func main() {
    client := digitalOceanApi.NewClient(
    digitalOceanApi.CreateConfiguration(
            digitalOceanApi.WithHttpConfiguration(
                digitalOceanApi.CreateHttpConfiguration(
                    digitalOceanApi.WithTimeout(30),
                ),
            ),
            digitalOceanApi.WithBearerAuthCredentials(
                digitalOceanApi.NewBearerAuthCredentials("AccessToken"),
            ),
            digitalOceanApi.WithLoggerConfiguration(
                digitalOceanApi.WithLevel("info"),
                digitalOceanApi.WithRequestConfiguration(
                    digitalOceanApi.WithRequestBody(true),
                ),
                digitalOceanApi.WithResponseConfiguration(
                    digitalOceanApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## DigitalOcean API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| M1ClickApplicationsApi() | Gets M1ClickApplicationsApi |
| AccountApi() | Gets AccountApi |
| ActionsApi() | Gets ActionsApi |
| AppsApi() | Gets AppsApi |
| BillingApi() | Gets BillingApi |
| BlockStorageApi() | Gets BlockStorageApi |
| BlockStorageActionsApi() | Gets BlockStorageActionsApi |
| CdnEndpointsApi() | Gets CdnEndpointsApi |
| CertificatesApi() | Gets CertificatesApi |
| ContainerRegistryApi() | Gets ContainerRegistryApi |
| DatabasesApi() | Gets DatabasesApi |
| DomainRecordsApi() | Gets DomainRecordsApi |
| DomainsApi() | Gets DomainsApi |
| DropletActionsApi() | Gets DropletActionsApi |
| DropletsApi() | Gets DropletsApi |
| FirewallsApi() | Gets FirewallsApi |
| FloatingIpActionsApi() | Gets FloatingIpActionsApi |
| FloatingIPsApi() | Gets FloatingIPsApi |
| FunctionsApi() | Gets FunctionsApi |
| ImageActionsApi() | Gets ImageActionsApi |
| ImagesApi() | Gets ImagesApi |
| KubernetesApi() | Gets KubernetesApi |
| LoadBalancersApi() | Gets LoadBalancersApi |
| MonitoringApi() | Gets MonitoringApi |
| ProjectResourcesApi() | Gets ProjectResourcesApi |
| ProjectsApi() | Gets ProjectsApi |
| RegionsApi() | Gets RegionsApi |
| ReservedIpActionsApi() | Gets ReservedIpActionsApi |
| ReservedIPsApi() | Gets ReservedIPsApi |
| SizesApi() | Gets SizesApi |
| SnapshotsApi() | Gets SnapshotsApi |
| SshKeysApi() | Gets SshKeysApi |
| TagsApi() | Gets TagsApi |
| UptimeApi() | Gets UptimeApi |
| VpCsApi() | Gets VpCsApi |

