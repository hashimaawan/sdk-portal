
# V2 Databases Sql Mode Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesSqlModeResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sqlMode` | `string` | Required | A string specifying the configured SQL modes for the MySQL cluster. | getSqlMode(): string | setSqlMode(string sqlMode): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesSqlModeResponseBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesSqlModeResponse = V2DatabasesSqlModeResponseBuilder::init(
    'ANSI,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION,NO_ZERO_DATE,NO_ZERO_IN_DATE,STRICT_ALL_TABLES'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

