
# Type 7 Enum

Type of the resource

## Enumeration

`Type7Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```java
import cloud.hetzner.api.models.Type7Enum;

Type7Enum type7 = Type7Enum.SERVER;
```

