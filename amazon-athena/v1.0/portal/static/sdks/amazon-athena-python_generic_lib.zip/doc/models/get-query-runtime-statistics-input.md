
# Get Query Runtime Statistics Input

## Structure

`GetQueryRuntimeStatisticsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```python
from amazonathena.models.get_query_runtime_statistics_input import GetQueryRuntimeStatisticsInput

get_query_runtime_statistics_input = GetQueryRuntimeStatisticsInput(
    query_execution_id='QueryExecutionId0'
)
```

