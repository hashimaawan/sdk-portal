
# X Amz Target 12 Enum

## Enumeration

`XAmzTarget12Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeletePreparedStatement` |

## Example

```ts
import { XAmzTarget12Enum } from 'amazon-athenalib';

const xAmzTarget12 = XAmzTarget12Enum.EnumAmazonAthenaDeletePreparedStatement;
```

