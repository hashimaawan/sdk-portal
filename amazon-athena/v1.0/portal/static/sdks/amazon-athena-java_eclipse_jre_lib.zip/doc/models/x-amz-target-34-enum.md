
# X Amz Target 34 Enum

## Enumeration

`XAmzTarget34Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATABASES` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget34Enum;

XAmzTarget34Enum xAmzTarget34 = XAmzTarget34Enum.ENUM_AMAZONATHENALISTDATABASES;
```

