
# X Amz Target 38 Enum

## Enumeration

`XAmzTarget38Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```ruby
x_amz_target38 = XAmzTarget38Enum::ENUM_AMAZONATHENALISTNOTEBOOKMETADATA
```

