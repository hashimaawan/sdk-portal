
# Query Runtime Statistics

The query execution timeline, statistics on input and output rows and bytes, and the different query stages that form the query execution plan.

*This model accepts additional fields of type unknown.*

## Structure

`QueryRuntimeStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `timeline` | [`QueryRuntimeStatisticsTimeline \| undefined`](../../doc/models/query-runtime-statistics-timeline.md) | Optional | Timeline statistics such as query queue time, planning time, execution time, service processing time, and total execution time. |
| `rows` | [`QueryRuntimeStatisticsRows \| undefined`](../../doc/models/query-runtime-statistics-rows.md) | Optional | Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query. |
| `outputStage` | [`OutputStage \| undefined`](../../doc/models/output-stage.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { QueryRuntimeStatistics } from 'amazon-athenalib';

const queryRuntimeStatistics: QueryRuntimeStatistics = {
  timeline: {
    queryQueueTimeInMillis: 156,
    queryPlanningTimeInMillis: 82,
    engineExecutionTimeInMillis: 112,
    serviceProcessingTimeInMillis: 126,
    totalExecutionTimeInMillis: 106,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  rows: {
    inputRows: 230,
    inputBytes: 250,
    outputBytes: 36,
    outputRows: 230,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  outputStage: {
    stageId: 130,
    state: 'State0',
    outputBytes: 108,
    outputRows: 158,
    inputBytes: 190,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

