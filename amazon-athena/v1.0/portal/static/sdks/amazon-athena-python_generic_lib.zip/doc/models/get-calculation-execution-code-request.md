
# Get Calculation Execution Code Request

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```python
from amazonathena.models.get_calculation_execution_code_request import GetCalculationExecutionCodeRequest

get_calculation_execution_code_request = GetCalculationExecutionCodeRequest(
    calculation_execution_id='CalculationExecutionId0'
)
```

