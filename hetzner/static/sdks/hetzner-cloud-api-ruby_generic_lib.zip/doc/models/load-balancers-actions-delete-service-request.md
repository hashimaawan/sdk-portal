
# Load Balancers Actions Delete Service Request

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listen_port` | `Float` | Required | The listen port of the service you want to delete |

## Example

```ruby
load_balancers_actions_delete_service_request = LoadBalancersActionsDeleteServiceRequest.new(
  4711
)
```

