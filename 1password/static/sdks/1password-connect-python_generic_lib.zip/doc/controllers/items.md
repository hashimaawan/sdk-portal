# Items

Access and manage items inside 1Password Vaults

```python
items_api = client.items
```

## Class Name

`ItemsApi`

## Methods

* [Get Vault Items](../../doc/controllers/items.md#get-vault-items)
* [Create Vault Item](../../doc/controllers/items.md#create-vault-item)
* [Delete Vault Item](../../doc/controllers/items.md#delete-vault-item)
* [Get Vault Item by Id](../../doc/controllers/items.md#get-vault-item-by-id)
* [Patch Vault Item](../../doc/controllers/items.md#patch-vault-item)
* [Update Vault Item](../../doc/controllers/items.md#update-vault-item)


# Get Vault Items

```python
def get_vault_items(self,
                   vault_uuid,
                   filter=None)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `str` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `filter` | `str` | Query, Optional | Filter the Item collection based on Item name using SCIM eq filter |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`List[Item]`](../../doc/models/item.md).

## Example Usage

```python
vault_uuid = 'vaultUuid2'

filter = 'title eq "Some Item Name"'

result = items_api.get_vault_items(
    vault_uuid,
    filter=filter
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Vault not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Create Vault Item

```python
def create_vault_item(self,
                     vault_uuid,
                     body=None)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `str` | Template, Required | The UUID of the Vault to create an Item in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`FullItem`](../../doc/models/full-item.md) | Body, Optional | - |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```python
vault_uuid = 'vaultUuid2'

body = FullItem(
    category=Category.MEMBERSHIP,
    vault=Vault1(
        id='id6'
    ),
    favorite=False,
    urls=[
        Url(
            href='https://example.com',
            primary=True
        ),
        Url(
            href='https://example.org'
        )
    ]
)

result = items_api.create_vault_item(
    vault_uuid,
    body=body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Unable to create item due to invalid input | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Delete Vault Item

```python
def delete_vault_item(self,
                     vault_uuid,
                     item_uuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `str` | Template, Required | The UUID of the Vault the item is in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `item_uuid` | `str` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**204**: Successfully deleted an item

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```python
vault_uuid = 'vaultUuid2'

item_uuid = 'itemUuid6'

result = items_api.delete_vault_item(
    vault_uuid,
    item_uuid
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Vault Item by Id

```python
def get_vault_item_by_id(self,
                        vault_uuid,
                        item_uuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `str` | Template, Required | The UUID of the Vault to fetch Item from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `item_uuid` | `str` | Template, Required | The UUID of the Item to fetch<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```python
vault_uuid = 'vaultUuid2'

item_uuid = 'itemUuid6'

result = items_api.get_vault_item_by_id(
    vault_uuid,
    item_uuid
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Patch Vault Item

Applies a modified [RFC6902 JSON Patch](https://tools.ietf.org/html/rfc6902) document to an Item or ItemField. This endpoint only supports `add`, `remove` and `replace` operations.

When modifying a specific ItemField, the ItemField's ID in the `path` attribute of the operation object: `/fields/{fieldId}`

```python
def patch_vault_item(self,
                    vault_uuid,
                    item_uuid,
                    body=None)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `str` | Template, Required | The UUID of the Vault the item is in<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `item_uuid` | `str` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`List[Patch]`](../../doc/models/patch.md) | Body, Optional | - |

## Response Type

**200**: OK - Item updated. If no Patch operations were provided, Item is unmodified.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```python
vault_uuid = 'vaultUuid2'

item_uuid = 'itemUuid6'

body = [
    Patch(
        op=Op.ADD,
        path='/fields',
        value=jsonpickle.decode('{"label":"New Field","type":"string","value":"hunter2"}')
    )
]

result = items_api.patch_vault_item(
    vault_uuid,
    item_uuid,
    body=body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Vault Item

```python
def update_vault_item(self,
                     vault_uuid,
                     item_uuid,
                     body=None)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vault_uuid` | `str` | Template, Required | The UUID of the Item's Vault<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `item_uuid` | `str` | Template, Required | The UUID of the Item to update<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `body` | [`FullItem`](../../doc/models/full-item.md) | Body, Optional | - |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`FullItem`](../../doc/models/full-item.md).

## Example Usage

```python
vault_uuid = 'vaultUuid2'

item_uuid = 'itemUuid6'

body = FullItem(
    category=Category.MEMBERSHIP,
    vault=Vault1(
        id='id6'
    ),
    favorite=False,
    urls=[
        Url(
            href='https://example.com',
            primary=True
        ),
        Url(
            href='https://example.org'
        )
    ]
)

result = items_api.update_vault_item(
    vault_uuid,
    item_uuid,
    body=body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Unable to create item due to invalid input | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

