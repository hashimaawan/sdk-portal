
# X Amz Target 39

## Enumeration

`XAmzTarget39`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```ruby
x_amz_target39 = XAmzTarget39::ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS
```

