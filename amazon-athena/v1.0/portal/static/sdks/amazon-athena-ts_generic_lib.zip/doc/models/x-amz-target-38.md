
# X Amz Target 38

## Enumeration

`XAmzTarget38`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNotebookMetadata` |

## Example

```ts
import { XAmzTarget38 } from 'amazon-athenalib';

const xAmzTarget38 = XAmzTarget38.EnumAmazonAthenaListNotebookMetadata;
```

