
# V2 Projects Default Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2ProjectsDefaultResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `project` | [`Project`](../../doc/models/project.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_projects_default_response = V2ProjectsDefaultResponse.new(
  project: Project.new(
    created_at: DateTimeHelper.from_rfc3339('2017-10-19T21:44:20Z'),
    description: 'Default project',
    environment: Environment::DEVELOPMENT,
    id: 'addb4547-6bab-419a-8542-76263a033cf6',
    name: 'Default',
    owner_id: 258992,
    owner_uuid: '99525febec065ca37b2ffe4f852fd2b2581895e7',
    purpose: 'Just trying out DigitalOcean',
    updated_at: DateTimeHelper.from_rfc3339('2019-11-05T18:50:03Z'),
    is_default: true,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

