
# Executor Type

## Enumeration

`ExecutorType`

## Fields

| Name |
|  --- |
| `Coordinator` |
| `Gateway` |
| `Worker` |

## Example

```ts
import { ExecutorType } from 'amazon-athenalib';

const executorType = ExecutorType.Gateway;
```

