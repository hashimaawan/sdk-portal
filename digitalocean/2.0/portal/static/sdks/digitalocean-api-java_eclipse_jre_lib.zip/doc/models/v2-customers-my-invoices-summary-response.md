
# V2 Customers My Invoices Summary Response

*This model accepts additional fields of type Object.*

## Structure

`V2CustomersMyInvoicesSummaryResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `String` | Optional | Total amount of the invoice, in USD.  This will reflect month-to-date usage in the invoice preview. | String getAmount() | setAmount(String amount) |
| `BillingPeriod` | `String` | Optional | Billing period of usage for which the invoice is issued, in `YYYY-MM`  format. | String getBillingPeriod() | setBillingPeriod(String billingPeriod) |
| `CreditsAndAdjustments` | [`CreditsAndAdjustments`](../../doc/models/credits-and-adjustments.md) | Optional | - | CreditsAndAdjustments getCreditsAndAdjustments() | setCreditsAndAdjustments(CreditsAndAdjustments creditsAndAdjustments) |
| `InvoiceUuid` | `String` | Optional | UUID of the invoice | String getInvoiceUuid() | setInvoiceUuid(String invoiceUuid) |
| `Overages` | [`Overages`](../../doc/models/overages.md) | Optional | - | Overages getOverages() | setOverages(Overages overages) |
| `ProductCharges` | [`ProductCharges`](../../doc/models/product-charges.md) | Optional | - | ProductCharges getProductCharges() | setProductCharges(ProductCharges productCharges) |
| `Taxes` | [`Taxes`](../../doc/models/taxes.md) | Optional | - | Taxes getTaxes() | setTaxes(Taxes taxes) |
| `UserBillingAddress` | [`UserBillingAddress`](../../doc/models/user-billing-address.md) | Optional | - | UserBillingAddress getUserBillingAddress() | setUserBillingAddress(UserBillingAddress userBillingAddress) |
| `UserCompany` | `String` | Optional | Company of the DigitalOcean customer being invoiced, if set. | String getUserCompany() | setUserCompany(String userCompany) |
| `UserEmail` | `String` | Optional | Email of the DigitalOcean customer being invoiced. | String getUserEmail() | setUserEmail(String userEmail) |
| `UserName` | `String` | Optional | Name of the DigitalOcean customer being invoiced. | String getUserName() | setUserName(String userName) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.CreditsAndAdjustments;
import com.digitalocean.api.models.Overages;
import com.digitalocean.api.models.V2CustomersMyInvoicesSummaryResponse;
import java.io.IOException;

V2CustomersMyInvoicesSummaryResponse v2CustomersMyInvoicesSummaryResponse = new V2CustomersMyInvoicesSummaryResponse.Builder()
    .amount("27.13")
    .billingPeriod("2020-01")
    .creditsAndAdjustments(new CreditsAndAdjustments.Builder()
        .amount("amount6")
        .name("name4")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .invoiceUuid("22737513-0ea7-4206-8ceb-98a575af7681")
    .overages(new Overages.Builder()
        .amount("amount6")
        .name("name4")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .userCompany("DigitalOcean")
    .userEmail("sammy@digitalocean.com")
    .userName("Sammy Shark")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

