
# Calculation Summary

Summary information for a notebook calculation.

## Structure

`CalculationSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CalculationExecutionId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | String getCalculationExecutionId() | setCalculationExecutionId(String calculationExecutionId) |
| `Description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getDescription() | setDescription(String description) |
| `Status` | [`Status1`](../../doc/models/status-1.md) | Optional | - | Status1 getStatus() | setStatus(Status1 status) |

## Example

```java
import com.amazonaws.useast1.athena.DateTimeHelper;
import com.amazonaws.useast1.athena.models.CalculationExecutionState1Enum;
import com.amazonaws.useast1.athena.models.CalculationSummary;
import com.amazonaws.useast1.athena.models.Status1;

CalculationSummary calculationSummary = new CalculationSummary.Builder()
    .calculationExecutionId("CalculationExecutionId4")
    .description("Description6")
    .status(new Status1.Builder()
        .submissionDateTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .completionDateTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .state(CalculationExecutionState1Enum.CANCELING)
        .stateChangeReason("StateChangeReason8")
        .build())
    .build();
```

