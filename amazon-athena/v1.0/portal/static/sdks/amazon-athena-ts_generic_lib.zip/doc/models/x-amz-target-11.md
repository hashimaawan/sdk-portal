
# X Amz Target 11

## Enumeration

`XAmzTarget11`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteNotebook` |

## Example

```ts
import { XAmzTarget11 } from 'amazon-athenalib';

const xAmzTarget11 = XAmzTarget11.EnumAmazonAthenaDeleteNotebook;
```

