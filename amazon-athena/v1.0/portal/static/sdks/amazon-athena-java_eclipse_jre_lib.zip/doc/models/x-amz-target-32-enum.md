
# X Amz Target 32 Enum

## Enumeration

`XAmzTarget32Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget32Enum;

XAmzTarget32Enum xAmzTarget32 = XAmzTarget32Enum.ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS;
```

