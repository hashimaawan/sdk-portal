
# X Amz Target 35

## Enumeration

`XAmzTarget35`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTENGINEVERSIONS` |

## Example

```ruby
x_amz_target35 = XAmzTarget35::ENUM_AMAZONATHENALISTENGINEVERSIONS
```

