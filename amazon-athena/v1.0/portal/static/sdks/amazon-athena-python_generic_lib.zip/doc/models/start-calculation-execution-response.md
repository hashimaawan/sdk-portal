
# Start Calculation Execution Response

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `state` | [`CalculationExecutionState4Enum`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```python
from amazonathena.models.calculation_execution_state_4_enum import CalculationExecutionState4Enum
from amazonathena.models.start_calculation_execution_response import StartCalculationExecutionResponse

start_calculation_execution_response = StartCalculationExecutionResponse(
    calculation_execution_id='CalculationExecutionId0',
    state=CalculationExecutionState4Enum.CANCELING
)
```

