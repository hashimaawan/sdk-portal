
# Delete Data Catalog Input

*This model accepts additional fields of type array.*

## Structure

`DeleteDataCatalogInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getName(): string | setName(string name): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DeleteDataCatalogInputBuilder;
use AmazonAthenaLib\ApiHelper;

$deleteDataCatalogInput = DeleteDataCatalogInputBuilder::init(
    'Name2'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

