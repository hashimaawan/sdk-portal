
# Server 16

Configuration for type Server, required if type is `server`

## Structure

`Server16`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `double` | Required | ID of the Server |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Server16 server16 = new Server16
{
    Id = 80,
};
```

