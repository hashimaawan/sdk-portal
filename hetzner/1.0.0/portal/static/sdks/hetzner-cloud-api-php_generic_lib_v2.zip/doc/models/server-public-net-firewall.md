
# Server Public Net Firewall

## Structure

`ServerPublicNetFirewall`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | ID of the Resource | getId(): ?int | setId(?int id): void |
| `status` | [`?string(Status72Enum)`](../../doc/models/status-72-enum.md) | Optional | Status of the Firewall on the Server | getStatus(): ?string | setStatus(?string status): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ServerPublicNetFirewallBuilder;
use HetznerCloudAPILib\Models\Status72Enum;

$serverPublicNetFirewall = ServerPublicNetFirewallBuilder::init()
    ->id(42)
    ->status(Status72Enum::APPLIED)
    ->build();
```

