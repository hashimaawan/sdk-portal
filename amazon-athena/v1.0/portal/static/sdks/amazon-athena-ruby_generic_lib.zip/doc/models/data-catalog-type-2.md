
# Data Catalog Type 2

The data catalog type.

## Enumeration

`DataCatalogType2`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```ruby
data_catalog_type2 = DataCatalogType2::GLUE
```

