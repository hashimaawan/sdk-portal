
# X Amz Target 34

## Enumeration

`XAmzTarget34`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATABASES` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget34;

$xAmzTarget34 = XAmzTarget34::ENUM_AMAZONATHENALISTDATABASES;
```

