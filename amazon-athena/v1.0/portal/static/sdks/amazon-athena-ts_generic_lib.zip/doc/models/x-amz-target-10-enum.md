
# X Amz Target 10 Enum

## Enumeration

`XAmzTarget10Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteNamedQuery` |

## Example

```ts
import { XAmzTarget10Enum } from 'amazon-athenalib';

const xAmzTarget10 = XAmzTarget10Enum.EnumAmazonAthenaDeleteNamedQuery;
```

