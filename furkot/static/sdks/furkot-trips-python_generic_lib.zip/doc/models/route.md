
# Route

route leading to the stop

## Structure

`Route`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `distance` | `int` | Optional | route distance in meters |
| `duration` | `int` | Optional | route duration in seconds |
| `mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Optional | travel mode |
| `polyline` | `str` | Optional | route path compatible with Google polyline encoding algorithm |

## Example

```python
from furkottrips.models.mode_enum import ModeEnum
from furkottrips.models.route import Route

route = Route(
    distance=134,
    duration=168,
    mode=ModeEnum.CAR,
    polyline='polyline0'
)
```

