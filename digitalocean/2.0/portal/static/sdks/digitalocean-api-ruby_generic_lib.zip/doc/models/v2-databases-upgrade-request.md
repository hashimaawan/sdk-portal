
# V2 Databases Upgrade Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesUpgradeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Optional | A string representing the version of the database engine in use for the cluster. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_upgrade_request = V2DatabasesUpgradeRequest.new(
  version: '10',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

