
# Type 21

The volume action to initiate.

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `ATTACH` |
| `DETACH` |
| `RESIZE` |

## Example

```ruby
type21 = Type21::DETACH
```

