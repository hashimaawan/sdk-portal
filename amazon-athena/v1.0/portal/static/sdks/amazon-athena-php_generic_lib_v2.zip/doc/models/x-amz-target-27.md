
# X Amz Target 27

## Enumeration

`XAmzTarget27`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSIONSTATUS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget27;

$xAmzTarget27 = XAmzTarget27::ENUM_AMAZONATHENAGETSESSIONSTATUS;
```

