
# X Amz Target 6 Enum

## Enumeration

`XAmzTarget6Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget6 := models.XAmzTarget6Enum_ENUMAMAZONATHENACREATEPREPAREDSTATEMENT

}
```

