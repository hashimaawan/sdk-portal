
# Type 39

Algorithm of the Load Balancer

## Enumeration

`Type39`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```ts
import { Type39 } from 'hetzner-cloud-apilib';

const type39 = Type39.RoundRobin;
```

