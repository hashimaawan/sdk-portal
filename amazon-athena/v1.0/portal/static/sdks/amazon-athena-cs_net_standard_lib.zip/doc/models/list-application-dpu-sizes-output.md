
# List Application DPU Sizes Output

## Structure

`ListApplicationDPUSizesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ApplicationDPUSizes` | [`List<ApplicationDPUSizes>`](../../doc/models/application-dpu-sizes.md) | Optional | - |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

ListApplicationDPUSizesOutput listApplicationDPUSizesOutput = new ListApplicationDPUSizesOutput
{
    ApplicationDPUSizes = new List<ApplicationDPUSizes>
    {
        new ApplicationDPUSizes
        {
            ApplicationRuntimeId = "ApplicationRuntimeId0",
            SupportedDPUSizes = new List<int>
            {
                113,
                114,
            },
        },
        new ApplicationDPUSizes
        {
            ApplicationRuntimeId = "ApplicationRuntimeId0",
            SupportedDPUSizes = new List<int>
            {
                113,
                114,
            },
        },
    },
    NextToken = "NextToken0",
};
```

