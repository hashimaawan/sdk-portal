
# Batch Get Query Execution Input

Contains an array of query execution IDs.

*This model accepts additional fields of type array.*

## Structure

`BatchGetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `queryExecutionIds` | `string[]` | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getQueryExecutionIds(): array | setQueryExecutionIds(array queryExecutionIds): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\BatchGetQueryExecutionInputBuilder;
use AmazonAthenaLib\ApiHelper;

$batchGetQueryExecutionInput = BatchGetQueryExecutionInputBuilder::init(
    [
        'QueryExecutionIds7',
        'QueryExecutionIds8',
        'QueryExecutionIds9'
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

