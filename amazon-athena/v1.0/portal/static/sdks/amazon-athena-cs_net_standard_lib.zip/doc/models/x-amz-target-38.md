
# X Amz Target 38

## Enumeration

`XAmzTarget38`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNotebookMetadata` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget38 xAmzTarget38 = XAmzTarget38.EnumAmazonAthenaListNotebookMetadata;
```

