
# Executor Type Enum

## Enumeration

`ExecutorTypeEnum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```ts
import { ExecutorTypeEnum } from 'amazon-athenalib';

const executorType = ExecutorTypeEnum.GATEWAY;
```

