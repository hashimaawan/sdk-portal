
# Import Notebook Output

## Structure

`ImportNotebookOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```python
from amazonathena.models.import_notebook_output import ImportNotebookOutput

import_notebook_output = ImportNotebookOutput(
    notebook_id='NotebookId2'
)
```

