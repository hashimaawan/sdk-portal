
# Price 6

## Structure

`Price6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location` | `String` | Required | Name of the Location the price is for |
| `price_monthly` | [`PriceMonthly7`](../../doc/models/price-monthly-7.md) | Required | Monthly costs for a Floating IP type in this Location |

## Example

```ruby
price6 = Price6.new(
  'fsn1',
  PriceMonthly7.new(
    '1.1900000000000000',
    '1.0000000000'
  )
)
```

