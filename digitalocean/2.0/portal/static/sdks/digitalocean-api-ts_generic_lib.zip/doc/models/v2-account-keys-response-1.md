
# V2 Account Keys Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AccountKeysResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sshKey` | [`SshKey \| undefined`](../../doc/models/ssh-key.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AccountKeysResponse1 } from 'digitalocean-apilib';

const v2AccountKeysResponse1: V2AccountKeysResponse1 = {
  sshKey: {
    name: 'name2',
    publicKey: 'public_key4',
    fingerprint: 'fingerprint8',
    id: 204,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

