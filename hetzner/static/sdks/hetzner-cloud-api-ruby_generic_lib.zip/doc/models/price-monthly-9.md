
# Price Monthly 9

Monthly costs for a Primary IP type in this Location

## Structure

`PriceMonthly9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `String` | Required | Price with VAT added |
| `net` | `String` | Required | Price without VAT |

## Example

```ruby
price_monthly9 = PriceMonthly9.new(
  '1.1900000000000000',
  '1.0000000000'
)
```

