# Volume Actions

```go
volumeActionsController := client.VolumeActionsController()
```

## Class Name

`VolumeActionsController`

## Methods

* [Get All Actions for a Volume](../../doc/controllers/volume-actions.md#get-all-actions-for-a-volume)
* [Attach Volume to a Server](../../doc/controllers/volume-actions.md#attach-volume-to-a-server)
* [Change Volume Protection](../../doc/controllers/volume-actions.md#change-volume-protection)
* [Detach Volume](../../doc/controllers/volume-actions.md#detach-volume)
* [Resize Volume](../../doc/controllers/volume-actions.md#resize-volume)
* [Get an Action for a Volume](../../doc/controllers/volume-actions.md#get-an-action-for-a-volume)


# Get All Actions for a Volume

Returns all Action objects for a Volume. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```go
GetAllActionsForAVolume(
    ctx context.Context,
    id int,
    sort *models.ParameterSortEnum,
    status *models.ParameterStatusEnum) (
    models.ApiResponse[models.ActionsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `sort` | [`*models.ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`*models.ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := volumeActionsController.GetAllActionsForAVolume(ctx, id, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "attach_volume",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 13,
          "type": "volume"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Attach Volume to a Server

Attaches a Volume to a Server. Works only if the Server is in the same Location as the Volume.

```go
AttachVolumeToAServer(
    ctx context.Context,
    id int,
    body *models.AttachVolumeRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`*models.AttachVolumeRequest`](../../doc/models/attach-volume-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `attach_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.AttachVolumeRequest{
    Automount:            models.ToPointer(false),
    Server:               43,
}

apiResponse, err := volumeActionsController.AttachVolumeToAServer(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 43,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Volume Protection

Changes the protection configuration of a Volume.

```go
ChangeVolumeProtection(
    ctx context.Context,
    id int,
    body *models.VolumesActionsChangeProtectionRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`*models.VolumesActionsChangeProtectionRequest`](../../doc/models/volumes-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.VolumesActionsChangeProtectionRequest{
    Delete:               models.ToPointer(true),
}

apiResponse, err := volumeActionsController.ChangeVolumeProtection(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Detach Volume

Detaches a Volume from the Server it’s attached to. You may attach it to a Server again at a later time.

```go
DetachVolume(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |

## Response Type

**201**: The `action` key contains the `detach_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := volumeActionsController.DetachVolume(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "detach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Resize Volume

Changes the size of a Volume. Note that downsizing a Volume is not possible.

```go
ResizeVolume(
    ctx context.Context,
    id int,
    body *models.VolumesActionsResizeRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`*models.VolumesActionsResizeRequest`](../../doc/models/volumes-actions-resize-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `resize_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.VolumesActionsResizeRequest{
    Size:                 float64(50),
}

apiResponse, err := volumeActionsController.ResizeVolume(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "resize_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Get an Action for a Volume

Returns a specific Action for a Volume.

```go
GetAnActionForAVolume(
    ctx context.Context,
    id int,
    actionId int) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Volume Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

actionId := 224

apiResponse, err := volumeActionsController.GetAnActionForAVolume(ctx, id, actionId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

