
# V2 Databases Config Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesConfigRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `config` | [Config](../../doc/models/config.md) \| [Config1](../../doc/models/config-1.md) \| [Config2](../../doc/models/config-2.md) \| nil | Optional | This is a container for any-of cases. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_config_request = V2DatabasesConfigRequest.new(
  config: Config.new(
    backup_hour: 23,
    backup_minute: 59,
    binlog_retention_period: 600,
    connect_timeout: 196,
    default_time_zone: 'default_time_zone8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

