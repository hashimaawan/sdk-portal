
# Algorithm

Algorithm of the Load Balancer

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```ts
import { Algorithm, Type28Enum } from 'hetzner-cloud-apilib';

const algorithm: Algorithm = {
  type: Type28Enum.RoundRobin,
};
```

