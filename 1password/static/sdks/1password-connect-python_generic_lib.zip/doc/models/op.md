
# Op

## Enumeration

`Op`

## Fields

| Name |
|  --- |
| `ADD` |
| `REMOVE` |
| `REPLACE` |

## Example

```python
from m1passwordconnect.models.op import Op

op = Op.REMOVE
```

