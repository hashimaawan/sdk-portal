
# V2 Registry Options Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2RegistryOptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `options` | [`Options2`](../../doc/models/options-2.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.options_2 import Options2
from digitaloceanapi.models.subscription_tier import SubscriptionTier
from digitaloceanapi.models.v_2_registry_options_response import V2RegistryOptionsResponse

v_2_registry_options_response = V2RegistryOptionsResponse(
    options=Options2(
        available_regions=[
            'available_regions9'
        ],
        subscription_tiers=[
            SubscriptionTier(
                allow_storage_overage=False,
                included_bandwidth_bytes=172,
                included_repositories=194,
                included_storage_bytes=242,
                monthly_price_in_cents=236,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            SubscriptionTier(
                allow_storage_overage=False,
                included_bandwidth_bytes=172,
                included_repositories=194,
                included_storage_bytes=242,
                monthly_price_in_cents=236,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            SubscriptionTier(
                allow_storage_overage=False,
                included_bandwidth_bytes=172,
                included_repositories=194,
                included_storage_bytes=242,
                monthly_price_in_cents=236,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

