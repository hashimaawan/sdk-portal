
# Type 11

The type of the IPv6 network interface.

**Note**: IPv6 private  networking is not currently supported.

## Enumeration

`Type11`

## Fields

| Name |
|  --- |
| `ENUM_PUBLIC` |

## Example

```java
import com.digitalocean.api.models.Type11;

Type11 type11 = Type11.ENUM_PUBLIC;
```

