
# X Amz Target 42

## Enumeration

`XAmzTarget42`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTSESSIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget42;

XAmzTarget42 xAmzTarget42 = XAmzTarget42.ENUM_AMAZONATHENALISTSESSIONS;
```

