
# Ssh Keys Request

*This model accepts additional fields of type unknown.*

## Structure

`SshKeysRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string` | Required | Name of the SSH key |
| `publicKey` | `string` | Required | Public key |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SshKeysRequest } from 'hetzner-cloud-apilib';

const sshKeysRequest: SshKeysRequest = {
  name: 'My ssh key',
  publicKey: 'ssh-rsa AAAjjk76kgf...Xt',
  labels: { 'key1': 'val1', 'key2': 'val2' },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

