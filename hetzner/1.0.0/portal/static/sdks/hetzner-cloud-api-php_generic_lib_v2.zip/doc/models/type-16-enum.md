
# Type 16 Enum

Type of the Floating IP

## Enumeration

`Type16Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```php
use HetznerCloudAPILib\Models\Type16Enum;

$type16 = Type16Enum::IPV4;
```

