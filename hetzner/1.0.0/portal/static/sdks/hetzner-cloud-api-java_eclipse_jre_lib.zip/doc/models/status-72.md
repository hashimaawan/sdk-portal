
# Status 72

Status of the Firewall on the Server

## Enumeration

`Status72`

## Fields

| Name |
|  --- |
| `APPLIED` |
| `PENDING` |

## Example

```java
import cloud.hetzner.api.models.Status72;

Status72 status72 = Status72.APPLIED;
```

