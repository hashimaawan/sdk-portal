
# Sort 8

## Enumeration

`Sort8`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `NAME` |
| `ENUM_NAMEASC` |
| `ENUM_NAMEDESC` |

## Example

```ruby
sort8 = Sort8::ENUM_NAMEASC
```

