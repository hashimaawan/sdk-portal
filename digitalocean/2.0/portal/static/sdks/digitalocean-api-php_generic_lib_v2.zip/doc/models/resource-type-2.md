
# Resource Type 2

The type of the resource.

## Enumeration

`ResourceType2`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `IMAGE` |
| `VOLUME` |
| `VOLUME_SNAPSHOT` |

## Example

```php
use DigitalOceanApiLib\Models\ResourceType2;

$resourceType2 = ResourceType2::VOLUME;
```

