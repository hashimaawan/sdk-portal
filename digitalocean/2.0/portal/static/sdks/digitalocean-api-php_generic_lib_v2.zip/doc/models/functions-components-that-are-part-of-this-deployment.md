
# Functions Components that Are Part of This Deployment

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`FunctionsComponentsThatArePartOfThisDeployment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `namespace` | `?string` | Optional | The namespace where the functions are deployed. | getNamespace(): ?string | setNamespace(?string namespace): void |
| `sourceCommitHash` | `?string` | Optional | The commit hash of the repository that was used to build this functions component. | getSourceCommitHash(): ?string | setSourceCommitHash(?string sourceCommitHash): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\FunctionsComponentsThatArePartOfThisDeploymentBuilder;
use DigitalOceanApiLib\ApiHelper;

$functionsComponentsThatArePartOfThisDeployment = FunctionsComponentsThatArePartOfThisDeploymentBuilder::init()
    ->name('my-functions-component')
    ->namespace('ap-b2a93513-8d9b-4223-9d61-5e7272c81c32')
    ->sourceCommitHash('54d4a727f457231062439895000d45437c7bb405')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

