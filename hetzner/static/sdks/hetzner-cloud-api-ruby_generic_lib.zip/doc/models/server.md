
# Server

## Structure

`Server`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the Resource |

## Example

```ruby
server = Server.new(
  42
)
```

