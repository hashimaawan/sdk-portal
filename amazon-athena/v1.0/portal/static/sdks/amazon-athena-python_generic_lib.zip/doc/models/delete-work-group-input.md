
# Delete Work Group Input

## Structure

`DeleteWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `str` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `recursive_delete_option` | `bool` | Optional | - |

## Example

```python
from amazonathena.models.delete_work_group_input import DeleteWorkGroupInput

delete_work_group_input = DeleteWorkGroupInput(
    work_group='WorkGroup8',
    recursive_delete_option=False
)
```

