
# X Amz Target 56

## Enumeration

`XAmzTarget56`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNotebook` |

## Example

```ts
import { XAmzTarget56 } from 'amazon-athenalib';

const xAmzTarget56 = XAmzTarget56.EnumAmazonAthenaUpdateNotebook;
```

