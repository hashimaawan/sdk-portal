
# Type

Type of the gif. By default, this is almost always gif

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Gif` |

## Example

```go
package main

import (
    "giphyApi/models"
)

func main() {
    mType := models.Type_Gif

}
```

