
# Result Reuse Information

Contains information about whether the result of a previous query was reused.

## Structure

`ResultReuseInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReusedPreviousResult` | `bool` | Required | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

ResultReuseInformation resultReuseInformation = new ResultReuseInformation
{
    ReusedPreviousResult = false,
};
```

