
# Operator

## Enumeration

`Operator`

## Fields

| Name |
|  --- |
| `UNSPECIFIED_OPERATOR` |
| `GREATER_THAN` |
| `LESS_THAN` |

## Example

```php
use DigitalOceanApiLib\Models\Operator;

$operator = Operator::LESS_THAN;
```

