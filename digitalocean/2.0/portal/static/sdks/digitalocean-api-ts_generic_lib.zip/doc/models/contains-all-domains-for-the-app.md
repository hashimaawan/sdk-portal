
# Contains All Domains for the App

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`ContainsAllDomainsForTheApp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `certificateExpiresAt` | `string \| undefined` | Optional, Read-only | - |
| `id` | `string \| undefined` | Optional | - |
| `phase` | [`Phase1 \| undefined`](../../doc/models/phase-1.md) | Optional | **Default**: `Phase1.Unknown` |
| `progress` | [`Progress1 \| undefined`](../../doc/models/progress-1.md) | Optional | - |
| `rotateValidationRecords` | `boolean \| undefined` | Optional, Read-only | - |
| `spec` | [`Domain \| undefined`](../../doc/models/domain.md) | Optional | - |
| `validations` | [`ListOfTxtValidationRecord[] \| undefined`](../../doc/models/list-of-txt-validation-record.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { ContainsAllDomainsForTheApp, Phase1 } from 'digitalocean-apilib';

const containsAllDomainsForTheApp: ContainsAllDomainsForTheApp = {
  certificateExpiresAt: '2024-01-29T23:59:59Z',
  id: '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf',
  phase: Phase1.Active,
  progress: {
    steps: [
      { 'key1': 'val1', 'key2': 'val2' },
      { 'key1': 'val1', 'key2': 'val2' },
      { 'key1': 'val1', 'key2': 'val2' }
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  rotateValidationRecords: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

