
# V2 Droplets Actions Request 2

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `image` | `number \| undefined` | Optional | The ID of a backup of the current Droplet instance to restore from. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type12, V2DropletsActionsRequest2 } from 'digitalocean-apilib';

const v2DropletsActionsRequest2: V2DropletsActionsRequest2 = {
  type: Type12.Reboot,
  image: 12389723,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

