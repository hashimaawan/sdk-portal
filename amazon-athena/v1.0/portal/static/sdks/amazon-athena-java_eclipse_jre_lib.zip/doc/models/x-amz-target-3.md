
# X Amz Target 3

## Enumeration

`XAmzTarget3`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEDATACATALOG` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget3;

XAmzTarget3 xAmzTarget3 = XAmzTarget3.ENUM_AMAZONATHENACREATEDATACATALOG;
```

