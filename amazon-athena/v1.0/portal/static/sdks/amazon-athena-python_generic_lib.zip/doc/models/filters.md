
# Filters

## Structure

`Filters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```python
from amazonathena.models.filters import Filters

filters = Filters(
    name='Name0'
)
```

