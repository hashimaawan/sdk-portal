
# Pagination

The Pagination Object contains information relating to the number of total results available as well as the number of results fetched and their relative positions.

*This model accepts additional fields of type object.*

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Count` | `int?` | Optional | Total number of items returned. |
| `Offset` | `int?` | Optional | Position in pagination. |
| `TotalCount` | `int?` | Optional | Total number of items available. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using GiphyApi.Standard.Models;
using GiphyApi.Standard.Utilities;

Pagination pagination = new Pagination
{
    Count = 25,
    Offset = 75,
    TotalCount = 250,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

