
# X Amz Target 39 Enum

## Enumeration

`XAmzTarget39Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```ruby
x_amz_target39 = XAmzTarget39Enum::ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS
```

