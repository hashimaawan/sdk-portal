
# Result Configuration 1

## Structure

`ResultConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OutputLocation` | `string` | Optional | - |
| `EncryptionConfiguration` | [`EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - |
| `ExpectedBucketOwner` | `string` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` |
| `AclConfiguration` | [`AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

ResultConfiguration1 resultConfiguration1 = new ResultConfiguration1
{
    OutputLocation = "OutputLocation4",
    EncryptionConfiguration = new EncryptionConfiguration2
    {
        EncryptionOption = EncryptionOption1Enum.SSES3,
        KmsKey = "KmsKey6",
    },
    ExpectedBucketOwner = "ExpectedBucketOwner4",
    AclConfiguration = new AclConfiguration1
    {
        S3AclOption = S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
    },
};
```

