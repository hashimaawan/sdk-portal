
# X Amz Target 2

## Enumeration

`XAmzTarget2`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```ruby
x_amz_target2 = XAmzTarget2::ENUM_AMAZONATHENABATCHGETQUERYEXECUTION
```

