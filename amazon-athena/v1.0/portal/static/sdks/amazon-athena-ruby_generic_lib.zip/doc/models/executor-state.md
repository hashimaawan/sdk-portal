
# Executor State

## Enumeration

`ExecutorState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```ruby
executor_state = ExecutorState::TERMINATED
```

