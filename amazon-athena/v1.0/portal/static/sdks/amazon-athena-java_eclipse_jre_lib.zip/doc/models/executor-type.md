
# Executor Type

## Enumeration

`ExecutorType`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```java
import com.amazonaws.useast1.athena.models.ExecutorType;

ExecutorType executorType = ExecutorType.GATEWAY;
```

