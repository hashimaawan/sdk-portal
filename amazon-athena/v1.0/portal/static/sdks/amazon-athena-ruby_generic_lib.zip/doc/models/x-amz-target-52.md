
# X Amz Target 52

## Enumeration

`XAmzTarget52`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATERMINATESESSION` |

## Example

```ruby
x_amz_target52 = XAmzTarget52::ENUM_AMAZONATHENATERMINATESESSION
```

