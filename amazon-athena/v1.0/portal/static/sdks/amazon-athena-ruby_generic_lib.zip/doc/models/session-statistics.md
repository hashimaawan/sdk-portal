
# Session Statistics

Contains statistics for a session.

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `Integer` | Optional | - |

## Example

```ruby
session_statistics = SessionStatistics.new(
  136
)
```

