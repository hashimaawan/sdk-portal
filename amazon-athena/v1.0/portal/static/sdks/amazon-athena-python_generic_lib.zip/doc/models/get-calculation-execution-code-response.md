
# Get Calculation Execution Code Response

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code_block` | `str` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```python
from amazonathena.models.get_calculation_execution_code_response import GetCalculationExecutionCodeResponse

get_calculation_execution_code_response = GetCalculationExecutionCodeResponse(
    code_block='CodeBlock2'
)
```

