
# Status 16

## Enumeration

`Status16`

## Fields

| Name |
|  --- |
| `DOWN` |
| `UP` |
| `CHECKING` |

## Example

```ruby
status16 = Status16::DOWN
```

