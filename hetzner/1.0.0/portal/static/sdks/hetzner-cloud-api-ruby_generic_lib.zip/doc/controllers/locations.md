# Locations

Datacenters are organized by Locations. Datacenters in the same Location are connected with very low latency links.

```ruby
locations_api = client.locations
```

## Class Name

`LocationsApi`

## Methods

* [Get All Locations](../../doc/controllers/locations.md#get-all-locations)
* [Get a Location](../../doc/controllers/locations.md#get-a-location)


# Get All Locations

Returns all Location objects.

```ruby
def get_all_locations(name: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter Locations by their name. The response will only contain the Location matching the specified name. |

## Response Type

**200**: The `locations` key in the reply contains an array of Location objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`LocationsResponse`](../../doc/models/locations-response.md).

## Example Usage

```ruby
result = locations_api.get_all_locations

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get a Location

Returns a specific Location object.

```ruby
def get_a_location(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of Location |

## Response Type

**200**: The `location` key in the reply contains a Location object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`LocationsResponse1`](../../doc/models/locations-response-1.md).

## Example Usage

```ruby
id = 112

result = locations_api.get_a_location(id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

