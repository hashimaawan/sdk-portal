
# Session State

## Enumeration

`SessionState`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Idle` |
| `Busy` |
| `Terminating` |
| `Terminated` |
| `Degraded` |
| `Failed` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    sessionState := models.SessionState_Terminating

}
```

