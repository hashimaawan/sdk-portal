
# Type 26

Type of the ISO

## Enumeration

`Type26`

## Fields

| Name |
|  --- |
| `PUBLIC` |
| `PRIVATE` |

## Example

```ruby
type26 = Type26::PUBLIC
```

