
# Interface

## Enumeration

`Interface`

## Fields

| Name |
|  --- |
| `Private` |
| `Public` |

## Example

```ts
import { Interface } from 'digitalocean-apilib';

const mInterface = Interface.Private;
```

