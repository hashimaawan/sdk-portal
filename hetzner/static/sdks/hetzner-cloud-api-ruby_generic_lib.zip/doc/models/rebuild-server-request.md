
# Rebuild Server Request

## Structure

`RebuildServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image` | `String` | Required | ID or name of Image to rebuilt from. |

## Example

```ruby
rebuild_server_request = RebuildServerRequest.new(
  'ubuntu-20.04'
)
```

