
# X Amz Target 32

## Enumeration

`XAmzTarget32`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistcalculationexecutions` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget32 := models.XAmzTarget32_EnumAmazonathenalistcalculationexecutions

}
```

