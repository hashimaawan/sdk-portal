
# Floating Ip 5

## Structure

`FloatingIp5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prices` | [`Array[Price6]`](../../doc/models/price-6.md) | Required | Floating IP type costs per Location |
| `type` | [`Type48Enum`](../../doc/models/type-48-enum.md) | Required | The type of the Floating IP |

## Example

```ruby
floating_ip5 = FloatingIp5.new(
  [
    Price6.new(
      'fsn1',
      PriceMonthly7.new(
        '1.1900000000000000',
        '1.0000000000'
      )
    )
  ],
  Type48Enum::IPV4
)
```

