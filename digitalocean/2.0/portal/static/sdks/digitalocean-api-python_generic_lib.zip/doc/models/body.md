
# Body

Optional data to be sent to function while triggering the function.

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Body`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.body import Body

body = Body(
    name='Welcome to DO!',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

