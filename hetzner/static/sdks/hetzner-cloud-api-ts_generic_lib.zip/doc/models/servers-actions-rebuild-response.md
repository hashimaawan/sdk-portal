
# Servers Actions Rebuild Response

## Structure

`ServersActionsRebuildResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action \| undefined`](../../doc/models/action.md) | Optional | - |
| `rootPassword` | `string \| null \| undefined` | Optional | New root password when not using SSH keys |

## Example

```ts
import {
  ServersActionsRebuildResponse,
  StatusEnum,
} from 'hetzner-cloud-apilib';

const serversActionsRebuildResponse: ServersActionsRebuildResponse = {
  action: {
    command: 'command6',
    error: {
      code: 'code2',
      message: 'message4',
    },
    finished: 'finished0',
    id: 238,
    progress: 143.26,
    resources: [
      {
        id: 198,
        type: 'type0',
      },
      {
        id: 198,
        type: 'type0',
      },
      {
        id: 198,
        type: 'type0',
      }
    ],
    started: 'started8',
    status: StatusEnum.Running,
  },
  rootPassword: 'root_password6',
};
```

