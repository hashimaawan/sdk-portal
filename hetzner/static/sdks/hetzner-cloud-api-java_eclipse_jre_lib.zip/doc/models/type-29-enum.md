
# Type 29 Enum

Type of the resource

## Enumeration

`Type29Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |
| `IP` |

## Example

```java
import cloud.hetzner.api.models.Type29Enum;

Type29Enum type29 = Type29Enum.SERVER;
```

