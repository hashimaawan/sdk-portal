
# X Amz Target 36

## Enumeration

`XAmzTarget36`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTEXECUTORS` |

## Example

```python
from amazonathena.models.x_amz_target_36 import XAmzTarget36

x_amz_target_36 = XAmzTarget36.ENUM_AMAZONATHENALISTEXECUTORS
```

