
# Logtail

Logtail configuration.

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Logtail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `String` | Optional | Logtail token. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
logtail = Logtail.new(
  token: 'abcdefghijklmnopqrstuvwxyz0123456789',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

