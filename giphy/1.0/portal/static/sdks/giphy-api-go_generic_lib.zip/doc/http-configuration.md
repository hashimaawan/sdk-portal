
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`giphyApiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `giphyApi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "giphyApi"
    "net/http"
)

func main() {
    httpConfiguration := giphyApi.CreateHttpConfiguration(
        giphyApi.WithTimeout(30),
        giphyApi.WithTransport(http.DefaultTransport),
        giphyApi.WithRetryConfiguration(giphyApi.DefaultRetryConfiguration()),
    )
}
```

