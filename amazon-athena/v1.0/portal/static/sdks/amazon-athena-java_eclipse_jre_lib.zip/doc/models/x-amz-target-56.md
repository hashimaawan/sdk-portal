
# X Amz Target 56

## Enumeration

`XAmzTarget56`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget56;

XAmzTarget56 xAmzTarget56 = XAmzTarget56.ENUM_AMAZONATHENAUPDATENOTEBOOK;
```

