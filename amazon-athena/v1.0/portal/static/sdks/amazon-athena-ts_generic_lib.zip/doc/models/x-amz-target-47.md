
# X Amz Target 47

## Enumeration

`XAmzTarget47`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartQueryExecution` |

## Example

```ts
import { XAmzTarget47 } from 'amazon-athenalib';

const xAmzTarget47 = XAmzTarget47.EnumAmazonAthenaStartQueryExecution;
```

