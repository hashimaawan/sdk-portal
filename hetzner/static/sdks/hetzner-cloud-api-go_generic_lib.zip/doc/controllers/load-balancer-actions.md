# Load Balancer Actions

```go
loadBalancerActionsController := client.LoadBalancerActionsController()
```

## Class Name

`LoadBalancerActionsController`

## Methods

* [Get All Actions for a Load Balancer](../../doc/controllers/load-balancer-actions.md#get-all-actions-for-a-load-balancer)
* [Add Service](../../doc/controllers/load-balancer-actions.md#add-service)
* [Add Target](../../doc/controllers/load-balancer-actions.md#add-target)
* [Attach a Load Balancer to a Network](../../doc/controllers/load-balancer-actions.md#attach-a-load-balancer-to-a-network)
* [Change Algorithm](../../doc/controllers/load-balancer-actions.md#change-algorithm)
* [Change Reverse DNS Entry for This Load Balancer](../../doc/controllers/load-balancer-actions.md#change-reverse-dns-entry-for-this-load-balancer)
* [Change Load Balancer Protection](../../doc/controllers/load-balancer-actions.md#change-load-balancer-protection)
* [Change the Type of a Load Balancer](../../doc/controllers/load-balancer-actions.md#change-the-type-of-a-load-balancer)
* [Delete Service](../../doc/controllers/load-balancer-actions.md#delete-service)
* [Detach a Load Balancer from a Network](../../doc/controllers/load-balancer-actions.md#detach-a-load-balancer-from-a-network)
* [Disable the Public Interface of a Load Balancer](../../doc/controllers/load-balancer-actions.md#disable-the-public-interface-of-a-load-balancer)
* [Enable the Public Interface of a Load Balancer](../../doc/controllers/load-balancer-actions.md#enable-the-public-interface-of-a-load-balancer)
* [Remove Target](../../doc/controllers/load-balancer-actions.md#remove-target)
* [Update Service](../../doc/controllers/load-balancer-actions.md#update-service)
* [Get an Action for a Load Balancer](../../doc/controllers/load-balancer-actions.md#get-an-action-for-a-load-balancer)


# Get All Actions for a Load Balancer

Returns all Action objects for a Load Balancer. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```go
GetAllActionsForALoadBalancer(
    ctx context.Context,
    id int,
    sort *models.ParameterSortEnum,
    status *models.ParameterStatusEnum) (
    models.ApiResponse[models.ActionsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `sort` | [`*models.ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`*models.ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := loadBalancerActionsController.GetAllActionsForALoadBalancer(ctx, id, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "add_service",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 4711,
          "type": "load_balancer"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Add Service

Adds a service to a Load Balancer.

#### Call specific error codes

| Code                       | Description                                             |
|----------------------------|---------------------------------------------------------|
| `source_port_already_used` | The source port you are trying to add is already in use |

```go
AddService(
    ctx context.Context,
    id int,
    body *models.LoadBalancerService) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.LoadBalancerService`](../../doc/models/load-balancer-service.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `add_service` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.LoadBalancerService{
    DestinationPort:      80,
    HealthCheck:          models.LoadBalancerServiceHealthCheck{
        Interval: 15,
        Port:     4711,
        Protocol: models.Protocol6Enum_HTTP,
        Retries:  3,
        Timeout:  10,
    },
    ListenPort:           443,
    Protocol:             models.Protocol7Enum_HTTPS,
    Proxyprotocol:        false,
}

apiResponse, err := loadBalancerActionsController.AddService(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Add Target

Adds a target to a Load Balancer.

#### Call specific error codes

| Code                                    | Description                                                                                           |
|-----------------------------------------|-------------------------------------------------------------------------------------------------------|
| `cloud_resource_ip_not_allowed`         | The IP you are trying to add as a target belongs to a Hetzner Cloud resource                          |
| `ip_not_owned`                          | The IP you are trying to add as a target is not owned by the Project owner                            |
| `load_balancer_not_attached_to_network` | The Load Balancer is not attached to a network                                                        |
| `robot_unavailable`                     | Robot was not available. The caller may retry the operation after a short delay.                      |
| `server_not_attached_to_network`        | The server you are trying to add as a target is not attached to the same network as the Load Balancer |
| `target_already_defined`                | The Load Balancer target you are trying to define is already defined                                  |

```go
AddTarget(
    ctx context.Context,
    id int,
    body *models.AddTargetRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.AddTargetRequest`](../../doc/models/add-target-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `add_target` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.AddTargetRequest{
    Type:                 models.Type29Enum_LABELSELECTOR,
    UsePrivateIp:         models.ToPointer(true),
}

apiResponse, err := loadBalancerActionsController.AddTarget(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_target",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Attach a Load Balancer to a Network

Attach a Load Balancer to a Network.

**Call specific error codes**

| Code                             | Description                                                           |
|----------------------------------|-----------------------------------------------------------------------|
| `load_balancer_already_attached` | The Load Balancer is already attached to a network                    |
| `ip_not_available`               | The provided Network IP is not available                              |
| `no_subnet_available`            | No Subnet or IP is available for the Load Balancer within the network |

```go
AttachALoadBalancerToANetwork(
    ctx context.Context,
    id int,
    body *models.LoadBalancersActionsAttachToNetworkRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.LoadBalancersActionsAttachToNetworkRequest`](../../doc/models/load-balancers-actions-attach-to-network-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `attach_to_network` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.LoadBalancersActionsAttachToNetworkRequest{
    Ip:                   models.ToPointer("10.0.1.1"),
    Network:              float64(4711),
}

apiResponse, err := loadBalancerActionsController.AttachALoadBalancerToANetwork(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_to_network",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Algorithm

Change the algorithm that determines to which target new requests are sent.

```go
ChangeAlgorithm(
    ctx context.Context,
    id int,
    body *models.LoadBalancersActionsChangeAlgorithmRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.LoadBalancersActionsChangeAlgorithmRequest`](../../doc/models/load-balancers-actions-change-algorithm-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_algorithm` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := loadBalancerActionsController.ChangeAlgorithm(ctx, id, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_algorithm",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Reverse DNS Entry for This Load Balancer

Changes the hostname that will appear when getting the hostname belonging to the public IPs (IPv4 and IPv6) of this Load Balancer.

Floating IPs assigned to the Server are not affected by this.

```go
ChangeReverseDNSEntryForThisLoadBalancer(
    ctx context.Context,
    id int,
    body *models.ChangeLoadbalancerDnsPtrRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.ChangeLoadbalancerDnsPtrRequest`](../../doc/models/change-loadbalancer-dns-ptr-request.md) | Body, Optional | Select the IP address for which to change the DNS entry by passing `ip`. It can be either IPv4 or IPv6. The target hostname is set by passing `dns_ptr`. |

## Response Type

**201**: The `action` key in the reply contains an Action object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.ChangeLoadbalancerDnsPtrRequest{
    DnsPtr:               models.ToPointer("lb1.example.com"),
    Ip:                   "1.2.3.4",
}

apiResponse, err := loadBalancerActionsController.ChangeReverseDNSEntryForThisLoadBalancer(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_dns_ptr",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Load Balancer Protection

Changes the protection configuration of a Load Balancer.

```go
ChangeLoadBalancerProtection(
    ctx context.Context,
    id int,
    body *models.LoadBalancersActionsChangeProtectionRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.LoadBalancersActionsChangeProtectionRequest`](../../doc/models/load-balancers-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.LoadBalancersActionsChangeProtectionRequest{
    Delete:               models.ToPointer(true),
}

apiResponse, err := loadBalancerActionsController.ChangeLoadBalancerProtection(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change the Type of a Load Balancer

Changes the type (Max Services, Max Targets and Max Connections) of a Load Balancer.

**Call specific error codes**

| Code                         | Description                                                     |
|------------------------------|-----------------------------------------------------------------|
| `invalid_load_balancer_type` | The Load Balancer type does not fit for the given Load Balancer |

```go
ChangeTheTypeOfALoadBalancer(
    ctx context.Context,
    id int,
    body *models.ChangeTypeRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.ChangeTypeRequest`](../../doc/models/change-type-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_load_balancer_type` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.ChangeTypeRequest{
    LoadBalancerType:     "lb21",
}

apiResponse, err := loadBalancerActionsController.ChangeTheTypeOfALoadBalancer(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_load_balancer_type",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Delete Service

Delete a service of a Load Balancer.

```go
DeleteService(
    ctx context.Context,
    id int,
    body *models.LoadBalancersActionsDeleteServiceRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.LoadBalancersActionsDeleteServiceRequest`](../../doc/models/load-balancers-actions-delete-service-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `delete_service` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.LoadBalancersActionsDeleteServiceRequest{
    ListenPort:           float64(4711),
}

apiResponse, err := loadBalancerActionsController.DeleteService(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "delete_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Detach a Load Balancer from a Network

Detaches a Load Balancer from a network.

```go
DetachALoadBalancerFromANetwork(
    ctx context.Context,
    id int,
    body *models.LoadBalancersActionsDetachFromNetworkRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.LoadBalancersActionsDetachFromNetworkRequest`](../../doc/models/load-balancers-actions-detach-from-network-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `detach_from_network` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.LoadBalancersActionsDetachFromNetworkRequest{
    Network:              float64(4711),
}

apiResponse, err := loadBalancerActionsController.DetachALoadBalancerFromANetwork(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "detach_from_network",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Disable the Public Interface of a Load Balancer

Disable the public interface of a Load Balancer. The Load Balancer will be not accessible from the internet via its public IPs.

#### Call specific error codes

| Code                                      | Description                                                                    |
|-------------------------------------------|--------------------------------------------------------------------------------|
| `load_balancer_not_attached_to_network`   |  The Load Balancer is not attached to a network                                |
| `targets_without_use_private_ip`          | The Load Balancer has targets that use the public IP instead of the private IP |

```go
DisableThePublicInterfaceOfALoadBalancer(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |

## Response Type

**201**: The `action` key contains the `disable_public_interface` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := loadBalancerActionsController.DisableThePublicInterfaceOfALoadBalancer(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "disable_public_interface",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Enable the Public Interface of a Load Balancer

Enable the public interface of a Load Balancer. The Load Balancer will be accessible from the internet via its public IPs.

```go
EnableThePublicInterfaceOfALoadBalancer(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |

## Response Type

**201**: The `action` key contains the `enable_public_interface` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := loadBalancerActionsController.EnableThePublicInterfaceOfALoadBalancer(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "enable_public_interface",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Remove Target

Removes a target from a Load Balancer.

```go
RemoveTarget(
    ctx context.Context,
    id int,
    body *models.RemoveTargetRequest) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.RemoveTargetRequest`](../../doc/models/remove-target-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `remove_target` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := loadBalancerActionsController.RemoveTarget(ctx, id, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "remove_target",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Update Service

Updates a Load Balancer Service.

#### Call specific error codes

| Code                       | Description                                             |
|----------------------------|---------------------------------------------------------|
| `source_port_already_used` | The source port you are trying to add is already in use |

```go
UpdateService(
    ctx context.Context,
    id int,
    body *models.LoadBalancerService) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`*models.LoadBalancerService`](../../doc/models/load-balancer-service.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `update_service` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.LoadBalancerService{
    DestinationPort:      80,
    HealthCheck:          models.LoadBalancerServiceHealthCheck{
        Interval: 15,
        Port:     4711,
        Protocol: models.Protocol6Enum_HTTP,
        Retries:  3,
        Timeout:  10,
    },
    ListenPort:           443,
    Protocol:             models.Protocol7Enum_HTTPS,
    Proxyprotocol:        false,
}

apiResponse, err := loadBalancerActionsController.UpdateService(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "update_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for a Load Balancer

Returns a specific Action for a Load Balancer.

```go
GetAnActionForALoadBalancer(
    ctx context.Context,
    id int,
    actionId int) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Load Balancer Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

actionId := 224

apiResponse, err := loadBalancerActionsController.GetAnActionForALoadBalancer(ctx, id, actionId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

