
# V2 Monitoring Alerts Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2MonitoringAlertsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `policies` | [`Array[Policy]`](../../doc/models/policy.md) | Required | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_monitoring_alerts_response = V2MonitoringAlertsResponse.new(
  policies: [
    Policy.new(
      alerts: Alerts.new(
        email: [
          'bob@exmaple.com'
        ],
        slack: [
          Slack.new(
            channel: 'Production Alerts',
            url: 'https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ',
            additional_properties: {
              'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
            }
          )
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      compare: Compare::GREATERTHAN,
      description: 'CPU Alert',
      enabled: true,
      entities: [
        '192018292'
      ],
      tags: [
        'droplet_tag'
      ],
      type: Type17::ENUM_V1INSIGHTSDROPLETCPU,
      uuid: '78b3da62-27e5-49ba-ac70-5db0b5935c64',
      value: 80,
      window: Window1::ENUM_5M,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

