
# V2 Apps Deployments Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2AppsDeploymentsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `forceBuild` | `?bool` | Optional | - | getForceBuild(): ?bool | setForceBuild(?bool forceBuild): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2AppsDeploymentsRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2AppsDeploymentsRequest = V2AppsDeploymentsRequestBuilder::init()
    ->forceBuild(true)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

