
# Update Placement Group Request

*This model accepts additional fields of type Object.*

## Structure

`UpdatePlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New PlacementGroup name |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
update_placement_group_request = UpdatePlacementGroupRequest.new(
  labels: { 'labelkey' => 'value' },
  name: 'my Placement Group',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

