
# Work Group State 1 Enum

The state of the workgroup.

## Enumeration

`WorkGroupState1Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    workGroupState1 := models.WorkGroupState1Enum_ENABLED

}
```

