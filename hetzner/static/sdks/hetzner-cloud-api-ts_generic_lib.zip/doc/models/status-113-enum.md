
# Status 113 Enum

Current status of the Volume

## Enumeration

`Status113Enum`

## Fields

| Name |
|  --- |
| `Creating` |
| `Available` |

## Example

```ts
import { Status113Enum } from 'hetzner-cloud-apilib';

const status113 = Status113Enum.Creating;
```

