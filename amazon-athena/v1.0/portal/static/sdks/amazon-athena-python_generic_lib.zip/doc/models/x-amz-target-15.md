
# X Amz Target 15

## Enumeration

`XAmzTarget15`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_15 import XAmzTarget15

x_amz_target_15 = XAmzTarget15.ENUM_AMAZONATHENAGETCALCULATIONEXECUTION
```

