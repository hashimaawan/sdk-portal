
# X Amz Target 31 Enum

## Enumeration

`XAmzTarget31Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget31Enum;

XAmzTarget31Enum xAmzTarget31 = XAmzTarget31Enum.ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES;
```

