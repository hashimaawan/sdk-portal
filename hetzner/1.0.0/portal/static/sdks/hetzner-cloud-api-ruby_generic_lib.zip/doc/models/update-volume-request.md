
# Update Volume Request

*This model accepts additional fields of type Object.*

## Structure

`UpdateVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Required | New Volume name |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
update_volume_request = UpdateVolumeRequest.new(
  name: 'database-storage',
  labels: Labels2.new(
    labelkey: 'labelkey4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

