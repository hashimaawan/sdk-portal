
# Change DNSPTR Request

## Structure

`ChangeDNSPTRRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dnsPtr` | `string \| null` | Required | Hostname to set as a reverse DNS PTR entry, will reset to original default value if `null` |
| `ip` | `string` | Required | IP address for which to set the reverse DNS entry |

## Example

```ts
import { ChangeDNSPTRRequest } from 'hetzner-cloud-apilib';

const changeDNSPTRRequest: ChangeDNSPTRRequest = {
  dnsPtr: 'server02.example.com',
  ip: '1.2.3.4',
};
```

