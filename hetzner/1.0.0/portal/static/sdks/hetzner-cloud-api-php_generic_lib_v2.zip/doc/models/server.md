
# Server

## Structure

`Server`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Resource | getId(): int | setId(int id): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ServerBuilder;

$server = ServerBuilder::init(
    42
)->build();
```

