
# Type Enum

Type of the Certificate

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```ts
import { TypeEnum } from 'hetzner-cloud-apilib';

const type = TypeEnum.Uploaded;
```

