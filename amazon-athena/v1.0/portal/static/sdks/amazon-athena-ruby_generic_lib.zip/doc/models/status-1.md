
# Status 1

## Structure

`Status1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `submission_date_time` | `DateTime` | Optional | - |
| `completion_date_time` | `DateTime` | Optional | - |
| `state` | [`CalculationExecutionState1Enum`](../../doc/models/calculation-execution-state-1-enum.md) | Optional | - |
| `state_change_reason` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
status1 = Status1.new(
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  CalculationExecutionState1Enum::QUEUED,
  'StateChangeReason0'
)
```

