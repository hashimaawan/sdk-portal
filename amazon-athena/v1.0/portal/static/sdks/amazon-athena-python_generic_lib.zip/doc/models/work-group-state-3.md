
# Work Group State 3

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```python
from amazonathena.models.work_group_state_3 import WorkGroupState3

work_group_state_3 = WorkGroupState3.ENABLED
```

