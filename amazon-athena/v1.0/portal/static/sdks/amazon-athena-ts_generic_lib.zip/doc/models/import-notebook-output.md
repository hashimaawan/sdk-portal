
# Import Notebook Output

## Structure

`ImportNotebookOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```ts
import { ImportNotebookOutput } from 'amazon-athenalib';

const importNotebookOutput: ImportNotebookOutput = {
  notebookId: 'NotebookId2',
};
```

