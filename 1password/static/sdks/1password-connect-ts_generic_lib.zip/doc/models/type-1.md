
# Type 1

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `String` |
| `Email` |
| `Concealed` |
| `Url` |
| `Totp` |
| `Date` |
| `MonthYear` |
| `Menu` |

## Example

```ts
import { Type1 } from 'm-1-password-connectlib';

const type1 = Type1.Concealed;
```

