
# Type 39

Algorithm of the Load Balancer

## Enumeration

`Type39`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```ruby
type39 = Type39::ROUND_ROBIN
```

