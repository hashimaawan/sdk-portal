
# List Sessions Request

*This model accepts additional fields of type interface{}.*

## Structure

`ListSessionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `StateFilter` | [`*models.SessionState3`](../../doc/models/session-state-3.md) | Optional | - |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `*string` | Optional | **Constraints**: *Maximum Length*: `2048` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    listSessionsRequest := models.ListSessionsRequest{
        WorkGroup:             "WorkGroup8",
        StateFilter:           models.ToPointer(models.SessionState3_Creating),
        MaxResults:            models.ToPointer(100),
        NextToken:             models.ToPointer("NextToken6"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

