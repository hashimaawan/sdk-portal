
# Query Execution

Information about a single instance of a query execution.

## Structure

`QueryExecution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `Query` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `StatementType` | [`*models.StatementType1Enum`](../../doc/models/statement-type-1-enum.md) | Optional | - |
| `ResultConfiguration` | [`*models.ResultConfiguration1`](../../doc/models/result-configuration-1.md) | Optional | - |
| `ResultReuseConfiguration` | [`*models.ResultReuseConfiguration1`](../../doc/models/result-reuse-configuration-1.md) | Optional | - |
| `QueryExecutionContext` | [`*models.QueryExecutionContext1`](../../doc/models/query-execution-context-1.md) | Optional | - |
| `Status` | [`*models.Status`](../../doc/models/status.md) | Optional | - |
| `Statistics` | [`*models.Statistics`](../../doc/models/statistics.md) | Optional | - |
| `WorkGroup` | `*string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `EngineVersion` | [`*models.EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - |
| `ExecutionParameters` | `[]string` | Optional | **Constraints**: *Minimum Items*: `1`, *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `SubstatementType` | `*string` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    queryExecution := models.QueryExecution{
        QueryExecutionId:         models.ToPointer("QueryExecutionId4"),
        Query:                    models.ToPointer("Query2"),
        StatementType:            models.ToPointer(models.StatementType1Enum_DML),
        ResultConfiguration:      models.ToPointer(models.ResultConfiguration1{
            OutputLocation:          models.ToPointer("OutputLocation0"),
            EncryptionConfiguration: models.ToPointer(models.EncryptionConfiguration2{
                EncryptionOption:     models.EncryptionOption1Enum_SSES3,
                KmsKey:               models.ToPointer("KmsKey6"),
            }),
            ExpectedBucketOwner:     models.ToPointer("ExpectedBucketOwner0"),
            AclConfiguration:        models.ToPointer(models.AclConfiguration1{
                S3AclOption:          models.S3AclOption1Enum_BUCKETOWNERFULLCONTROL,
            }),
        }),
        ResultReuseConfiguration: models.ToPointer(models.ResultReuseConfiguration1{
            ResultReuseByAgeConfiguration: models.ToPointer(models.ResultReuseByAgeConfiguration2{
                Enabled:              false,
                MaxAgeInMinutes:      models.ToPointer(26),
            }),
        }),
    }

}
```

