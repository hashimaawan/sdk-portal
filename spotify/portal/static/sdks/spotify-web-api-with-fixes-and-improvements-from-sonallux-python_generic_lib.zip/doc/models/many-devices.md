
# Many Devices

*This model accepts additional fields of type Any.*

## Structure

`ManyDevices`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `devices` | [`List[DeviceObject]`](../../doc/models/device-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from spotifywebapiwithfixesandimprovementsfromsonallux.models.device_object import DeviceObject
from spotifywebapiwithfixesandimprovementsfromsonallux.models.many_devices import ManyDevices

many_devices = ManyDevices(
    devices=[
        DeviceObject(
            id='id4',
            is_active=False,
            is_private_session=False,
            is_restricted=False,
            name='Kitchen speaker',
            mtype='computer',
            volume_percent=59,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

