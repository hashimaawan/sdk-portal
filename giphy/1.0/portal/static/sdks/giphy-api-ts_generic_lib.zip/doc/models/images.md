
# Images

An object containing data for various available formats and sizes of this GIF.

*This model accepts additional fields of type unknown.*

## Structure

`Images`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `downsized` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `downsizedLarge` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `downsizedMedium` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `downsizedSmall` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `downsizedStill` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedHeight` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedHeightDownsampled` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedHeightSmall` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedHeightSmallStill` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedHeightStill` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedWidth` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedWidthDownsampled` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedWidthSmall` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedWidthSmallStill` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `fixedWidthStill` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `looping` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `original` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `originalStill` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `preview` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `previewGif` | [`Image \| undefined`](../../doc/models/image.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Images } from 'giphy-apilib';

const images: Images = {
  downsized: {
    frames: 'frames0',
    height: 'height8',
    mp4: 'mp40',
    mp4Size: 'mp4_size2',
    size: 'size2',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  downsizedLarge: {
    frames: 'frames6',
    height: 'height4',
    mp4: 'mp46',
    mp4Size: 'mp4_size8',
    size: 'size8',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  downsizedMedium: {
    frames: 'frames2',
    height: 'height0',
    mp4: 'mp42',
    mp4Size: 'mp4_size4',
    size: 'size4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  downsizedSmall: {
    frames: 'frames0',
    height: 'height8',
    mp4: 'mp40',
    mp4Size: 'mp4_size2',
    size: 'size2',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  downsizedStill: {
    frames: 'frames4',
    height: 'height4',
    mp4: 'mp46',
    mp4Size: 'mp4_size8',
    size: 'size2',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

