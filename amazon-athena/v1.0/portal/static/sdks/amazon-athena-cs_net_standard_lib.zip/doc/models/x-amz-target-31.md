
# X Amz Target 31

## Enumeration

`XAmzTarget31`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListApplicationDpuSizes` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget31 xAmzTarget31 = XAmzTarget31.EnumAmazonAthenaListApplicationDpuSizes;
```

