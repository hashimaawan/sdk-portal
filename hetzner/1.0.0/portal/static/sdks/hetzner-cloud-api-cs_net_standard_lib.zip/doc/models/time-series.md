
# Time Series

## Structure

`TimeSeries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Values` | [`List<List<TimeSeriesValues>>`](../../doc/models/containers/time-series-values.md) | Required | This is 2d List of a container for one-of cases. |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using HetznerCloudAPI.Standard.Models.Containers;
using System.Collections.Generic;

TimeSeries timeSeries = new TimeSeries
{
    Values = new List<List<TimeSeriesValues>>
    {
        new List<TimeSeriesValues>
        {
            TimeSeriesValues.FromPrecision(138.94),
            TimeSeriesValues.FromPrecision(138.95),
        },
        new List<TimeSeriesValues>
        {
            TimeSeriesValues.FromPrecision(138.94),
            TimeSeriesValues.FromPrecision(138.95),
        },
    },
};
```

