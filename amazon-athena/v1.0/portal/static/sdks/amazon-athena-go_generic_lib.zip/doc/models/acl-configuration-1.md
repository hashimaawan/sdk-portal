
# Acl Configuration 1

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `S3AclOption` | [`models.S3AclOption1Enum`](../../doc/models/s3-acl-option-1-enum.md) | Required | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    aclConfiguration1 := models.AclConfiguration1{
        S3AclOption:          models.S3AclOption1Enum_BUCKETOWNERFULLCONTROL,
    }

}
```

