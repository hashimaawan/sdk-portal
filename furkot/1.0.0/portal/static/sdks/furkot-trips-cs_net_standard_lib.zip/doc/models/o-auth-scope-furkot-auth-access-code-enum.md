
# O Auth Scope Furkot Auth Access Code Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthAccessCodeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `Readtrips` | list trips and stops info |

## Example

```csharp
using FurkotTrips.Standard.Models;

OAuthScopeFurkotAuthAccessCodeEnum oAuthScopeFurkotAuthAccessCode = OAuthScopeFurkotAuthAccessCodeEnum.Readtrips;
```

