
# List Application DPU Sizes Output

## Structure

`ListApplicationDPUSizesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ApplicationDPUSizes` | [`[]models.ApplicationDPUSizes`](../../doc/models/application-dpu-sizes.md) | Optional | - |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listApplicationDPUSizesOutput := models.ListApplicationDPUSizesOutput{
        ApplicationDPUSizes:  []models.ApplicationDPUSizes{
            models.ApplicationDPUSizes{
                ApplicationRuntimeId: models.ToPointer("ApplicationRuntimeId0"),
                SupportedDPUSizes:    []int{
                    113,
                    114,
                },
            },
            models.ApplicationDPUSizes{
                ApplicationRuntimeId: models.ToPointer("ApplicationRuntimeId0"),
                SupportedDPUSizes:    []int{
                    113,
                    114,
                },
            },
        },
        NextToken:            models.ToPointer("NextToken0"),
    }

}
```

