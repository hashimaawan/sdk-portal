
# X Amz Target 33

## Enumeration

`XAmzTarget33`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATACATALOGS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget33;

XAmzTarget33 xAmzTarget33 = XAmzTarget33.ENUM_AMAZONATHENALISTDATACATALOGS;
```

