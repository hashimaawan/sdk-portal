
# Server Types Response

*This model accepts additional fields of type Any.*

## Structure

`ServerTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server_types` | [`List[ServerTypes7]`](../../doc/models/server-types-7.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.cpu_type import CpuType
from hetznercloudapi.models.price_9 import Price9
from hetznercloudapi.models.price_hourly_8 import PriceHourly8
from hetznercloudapi.models.price_monthly_10 import PriceMonthly10
from hetznercloudapi.models.server_types_7 import ServerTypes7
from hetznercloudapi.models.server_types_response import ServerTypesResponse
from hetznercloudapi.models.storage_type import StorageType

server_types_response = ServerTypesResponse(
    server_types=[
        ServerTypes7(
            cores=1,
            cpu_type=CpuType.SHARED,
            deprecated=False,
            description='CX11',
            disk=24,
            id=1,
            memory=1,
            name='cx11',
            prices=[
                Price9(
                    location='fsn1',
                    price_hourly=PriceHourly8(
                        gross='1.1900000000000000',
                        net='1.0000000000',
                        additional_properties={
                            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                        }
                    ),
                    price_monthly=PriceMonthly10(
                        gross='1.1900000000000000',
                        net='1.0000000000',
                        additional_properties={
                            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                        }
                    ),
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            storage_type=StorageType.LOCAL,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

