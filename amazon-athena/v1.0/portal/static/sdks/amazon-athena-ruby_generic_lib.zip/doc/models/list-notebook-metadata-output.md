
# List Notebook Metadata Output

## Structure

`ListNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `notebook_metadata_list` | [`Array[NotebookMetadata]`](../../doc/models/notebook-metadata.md) | Optional | - |

## Example

```ruby
list_notebook_metadata_output = ListNotebookMetadataOutput.new(
  'NextToken8',
  [
    NotebookMetadata.new(
      'NotebookId4',
      'Name4',
      'WorkGroup6',
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      NotebookType1Enum::IPYNB,
      DateTimeHelper.from_rfc3339(nil)
    )
  ]
)
```

