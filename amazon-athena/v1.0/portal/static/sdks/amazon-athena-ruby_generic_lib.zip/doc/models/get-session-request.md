
# Get Session Request

## Structure

`GetSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ruby
get_session_request = GetSessionRequest.new(
  'SessionId4'
)
```

