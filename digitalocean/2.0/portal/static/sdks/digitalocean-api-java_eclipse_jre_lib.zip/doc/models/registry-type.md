
# Registry Type

- DOCKER_HUB: The DockerHub container registry type.
- DOCR: The DigitalOcean container registry type.

## Enumeration

`RegistryType`

## Fields

| Name |
|  --- |
| `DOCKER_HUB` |
| `DOCR` |

## Example

```java
import com.digitalocean.api.models.RegistryType;

RegistryType registryType = RegistryType.DOCKER_HUB;
```

