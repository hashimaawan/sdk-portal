
# Target

## Structure

`Target`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `health_status` | [`Array[HealthStatus]`](../../doc/models/health-status.md) | Optional | - |
| `server` | [`Server11`](../../doc/models/server-11.md) | Optional | - |
| `type` | `String` | Optional | - |
| `use_private_ip` | `TrueClass \| FalseClass` | Optional | - |

## Example

```ruby
target = Target.new(
  [
    HealthStatus.new(
      142,
      Status30Enum::UNKNOWN
    ),
    HealthStatus.new(
      142,
      Status30Enum::UNKNOWN
    ),
    HealthStatus.new(
      142,
      Status30Enum::UNKNOWN
    )
  ],
  Server11.new(
    14
  ),
  'server',
  false
)
```

