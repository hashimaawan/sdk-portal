
# Get Table Metadata Input

## Structure

`GetTableMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalog_name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `database_name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `table_name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```ruby
get_table_metadata_input = GetTableMetadataInput.new(
  'CatalogName4',
  'DatabaseName4',
  'TableName6'
)
```

