
# Window

## Enumeration

`Window`

## Fields

| Name |
|  --- |
| `UNSPECIFIED_WINDOW` |
| `FIVE_MINUTES` |
| `TEN_MINUTES` |
| `THIRTY_MINUTES` |
| `ONE_HOUR` |

## Example

```python
from digitaloceanapi.models.window import Window

window = Window.ONE_HOUR
```

