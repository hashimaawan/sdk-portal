
# Executors Summary

Contains summary information about an executor.

## Structure

`ExecutorsSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `executorId` | `string` | Required | **Constraints**: *Maximum Length*: `100000`, *Pattern*: `.*` |
| `executorType` | [`ExecutorType2Enum \| undefined`](../../doc/models/executor-type-2-enum.md) | Optional | - |
| `startDateTime` | `number \| undefined` | Optional | - |
| `terminationDateTime` | `number \| undefined` | Optional | - |
| `executorState` | [`ExecutorState3Enum \| undefined`](../../doc/models/executor-state-3-enum.md) | Optional | - |
| `executorSize` | `number \| undefined` | Optional | - |

## Example

```ts
import {
  ExecutorState3Enum,
  ExecutorType2Enum,
  ExecutorsSummary,
} from 'amazon-athenalib';

const executorsSummary: ExecutorsSummary = {
  executorId: 'ExecutorId8',
  executorType: ExecutorType2Enum.WORKER,
  startDateTime: 52,
  terminationDateTime: 56,
  executorState: ExecutorState3Enum.CREATING,
  executorSize: 222,
};
```

