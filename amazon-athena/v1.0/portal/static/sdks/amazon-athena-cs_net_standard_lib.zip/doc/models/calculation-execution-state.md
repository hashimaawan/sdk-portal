
# Calculation Execution State

## Enumeration

`CalculationExecutionState`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Queued` |
| `Running` |
| `Canceling` |
| `Canceled` |
| `Completed` |
| `Failed` |

## Example

```csharp
using AmazonAthena.Standard.Models;

CalculationExecutionState calculationExecutionState = CalculationExecutionState.Completed;
```

