
# Create Floating Ip Request

*This model accepts additional fields of type interface{}.*

## Structure

`CreateFloatingIpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `*string` | Optional | - |
| `HomeLocation` | `*string` | Optional | Home Location (routing is optimized for that Location). Only optional if Server argument is passed. |
| `Labels` | `*interface{}` | Optional | User-defined labels (key-value pairs) |
| `Name` | `*string` | Optional | - |
| `Server` | `*int` | Optional | Server to assign the Floating IP to |
| `Type` | [`models.Type17`](../../doc/models/type-17.md) | Required | Floating IP type |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    createFloatingIpRequest := models.CreateFloatingIpRequest{
        Description:           models.ToPointer("Web Frontend"),
        HomeLocation:          models.ToPointer("fsn1"),
        Labels:                models.ToPointer(interface{}("[labelkey, value]")),
        Name:                  models.ToPointer("Web Frontend"),
        Server:                models.ToPointer(42),
        Type:                  models.Type17_Ipv4,
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

