
# Parameter Type 1 Enum

## Enumeration

`ParameterType1Enum`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```java
import cloud.hetzner.api.models.ParameterType1Enum;

ParameterType1Enum parameterType1 = ParameterType1Enum.SPREAD;
```

