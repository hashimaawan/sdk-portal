
# O Auth Scope Furkot Auth Access Code Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthAccessCodeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list trips and stops info |

## Example

```go
package main

import (
    "furkottrips/models"
)

func main() {
    oAuthScopeFurkotAuthAccessCode := models.OAuthScopeFurkotAuthAccessCodeEnum_READTRIPS

}
```

