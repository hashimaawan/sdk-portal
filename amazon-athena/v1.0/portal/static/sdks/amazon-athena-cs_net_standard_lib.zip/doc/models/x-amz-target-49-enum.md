
# X Amz Target 49 Enum

## Enumeration

`XAmzTarget49Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStopCalculationExecution` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget49Enum xAmzTarget49 = XAmzTarget49Enum.EnumAmazonAthenaStopCalculationExecution;
```

