
# Status 30

## Enumeration

`Status30`

## Fields

| Name |
|  --- |
| `HEALTHY` |
| `UNHEALTHY` |
| `UNKNOWN` |

## Example

```python
from hetznercloudapi.models.status_30 import Status30

status_30 = Status30.HEALTHY
```

