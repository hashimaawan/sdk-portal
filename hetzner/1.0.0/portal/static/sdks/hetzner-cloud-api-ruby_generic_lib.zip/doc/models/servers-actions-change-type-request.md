
# Servers Actions Change Type Request

*This model accepts additional fields of type Object.*

## Structure

`ServersActionsChangeTypeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server_type` | `String` | Required | ID or name of Server type the Server should migrate to |
| `upgrade_disk` | `TrueClass \| FalseClass` | Required | If false, do not upgrade the disk (this allows downgrading the Server type later) |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
servers_actions_change_type_request = ServersActionsChangeTypeRequest.new(
  server_type: 'cx11',
  upgrade_disk: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

