
# X Amz Target 4

## Enumeration

`XAmzTarget4`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget4;

$xAmzTarget4 = XAmzTarget4::ENUM_AMAZONATHENACREATENAMEDQUERY;
```

