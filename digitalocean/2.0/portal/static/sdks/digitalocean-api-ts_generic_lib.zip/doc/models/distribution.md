
# Distribution

The name of a custom image's distribution. Currently, the valid values are  `Arch Linux`, `CentOS`, `CoreOS`, `Debian`, `Fedora`, `Fedora Atomic`,  `FreeBSD`, `Gentoo`, `openSUSE`, `RancherOS`, `Rocky Linux`, `Ubuntu`, and `Unknown`.  Any other value will be accepted but ignored, and `Unknown` will be used in its place.

## Enumeration

`Distribution`

## Fields

| Name |
|  --- |
| `EnumArchLinux` |
| `CentOs` |
| `CoreOs` |
| `Debian` |
| `Fedora` |
| `EnumFedoraAtomic` |
| `FreeBsd` |
| `Gentoo` |
| `OpenSuse` |
| `RancherOs` |
| `EnumRockyLinux` |
| `Ubuntu` |
| `Unknown` |

## Example

```ts
import { Distribution } from 'digitalocean-apilib';

const distribution = Distribution.EnumFedoraAtomic;
```

