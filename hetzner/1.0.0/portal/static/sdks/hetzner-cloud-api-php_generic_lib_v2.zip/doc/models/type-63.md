
# Type 63

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |
| `BACKUP` |

## Example

```php
use HetznerCloudApiLib\Models\Type63;

$type63 = Type63::SNAPSHOT;
```

