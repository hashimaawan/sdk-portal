
# V2 Apps Response 2

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2AppsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_apps_response_2 import V2AppsResponse2

v_2_apps_response_2 = V2AppsResponse2(
    id='4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

