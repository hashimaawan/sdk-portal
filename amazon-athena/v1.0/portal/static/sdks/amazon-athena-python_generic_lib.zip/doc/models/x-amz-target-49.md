
# X Amz Target 49

## Enumeration

`XAmzTarget49`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_49 import XAmzTarget49

x_amz_target_49 = XAmzTarget49.ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION
```

