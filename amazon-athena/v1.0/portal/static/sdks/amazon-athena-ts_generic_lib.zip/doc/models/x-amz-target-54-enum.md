
# X Amz Target 54 Enum

## Enumeration

`XAmzTarget54Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateDataCatalog` |

## Example

```ts
import { XAmzTarget54Enum } from 'amazon-athenalib';

const xAmzTarget54 = XAmzTarget54Enum.EnumAmazonAthenaUpdateDataCatalog;
```

