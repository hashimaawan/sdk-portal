
# Type 7

Type of the resource

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```java
import cloud.hetzner.api.models.Type7;

Type7 type7 = Type7.SERVER;
```

