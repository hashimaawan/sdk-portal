
# List Executors Request

*This model accepts additional fields of type Any.*

## Structure

`ListExecutorsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `executor_state_filter` | [`ExecutorState1`](../../doc/models/executor-state-1.md) | Optional | - |
| `max_results` | `int` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `next_token` | `str` | Optional | **Constraints**: *Maximum Length*: `2048` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.executor_state_1 import ExecutorState1
from amazonathena.models.list_executors_request import ListExecutorsRequest

list_executors_request = ListExecutorsRequest(
    session_id='SessionId6',
    executor_state_filter=ExecutorState1.REGISTERED,
    max_results=100,
    next_token='NextToken2',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

