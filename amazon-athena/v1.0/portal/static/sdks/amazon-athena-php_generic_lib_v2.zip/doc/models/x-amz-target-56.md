
# X Amz Target 56

## Enumeration

`XAmzTarget56`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget56;

$xAmzTarget56 = XAmzTarget56::ENUM_AMAZONATHENAUPDATENOTEBOOK;
```

