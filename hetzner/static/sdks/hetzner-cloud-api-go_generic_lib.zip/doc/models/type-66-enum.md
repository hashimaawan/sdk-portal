
# Type 66 Enum

## Enumeration

`Type66Enum`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type66 := models.Type66Enum_NETWORK

}
```

