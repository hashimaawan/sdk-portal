
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.Production`** |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(30)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| LogBuilder | [`LogBuilder`](../doc/log-builder.md) | Represents the logging configuration builder for API calls |
| AuthorizationCodeAuth | [`AuthorizationCodeAuth`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

## Code-Based Initialization

```csharp
using Microsoft.Extensions.Logging;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Authentication;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using System.Collections.Generic;

namespace ConsoleApp;

SpotifyWebApiWithFixesAndImprovementsFromSonalluxClient client = new SpotifyWebApiWithFixesAndImprovementsFromSonalluxClient.Builder()
    .AuthorizationCodeAuth(
        new AuthorizationCodeAuthModel.Builder(
            "OAuthClientId",
            "OAuthClientSecret",
            "OAuthRedirectUri"
        )
        .OauthScopes(
            new List<OauthScope>
            {
                OauthScope.AppRemoteControl,
                OauthScope.PlaylistReadPrivate,
            })
        .Build())
    .HttpClientConfig(httpClientConfig =>
        httpClientConfig.Timeout(TimeSpan.FromSeconds(100)))
    .Environment(SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Environment.Production)
    .LoggingConfig(config => config
        .LogLevel(LogLevel.Information)
        .RequestConfig(reqConfig => reqConfig.Body(true))
        .ResponseConfig(respConfig => respConfig.Headers(true))
    )
    .Build();
```

## Configuration-Based Initialization

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp;

// Build the IConfiguration using .NET conventions (JSON, environment, etc.)
var configuration = new ConfigurationBuilder()
    .AddJsonFile("config.json")
    .AddEnvironmentVariables() // [optional] read environment variables
    .Build();

// Instantiate your SDK and configure it from IConfiguration
var client = SpotifyWebApiWithFixesAndImprovementsFromSonalluxClient
    .FromConfiguration(configuration.GetSection("SpotifyWebApiWithFixesAndImprovementsFromSonallux"));
```

See the [Configuration-Based Initialization](../doc/configuration-based-initialization.md) section for details.

## Spotify Web API with fixes and improvements from sonalluxClient Class

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| AlbumsApi | Gets AlbumsApi. |
| ArtistsApi | Gets ArtistsApi. |
| AudiobooksApi | Gets AudiobooksApi. |
| CategoriesApi | Gets CategoriesApi. |
| ChaptersApi | Gets ChaptersApi. |
| EpisodesApi | Gets EpisodesApi. |
| GenresApi | Gets GenresApi. |
| MarketsApi | Gets MarketsApi. |
| PlayerApi | Gets PlayerApi. |
| PlaylistsApi | Gets PlaylistsApi. |
| SearchApi | Gets SearchApi. |
| ShowsApi | Gets ShowsApi. |
| TracksApi | Gets TracksApi. |
| UsersApi | Gets UsersApi. |
| OauthAuthorizationApi | Gets OauthAuthorizationApi. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| AuthorizationCodeAuth | Gets the credentials to use with AuthorizationCodeAuth. | [`IAuthorizationCodeAuth`](auth/oauth-2-authorization-code-grant.md) |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the Spotify Web API with fixes and improvements from sonalluxClient using the values provided for the builder. | `Builder` |

## Spotify Web API with fixes and improvements from sonalluxClient Builder Class

Class to build instances of Spotify Web API with fixes and improvements from sonalluxClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `AuthorizationCodeAuth(Action<AuthorizationCodeAuthModel.Builder> action)` | Sets credentials for AuthorizationCodeAuth. | `Builder` |

