
# Label Selector 5

Configuration for type label_selector, required if type is `label_selector`

## Structure

`LabelSelector5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    labelSelector5 := models.LabelSelector5{
        Selector:             "env=prod",
    }

}
```

