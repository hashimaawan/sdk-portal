
# X Amz Target 28 Enum

## Enumeration

`XAmzTarget28Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETTABLEMETADATA` |

## Example

```ruby
x_amz_target28 = XAmzTarget28Enum::ENUM_AMAZONATHENAGETTABLEMETADATA
```

