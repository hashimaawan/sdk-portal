
# Direction Enum

Select traffic direction on which rule should be applied. Use `source_ips` for direction `in` and `destination_ips` for direction `out`.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `ENUM_IN` |
| `OUT` |

## Example

```python
from hetznercloudapi.models.direction_enum import DirectionEnum

direction = DirectionEnum.ENUM_IN
```

