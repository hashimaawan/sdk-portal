
# Iso 2

ISO Image that is attached to this Server. Null if no ISO is attached.

*This model accepts additional fields of type object.*

## Structure

`Iso2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Deprecated` | `string` | Required | ISO 8601 timestamp of deprecation, null if ISO is still available. After the deprecation time it will no longer be possible to attach the ISO to Servers. |
| `Description` | `string` | Required | Description of the ISO |
| `Id` | `int` | Required | ID of the Resource |
| `Name` | `string` | Required | Unique identifier of the ISO. Only set for public ISOs |
| `Type` | [`Type26`](../../doc/models/type-26.md) | Required | Type of the ISO |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

Iso2 iso2 = new Iso2
{
    Deprecated = "2018-02-28T00:00:00+00:00",
    Description = "FreeBSD 11.0 x64",
    Id = 42,
    Name = "FreeBSD-11.0-RELEASE-amd64-dvd1",
    Type = Type26.Public,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

