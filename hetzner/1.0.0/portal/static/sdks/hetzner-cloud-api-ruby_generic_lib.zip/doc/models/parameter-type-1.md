
# Parameter Type 1

## Enumeration

`ParameterType1`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```ruby
parameter_type1 = ParameterType1::SPREAD
```

