
# X Amz Target 23

## Enumeration

`XAmzTarget23`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetqueryexecution` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget23 := models.XAmzTarget23_EnumAmazonathenagetqueryexecution

}
```

