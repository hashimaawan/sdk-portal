
# Result

## Enumeration

`Result`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `DENY` |

## Example

```php
use M1PasswordConnectLib\Models\Result;

$result = Result::SUCCESS;
```

