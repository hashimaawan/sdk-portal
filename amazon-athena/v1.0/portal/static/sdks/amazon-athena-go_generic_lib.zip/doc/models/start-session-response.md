
# Start Session Response

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `State` | [`*models.SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    startSessionResponse := models.StartSessionResponse{
        SessionId:            models.ToPointer("SessionId4"),
        State:                models.ToPointer(models.SessionState1Enum_CREATING),
    }

}
```

