
# Algorithm

Algorithm of the Load Balancer

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`models.Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    algorithm := models.Algorithm{
        Type:                 models.Type28Enum_ROUNDROBIN,
    }

}
```

