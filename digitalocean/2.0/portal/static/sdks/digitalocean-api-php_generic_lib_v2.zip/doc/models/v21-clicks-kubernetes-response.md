
# V21 Clicks Kubernetes Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V21ClicksKubernetesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `message` | `?string` | Optional | A message about the result of the request. | getMessage(): ?string | setMessage(?string message): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V21ClicksKubernetesResponseBuilder;
use DigitalOceanApiLib\ApiHelper;

$v21ClicksKubernetesResponse = V21ClicksKubernetesResponseBuilder::init()
    ->message('Successfully kicked off addon job.')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

