
# Assign Floating Ip Request

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `floating_ip_assigned`        | The floating IP is already assigned                           |

*This model accepts additional fields of type array.*

## Structure

`AssignFloatingIpRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `server` | `int` | Required | ID of the Server the Floating IP shall be assigned to | getServer(): int | setServer(int server): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\AssignFloatingIpRequestBuilder;
use HetznerCloudApiLib\ApiHelper;

$assignFloatingIpRequest = AssignFloatingIpRequestBuilder::init(
    42
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

