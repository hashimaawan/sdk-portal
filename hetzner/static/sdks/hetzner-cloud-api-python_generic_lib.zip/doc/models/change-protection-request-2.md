
# Change Protection Request 2

## Structure

`ChangeProtectionRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Optional | If true, prevents the Primary IP from being deleted |

## Example

```python
from hetznercloudapi.models.change_protection_request_2 import ChangeProtectionRequest2

change_protection_request_2 = ChangeProtectionRequest2(
    delete=True
)
```

