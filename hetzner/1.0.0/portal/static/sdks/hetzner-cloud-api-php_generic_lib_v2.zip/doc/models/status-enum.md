
# Status Enum

Status of the Action

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ERROR` |

## Example

```php
use HetznerCloudAPILib\Models\StatusEnum;

$status = StatusEnum::ERROR;
```

