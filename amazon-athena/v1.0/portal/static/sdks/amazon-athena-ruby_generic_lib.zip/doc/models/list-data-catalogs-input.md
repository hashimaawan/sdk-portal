
# List Data Catalogs Input

## Structure

`ListDataCatalogsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 2`, `<= 50` |

## Example

```ruby
list_data_catalogs_input = ListDataCatalogsInput.new(
  'NextToken4',
  50
)
```

