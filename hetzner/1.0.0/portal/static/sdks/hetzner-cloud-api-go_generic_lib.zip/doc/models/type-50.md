
# Type 50

Type of the Primary IP

## Enumeration

`Type50`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type50 := models.Type50_Ipv4

}
```

