# Firewall Actions

```csharp
FirewallActionsApi firewallActionsApi = client.FirewallActionsApi;
```

## Class Name

`FirewallActionsApi`

## Methods

* [Get All Actions for a Firewall](../../doc/controllers/firewall-actions.md#get-all-actions-for-a-firewall)
* [Apply to Resources](../../doc/controllers/firewall-actions.md#apply-to-resources)
* [Remove from Resources](../../doc/controllers/firewall-actions.md#remove-from-resources)
* [Set Rules](../../doc/controllers/firewall-actions.md#set-rules)
* [Get an Action for a Firewall](../../doc/controllers/firewall-actions.md#get-an-action-for-a-firewall)


# Get All Actions for a Firewall

Returns all Action objects for a Firewall. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```csharp
GetAllActionsForAFirewallAsync(
    int id,
    Models.ParameterSort? sort = null,
    Models.ParameterStatus? status = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |
| `sort` | [`ParameterSort?`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatus?`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```csharp
int id = 112;
try
{
    ApiResponse<ActionsResponse> result = await firewallActionsApi.GetAllActionsForAFirewallAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "set_firewall_rules",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Apply to Resources

Applies one Firewall to multiple resources.

Currently servers (public network interface) and label selectors are supported.

#### Call specific error codes

| Code                          | Description                                                   |
|-------------------------------|---------------------------------------------------------------|
| `firewall_already_applied`    | Firewall was already applied on resource                      |
| `incompatible_network_type`   | The Network type is incompatible for the given resource       |
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```csharp
ApplyToResourcesAsync(
    int id,
    Models.ApplyToResourcesRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`ApplyToResourcesRequest`](../../doc/models/apply-to-resources-request.md) | Body, Optional | - |

## Response Type

**201**: The `actions` key contains multiple `apply_firewall` Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```csharp
int id = 112;
ApplyToResourcesRequest body = new ApplyToResourcesRequest
{
    ApplyTo = new List<FirewallApplyToResources>
    {
        new FirewallApplyToResources
        {
            Server = new Server9
            {
                Id = 42,
            },
            Type = Type7.Server,
        },
    },
};

try
{
    ApiResponse<ActionsResponse> result = await firewallActionsApi.ApplyToResourcesAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "apply_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Remove from Resources

Removes one Firewall from multiple resources.

Currently only Servers (and their public network interfaces) are supported.

#### Call specific error codes

| Code                                  | Description                                                            |
|---------------------------------------|------------------------------------------------------------------------|
| `firewall_already_removed`            | Firewall was already removed from the resource                         |
| `firewall_resource_not_found`         | The resource the Firewall should be attached to was not found          |
| `firewall_managed_by_label_selector`  | Firewall was applied via label selector and cannot be removed manually |

```csharp
RemoveFromResourcesAsync(
    int id,
    Models.RemoveFromResourcesRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`RemoveFromResourcesRequest`](../../doc/models/remove-from-resources-request.md) | Body, Optional | - |

## Response Type

**201**: The `actions` key contains multiple `remove_firewall` Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```csharp
int id = 112;
RemoveFromResourcesRequest body = new RemoveFromResourcesRequest
{
    RemoveFrom = new List<FirewallRemoveFromResources>
    {
        new FirewallRemoveFromResources
        {
            Server = new Server9
            {
                Id = 42,
            },
            Type = Type7.Server,
        },
    },
};

try
{
    ApiResponse<ActionsResponse> result = await firewallActionsApi.RemoveFromResourcesAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "remove_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Set Rules

Sets the rules of a Firewall.

All existing rules will be overwritten. Pass an empty `rules` array to remove all rules.
The maximum amount of rules that can be defined is 50.

#### Call specific error codes

| Code                          | Description                                                   |
|-------------------------------|---------------------------------------------------------------|
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```csharp
SetRulesAsync(
    int id,
    Models.SetRulesRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`SetRulesRequest`](../../doc/models/set-rules-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains one `set_firewall_rules` Action plus one `apply_firewall` Action per resource where the Firewall is active

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```csharp
int id = 112;
SetRulesRequest body = new SetRulesRequest
{
    Rules = new List<Rule>
    {
        new Rule
        {
            Direction = Direction.In,
            Protocol = Protocol.Tcp,
            Description = "Allow port 80",
            Port = "80",
            SourceIps = new List<string>
            {
                "28.239.13.1/32",
                "28.239.14.0/24",
                "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
            },
        },
    },
};

try
{
    ApiResponse<ActionsResponse> result = await firewallActionsApi.SetRulesAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "set_firewall_rules",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    },
    {
      "command": "apply_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        },
        {
          "id": 42,
          "type": "server"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Get an Action for a Firewall

Returns a specific Action for a Firewall.

```csharp
GetAnActionForAFirewallAsync(
    int id,
    int actionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Firewall Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```csharp
int id = 112;
int actionId = 224;
try
{
    ApiResponse<ActionResponse> result = await firewallActionsApi.GetAnActionForAFirewallAsync(
        id,
        actionId
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "set_firewall_rules",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 38,
        "type": "firewall"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

