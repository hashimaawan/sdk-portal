
# X Amz Target 6

## Enumeration

`XAmzTarget6`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_6 import XAmzTarget6

x_amz_target_6 = XAmzTarget6.ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT
```

