
# X Amz Target 50

## Enumeration

`XAmzTarget50`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPQUERYEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget50;

XAmzTarget50 xAmzTarget50 = XAmzTarget50.ENUM_AMAZONATHENASTOPQUERYEXECUTION;
```

