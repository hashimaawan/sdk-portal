
# X Amz Target 9 Enum

## Enumeration

`XAmzTarget9Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteDataCatalog` |

## Example

```ts
import { XAmzTarget9Enum } from 'amazon-athenalib';

const xAmzTarget9 = XAmzTarget9Enum.EnumAmazonAthenaDeleteDataCatalog;
```

