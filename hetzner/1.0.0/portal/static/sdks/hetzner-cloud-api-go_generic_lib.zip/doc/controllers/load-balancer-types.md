# Load Balancer Types

```go
loadBalancerTypesApi := client.LoadBalancerTypesApi()
```

## Class Name

`LoadBalancerTypesApi`

## Methods

* [Get All Load Balancer Types](../../doc/controllers/load-balancer-types.md#get-all-load-balancer-types)
* [Get a Load Balancer Type](../../doc/controllers/load-balancer-types.md#get-a-load-balancer-type)


# Get All Load Balancer Types

Gets all Load Balancer type objects.

```go
GetAllLoadBalancerTypes(
    ctx context.Context,
    name *string) (
    models.ApiResponse[models.LoadBalancerTypesResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `*string` | Query, Optional | Can be used to filter Load Balancer types by their name. The response will only contain the Load Balancer type matching the specified name. |

## Response Type

**200**: The `load_balancer_types` key in the reply contains an array of Load Balancer type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.LoadBalancerTypesResponse](../../doc/models/load-balancer-types-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := loadBalancerTypesApi.GetAllLoadBalancerTypes(ctx, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get a Load Balancer Type

Gets a specific Load Balancer type object.

```go
GetALoadBalancerType(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.LoadBalancerTypesResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Load Balancer type |

## Response Type

**200**: The `load_balancer_type` key in the reply contains a Load Balancer type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.LoadBalancerTypesResponse1](../../doc/models/load-balancer-types-response-1.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := loadBalancerTypesApi.GetALoadBalancerType(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

