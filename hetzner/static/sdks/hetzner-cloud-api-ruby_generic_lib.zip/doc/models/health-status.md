
# Health Status

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listen_port` | `Integer` | Optional | - |
| `status` | [`Status30Enum`](../../doc/models/status-30-enum.md) | Optional | - |

## Example

```ruby
health_status = HealthStatus.new(
  443,
  Status30Enum::HEALTHY
)
```

