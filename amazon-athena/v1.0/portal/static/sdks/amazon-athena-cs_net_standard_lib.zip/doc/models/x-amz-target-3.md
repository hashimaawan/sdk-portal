
# X Amz Target 3

## Enumeration

`XAmzTarget3`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateDataCatalog` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget3 xAmzTarget3 = XAmzTarget3.EnumAmazonAthenaCreateDataCatalog;
```

