
# Server 9

Configuration for type server, required if type is `server`

## Structure

`Server9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the Server |

## Example

```ruby
server9 = Server9.new(
  216
)
```

