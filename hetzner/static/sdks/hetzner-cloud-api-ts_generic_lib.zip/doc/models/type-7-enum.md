
# Type 7 Enum

Type of the resource

## Enumeration

`Type7Enum`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```ts
import { Type7Enum } from 'hetzner-cloud-apilib';

const type7 = Type7Enum.Server;
```

