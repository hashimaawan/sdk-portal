
# V2 Registry Docker Credentials Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2RegistryDockerCredentialsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auths` | [`Auths`](../../doc/models/auths.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_registry_docker_credentials_response = V2RegistryDockerCredentialsResponse.new(
  auths: Auths.new(
    registry_digitalocean_com: RegistryDigitaloceanCom.new(
      auth: 'auth0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

