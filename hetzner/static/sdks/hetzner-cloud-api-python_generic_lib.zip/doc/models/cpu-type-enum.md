
# Cpu Type Enum

Type of cpu

## Enumeration

`CpuTypeEnum`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```python
from hetznercloudapi.models.cpu_type_enum import CpuTypeEnum

cpu_type = CpuTypeEnum.SHARED
```

