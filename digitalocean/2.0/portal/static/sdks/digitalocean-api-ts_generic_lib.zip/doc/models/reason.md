
# Reason

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Reason`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Reason } from 'digitalocean-apilib';

const reason: Reason = {
  code: 'Title of Error',
  message: 'This is an error',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

