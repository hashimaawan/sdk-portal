
# Status 72 Enum

Status of the Firewall on the Server

## Enumeration

`Status72Enum`

## Fields

| Name |
|  --- |
| `APPLIED` |
| `PENDING` |

## Example

```ruby
status72 = Status72Enum::APPLIED
```

