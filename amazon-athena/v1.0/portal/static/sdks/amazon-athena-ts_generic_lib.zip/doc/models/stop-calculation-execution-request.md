
# Stop Calculation Execution Request

## Structure

`StopCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```ts
import { StopCalculationExecutionRequest } from 'amazon-athenalib';

const stopCalculationExecutionRequest: StopCalculationExecutionRequest = {
  calculationExecutionId: 'CalculationExecutionId2',
};
```

