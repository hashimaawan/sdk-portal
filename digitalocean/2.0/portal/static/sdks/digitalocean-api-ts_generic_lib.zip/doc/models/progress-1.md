
# Progress 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Progress1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `steps` | [`unknown[] \| undefined`](../../doc/models/object.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Progress1 } from 'digitalocean-apilib';

const progress1: Progress1 = {
  steps: [
    { 'key1': 'val1', 'key2': 'val2' },
    { 'key1': 'val1', 'key2': 'val2' }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

