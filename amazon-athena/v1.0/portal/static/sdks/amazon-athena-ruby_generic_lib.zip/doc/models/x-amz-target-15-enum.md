
# X Amz Target 15 Enum

## Enumeration

`XAmzTarget15Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```ruby
x_amz_target15 = XAmzTarget15Enum::ENUM_AMAZONATHENAGETCALCULATIONEXECUTION
```

