
# Getting Started with Spotify Web API with fixes and improvements from sonallux

## Introduction

You can use Spotify's Web API to discover music and podcasts, manage your Spotify library, control audio playback, and much more. Browse our available Web API endpoints using the sidebar at left, or via the navigation bar on top of this page on smaller screens.

In order to make successful Web API requests your app will need a valid access token. One can be obtained through <a href="https://developer.spotify.com/documentation/general/guides/authorization-guide/">OAuth 2.0</a>.

The base URI for all Web API requests is `https://api.spotify.com/v1`.

Need help? See our <a href="https://developer.spotify.com/documentation/web-api/guides/">Web API guides</a> for more information, or visit the <a href="https://community.spotify.com/t5/Spotify-for-Developers/bd-p/Spotify_Developer">Spotify for Developers community forum</a> to ask questions and connect with other developers.

## Building

The generated code uses the Newtonsoft Json.NET NuGet Package. If the automatic NuGet package restore is enabled, these dependencies will be installed automatically. Therefore, you will need internet access for build.

* Open the solution (SpotifyWebApiWithFixesAndImprovementsFromSonallux.sln) file.

Invoke the build process using Ctrl + Shift + B shortcut key or using the Build menu as shown below.

The build process generates a portable class library, which can be used like a normal class library. More information on how to use can be found at the MSDN Portable Class Libraries documentation.

The supported version is **.NET Standard 2.0**. For checking compatibility of your .NET implementation with the generated library, [click here](https://dotnet.microsoft.com/en-us/platform/dotnet-standard#versions).

## Installation

The following section explains how to use the SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard library in a new project.

### 1. Starting a new project

For starting a new project, right click on the current solution from the solution explorer and choose `Add -> New Project`.

![Add a new project in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Spotify%20Web%20API%20with%20fixes%20and%20improvements%20from%20sonallux-CSharp&workspaceName=SpotifyWebApiWithFixesAndImprovementsFromSonallux&projectName=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&rootNamespace=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&step=addProject)

Next, choose `Console Application`, provide `TestConsoleProject` as the project name and click OK.

![Create a new Console Application in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Spotify%20Web%20API%20with%20fixes%20and%20improvements%20from%20sonallux-CSharp&workspaceName=SpotifyWebApiWithFixesAndImprovementsFromSonallux&projectName=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&rootNamespace=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&step=createProject)

### 2. Set as startup project

The new console project is the entry point for the eventual execution. This requires us to set the `TestConsoleProject` as the start-up project. To do this, right-click on the `TestConsoleProject` and choose `Set as StartUp Project` form the context menu.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Spotify%20Web%20API%20with%20fixes%20and%20improvements%20from%20sonallux-CSharp&workspaceName=SpotifyWebApiWithFixesAndImprovementsFromSonallux&projectName=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&rootNamespace=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&step=setStartup)

### 3. Add reference of the library project

In order to use the `SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard` library in the new project, first we must add a project reference to the `TestConsoleProject`. First, right click on the `References` node in the solution explorer and click `Add Reference...`

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Spotify%20Web%20API%20with%20fixes%20and%20improvements%20from%20sonallux-CSharp&workspaceName=SpotifyWebApiWithFixesAndImprovementsFromSonallux&projectName=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&rootNamespace=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&step=addReference)

Next, a window will be displayed where we must set the `checkbox` on `SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard` and click `OK`. By doing this, we have added a reference of the `SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard` project into the new `TestConsoleProject`.

![Creating a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Spotify%20Web%20API%20with%20fixes%20and%20improvements%20from%20sonallux-CSharp&workspaceName=SpotifyWebApiWithFixesAndImprovementsFromSonallux&projectName=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&rootNamespace=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&step=createReference)

### 4. Write sample code

Once the `TestConsoleProject` is created, a file named `Program.cs` will be visible in the solution explorer with an empty `Main` method. This is the entry point for the execution of the entire solution. Here, you can add code to initialize the client library and acquire the instance of a Api class. Sample code to initialize the client library and using Api methods is given in the subsequent sections.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Spotify%20Web%20API%20with%20fixes%20and%20improvements%20from%20sonallux-CSharp&workspaceName=SpotifyWebApiWithFixesAndImprovementsFromSonallux&projectName=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&rootNamespace=SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard&step=addCode)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.Production`** |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(30)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| LogBuilder | [`LogBuilder`](doc/log-builder.md) | Represents the logging configuration builder for API calls |
| AuthorizationCodeAuth | [`AuthorizationCodeAuth`](doc/auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

### Code-Based Initialization

```csharp
using Microsoft.Extensions.Logging;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Authentication;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using System.Collections.Generic;

namespace ConsoleApp;

SpotifyWebApiWithFixesAndImprovementsFromSonalluxClient client = new SpotifyWebApiWithFixesAndImprovementsFromSonalluxClient.Builder()
    .AuthorizationCodeAuth(
        new AuthorizationCodeAuthModel.Builder(
            "OAuthClientId",
            "OAuthClientSecret",
            "OAuthRedirectUri"
        )
        .OauthScopes(
            new List<OauthScope>
            {
                OauthScope.AppRemoteControl,
                OauthScope.PlaylistReadPrivate,
            })
        .Build())
    .HttpClientConfig(httpClientConfig =>
        httpClientConfig.Timeout(TimeSpan.FromSeconds(100)))
    .Environment(SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Environment.Production)
    .LoggingConfig(config => config
        .LogLevel(LogLevel.Information)
        .RequestConfig(reqConfig => reqConfig.Body(true))
        .ResponseConfig(respConfig => respConfig.Headers(true))
    )
    .Build();
```

### Configuration-Based Initialization

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp;

// Build the IConfiguration using .NET conventions (JSON, environment, etc.)
var configuration = new ConfigurationBuilder()
    .AddJsonFile("config.json")
    .AddEnvironmentVariables() // [optional] read environment variables
    .Build();

// Instantiate your SDK and configure it from IConfiguration
var client = SpotifyWebApiWithFixesAndImprovementsFromSonalluxClient
    .FromConfiguration(configuration.GetSection("SpotifyWebApiWithFixesAndImprovementsFromSonallux"));
```

See the [Configuration-Based Initialization](doc/configuration-based-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| Production | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`oauth_2_0 (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Albums](doc/controllers/albums.md)
* [Artists](doc/controllers/artists.md)
* [Audiobooks](doc/controllers/audiobooks.md)
* [Categories](doc/controllers/categories.md)
* [Chapters](doc/controllers/chapters.md)
* [Episodes](doc/controllers/episodes.md)
* [Genres](doc/controllers/genres.md)
* [Markets](doc/controllers/markets.md)
* [Player](doc/controllers/player.md)
* [Playlists](doc/controllers/playlists.md)
* [Search](doc/controllers/search.md)
* [Shows](doc/controllers/shows.md)
* [Tracks](doc/controllers/tracks.md)
* [Users](doc/controllers/users.md)

## SDK Infrastructure

### Configuration

* [Configuration-Based Initialization](doc/configuration-based-initialization.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfigurationBuilder](doc/http-client-configuration-builder.md)
* [LogBuilder](doc/log-builder.md)
* [LogRequestBuilder](doc/log-request-builder.md)
* [LogResponseBuilder](doc/log-response-builder.md)
* [ProxyConfigurationBuilder](doc/proxy-configuration-builder.md)

### HTTP

* [HttpCallback](doc/http-callback.md)
* [HttpContext](doc/http-context.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)

### Utilities

* [ApiException](doc/api-exception.md)
* [ApiResponse](doc/api-response.md)
* [ApiHelper](doc/api-helper.md)
* [CustomDateTimeConverter](doc/custom-date-time-converter.md)
* [UnixDateTimeConverter](doc/unix-date-time-converter.md)

