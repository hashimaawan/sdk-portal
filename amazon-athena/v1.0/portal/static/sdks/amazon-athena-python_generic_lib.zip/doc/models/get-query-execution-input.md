
# Get Query Execution Input

## Structure

`GetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```python
from amazonathena.models.get_query_execution_input import GetQueryExecutionInput

get_query_execution_input = GetQueryExecutionInput(
    query_execution_id='QueryExecutionId6'
)
```

