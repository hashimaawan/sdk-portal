
# Volumes Response

## Structure

`VolumesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Optional | - | Meta getMeta() | setMeta(Meta meta) |
| `Volumes` | [`List<Volume1>`](../../doc/models/volume-1.md) | Required | - | List<Volume1> getVolumes() | setVolumes(List<Volume1> volumes) |

## Example

```java
import cloud.hetzner.api.models.Location16;
import cloud.hetzner.api.models.Meta;
import cloud.hetzner.api.models.Pagination;
import cloud.hetzner.api.models.Protection;
import cloud.hetzner.api.models.Status113Enum;
import cloud.hetzner.api.models.Volume1;
import cloud.hetzner.api.models.VolumesResponse;
import java.util.Arrays;
import java.util.LinkedHashMap;

VolumesResponse volumesResponse = new VolumesResponse.Builder(
    Arrays.asList(
        new Volume1.Builder(
            "2016-01-30T23:55:00+00:00",
            "xfs",
            42,
            new LinkedHashMap<String, String>() {{
                put("key0", "labels4");
            }},
            "/dev/disk/by-id/scsi-0HC_Volume_4711",
            new Location16.Builder(
                "Falkenstein",
                "DE",
                "Falkenstein DC Park 1",
                1D,
                50.47612D,
                12.370071D,
                "fsn1",
                "eu-central"
            )
            .build(),
            "my-resource",
            new Protection.Builder(
                false
            )
            .build(),
            12,
            42D,
            Status113Enum.AVAILABLE
        )
        .build()
    )
)
.meta(new Meta.Builder(
        new Pagination.Builder(
            77.7D,
            209.18D,
            17.58D,
            13.34D,
            50.02D,
            206.64D
        )
        .build()
    )
    .build())
.build();
```

