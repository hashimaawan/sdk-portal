
# Mode

travel mode

## Enumeration

`Mode`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```python
from furkottrips.models.mode import Mode

mode = Mode.BICYCLE
```

