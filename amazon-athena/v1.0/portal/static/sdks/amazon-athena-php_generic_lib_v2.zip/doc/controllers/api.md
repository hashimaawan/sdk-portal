# API

```php
$api = $client->getApi();
```

## Class Name

`Api`

## Methods

* [Batch Get Named Query](../../doc/controllers/api.md#batch-get-named-query)
* [Batch Get Prepared Statement](../../doc/controllers/api.md#batch-get-prepared-statement)
* [Batch Get Query Execution](../../doc/controllers/api.md#batch-get-query-execution)
* [Create Data Catalog](../../doc/controllers/api.md#create-data-catalog)
* [Create Named Query](../../doc/controllers/api.md#create-named-query)
* [Create Notebook](../../doc/controllers/api.md#create-notebook)
* [Create Prepared Statement](../../doc/controllers/api.md#create-prepared-statement)
* [Create Presigned Notebook Url](../../doc/controllers/api.md#create-presigned-notebook-url)
* [Create Work Group](../../doc/controllers/api.md#create-work-group)
* [Delete Data Catalog](../../doc/controllers/api.md#delete-data-catalog)
* [Delete Named Query](../../doc/controllers/api.md#delete-named-query)
* [Delete Notebook](../../doc/controllers/api.md#delete-notebook)
* [Delete Prepared Statement](../../doc/controllers/api.md#delete-prepared-statement)
* [Delete Work Group](../../doc/controllers/api.md#delete-work-group)
* [Export Notebook](../../doc/controllers/api.md#export-notebook)
* [Get Calculation Execution](../../doc/controllers/api.md#get-calculation-execution)
* [Get Calculation Execution Code](../../doc/controllers/api.md#get-calculation-execution-code)
* [Get Calculation Execution Status](../../doc/controllers/api.md#get-calculation-execution-status)
* [Get Data Catalog](../../doc/controllers/api.md#get-data-catalog)
* [Get Database](../../doc/controllers/api.md#get-database)
* [Get Named Query](../../doc/controllers/api.md#get-named-query)
* [Get Notebook Metadata](../../doc/controllers/api.md#get-notebook-metadata)
* [Get Prepared Statement](../../doc/controllers/api.md#get-prepared-statement)
* [Get Query Execution](../../doc/controllers/api.md#get-query-execution)
* [Get Query Results](../../doc/controllers/api.md#get-query-results)
* [Get Query Runtime Statistics](../../doc/controllers/api.md#get-query-runtime-statistics)
* [Get Session](../../doc/controllers/api.md#get-session)
* [Get Session Status](../../doc/controllers/api.md#get-session-status)
* [Get Table Metadata](../../doc/controllers/api.md#get-table-metadata)
* [Get Work Group](../../doc/controllers/api.md#get-work-group)
* [Import Notebook](../../doc/controllers/api.md#import-notebook)
* [List Application DPU Sizes](../../doc/controllers/api.md#list-application-dpu-sizes)
* [List Calculation Executions](../../doc/controllers/api.md#list-calculation-executions)
* [List Data Catalogs](../../doc/controllers/api.md#list-data-catalogs)
* [List Databases](../../doc/controllers/api.md#list-databases)
* [List Engine Versions](../../doc/controllers/api.md#list-engine-versions)
* [List Executors](../../doc/controllers/api.md#list-executors)
* [List Named Queries](../../doc/controllers/api.md#list-named-queries)
* [List Notebook Metadata](../../doc/controllers/api.md#list-notebook-metadata)
* [List Notebook Sessions](../../doc/controllers/api.md#list-notebook-sessions)
* [List Prepared Statements](../../doc/controllers/api.md#list-prepared-statements)
* [List Query Executions](../../doc/controllers/api.md#list-query-executions)
* [List Sessions](../../doc/controllers/api.md#list-sessions)
* [List Table Metadata](../../doc/controllers/api.md#list-table-metadata)
* [List Tags for Resource](../../doc/controllers/api.md#list-tags-for-resource)
* [List Work Groups](../../doc/controllers/api.md#list-work-groups)
* [Start Calculation Execution](../../doc/controllers/api.md#start-calculation-execution)
* [Start Query Execution](../../doc/controllers/api.md#start-query-execution)
* [Start Session](../../doc/controllers/api.md#start-session)
* [Stop Calculation Execution](../../doc/controllers/api.md#stop-calculation-execution)
* [Stop Query Execution](../../doc/controllers/api.md#stop-query-execution)
* [Tag Resource](../../doc/controllers/api.md#tag-resource)
* [Terminate Session](../../doc/controllers/api.md#terminate-session)
* [Untag Resource](../../doc/controllers/api.md#untag-resource)
* [Update Data Catalog](../../doc/controllers/api.md#update-data-catalog)
* [Update Named Query](../../doc/controllers/api.md#update-named-query)
* [Update Notebook](../../doc/controllers/api.md#update-notebook)
* [Update Notebook Metadata](../../doc/controllers/api.md#update-notebook-metadata)
* [Update Prepared Statement](../../doc/controllers/api.md#update-prepared-statement)
* [Update Work Group](../../doc/controllers/api.md#update-work-group)


# Batch Get Named Query

Returns the details of a single named query or a list of up to 50 queries, which you provide as an array of query ID strings. Requires you to have access to the workgroup in which the queries were saved. Use <a>ListNamedQueriesInput</a> to get the list of named query IDs in the specified workgroup. If information could not be retrieved for a submitted query ID, information about the query ID submitted is listed under <a>UnprocessedNamedQueryId</a>. Named queries differ from executed queries. Use <a>BatchGetQueryExecutionInput</a> to get details about each unique query execution, and <a>ListQueryExecutionsInput</a> to get a list of query execution IDs.

```php
function batchGetNamedQuery(
    string $xAmzTarget,
    BatchGetNamedQueryInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget)`](../../doc/models/x-amz-target.md) | Header, Required | - |
| `body` | [`BatchGetNamedQueryInput`](../../doc/models/batch-get-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`BatchGetNamedQueryOutput`](../../doc/models/batch-get-named-query-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget::ENUM_AMAZONATHENABATCHGETNAMEDQUERY;

$body = BatchGetNamedQueryInputBuilder::init(
    [
        'NamedQueryIds9'
    ]
)->build();

$api = $client->getAPI();
$apiResponse = $api->batchGetNamedQuery(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'BatchGetNamedQueryOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Batch Get Prepared Statement

Returns the details of a single prepared statement or a list of up to 256 prepared statements for the array of prepared statement names that you provide. Requires you to have access to the workgroup to which the prepared statements belong. If a prepared statement cannot be retrieved for the name specified, the statement is listed in <code>UnprocessedPreparedStatementNames</code>.

```php
function batchGetPreparedStatement(
    string $xAmzTarget,
    BatchGetPreparedStatementInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget1)`](../../doc/models/x-amz-target-1.md) | Header, Required | - |
| `body` | [`BatchGetPreparedStatementInput`](../../doc/models/batch-get-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`BatchGetPreparedStatementOutput`](../../doc/models/batch-get-prepared-statement-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget1::ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT;

$body = BatchGetPreparedStatementInputBuilder::init(
    [
        'PreparedStatementNames0',
        'PreparedStatementNames1',
        'PreparedStatementNames2'
    ],
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->batchGetPreparedStatement(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'BatchGetPreparedStatementOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Batch Get Query Execution

Returns the details of a single query execution or a list of up to 50 query executions, which you provide as an array of query execution ID strings. Requires you to have access to the workgroup in which the queries ran. To get a list of query execution IDs, use <a>ListQueryExecutionsInput$WorkGroup</a>. Query executions differ from named (saved) queries. Use <a>BatchGetNamedQueryInput</a> to get details about named queries.

```php
function batchGetQueryExecution(
    string $xAmzTarget,
    BatchGetQueryExecutionInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget2)`](../../doc/models/x-amz-target-2.md) | Header, Required | - |
| `body` | [`BatchGetQueryExecutionInput`](../../doc/models/batch-get-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`BatchGetQueryExecutionOutput`](../../doc/models/batch-get-query-execution-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget2::ENUM_AMAZONATHENABATCHGETQUERYEXECUTION;

$body = BatchGetQueryExecutionInputBuilder::init(
    [
        'QueryExecutionIds3'
    ]
)->build();

$api = $client->getAPI();
$apiResponse = $api->batchGetQueryExecution(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'BatchGetQueryExecutionOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Data Catalog

Creates (registers) a data catalog with the specified name and properties. Catalogs created are visible to all users of the same Amazon Web Services account.

```php
function createDataCatalog(
    string $xAmzTarget,
    CreateDataCatalogInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget3)`](../../doc/models/x-amz-target-3.md) | Header, Required | - |
| `body` | [`CreateDataCatalogInput`](../../doc/models/create-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget3::ENUM_AMAZONATHENACREATEDATACATALOG;

$body = CreateDataCatalogInputBuilder::init(
    'Name6',
    DataCatalogType1::HIVE
)->build();

$api = $client->getAPI();
$apiResponse = $api->createDataCatalog(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Named Query

<p>Creates a named query in the specified workgroup. Requires that you have access to the workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```php
function createNamedQuery(
    string $xAmzTarget,
    CreateNamedQueryInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget4)`](../../doc/models/x-amz-target-4.md) | Header, Required | - |
| `body` | [`CreateNamedQueryInput`](../../doc/models/create-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`CreateNamedQueryOutput`](../../doc/models/create-named-query-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget4::ENUM_AMAZONATHENACREATENAMEDQUERY;

$body = CreateNamedQueryInputBuilder::init(
    'Name6',
    'Database4',
    'QueryString8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->createNamedQuery(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'CreateNamedQueryOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Notebook

Creates an empty <code>ipynb</code> file in the specified Apache Spark enabled workgroup. Throws an error if a file in the workgroup with the same name already exists.

```php
function createNotebook(
    string $xAmzTarget,
    CreateNotebookInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget5)`](../../doc/models/x-amz-target-5.md) | Header, Required | - |
| `body` | [`CreateNotebookInput`](../../doc/models/create-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`CreateNotebookOutput`](../../doc/models/create-notebook-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget5::ENUM_AMAZONATHENACREATENOTEBOOK;

$body = CreateNotebookInputBuilder::init(
    'WorkGroup8',
    'Name6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->createNotebook(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'CreateNotebookOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Create Prepared Statement

Creates a prepared statement for use with SQL queries in Athena.

```php
function createPreparedStatement(
    string $xAmzTarget,
    CreatePreparedStatementInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget6)`](../../doc/models/x-amz-target-6.md) | Header, Required | - |
| `body` | [`CreatePreparedStatementInput`](../../doc/models/create-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget6::ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT;

$body = CreatePreparedStatementInputBuilder::init(
    'StatementName4',
    'WorkGroup8',
    'QueryStatement8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->createPreparedStatement(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Create Presigned Notebook Url

Gets an authentication token and the URL at which the notebook can be accessed. During programmatic access, <code>CreatePresignedNotebookUrl</code> must be called every 10 minutes to refresh the authentication token. For information about granting programmatic access, see <a href="https://docs.aws.amazon.com/athena/latest/ug/setting-up.html#setting-up-grant-programmatic-access">Grant programmatic access</a>.

```php
function createPresignedNotebookUrl(
    string $xAmzTarget,
    CreatePresignedNotebookUrlRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget7)`](../../doc/models/x-amz-target-7.md) | Header, Required | - |
| `body` | [`CreatePresignedNotebookUrlRequest`](../../doc/models/create-presigned-notebook-url-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`CreatePresignedNotebookUrlResponse`](../../doc/models/create-presigned-notebook-url-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget7::ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL;

$body = CreatePresignedNotebookUrlRequestBuilder::init(
    'SessionId2'
)->build();

$api = $client->getAPI();
$apiResponse = $api->createPresignedNotebookUrl(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'CreatePresignedNotebookUrlResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Create Work Group

Creates a workgroup with the specified name. A workgroup can be an Apache Spark enabled workgroup or an Athena SQL workgroup.

```php
function createWorkGroup(
    string $xAmzTarget,
    CreateWorkGroupInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget8)`](../../doc/models/x-amz-target-8.md) | Header, Required | - |
| `body` | [`CreateWorkGroupInput`](../../doc/models/create-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget8::ENUM_AMAZONATHENACREATEWORKGROUP;

$body = CreateWorkGroupInputBuilder::init(
    'Name6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->createWorkGroup(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Data Catalog

Deletes a data catalog.

```php
function deleteDataCatalog(
    string $xAmzTarget,
    DeleteDataCatalogInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget9)`](../../doc/models/x-amz-target-9.md) | Header, Required | - |
| `body` | [`DeleteDataCatalogInput`](../../doc/models/delete-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget9::ENUM_AMAZONATHENADELETEDATACATALOG;

$body = DeleteDataCatalogInputBuilder::init(
    'Name6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->deleteDataCatalog(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Named Query

<p>Deletes the named query if you have access to the workgroup in which the query was saved.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```php
function deleteNamedQuery(
    string $xAmzTarget,
    DeleteNamedQueryInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget10)`](../../doc/models/x-amz-target-10.md) | Header, Required | - |
| `body` | [`DeleteNamedQueryInput`](../../doc/models/delete-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget10::ENUM_AMAZONATHENADELETENAMEDQUERY;

$body = DeleteNamedQueryInputBuilder::init(
    'NamedQueryId6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->deleteNamedQuery(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Delete Notebook

Deletes the specified notebook.

```php
function deleteNotebook(
    string $xAmzTarget,
    DeleteNotebookInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget11)`](../../doc/models/x-amz-target-11.md) | Header, Required | - |
| `body` | [`DeleteNotebookInput`](../../doc/models/delete-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget11::ENUM_AMAZONATHENADELETENOTEBOOK;

$body = DeleteNotebookInputBuilder::init(
    'NotebookId6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->deleteNotebook(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Delete Prepared Statement

Deletes the prepared statement with the specified name from the specified workgroup.

```php
function deletePreparedStatement(
    string $xAmzTarget,
    DeletePreparedStatementInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget12)`](../../doc/models/x-amz-target-12.md) | Header, Required | - |
| `body` | [`DeletePreparedStatementInput`](../../doc/models/delete-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget12::ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT;

$body = DeletePreparedStatementInputBuilder::init(
    'StatementName4',
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->deletePreparedStatement(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Delete Work Group

Deletes the workgroup with the specified name. The primary workgroup cannot be deleted.

```php
function deleteWorkGroup(
    string $xAmzTarget,
    DeleteWorkGroupInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget13)`](../../doc/models/x-amz-target-13.md) | Header, Required | - |
| `body` | [`DeleteWorkGroupInput`](../../doc/models/delete-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget13::ENUM_AMAZONATHENADELETEWORKGROUP;

$body = DeleteWorkGroupInputBuilder::init(
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->deleteWorkGroup(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Export Notebook

Exports the specified notebook and its metadata.

```php
function exportNotebook(
    string $xAmzTarget,
    ExportNotebookInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget14)`](../../doc/models/x-amz-target-14.md) | Header, Required | - |
| `body` | [`ExportNotebookInput`](../../doc/models/export-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ExportNotebookOutput`](../../doc/models/export-notebook-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget14::ENUM_AMAZONATHENAEXPORTNOTEBOOK;

$body = ExportNotebookInputBuilder::init(
    'NotebookId6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->exportNotebook(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ExportNotebookOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Calculation Execution

Describes a previously submitted calculation execution.

```php
function getCalculationExecution(
    string $xAmzTarget,
    GetCalculationExecutionRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget15)`](../../doc/models/x-amz-target-15.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionRequest`](../../doc/models/get-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetCalculationExecutionResponse`](../../doc/models/get-calculation-execution-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget15::ENUM_AMAZONATHENAGETCALCULATIONEXECUTION;

$body = GetCalculationExecutionRequestBuilder::init(
    'CalculationExecutionId8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getCalculationExecution(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetCalculationExecutionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Calculation Execution Code

Retrieves the unencrypted code that was executed for the calculation.

```php
function getCalculationExecutionCode(
    string $xAmzTarget,
    GetCalculationExecutionCodeRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget16)`](../../doc/models/x-amz-target-16.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionCodeRequest`](../../doc/models/get-calculation-execution-code-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetCalculationExecutionCodeResponse`](../../doc/models/get-calculation-execution-code-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget16::ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE;

$body = GetCalculationExecutionCodeRequestBuilder::init(
    'CalculationExecutionId8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getCalculationExecutionCode(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetCalculationExecutionCodeResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Calculation Execution Status

Gets the status of a current calculation.

```php
function getCalculationExecutionStatus(
    string $xAmzTarget,
    GetCalculationExecutionStatusRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget17)`](../../doc/models/x-amz-target-17.md) | Header, Required | - |
| `body` | [`GetCalculationExecutionStatusRequest`](../../doc/models/get-calculation-execution-status-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetCalculationExecutionStatusResponse`](../../doc/models/get-calculation-execution-status-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget17::ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS;

$body = GetCalculationExecutionStatusRequestBuilder::init(
    'CalculationExecutionId8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getCalculationExecutionStatus(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetCalculationExecutionStatusResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Data Catalog

Returns the specified data catalog.

```php
function getDataCatalog(
    string $xAmzTarget,
    GetDataCatalogInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget18)`](../../doc/models/x-amz-target-18.md) | Header, Required | - |
| `body` | [`GetDataCatalogInput`](../../doc/models/get-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetDataCatalogOutput`](../../doc/models/get-data-catalog-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget18::ENUM_AMAZONATHENAGETDATACATALOG;

$body = GetDataCatalogInputBuilder::init(
    'Name6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getDataCatalog(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetDataCatalogOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Database

Returns a database object for the specified database and data catalog.

```php
function getDatabase(
    string $xAmzTarget,
    GetDatabaseInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget19)`](../../doc/models/x-amz-target-19.md) | Header, Required | - |
| `body` | [`GetDatabaseInput`](../../doc/models/get-database-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetDatabaseOutput`](../../doc/models/get-database-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget19::ENUM_AMAZONATHENAGETDATABASE;

$body = GetDatabaseInputBuilder::init(
    'CatalogName0',
    'DatabaseName0'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getDatabase(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetDatabaseOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# Get Named Query

Returns information about a single query. Requires that you have access to the workgroup in which the query was saved.

```php
function getNamedQuery(
    string $xAmzTarget,
    GetNamedQueryInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget20)`](../../doc/models/x-amz-target-20.md) | Header, Required | - |
| `body` | [`GetNamedQueryInput`](../../doc/models/get-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetNamedQueryOutput`](../../doc/models/get-named-query-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget20::ENUM_AMAZONATHENAGETNAMEDQUERY;

$body = GetNamedQueryInputBuilder::init(
    'NamedQueryId6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getNamedQuery(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetNamedQueryOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Notebook Metadata

Retrieves notebook metadata for the specified notebook ID.

```php
function getNotebookMetadata(
    string $xAmzTarget,
    GetNotebookMetadataInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget21)`](../../doc/models/x-amz-target-21.md) | Header, Required | - |
| `body` | [`GetNotebookMetadataInput`](../../doc/models/get-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetNotebookMetadataOutput`](../../doc/models/get-notebook-metadata-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget21::ENUM_AMAZONATHENAGETNOTEBOOKMETADATA;

$body = GetNotebookMetadataInputBuilder::init(
    'NotebookId6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getNotebookMetadata(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetNotebookMetadataOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Prepared Statement

Retrieves the prepared statement with the specified name from the specified workgroup.

```php
function getPreparedStatement(
    string $xAmzTarget,
    GetPreparedStatementInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget22)`](../../doc/models/x-amz-target-22.md) | Header, Required | - |
| `body` | [`GetPreparedStatementInput`](../../doc/models/get-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetPreparedStatementOutput`](../../doc/models/get-prepared-statement-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget22::ENUM_AMAZONATHENAGETPREPAREDSTATEMENT;

$body = GetPreparedStatementInputBuilder::init(
    'StatementName4',
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getPreparedStatement(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetPreparedStatementOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Query Execution

Returns information about a single execution of a query if you have access to the workgroup in which the query ran. Each time a query executes, information about the query execution is saved with a unique ID.

```php
function getQueryExecution(
    string $xAmzTarget,
    GetQueryExecutionInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget23)`](../../doc/models/x-amz-target-23.md) | Header, Required | - |
| `body` | [`GetQueryExecutionInput`](../../doc/models/get-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetQueryExecutionOutput`](../../doc/models/get-query-execution-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget23::ENUM_AMAZONATHENAGETQUERYEXECUTION;

$body = GetQueryExecutionInputBuilder::init(
    'QueryExecutionId0'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getQueryExecution(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetQueryExecutionOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Query Results

<p>Streams the results of a single query execution specified by <code>QueryExecutionId</code> from the Athena query results location in Amazon S3. For more information, see <a href="https://docs.aws.amazon.com/athena/latest/ug/querying.html">Working with query results, recent queries, and output files</a> in the <i>Amazon Athena User Guide</i>. This request does not execute the query but returns results. Use <a>StartQueryExecution</a> to run a query.</p> <p>To stream query results successfully, the IAM principal with permission to call <code>GetQueryResults</code> also must have permissions to the Amazon S3 <code>GetObject</code> action for the Athena query results location.</p> <important> <p>IAM principals with permission to the Amazon S3 <code>GetObject</code> action for the query results location are able to retrieve query results from Amazon S3 even if permission to the <code>GetQueryResults</code> action is denied. To restrict user or role access, ensure that Amazon S3 permissions to the Athena query location are denied.</p> </important>


```php
function getQueryResults(
    string $xAmzTarget,
    GetQueryResultsInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget24)`](../../doc/models/x-amz-target-24.md) | Header, Required | - |
| `body` | [`GetQueryResultsInput`](../../doc/models/get-query-results-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetQueryResultsOutput`](../../doc/models/get-query-results-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget24::ENUM_AMAZONATHENAGETQUERYRESULTS;

$body = GetQueryResultsInputBuilder::init(
    'QueryExecutionId0'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getQueryResults(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetQueryResultsOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Get Query Runtime Statistics

Returns query execution runtime statistics related to a single execution of a query if you have access to the workgroup in which the query ran. Query execution runtime statistics are returned only when <a>QueryExecutionStatus$State</a> is in a SUCCEEDED or FAILED state. Stage-level input and output row count and data size statistics are not shown when a query has row-level filters defined in Lake Formation.

```php
function getQueryRuntimeStatistics(
    string $xAmzTarget,
    GetQueryRuntimeStatisticsInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget25)`](../../doc/models/x-amz-target-25.md) | Header, Required | - |
| `body` | [`GetQueryRuntimeStatisticsInput`](../../doc/models/get-query-runtime-statistics-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetQueryRuntimeStatisticsOutput`](../../doc/models/get-query-runtime-statistics-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget25::ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS;

$body = GetQueryRuntimeStatisticsInputBuilder::init(
    'QueryExecutionId0'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getQueryRuntimeStatistics(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetQueryRuntimeStatisticsOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Get Session

Gets the full details of a previously created session, including the session status and configuration.

```php
function getSession(
    string $xAmzTarget,
    GetSessionRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget26)`](../../doc/models/x-amz-target-26.md) | Header, Required | - |
| `body` | [`GetSessionRequest`](../../doc/models/get-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetSessionResponse`](../../doc/models/get-session-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget26::ENUM_AMAZONATHENAGETSESSION;

$body = GetSessionRequestBuilder::init(
    'SessionId2'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getSession(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetSessionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Session Status

Gets the current status of a session.

```php
function getSessionStatus(
    string $xAmzTarget,
    GetSessionStatusRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget27)`](../../doc/models/x-amz-target-27.md) | Header, Required | - |
| `body` | [`GetSessionStatusRequest`](../../doc/models/get-session-status-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetSessionStatusResponse`](../../doc/models/get-session-status-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget27::ENUM_AMAZONATHENAGETSESSIONSTATUS;

$body = GetSessionStatusRequestBuilder::init(
    'SessionId2'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getSessionStatus(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetSessionStatusResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Get Table Metadata

Returns table metadata for the specified catalog, database, and table.

```php
function getTableMetadata(
    string $xAmzTarget,
    GetTableMetadataInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget28)`](../../doc/models/x-amz-target-28.md) | Header, Required | - |
| `body` | [`GetTableMetadataInput`](../../doc/models/get-table-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetTableMetadataOutput`](../../doc/models/get-table-metadata-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget28::ENUM_AMAZONATHENAGETTABLEMETADATA;

$body = GetTableMetadataInputBuilder::init(
    'CatalogName0',
    'DatabaseName0',
    'TableName2'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getTableMetadata(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetTableMetadataOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# Get Work Group

Returns information about the workgroup with the specified name.

```php
function getWorkGroup(
    string $xAmzTarget,
    GetWorkGroupInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget29)`](../../doc/models/x-amz-target-29.md) | Header, Required | - |
| `body` | [`GetWorkGroupInput`](../../doc/models/get-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`GetWorkGroupOutput`](../../doc/models/get-work-group-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget29::ENUM_AMAZONATHENAGETWORKGROUP;

$body = GetWorkGroupInputBuilder::init(
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->getWorkGroup(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'GetWorkGroupOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Import Notebook

Imports a single <code>ipynb</code> file to a Spark enabled workgroup. The maximum file size that can be imported is 10 megabytes. If an <code>ipynb</code> file with the same name already exists in the workgroup, throws an error.

```php
function importNotebook(
    string $xAmzTarget,
    ImportNotebookInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget30)`](../../doc/models/x-amz-target-30.md) | Header, Required | - |
| `body` | [`ImportNotebookInput`](../../doc/models/import-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ImportNotebookOutput`](../../doc/models/import-notebook-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget30::ENUM_AMAZONATHENAIMPORTNOTEBOOK;

$body = ImportNotebookInputBuilder::init(
    'WorkGroup8',
    'Name6',
    'Payload2',
    NotebookType2::IPYNB
)->build();

$api = $client->getAPI();
$apiResponse = $api->importNotebook(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ImportNotebookOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Application DPU Sizes

Returns the supported DPU sizes for the supported application runtimes (for example, <code>Athena notebook version 1</code>).

```php
function listApplicationDpuSizes(
    string $xAmzTarget,
    ListApplicationDpuSizesInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget31)`](../../doc/models/x-amz-target-31.md) | Header, Required | - |
| `body` | [`ListApplicationDpuSizesInput`](../../doc/models/list-application-dpu-sizes-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListApplicationDpuSizesOutput`](../../doc/models/list-application-dpu-sizes-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget31::ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES;

$body = ListApplicationDpuSizesInputBuilder::init()->build();

$api = $client->getAPI();
$apiResponse = $api->listApplicationDpuSizes(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListApplicationDpuSizesOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Calculation Executions

Lists the calculations that have been submitted to a session in descending order. Newer calculations are listed first; older calculations are listed later.

```php
function listCalculationExecutions(
    string $xAmzTarget,
    ListCalculationExecutionsRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget32)`](../../doc/models/x-amz-target-32.md) | Header, Required | - |
| `body` | [`ListCalculationExecutionsRequest`](../../doc/models/list-calculation-executions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListCalculationExecutionsResponse`](../../doc/models/list-calculation-executions-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget32::ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS;

$body = ListCalculationExecutionsRequestBuilder::init(
    'SessionId2'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listCalculationExecutions(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListCalculationExecutionsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Data Catalogs

<p>Lists the data catalogs in the current Amazon Web Services account.</p> <note> <p>In the Athena console, data catalogs are listed as "data sources" on the <b>Data sources</b> page under the <b>Data source name</b> column.</p> </note>


```php
function listDataCatalogs(
    string $xAmzTarget,
    ListDataCatalogsInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget33)`](../../doc/models/x-amz-target-33.md) | Header, Required | - |
| `body` | [`ListDataCatalogsInput`](../../doc/models/list-data-catalogs-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListDataCatalogsOutput`](../../doc/models/list-data-catalogs-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget33::ENUM_AMAZONATHENALISTDATACATALOGS;

$body = ListDataCatalogsInputBuilder::init()->build();

$api = $client->getAPI();
$apiResponse = $api->listDataCatalogs(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListDataCatalogsOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Databases

Lists the databases in the specified data catalog.

```php
function listDatabases(
    string $xAmzTarget,
    ListDatabasesInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget34)`](../../doc/models/x-amz-target-34.md) | Header, Required | - |
| `body` | [`ListDatabasesInput`](../../doc/models/list-databases-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListDatabasesOutput`](../../doc/models/list-databases-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget34::ENUM_AMAZONATHENALISTDATABASES;

$body = ListDatabasesInputBuilder::init(
    'CatalogName0'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listDatabases(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListDatabasesOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# List Engine Versions

Returns a list of engine versions that are available to choose from, including the Auto option.

```php
function listEngineVersions(
    string $xAmzTarget,
    ListEngineVersionsInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget35)`](../../doc/models/x-amz-target-35.md) | Header, Required | - |
| `body` | [`ListEngineVersionsInput`](../../doc/models/list-engine-versions-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListEngineVersionsOutput`](../../doc/models/list-engine-versions-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget35::ENUM_AMAZONATHENALISTENGINEVERSIONS;

$body = ListEngineVersionsInputBuilder::init()->build();

$api = $client->getAPI();
$apiResponse = $api->listEngineVersions(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListEngineVersionsOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Executors

Lists, in descending order, the executors that joined a session. Newer executors are listed first; older executors are listed later. The result can be optionally filtered by state.

```php
function listExecutors(
    string $xAmzTarget,
    ListExecutorsRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget36)`](../../doc/models/x-amz-target-36.md) | Header, Required | - |
| `body` | [`ListExecutorsRequest`](../../doc/models/list-executors-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListExecutorsResponse`](../../doc/models/list-executors-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget36::ENUM_AMAZONATHENALISTEXECUTORS;

$body = ListExecutorsRequestBuilder::init(
    'SessionId2'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listExecutors(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListExecutorsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Named Queries

<p>Provides a list of available query IDs only for queries saved in the specified workgroup. Requires that you have access to the specified workgroup. If a workgroup is not specified, lists the saved queries for the primary workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```php
function listNamedQueries(
    string $xAmzTarget,
    ListNamedQueriesInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget37)`](../../doc/models/x-amz-target-37.md) | Header, Required | - |
| `body` | [`ListNamedQueriesInput`](../../doc/models/list-named-queries-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListNamedQueriesOutput`](../../doc/models/list-named-queries-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget37::ENUM_AMAZONATHENALISTNAMEDQUERIES;

$body = ListNamedQueriesInputBuilder::init()->build();

$api = $client->getAPI();
$apiResponse = $api->listNamedQueries(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListNamedQueriesOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Notebook Metadata

Displays the notebook files for the specified workgroup in paginated format.

```php
function listNotebookMetadata(
    string $xAmzTarget,
    ListNotebookMetadataInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget38)`](../../doc/models/x-amz-target-38.md) | Header, Required | - |
| `body` | [`ListNotebookMetadataInput`](../../doc/models/list-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListNotebookMetadataOutput`](../../doc/models/list-notebook-metadata-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget38::ENUM_AMAZONATHENALISTNOTEBOOKMETADATA;

$body = ListNotebookMetadataInputBuilder::init(
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listNotebookMetadata(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListNotebookMetadataOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# List Notebook Sessions

Lists, in descending order, the sessions that have been created in a notebook that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code> or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```php
function listNotebookSessions(
    string $xAmzTarget,
    ListNotebookSessionsRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget39)`](../../doc/models/x-amz-target-39.md) | Header, Required | - |
| `body` | [`ListNotebookSessionsRequest`](../../doc/models/list-notebook-sessions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListNotebookSessionsResponse`](../../doc/models/list-notebook-sessions-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget39::ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS;

$body = ListNotebookSessionsRequestBuilder::init(
    'NotebookId6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listNotebookSessions(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListNotebookSessionsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Prepared Statements

Lists the prepared statements in the specified workgroup.

```php
function listPreparedStatements(
    string $xAmzTarget,
    ListPreparedStatementsInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget40)`](../../doc/models/x-amz-target-40.md) | Header, Required | - |
| `body` | [`ListPreparedStatementsInput`](../../doc/models/list-prepared-statements-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListPreparedStatementsOutput`](../../doc/models/list-prepared-statements-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget40::ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS;

$body = ListPreparedStatementsInputBuilder::init(
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listPreparedStatements(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListPreparedStatementsOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Query Executions

<p>Provides a list of available query execution IDs for the queries in the specified workgroup. If a workgroup is not specified, returns a list of query execution IDs for the primary workgroup. Requires you to have access to the workgroup in which the queries ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```php
function listQueryExecutions(
    string $xAmzTarget,
    ListQueryExecutionsInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget41)`](../../doc/models/x-amz-target-41.md) | Header, Required | - |
| `body` | [`ListQueryExecutionsInput`](../../doc/models/list-query-executions-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListQueryExecutionsOutput`](../../doc/models/list-query-executions-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget41::ENUM_AMAZONATHENALISTQUERYEXECUTIONS;

$body = ListQueryExecutionsInputBuilder::init()->build();

$api = $client->getAPI();
$apiResponse = $api->listQueryExecutions(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListQueryExecutionsOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# List Sessions

Lists the sessions in a workgroup that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code>, or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```php
function listSessions(
    string $xAmzTarget,
    ListSessionsRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget42)`](../../doc/models/x-amz-target-42.md) | Header, Required | - |
| `body` | [`ListSessionsRequest`](../../doc/models/list-sessions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListSessionsResponse`](../../doc/models/list-sessions-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget42::ENUM_AMAZONATHENALISTSESSIONS;

$body = ListSessionsRequestBuilder::init(
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listSessions(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListSessionsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Table Metadata

Lists the metadata for the tables in the specified data catalog database.

```php
function listTableMetadata(
    string $xAmzTarget,
    ListTableMetadataInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget43)`](../../doc/models/x-amz-target-43.md) | Header, Required | - |
| `body` | [`ListTableMetadataInput`](../../doc/models/list-table-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListTableMetadataOutput`](../../doc/models/list-table-metadata-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget43::ENUM_AMAZONATHENALISTTABLEMETADATA;

$body = ListTableMetadataInputBuilder::init(
    'CatalogName0',
    'DatabaseName0'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listTableMetadata(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListTableMetadataOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | MetadataException | `ApiException` |


# List Tags for Resource

Lists the tags associated with an Athena workgroup or data catalog resource.

```php
function listTagsForResource(
    string $xAmzTarget,
    ListTagsForResourceInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget44)`](../../doc/models/x-amz-target-44.md) | Header, Required | - |
| `body` | [`ListTagsForResourceInput`](../../doc/models/list-tags-for-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListTagsForResourceOutput`](../../doc/models/list-tags-for-resource-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget44::ENUM_AMAZONATHENALISTTAGSFORRESOURCE;

$body = ListTagsForResourceInputBuilder::init(
    'ResourceARN4'
)->build();

$api = $client->getAPI();
$apiResponse = $api->listTagsForResource(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListTagsForResourceOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# List Work Groups

Lists available workgroups for the account.

```php
function listWorkGroups(
    string $xAmzTarget,
    ListWorkGroupsInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null,
    ?string $maxResults = null,
    ?string $nextToken = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget45)`](../../doc/models/x-amz-target-45.md) | Header, Required | - |
| `body` | [`ListWorkGroupsInput`](../../doc/models/list-work-groups-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |
| `maxResults` | `?string` | Query, Optional | Pagination limit |
| `nextToken` | `?string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ListWorkGroupsOutput`](../../doc/models/list-work-groups-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget45::ENUM_AMAZONATHENALISTWORKGROUPS;

$body = ListWorkGroupsInputBuilder::init()->build();

$api = $client->getAPI();
$apiResponse = $api->listWorkGroups(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ListWorkGroupsOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Start Calculation Execution

Submits calculations for execution within a session. You can supply the code to run as an inline code block within the request.

```php
function startCalculationExecution(
    string $xAmzTarget,
    StartCalculationExecutionRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget46)`](../../doc/models/x-amz-target-46.md) | Header, Required | - |
| `body` | [`StartCalculationExecutionRequest`](../../doc/models/start-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`StartCalculationExecutionResponse`](../../doc/models/start-calculation-execution-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget46::ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION;

$body = StartCalculationExecutionRequestBuilder::init(
    'SessionId2'
)->build();

$api = $client->getAPI();
$apiResponse = $api->startCalculationExecution(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'StartCalculationExecutionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Start Query Execution

Runs the SQL query statements contained in the <code>Query</code>. Requires you to have access to the workgroup in which the query ran. Running queries against an external catalog requires <a>GetDataCatalog</a> permission to the catalog. For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.

```php
function startQueryExecution(
    string $xAmzTarget,
    StartQueryExecutionInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget47)`](../../doc/models/x-amz-target-47.md) | Header, Required | - |
| `body` | [`StartQueryExecutionInput`](../../doc/models/start-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`StartQueryExecutionOutput`](../../doc/models/start-query-execution-output.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget47::ENUM_AMAZONATHENASTARTQUERYEXECUTION;

$body = StartQueryExecutionInputBuilder::init(
    'QueryString8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->startQueryExecution(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'StartQueryExecutionOutput:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Start Session

Creates a session for running calculations within a workgroup. The session is ready when it reaches an <code>IDLE</code> state.

```php
function startSession(
    string $xAmzTarget,
    StartSessionRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget48)`](../../doc/models/x-amz-target-48.md) | Header, Required | - |
| `body` | [`StartSessionRequest`](../../doc/models/start-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`StartSessionResponse`](../../doc/models/start-session-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget48::ENUM_AMAZONATHENASTARTSESSION;

$body = StartSessionRequestBuilder::init(
    'WorkGroup8',
    EngineConfiguration1Builder::init(
        94
    )->build()
)->build();

$api = $client->getAPI();
$apiResponse = $api->startSession(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'StartSessionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |
| 483 | SessionAlreadyExistsException | `ApiException` |
| 484 | TooManyRequestsException | `ApiException` |


# Stop Calculation Execution

<p>Requests the cancellation of a calculation. A <code>StopCalculationExecution</code> call on a calculation that is already in a terminal state (for example, <code>STOPPED</code>, <code>FAILED</code>, or <code>COMPLETED</code>) succeeds but has no effect.</p> <note> <p>Cancelling a calculation is done on a best effort basis. If a calculation cannot be cancelled, you can be charged for its completion. If you are concerned about being charged for a calculation that cannot be cancelled, consider terminating the session in which the calculation is running.</p> </note>


```php
function stopCalculationExecution(
    string $xAmzTarget,
    StopCalculationExecutionRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget49)`](../../doc/models/x-amz-target-49.md) | Header, Required | - |
| `body` | [`StopCalculationExecutionRequest`](../../doc/models/stop-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`StopCalculationExecutionResponse`](../../doc/models/stop-calculation-execution-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget49::ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION;

$body = StopCalculationExecutionRequestBuilder::init(
    'CalculationExecutionId8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->stopCalculationExecution(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'StopCalculationExecutionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Stop Query Execution

<p>Stops a query execution. Requires you to have access to the workgroup in which the query ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```php
function stopQueryExecution(
    string $xAmzTarget,
    StopQueryExecutionInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget50)`](../../doc/models/x-amz-target-50.md) | Header, Required | - |
| `body` | [`StopQueryExecutionInput`](../../doc/models/stop-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget50::ENUM_AMAZONATHENASTOPQUERYEXECUTION;

$body = StopQueryExecutionInputBuilder::init(
    'QueryExecutionId0'
)->build();

$api = $client->getAPI();
$apiResponse = $api->stopQueryExecution(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Tag Resource

Adds one or more tags to an Athena resource. A tag is a label that you assign to a resource. In Athena, a resource can be a workgroup or data catalog. Each tag consists of a key and an optional value, both of which you define. For example, you can use tags to categorize Athena workgroups or data catalogs by purpose, owner, or environment. Use a consistent set of tag keys to make it easier to search and filter workgroups or data catalogs in your account. For best practices, see <a href="https://docs.aws.amazon.com/whitepapers/latest/tagging-best-practices/tagging-best-practices.html">Tagging Best Practices</a>. Tag keys can be from 1 to 128 UTF-8 Unicode characters, and tag values can be from 0 to 256 UTF-8 Unicode characters. Tags can use letters and numbers representable in UTF-8, and the following characters: + - = . _ : / @. Tag keys and values are case-sensitive. Tag keys must be unique per resource. If you specify more than one tag, separate them by commas.

```php
function tagResource(
    string $xAmzTarget,
    TagResourceInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget51)`](../../doc/models/x-amz-target-51.md) | Header, Required | - |
| `body` | [`TagResourceInput`](../../doc/models/tag-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget51::ENUM_AMAZONATHENATAGRESOURCE;

$body = TagResourceInputBuilder::init(
    'ResourceARN4',
    [
        TagBuilder::init()->build()
    ]
)->build();

$api = $client->getAPI();
$apiResponse = $api->tagResource(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Terminate Session

Terminates an active session. A <code>TerminateSession</code> call on a session that is already inactive (for example, in a <code>FAILED</code>, <code>TERMINATED</code> or <code>TERMINATING</code> state) succeeds but has no effect. Calculations running in the session when <code>TerminateSession</code> is called are forcefully stopped, but may display as <code>FAILED</code> instead of <code>STOPPED</code>.

```php
function terminateSession(
    string $xAmzTarget,
    TerminateSessionRequest $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget52)`](../../doc/models/x-amz-target-52.md) | Header, Required | - |
| `body` | [`TerminateSessionRequest`](../../doc/models/terminate-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`TerminateSessionResponse`](../../doc/models/terminate-session-response.md).

## Example Usage

```php
$xAmzTarget = XAmzTarget52::ENUM_AMAZONATHENATERMINATESESSION;

$body = TerminateSessionRequestBuilder::init(
    'SessionId2'
)->build();

$api = $client->getAPI();
$apiResponse = $api->terminateSession(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'TerminateSessionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Untag Resource

Removes one or more tags from a data catalog or workgroup resource.

```php
function untagResource(
    string $xAmzTarget,
    UntagResourceInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget53)`](../../doc/models/x-amz-target-53.md) | Header, Required | - |
| `body` | [`UntagResourceInput`](../../doc/models/untag-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget53::ENUM_AMAZONATHENAUNTAGRESOURCE;

$body = UntagResourceInputBuilder::init(
    'ResourceARN4',
    [
        'TagKeys9',
        'TagKeys0'
    ]
)->build();

$api = $client->getAPI();
$apiResponse = $api->untagResource(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Update Data Catalog

Updates the data catalog that has the specified name.

```php
function updateDataCatalog(
    string $xAmzTarget,
    UpdateDataCatalogInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget54)`](../../doc/models/x-amz-target-54.md) | Header, Required | - |
| `body` | [`UpdateDataCatalogInput`](../../doc/models/update-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget54::ENUM_AMAZONATHENAUPDATEDATACATALOG;

$body = UpdateDataCatalogInputBuilder::init(
    'Name6',
    DataCatalogType3::HIVE
)->build();

$api = $client->getAPI();
$apiResponse = $api->updateDataCatalog(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Update Named Query

Updates a <a>NamedQuery</a> object. The database or workgroup cannot be updated.

```php
function updateNamedQuery(
    string $xAmzTarget,
    UpdateNamedQueryInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget55)`](../../doc/models/x-amz-target-55.md) | Header, Required | - |
| `body` | [`UpdateNamedQueryInput`](../../doc/models/update-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget55::ENUM_AMAZONATHENAUPDATENAMEDQUERY;

$body = UpdateNamedQueryInputBuilder::init(
    'NamedQueryId6',
    'Name6',
    'QueryString8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->updateNamedQuery(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |


# Update Notebook

Updates the contents of a Spark notebook.

```php
function updateNotebook(
    string $xAmzTarget,
    UpdateNotebookInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget56)`](../../doc/models/x-amz-target-56.md) | Header, Required | - |
| `body` | [`UpdateNotebookInput`](../../doc/models/update-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget56::ENUM_AMAZONATHENAUPDATENOTEBOOK;

$body = UpdateNotebookInputBuilder::init(
    'NotebookId6',
    'Payload2',
    NotebookType2::IPYNB
)->build();

$api = $client->getAPI();
$apiResponse = $api->updateNotebook(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Update Notebook Metadata

Updates the metadata for a notebook.

```php
function updateNotebookMetadata(
    string $xAmzTarget,
    UpdateNotebookMetadataInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget57)`](../../doc/models/x-amz-target-57.md) | Header, Required | - |
| `body` | [`UpdateNotebookMetadataInput`](../../doc/models/update-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget57::ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA;

$body = UpdateNotebookMetadataInputBuilder::init(
    'NotebookId6',
    'Name6'
)->build();

$api = $client->getAPI();
$apiResponse = $api->updateNotebookMetadata(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | TooManyRequestsException | `ApiException` |


# Update Prepared Statement

Updates a prepared statement.

```php
function updatePreparedStatement(
    string $xAmzTarget,
    UpdatePreparedStatementInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget58)`](../../doc/models/x-amz-target-58.md) | Header, Required | - |
| `body` | [`UpdatePreparedStatementInput`](../../doc/models/update-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget58::ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT;

$body = UpdatePreparedStatementInputBuilder::init(
    'StatementName4',
    'WorkGroup8',
    'QueryStatement8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->updatePreparedStatement(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |
| 482 | ResourceNotFoundException | `ApiException` |


# Update Work Group

Updates the workgroup with the specified name. The workgroup's name cannot be changed. Only <code>ConfigurationUpdates</code> can be specified.

```php
function updateWorkGroup(
    string $xAmzTarget,
    UpdateWorkGroupInput $body,
    ?string $xAmzContentSha256 = null,
    ?string $xAmzDate = null,
    ?string $xAmzAlgorithm = null,
    ?string $xAmzCredential = null,
    ?string $xAmzSecurityToken = null,
    ?string $xAmzSignature = null,
    ?string $xAmzSignedHeaders = null
): ApiResponse
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`string(XAmzTarget59)`](../../doc/models/x-amz-target-59.md) | Header, Required | - |
| `body` | [`UpdateWorkGroupInput`](../../doc/models/update-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `?string` | Header, Optional | - |
| `xAmzDate` | `?string` | Header, Optional | - |
| `xAmzAlgorithm` | `?string` | Header, Optional | - |
| `xAmzCredential` | `?string` | Header, Optional | - |
| `xAmzSecurityToken` | `?string` | Header, Optional | - |
| `xAmzSignature` | `?string` | Header, Optional | - |
| `xAmzSignedHeaders` | `?string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `array`.

## Example Usage

```php
$xAmzTarget = XAmzTarget59::ENUM_AMAZONATHENAUPDATEWORKGROUP;

$body = UpdateWorkGroupInputBuilder::init(
    'WorkGroup8'
)->build();

$api = $client->getAPI();
$apiResponse = $api->updateWorkGroup(
    $xAmzTarget,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'array:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiException` |
| 481 | InvalidRequestException | `ApiException` |

