
# Applied to Resource

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `Type` | [`Type5Enum?`](../../doc/models/type-5-enum.md) | Optional | Type of resource referenced |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

AppliedToResource appliedToResource = new AppliedToResource
{
    Server = new Server
    {
        Id = 14,
    },
    Type = Type5Enum.Server,
};
```

