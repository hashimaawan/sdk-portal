
# X Amz Target 47 Enum

## Enumeration

`XAmzTarget47Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTQUERYEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_47_enum import XAmzTarget47Enum

x_amz_target_47 = XAmzTarget47Enum.ENUM_AMAZONATHENASTARTQUERYEXECUTION
```

