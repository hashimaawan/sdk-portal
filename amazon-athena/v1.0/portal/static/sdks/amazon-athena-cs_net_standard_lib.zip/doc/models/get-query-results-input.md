
# Get Query Results Input

## Structure

`GetQueryResultsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 1000` |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetQueryResultsInput getQueryResultsInput = new GetQueryResultsInput
{
    QueryExecutionId = "QueryExecutionId6",
    NextToken = "NextToken2",
    MaxResults = 42,
};
```

