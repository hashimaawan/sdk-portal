
# Result Reuse Information 2

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reused_previous_result` | `TrueClass \| FalseClass` | Required | - |

## Example

```ruby
result_reuse_information2 = ResultReuseInformation2.new(
  false
)
```

