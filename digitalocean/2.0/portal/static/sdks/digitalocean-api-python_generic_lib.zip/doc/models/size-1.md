
# Size 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Size1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | A Droplet size available for use in a Kubernetes node pool. |
| `slug` | `str` | Optional | The identifier for a size for use when creating a new cluster. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.size_1 import Size1

size_1 = Size1(
    name='s-1vcpu-2gb',
    slug='s-1vcpu-2gb',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

