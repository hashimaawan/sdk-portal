
# V2 Databases Users Reset Auth Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResetAuthRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mysqlSettings` | [`?MysqlSettings`](../../doc/models/mysql-settings.md) | Optional | - | getMysqlSettings(): ?MysqlSettings | setMysqlSettings(?MysqlSettings mysqlSettings): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesUsersResetAuthRequestBuilder;
use DigitalOceanApiLib\Models\Builders\MysqlSettingsBuilder;
use DigitalOceanApiLib\Models\AuthPlugin;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesUsersResetAuthRequest = V2DatabasesUsersResetAuthRequestBuilder::init()
    ->mysqlSettings(
        MysqlSettingsBuilder::init(
            AuthPlugin::MYSQL_NATIVE_PASSWORD
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

