
# Result Set Metadata

The metadata that describes the column structure and data types of a table of query results. To return a <code>ResultSetMetadata</code> object, use <a>GetQueryResults</a>.

*This model accepts additional fields of type Object.*

## Structure

`ResultSetMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `column_info` | [`Array[ColumnInfo]`](../../doc/models/column-info.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
result_set_metadata = ResultSetMetadata.new(
  column_info: [
    ColumnInfo.new(
      name: 'Name6',
      type: 'Type6',
      catalog_name: 'CatalogName0',
      schema_name: 'SchemaName0',
      table_name: 'TableName2',
      label: 'Label4',
      precision: 48,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

