
# Type 2

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `USER_CREATED` |
| `PERSONAL` |
| `EVERYONE` |
| `TRANSFER` |

## Example

```php
use M1PasswordConnectLib\Models\Type2;

$type2 = Type2::EVERYONE;
```

