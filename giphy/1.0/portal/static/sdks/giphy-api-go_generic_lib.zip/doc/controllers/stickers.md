# Stickers

```go
stickersApi := client.StickersApi()
```

## Class Name

`StickersApi`

## Methods

* [Random Sticker](../../doc/controllers/stickers.md#random-sticker)
* [Search Stickers](../../doc/controllers/stickers.md#search-stickers)
* [Translate Sticker](../../doc/controllers/stickers.md#translate-sticker)
* [Trending Stickers](../../doc/controllers/stickers.md#trending-stickers)


# Random Sticker

Returns a random GIF, limited by tag. Excluding the tag parameter will return a random GIF from the GIPHY catalog.

```go
RandomSticker(
    ctx context.Context,
    tag *string,
    rating *string) (
    models.ApiResponse[models.StickersRandomResponse],
    error)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tag` | `*string` | Query, Optional | Filters results by specified tag. |
| `rating` | `*string` | Query, Optional | Filters results by specified rating. |

## Response Type

**200**

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.StickersRandomResponse](../../doc/models/stickers-random-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := stickersApi.RandomSticker(ctx, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiError` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiError` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiError` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiError` |


# Search Stickers

Replicates the functionality and requirements of the classic GIPHY search, but returns animated stickers rather than GIFs.

```go
SearchStickers(
    ctx context.Context,
    q string,
    limit *int,
    offset *int,
    rating *string,
    lang *string) (
    models.ApiResponse[models.StickersSearchResponse],
    error)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `q` | `string` | Query, Required | Search query term or prhase. |
| `limit` | `*int` | Query, Optional | The maximum number of records to return.<br><br>**Default**: `25` |
| `offset` | `*int` | Query, Optional | An optional results offset.<br><br>**Default**: `0` |
| `rating` | `*string` | Query, Optional | Filters results by specified rating. |
| `lang` | `*string` | Query, Optional | Specify default language for regional content; use a 2-letter ISO 639-1 language code. |

## Response Type

**200**: Search results

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.StickersSearchResponse](../../doc/models/stickers-search-response.md).

## Example Usage

```go
ctx := context.Background()

q := "q0"

limit := 25

offset := 0

apiResponse, err := stickersApi.SearchStickers(ctx, q, &limit, &offset, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiError` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiError` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiError` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiError` |


# Translate Sticker

The translate API draws on search, but uses the GIPHY `special sauce` to handle translating from one vocabulary to another. In this case, words and phrases to GIFs.

```go
TranslateSticker(
    ctx context.Context,
    s string) (
    models.ApiResponse[models.StickersTranslateResponse],
    error)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s` | `string` | Query, Required | Search term. |

## Response Type

**200**

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.StickersTranslateResponse](../../doc/models/stickers-translate-response.md).

## Example Usage

```go
ctx := context.Background()

s := "s8"

apiResponse, err := stickersApi.TranslateSticker(ctx, s)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiError` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiError` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiError` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiError` |


# Trending Stickers

Fetch Stickers currently trending online. Hand curated by the GIPHY editorial team. Returns 25 results by default.

```go
TrendingStickers(
    ctx context.Context,
    limit *int,
    offset *int,
    rating *string) (
    models.ApiResponse[models.StickersTrendingResponse],
    error)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `*int` | Query, Optional | The maximum number of records to return.<br><br>**Default**: `25` |
| `offset` | `*int` | Query, Optional | An optional results offset.<br><br>**Default**: `0` |
| `rating` | `*string` | Query, Optional | Filters results by specified rating. |

## Response Type

**200**

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.StickersTrendingResponse](../../doc/models/stickers-trending-response.md).

## Example Usage

```go
ctx := context.Background()

limit := 25

offset := 0

apiResponse, err := stickersApi.TrendingStickers(ctx, &limit, &offset, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiError` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiError` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiError` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiError` |

