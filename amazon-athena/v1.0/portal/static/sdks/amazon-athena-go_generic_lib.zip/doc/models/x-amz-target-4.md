
# X Amz Target 4

## Enumeration

`XAmzTarget4`

## Fields

| Name |
|  --- |
| `EnumAmazonathenacreatenamedquery` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget4 := models.XAmzTarget4_EnumAmazonathenacreatenamedquery

}
```

