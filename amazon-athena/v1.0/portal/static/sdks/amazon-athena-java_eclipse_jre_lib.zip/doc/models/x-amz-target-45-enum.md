
# X Amz Target 45 Enum

## Enumeration

`XAmzTarget45Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTWORKGROUPS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget45Enum;

XAmzTarget45Enum xAmzTarget45 = XAmzTarget45Enum.ENUM_AMAZONATHENALISTWORKGROUPS;
```

