
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Item` |
| `Vault` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    mType := models.Type_Item

}
```

