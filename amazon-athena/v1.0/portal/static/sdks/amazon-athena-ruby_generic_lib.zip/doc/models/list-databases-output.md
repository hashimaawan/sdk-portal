
# List Databases Output

## Structure

`ListDatabasesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database_list` | [`Array[Database]`](../../doc/models/database.md) | Optional | - |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_databases_output = ListDatabasesOutput.new(
  [
    Database.new(
      'Name4',
      'Description8',
      Parameters.new
    )
  ],
  'NextToken8'
)
```

