
# App Bandwidth Usage

Bandwidth usage for an app.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`AppBandwidthUsage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appId` | `string \| undefined` | Optional | The ID of the app. |
| `bandwidthBytes` | `string \| undefined` | Optional | The used bandwidth amount in bytes. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { AppBandwidthUsage } from 'digitalocean-apilib';

const appBandwidthUsage: AppBandwidthUsage = {
  appId: '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf',
  bandwidthBytes: '513668',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

