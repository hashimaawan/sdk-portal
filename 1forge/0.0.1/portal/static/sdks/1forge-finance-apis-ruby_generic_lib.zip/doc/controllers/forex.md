# Forex

```ruby
forex_api = client.forex
```

## Class Name

`ForexApi`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```ruby
def get_quotes_for_all_symbols
```

## Response Type

**200**: A list of quotes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
result = forex_api.get_quotes_for_all_symbols

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```ruby
def get_a_list_of_symbols_for_which_we_provide_real_time_quotes
```

## Response Type

**200**: A list of symbols

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type `Array[String]`.

## Example Usage

```ruby
result = forex_api.get_a_list_of_symbols_for_which_we_provide_real_time_quotes

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

