
# Query Stage Plan

*This model accepts additional fields of type object.*

## Structure

`QueryStagePlan`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | - |
| `Identifier` | `string` | Optional | - |
| `Children` | [`List<QueryStagePlanNode>`](../../doc/models/query-stage-plan-node.md) | Optional | - |
| `RemoteSources` | `List<string>` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;
using System.Collections.Generic;

QueryStagePlan queryStagePlan = new QueryStagePlan
{
    Name = "Name0",
    Identifier = "Identifier6",
    Children = new List<QueryStagePlanNode>
    {
        new QueryStagePlanNode
        {
            Name = "Name6",
            Identifier = "Identifier2",
            Children = new List<QueryStagePlanNode>
            {
                new QueryStagePlanNode
                {
                },
            },
            RemoteSources = new List<string>
            {
                "RemoteSources4",
                "RemoteSources5",
                "RemoteSources6",
            },
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
    },
    RemoteSources = new List<string>
    {
        "RemoteSources8",
        "RemoteSources9",
        "RemoteSources0",
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

