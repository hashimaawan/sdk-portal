
# X Amz Target 23

## Enumeration

`XAmzTarget23`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget23;

XAmzTarget23 xAmzTarget23 = XAmzTarget23.ENUM_AMAZONATHENAGETQUERYEXECUTION;
```

