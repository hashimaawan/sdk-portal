
# Mode Enum

travel mode

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```go
package main

import (
    "furkottrips/models"
)

func main() {
    mode := models.ModeEnum_BICYCLE

}
```

