
# X Amz Target 35 Enum

## Enumeration

`XAmzTarget35Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListEngineVersions` |

## Example

```ts
import { XAmzTarget35Enum } from 'amazon-athenalib';

const xAmzTarget35 = XAmzTarget35Enum.EnumAmazonAthenaListEngineVersions;
```

