
# X Amz Target 30 Enum

## Enumeration

`XAmzTarget30Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAIMPORTNOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget30Enum;

XAmzTarget30Enum xAmzTarget30 = XAmzTarget30Enum.ENUM_AMAZONATHENAIMPORTNOTEBOOK;
```

