
# Create Presigned Notebook Url Request

*This model accepts additional fields of type unknown.*

## Structure

`CreatePresignedNotebookUrlRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { CreatePresignedNotebookUrlRequest } from 'amazon-athenalib';

const createPresignedNotebookUrlRequest: CreatePresignedNotebookUrlRequest = {
  sessionId: 'SessionId0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

