
# Row

The rows that make up a query result table.

## Structure

`Row`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Data` | [`List<Datum>`](../../doc/models/datum.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

Row row = new Row
{
    Data = new List<Datum>
    {
        new Datum
        {
            VarCharValue = "VarCharValue8",
        },
    },
};
```

