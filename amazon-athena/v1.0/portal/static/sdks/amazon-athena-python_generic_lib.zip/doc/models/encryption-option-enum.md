
# Encryption Option Enum

## Enumeration

`EncryptionOptionEnum`

## Fields

| Name |
|  --- |
| `SSE_S3` |
| `SSE_KMS` |
| `CSE_KMS` |

## Example

```python
from amazonathena.models.encryption_option_enum import EncryptionOptionEnum

encryption_option = EncryptionOptionEnum.SSE_KMS
```

