
# X Amz Target 55 Enum

## Enumeration

`XAmzTarget55Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAUPDATENAMEDQUERY` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget55 := models.XAmzTarget55Enum_ENUMAMAZONATHENAUPDATENAMEDQUERY

}
```

