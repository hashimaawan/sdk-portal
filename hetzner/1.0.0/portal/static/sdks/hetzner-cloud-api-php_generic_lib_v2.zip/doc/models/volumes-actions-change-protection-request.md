
# Volumes Actions Change Protection Request

## Structure

`VolumesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `delete` | `?bool` | Optional | If true, prevents the Volume from being deleted | getDelete(): ?bool | setDelete(?bool delete): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\VolumesActionsChangeProtectionRequestBuilder;

$volumesActionsChangeProtectionRequest = VolumesActionsChangeProtectionRequestBuilder::init()
    ->delete(true)
    ->build();
```

