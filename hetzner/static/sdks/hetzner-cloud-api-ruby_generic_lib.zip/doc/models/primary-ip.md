
# Primary Ip

## Structure

`PrimaryIp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prices` | [`Array[Price8]`](../../doc/models/price-8.md) | Required | Primary IP type costs per Location |
| `type` | [`Type49Enum`](../../doc/models/type-49-enum.md) | Required | The type of the Primary IP |

## Example

```ruby
primary_ip = PrimaryIp.new(
  [
    Price8.new(
      'fsn1',
      PriceHourly7.new(
        '1.1900000000000000',
        '1.0000000000'
      ),
      PriceMonthly9.new(
        '1.1900000000000000',
        '1.0000000000'
      )
    )
  ],
  Type49Enum::IPV4
)
```

