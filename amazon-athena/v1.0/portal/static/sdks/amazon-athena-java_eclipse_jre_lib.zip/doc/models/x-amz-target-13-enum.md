
# X Amz Target 13 Enum

## Enumeration

`XAmzTarget13Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEWORKGROUP` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget13Enum;

XAmzTarget13Enum xAmzTarget13 = XAmzTarget13Enum.ENUM_AMAZONATHENADELETEWORKGROUP;
```

