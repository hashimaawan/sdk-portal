
# Calculation Configuration

Contains configuration information for the calculation.

*This model accepts additional fields of type object.*

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CodeBlock` | `string` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

CalculationConfiguration calculationConfiguration = new CalculationConfiguration
{
    CodeBlock = "CodeBlock2",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

