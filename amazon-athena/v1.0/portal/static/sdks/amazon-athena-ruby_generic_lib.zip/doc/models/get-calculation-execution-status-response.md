
# Get Calculation Execution Status Response

## Structure

`GetCalculationExecutionStatusResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`Status1`](../../doc/models/status-1.md) | Optional | - |
| `statistics` | [`Statistics1`](../../doc/models/statistics-1.md) | Optional | - |

## Example

```ruby
get_calculation_execution_status_response = GetCalculationExecutionStatusResponse.new(
  Status1.new(
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    CalculationExecutionState1Enum::CANCELING,
    'StateChangeReason8'
  ),
  Statistics1.new(
    164,
    'Progress6'
  )
)
```

