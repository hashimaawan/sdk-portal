
# Type 5

Type of resource referenced

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `SERVER` |

## Example

```java
import cloud.hetzner.api.models.Type5;

Type5 type5 = Type5.SERVER;
```

