
# Table Metadata 2

*This model accepts additional fields of type Object.*

## Structure

`TableMetadata2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `create_time` | `DateTime` | Optional | - |
| `last_access_time` | `DateTime` | Optional | - |
| `table_type` | `String` | Optional | **Constraints**: *Maximum Length*: `255` |
| `columns` | [`Array[Column]`](../../doc/models/column.md) | Optional | - |
| `partition_keys` | [`Array[Column]`](../../doc/models/column.md) | Optional | - |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
table_metadata2 = TableMetadata2.new(
  name: 'Name6',
  create_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  last_access_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  table_type: 'TableType2',
  columns: [
    Column.new(
      name: 'Name0',
      type: 'Type0',
      comment: 'Comment4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Column.new(
      name: 'Name0',
      type: 'Type0',
      comment: 'Comment4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  partition_keys: [
    Column.new(
      name: 'Name6',
      type: 'Type6',
      comment: 'Comment0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

