
# Start Query Execution Output

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    startQueryExecutionOutput := models.StartQueryExecutionOutput{
        QueryExecutionId:     models.ToPointer("QueryExecutionId0"),
    }

}
```

