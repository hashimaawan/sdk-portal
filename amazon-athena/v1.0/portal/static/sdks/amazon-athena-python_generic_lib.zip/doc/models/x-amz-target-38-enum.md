
# X Amz Target 38 Enum

## Enumeration

`XAmzTarget38Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_38_enum import XAmzTarget38Enum

x_amz_target_38 = XAmzTarget38Enum.ENUM_AMAZONATHENALISTNOTEBOOKMETADATA
```

