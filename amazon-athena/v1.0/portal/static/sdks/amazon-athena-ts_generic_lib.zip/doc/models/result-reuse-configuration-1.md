
# Result Reuse Configuration 1

*This model accepts additional fields of type unknown.*

## Structure

`ResultReuseConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resultReuseByAgeConfiguration` | [`ResultReuseByAgeConfiguration2 \| undefined`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ResultReuseConfiguration1 } from 'amazon-athenalib';

const resultReuseConfiguration1: ResultReuseConfiguration1 = {
  resultReuseByAgeConfiguration: {
    enabled: false,
    maxAgeInMinutes: 26,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

