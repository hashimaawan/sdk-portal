# Gifs

```csharp
GifsController gifsController = client.GifsController;
```

## Class Name

`GifsController`

## Methods

* [Get Gifs by Id](../../doc/controllers/gifs.md#get-gifs-by-id)
* [Random Gif](../../doc/controllers/gifs.md#random-gif)
* [Search Gifs](../../doc/controllers/gifs.md#search-gifs)
* [Translate Gif](../../doc/controllers/gifs.md#translate-gif)
* [Trending Gifs](../../doc/controllers/gifs.md#trending-gifs)
* [Get Gif by Id](../../doc/controllers/gifs.md#get-gif-by-id)


# Get Gifs by Id

A multiget version of the get GIF by ID endpoint.

```csharp
GetGifsByIdAsync(
    string ids = null)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ids` | `string` | Query, Optional | Filters results by specified GIF IDs, separated by commas. |

## Response Type

**200**

[`Task<Models.GifsResponse>`](../../doc/models/gifs-response.md)

## Example Usage

```csharp
try
{
    GifsResponse result = await gifsController.GetGifsByIdAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Random Gif

Returns a random GIF, limited by tag. Excluding the tag parameter will return a random GIF from the GIPHY catalog.

```csharp
RandomGifAsync(
    string tag = null,
    string rating = null)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tag` | `string` | Query, Optional | Filters results by specified tag. |
| `rating` | `string` | Query, Optional | Filters results by specified rating. |

## Response Type

**200**

[`Task<Models.GifsRandomResponse>`](../../doc/models/gifs-random-response.md)

## Example Usage

```csharp
try
{
    GifsRandomResponse result = await gifsController.RandomGifAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Search Gifs

Search all GIPHY GIFs for a word or phrase. Punctuation will be stripped and ignored.  Use a plus or url encode for phrases. Example paul+rudd, ryan+gosling or american+psycho.

```csharp
SearchGifsAsync(
    string q,
    int? limit = 25,
    int? offset = 0,
    string rating = null,
    string lang = null)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `q` | `string` | Query, Required | Search query term or prhase. |
| `limit` | `int?` | Query, Optional | The maximum number of records to return.<br><br>**Default**: `25` |
| `offset` | `int?` | Query, Optional | An optional results offset.<br><br>**Default**: `0` |
| `rating` | `string` | Query, Optional | Filters results by specified rating. |
| `lang` | `string` | Query, Optional | Specify default language for regional content; use a 2-letter ISO 639-1 language code. |

## Response Type

**200**: Search results

[`Task<Models.GifsSearchResponse>`](../../doc/models/gifs-search-response.md)

## Example Usage

```csharp
string q = "q0";
int? limit = 25;
int? offset = 0;
try
{
    GifsSearchResponse result = await gifsController.SearchGifsAsync(
        q,
        limit,
        offset
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Translate Gif

The translate API draws on search, but uses the GIPHY `special sauce` to handle translating from one vocabulary to another. In this case, words and phrases to GIF

```csharp
TranslateGifAsync(
    string s)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s` | `string` | Query, Required | Search term. |

## Response Type

**200**

[`Task<Models.GifsTranslateResponse>`](../../doc/models/gifs-translate-response.md)

## Example Usage

```csharp
string s = "s8";
try
{
    GifsTranslateResponse result = await gifsController.TranslateGifAsync(s);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Trending Gifs

Fetch GIFs currently trending online. Hand curated by the GIPHY editorial team.  The data returned mirrors the GIFs showcased on the GIPHY homepage. Returns 25 results by default.

```csharp
TrendingGifsAsync(
    int? limit = 25,
    int? offset = 0,
    string rating = null)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `int?` | Query, Optional | The maximum number of records to return.<br><br>**Default**: `25` |
| `offset` | `int?` | Query, Optional | An optional results offset.<br><br>**Default**: `0` |
| `rating` | `string` | Query, Optional | Filters results by specified rating. |

## Response Type

**200**

[`Task<Models.GifsTrendingResponse>`](../../doc/models/gifs-trending-response.md)

## Example Usage

```csharp
int? limit = 25;
int? offset = 0;
try
{
    GifsTrendingResponse result = await gifsController.TrendingGifsAsync(
        limit,
        offset
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |


# Get Gif by Id

Returns a GIF given that GIF's unique ID

```csharp
GetGifByIdAsync(
    int gifId)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gifId` | `int` | Template, Required | Filters results by specified GIF ID. |

## Response Type

**200**

[`Task<Models.GifsResponse1>`](../../doc/models/gifs-response-1.md)

## Example Usage

```csharp
int gifId = 250;
try
{
    GifsResponse1 result = await gifsController.GetGifByIdAsync(gifId);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `ApiException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `ApiException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `ApiException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `ApiException` |

