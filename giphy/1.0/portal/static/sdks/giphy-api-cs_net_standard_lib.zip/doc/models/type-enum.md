
# Type Enum

Type of the gif. By default, this is almost always gif

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `Gif` |

## Example

```csharp
using GiphyAPI.Standard.Models;

TypeEnum type = TypeEnum.Gif;
```

