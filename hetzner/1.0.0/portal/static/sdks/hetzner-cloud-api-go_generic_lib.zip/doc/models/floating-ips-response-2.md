
# Floating Ips Response 2

*This model accepts additional fields of type interface{}.*

## Structure

`FloatingIpsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FloatingIp` | [`models.FloatingIp`](../../doc/models/floating-ip.md) | Required | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    floatingIpsResponse2 := models.FloatingIpsResponse2{
        FloatingIp:            models.FloatingIp{
            Blocked:               false,
            Created:               "2016-01-30T23:55:00+00:00",
            Description:           models.ToPointer("this describes my resource"),
            DnsPtr:                []models.DnsPtr{
                models.DnsPtr{
                    DnsPtr:                "server.example.com",
                    Ip:                    "2001:db8::1",
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                },
            },
            HomeLocation:          models.HomeLocation{
                City:                  "Falkenstein",
                Country:               "DE",
                Description:           "Falkenstein DC Park 1",
                Id:                    float64(1),
                Latitude:              float64(50.47612),
                Longitude:             float64(12.370071),
                Name:                  "fsn1",
                NetworkZone:           "eu-central",
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            Id:                    42,
            Ip:                    "131.232.99.1",
            Labels:                map[string]string{
                "key0": "labels4",
                "key1": "labels3",
                "key2": "labels2",
            },
            Name:                  "my-resource",
            Protection:            models.Protection{
                Delete:                false,
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            Server:                models.ToPointer(42),
            Type:                  models.Type16_Ipv4,
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

