
# List Data Catalogs Input

## Structure

`ListDataCatalogsInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NextToken` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getNextToken() | setNextToken(String nextToken) |
| `MaxResults` | `Integer` | Optional | **Constraints**: `>= 2`, `<= 50` | Integer getMaxResults() | setMaxResults(Integer maxResults) |

## Example

```java
import com.amazonaws.useast1.athena.models.ListDataCatalogsInput;

ListDataCatalogsInput listDataCatalogsInput = new ListDataCatalogsInput.Builder()
    .nextToken("NextToken8")
    .maxResults(50)
    .build();
```

