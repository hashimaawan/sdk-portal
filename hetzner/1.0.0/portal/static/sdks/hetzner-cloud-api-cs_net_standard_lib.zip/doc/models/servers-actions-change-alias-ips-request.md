
# Servers Actions Change Alias Ips Request

## Structure

`ServersActionsChangeAliasIpsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AliasIps` | `List<string>` | Required | New alias IPs to set for this Server |
| `Network` | `int` | Required | ID of an existing Network already attached to the Server |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

ServersActionsChangeAliasIpsRequest serversActionsChangeAliasIpsRequest = new ServersActionsChangeAliasIpsRequest
{
    AliasIps = new List<string>
    {
        "10.0.1.2",
    },
    Network = 4711,
};
```

