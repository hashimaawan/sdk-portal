
# List Notebook Metadata Output

*This model accepts additional fields of type array.*

## Structure

`ListNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |
| `notebookMetadataList` | [`?(NotebookMetadata[])`](../../doc/models/notebook-metadata.md) | Optional | - | getNotebookMetadataList(): ?array | setNotebookMetadataList(?array notebookMetadataList): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListNotebookMetadataOutputBuilder;
use AmazonAthenaLib\Models\Builders\NotebookMetadataBuilder;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\Models\NotebookType1;
use AmazonAthenaLib\ApiHelper;

$listNotebookMetadataOutput = ListNotebookMetadataOutputBuilder::init()
    ->nextToken('NextToken2')
    ->notebookMetadataList(
        [
            NotebookMetadataBuilder::init()
                ->notebookId('NotebookId4')
                ->name('Name4')
                ->workGroup('WorkGroup6')
                ->creationTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->type(NotebookType1::IPYNB)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

