# Actions

Actions show the results and progress of asynchronous requests to the API.

```php
$actionsController = $client->getActionsController();
```

## Class Name

`ActionsController`

## Methods

* [Get All Actions](../../doc/controllers/actions.md#get-all-actions)
* [Get an Action](../../doc/controllers/actions.md#get-an-action)


# Get All Actions

Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```php
function getAllActions(?int $id = null, ?string $sort = null, ?string $status = null): ActionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `?int` | Query, Optional | Can be used multiple times, the response will contain only Actions with specified IDs |
| `sort` | [`?string(ParameterSortEnum)`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`?string(ParameterStatusEnum)`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```php
$actionsController = $client->getActionsController();

try {
    $result = $actionsController->getAllActions();
    echo 'ActionsResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get an Action

Returns a specific Action object.

```php
function getAnAction(int $id): ActionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |

## Response Type

**200**: The `action` key in the reply has this structure

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```php
$id = 112;

$actionsController = $client->getActionsController();

try {
    $result = $actionsController->getAnAction($id);
    echo 'ActionResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

