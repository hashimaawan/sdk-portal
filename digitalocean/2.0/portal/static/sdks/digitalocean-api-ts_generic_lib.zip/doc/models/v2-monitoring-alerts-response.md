
# V2 Monitoring Alerts Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2MonitoringAlertsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `policies` | [`Policy[]`](../../doc/models/policy.md) | Required | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Compare,
  Type17,
  V2MonitoringAlertsResponse,
  Window1,
} from 'digitalocean-apilib';

const v2MonitoringAlertsResponse: V2MonitoringAlertsResponse = {
  policies: [
    {
      alerts: {
        email: [
          'bob@exmaple.com'
        ],
        slack: [
          {
            channel: 'Production Alerts',
            url: 'https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ',
            additionalProperties: {
              'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
            },
          }
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      compare: Compare.GreaterThan,
      description: 'CPU Alert',
      enabled: true,
      entities: [
        '192018292'
      ],
      tags: [
        'droplet_tag'
      ],
      type: Type17.EnumV1Insightsdropletcpu,
      uuid: '78b3da62-27e5-49ba-ac70-5db0b5935c64',
      value: 80,
      window: Window1.Enum5M,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

