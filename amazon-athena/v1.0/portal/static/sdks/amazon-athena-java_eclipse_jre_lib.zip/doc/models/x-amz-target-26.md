
# X Amz Target 26

## Enumeration

`XAmzTarget26`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget26;

XAmzTarget26 xAmzTarget26 = XAmzTarget26.ENUM_AMAZONATHENAGETSESSION;
```

