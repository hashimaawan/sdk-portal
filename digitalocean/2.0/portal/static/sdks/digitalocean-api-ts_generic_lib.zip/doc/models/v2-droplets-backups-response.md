
# V2 Droplets Backups Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DropletsBackupsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `backups` | [`Backup1[] \| undefined`](../../doc/models/backup-1.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type13, V2DropletsBackupsResponse } from 'digitalocean-apilib';

const v2DropletsBackupsResponse: V2DropletsBackupsResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  backups: [
    {
      id: 196,
      createdAt: '2016-03-13T12:52:32.123Z',
      minDiskSize: 242,
      name: 'name4',
      regions: [
        'regions9',
        'regions0',
        'regions1'
      ],
      sizeGigabytes: 180.5,
      type: Type13.Snapshot,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      id: 196,
      createdAt: '2016-03-13T12:52:32.123Z',
      minDiskSize: 242,
      name: 'name4',
      regions: [
        'regions9',
        'regions0',
        'regions1'
      ],
      sizeGigabytes: 180.5,
      type: Type13.Snapshot,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

