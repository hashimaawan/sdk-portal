
# Type 51 Enum

Primary IP type

## Enumeration

`Type51Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type51Enum } from 'hetzner-cloud-apilib';

const type51 = Type51Enum.Ipv4;
```

