
# Album Group

This field describes the relationship between the artist and the album.

## Enumeration

`AlbumGroup`

## Fields

| Name |
|  --- |
| `Album` |
| `Single` |
| `Compilation` |
| `AppearsOn` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    albumGroup := models.AlbumGroup_Compilation

}
```

