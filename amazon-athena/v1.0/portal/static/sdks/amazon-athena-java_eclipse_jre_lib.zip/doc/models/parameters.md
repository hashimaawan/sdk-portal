
# Parameters

*This model accepts additional fields of type String.*

## Structure

`Parameters`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AdditionalProperties` | `Map<String, String>` | Optional | **Constraints**: *Maximum Length*: `51200` | String getAdditionalProperty(String key) | additionalProperty(String key, String value) |

## Example (as JSON)

```json
{
  "exampleAdditionalProperty": "Parameters_additionalProperties2"
}
```

