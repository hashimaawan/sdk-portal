
# X Amz Target 56 Enum

## Enumeration

`XAmzTarget56Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget56Enum;

XAmzTarget56Enum xAmzTarget56 = XAmzTarget56Enum.ENUM_AMAZONATHENAUPDATENOTEBOOK;
```

