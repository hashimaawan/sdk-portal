
# Engine

- MYSQL: MySQL
- PG: PostgreSQL
- REDIS: Redis

## Enumeration

`Engine`

## Fields

| Name |
|  --- |
| `UNSET_` |
| `MYSQL` |
| `PG` |
| `REDIS` |

## Example

```php
use DigitalOceanApiLib\Models\Engine;

$engine = Engine::PG;
```

