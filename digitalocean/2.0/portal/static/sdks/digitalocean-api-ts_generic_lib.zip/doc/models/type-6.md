
# Type 6

Type of billing history entry.

## Enumeration

`Type6`

## Fields

| Name |
|  --- |
| `AchFailure` |
| `Adjustment` |
| `AttemptFailed` |
| `Chargeback` |
| `Credit` |
| `CreditExpiration` |
| `Invoice` |
| `Payment` |
| `Refund` |
| `Reversal` |

## Example

```ts
import { Type6 } from 'digitalocean-apilib';

const type6 = Type6.Credit;
```

