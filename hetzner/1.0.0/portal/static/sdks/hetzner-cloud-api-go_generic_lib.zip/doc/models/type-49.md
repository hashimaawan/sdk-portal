
# Type 49

The type of the Primary IP

## Enumeration

`Type49`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type49 := models.Type49_Ipv4

}
```

