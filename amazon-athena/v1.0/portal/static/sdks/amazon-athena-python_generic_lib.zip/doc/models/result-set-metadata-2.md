
# Result Set Metadata 2

## Structure

`ResultSetMetadata2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `column_info` | [`List[ColumnInfo]`](../../doc/models/column-info.md) | Optional | - |

## Example

```python
from amazonathena.models.column_info import ColumnInfo
from amazonathena.models.result_set_metadata_2 import ResultSetMetadata2

result_set_metadata_2 = ResultSetMetadata2(
    column_info=[
        ColumnInfo(
            name='Name6',
            mtype='Type6',
            catalog_name='CatalogName0',
            schema_name='SchemaName0',
            table_name='TableName2',
            label='Label4',
            precision=48
        )
    ]
)
```

