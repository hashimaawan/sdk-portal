
# Datacenters Response 1

## Structure

`DatacentersResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Datacenter` | [`Datacenter`](../../doc/models/datacenter.md) | Required | - | Datacenter getDatacenter() | setDatacenter(Datacenter datacenter) |

## Example

```java
import cloud.hetzner.api.models.Datacenter;
import cloud.hetzner.api.models.DatacentersResponse1;
import cloud.hetzner.api.models.Location;
import cloud.hetzner.api.models.ServerTypes;
import java.util.Arrays;

DatacentersResponse1 datacentersResponse1 = new DatacentersResponse1.Builder(
    new Datacenter.Builder(
        "Falkenstein DC Park 8",
        42,
        new Location.Builder(
            "Falkenstein",
            "DE",
            "Falkenstein DC Park 1",
            1D,
            50.47612D,
            12.370071D,
            "fsn1",
            "eu-central"
        )
        .build(),
        "fsn1-dc8",
        new ServerTypes.Builder(
            Arrays.asList(
                1D,
                2D,
                3D
            ),
            Arrays.asList(
                1D,
                2D,
                3D
            ),
            Arrays.asList(
                1D,
                2D,
                3D
            )
        )
        .build()
    )
    .build()
)
.build();
```

