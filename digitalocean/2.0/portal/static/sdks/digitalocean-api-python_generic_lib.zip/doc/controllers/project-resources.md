# Project Resources

```python
project_resources_api = client.project_resources
```

## Class Name

`ProjectResourcesApi`

## Methods

* [Projects List Resources Default](../../doc/controllers/project-resources.md#projects-list-resources-default)
* [Projects Assign Resources Default](../../doc/controllers/project-resources.md#projects-assign-resources-default)
* [Projects List Resources](../../doc/controllers/project-resources.md#projects-list-resources)
* [Projects Assign Resources](../../doc/controllers/project-resources.md#projects-assign-resources)


# Projects List Resources Default

To list all your resources in your default project, send a GET request to `/v2/projects/default/resources`.

```python
def projects_list_resources_default(self)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse`](../../doc/models/v2-projects-default-resources-response.md).

## Example Usage

```python
result = project_resources_api.projects_list_resources_default()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects Assign Resources Default

To assign resources to your default project, send a POST request to `/v2/projects/default/resources`.

```python
def projects_assign_resources_default(self,
                                     body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2ProjectsDefaultResourcesRequest`](../../doc/models/v2-projects-default-resources-request.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse1`](../../doc/models/v2-projects-default-resources-response-1.md).

## Example Usage

```python
body = V2ProjectsDefaultResourcesRequest(
    resources=[
        'do:droplet:13457723',
        'do:domain:example.com'
    ]
)

result = project_resources_api.projects_assign_resources_default(body)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects List Resources

To list all your resources in a project, send a GET request to `/v2/projects/$PROJECT_ID/resources`.

```python
def projects_list_resources(self,
                           project_id,
                           per_page=20,
                           page=1)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `project_id` | `uuid\|str` | Template, Required | A unique identifier for a project. |
| `per_page` | `int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse`](../../doc/models/v2-projects-default-resources-response.md).

## Example Usage

```python
project_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

per_page = 2

page = 1

result = project_resources_api.projects_list_resources(
    project_id,
    per_page=per_page,
    page=page
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects Assign Resources

To assign resources to a project, send a POST request to `/v2/projects/$PROJECT_ID/resources`.

```python
def projects_assign_resources(self,
                             project_id,
                             body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `project_id` | `uuid\|str` | Template, Required | A unique identifier for a project. |
| `body` | [`V2ProjectsDefaultResourcesRequest`](../../doc/models/v2-projects-default-resources-request.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse1`](../../doc/models/v2-projects-default-resources-response-1.md).

## Example Usage

```python
project_id = '4de7ac8b-495b-4884-9a69-1050c6793cd6'

body = V2ProjectsDefaultResourcesRequest(
    resources=[
        'do:droplet:13457723',
        'do:domain:example.com'
    ]
)

result = project_resources_api.projects_assign_resources(
    project_id,
    body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

