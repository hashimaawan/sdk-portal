
# Status 23

## Enumeration

`Status23`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Status23 status23 = Status23.Available;
```

