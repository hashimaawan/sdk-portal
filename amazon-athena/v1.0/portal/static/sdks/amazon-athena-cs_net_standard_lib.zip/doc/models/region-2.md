
# Region 2

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `Cnnorth1` |
| `Cnnorthwest1` |

## Example

```csharp
using AmazonAthena.Standard.Models;

Region2 region2 = Region2.Cnnorth1;
```

