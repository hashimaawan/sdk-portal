
# X Amz Target 37

## Enumeration

`XAmzTarget37`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNamedQueries` |

## Example

```ts
import { XAmzTarget37 } from 'amazon-athenalib';

const xAmzTarget37 = XAmzTarget37.EnumAmazonAthenaListNamedQueries;
```

