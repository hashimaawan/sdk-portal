
# X Amz Target 47

## Enumeration

`XAmzTarget47`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTQUERYEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget47;

$xAmzTarget47 = XAmzTarget47::ENUM_AMAZONATHENASTARTQUERYEXECUTION;
```

