
# Statistics

## Structure

`Statistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `engine_execution_time_in_millis` | `Integer` | Optional | - |
| `data_scanned_in_bytes` | `Integer` | Optional | - |
| `data_manifest_location` | `String` | Optional | - |
| `total_execution_time_in_millis` | `Integer` | Optional | - |
| `query_queue_time_in_millis` | `Integer` | Optional | - |
| `query_planning_time_in_millis` | `Integer` | Optional | - |
| `service_processing_time_in_millis` | `Integer` | Optional | - |
| `result_reuse_information` | [`ResultReuseInformation2`](../../doc/models/result-reuse-information-2.md) | Optional | - |

## Example

```ruby
statistics = Statistics.new(
  72,
  60,
  'DataManifestLocation0',
  146,
  116,
  nil,
  nil,
  ResultReuseInformation2.new
)
```

