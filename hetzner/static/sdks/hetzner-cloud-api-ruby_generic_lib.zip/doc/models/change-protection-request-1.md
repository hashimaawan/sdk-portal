
# Change Protection Request 1

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Network from being deleted |

## Example

```ruby
change_protection_request1 = ChangeProtectionRequest1.new(
  true
)
```

