
# Mode

travel mode

## Enumeration

`Mode`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```java
import com.furkot.trips.models.Mode;

Mode mode = Mode.BICYCLE;
```

