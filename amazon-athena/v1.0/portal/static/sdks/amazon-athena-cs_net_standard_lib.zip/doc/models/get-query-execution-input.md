
# Get Query Execution Input

## Structure

`GetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetQueryExecutionInput getQueryExecutionInput = new GetQueryExecutionInput
{
    QueryExecutionId = "QueryExecutionId8",
};
```

