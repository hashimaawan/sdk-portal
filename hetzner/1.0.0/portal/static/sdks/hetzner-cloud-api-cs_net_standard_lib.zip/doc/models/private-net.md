
# Private Net

## Structure

`PrivateNet`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Ip` | `string` | Optional | - |
| `Network` | `int?` | Optional | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

PrivateNet privateNet = new PrivateNet
{
    Ip = "10.0.0.2",
    Network = 4711,
};
```

