
# Type 24 Enum

Destination Image type to convert to

## Enumeration

`Type24Enum`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |

## Example

```python
from hetznercloudapi.models.type_24_enum import Type24Enum

type_24 = Type24Enum.SNAPSHOT
```

