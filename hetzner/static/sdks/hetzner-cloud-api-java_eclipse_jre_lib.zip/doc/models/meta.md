
# Meta

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Pagination` | [`Pagination`](../../doc/models/pagination.md) | Required | - | Pagination getPagination() | setPagination(Pagination pagination) |

## Example

```java
import cloud.hetzner.api.models.Meta;
import cloud.hetzner.api.models.Pagination;

Meta meta = new Meta.Builder(
    new Pagination.Builder(
        4D,
        4D,
        3D,
        25D,
        2D,
        100D
    )
    .build()
)
.build();
```

