
# Volumes Actions Change Protection Request

## Structure

`VolumesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the Volume from being deleted |

## Example

```ts
import { VolumesActionsChangeProtectionRequest } from 'hetzner-cloud-apilib';

const volumesActionsChangeProtectionRequest: VolumesActionsChangeProtectionRequest = {
  mDelete: true,
};
```

