
# Slack

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Slack`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `str` | Required | Slack channel to notify of an alert trigger. |
| `url` | `str` | Required | Slack Webhook URL. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.slack import Slack

slack = Slack(
    channel='Production Alerts',
    url='https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

