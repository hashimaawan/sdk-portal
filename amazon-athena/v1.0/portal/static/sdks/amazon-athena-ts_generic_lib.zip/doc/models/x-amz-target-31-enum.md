
# X Amz Target 31 Enum

## Enumeration

`XAmzTarget31Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListApplicationDPUSizes` |

## Example

```ts
import { XAmzTarget31Enum } from 'amazon-athenalib';

const xAmzTarget31 = XAmzTarget31Enum.EnumAmazonAthenaListApplicationDPUSizes;
```

