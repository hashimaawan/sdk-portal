# Load Balancer Actions

```ts
const loadBalancerActionsApi = new LoadBalancerActionsApi(client);
```

## Class Name

`LoadBalancerActionsApi`

## Methods

* [Get All Actions for a Load Balancer](../../doc/controllers/load-balancer-actions.md#get-all-actions-for-a-load-balancer)
* [Add Service](../../doc/controllers/load-balancer-actions.md#add-service)
* [Add Target](../../doc/controllers/load-balancer-actions.md#add-target)
* [Attach a Load Balancer to a Network](../../doc/controllers/load-balancer-actions.md#attach-a-load-balancer-to-a-network)
* [Change Algorithm](../../doc/controllers/load-balancer-actions.md#change-algorithm)
* [Change Reverse DNS Entry for This Load Balancer](../../doc/controllers/load-balancer-actions.md#change-reverse-dns-entry-for-this-load-balancer)
* [Change Load Balancer Protection](../../doc/controllers/load-balancer-actions.md#change-load-balancer-protection)
* [Change the Type of a Load Balancer](../../doc/controllers/load-balancer-actions.md#change-the-type-of-a-load-balancer)
* [Delete Service](../../doc/controllers/load-balancer-actions.md#delete-service)
* [Detach a Load Balancer from a Network](../../doc/controllers/load-balancer-actions.md#detach-a-load-balancer-from-a-network)
* [Disable the Public Interface of a Load Balancer](../../doc/controllers/load-balancer-actions.md#disable-the-public-interface-of-a-load-balancer)
* [Enable the Public Interface of a Load Balancer](../../doc/controllers/load-balancer-actions.md#enable-the-public-interface-of-a-load-balancer)
* [Remove Target](../../doc/controllers/load-balancer-actions.md#remove-target)
* [Update Service](../../doc/controllers/load-balancer-actions.md#update-service)
* [Get an Action for a Load Balancer](../../doc/controllers/load-balancer-actions.md#get-an-action-for-a-load-balancer)


# Get All Actions for a Load Balancer

Returns all Action objects for a Load Balancer. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```ts
async getAllActionsForALoadBalancer(
  id: number,
  sort?: ParameterSort,
  status?: ParameterStatus,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionsResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `sort` | [`ParameterSort \| undefined`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatus \| undefined`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionsResponse`](../../doc/models/actions-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await loadBalancerActionsApi.getAllActionsForALoadBalancer(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "add_service",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 4711,
          "type": "load_balancer"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Add Service

Adds a service to a Load Balancer.

#### Call specific error codes

| Code                       | Description                                             |
|----------------------------|---------------------------------------------------------|
| `source_port_already_used` | The source port you are trying to add is already in use |

```ts
async addService(
  id: number,
  body?: LoadBalancerService,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`LoadBalancerService \| undefined`](../../doc/models/load-balancer-service.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `add_service` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: LoadBalancerService = {
  destinationPort: 80,
  healthCheck: {
    interval: 15,
    port: 4711,
    protocol: Protocol6.Http,
    retries: 3,
    timeout: 10,
  },
  listenPort: 443,
  protocol: Protocol7.Https,
  proxyprotocol: false,
};

try {
  const response = await loadBalancerActionsApi.addService(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Add Target

Adds a target to a Load Balancer.

#### Call specific error codes

| Code                                    | Description                                                                                           |
|-----------------------------------------|-------------------------------------------------------------------------------------------------------|
| `cloud_resource_ip_not_allowed`         | The IP you are trying to add as a target belongs to a Hetzner Cloud resource                          |
| `ip_not_owned`                          | The IP you are trying to add as a target is not owned by the Project owner                            |
| `load_balancer_not_attached_to_network` | The Load Balancer is not attached to a network                                                        |
| `robot_unavailable`                     | Robot was not available. The caller may retry the operation after a short delay.                      |
| `server_not_attached_to_network`        | The server you are trying to add as a target is not attached to the same network as the Load Balancer |
| `target_already_defined`                | The Load Balancer target you are trying to define is already defined                                  |

```ts
async addTarget(
  id: number,
  body?: AddTargetRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`AddTargetRequest \| undefined`](../../doc/models/add-target-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `add_target` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: AddTargetRequest = {
  type: Type29.LabelSelector,
  usePrivateIp: true,
};

try {
  const response = await loadBalancerActionsApi.addTarget(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_target",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Attach a Load Balancer to a Network

Attach a Load Balancer to a Network.

**Call specific error codes**

| Code                             | Description                                                           |
|----------------------------------|-----------------------------------------------------------------------|
| `load_balancer_already_attached` | The Load Balancer is already attached to a network                    |
| `ip_not_available`               | The provided Network IP is not available                              |
| `no_subnet_available`            | No Subnet or IP is available for the Load Balancer within the network |

```ts
async attachALoadBalancerToANetwork(
  id: number,
  body?: LoadBalancersActionsAttachToNetworkRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`LoadBalancersActionsAttachToNetworkRequest \| undefined`](../../doc/models/load-balancers-actions-attach-to-network-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `attach_to_network` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: LoadBalancersActionsAttachToNetworkRequest = {
  network: 4711,
  ip: '10.0.1.1',
};

try {
  const response = await loadBalancerActionsApi.attachALoadBalancerToANetwork(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_to_network",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Algorithm

Change the algorithm that determines to which target new requests are sent.

```ts
async changeAlgorithm(
  id: number,
  body?: LoadBalancersActionsChangeAlgorithmRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`LoadBalancersActionsChangeAlgorithmRequest \| undefined`](../../doc/models/load-balancers-actions-change-algorithm-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `change_algorithm` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await loadBalancerActionsApi.changeAlgorithm(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_algorithm",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Reverse DNS Entry for This Load Balancer

Changes the hostname that will appear when getting the hostname belonging to the public IPs (IPv4 and IPv6) of this Load Balancer.

Floating IPs assigned to the Server are not affected by this.

```ts
async changeReverseDnsEntryForThisLoadBalancer(
  id: number,
  body?: ChangeLoadbalancerDnsPtrRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`ChangeLoadbalancerDnsPtrRequest \| undefined`](../../doc/models/change-loadbalancer-dns-ptr-request.md) | Body, Optional | Select the IP address for which to change the DNS entry by passing `ip`. It can be either IPv4 or IPv6. The target hostname is set by passing `dns_ptr`. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key in the reply contains an Action object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: ChangeLoadbalancerDnsPtrRequest = {
  dnsPtr: 'lb1.example.com',
  ip: '1.2.3.4',
};

try {
  const response = await loadBalancerActionsApi.changeReverseDnsEntryForThisLoadBalancer(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_dns_ptr",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Load Balancer Protection

Changes the protection configuration of a Load Balancer.

```ts
async changeLoadBalancerProtection(
  id: number,
  body?: LoadBalancersActionsChangeProtectionRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`LoadBalancersActionsChangeProtectionRequest \| undefined`](../../doc/models/load-balancers-actions-change-protection-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `change_protection` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: LoadBalancersActionsChangeProtectionRequest = {
  mDelete: true,
};

try {
  const response = await loadBalancerActionsApi.changeLoadBalancerProtection(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change the Type of a Load Balancer

Changes the type (Max Services, Max Targets and Max Connections) of a Load Balancer.

**Call specific error codes**

| Code                         | Description                                                     |
|------------------------------|-----------------------------------------------------------------|
| `invalid_load_balancer_type` | The Load Balancer type does not fit for the given Load Balancer |

```ts
async changeTheTypeOfALoadBalancer(
  id: number,
  body?: ChangeTypeRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`ChangeTypeRequest \| undefined`](../../doc/models/change-type-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `change_load_balancer_type` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: ChangeTypeRequest = {
  loadBalancerType: 'lb21',
};

try {
  const response = await loadBalancerActionsApi.changeTheTypeOfALoadBalancer(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_load_balancer_type",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Delete Service

Delete a service of a Load Balancer.

```ts
async deleteService(
  id: number,
  body?: LoadBalancersActionsDeleteServiceRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`LoadBalancersActionsDeleteServiceRequest \| undefined`](../../doc/models/load-balancers-actions-delete-service-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `delete_service` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: LoadBalancersActionsDeleteServiceRequest = {
  listenPort: 4711,
};

try {
  const response = await loadBalancerActionsApi.deleteService(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "delete_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Detach a Load Balancer from a Network

Detaches a Load Balancer from a network.

```ts
async detachALoadBalancerFromANetwork(
  id: number,
  body?: LoadBalancersActionsDetachFromNetworkRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`LoadBalancersActionsDetachFromNetworkRequest \| undefined`](../../doc/models/load-balancers-actions-detach-from-network-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `detach_from_network` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: LoadBalancersActionsDetachFromNetworkRequest = {
  network: 4711,
};

try {
  const response = await loadBalancerActionsApi.detachALoadBalancerFromANetwork(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "detach_from_network",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Disable the Public Interface of a Load Balancer

Disable the public interface of a Load Balancer. The Load Balancer will be not accessible from the internet via its public IPs.

#### Call specific error codes

| Code                                      | Description                                                                    |
|-------------------------------------------|--------------------------------------------------------------------------------|
| `load_balancer_not_attached_to_network`   |  The Load Balancer is not attached to a network                                |
| `targets_without_use_private_ip`          | The Load Balancer has targets that use the public IP instead of the private IP |

```ts
async disableThePublicInterfaceOfALoadBalancer(
  id: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `disable_public_interface` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await loadBalancerActionsApi.disableThePublicInterfaceOfALoadBalancer(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "disable_public_interface",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Enable the Public Interface of a Load Balancer

Enable the public interface of a Load Balancer. The Load Balancer will be accessible from the internet via its public IPs.

```ts
async enableThePublicInterfaceOfALoadBalancer(
  id: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `enable_public_interface` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await loadBalancerActionsApi.enableThePublicInterfaceOfALoadBalancer(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "enable_public_interface",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Remove Target

Removes a target from a Load Balancer.

```ts
async removeTarget(
  id: number,
  body?: RemoveTargetRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`RemoveTargetRequest \| undefined`](../../doc/models/remove-target-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `remove_target` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await loadBalancerActionsApi.removeTarget(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "remove_target",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Update Service

Updates a Load Balancer Service.

#### Call specific error codes

| Code                       | Description                                             |
|----------------------------|---------------------------------------------------------|
| `source_port_already_used` | The source port you are trying to add is already in use |

```ts
async updateService(
  id: number,
  body?: LoadBalancerService,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `body` | [`LoadBalancerService \| undefined`](../../doc/models/load-balancer-service.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `action` key contains the `update_service` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const body: LoadBalancerService = {
  destinationPort: 80,
  healthCheck: {
    interval: 15,
    port: 4711,
    protocol: Protocol6.Http,
    retries: 3,
    timeout: 10,
  },
  listenPort: 443,
  protocol: Protocol7.Https,
  proxyprotocol: false,
};

try {
  const response = await loadBalancerActionsApi.updateService(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "update_service",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for a Load Balancer

Returns a specific Action for a Load Balancer.

```ts
async getAnActionForALoadBalancer(
  id: number,
  actionId: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Load Balancer |
| `actionId` | `number` | Template, Required | ID of the Action |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `action` key contains the Load Balancer Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

const actionId = 224;

try {
  const response = await loadBalancerActionsApi.getAnActionForALoadBalancer(
    id,
    actionId
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

