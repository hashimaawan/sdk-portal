
# Load Balancer Target Server

Server where the traffic should be routed through

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LoadBalancerTargetServer loadBalancerTargetServer = new LoadBalancerTargetServer
{
    Id = 80,
};
```

