
# X Amz Target 41 Enum

## Enumeration

`XAmzTarget41Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget41 := models.XAmzTarget41Enum_ENUMAMAZONATHENALISTQUERYEXECUTIONS

}
```

