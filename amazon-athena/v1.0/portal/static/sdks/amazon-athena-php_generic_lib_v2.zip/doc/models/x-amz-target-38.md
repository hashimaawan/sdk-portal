
# X Amz Target 38

## Enumeration

`XAmzTarget38`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget38;

$xAmzTarget38 = XAmzTarget38::ENUM_AMAZONATHENALISTNOTEBOOKMETADATA;
```

