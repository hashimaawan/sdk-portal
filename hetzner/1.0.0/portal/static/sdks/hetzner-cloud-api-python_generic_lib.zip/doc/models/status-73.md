
# Status 73

Status of the Server

## Enumeration

`Status73`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `INITIALIZING` |
| `STARTING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `MIGRATING` |
| `REBUILDING` |
| `UNKNOWN` |

## Example

```python
from hetznercloudapi.models.status_73 import Status73

status_73 = Status73.STOPPING
```

