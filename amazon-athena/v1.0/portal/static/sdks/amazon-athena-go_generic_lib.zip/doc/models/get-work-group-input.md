
# Get Work Group Input

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getWorkGroupInput := models.GetWorkGroupInput{
        WorkGroup:            "WorkGroup8",
    }

}
```

