
# Release Date Precision

The precision with which `release_date` value is known.

## Enumeration

`ReleaseDatePrecision`

## Fields

| Name |
|  --- |
| `Year` |
| `Month` |
| `Day` |

## Example

```ts
import {
  ReleaseDatePrecision,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const releaseDatePrecision = ReleaseDatePrecision.Year;
```

