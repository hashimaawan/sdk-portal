
# Isos Response

## Structure

`IsosResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Isos` | [`List<Iso>`](../../doc/models/iso.md) | Required | - |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

IsosResponse isosResponse = new IsosResponse
{
    Isos = new List<Iso>
    {
        new Iso
        {
            Deprecated = "2018-02-28T00:00:00+00:00",
            Description = "FreeBSD 11.0 x64",
            Id = 42,
            Name = "FreeBSD-11.0-RELEASE-amd64-dvd1",
            Type = Type26Enum.Public,
        },
    },
    Meta = new Meta
    {
        Pagination = new Pagination
        {
            LastPage = 77.7,
            NextPage = 209.18,
            Page = 17.58,
            PerPage = 13.34,
            PreviousPage = 50.02,
            TotalEntries = 206.64,
        },
    },
};
```

