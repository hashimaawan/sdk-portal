
# X Amz Target 14 Enum

## Enumeration

`XAmzTarget14Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAEXPORTNOTEBOOK` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget14Enum;

XAmzTarget14Enum xAmzTarget14 = XAmzTarget14Enum.ENUM_AMAZONATHENAEXPORTNOTEBOOK;
```

