
# V2 Customers My Invoices Summary Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2CustomersMyInvoicesSummaryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `String` | Optional | Total amount of the invoice, in USD.  This will reflect month-to-date usage in the invoice preview. |
| `billing_period` | `String` | Optional | Billing period of usage for which the invoice is issued, in `YYYY-MM`  format. |
| `credits_and_adjustments` | [`CreditsAndAdjustments`](../../doc/models/credits-and-adjustments.md) | Optional | - |
| `invoice_uuid` | `String` | Optional | UUID of the invoice |
| `overages` | [`Overages`](../../doc/models/overages.md) | Optional | - |
| `product_charges` | [`ProductCharges`](../../doc/models/product-charges.md) | Optional | - |
| `taxes` | [`Taxes`](../../doc/models/taxes.md) | Optional | - |
| `user_billing_address` | [`UserBillingAddress`](../../doc/models/user-billing-address.md) | Optional | - |
| `user_company` | `String` | Optional | Company of the DigitalOcean customer being invoiced, if set. |
| `user_email` | `String` | Optional | Email of the DigitalOcean customer being invoiced. |
| `user_name` | `String` | Optional | Name of the DigitalOcean customer being invoiced. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_customers_my_invoices_summary_response = V2CustomersMyInvoicesSummaryResponse.new(
  amount: '27.13',
  billing_period: '2020-01',
  credits_and_adjustments: CreditsAndAdjustments.new(
    amount: 'amount6',
    name: 'name4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  invoice_uuid: '22737513-0ea7-4206-8ceb-98a575af7681',
  overages: Overages.new(
    amount: 'amount6',
    name: 'name4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  user_company: 'DigitalOcean',
  user_email: 'sammy@digitalocean.com',
  user_name: 'Sammy Shark',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

