
# Stop Calculation Execution Response

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`CalculationExecutionState4Enum`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```python
from amazonathena.models.calculation_execution_state_4_enum import CalculationExecutionState4Enum
from amazonathena.models.stop_calculation_execution_response import StopCalculationExecutionResponse

stop_calculation_execution_response = StopCalculationExecutionResponse(
    state=CalculationExecutionState4Enum.QUEUED
)
```

