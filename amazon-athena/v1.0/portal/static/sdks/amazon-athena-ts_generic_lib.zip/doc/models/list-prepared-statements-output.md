
# List Prepared Statements Output

## Structure

`ListPreparedStatementsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preparedStatements` | [`PreparedStatementSummary[] \| undefined`](../../doc/models/prepared-statement-summary.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `50` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListPreparedStatementsOutput } from 'amazon-athenalib';

const listPreparedStatementsOutput: ListPreparedStatementsOutput = {
  preparedStatements: [
    {
      statementName: 'StatementName2',
      lastModifiedTime: '2016-03-13T12:52:32.123Z',
    },
    {
      statementName: 'StatementName2',
      lastModifiedTime: '2016-03-13T12:52:32.123Z',
    }
  ],
  nextToken: 'NextToken2',
};
```

