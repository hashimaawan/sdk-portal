
# X Amz Target 17 Enum

## Enumeration

`XAmzTarget17Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS` |

## Example

```ruby
x_amz_target17 = XAmzTarget17Enum::ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS
```

