
# X Amz Target 2 Enum

## Enumeration

`XAmzTarget2Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetQueryExecution` |

## Example

```ts
import { XAmzTarget2Enum } from 'amazon-athenalib';

const xAmzTarget2 = XAmzTarget2Enum.EnumAmazonAthenaBatchGetQueryExecution;
```

