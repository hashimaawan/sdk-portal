
# Get Database Output

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Database` | [`Database2`](../../doc/models/database-2.md) | Optional | - | Database2 getDatabase() | setDatabase(Database2 database) |

## Example

```java
import com.amazonaws.useast1.athena.models.Database2;
import com.amazonaws.useast1.athena.models.GetDatabaseOutput;
import com.amazonaws.useast1.athena.models.Parameters;

GetDatabaseOutput getDatabaseOutput = new GetDatabaseOutput.Builder()
    .database(new Database2.Builder(
        "Name2"
    )
    .description("Description8")
    .parameters(new Parameters.Builder()
            .build())
    .build())
    .build();
```

