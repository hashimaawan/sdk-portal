
# Encryption Configuration

If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information.

*This model accepts additional fields of type unknown.*

## Structure

`EncryptionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryptionOption` | [`EncryptionOption1`](../../doc/models/encryption-option-1.md) | Required | - |
| `kmsKey` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { EncryptionConfiguration, EncryptionOption1 } from 'amazon-athenalib';

const encryptionConfiguration: EncryptionConfiguration = {
  encryptionOption: EncryptionOption1.SseKms,
  kmsKey: 'KmsKey6',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

