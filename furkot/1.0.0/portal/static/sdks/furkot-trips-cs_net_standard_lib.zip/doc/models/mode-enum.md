
# Mode Enum

travel mode

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `Car` |
| `Motorcycle` |
| `Bicycle` |
| `Walk` |
| `Other` |

## Example

```csharp
using FurkotTrips.Standard.Models;

ModeEnum mode = ModeEnum.Bicycle;
```

