
# X Amz Target 58

## Enumeration

`XAmzTarget58`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdatePreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget58 xAmzTarget58 = XAmzTarget58.EnumAmazonAthenaUpdatePreparedStatement;
```

