
# Price Hourly 8

Hourly costs for a Server type in this Location

## Structure

`PriceHourly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

PriceHourly8 priceHourly8 = new PriceHourly8
{
    Gross = "1.1900000000000000",
    Net = "1.0000000000",
};
```

