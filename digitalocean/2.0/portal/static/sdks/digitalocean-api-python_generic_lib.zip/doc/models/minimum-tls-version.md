
# Minimum Tls Version

The minimum version of TLS a client application can use to access resources for the domain.  Must be one of the following values wrapped within quotations: `"1.2"` or `"1.3"`.

## Enumeration

`MinimumTlsVersion`

## Fields

| Name |
|  --- |
| `ENUM_12` |
| `ENUM_13` |

## Example

```python
from digitaloceanapi.models.minimum_tls_version import MinimumTlsVersion

minimum_tls_version = MinimumTlsVersion.ENUM_12
```

