
# Result Configuration 1

*This model accepts additional fields of type Object.*

## Structure

`ResultConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `output_location` | `String` | Optional | - |
| `encryption_configuration` | [`EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - |
| `expected_bucket_owner` | `String` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` |
| `acl_configuration` | [`AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
result_configuration1 = ResultConfiguration1.new(
  output_location: 'OutputLocation8',
  encryption_configuration: EncryptionConfiguration2.new(
    encryption_option: EncryptionOption1::SSE_S3,
    kms_key: 'KmsKey6',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  expected_bucket_owner: 'ExpectedBucketOwner8',
  acl_configuration: AclConfiguration1.new(
    s3_acl_option: S3AclOption1::BUCKET_OWNER_FULL_CONTROL,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

