
# Direction

## Enumeration

`Direction`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```java
import com.digitalocean.api.models.Direction;

Direction direction = Direction.INBOUND;
```

