
# V2 Registry Garbage Collections Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `garbageCollections` | [`GarbageCollection[] \| undefined`](../../doc/models/garbage-collection.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Status15,
  V2RegistryGarbageCollectionsResponse,
} from 'digitalocean-apilib';

const v2RegistryGarbageCollectionsResponse: V2RegistryGarbageCollectionsResponse = {
  garbageCollections: [
    {
      blobsDeleted: 26,
      createdAt: '2016-03-13T12:52:32.123Z',
      freedBytes: 100,
      registryName: 'registry_name2',
      status: Status15.Requested,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

