
# Terminate Session Response

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```python
from amazonathena.models.session_state_1_enum import SessionState1Enum
from amazonathena.models.terminate_session_response import TerminateSessionResponse

terminate_session_response = TerminateSessionResponse(
    state=SessionState1Enum.CREATING
)
```

