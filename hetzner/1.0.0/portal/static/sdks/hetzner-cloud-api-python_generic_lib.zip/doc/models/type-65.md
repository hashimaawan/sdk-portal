
# Type 65

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65`

## Fields

| Name |
|  --- |
| `LINUX64` |
| `LINUX32` |

## Example

```python
from hetznercloudapi.models.type_65 import Type65

type_65 = Type65.LINUX64
```

