
# Type 29

Type of the resource

## Enumeration

`Type29`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |
| `IP` |

## Example

```python
from hetznercloudapi.models.type_29 import Type29

type_29 = Type29.IP
```

