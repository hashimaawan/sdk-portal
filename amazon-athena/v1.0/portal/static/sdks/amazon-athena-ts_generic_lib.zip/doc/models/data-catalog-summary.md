
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

*This model accepts additional fields of type unknown.*

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalogName` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `type` | [`DataCatalogType2 \| undefined`](../../doc/models/data-catalog-type-2.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DataCatalogSummary, DataCatalogType2 } from 'amazon-athenalib';

const dataCatalogSummary: DataCatalogSummary = {
  catalogName: 'CatalogName2',
  type: DataCatalogType2.Hive,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

