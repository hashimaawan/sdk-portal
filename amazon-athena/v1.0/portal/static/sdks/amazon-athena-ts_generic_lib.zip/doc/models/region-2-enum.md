
# Region 2 Enum

## Enumeration

`Region2Enum`

## Fields

| Name |
|  --- |
| `Cnnorth1` |
| `Cnnorthwest1` |

## Example

```ts
import { Region2Enum } from 'amazon-athenalib';

const region2 = Region2Enum.Cnnorth1;
```

