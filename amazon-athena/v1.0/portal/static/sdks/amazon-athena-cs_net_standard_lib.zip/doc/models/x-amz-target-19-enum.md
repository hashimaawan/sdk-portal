
# X Amz Target 19 Enum

## Enumeration

`XAmzTarget19Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetDatabase` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget19Enum xAmzTarget19 = XAmzTarget19Enum.EnumAmazonAthenaGetDatabase;
```

