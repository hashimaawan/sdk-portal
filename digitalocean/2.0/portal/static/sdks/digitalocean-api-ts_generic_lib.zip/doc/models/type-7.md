
# Type 7

The type of resource that the firewall rule allows to access the database cluster.

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `Droplet` |
| `K8S` |
| `IpAddr` |
| `Tag` |
| `App` |

## Example

```ts
import { Type7 } from 'digitalocean-apilib';

const type7 = Type7.App;
```

