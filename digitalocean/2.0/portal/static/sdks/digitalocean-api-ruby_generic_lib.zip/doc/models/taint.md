
# Taint

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Taint`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `effect` | [`Effect`](../../doc/models/effect.md) | Optional | How the node reacts to pods that it won't tolerate. Available effect values are `NoSchedule`, `PreferNoSchedule`, and `NoExecute`. |
| `key` | `String` | Optional | An arbitrary string. The `key` and `value` fields of the `taint` object form a key-value pair. For example, if the value of the `key` field is "special" and the value of the `value` field is "gpu", the key value pair would be `special=gpu`. |
| `value` | `String` | Optional | An arbitrary string. The `key` and `value` fields of the `taint` object form a key-value pair. For example, if the value of the `key` field is "special" and the value of the `value` field is "gpu", the key value pair would be `special=gpu`. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
taint = Taint.new(
  effect: Effect::NOSCHEDULE,
  key: 'priority',
  value: 'high',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

