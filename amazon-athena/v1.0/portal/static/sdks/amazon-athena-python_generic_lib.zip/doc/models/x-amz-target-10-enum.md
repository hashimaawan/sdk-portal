
# X Amz Target 10 Enum

## Enumeration

`XAmzTarget10Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_10_enum import XAmzTarget10Enum

x_amz_target_10 = XAmzTarget10Enum.ENUM_AMAZONATHENADELETENAMEDQUERY
```

