
# X Amz Target Enum

## Enumeration

`XAmzTargetEnum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```ruby
x_amz_target = XAmzTargetEnum::ENUM_AMAZONATHENABATCHGETNAMEDQUERY
```

