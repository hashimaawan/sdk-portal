
# Create Prepared Statement Input

## Structure

`CreatePreparedStatementInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statement_name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `work_group` | `str` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `query_statement` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```python
from amazonathena.models.create_prepared_statement_input import CreatePreparedStatementInput

create_prepared_statement_input = CreatePreparedStatementInput(
    statement_name='StatementName6',
    work_group='WorkGroup0',
    query_statement='QueryStatement0',
    description='Description2'
)
```

