
# Engine Version

The Athena engine version for running queries, or the PySpark engine version for running sessions.

## Structure

`EngineVersion`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selected_engine_version` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `effective_engine_version` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```ruby
engine_version = EngineVersion.new(
  'SelectedEngineVersion4',
  'EffectiveEngineVersion4'
)
```

