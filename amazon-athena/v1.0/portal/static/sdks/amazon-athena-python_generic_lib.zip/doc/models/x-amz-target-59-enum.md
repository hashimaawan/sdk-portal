
# X Amz Target 59 Enum

## Enumeration

`XAmzTarget59Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEWORKGROUP` |

## Example

```python
from amazonathena.models.x_amz_target_59_enum import XAmzTarget59Enum

x_amz_target_59 = XAmzTarget59Enum.ENUM_AMAZONATHENAUPDATEWORKGROUP
```

