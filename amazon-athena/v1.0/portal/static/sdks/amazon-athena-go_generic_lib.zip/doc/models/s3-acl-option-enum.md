
# S3 Acl Option Enum

## Enumeration

`S3AclOptionEnum`

## Fields

| Name |
|  --- |
| `BUCKETOWNERFULLCONTROL` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    s3AclOption := models.S3AclOptionEnum_BUCKETOWNERFULLCONTROL

}
```

