
# List Tags for Resource Output

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | [`List[Tag]`](../../doc/models/tag.md) | Optional | - |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```python
from amazonathena.models.list_tags_for_resource_output import ListTagsForResourceOutput
from amazonathena.models.tag import Tag

list_tags_for_resource_output = ListTagsForResourceOutput(
    tags=[
        Tag(
            key='Key0',
            value='Value6'
        )
    ],
    next_token='NextToken4'
)
```

