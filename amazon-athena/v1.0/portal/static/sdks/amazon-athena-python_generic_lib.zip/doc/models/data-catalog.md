
# Data Catalog

<p>Contains information about a data catalog in an Amazon Web Services account.</p> <note> <p>In the Athena console, data catalogs are listed as "data sources" on the <b>Data sources</b> page under the <b>Data source name</b> column.</p> </note>


## Structure

`DataCatalog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `mtype` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```python
from amazonathena.models.data_catalog import DataCatalog
from amazonathena.models.data_catalog_type_1_enum import DataCatalogType1Enum
from amazonathena.models.parameters import Parameters

data_catalog = DataCatalog(
    name='Name8',
    mtype=DataCatalogType1Enum.LAMBDA,
    description='Description8',
    parameters=Parameters()
)
```

