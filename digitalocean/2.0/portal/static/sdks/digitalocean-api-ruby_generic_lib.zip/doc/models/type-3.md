
# Type 3

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `BUILD` |
| `DEPLOY` |
| `RUN` |

## Example

```ruby
type3 = Type3::DEPLOY
```

