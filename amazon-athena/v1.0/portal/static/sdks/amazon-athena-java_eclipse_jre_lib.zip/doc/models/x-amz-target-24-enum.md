
# X Amz Target 24 Enum

## Enumeration

`XAmzTarget24Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRESULTS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget24Enum;

XAmzTarget24Enum xAmzTarget24 = XAmzTarget24Enum.ENUM_AMAZONATHENAGETQUERYRESULTS;
```

