
# Result Reuse by Age Configuration 2

## Structure

`ResultReuseByAgeConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Enabled` | `bool` | Required | - |
| `MaxAgeInMinutes` | `*int` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    resultReuseByAgeConfiguration2 := models.ResultReuseByAgeConfiguration2{
        Enabled:              false,
        MaxAgeInMinutes:      models.ToPointer(44),
    }

}
```

