# Firewalls

Firewalls can limit the network access to or from your resources.

* When applying a firewall with no `in` rule all inbound traffic will be dropped. The default for `in` is `DROP`.
* When applying a firewall with no `out` rule all outbound traffic will be accepted. The default for `out` is `ACCEPT`.

```go
firewallsApi := client.FirewallsApi()
```

## Class Name

`FirewallsApi`

## Methods

* [Get All Firewalls](../../doc/controllers/firewalls.md#get-all-firewalls)
* [Create a Firewall](../../doc/controllers/firewalls.md#create-a-firewall)
* [Delete a Firewall](../../doc/controllers/firewalls.md#delete-a-firewall)
* [Get a Firewall](../../doc/controllers/firewalls.md#get-a-firewall)
* [Update a Firewall](../../doc/controllers/firewalls.md#update-a-firewall)


# Get All Firewalls

Returns all Firewall objects.

```go
GetAllFirewalls(
    ctx context.Context,
    sort *models.Sort,
    name *string,
    labelSelector *string) (
    models.ApiResponse[models.FirewallsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`*models.Sort`](../../doc/models/sort.md) | Query, Optional | Can be used multiple times. |
| `name` | `*string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `*string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `firewalls` key contains an array of Firewall objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.FirewallsResponse](../../doc/models/firewalls-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := firewallsApi.GetAllFirewalls(ctx, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Create a Firewall

Creates a new Firewall.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_already_added`        | Server added more than one time to resource                   |
| `incompatible_network_type`   | The Network type is incompatible for the given resource       |
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```go
CreateAFirewall(
    ctx context.Context,
    body *models.CreateFirewallRequest) (
    models.ApiResponse[models.CreateFirewallResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`*models.CreateFirewallRequest`](../../doc/models/create-firewall-request.md) | Body, Optional | - |

## Response Type

**201**: The `firewall` key contains the Firewall that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CreateFirewallResponse](../../doc/models/create-firewall-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.CreateFirewallRequest{
    ApplyTo:               []models.ApplyTo{
        models.ApplyTo{
            Server:                models.ToPointer(models.Server2{
                Id:                    42,
            }),
            Type:                  models.Type7_Server,
        },
    },
    Labels:                models.ToPointer(interface{}("[env, dev]")),
    Name:                  "Corporate Intranet Protection",
    Rules:                 []models.Rule{
        models.Rule{
            Description:           models.NewOptional(models.ToPointer("Allow port 80")),
            Direction:             models.Direction_In,
            Port:                  models.ToPointer("80"),
            Protocol:              models.Protocol_Tcp,
            SourceIps:             []string{
                "28.239.13.1/32",
                "28.239.14.0/24",
                "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
            },
        },
    },
}

apiResponse, err := firewallsApi.CreateAFirewall(ctx, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Delete a Firewall

Deletes a Firewall.

#### Call specific error codes

| Code                 | Description                               |
|--------------------- |-------------------------------------------|
| `resource_in_use`    | Firewall must not be in use to be deleted |

```go
DeleteAFirewall(
    ctx context.Context,
    id int) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Firewall deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

id := 112

resp, err := firewallsApi.DeleteAFirewall(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```


# Get a Firewall

Gets a specific Firewall object.

```go
GetAFirewall(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.FirewallResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `firewall` key contains a Firewall object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.FirewallResponse](../../doc/models/firewall-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := firewallsApi.GetAFirewall(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Update a Firewall

Updates the Firewall.

Note that when updating labels, the Firewall's current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the Firewall object changes during the request, the response will be a “conflict” error.

```go
UpdateAFirewall(
    ctx context.Context,
    id int,
    body *models.UpdateFirewallRequest) (
    models.ApiResponse[models.FirewallResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`*models.UpdateFirewallRequest`](../../doc/models/update-firewall-request.md) | Body, Optional | - |

## Response Type

**200**: The `firewall` key contains the Firewall that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.FirewallResponse](../../doc/models/firewall-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.UpdateFirewallRequest{
    Labels:                models.ToPointer(interface{}("[labelkey, value]")),
    Name:                  models.ToPointer("new-name"),
}

apiResponse, err := firewallsApi.UpdateAFirewall(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

