
# X Amz Target Enum

## Enumeration

`XAmzTargetEnum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_enum import XAmzTargetEnum

x_amz_target = XAmzTargetEnum.ENUM_AMAZONATHENABATCHGETNAMEDQUERY
```

