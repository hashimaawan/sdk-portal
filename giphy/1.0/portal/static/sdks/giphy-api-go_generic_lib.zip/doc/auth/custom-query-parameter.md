
# Custom Query Parameter



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| apiKey | `string` | - | `WithApiKey` | `ApiKey()` |



**Note:** Required auth credentials can be set using `WithCustomQueryAuthenticationCredentials()` by providing a credentials instance with `NewCustomQueryAuthenticationCredentials()` in the configuration initialization and accessed using the `CustomQueryAuthenticationCredentials()` method in the configuration instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```go
package main

import (
    "giphyApi"
)

func main() {
    client := giphyApi.NewClient(
    giphyApi.CreateConfiguration(
            giphyApi.WithCustomQueryAuthenticationCredentials(
                giphyApi.NewCustomQueryAuthenticationCredentials("api_key"),
            ),
        ),
    )
}
```


