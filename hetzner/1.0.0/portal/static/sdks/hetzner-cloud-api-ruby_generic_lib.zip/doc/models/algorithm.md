
# Algorithm

Algorithm of the Load Balancer

*This model accepts additional fields of type Object.*

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type28`](../../doc/models/type-28.md) | Required | Type of the algorithm |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
algorithm = Algorithm.new(
  type: Type28::ROUND_ROBIN,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

