
# Change Protection Request

## Structure

`ChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Delete` | `Boolean` | Optional | If true, prevents the Floating IP from being deleted | Boolean getDelete() | setDelete(Boolean delete) |

## Example

```java
import cloud.hetzner.api.models.ChangeProtectionRequest;

ChangeProtectionRequest changeProtectionRequest = new ChangeProtectionRequest.Builder()
    .delete(true)
    .build();
```

