
# X Amz Target 42

## Enumeration

`XAmzTarget42`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTSESSIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget42;

$xAmzTarget42 = XAmzTarget42::ENUM_AMAZONATHENALISTSESSIONS;
```

