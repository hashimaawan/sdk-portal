
# X Amz Target 42 Enum

## Enumeration

`XAmzTarget42Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTSESSIONS` |

## Example

```python
from amazonathena.models.x_amz_target_42_enum import XAmzTarget42Enum

x_amz_target_42 = XAmzTarget42Enum.ENUM_AMAZONATHENALISTSESSIONS
```

