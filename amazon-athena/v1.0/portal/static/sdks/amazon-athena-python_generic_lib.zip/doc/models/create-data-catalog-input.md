
# Create Data Catalog Input

## Structure

`CreateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `mtype` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `tags` | [`List[Tag]`](../../doc/models/tag.md) | Optional | - |

## Example

```python
from amazonathena.models.create_data_catalog_input import CreateDataCatalogInput
from amazonathena.models.data_catalog_type_1_enum import DataCatalogType1Enum
from amazonathena.models.parameters import Parameters
from amazonathena.models.tag import Tag

create_data_catalog_input = CreateDataCatalogInput(
    name='Name0',
    mtype=DataCatalogType1Enum.LAMBDA,
    description='Description6',
    parameters=Parameters(),
    tags=[
        Tag(
            key='Key0',
            value='Value6'
        )
    ]
)
```

