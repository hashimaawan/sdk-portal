
# X Amz Target 28 Enum

## Enumeration

`XAmzTarget28Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETTABLEMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget28Enum;

$xAmzTarget28 = XAmzTarget28Enum::ENUM_AMAZONATHENAGETTABLEMETADATA;
```

