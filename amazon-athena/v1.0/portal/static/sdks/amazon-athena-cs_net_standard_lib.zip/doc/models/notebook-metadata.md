
# Notebook Metadata

Contains metadata for notebook, including the notebook name, ID, workgroup, and time created.

## Structure

`NotebookMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NotebookId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `Name` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `WorkGroup` | `string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `CreationTime` | `DateTime?` | Optional | - |
| `Type` | [`NotebookType1Enum?`](../../doc/models/notebook-type-1-enum.md) | Optional | - |
| `LastModifiedTime` | `DateTime?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Globalization;

NotebookMetadata notebookMetadata = new NotebookMetadata
{
    NotebookId = "NotebookId0",
    Name = "Name0",
    WorkGroup = "WorkGroup2",
    CreationTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    Type = NotebookType1Enum.IPYNB,
};
```

