
# V2 Apps Components Logs Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsComponentsLogsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `historicUrls` | `string[] \| undefined` | Optional | - |
| `liveUrl` | `string \| undefined` | Optional | A URL of the real-time live logs. This URL may use either the `https://` or `wss://` protocols and will keep pushing live logs as they become available. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AppsComponentsLogsResponse } from 'digitalocean-apilib';

const v2AppsComponentsLogsResponse: V2AppsComponentsLogsResponse = {
  historicUrls: [
    'historic_urls9',
    'historic_urls0',
    'historic_urls1'
  ],
  liveUrl: 'ws://logs/build',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

