
# X Amz Target 45

## Enumeration

`XAmzTarget45`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTWORKGROUPS` |

## Example

```ruby
x_amz_target45 = XAmzTarget45::ENUM_AMAZONATHENALISTWORKGROUPS
```

