
# Calculation Configuration

Contains configuration information for the calculation.

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `codeBlock` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```ts
import { CalculationConfiguration } from 'amazon-athenalib';

const calculationConfiguration: CalculationConfiguration = {
  codeBlock: 'CodeBlock2',
};
```

