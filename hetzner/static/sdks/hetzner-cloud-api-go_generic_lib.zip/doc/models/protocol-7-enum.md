
# Protocol 7 Enum

Protocol of the Load Balancer

## Enumeration

`Protocol7Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    protocol7 := models.Protocol7Enum_HTTP

}
```

