# IS Os

ISOs are read-only Images of DVDs. While we recommend using our Image functionality to install your Servers we also provide some stock ISOs so you can install more exotic operating systems by yourself.

On request our support uploads a private ISO just for you. These are marked with type `private` and only visible in your Project.

To attach an ISO to your Server use `POST /servers/{id}/actions/attach_iso`.

```java
IsOsApi isOsApi = client.getIsOsApi();
```

## Class Name

`IsOsApi`

## Methods

* [Get All IS Os](../../doc/controllers/is-os.md#get-all-is-os)
* [Get an ISO](../../doc/controllers/is-os.md#get-an-iso)


# Get All IS Os

Returns all available ISO objects.

```java
CompletableFuture<ApiResponse<IsosResponse>> getAllIsOsAsync(
    final String name)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter ISOs by their name. The response will only contain the ISO matching the specified name. |

## Response Type

**200**: The `isos` key in the reply contains an array of iso objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`IsosResponse`](../../doc/models/isos-response.md).

## Example Usage

```java
isOsApi.getAllIsOsAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get an ISO

Returns a specific ISO object.

```java
CompletableFuture<ApiResponse<IsosResponse1>> getAnIsoAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the ISO |

## Response Type

**200**: The `iso` key in the reply contains an array of ISO objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`IsosResponse1`](../../doc/models/isos-response-1.md).

## Example Usage

```java
int id = 112;

isOsApi.getAnIsoAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

