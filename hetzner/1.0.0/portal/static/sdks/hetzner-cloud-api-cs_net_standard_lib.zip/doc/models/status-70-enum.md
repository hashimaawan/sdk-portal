
# Status 70 Enum

## Enumeration

`Status70Enum`

## Fields

| Name |
|  --- |
| `Initializing` |
| `Starting` |
| `Running` |
| `Stopping` |
| `Off` |
| `Deleting` |
| `Rebuilding` |
| `Migrating` |
| `Unknown` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Status70Enum status70 = Status70Enum.Migrating;
```

