
# Create Image Request

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string \| undefined` | Optional | Description of the Image, will be auto-generated if not set |
| `labels` | [`Labels \| undefined`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `type` | [`Type63Enum \| undefined`](../../doc/models/type-63-enum.md) | Optional | Type of Image to create (default: `snapshot`) |

## Example

```ts
import { CreateImageRequest, Type63Enum } from 'hetzner-cloud-apilib';

const createImageRequest: CreateImageRequest = {
  description: 'my image',
  labels: {
    labelkey: 'labelkey4',
  },
  type: Type63Enum.Snapshot,
};
```

