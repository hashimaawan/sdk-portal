
# X Amz Target 28 Enum

## Enumeration

`XAmzTarget28Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETTABLEMETADATA` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget28 := models.XAmzTarget28Enum_ENUMAMAZONATHENAGETTABLEMETADATA

}
```

