
# Get Database Output

*This model accepts additional fields of type Any.*

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | [`Database2`](../../doc/models/database-2.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.database_2 import Database2
from amazonathena.models.get_database_output import GetDatabaseOutput
from amazonathena.models.parameters import Parameters

get_database_output = GetDatabaseOutput(
    database=Database2(
        name='Name2',
        description='Description8',
        parameters=Parameters(
            additional_properties={
                'exampleAdditionalProperty': 'Parameters_additionalProperties2'
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

