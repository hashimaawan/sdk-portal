
# Add Target Request

## Structure

`AddTargetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip` | [`Ip \| undefined`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. |
| `labelSelector` | [`LabelSelector12 \| undefined`](../../doc/models/label-selector-12.md) | Optional | Configuration for label selector targets, required if type is `label_selector` |
| `server` | [`Server16 \| undefined`](../../doc/models/server-16.md) | Optional | Configuration for type Server, required if type is `server` |
| `type` | [`Type29Enum`](../../doc/models/type-29-enum.md) | Required | Type of the resource |
| `usePrivateIp` | `boolean \| undefined` | Optional | Use the private network IP instead of the public IP of the Server, requires the Server and Load Balancer to be in the same network. Default value is false. |

## Example

```ts
import { AddTargetRequest, Type29Enum } from 'hetzner-cloud-apilib';

const addTargetRequest: AddTargetRequest = {
  type: Type29Enum.Server,
  ip: {
    ip: 'ip8',
  },
  labelSelector: {
    selector: 'selector8',
  },
  server: {
    id: 217.74,
  },
  usePrivateIp: true,
};
```

