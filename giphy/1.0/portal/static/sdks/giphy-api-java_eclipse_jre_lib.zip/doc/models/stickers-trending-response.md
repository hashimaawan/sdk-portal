
# Stickers Trending Response

*This model accepts additional fields of type Object.*

## Structure

`StickersTrendingResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`List<Gif>`](../../doc/models/gif.md) | Optional | - | List<Gif> getData() | setData(List<Gif> data) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Optional | The Meta Object contains basic information regarding the request, whether it was successful, and the response given by the API.  Check `responses` to see a description of types of response codes the API might give you under different cirumstances. | Meta getMeta() | setMeta(Meta meta) |
| `Pagination` | [`Pagination`](../../doc/models/pagination.md) | Optional | The Pagination Object contains information relating to the number of total results available as well as the number of results fetched and their relative positions. | Pagination getPagination() | setPagination(Pagination pagination) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.giphy.api.ApiHelper;
import com.giphy.api.DateTimeHelper;
import com.giphy.api.models.Gif;
import com.giphy.api.models.Meta;
import com.giphy.api.models.Pagination;
import com.giphy.api.models.StickersTrendingResponse;
import java.io.IOException;
import java.util.Arrays;

StickersTrendingResponse stickersTrendingResponse = new StickersTrendingResponse.Builder()
    .data(Arrays.asList(
        new Gif.Builder()
            .bitlyUrl("bitly_url0")
            .contentUrl("content_url4")
            .createDatetime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
            .embdedUrl("embded_url8")
            .featuredTags(Arrays.asList(
                "featured_tags0"
            ))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ))
    .meta(new Meta.Builder()
        .msg("msg8")
        .responseId("response_id0")
        .status(98)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .pagination(new Pagination.Builder()
        .count(192)
        .offset(240)
        .totalCount(100)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

