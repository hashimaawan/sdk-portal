
# Query Stage Plan Node

Stage plan information such as name, identifier, sub plans, and remote sources.

## Structure

`QueryStagePlanNode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | - |
| `identifier` | `str` | Optional | - |
| `children` | [`List[QueryStagePlanNode]`](../../doc/models/query-stage-plan-node.md) | Optional | - |
| `remote_sources` | `List[str]` | Optional | - |

## Example

```python
from amazonathena.models.query_stage_plan_node import QueryStagePlanNode

query_stage_plan_node = QueryStagePlanNode(
    name='Name0',
    identifier='Identifier6',
    children=[
        QueryStagePlanNode(
            name='Name6',
            identifier='Identifier2',
            children=[
                QueryStagePlanNode()
            ],
            remote_sources=[
                'RemoteSources4',
                'RemoteSources5',
                'RemoteSources6'
            ]
        )
    ],
    remote_sources=[
        'RemoteSources8',
        'RemoteSources9',
        'RemoteSources0'
    ]
)
```

