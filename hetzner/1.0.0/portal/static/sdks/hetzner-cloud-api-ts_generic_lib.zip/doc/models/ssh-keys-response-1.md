
# Ssh Keys Response 1

*This model accepts additional fields of type unknown.*

## Structure

`SshKeysResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sshKey` | [`SshKey`](../../doc/models/ssh-key.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SshKeysResponse1 } from 'hetzner-cloud-apilib';

const sshKeysResponse1: SshKeysResponse1 = {
  sshKey: {
    created: '2016-01-30T23:55:00+00:00',
    fingerprint: 'b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f',
    id: 42,
    labels: {
      'key0': 'labels0'
    },
    name: 'my-resource',
    publicKey: 'ssh-rsa AAAjjk76kgf...Xt',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

