
# V2 Functions Namespaces Triggers Response 1

*This model accepts additional fields of type Object.*

## Structure

`V2FunctionsNamespacesTriggersResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Trigger` | [`Trigger`](../../doc/models/trigger.md) | Optional | - | Trigger getTrigger() | setTrigger(Trigger trigger) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Trigger;
import com.digitalocean.api.models.V2FunctionsNamespacesTriggersResponse1;
import java.io.IOException;

V2FunctionsNamespacesTriggersResponse1 v2FunctionsNamespacesTriggersResponse1 = new V2FunctionsNamespacesTriggersResponse1.Builder()
    .trigger(new Trigger.Builder()
        .createdAt("created_at6")
        .function("function6")
        .isEnabled(false)
        .name("name8")
        .namespace("namespace4")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

