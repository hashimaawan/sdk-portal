
# X Amz Target 23 Enum

## Enumeration

`XAmzTarget23Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget23Enum;

$xAmzTarget23 = XAmzTarget23Enum::ENUM_AMAZONATHENAGETQUERYEXECUTION;
```

