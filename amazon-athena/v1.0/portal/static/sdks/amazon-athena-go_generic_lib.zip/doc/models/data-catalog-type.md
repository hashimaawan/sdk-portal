
# Data Catalog Type

## Enumeration

`DataCatalogType`

## Fields

| Name |
|  --- |
| `Lambda` |
| `Glue` |
| `Hive` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    dataCatalogType := models.DataCatalogType_Hive

}
```

