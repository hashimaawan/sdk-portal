
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`amazonAthenaRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `amazonAthena.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "amazonAthena"
    "net/http"
)

func main() {
    httpConfiguration := amazonAthena.CreateHttpConfiguration(
        amazonAthena.WithTimeout(30),
        amazonAthena.WithTransport(http.DefaultTransport),
        amazonAthena.WithRetryConfiguration(amazonAthena.DefaultRetryConfiguration()),
    )
}
```

