
# V2 Reserved Ips Response 2

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2ReservedIpsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reserved_ip` | [`ReservedIp`](../../doc/models/reserved-ip.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_reserved_ips_response2 = V2ReservedIpsResponse2.new(
  reserved_ip: ReservedIp.new(
    droplet: { 'key1' => 'val1', 'key2' => 'val2' },
    ip: 'ip6',
    locked: false,
    project_id: '00002548-0000-0000-0000-000000000000',
    region: Region.new(
      available: false,
      features: [
        'features7',
        'features8',
        'features9'
      ],
      name: 'name6',
      sizes: [
        'sizes6'
      ],
      slug: 'slug0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

