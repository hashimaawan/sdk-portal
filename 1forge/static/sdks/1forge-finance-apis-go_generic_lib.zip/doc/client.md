
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |

The API client can be initialized as follows:

```go
package main

import (
    "m1forgefinanceapis"
)

func main() {
    client := m1forgefinanceapis.NewClient(
    m1forgefinanceapis.CreateConfiguration(
            m1forgefinanceapis.WithHttpConfiguration(
                m1forgefinanceapis.CreateHttpConfiguration(
                    m1forgefinanceapis.WithTimeout(0),
                ),
            ),
            m1forgefinanceapis.WithEnvironment(m1forgefinanceapis.PRODUCTION),
        ),
    )
}
```

## 1Forge Finance APIs Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| ForexController() | Gets ForexController |

