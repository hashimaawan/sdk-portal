
# Result Reuse Information 2

*This model accepts additional fields of type interface{}.*

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReusedPreviousResult` | `bool` | Required | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    resultReuseInformation2 := models.ResultReuseInformation2{
        ReusedPreviousResult:  false,
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

