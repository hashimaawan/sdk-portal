
# V2 Images Request 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2ImagesRequest1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `description` | `?string` | Optional | An optional free-form text field to describe an image. | getDescription(): ?string | setDescription(?string description): void |
| `distribution` | [`?string(Distribution)`](../../doc/models/distribution.md) | Optional | The name of a custom image's distribution. Currently, the valid values are  `Arch Linux`, `CentOS`, `CoreOS`, `Debian`, `Fedora`, `Fedora Atomic`,  `FreeBSD`, `Gentoo`, `openSUSE`, `RancherOS`, `Rocky Linux`, `Ubuntu`, and `Unknown`.  Any other value will be accepted but ignored, and `Unknown` will be used in its place. | getDistribution(): ?string | setDistribution(?string distribution): void |
| `name` | `?string` | Optional | The display name that has been given to an image.  This is what is shown in the control panel and is generally a descriptive title for the image in question. | getName(): ?string | setName(?string name): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2ImagesRequest1Builder;
use DigitalOceanApiLib\Models\Distribution;
use DigitalOceanApiLib\ApiHelper;

$v2ImagesRequest1 = V2ImagesRequest1Builder::init()
    ->description('description4')
    ->distribution(Distribution::UBUNTU)
    ->name('Nifty New Snapshot')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

