
# V2 Uptime Checks Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2UptimeChecksResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checks` | [`List[Check]`](../../doc/models/check.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.check import Check
from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.region_8 import Region8
from digitaloceanapi.models.v_2_uptime_checks_response import V2UptimeChecksResponse

v_2_uptime_checks_response = V2UptimeChecksResponse(
    meta=Meta(
        total=1,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    checks=[
        Check(
            id='00000820-0000-0000-0000-000000000000',
            enabled=False,
            name='name0',
            regions=[
                Region8.US_WEST,
                Region8.EU_WEST,
                Region8.SE_ASIA
            ],
            target='target2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Check(
            id='00000820-0000-0000-0000-000000000000',
            enabled=False,
            name='name0',
            regions=[
                Region8.US_WEST,
                Region8.EU_WEST,
                Region8.SE_ASIA
            ],
            target='target2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Check(
            id='00000820-0000-0000-0000-000000000000',
            enabled=False,
            name='name0',
            regions=[
                Region8.US_WEST,
                Region8.EU_WEST,
                Region8.SE_ASIA
            ],
            target='target2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    links=Links(
        pages=Pages(
            last='last6',
            next='next2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

