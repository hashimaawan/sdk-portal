
# V2 Databases Online Migration Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesOnlineMigrationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `disable_ssl` | `TrueClass \| FalseClass` | Optional | Enables SSL encryption when connecting to the source database. |
| `source` | [`Source`](../../doc/models/source.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_online_migration_request = V2DatabasesOnlineMigrationRequest.new(
  disable_ssl: false,
  source: Source.new(
    database: 'database4',
    host: 'host4',
    password: 'password8',
    port: 180,
    ssl: false,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

