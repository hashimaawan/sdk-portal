
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `KUBERNETES` |

## Example

```python
from digitaloceanapi.models.mtype import Type

mtype = Type.DROPLET
```

