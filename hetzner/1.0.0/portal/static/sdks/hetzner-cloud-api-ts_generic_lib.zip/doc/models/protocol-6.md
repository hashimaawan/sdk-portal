
# Protocol 6

Type of the health check

## Enumeration

`Protocol6`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |

## Example

```ts
import { Protocol6 } from 'hetzner-cloud-apilib';

const protocol6 = Protocol6.Tcp;
```

