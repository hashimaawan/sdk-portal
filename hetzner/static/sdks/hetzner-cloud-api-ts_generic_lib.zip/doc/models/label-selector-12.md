
# Label Selector 12

Configuration for label selector targets, required if type is `label_selector`

## Structure

`LabelSelector12`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector |

## Example

```ts
import { LabelSelector12 } from 'hetzner-cloud-apilib';

const labelSelector12: LabelSelector12 = {
  selector: 'env=prod',
};
```

