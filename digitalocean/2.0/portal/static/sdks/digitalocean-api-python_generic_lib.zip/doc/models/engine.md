
# Engine

- MYSQL: MySQL
- PG: PostgreSQL
- REDIS: Redis

## Enumeration

`Engine`

## Fields

| Name |
|  --- |
| `UNSET` |
| `MYSQL` |
| `PG` |
| `REDIS` |

## Example

```python
from digitaloceanapi.models.engine import Engine

engine = Engine.PG
```

