
# V2 Functions Namespaces Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `str` | Required | The namespace's unique name. |
| `region` | `str` | Required | The [datacenter region](https://docs.digitalocean.com/products/platform/availability-matrix/#available-datacenters) in which to create the namespace. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_functions_namespaces_request import V2FunctionsNamespacesRequest

v_2_functions_namespaces_request = V2FunctionsNamespacesRequest(
    label='my namespace',
    region='nyc1',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

