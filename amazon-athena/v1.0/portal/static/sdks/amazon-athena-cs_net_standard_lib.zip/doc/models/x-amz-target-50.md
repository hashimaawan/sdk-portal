
# X Amz Target 50

## Enumeration

`XAmzTarget50`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStopQueryExecution` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget50 xAmzTarget50 = XAmzTarget50.EnumAmazonAthenaStopQueryExecution;
```

