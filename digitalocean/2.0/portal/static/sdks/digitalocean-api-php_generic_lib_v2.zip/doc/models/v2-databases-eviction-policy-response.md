
# V2 Databases Eviction Policy Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesEvictionPolicyResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `evictionPolicy` | [`string(RedisMaxmemoryPolicy)`](../../doc/models/redis-maxmemory-policy.md) | Required | A string specifying the desired eviction policy for the Redis cluster.<br><br>- `noeviction`: Don't evict any data, returns error when memory limit is reached.<br>- `allkeys_lru:` Evict any key, least recently used (LRU) first.<br>- `allkeys_random`: Evict keys in a random order.<br>- `volatile_lru`: Evict keys with expiration only, least recently used (LRU) first.<br>- `volatile_random`: Evict keys with expiration only in a random order.<br>- `volatile_ttl`: Evict keys with expiration only, shortest time-to-live (TTL) first. | getEvictionPolicy(): string | setEvictionPolicy(string evictionPolicy): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesEvictionPolicyResponseBuilder;
use DigitalOceanApiLib\Models\RedisMaxmemoryPolicy;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesEvictionPolicyResponse = V2DatabasesEvictionPolicyResponseBuilder::init(
    RedisMaxmemoryPolicy::ALLKEYS_LRU
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

