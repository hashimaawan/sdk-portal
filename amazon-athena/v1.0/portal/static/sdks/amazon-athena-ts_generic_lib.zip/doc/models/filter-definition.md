
# Filter Definition

A string for searching notebook names.

## Structure

`FilterDefinition`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```ts
import { FilterDefinition } from 'amazon-athenalib';

const filterDefinition: FilterDefinition = {
  name: 'Name2',
};
```

