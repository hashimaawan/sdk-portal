
# Type 22 Enum

Type of the Image

## Enumeration

`Type22Enum`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `APP` |
| `SNAPSHOT` |
| `BACKUP` |
| `TEMPORARY` |

## Example

```python
from hetznercloudapi.models.type_22_enum import Type22Enum

type_22 = Type22Enum.APP
```

