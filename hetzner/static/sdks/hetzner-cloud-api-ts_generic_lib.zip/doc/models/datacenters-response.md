
# Datacenters Response

## Structure

`DatacentersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `datacenters` | [`Datacenter[]`](../../doc/models/datacenter.md) | Required | - |
| `recommendation` | `number` | Required | The Datacenter which is recommended to be used to create new Servers. |

## Example

```ts
import { DatacentersResponse } from 'hetzner-cloud-apilib';

const datacentersResponse: DatacentersResponse = {
  datacenters: [
    {
      description: 'Falkenstein DC Park 8',
      id: 42,
      location: {
        city: 'Falkenstein',
        country: 'DE',
        description: 'Falkenstein DC Park 1',
        id: 1,
        latitude: 50.47612,
        longitude: 12.370071,
        name: 'fsn1',
        networkZone: 'eu-central',
      },
      name: 'fsn1-dc8',
      serverTypes: {
        available: [
          1,
          2,
          3
        ],
        availableForMigration: [
          1,
          2,
          3
        ],
        supported: [
          1,
          2,
          3
        ],
      },
    }
  ],
  recommendation: 1,
};
```

