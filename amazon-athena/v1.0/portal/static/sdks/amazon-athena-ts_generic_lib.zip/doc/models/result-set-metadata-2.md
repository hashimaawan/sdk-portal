
# Result Set Metadata 2

## Structure

`ResultSetMetadata2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `columnInfo` | [`ColumnInfo[] \| undefined`](../../doc/models/column-info.md) | Optional | - |

## Example

```ts
import { ResultSetMetadata2 } from 'amazon-athenalib';

const resultSetMetadata2: ResultSetMetadata2 = {
  columnInfo: [
    {
      name: 'Name6',
      type: 'Type6',
      catalogName: 'CatalogName0',
      schemaName: 'SchemaName0',
      tableName: 'TableName2',
      label: 'Label4',
      precision: 48,
    },
    {
      name: 'Name6',
      type: 'Type6',
      catalogName: 'CatalogName0',
      schemaName: 'SchemaName0',
      tableName: 'TableName2',
      label: 'Label4',
      precision: 48,
    }
  ],
};
```

