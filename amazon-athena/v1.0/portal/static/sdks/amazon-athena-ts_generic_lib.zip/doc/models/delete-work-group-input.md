
# Delete Work Group Input

## Structure

`DeleteWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `recursiveDeleteOption` | `boolean \| undefined` | Optional | - |

## Example

```ts
import { DeleteWorkGroupInput } from 'amazon-athenalib';

const deleteWorkGroupInput: DeleteWorkGroupInput = {
  workGroup: 'WorkGroup0',
  recursiveDeleteOption: false,
};
```

