# Activity

Access API Request Activity

```php
$activityApi = $client->getActivityApi();
```

## Class Name

`ActivityApi`


# Get Api Activity

```php
function getApiActivity(?int $limit = 50, ?int $offset = 0): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `?int` | Query, Optional | How many API Events should be retrieved in a single request.<br><br>**Default**: `50` |
| `offset` | `?int` | Query, Optional | How far into the collection of API Events should the response start<br><br>**Default**: `0` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ApiRequest[]`](../../doc/models/api-request.md).

## Example Usage

```php
$limit = 10;

$offset = 50;

$activityApi = $client->getActivityApi();
$apiResponse = $activityApi->getApiActivity(
    $limit,
    $offset
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ApiRequest[]:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

