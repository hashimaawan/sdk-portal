
# X Amz Target 41

## Enumeration

`XAmzTarget41`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```python
from amazonathena.models.x_amz_target_41 import XAmzTarget41

x_amz_target_41 = XAmzTarget41.ENUM_AMAZONATHENALISTQUERYEXECUTIONS
```

