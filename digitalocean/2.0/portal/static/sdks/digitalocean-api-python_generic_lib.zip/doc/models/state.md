
# State

A string representing the current state of the certificate. It may be `pending`, `verified`, or `error`.

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `PENDING` |
| `VERIFIED` |
| `ERROR` |

## Example

```python
from digitaloceanapi.models.state import State

state = State.ERROR
```

