
# Status 73 Enum

Status of the Server

## Enumeration

`Status73Enum`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `INITIALIZING` |
| `STARTING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `MIGRATING` |
| `REBUILDING` |
| `UNKNOWN` |

## Example

```python
from hetznercloudapi.models.status_73_enum import Status73Enum

status_73 = Status73Enum.STOPPING
```

