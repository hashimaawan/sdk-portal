
# X Amz Target 33 Enum

## Enumeration

`XAmzTarget33Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATACATALOGS` |

## Example

```python
from amazonathena.models.x_amz_target_33_enum import XAmzTarget33Enum

x_amz_target_33 = XAmzTarget33Enum.ENUM_AMAZONATHENALISTDATACATALOGS
```

