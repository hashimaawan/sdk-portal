
# X Amz Target 11 Enum

## Enumeration

`XAmzTarget11Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteNotebook` |

## Example

```ts
import { XAmzTarget11Enum } from 'amazon-athenalib';

const xAmzTarget11 = XAmzTarget11Enum.EnumAmazonAthenaDeleteNotebook;
```

