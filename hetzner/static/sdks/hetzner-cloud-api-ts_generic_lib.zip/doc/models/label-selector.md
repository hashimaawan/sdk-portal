
# Label Selector

## Structure

`LabelSelector`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector |

## Example

```ts
import { LabelSelector } from 'hetzner-cloud-apilib';

const labelSelector: LabelSelector = {
  selector: 'env=prod',
};
```

