
# Protocol 7 Enum

Protocol of the Load Balancer

## Enumeration

`Protocol7Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```java
import cloud.hetzner.api.models.Protocol7Enum;

Protocol7Enum protocol7 = Protocol7Enum.HTTP;
```

