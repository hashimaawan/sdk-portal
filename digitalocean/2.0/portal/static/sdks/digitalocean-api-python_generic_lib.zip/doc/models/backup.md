
# Backup

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Backup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `created_at` | `datetime` | Required | A time value given in ISO8601 combined date and time format at which the backup was created. |
| `size_gigabytes` | `float` | Required | The size of the database backup in GBs. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.backup import Backup

backup = Backup(
    created_at=dateutil.parser.parse('2019-01-31T19:25:22Z'),
    size_gigabytes=0.03364864,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

