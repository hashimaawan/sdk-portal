
# Column

Contains metadata for a column in a table.

## Structure

`Column`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `type` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `4096` |
| `comment` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |

## Example

```ts
import { Column } from 'amazon-athenalib';

const column: Column = {
  name: 'Name6',
  type: 'Type6',
  comment: 'Comment2',
};
```

