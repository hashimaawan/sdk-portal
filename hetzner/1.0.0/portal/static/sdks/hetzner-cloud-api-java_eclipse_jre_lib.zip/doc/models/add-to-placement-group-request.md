
# Add to Placement Group Request

*This model accepts additional fields of type Object.*

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PlacementGroup` | `int` | Required | ID of Placement Group the Server should be added to | int getPlacementGroup() | setPlacementGroup(int placementGroup) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.AddToPlacementGroupRequest;
import java.io.IOException;

AddToPlacementGroupRequest addToPlacementGroupRequest = new AddToPlacementGroupRequest.Builder(
    1
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

