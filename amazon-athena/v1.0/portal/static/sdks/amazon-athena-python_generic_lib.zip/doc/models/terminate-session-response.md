
# Terminate Session Response

*This model accepts additional fields of type Any.*

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`SessionState1`](../../doc/models/session-state-1.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.session_state_1 import SessionState1
from amazonathena.models.terminate_session_response import TerminateSessionResponse

terminate_session_response = TerminateSessionResponse(
    state=SessionState1.CREATING,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

