
# Type 66 Enum

## Enumeration

`Type66Enum`

## Fields

| Name |
|  --- |
| `Cpu` |
| `Disk` |
| `Network` |

## Example

```ts
import { Type66Enum } from 'hetzner-cloud-apilib';

const type66 = Type66Enum.Network;
```

