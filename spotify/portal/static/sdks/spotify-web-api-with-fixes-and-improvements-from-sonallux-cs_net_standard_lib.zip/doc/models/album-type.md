
# Album Type

The type of the album.

## Enumeration

`AlbumType`

## Fields

| Name |
|  --- |
| `Album` |
| `Single` |
| `Compilation` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

AlbumType albumType = AlbumType.Compilation;
```

