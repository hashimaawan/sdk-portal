
# Type 63

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |
| `BACKUP` |

## Example

```java
import cloud.hetzner.api.models.Type63;

Type63 type63 = Type63.SNAPSHOT;
```

