
# Get Query Results Output

## Structure

`GetQueryResultsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UpdateCount` | `*int` | Optional | - |
| `ResultSet` | [`*models.ResultSet2`](../../doc/models/result-set-2.md) | Optional | - |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getQueryResultsOutput := models.GetQueryResultsOutput{
        UpdateCount:          models.ToPointer(60),
        ResultSet:            models.ToPointer(models.ResultSet2{
            Rows:                 []models.Row{
                models.Row{
                    Data:                 []models.Datum{
                        models.Datum{
                            VarCharValue:         models.ToPointer("VarCharValue8"),
                        },
                        models.Datum{
                            VarCharValue:         models.ToPointer("VarCharValue8"),
                        },
                    },
                },
                models.Row{
                    Data:                 []models.Datum{
                        models.Datum{
                            VarCharValue:         models.ToPointer("VarCharValue8"),
                        },
                        models.Datum{
                            VarCharValue:         models.ToPointer("VarCharValue8"),
                        },
                    },
                },
            },
            ResultSetMetadata:    models.ToPointer(models.ResultSetMetadata2{
                ColumnInfo:           []models.ColumnInfo{
                    models.ColumnInfo{
                        CatalogName:          models.ToPointer("CatalogName0"),
                        SchemaName:           models.ToPointer("SchemaName0"),
                        TableName:            models.ToPointer("TableName2"),
                        Name:                 "Name6",
                        Label:                models.ToPointer("Label4"),
                        Type:                 "Type6",
                        Precision:            models.ToPointer(48),
                    },
                },
            }),
        }),
        NextToken:            models.ToPointer("NextToken0"),
    }

}
```

