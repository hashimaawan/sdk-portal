
# Batch Get Query Execution Output

## Structure

`BatchGetQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_executions` | [`Array[QueryExecution]`](../../doc/models/query-execution.md) | Optional | - |
| `unprocessed_query_execution_ids` | [`Array[UnprocessedQueryExecutionId]`](../../doc/models/unprocessed-query-execution-id.md) | Optional | - |

## Example

```ruby
batch_get_query_execution_output = BatchGetQueryExecutionOutput.new(
  [
    QueryExecution.new(
      'QueryExecutionId6',
      'Query0',
      StatementType1Enum::UTILITY,
      ResultConfiguration1.new(
        'OutputLocation0',
        EncryptionConfiguration2.new(
          EncryptionOption1Enum::SSE_S3,
          'KmsKey6'
        ),
        'ExpectedBucketOwner0',
        AclConfiguration1.new(
          S3AclOption1Enum::BUCKET_OWNER_FULL_CONTROL
        )
      ),
      ResultReuseConfiguration1.new(
        ResultReuseByAgeConfiguration2.new(
          false,
          26
        )
      ),
      QueryExecutionContext1.new,
      Status.new(
        envrr,
        nil,
        DateTimeHelper.from_rfc3339(nil),
        DateTimeHelper.from_rfc3339(nil),
        AthenaError2.new
      ),
      Statistics.new(
        nil,
        nil,
        nil,
        nil,
        nil,
        nil,
        nil,
        ResultReuseInformation2.new
      ),
      nil,
      EngineVersion1.new,
      []
    ),
    QueryExecution.new(
      'QueryExecutionId6',
      'Query0',
      StatementType1Enum::UTILITY,
      ResultConfiguration1.new(
        'OutputLocation0',
        EncryptionConfiguration2.new(
          EncryptionOption1Enum::SSE_S3,
          'KmsKey6'
        ),
        'ExpectedBucketOwner0',
        AclConfiguration1.new(
          S3AclOption1Enum::BUCKET_OWNER_FULL_CONTROL
        )
      ),
      ResultReuseConfiguration1.new(
        ResultReuseByAgeConfiguration2.new(
          false,
          26
        )
      ),
      QueryExecutionContext1.new,
      Status.new(
        envrr,
        nil,
        DateTimeHelper.from_rfc3339(nil),
        DateTimeHelper.from_rfc3339(nil),
        AthenaError2.new
      ),
      Statistics.new(
        nil,
        nil,
        nil,
        nil,
        nil,
        nil,
        nil,
        ResultReuseInformation2.new
      ),
      nil,
      EngineVersion1.new,
      []
    )
  ],
  [
    UnprocessedQueryExecutionId.new(
      'QueryExecutionId6',
      'ErrorCode2',
      'ErrorMessage8'
    ),
    UnprocessedQueryExecutionId.new(
      'QueryExecutionId6',
      'ErrorCode2',
      'ErrorMessage8'
    ),
    UnprocessedQueryExecutionId.new(
      'QueryExecutionId6',
      'ErrorCode2',
      'ErrorMessage8'
    )
  ]
)
```

