
# Type 42 Enum

Type of Subnetwork

## Enumeration

`Type42Enum`

## Fields

| Name |
|  --- |
| `CLOUD` |
| `SERVER` |
| `VSWITCH` |

## Example

```java
import cloud.hetzner.api.models.Type42Enum;

Type42Enum type42 = Type42Enum.CLOUD;
```

