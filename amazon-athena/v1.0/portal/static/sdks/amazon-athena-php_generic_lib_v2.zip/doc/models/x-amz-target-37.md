
# X Amz Target 37

## Enumeration

`XAmzTarget37`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNAMEDQUERIES` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget37;

$xAmzTarget37 = XAmzTarget37::ENUM_AMAZONATHENALISTNAMEDQUERIES;
```

