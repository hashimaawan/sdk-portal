
# X Amz Target 51

## Enumeration

`XAmzTarget51`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATAGRESOURCE` |

## Example

```ruby
x_amz_target51 = XAmzTarget51::ENUM_AMAZONATHENATAGRESOURCE
```

