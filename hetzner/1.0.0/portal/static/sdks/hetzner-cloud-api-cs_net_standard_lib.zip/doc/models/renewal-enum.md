
# Renewal Enum

Status of the renewal process of the Certificate.

## Enumeration

`RenewalEnum`

## Fields

| Name |
|  --- |
| `Scheduled` |
| `Pending` |
| `Failed` |
| `Unavailable` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

RenewalEnum renewal = RenewalEnum.Failed;
```

