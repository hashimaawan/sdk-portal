
# X Amz Target 36

## Enumeration

`XAmzTarget36`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTEXECUTORS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget36;

$xAmzTarget36 = XAmzTarget36::ENUM_AMAZONATHENALISTEXECUTORS;
```

