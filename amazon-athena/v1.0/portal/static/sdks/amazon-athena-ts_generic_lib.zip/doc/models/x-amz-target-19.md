
# X Amz Target 19

## Enumeration

`XAmzTarget19`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetDatabase` |

## Example

```ts
import { XAmzTarget19 } from 'amazon-athenalib';

const xAmzTarget19 = XAmzTarget19.EnumAmazonAthenaGetDatabase;
```

