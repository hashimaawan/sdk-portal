
# X Amz Target 11

## Enumeration

`XAmzTarget11`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_11 import XAmzTarget11

x_amz_target_11 = XAmzTarget11.ENUM_AMAZONATHENADELETENOTEBOOK
```

