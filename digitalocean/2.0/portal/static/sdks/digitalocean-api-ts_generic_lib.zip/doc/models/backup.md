
# Backup

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Backup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `createdAt` | `string` | Required | A time value given in ISO8601 combined date and time format at which the backup was created. |
| `sizeGigabytes` | `number` | Required | The size of the database backup in GBs. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Backup } from 'digitalocean-apilib';

const backup: Backup = {
  createdAt: '2019-01-31T19:25:22Z',
  sizeGigabytes: 0.03364864,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

