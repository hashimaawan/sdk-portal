
# V2 Firewalls Tags Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2FirewallsTagsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | `List[str]` | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_firewalls_tags_request import V2FirewallsTagsRequest

v_2_firewalls_tags_request = V2FirewallsTagsRequest(
    tags=[
        'tags7',
        'tags8'
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

