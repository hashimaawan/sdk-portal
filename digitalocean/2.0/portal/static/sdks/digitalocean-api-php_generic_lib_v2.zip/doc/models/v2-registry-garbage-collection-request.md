
# V2 Registry Garbage Collection Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cancel` | `?bool` | Optional | A boolean value indicating that the garbage collection should be cancelled. | getCancel(): ?bool | setCancel(?bool cancel): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2RegistryGarbageCollectionRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2RegistryGarbageCollectionRequest = V2RegistryGarbageCollectionRequestBuilder::init()
    ->cancel(true)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

