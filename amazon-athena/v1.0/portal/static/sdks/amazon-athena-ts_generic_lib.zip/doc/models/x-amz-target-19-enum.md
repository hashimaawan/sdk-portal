
# X Amz Target 19 Enum

## Enumeration

`XAmzTarget19Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetDatabase` |

## Example

```ts
import { XAmzTarget19Enum } from 'amazon-athenalib';

const xAmzTarget19 = XAmzTarget19Enum.EnumAmazonAthenaGetDatabase;
```

