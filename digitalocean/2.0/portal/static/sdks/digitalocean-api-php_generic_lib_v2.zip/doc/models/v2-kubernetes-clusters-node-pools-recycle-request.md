
# V2 Kubernetes Clusters Node Pools Recycle Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersNodePoolsRecycleRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `nodes` | `?(string[])` | Optional | - | getNodes(): ?array | setNodes(?array nodes): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2KubernetesClustersNodePoolsRecycleRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2KubernetesClustersNodePoolsRecycleRequest = V2KubernetesClustersNodePoolsRecycleRequestBuilder::init()
    ->nodes(
        [
            'd8db5e1a-6103-43b5-a7b3-8a948210a9fc'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

