
# Custom Header Signature



Documentation for accessing and setting credentials for hmac.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| Authorization | `string` | Amazon Signature authorization v4 | `Authorization` | `Authorization` |



**Note:** Auth credentials can be set using `CustomHeaderAuthenticationCredentials` in the client builder and accessed through `CustomHeaderAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```csharp
using AmazonAthena.Standard;
using AmazonAthena.Standard.Authentication;

namespace ConsoleApp;

AmazonAthenaClient client = new AmazonAthenaClient.Builder()
    .CustomHeaderAuthenticationCredentials(
        new CustomHeaderAuthenticationModel.Builder(
            "Authorization"
        )
        .Build())
    .Build();
```


