# Network Actions

```php
$networkActionsApi = $client->getNetworkActionsApi();
```

## Class Name

`NetworkActionsApi`

## Methods

* [Get All Actions for a Network](../../doc/controllers/network-actions.md#get-all-actions-for-a-network)
* [Add a Route to a Network](../../doc/controllers/network-actions.md#add-a-route-to-a-network)
* [Add a Subnet to a Network](../../doc/controllers/network-actions.md#add-a-subnet-to-a-network)
* [Change IP Range of a Network](../../doc/controllers/network-actions.md#change-ip-range-of-a-network)
* [Change Network Protection](../../doc/controllers/network-actions.md#change-network-protection)
* [Delete a Route from a Network](../../doc/controllers/network-actions.md#delete-a-route-from-a-network)
* [Delete a Subnet from a Network](../../doc/controllers/network-actions.md#delete-a-subnet-from-a-network)
* [Get an Action for a Network](../../doc/controllers/network-actions.md#get-an-action-for-a-network)


# Get All Actions for a Network

Returns all Action objects for a Network. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```php
function getAllActionsForANetwork(int $id, ?string $sort = null, ?string $status = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `sort` | [`?string(ParameterSort)`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`?string(ParameterStatus)`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionsResponse`](../../doc/models/actions-response.md).

## Example Usage

```php
$id = 112;

$networkActionsApi = $client->getNetworkActionsApi();
$apiResponse = $networkActionsApi->getAllActionsForANetwork($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "add_subnet",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Add a Route to a Network

Adds a route entry to a Network.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```php
function addARouteToANetwork(int $id, ?AddDeleteRouteRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`?AddDeleteRouteRequest`](../../doc/models/add-delete-route-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `add_route` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$body = AddDeleteRouteRequestBuilder::init(
    '10.100.1.0/24',
    '10.0.1.1'
)->build();

$networkActionsApi = $client->getNetworkActionsApi();
$apiResponse = $networkActionsApi->addARouteToANetwork(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_route",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Add a Subnet to a Network

Adds a new subnet object to the Network. If you do not specify an `ip_range` for the subnet we will automatically pick the first available /24 range for you if possible.

Note: if the parent Network object changes during the request, the response will be a “conflict” error.

```php
function addASubnetToANetwork(int $id, ?AddSubnetRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`?AddSubnetRequest`](../../doc/models/add-subnet-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `add_subnet` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$body = AddSubnetRequestBuilder::init(
    'eu-central',
    Type42::SERVER
)
    ->ipRange('10.0.1.0/24')
    ->vswitchId(1000)
    ->build();

$networkActionsApi = $client->getNetworkActionsApi();
$apiResponse = $networkActionsApi->addASubnetToANetwork(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_subnet",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change IP Range of a Network

Changes the IP range of a Network. IP ranges can only be extended and never shrunk. You can only add IPs at the end of an existing IP range. This means that the IP part of your existing range must stay the same and you can only change its netmask.

For example if you have a range `10.0.0.0/16` you want to extend then your new range must also start with the IP `10.0.0.0`. Your CIDR netmask `/16` may change to a number that is smaller than `16` thereby increasing the IP range. So valid entries would be `10.0.0.0/15`, `10.0.0.0/14`, `10.0.0.0/13` and so on.

After changing the IP range you will have to adjust the routes on your connected Servers by either rebooting them or manually changing the routes to your private Network interface.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```php
function changeIpRangeOfANetwork(int $id, ?ChangeIpRangeRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`?ChangeIpRangeRequest`](../../doc/models/change-ip-range-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_ip_range` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$body = ChangeIpRangeRequestBuilder::init(
    '10.0.0.0/12'
)->build();

$networkActionsApi = $client->getNetworkActionsApi();
$apiResponse = $networkActionsApi->changeIpRangeOfANetwork(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_ip_range",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Network Protection

Changes the protection configuration of a Network.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```php
function changeNetworkProtection(int $id, ?ChangeProtectionRequest1 $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`?ChangeProtectionRequest1`](../../doc/models/change-protection-request-1.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$body = ChangeProtectionRequest1Builder::init()
    ->delete(true)
    ->build();

$networkActionsApi = $client->getNetworkActionsApi();
$apiResponse = $networkActionsApi->changeNetworkProtection(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Delete a Route from a Network

Delete a route entry from a Network.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```php
function deleteARouteFromANetwork(int $id, ?AddDeleteRouteRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`?AddDeleteRouteRequest`](../../doc/models/add-delete-route-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `delete_route` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$body = AddDeleteRouteRequestBuilder::init(
    '10.100.1.0/24',
    '10.0.1.1'
)->build();

$networkActionsApi = $client->getNetworkActionsApi();
$apiResponse = $networkActionsApi->deleteARouteFromANetwork(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "delete_route",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Delete a Subnet from a Network

Deletes a single subnet entry from a Network. You cannot delete subnets which still have Servers attached. If you have Servers attached you first need to detach all Servers that use IPs from this subnet before you can delete the subnet.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```php
function deleteASubnetFromANetwork(int $id, ?DeleteSubnetRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`?DeleteSubnetRequest`](../../doc/models/delete-subnet-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `delete_subnet` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$body = DeleteSubnetRequestBuilder::init(
    '10.0.1.0/24'
)->build();

$networkActionsApi = $client->getNetworkActionsApi();
$apiResponse = $networkActionsApi->deleteASubnetFromANetwork(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "delete_subnet",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Get an Action for a Network

Returns a specific Action for a Network.

```php
function getAnActionForANetwork(int $id, int $actionId): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Network Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```php
$id = 112;

$actionId = 224;

$networkActionsApi = $client->getNetworkActionsApi();
$apiResponse = $networkActionsApi->getAnActionForANetwork(
    $id,
    $actionId
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ActionResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_subnet",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

