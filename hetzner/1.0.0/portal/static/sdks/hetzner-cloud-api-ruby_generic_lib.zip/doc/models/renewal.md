
# Renewal

Status of the renewal process of the Certificate.

## Enumeration

`Renewal`

## Fields

| Name |
|  --- |
| `SCHEDULED` |
| `PENDING` |
| `FAILED` |
| `UNAVAILABLE` |

## Example

```ruby
renewal = Renewal::FAILED
```

