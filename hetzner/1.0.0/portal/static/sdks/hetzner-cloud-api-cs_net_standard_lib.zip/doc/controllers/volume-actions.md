# Volume Actions

```csharp
VolumeActionsApi volumeActionsApi = client.VolumeActionsApi;
```

## Class Name

`VolumeActionsApi`

## Methods

* [Get All Actions for a Volume](../../doc/controllers/volume-actions.md#get-all-actions-for-a-volume)
* [Attach Volume to a Server](../../doc/controllers/volume-actions.md#attach-volume-to-a-server)
* [Change Volume Protection](../../doc/controllers/volume-actions.md#change-volume-protection)
* [Detach Volume](../../doc/controllers/volume-actions.md#detach-volume)
* [Resize Volume](../../doc/controllers/volume-actions.md#resize-volume)
* [Get an Action for a Volume](../../doc/controllers/volume-actions.md#get-an-action-for-a-volume)


# Get All Actions for a Volume

Returns all Action objects for a Volume. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```csharp
GetAllActionsForAVolumeAsync(
    int id,
    Models.ParameterSort? sort = null,
    Models.ParameterStatus? status = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `sort` | [`ParameterSort?`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatus?`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```csharp
int id = 112;
try
{
    ApiResponse<ActionsResponse> result = await volumeActionsApi.GetAllActionsForAVolumeAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "attach_volume",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 13,
          "type": "volume"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Attach Volume to a Server

Attaches a Volume to a Server. Works only if the Server is in the same Location as the Volume.

```csharp
AttachVolumeToAServerAsync(
    int id,
    Models.AttachVolumeRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`AttachVolumeRequest`](../../doc/models/attach-volume-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `attach_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```csharp
int id = 112;
AttachVolumeRequest body = new AttachVolumeRequest
{
    Server = 43,
    Automount = false,
};

try
{
    ApiResponse<ActionResponse> result = await volumeActionsApi.AttachVolumeToAServerAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 43,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Volume Protection

Changes the protection configuration of a Volume.

```csharp
ChangeVolumeProtectionAsync(
    int id,
    Models.VolumesActionsChangeProtectionRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`VolumesActionsChangeProtectionRequest`](../../doc/models/volumes-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```csharp
int id = 112;
VolumesActionsChangeProtectionRequest body = new VolumesActionsChangeProtectionRequest
{
    Delete = true,
};

try
{
    ApiResponse<ActionResponse> result = await volumeActionsApi.ChangeVolumeProtectionAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Detach Volume

Detaches a Volume from the Server it’s attached to. You may attach it to a Server again at a later time.

```csharp
DetachVolumeAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |

## Response Type

**201**: The `action` key contains the `detach_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```csharp
int id = 112;
try
{
    ApiResponse<ActionResponse> result = await volumeActionsApi.DetachVolumeAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "detach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Resize Volume

Changes the size of a Volume. Note that downsizing a Volume is not possible.

```csharp
ResizeVolumeAsync(
    int id,
    Models.VolumesActionsResizeRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `body` | [`VolumesActionsResizeRequest`](../../doc/models/volumes-actions-resize-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `resize_volume` Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```csharp
int id = 112;
VolumesActionsResizeRequest body = new VolumesActionsResizeRequest
{
    Size = 50,
};

try
{
    ApiResponse<ActionResponse> result = await volumeActionsApi.ResizeVolumeAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "resize_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Get an Action for a Volume

Returns a specific Action for a Volume.

```csharp
GetAnActionForAVolumeAsync(
    int id,
    int actionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Volume |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Volume Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```csharp
int id = 112;
int actionId = 224;
try
{
    ApiResponse<ActionResponse> result = await volumeActionsApi.GetAnActionForAVolumeAsync(
        id,
        actionId
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

