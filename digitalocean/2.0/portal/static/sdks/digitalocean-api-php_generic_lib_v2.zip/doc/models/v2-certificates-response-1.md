
# V2 Certificates Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2CertificatesResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `certificate` | [`?Certificate`](../../doc/models/certificate.md) | Optional | - | getCertificate(): ?Certificate | setCertificate(?Certificate certificate): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2CertificatesResponse1Builder;
use DigitalOceanApiLib\Models\Builders\CertificateBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\ApiHelper;

$v2CertificatesResponse1 = V2CertificatesResponse1Builder::init()
    ->certificate(
        CertificateBuilder::init()
            ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->dnsNames(
                [
                    'dns_names8',
                    'dns_names9',
                    'dns_names0'
                ]
            )
            ->id('00002190-0000-0000-0000-000000000000')
            ->name('name2')
            ->notAfter(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

