
# Create Data Catalog Input

## Structure

`CreateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `type` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters \| undefined`](../../doc/models/parameters.md) | Optional | - |
| `tags` | [`Tag[] \| undefined`](../../doc/models/tag.md) | Optional | - |

## Example

```ts
import {
  CreateDataCatalogInput,
  DataCatalogType1Enum,
} from 'amazon-athenalib';

const createDataCatalogInput: CreateDataCatalogInput = {
  name: 'Name6',
  type: DataCatalogType1Enum.GLUE,
  description: 'Description2',
  parameters: {},
  tags: [
    {
      key: 'Key0',
      value: 'Value6',
    },
    {
      key: 'Key0',
      value: 'Value6',
    },
    {
      key: 'Key0',
      value: 'Value6',
    }
  ],
};
```

