
# X Amz Target 44

## Enumeration

`XAmzTarget44`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```ruby
x_amz_target44 = XAmzTarget44::ENUM_AMAZONATHENALISTTAGSFORRESOURCE
```

