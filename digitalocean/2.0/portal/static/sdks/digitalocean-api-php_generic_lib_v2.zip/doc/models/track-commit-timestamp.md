
# Track Commit Timestamp

Record commit time of transactions.

## Enumeration

`TrackCommitTimestamp`

## Fields

| Name |
|  --- |
| `OFF` |
| `ON` |

## Example

```php
use DigitalOceanApiLib\Models\TrackCommitTimestamp;

$trackCommitTimestamp = TrackCommitTimestamp::OFF;
```

