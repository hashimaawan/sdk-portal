
# X Amz Target 38 Enum

## Enumeration

`XAmzTarget38Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget38 := models.XAmzTarget38Enum_ENUMAMAZONATHENALISTNOTEBOOKMETADATA

}
```

