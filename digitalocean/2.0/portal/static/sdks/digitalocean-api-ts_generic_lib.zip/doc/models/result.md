
# Result

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Result`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `metric` | `Record<string, string>` | Required | An object containing the metric labels. |
| `values` | [`ResultValues[]`](../../doc/models/containers/result-values.md) | Required | This is 2d Array of a container for one-of cases. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Result } from 'digitalocean-apilib';

const result: Result = {
  metric: {
    'host_id': '19201920'
  },
  values: [
    null,
    null
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

