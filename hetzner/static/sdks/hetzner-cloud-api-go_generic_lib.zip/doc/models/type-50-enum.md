
# Type 50 Enum

Type of the Primary IP

## Enumeration

`Type50Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type50 := models.Type50Enum_IPV4

}
```

