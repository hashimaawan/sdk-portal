
# X Amz Target 27 Enum

## Enumeration

`XAmzTarget27Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSIONSTATUS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget27Enum;

XAmzTarget27Enum xAmzTarget27 = XAmzTarget27Enum.ENUM_AMAZONATHENAGETSESSIONSTATUS;
```

