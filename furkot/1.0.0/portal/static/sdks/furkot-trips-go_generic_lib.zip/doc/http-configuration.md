
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `0` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`furkottripsRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `furkottrips.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "furkottrips"
    "net/http"
)

func main() {
    httpConfiguration := furkottrips.CreateHttpConfiguration(
        furkottrips.WithTimeout(0),
        furkottrips.WithTransport(http.DefaultTransport),
        furkottrips.WithRetryConfiguration(furkottrips.DefaultRetryConfiguration()),
    )
}
```

