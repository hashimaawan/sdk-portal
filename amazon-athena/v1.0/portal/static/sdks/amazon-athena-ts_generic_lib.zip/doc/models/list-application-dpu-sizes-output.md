
# List Application Dpu Sizes Output

*This model accepts additional fields of type unknown.*

## Structure

`ListApplicationDpuSizesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applicationDpuSizes` | [`ApplicationDpuSizes[] \| undefined`](../../doc/models/application-dpu-sizes.md) | Optional | - |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ListApplicationDpuSizesOutput } from 'amazon-athenalib';

const listApplicationDpuSizesOutput: ListApplicationDpuSizesOutput = {
  applicationDpuSizes: [
    {
      applicationRuntimeId: 'ApplicationRuntimeId0',
      supportedDpuSizes: [
        113,
        114
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      applicationRuntimeId: 'ApplicationRuntimeId0',
      supportedDpuSizes: [
        113,
        114
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  nextToken: 'NextToken0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

