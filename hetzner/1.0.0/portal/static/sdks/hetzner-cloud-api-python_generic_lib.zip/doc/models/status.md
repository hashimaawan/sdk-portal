
# Status

Status of the Action

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ERROR` |

## Example

```python
from hetznercloudapi.models.status import Status

status = Status.ERROR
```

