
# Column Nullable 2 Enum

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2Enum`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```python
from amazonathena.models.column_nullable_2_enum import ColumnNullable2Enum

column_nullable_2 = ColumnNullable2Enum.NOT_NULL
```

