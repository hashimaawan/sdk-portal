
# Type 66 Enum

## Enumeration

`Type66Enum`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```java
import cloud.hetzner.api.models.Type66Enum;

Type66Enum type66 = Type66Enum.NETWORK;
```

