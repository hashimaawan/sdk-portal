
# Internal Tmp Mem Storage Engine

The storage engine for in-memory internal temporary tables.

## Enumeration

`InternalTmpMemStorageEngine`

## Fields

| Name |
|  --- |
| `TEMPTABLE` |
| `MEMORY` |

## Example

```php
use DigitalOceanApiLib\Models\InternalTmpMemStorageEngine;

$internalTmpMemStorageEngine = InternalTmpMemStorageEngine::TEMPTABLE;
```

