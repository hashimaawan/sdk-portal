
# X Amz Target 5 Enum

## Enumeration

`XAmzTarget5Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_5_enum import XAmzTarget5Enum

x_amz_target_5 = XAmzTarget5Enum.ENUM_AMAZONATHENACREATENOTEBOOK
```

