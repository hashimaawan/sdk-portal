
# Type 24 Enum

Destination Image type to convert to

## Enumeration

`Type24Enum`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |

## Example

```java
import cloud.hetzner.api.models.Type24Enum;

Type24Enum type24 = Type24Enum.SNAPSHOT;
```

