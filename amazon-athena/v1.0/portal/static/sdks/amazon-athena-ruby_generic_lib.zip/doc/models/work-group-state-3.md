
# Work Group State 3

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ruby
work_group_state3 = WorkGroupState3::ENABLED
```

