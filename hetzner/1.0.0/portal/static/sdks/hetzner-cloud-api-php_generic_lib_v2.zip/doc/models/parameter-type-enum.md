
# Parameter Type Enum

## Enumeration

`ParameterTypeEnum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```php
use HetznerCloudAPILib\Models\ParameterTypeEnum;

$parameterType = ParameterTypeEnum::UPLOADED;
```

