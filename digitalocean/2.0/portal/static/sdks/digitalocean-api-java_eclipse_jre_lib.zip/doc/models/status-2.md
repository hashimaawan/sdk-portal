
# Status 2

## Enumeration

`Status2`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING` |
| `RUNNING` |
| `ERROR` |
| `SUCCESS` |

## Example

```java
import com.digitalocean.api.models.Status2;

Status2 status2 = Status2.PENDING;
```

