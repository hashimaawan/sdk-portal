
# Price per Gb Month

## Structure

`PricePerGbMonth`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

PricePerGbMonth pricePerGbMonth = new PricePerGbMonth
{
    Gross = "1.1900000000000000",
    Net = "1.0000000000",
};
```

