
# Type 42

Type of Subnetwork

## Enumeration

`Type42`

## Fields

| Name |
|  --- |
| `CLOUD` |
| `SERVER` |
| `VSWITCH` |

## Example

```php
use HetznerCloudApiLib\Models\Type42;

$type42 = Type42::CLOUD;
```

