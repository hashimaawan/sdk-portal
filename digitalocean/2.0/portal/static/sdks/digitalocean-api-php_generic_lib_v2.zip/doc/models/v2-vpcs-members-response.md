
# V2 Vpcs Members Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2VpcsMembersResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `members` | [`?(Member[])`](../../doc/models/member.md) | Optional | - | getMembers(): ?array | setMembers(?array members): void |
| `links` | [`?Links`](../../doc/models/links.md) | Optional | - | getLinks(): ?Links | setLinks(?Links links): void |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - | getMeta(): Meta | setMeta(Meta meta): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2VpcsMembersResponseBuilder;
use DigitalOceanApiLib\Models\Builders\MetaBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\MemberBuilder;
use DigitalOceanApiLib\Models\Builders\LinksBuilder;
use DigitalOceanApiLib\Models\Builders\PagesBuilder;

$v2VpcsMembersResponse = V2VpcsMembersResponseBuilder::init(
    MetaBuilder::init(
        4
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->members(
        [
            MemberBuilder::init()
                ->createdAt('2020-03-13T19:30:48Z')
                ->name('nyc1-load-balancer-01')
                ->urn('do:loadbalancer:fb294d78-d193-4cb2-8737-ea620993591b')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            MemberBuilder::init()
                ->createdAt('2020-03-13T19:30:18Z')
                ->name('db-postgresql-nyc1-55986')
                ->urn('do:dbaas:13f7a2f6-43df-4c4a-8129-8733267ddeea')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            MemberBuilder::init()
                ->createdAt('2020-03-13T19:30:16Z')
                ->name('k8s-nyc1-1584127772221')
                ->urn('do:kubernetes:da39d893-96e1-4e4d-971d-1fdda33a46b1')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            MemberBuilder::init()
                ->createdAt('2020-03-13T19:29:20Z')
                ->name('ubuntu-s-1vcpu-1gb-nyc1-01')
                ->urn('do:droplet:86e29982-03a7-4946-8a07-a0114dff8754')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->links(
        LinksBuilder::init()
            ->pages(
                PagesBuilder::init()
                    ->last('last6')
                    ->next('next2')
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

