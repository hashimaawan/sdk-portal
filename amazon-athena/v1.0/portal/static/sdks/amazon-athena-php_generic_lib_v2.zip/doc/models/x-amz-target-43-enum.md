
# X Amz Target 43 Enum

## Enumeration

`XAmzTarget43Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTABLEMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget43Enum;

$xAmzTarget43 = XAmzTarget43Enum::ENUM_AMAZONATHENALISTTABLEMETADATA;
```

