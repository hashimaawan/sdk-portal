
# X Amz Target 26 Enum

## Enumeration

`XAmzTarget26Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetSession` |

## Example

```ts
import { XAmzTarget26Enum } from 'amazon-athenalib';

const xAmzTarget26 = XAmzTarget26Enum.EnumAmazonAthenaGetSession;
```

