
# Renewal Enum

Status of the renewal process of the Certificate.

## Enumeration

`RenewalEnum`

## Fields

| Name |
|  --- |
| `SCHEDULED` |
| `PENDING` |
| `FAILED` |
| `UNAVAILABLE` |

## Example

```php
use HetznerCloudAPILib\Models\RenewalEnum;

$renewal = RenewalEnum::FAILED;
```

