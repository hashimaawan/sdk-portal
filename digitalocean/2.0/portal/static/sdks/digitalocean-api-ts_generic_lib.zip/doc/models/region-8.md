
# Region 8

## Enumeration

`Region8`

## Fields

| Name |
|  --- |
| `UsEast` |
| `UsWest` |
| `EuWest` |
| `SeAsia` |

## Example

```ts
import { Region8 } from 'digitalocean-apilib';

const region8 = Region8.UsEast;
```

