
# Protocol Enum

Type of traffic to allow

## Enumeration

`ProtocolEnum`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |
| `ESP` |
| `GRE` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    protocol := models.ProtocolEnum_ESP

}
```

