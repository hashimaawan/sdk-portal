
# X Amz Target 27 Enum

## Enumeration

`XAmzTarget27Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSIONSTATUS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget27Enum;

$xAmzTarget27 = XAmzTarget27Enum::ENUM_AMAZONATHENAGETSESSIONSTATUS;
```

