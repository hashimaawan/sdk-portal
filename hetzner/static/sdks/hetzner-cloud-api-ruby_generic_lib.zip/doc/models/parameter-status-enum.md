
# Parameter Status Enum

## Enumeration

`ParameterStatusEnum`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ERROR` |

## Example

```ruby
parameter_status = ParameterStatusEnum::ERROR
```

