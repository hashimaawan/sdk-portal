
# Column Nullable 2 Enum

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2Enum`

## Fields

| Name |
|  --- |
| `NOTNULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ColumnNullable2Enum columnNullable2 = ColumnNullable2Enum.NOTNULL;
```

