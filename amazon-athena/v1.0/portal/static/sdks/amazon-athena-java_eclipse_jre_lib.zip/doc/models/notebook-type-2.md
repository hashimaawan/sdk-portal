
# Notebook Type 2

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```java
import com.amazonaws.useast1.athena.models.NotebookType2;

NotebookType2 notebookType2 = NotebookType2.IPYNB;
```

