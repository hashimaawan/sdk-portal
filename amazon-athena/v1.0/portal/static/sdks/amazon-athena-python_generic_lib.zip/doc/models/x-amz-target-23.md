
# X Amz Target 23

## Enumeration

`XAmzTarget23`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_23 import XAmzTarget23

x_amz_target_23 = XAmzTarget23.ENUM_AMAZONATHENAGETQUERYEXECUTION
```

