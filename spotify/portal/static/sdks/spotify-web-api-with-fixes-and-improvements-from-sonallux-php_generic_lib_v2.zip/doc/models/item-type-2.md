
# Item Type 2

The ID type.

## Enumeration

`ItemType2`

## Fields

| Name |
|  --- |
| `ARTIST` |
| `USER` |

## Example

```php
use SpotifyWebApiWithFixesAndImprovementsFromSonalluxLib\Models\ItemType2;

$itemType2 = ItemType2::ARTIST;
```

