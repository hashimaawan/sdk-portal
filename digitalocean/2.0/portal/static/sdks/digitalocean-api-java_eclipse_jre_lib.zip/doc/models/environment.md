
# Environment

The environment of the project's resources.

## Enumeration

`Environment`

## Fields

| Name |
|  --- |
| `DEVELOPMENT` |
| `STAGING` |
| `PRODUCTION` |

## Example

```java
import com.digitalocean.api.models.Environment;

Environment environment = Environment.STAGING;
```

