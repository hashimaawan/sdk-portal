
# Redis Maxmemory Policy

A string specifying the desired eviction policy for the Redis cluster.

- `noeviction`: Don't evict any data, returns error when memory limit is reached.
- `allkeys_lru:` Evict any key, least recently used (LRU) first.
- `allkeys_random`: Evict keys in a random order.
- `volatile_lru`: Evict keys with expiration only, least recently used (LRU) first.
- `volatile_random`: Evict keys with expiration only in a random order.
- `volatile_ttl`: Evict keys with expiration only, shortest time-to-live (TTL) first.

## Enumeration

`RedisMaxmemoryPolicy`

## Fields

| Name |
|  --- |
| `NOEVICTION` |
| `ALLKEYS_LRU` |
| `ALLKEYS_RANDOM` |
| `VOLATILE_LRU` |
| `VOLATILE_RANDOM` |
| `VOLATILE_TTL` |

## Example

```java
import com.digitalocean.api.models.RedisMaxmemoryPolicy;

RedisMaxmemoryPolicy redisMaxmemoryPolicy = RedisMaxmemoryPolicy.ALLKEYS_RANDOM;
```

