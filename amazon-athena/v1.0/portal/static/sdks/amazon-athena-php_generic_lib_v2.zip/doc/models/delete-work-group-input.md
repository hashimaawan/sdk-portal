
# Delete Work Group Input

*This model accepts additional fields of type array.*

## Structure

`DeleteWorkGroupInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): string | setWorkGroup(string workGroup): void |
| `recursiveDeleteOption` | `?bool` | Optional | - | getRecursiveDeleteOption(): ?bool | setRecursiveDeleteOption(?bool recursiveDeleteOption): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DeleteWorkGroupInputBuilder;
use AmazonAthenaLib\ApiHelper;

$deleteWorkGroupInput = DeleteWorkGroupInputBuilder::init(
    'WorkGroup0'
)
    ->recursiveDeleteOption(false)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

