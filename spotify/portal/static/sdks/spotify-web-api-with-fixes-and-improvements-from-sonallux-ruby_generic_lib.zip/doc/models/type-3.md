
# Type 3

The object type.

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `USER` |

## Example

```ruby
type3 = Type3::USER
```

