
# Os Flavor

Flavor of operating system contained in the Image

## Enumeration

`OsFlavor`

## Fields

| Name |
|  --- |
| `Ubuntu` |
| `Centos` |
| `Debian` |
| `Fedora` |
| `Unknown` |

## Example

```ts
import { OsFlavor } from 'hetzner-cloud-apilib';

const osFlavor = OsFlavor.Debian;
```

