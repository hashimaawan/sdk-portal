
# Image

*This model accepts additional fields of type unknown.*

## Structure

`Image`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `boundTo` | `number \| null` | Required | ID of Server the Image is bound to. Only set for Images of type `backup`. |
| `created` | `string` | Required | Point in time when the Resource was created (in ISO-8601 format) |
| `createdFrom` | [`CreatedFrom \| null`](../../doc/models/created-from.md) | Required | Information about the Server the Image was created from |
| `deleted` | `string \| null` | Required | Point in time where the Image was deleted (in ISO-8601 format) |
| `deprecated` | `string \| null` | Required | Point in time when the Image is considered to be deprecated (in ISO-8601 format) |
| `description` | `string` | Required | Description of the Image |
| `diskSize` | `number` | Required | Size of the disk contained in the Image in GB |
| `id` | `number` | Required | ID of the Resource |
| `imageSize` | `number \| null` | Required | Size of the Image file in our storage in GB. For snapshot Images this is the value relevant for calculating costs for the Image. |
| `labels` | `Record<string, string>` | Required | User-defined labels (key-value pairs) |
| `name` | `string \| null` | Required | Unique identifier of the Image. This value is only set for system Images. |
| `osFlavor` | [`OsFlavor`](../../doc/models/os-flavor.md) | Required | Flavor of operating system contained in the Image |
| `osVersion` | `string \| null` | Required | Operating system version |
| `protection` | [`Protection`](../../doc/models/protection.md) | Required | Protection configuration for the Resource |
| `rapidDeploy` | `boolean \| undefined` | Optional | Indicates that rapid deploy of the Image is available |
| `status` | [`Status24`](../../doc/models/status-24.md) | Required | Whether the Image can be used or if it's still being created or unavailable |
| `type` | [`Type22`](../../doc/models/type-22.md) | Required | Type of the Image |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Image, OsFlavor, Status24, Type22 } from 'hetzner-cloud-apilib';

const image: Image = {
  boundTo: null,
  created: '2016-01-30T23:55:00+00:00',
  createdFrom: {
    id: 1,
    name: 'Server',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  deleted: null,
  deprecated: '2018-02-28T00:00:00+00:00',
  description: 'Ubuntu 20.04 Standard 64 bit',
  diskSize: 10,
  id: 42,
  imageSize: 2.3,
  labels: {
    'key0': 'labels4'
  },
  name: 'ubuntu-20.04',
  osFlavor: OsFlavor.Ubuntu,
  osVersion: '20.04',
  protection: {
    mDelete: false,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  status: Status24.Unavailable,
  type: Type22.Snapshot,
  rapidDeploy: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

