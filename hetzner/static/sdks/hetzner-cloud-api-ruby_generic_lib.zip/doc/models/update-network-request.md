
# Update Network Request

## Structure

`UpdateNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New network name |

## Example

```ruby
update_network_request = UpdateNetworkRequest.new(
  Labels2.new(
    'labelkey4'
  ),
  'new-name'
)
```

