
# X Amz Target 33

## Enumeration

`XAmzTarget33`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATACATALOGS` |

## Example

```python
from amazonathena.models.x_amz_target_33 import XAmzTarget33

x_amz_target_33 = XAmzTarget33.ENUM_AMAZONATHENALISTDATACATALOGS
```

