
# X Amz Target 53

## Enumeration

`XAmzTarget53`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUNTAGRESOURCE` |

## Example

```python
from amazonathena.models.x_amz_target_53 import XAmzTarget53

x_amz_target_53 = XAmzTarget53.ENUM_AMAZONATHENAUNTAGRESOURCE
```

