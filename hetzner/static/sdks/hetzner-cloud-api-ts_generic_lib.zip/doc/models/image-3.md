
# Image 3

The cost of Image per GB/month

## Structure

`Image3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pricePerGbMonth` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - |

## Example

```ts
import { Image3 } from 'hetzner-cloud-apilib';

const image3: Image3 = {
  pricePerGbMonth: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
  },
};
```

