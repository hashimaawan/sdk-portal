
# Calculation Execution State Enum

## Enumeration

`CalculationExecutionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```java
import com.amazonaws.useast1.athena.models.CalculationExecutionStateEnum;

CalculationExecutionStateEnum calculationExecutionState = CalculationExecutionStateEnum.COMPLETED;
```

