
# V2 Functions Namespaces Response 1

*This model accepts additional fields of type Object.*

## Structure

`V2FunctionsNamespacesResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Namespace` | [`Namespace`](../../doc/models/namespace.md) | Optional | - | Namespace getNamespace() | setNamespace(Namespace namespace) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Namespace;
import com.digitalocean.api.models.V2FunctionsNamespacesResponse1;
import java.io.IOException;

V2FunctionsNamespacesResponse1 v2FunctionsNamespacesResponse1 = new V2FunctionsNamespacesResponse1.Builder()
    .namespace(new Namespace.Builder()
        .apiHost("api_host2")
        .createdAt("created_at0")
        .key("key2")
        .label("label2")
        .namespace("namespace0")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

