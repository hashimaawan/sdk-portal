
# Type Enum

Type of the Certificate

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```java
import cloud.hetzner.api.models.TypeEnum;

TypeEnum type = TypeEnum.UPLOADED;
```

