
# Datum

A piece of data (a field in the table).

## Structure

`Datum`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `var_char_value` | `String` | Optional | - |

## Example

```ruby
datum = Datum.new(
  'VarCharValue8'
)
```

