
# Getting Started with 1Password Connect

## Introduction

REST API interface for 1Password Connect.

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the m1PasswordConnect library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace m1PasswordConnect => ".\\1password-connect-go_generic_lib" // local path to the SDK

require m1PasswordConnect v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](doc/auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```go
package main

import (
    "m1PasswordConnect"
)

func main() {
    client := m1PasswordConnect.NewClient(
    m1PasswordConnect.CreateConfiguration(
            m1PasswordConnect.WithHttpConfiguration(
                m1PasswordConnect.CreateHttpConfiguration(
                    m1PasswordConnect.WithTimeout(30),
                ),
            ),
            m1PasswordConnect.WithEnvironment(m1PasswordConnect.PRODUCTION),
            m1PasswordConnect.WithBearerAuthCredentials(
                m1PasswordConnect.NewBearerAuthCredentials("AccessToken"),
            ),
            m1PasswordConnect.WithLoggerConfiguration(
                m1PasswordConnect.WithLevel("info"),
                m1PasswordConnect.WithRequestConfiguration(
                    m1PasswordConnect.WithRequestBody(true),
                ),
                m1PasswordConnect.WithResponseConfiguration(
                    m1PasswordConnect.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| Production | **Default** |
| Environment2 | - |
| Environment3 | - |

## Authorization

This API uses the following authentication schemes.

* [`ConnectToken (OAuth 2 Bearer token)`](doc/auth/oauth-2-bearer-token.md)

## List of APIs

* [Items](doc/controllers/items.md)
* [Vaults](doc/controllers/vaults.md)
* [Activity](doc/controllers/activity.md)
* [Health](doc/controllers/health.md)
* [Metrics](doc/controllers/metrics.md)
* [Files](doc/controllers/files.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

