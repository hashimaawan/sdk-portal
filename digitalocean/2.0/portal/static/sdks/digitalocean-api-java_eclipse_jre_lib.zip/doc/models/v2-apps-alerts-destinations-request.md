
# V2 Apps Alerts Destinations Request

*This model accepts additional fields of type Object.*

## Structure

`V2AppsAlertsDestinationsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Emails` | `List<String>` | Optional | - | List<String> getEmails() | setEmails(List<String> emails) |
| `SlackWebhooks` | [`List<SlackWebhooksToSendAlertsTo>`](../../doc/models/slack-webhooks-to-send-alerts-to.md) | Optional | - | List<SlackWebhooksToSendAlertsTo> getSlackWebhooks() | setSlackWebhooks(List<SlackWebhooksToSendAlertsTo> slackWebhooks) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.SlackWebhooksToSendAlertsTo;
import com.digitalocean.api.models.V2AppsAlertsDestinationsRequest;
import java.io.IOException;
import java.util.Arrays;

V2AppsAlertsDestinationsRequest v2AppsAlertsDestinationsRequest = new V2AppsAlertsDestinationsRequest.Builder()
    .emails(Arrays.asList(
        "sammy@digitalocean.com"
    ))
    .slackWebhooks(Arrays.asList(
        new SlackWebhooksToSendAlertsTo.Builder()
            .channel("channel8")
            .url("url0")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

