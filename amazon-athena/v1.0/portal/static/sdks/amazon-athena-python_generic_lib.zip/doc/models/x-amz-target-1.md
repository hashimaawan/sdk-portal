
# X Amz Target 1

## Enumeration

`XAmzTarget1`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_1 import XAmzTarget1

x_amz_target_1 = XAmzTarget1.ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT
```

