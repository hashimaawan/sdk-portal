
# X Amz Target 29 Enum

## Enumeration

`XAmzTarget29Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETWORKGROUP` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget29 := models.XAmzTarget29Enum_ENUMAMAZONATHENAGETWORKGROUP

}
```

