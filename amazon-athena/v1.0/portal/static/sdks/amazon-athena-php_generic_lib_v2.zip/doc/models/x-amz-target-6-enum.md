
# X Amz Target 6 Enum

## Enumeration

`XAmzTarget6Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget6Enum;

$xAmzTarget6 = XAmzTarget6Enum::ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT;
```

