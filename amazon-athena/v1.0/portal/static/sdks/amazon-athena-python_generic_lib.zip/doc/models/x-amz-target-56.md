
# X Amz Target 56

## Enumeration

`XAmzTarget56`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_56 import XAmzTarget56

x_amz_target_56 = XAmzTarget56.ENUM_AMAZONATHENAUPDATENOTEBOOK
```

