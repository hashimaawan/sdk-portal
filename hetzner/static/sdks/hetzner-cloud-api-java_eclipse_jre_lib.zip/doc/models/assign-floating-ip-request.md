
# Assign Floating IP Request

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `floating_ip_assigned`        | The floating IP is already assigned                           |

## Structure

`AssignFloatingIPRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Server` | `int` | Required | ID of the Server the Floating IP shall be assigned to | int getServer() | setServer(int server) |

## Example

```java
import cloud.hetzner.api.models.AssignFloatingIPRequest;

AssignFloatingIPRequest assignFloatingIPRequest = new AssignFloatingIPRequest.Builder(
    42
)
.build();
```

