
# Stop Calculation Execution Response

*This model accepts additional fields of type Object.*

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `State` | [`CalculationExecutionState4`](../../doc/models/calculation-execution-state-4.md) | Optional | - | CalculationExecutionState4 getState() | setState(CalculationExecutionState4 state) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.models.CalculationExecutionState4;
import com.amazonaws.useast1.athena.models.StopCalculationExecutionResponse;
import java.io.IOException;

StopCalculationExecutionResponse stopCalculationExecutionResponse = new StopCalculationExecutionResponse.Builder()
    .state(CalculationExecutionState4.QUEUED)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

