
# V2 Firewalls Droplets Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2FirewallsDropletsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_ids` | `List[int]` | Required | An array containing the IDs of the Droplets to be removed from the firewall. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_firewalls_droplets_request import V2FirewallsDropletsRequest

v_2_firewalls_droplets_request = V2FirewallsDropletsRequest(
    droplet_ids=[
        49696269
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

