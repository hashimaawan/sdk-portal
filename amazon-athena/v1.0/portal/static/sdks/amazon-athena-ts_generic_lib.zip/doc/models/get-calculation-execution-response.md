
# Get Calculation Execution Response

*This model accepts additional fields of type unknown.*

## Structure

`GetCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `sessionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `workingDirectory` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(https\|s3\|S3)://([^/]+)/?(.*)$` |
| `status` | [`Status1 \| undefined`](../../doc/models/status-1.md) | Optional | - |
| `statistics` | [`Statistics1 \| undefined`](../../doc/models/statistics-1.md) | Optional | - |
| `result` | [`Result \| undefined`](../../doc/models/result.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  CalculationExecutionState1,
  GetCalculationExecutionResponse,
} from 'amazon-athenalib';

const getCalculationExecutionResponse: GetCalculationExecutionResponse = {
  calculationExecutionId: 'CalculationExecutionId4',
  sessionId: 'SessionId8',
  description: 'Description6',
  workingDirectory: 'WorkingDirectory8',
  status: {
    submissionDateTime: '2016-03-13T12:52:32.123Z',
    completionDateTime: '2016-03-13T12:52:32.123Z',
    state: CalculationExecutionState1.Canceling,
    stateChangeReason: 'StateChangeReason8',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

