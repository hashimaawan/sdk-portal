
# Locations Response 1

## Structure

`LocationsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `location` | [`Location`](../../doc/models/location.md) | Required | - | getLocation(): Location | setLocation(Location location): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LocationsResponse1Builder;
use HetznerCloudAPILib\Models\Builders\LocationBuilder;

$locationsResponse1 = LocationsResponse1Builder::init(
    LocationBuilder::init(
        'Falkenstein',
        'DE',
        'Falkenstein DC Park 1',
        1,
        50.47612,
        12.370071,
        'fsn1',
        'eu-central'
    )->build()
)->build();
```

