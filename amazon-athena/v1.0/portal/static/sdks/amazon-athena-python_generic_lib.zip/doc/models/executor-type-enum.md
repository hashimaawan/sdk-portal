
# Executor Type Enum

## Enumeration

`ExecutorTypeEnum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```python
from amazonathena.models.executor_type_enum import ExecutorTypeEnum

executor_type = ExecutorTypeEnum.WORKER
```

