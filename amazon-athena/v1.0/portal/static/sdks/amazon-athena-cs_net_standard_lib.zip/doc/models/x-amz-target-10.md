
# X Amz Target 10

## Enumeration

`XAmzTarget10`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteNamedQuery` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget10 xAmzTarget10 = XAmzTarget10.EnumAmazonAthenaDeleteNamedQuery;
```

