
# Parameter Status

## Enumeration

`ParameterStatus`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ERROR` |

## Example

```java
import cloud.hetzner.api.models.ParameterStatus;

ParameterStatus parameterStatus = ParameterStatus.ERROR;
```

