
# X Amz Target 49

## Enumeration

`XAmzTarget49`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStopCalculationExecution` |

## Example

```ts
import { XAmzTarget49 } from 'amazon-athenalib';

const xAmzTarget49 = XAmzTarget49.EnumAmazonAthenaStopCalculationExecution;
```

