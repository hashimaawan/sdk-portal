
# X Amz Target 18 Enum

## Enumeration

`XAmzTarget18Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATACATALOG` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget18Enum;

XAmzTarget18Enum xAmzTarget18 = XAmzTarget18Enum.ENUM_AMAZONATHENAGETDATACATALOG;
```

