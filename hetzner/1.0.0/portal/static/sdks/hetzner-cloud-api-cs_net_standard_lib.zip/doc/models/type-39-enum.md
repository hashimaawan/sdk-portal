
# Type 39 Enum

Algorithm of the Load Balancer

## Enumeration

`Type39Enum`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type39Enum type39 = Type39Enum.RoundRobin;
```

