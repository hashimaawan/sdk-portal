
# Result Reuse Configuration

Specifies the query result reuse behavior for the query.

## Structure

`ResultReuseConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resultReuseByAgeConfiguration` | [`ResultReuseByAgeConfiguration2 \| undefined`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |

## Example

```ts
import { ResultReuseConfiguration } from 'amazon-athenalib';

const resultReuseConfiguration: ResultReuseConfiguration = {
  resultReuseByAgeConfiguration: {
    enabled: false,
    maxAgeInMinutes: 26,
  },
};
```

