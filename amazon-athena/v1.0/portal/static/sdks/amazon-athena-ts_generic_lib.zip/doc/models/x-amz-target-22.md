
# X Amz Target 22

## Enumeration

`XAmzTarget22`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetPreparedStatement` |

## Example

```ts
import { XAmzTarget22 } from 'amazon-athenalib';

const xAmzTarget22 = XAmzTarget22.EnumAmazonAthenaGetPreparedStatement;
```

