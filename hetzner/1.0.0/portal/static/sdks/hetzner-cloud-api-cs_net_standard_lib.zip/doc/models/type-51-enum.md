
# Type 51 Enum

Primary IP type

## Enumeration

`Type51Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type51Enum type51 = Type51Enum.Ipv4;
```

