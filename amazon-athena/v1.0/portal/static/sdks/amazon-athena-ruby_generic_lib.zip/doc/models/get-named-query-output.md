
# Get Named Query Output

## Structure

`GetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query` | [`NamedQuery1`](../../doc/models/named-query-1.md) | Optional | - |

## Example

```ruby
get_named_query_output = GetNamedQueryOutput.new(
  NamedQuery1.new(
    'Name0',
    'Database8',
    'QueryString2',
    'Description6',
    'NamedQueryId2',
    'WorkGroup2'
  )
)
```

