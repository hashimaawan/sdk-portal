
# Create Presigned Notebook Url Response

*This model accepts additional fields of type array.*

## Structure

`CreatePresignedNotebookUrlResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notebookUrl` | `string` | Required | - | getNotebookUrl(): string | setNotebookUrl(string notebookUrl): void |
| `authToken` | `string` | Required | **Constraints**: *Maximum Length*: `2048` | getAuthToken(): string | setAuthToken(string authToken): void |
| `authTokenExpirationTime` | `int` | Required | - | getAuthTokenExpirationTime(): int | setAuthTokenExpirationTime(int authTokenExpirationTime): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\CreatePresignedNotebookUrlResponseBuilder;
use AmazonAthenaLib\ApiHelper;

$createPresignedNotebookUrlResponse = CreatePresignedNotebookUrlResponseBuilder::init(
    'NotebookUrl0',
    'AuthToken4',
    240
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

