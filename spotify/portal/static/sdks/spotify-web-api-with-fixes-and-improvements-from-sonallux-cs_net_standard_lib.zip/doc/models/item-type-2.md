
# Item Type 2

The ID type.

## Enumeration

`ItemType2`

## Fields

| Name |
|  --- |
| `Artist` |
| `User` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

ItemType2 itemType2 = ItemType2.Artist;
```

