
# Saved Album Object

*This model accepts additional fields of type Object.*

## Structure

`SavedAlbumObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `added_at` | `DateTime` | Optional | The date and time the album was saved<br>Timestamps are returned in ISO 8601 format as Coordinated Universal Time (UTC) with a zero offset: YYYY-MM-DDTHH:MM:SSZ.<br>If the time is imprecise (for example, the date/time of an album release), an additional field indicates the precision; see for example, release_date in an album object. |
| `album` | [`AlbumObject`](../../doc/models/album-object.md) | Optional | Information about the album. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
saved_album_object = SavedAlbumObject.new(
  added_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  album: AlbumObject.new(
    album_type: AlbumType::SINGLE,
    total_tracks: 170,
    available_markets: [
      'available_markets2',
      'available_markets3'
    ],
    external_urls: ExternalUrlObject.new(
      spotify: 'spotify6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    href: 'href0',
    id: 'id8',
    images: [
      ImageObject.new(
        url: 'url6',
        height: 182,
        width: 222,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    name: 'name8',
    release_date: 'release_date6',
    release_date_precision: ReleaseDatePrecision::DAY,
    type: 'type2',
    uri: 'uri2',
    artists: [
      SimplifiedArtistObject.new(
        external_urls: ExternalUrlObject.new(
          spotify: 'spotify6',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        href: 'href2',
        id: 'id0',
        name: 'name0',
        type: Type::ARTIST,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      SimplifiedArtistObject.new(
        external_urls: ExternalUrlObject.new(
          spotify: 'spotify6',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        href: 'href2',
        id: 'id0',
        name: 'name0',
        type: Type::ARTIST,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    tracks: PagingSimplifiedTrackObject.new(
      href: 'href6',
      limit: 142,
      mnext: 'next8',
      offset: 238,
      previous: 'previous2',
      total: 236,
      items: [
        SimplifiedTrackObject.new(
          artists: [
            SimplifiedArtistObject.new(
              external_urls: ExternalUrlObject.new(
                spotify: 'spotify6',
                additional_properties: {
                  'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
                }
              ),
              href: 'href2',
              id: 'id0',
              name: 'name0',
              type: Type::ARTIST,
              additional_properties: {
                'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
              }
            )
          ],
          available_markets: [
            'available_markets2'
          ],
          disc_number: 244,
          duration_ms: 52,
          explicit: false,
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    copyrights: [
      CopyrightObject.new(
        text: 'text2',
        type: 'type2',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      CopyrightObject.new(
        text: 'text2',
        type: 'type2',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    external_ids: ExternalIdObject.new(
      isrc: 'isrc8',
      ean: 'ean8',
      upc: 'upc2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    genres: [
      'genres5',
      'genres6',
      'genres7'
    ],
    label: 'label8',
    popularity: 78,
    restrictions: AlbumRestrictionObject.new(
      reason: Reason::EXPLICIT,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

