
# Load Balancers Actions Change Algorithm Request

*This model accepts additional fields of type array.*

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type39)`](../../doc/models/type-39.md) | Required | Algorithm of the Load Balancer | getType(): string | setType(string type): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\LoadBalancersActionsChangeAlgorithmRequestBuilder;
use HetznerCloudApiLib\Models\Type39;
use HetznerCloudApiLib\ApiHelper;

$loadBalancersActionsChangeAlgorithmRequest = LoadBalancersActionsChangeAlgorithmRequestBuilder::init(
    Type39::ROUND_ROBIN
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

