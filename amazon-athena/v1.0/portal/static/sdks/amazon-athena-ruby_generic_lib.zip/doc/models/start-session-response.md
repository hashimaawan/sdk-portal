
# Start Session Response

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `state` | [`SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```ruby
start_session_response = StartSessionResponse.new(
  'SessionId6',
  SessionState1Enum::DEGRADED
)
```

