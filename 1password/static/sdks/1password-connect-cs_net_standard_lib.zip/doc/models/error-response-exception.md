
# Error Response Exception

*This model accepts additional fields of type object.*

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MessageProperty` | `string` | Optional | A message detailing the error |
| `Status` | `int?` | Optional | HTTP Status Code |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
try
{
    // make the API call
}
catch (ApiException e)
{
    if (e is ErrorResponseException)
    {
        // TODO: Handle ErrorResponseException
        Console.WriteLine(e.Message);
    }
}
```

