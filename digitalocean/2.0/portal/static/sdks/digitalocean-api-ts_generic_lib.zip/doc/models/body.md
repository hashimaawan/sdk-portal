
# Body

Optional data to be sent to function while triggering the function.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Body`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Body } from 'digitalocean-apilib';

const body: Body = {
  name: 'Welcome to DO!',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

