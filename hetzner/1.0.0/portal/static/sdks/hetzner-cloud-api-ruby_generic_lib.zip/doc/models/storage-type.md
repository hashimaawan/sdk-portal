
# Storage Type

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageType`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `NETWORK` |

## Example

```ruby
storage_type = StorageType::LOCAL
```

