
# Query Execution Status

The completion date, current state, submission time, and state change reason (if applicable) for the query execution.

## Structure

`QueryExecutionStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `State` | [`QueryExecutionState1Enum?`](../../doc/models/query-execution-state-1-enum.md) | Optional | - |
| `StateChangeReason` | `string` | Optional | - |
| `SubmissionDateTime` | `DateTime?` | Optional | - |
| `CompletionDateTime` | `DateTime?` | Optional | - |
| `AthenaError` | [`AthenaError2`](../../doc/models/athena-error-2.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Globalization;

QueryExecutionStatus queryExecutionStatus = new QueryExecutionStatus
{
    State = QueryExecutionState1Enum.SUCCEEDED,
    StateChangeReason = "StateChangeReason0",
    SubmissionDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    CompletionDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    AthenaError = new AthenaError2
    {
        ErrorCategory = 3,
        ErrorType = 128,
        Retryable = false,
        ErrorMessage = "ErrorMessage8",
    },
};
```

