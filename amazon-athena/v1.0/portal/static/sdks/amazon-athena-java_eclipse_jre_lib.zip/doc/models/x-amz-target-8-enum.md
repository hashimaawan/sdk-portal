
# X Amz Target 8 Enum

## Enumeration

`XAmzTarget8Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEWORKGROUP` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget8Enum;

XAmzTarget8Enum xAmzTarget8 = XAmzTarget8Enum.ENUM_AMAZONATHENACREATEWORKGROUP;
```

