
# Overages

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Overages`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `String` | Optional | Total amount charged in USD |
| `name` | `String` | Optional | Name of the charge |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
overages = Overages.new(
  amount: '3.45',
  name: 'Overages',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

