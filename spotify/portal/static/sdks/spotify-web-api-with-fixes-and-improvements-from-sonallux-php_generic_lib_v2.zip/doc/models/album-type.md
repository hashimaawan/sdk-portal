
# Album Type

The type of the album.

## Enumeration

`AlbumType`

## Fields

| Name |
|  --- |
| `ALBUM` |
| `SINGLE` |
| `COMPILATION` |

## Example

```php
use SpotifyWebApiWithFixesAndImprovementsFromSonalluxLib\Models\AlbumType;

$albumType = AlbumType::COMPILATION;
```

