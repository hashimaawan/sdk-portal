
# Type

Type of the gif. By default, this is almost always gif

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `GIF` |

## Example

```php
use GiphyApiLib\Models\Type;

$type = Type::GIF;
```

