
# Sort 8

## Enumeration

`Sort8`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |

## Example

```ts
import { Sort8 } from 'hetzner-cloud-apilib';

const sort8 = Sort8.EnumNameasc;
```

