
# Type

Type of the Certificate

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```ts
import { Type } from 'hetzner-cloud-apilib';

const type = Type.Uploaded;
```

