
# Firewall 4

## Structure

`Firewall4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewall` | `Integer` | Optional | ID of the Firewall |

## Example

```ruby
firewall4 = Firewall4.new(
  176
)
```

