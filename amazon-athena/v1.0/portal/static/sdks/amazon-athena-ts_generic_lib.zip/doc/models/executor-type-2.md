
# Executor Type 2

The type of executor used for the application (<code>COORDINATOR</code>, <code>GATEWAY</code>, or <code>WORKER</code>).

## Enumeration

`ExecutorType2`

## Fields

| Name |
|  --- |
| `Coordinator` |
| `Gateway` |
| `Worker` |

## Example

```ts
import { ExecutorType2 } from 'amazon-athenalib';

const executorType2 = ExecutorType2.Coordinator;
```

