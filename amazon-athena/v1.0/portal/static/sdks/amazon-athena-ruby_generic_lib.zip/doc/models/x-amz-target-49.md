
# X Amz Target 49

## Enumeration

`XAmzTarget49`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```ruby
x_amz_target49 = XAmzTarget49::ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION
```

