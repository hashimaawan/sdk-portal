
# Status 7

A status string indicating the state of a custom image. This may be `NEW`,
`available`, `pending`, `deleted`, or `retired`.

## Enumeration

`Status7`

## Fields

| Name |
|  --- |
| `NEW` |
| `AVAILABLE` |
| `PENDING` |
| `DELETED` |
| `RETIRED` |

## Example

```python
from digitaloceanapi.models.status_7 import Status7

status_7 = Status7.DELETED
```

