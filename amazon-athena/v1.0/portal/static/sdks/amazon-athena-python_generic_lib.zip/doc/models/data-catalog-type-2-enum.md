
# Data Catalog Type 2 Enum

The data catalog type.

## Enumeration

`DataCatalogType2Enum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```python
from amazonathena.models.data_catalog_type_2_enum import DataCatalogType2Enum

data_catalog_type_2 = DataCatalogType2Enum.LAMBDA
```

