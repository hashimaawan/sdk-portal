
# Update Data Catalog Input

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Type` | [`DataCatalogType3Enum`](../../doc/models/data-catalog-type-3-enum.md) | Required | - |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

UpdateDataCatalogInput updateDataCatalogInput = new UpdateDataCatalogInput
{
    Name = "Name4",
    Type = DataCatalogType3Enum.GLUE,
    Description = "Description2",
    Parameters = new Parameters
    {
    },
};
```

