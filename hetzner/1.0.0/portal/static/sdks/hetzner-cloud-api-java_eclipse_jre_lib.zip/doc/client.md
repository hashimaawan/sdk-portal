
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| loggingConfig | [`Consumer<ApiLoggingConfiguration.Builder>`](../doc/api-logging-configuration-builder.md) | Set up Logging Configuration instance. |

The API client can be initialized as follows:

```java
import cloud.hetzner.api.HetznerCloudApiClient;
import cloud.hetzner.api.exceptions.ApiException;
import cloud.hetzner.api.http.response.ApiResponse;
import org.slf4j.event.Level;

public class Program {
    public static void main(String[] args) {
        HetznerCloudApiClient client = new HetznerCloudApiClient.Builder()
            .loggingConfig(builder -> builder
                    .level(Level.DEBUG)
                    .requestConfig(logConfigBuilder -> logConfigBuilder.body(true))
                    .responseConfig(logConfigBuilder -> logConfigBuilder.headers(true)))
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .build();

    }
}
```

## Hetzner Cloud APIClient Class

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

### Apis

| Name | Description | Return Type |
|  --- | --- | --- |
| `getActionsApi()` | Provides access to Actions controller. | `ActionsApi` |
| `getCertificatesApi()` | Provides access to Certificates controller. | `CertificatesApi` |
| `getCertificateActionsApi()` | Provides access to CertificateActions controller. | `CertificateActionsApi` |
| `getDatacentersApi()` | Provides access to Datacenters controller. | `DatacentersApi` |
| `getFirewallsApi()` | Provides access to Firewalls controller. | `FirewallsApi` |
| `getFirewallActionsApi()` | Provides access to FirewallActions controller. | `FirewallActionsApi` |
| `getFloatingIPsApi()` | Provides access to FloatingIPs controller. | `FloatingIPsApi` |
| `getFloatingIpActionsApi()` | Provides access to FloatingIpActions controller. | `FloatingIpActionsApi` |
| `getImagesApi()` | Provides access to Images controller. | `ImagesApi` |
| `getImageActionsApi()` | Provides access to ImageActions controller. | `ImageActionsApi` |
| `getIsOsApi()` | Provides access to IsOs controller. | `IsOsApi` |
| `getLoadBalancersApi()` | Provides access to LoadBalancers controller. | `LoadBalancersApi` |
| `getLoadBalancerActionsApi()` | Provides access to LoadBalancerActions controller. | `LoadBalancerActionsApi` |
| `getLoadBalancerTypesApi()` | Provides access to LoadBalancerTypes controller. | `LoadBalancerTypesApi` |
| `getLocationsApi()` | Provides access to Locations controller. | `LocationsApi` |
| `getPrimaryIPsApi()` | Provides access to PrimaryIPs controller. | `PrimaryIPsApi` |
| `getPrimaryIpActionsApi()` | Provides access to PrimaryIpActions controller. | `PrimaryIpActionsApi` |
| `getNetworksApi()` | Provides access to Networks controller. | `NetworksApi` |
| `getNetworkActionsApi()` | Provides access to NetworkActions controller. | `NetworkActionsApi` |
| `getPlacementGroupsApi()` | Provides access to PlacementGroups controller. | `PlacementGroupsApi` |
| `getPricingApi()` | Provides access to Pricing controller. | `PricingApi` |
| `getServersApi()` | Provides access to Servers controller. | `ServersApi` |
| `getServerActionsApi()` | Provides access to ServerActions controller. | `ServerActionsApi` |
| `getServerTypesApi()` | Provides access to ServerTypes controller. | `ServerTypesApi` |
| `getSshKeysApi()` | Provides access to SshKeys controller. | `SshKeysApi` |
| `getVolumesApi()` | Provides access to Volumes controller. | `VolumesApi` |
| `getVolumeActionsApi()` | Provides access to VolumeActions controller. | `VolumeActionsApi` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getLoggingConfig()` | Logging Configuration instance. | [`ReadonlyLoggingConfiguration`](../doc/api-logging-configuration.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

