
# A Criterion for Routing Http Traffic to a Component

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`ACriterionForRoutingHttpTrafficToAComponent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path` | `string \| undefined` | Optional | An HTTP path prefix. Paths must start with / and must be unique across all components within an app. |
| `preservePathPrefix` | `boolean \| undefined` | Optional | An optional flag to preserve the path that is forwarded to the backend service. By default, the HTTP request path will be trimmed from the left when forwarded to the component. For example, a component with `path=/api` will have requests to `/api/list` trimmed to `/list`. If this value is `true`, the path will remain `/api/list`. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  ACriterionForRoutingHttpTrafficToAComponent,
} from 'digitalocean-apilib';

const aCriterionForRoutingHttpTrafficToAComponent: ACriterionForRoutingHttpTrafficToAComponent = {
  path: '/api',
  preservePathPrefix: true,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

