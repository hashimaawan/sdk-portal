
# V21 Clicks Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V21ClicksResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `m_1_clicks` | [`Array[M1Click]`](../../doc/models/m1-click.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_1_clicks_response = V21ClicksResponse.new(
  m1_clicks: [
    M1Click.new(
      slug: 'slug8',
      type: 'type2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

