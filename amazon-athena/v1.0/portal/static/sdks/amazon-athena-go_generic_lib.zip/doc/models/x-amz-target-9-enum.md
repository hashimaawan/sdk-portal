
# X Amz Target 9 Enum

## Enumeration

`XAmzTarget9Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENADELETEDATACATALOG` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget9 := models.XAmzTarget9Enum_ENUMAMAZONATHENADELETEDATACATALOG

}
```

