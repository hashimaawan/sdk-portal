
# Status 24 Enum

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24Enum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |
| `UNAVAILABLE` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    status24 := models.Status24Enum_AVAILABLE

}
```

