
# Server Public Net Firewall

## Structure

`ServerPublicNetFirewall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | ID of the Resource |
| `Status` | [`Status72Enum?`](../../doc/models/status-72-enum.md) | Optional | Status of the Firewall on the Server |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ServerPublicNetFirewall serverPublicNetFirewall = new ServerPublicNetFirewall
{
    Id = 42,
    Status = Status72Enum.Applied,
};
```

