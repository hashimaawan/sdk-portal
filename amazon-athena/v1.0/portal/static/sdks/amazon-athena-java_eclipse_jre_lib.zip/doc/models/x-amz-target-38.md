
# X Amz Target 38

## Enumeration

`XAmzTarget38`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget38;

XAmzTarget38 xAmzTarget38 = XAmzTarget38.ENUM_AMAZONATHENALISTNOTEBOOKMETADATA;
```

