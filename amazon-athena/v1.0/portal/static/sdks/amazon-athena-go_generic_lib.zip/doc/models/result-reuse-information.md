
# Result Reuse Information

Contains information about whether the result of a previous query was reused.

## Structure

`ResultReuseInformation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReusedPreviousResult` | `bool` | Required | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    resultReuseInformation := models.ResultReuseInformation{
        ReusedPreviousResult: false,
    }

}
```

