
# Column Nullable 2 Enum

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2Enum`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```ruby
column_nullable2 = ColumnNullable2Enum::NULLABLE
```

