
# Change Protection Request

## Structure

`ChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `delete` | `?bool` | Optional | If true, prevents the Floating IP from being deleted | getDelete(): ?bool | setDelete(?bool delete): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ChangeProtectionRequestBuilder;

$changeProtectionRequest = ChangeProtectionRequestBuilder::init()
    ->delete(true)
    ->build();
```

