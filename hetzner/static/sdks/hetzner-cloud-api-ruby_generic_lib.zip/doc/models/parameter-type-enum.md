
# Parameter Type Enum

## Enumeration

`ParameterTypeEnum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```ruby
parameter_type = ParameterTypeEnum::UPLOADED
```

