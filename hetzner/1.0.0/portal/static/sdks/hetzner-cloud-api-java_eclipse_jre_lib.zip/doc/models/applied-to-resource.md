
# Applied to Resource

*This model accepts additional fields of type Object.*

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Server` | [`Server`](../../doc/models/server.md) | Optional | - | Server getServer() | setServer(Server server) |
| `Type` | [`Type5`](../../doc/models/type-5.md) | Optional | Type of resource referenced | Type5 getType() | setType(Type5 type) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.AppliedToResource;
import cloud.hetzner.api.models.Server;
import cloud.hetzner.api.models.Type5;
import java.io.IOException;

AppliedToResource appliedToResource = new AppliedToResource.Builder()
    .server(new Server.Builder(
        14
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
    .type(Type5.SERVER)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

