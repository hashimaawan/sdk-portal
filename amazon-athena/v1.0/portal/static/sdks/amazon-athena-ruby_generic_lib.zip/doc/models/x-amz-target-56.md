
# X Amz Target 56

## Enumeration

`XAmzTarget56`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOK` |

## Example

```ruby
x_amz_target56 = XAmzTarget56::ENUM_AMAZONATHENAUPDATENOTEBOOK
```

