
# Tier

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Tier`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `buildSeconds` | `string \| undefined` | Optional | - |
| `egressBandwidthBytes` | `string \| undefined` | Optional | - |
| `name` | `string \| undefined` | Optional | - |
| `slug` | `string \| undefined` | Optional | - |
| `storageBytes` | `string \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Tier } from 'digitalocean-apilib';

const tier: Tier = {
  buildSeconds: '233',
  egressBandwidthBytes: '123',
  name: 'test',
  slug: 'test',
  storageBytes: '10000000',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

