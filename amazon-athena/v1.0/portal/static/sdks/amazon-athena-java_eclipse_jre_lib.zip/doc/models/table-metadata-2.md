
# Table Metadata 2

## Structure

`TableMetadata2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | String getName() | setName(String name) |
| `CreateTime` | `LocalDateTime` | Optional | - | LocalDateTime getCreateTime() | setCreateTime(LocalDateTime createTime) |
| `LastAccessTime` | `LocalDateTime` | Optional | - | LocalDateTime getLastAccessTime() | setLastAccessTime(LocalDateTime lastAccessTime) |
| `TableType` | `String` | Optional | **Constraints**: *Maximum Length*: `255` | String getTableType() | setTableType(String tableType) |
| `Columns` | [`List<Column>`](../../doc/models/column.md) | Optional | - | List<Column> getColumns() | setColumns(List<Column> columns) |
| `PartitionKeys` | [`List<Column>`](../../doc/models/column.md) | Optional | - | List<Column> getPartitionKeys() | setPartitionKeys(List<Column> partitionKeys) |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - | Parameters getParameters() | setParameters(Parameters parameters) |

## Example

```java
import com.amazonaws.useast1.athena.DateTimeHelper;
import com.amazonaws.useast1.athena.models.Column;
import com.amazonaws.useast1.athena.models.TableMetadata2;
import java.util.Arrays;

TableMetadata2 tableMetadata2 = new TableMetadata2.Builder(
    "Name8"
)
.createTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
.lastAccessTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
.tableType("TableType6")
.columns(Arrays.asList(
        new Column.Builder(
            "Name0"
        )
        .type("Type0")
        .comment("Comment4")
        .build(),
        new Column.Builder(
            "Name0"
        )
        .type("Type0")
        .comment("Comment4")
        .build()
    ))
.partitionKeys(Arrays.asList(
        new Column.Builder(
            "Name6"
        )
        .type("Type6")
        .comment("Comment0")
        .build(),
        new Column.Builder(
            "Name6"
        )
        .type("Type6")
        .comment("Comment0")
        .build()
    ))
.build();
```

