
# V21 Clicks Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V21ClicksResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `m1Clicks` | [`M1Click[] \| undefined`](../../doc/models/m1-click.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V21ClicksResponse } from 'digitalocean-apilib';

const v21ClicksResponse: V21ClicksResponse = {
  m1Clicks: [
    {
      slug: 'slug8',
      type: 'type2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      slug: 'slug8',
      type: 'type2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

