
# Type 66

## Enumeration

`Type66`

## Fields

| Name |
|  --- |
| `Cpu` |
| `Disk` |
| `Network` |

## Example

```ts
import { Type66 } from 'hetzner-cloud-apilib';

const type66 = Type66.Network;
```

