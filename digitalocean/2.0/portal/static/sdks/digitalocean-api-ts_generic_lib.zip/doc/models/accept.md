
# Accept

## Enumeration

`Accept`

## Fields

| Name |
|  --- |
| `EnumApplicationjson` |
| `EnumApplicationyaml` |

## Example

```ts
import { Accept } from 'digitalocean-apilib';

const accept = Accept.EnumApplicationjson;
```

