
# Oauth Scope Furkot Auth Access Code

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthAccessCode`

## Fields

| Name | Description |
|  --- | --- |
| `Readtrips` | list trips and stops info |

## Example

```go
package main

import (
    "furkotTrips/models"
)

func main() {
    oauthScopeFurkotAuthAccessCode := models.OauthScopeFurkotAuthAccessCode_Readtrips

}
```

