
# Type 66

## Enumeration

`Type66`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```python
from hetznercloudapi.models.type_66 import Type66

type_66 = Type66.DISK
```

