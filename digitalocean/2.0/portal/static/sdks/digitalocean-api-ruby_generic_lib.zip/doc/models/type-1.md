
# Type 1

- DEFAULT: The default `.ondigitalocean.app` domain assigned to this app
- PRIMARY: The primary domain for this app that is displayed as the default in the control panel, used in bindable environment variables, and any other places that reference an app's live URL. Only one domain may be set as primary.
- ALIAS: A non-primary domain

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `DEFAULT` |
| `PRIMARY` |
| `ALIAS` |

## Example

```ruby
type1 = Type1::PRIMARY
```

