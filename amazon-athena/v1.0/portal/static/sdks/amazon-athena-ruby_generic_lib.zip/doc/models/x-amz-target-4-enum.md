
# X Amz Target 4 Enum

## Enumeration

`XAmzTarget4Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENAMEDQUERY` |

## Example

```ruby
x_amz_target4 = XAmzTarget4Enum::ENUM_AMAZONATHENACREATENAMEDQUERY
```

