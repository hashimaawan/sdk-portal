
# Custom Header Signature



Documentation for accessing and setting credentials for hmac.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| Authorization | `String` | Amazon Signature authorization v4 | `authorization` |



**Note:** Auth credentials can be set using named parameter for any of the above credentials (e.g. `authorization`) in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```ruby
require 'amazon_athena'
include AmazonAthena

client = Client.new(
  custom_header_authentication_credentials: CustomHeaderAuthenticationCredentials.new(
    authorization: 'Authorization'
  )
)
```


