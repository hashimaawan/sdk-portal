
# Statistics 3

## Structure

`Statistics3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DpuExecutionInMillis` | `Integer` | Optional | - | Integer getDpuExecutionInMillis() | setDpuExecutionInMillis(Integer dpuExecutionInMillis) |

## Example

```java
import com.amazonaws.useast1.athena.models.Statistics3;

Statistics3 statistics3 = new Statistics3.Builder()
    .dpuExecutionInMillis(130)
    .build();
```

