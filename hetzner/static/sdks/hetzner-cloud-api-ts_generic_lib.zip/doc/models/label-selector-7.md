
# Label Selector 7

Label selector and a list of selected targets

## Structure

`LabelSelector7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector |

## Example

```ts
import { LabelSelector7 } from 'hetzner-cloud-apilib';

const labelSelector7: LabelSelector7 = {
  selector: 'env=prod',
};
```

