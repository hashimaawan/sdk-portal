
# Servers Actions Rebuild Response

## Structure

`ServersActionsRebuildResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Action` | [`Action`](../../doc/models/action.md) | Optional | - | Action getAction() | setAction(Action action) |
| `RootPassword` | `String` | Optional | New root password when not using SSH keys | String getRootPassword() | setRootPassword(String rootPassword) |

## Example

```java
import cloud.hetzner.api.models.Action;
import cloud.hetzner.api.models.Error;
import cloud.hetzner.api.models.Resource;
import cloud.hetzner.api.models.ServersActionsRebuildResponse;
import cloud.hetzner.api.models.StatusEnum;
import java.util.Arrays;

ServersActionsRebuildResponse serversActionsRebuildResponse = new ServersActionsRebuildResponse.Builder()
    .action(new Action.Builder(
        "command6",
        new Error.Builder(
            "code2",
            "message4"
        )
        .build(),
        "finished0",
        238,
        143.26D,
        Arrays.asList(
            new Resource.Builder(
                198,
                "type0"
            )
            .build(),
            new Resource.Builder(
                198,
                "type0"
            )
            .build(),
            new Resource.Builder(
                198,
                "type0"
            )
            .build()
        ),
        "started8",
        StatusEnum.RUNNING
    )
    .build())
    .rootPassword("root_password6")
    .build();
```

