
# Calculation Execution State

## Enumeration

`CalculationExecutionState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```ruby
calculation_execution_state = CalculationExecutionState::CANCELING
```

