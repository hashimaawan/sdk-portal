
# X Amz Target 52 Enum

## Enumeration

`XAmzTarget52Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaTerminateSession` |

## Example

```ts
import { XAmzTarget52Enum } from 'amazon-athenalib';

const xAmzTarget52 = XAmzTarget52Enum.EnumAmazonAthenaTerminateSession;
```

