
# Images Actions Change Protection Request

*This model accepts additional fields of type array.*

## Structure

`ImagesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `delete` | `?bool` | Optional | If true, prevents the snapshot from being deleted | getDelete(): ?bool | setDelete(?bool delete): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\ImagesActionsChangeProtectionRequestBuilder;
use HetznerCloudApiLib\ApiHelper;

$imagesActionsChangeProtectionRequest = ImagesActionsChangeProtectionRequestBuilder::init()
    ->delete(true)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

