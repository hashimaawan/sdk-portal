
# V2 Databases Dbs Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesDbsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `db` | [`Db`](../../doc/models/db.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2DatabasesDbsResponse1 } from 'digitalocean-apilib';

const v2DatabasesDbsResponse1: V2DatabasesDbsResponse1 = {
  db: {
    name: 'alpha',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

