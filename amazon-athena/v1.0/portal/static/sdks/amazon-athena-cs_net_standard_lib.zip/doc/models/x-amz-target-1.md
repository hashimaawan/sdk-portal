
# X Amz Target 1

## Enumeration

`XAmzTarget1`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetPreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget1 xAmzTarget1 = XAmzTarget1.EnumAmazonAthenaBatchGetPreparedStatement;
```

