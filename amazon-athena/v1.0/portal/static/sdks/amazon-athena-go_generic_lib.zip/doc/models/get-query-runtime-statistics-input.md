
# Get Query Runtime Statistics Input

*This model accepts additional fields of type interface{}.*

## Structure

`GetQueryRuntimeStatisticsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    getQueryRuntimeStatisticsInput := models.GetQueryRuntimeStatisticsInput{
        QueryExecutionId:      "QueryExecutionId0",
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

