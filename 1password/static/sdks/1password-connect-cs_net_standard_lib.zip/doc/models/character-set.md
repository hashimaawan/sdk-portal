
# Character Set

## Enumeration

`CharacterSet`

## Fields

| Name |
|  --- |
| `Letters` |
| `Digits` |
| `Symbols` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

CharacterSet characterSet = CharacterSet.Digits;
```

