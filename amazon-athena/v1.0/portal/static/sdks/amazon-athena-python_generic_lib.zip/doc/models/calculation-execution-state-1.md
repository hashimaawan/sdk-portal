
# Calculation Execution State 1

<p>The state of the calculation execution. A description of each state follows.</p> <p> <code>CREATING</code> - The calculation is in the process of being created.</p> <p> <code>CREATED</code> - The calculation has been created and is ready to run.</p> <p> <code>QUEUED</code> - The calculation has been queued for processing.</p> <p> <code>RUNNING</code> - The calculation is running.</p> <p> <code>CANCELING</code> - A request to cancel the calculation has been received and the system is working to stop it.</p> <p> <code>CANCELED</code> - The calculation is no longer running as the result of a cancel request.</p> <p> <code>COMPLETED</code> - The calculation has completed without error.</p> <p> <code>FAILED</code> - The calculation failed and is no longer running.</p>


## Enumeration

`CalculationExecutionState1`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```python
from amazonathena.models.calculation_execution_state_1 import CalculationExecutionState1

calculation_execution_state_1 = CalculationExecutionState1.CREATING
```

