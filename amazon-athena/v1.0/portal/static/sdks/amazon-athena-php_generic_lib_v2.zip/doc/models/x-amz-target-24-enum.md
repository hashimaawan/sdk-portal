
# X Amz Target 24 Enum

## Enumeration

`XAmzTarget24Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRESULTS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget24Enum;

$xAmzTarget24 = XAmzTarget24Enum::ENUM_AMAZONATHENAGETQUERYRESULTS;
```

