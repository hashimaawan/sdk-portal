
# Sort 8 Enum

## Enumeration

`Sort8Enum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `NAME` |
| `ENUM_NAMEASC` |
| `ENUM_NAMEDESC` |

## Example

```php
use HetznerCloudAPILib\Models\Sort8Enum;

$sort8 = Sort8Enum::ENUM_NAMEASC;
```

