
# X Amz Target 51 Enum

## Enumeration

`XAmzTarget51Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaTagResource` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget51Enum xAmzTarget51 = XAmzTarget51Enum.EnumAmazonAthenaTagResource;
```

