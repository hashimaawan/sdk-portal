
# Calculation Status

Contains information about the status of a notebook calculation.

## Structure

`CalculationStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `submissionDateTime` | `string \| undefined` | Optional | - |
| `completionDateTime` | `string \| undefined` | Optional | - |
| `state` | [`CalculationExecutionState1Enum \| undefined`](../../doc/models/calculation-execution-state-1-enum.md) | Optional | - |
| `stateChangeReason` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import {
  CalculationExecutionState1Enum,
  CalculationStatus,
} from 'amazon-athenalib';

const calculationStatus: CalculationStatus = {
  submissionDateTime: '2016-03-13T12:52:32.123Z',
  completionDateTime: '2016-03-13T12:52:32.123Z',
  state: CalculationExecutionState1Enum.CREATING,
  stateChangeReason: 'StateChangeReason2',
};
```

