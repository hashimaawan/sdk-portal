
# X Amz Target 13

## Enumeration

`XAmzTarget13`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEWORKGROUP` |

## Example

```python
from amazonathena.models.x_amz_target_13 import XAmzTarget13

x_amz_target_13 = XAmzTarget13.ENUM_AMAZONATHENADELETEWORKGROUP
```

