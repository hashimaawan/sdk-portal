
# Price Monthly 8

Monthly costs for a Load Balancer type in this network zone

## Structure

`PriceMonthly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    priceMonthly8 := models.PriceMonthly8{
        Gross:                "1.1900000000000000",
        Net:                  "1.0000000000",
    }

}
```

