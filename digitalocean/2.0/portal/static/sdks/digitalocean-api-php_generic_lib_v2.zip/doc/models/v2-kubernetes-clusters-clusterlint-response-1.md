
# V2 Kubernetes Clusters Clusterlint Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersClusterlintResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `runId` | `?string` | Optional | ID of the clusterlint run that can be used later to fetch the diagnostics. | getRunId(): ?string | setRunId(?string runId): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2KubernetesClustersClusterlintResponse1Builder;
use DigitalOceanApiLib\ApiHelper;

$v2KubernetesClustersClusterlintResponse1 = V2KubernetesClustersClusterlintResponse1Builder::init()
    ->runId('50c2f44c-011d-493e-aee5-361a4a0d1844')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

