
# X Amz Target 24

## Enumeration

`XAmzTarget24`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetqueryresults` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget24 := models.XAmzTarget24_EnumAmazonathenagetqueryresults

}
```

