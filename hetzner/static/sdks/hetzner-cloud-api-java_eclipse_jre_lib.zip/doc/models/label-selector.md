
# Label Selector

## Structure

`LabelSelector`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Selector` | `String` | Required | Label selector | String getSelector() | setSelector(String selector) |

## Example

```java
import cloud.hetzner.api.models.LabelSelector;

LabelSelector labelSelector = new LabelSelector.Builder(
    "env=prod"
)
.build();
```

