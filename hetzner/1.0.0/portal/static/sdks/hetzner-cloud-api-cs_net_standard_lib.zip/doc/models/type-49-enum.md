
# Type 49 Enum

The type of the Primary IP

## Enumeration

`Type49Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type49Enum type49 = Type49Enum.Ipv4;
```

