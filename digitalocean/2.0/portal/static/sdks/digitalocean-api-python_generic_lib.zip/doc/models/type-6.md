
# Type 6

Type of billing history entry.

## Enumeration

`Type6`

## Fields

| Name |
|  --- |
| `ACHFAILURE` |
| `ADJUSTMENT` |
| `ATTEMPTFAILED` |
| `CHARGEBACK` |
| `CREDIT` |
| `CREDITEXPIRATION` |
| `INVOICE` |
| `PAYMENT` |
| `REFUND` |
| `REVERSAL` |

## Example

```python
from digitaloceanapi.models.type_6 import Type6

type_6 = Type6.CREDIT
```

