
# X Amz Target 51

## Enumeration

`XAmzTarget51`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATAGRESOURCE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget51;

XAmzTarget51 xAmzTarget51 = XAmzTarget51.ENUM_AMAZONATHENATAGRESOURCE;
```

