# Droplet Actions

```ts
const dropletActionsApi = new DropletActionsApi(client);
```

## Class Name

`DropletActionsApi`

## Methods

* [Droplet Actions Post by Tag](../../doc/controllers/droplet-actions.md#droplet-actions-post-by-tag)
* [Droplet Actions List](../../doc/controllers/droplet-actions.md#droplet-actions-list)
* [Droplet Actions Post](../../doc/controllers/droplet-actions.md#droplet-actions-post)
* [Droplet Actions Get](../../doc/controllers/droplet-actions.md#droplet-actions-get)


# Droplet Actions Post by Tag

Some actions can be performed in bulk on tagged Droplets. The actions can be
initiated by sending a POST to `/v2/droplets/actions?tag_name=$TAG_NAME` with
the action arguments.

Only a sub-set of action types are supported:

- `power_cycle`
- `power_on`
- `power_off`
- `shutdown`
- `enable_ipv6`
- `enable_backups`
- `disable_backups`
- `snapshot`

```ts
async dropletActionsPostByTag(
  tagName?: string,
  body?: DropletActionsPostByTagBody,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2DropletsActionsResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tagName` | `string \| undefined` | Query, Optional | Used to filter Droplets by a specific tag. Can not be combined with `name`. |
| `body` | [`DropletActionsPostByTagBody \| undefined`](../../doc/models/containers/droplet-actions-post-by-tag-body.md) | Body, Optional | This is a container for one-of cases. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The response will be a JSON object with a key called `actions`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2DropletsActionsResponse`](../../doc/models/v2-droplets-actions-response.md).

## Example Usage

```ts
const tagName = 'env:prod';

const body: DropletActionsPostByTagBody = {
  type: Type12.Reboot,
};

try {
  const response = await dropletActionsApi.dropletActionsPostByTag(
    tagName,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Droplet Actions List

To retrieve a list of all actions that have been executed for a Droplet, send
a GET request to `/v2/droplets/$DROPLET_ID/actions`.

The results will be returned as a JSON object with an `actions` key. This will
be set to an array filled with `action` objects containing the standard
`action` attributes.

```ts
async dropletActionsList(
  dropletId: number,
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2DropletsActionsResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletId` | `number` | Template, Required | A unique identifier for a Droplet instance.<br><br>**Constraints**: `>= 1` |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: A JSON object with an `actions` key.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2DropletsActionsResponse1`](../../doc/models/v2-droplets-actions-response-1.md).

## Example Usage

```ts
const dropletId = 3164444;

const perPage = 2;

const page = 1;

try {
  const response = await dropletActionsApi.dropletActionsList(
    dropletId,
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "completed_at": "2020-07-20T19:37:45Z",
      "id": 982864273,
      "region": {
        "available": true,
        "features": [
          "private_networking",
          "backups",
          "ipv6",
          "metadata",
          "install_agent",
          "image_transfer"
        ],
        "name": "New York 3",
        "sizes": [
          "s-1vcpu-1gb",
          "s-1vcpu-2gb",
          "s-3vcpu-1gb",
          "s-2vcpu-2gb",
          "s-1vcpu-3gb",
          "s-2vcpu-4gb",
          "s-4vcpu-8gb",
          "m-1vcpu-8gb",
          "s-6vcpu-16gb",
          "s-8vcpu-32gb",
          "s-12vcpu-48gb"
        ],
        "slug": "nyc3"
      },
      "region_slug": "nyc3",
      "resource_id": 3164444,
      "resource_type": "droplet",
      "started_at": "2020-07-20T19:37:30Z",
      "status": "completed",
      "type": "create"
    }
  ],
  "links": {},
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Droplet Actions Post

To initiate an action on a Droplet send a POST request to
`/v2/droplets/$DROPLET_ID/actions`. In the JSON body to the request,
set the `type` attribute to on of the supported action types:

| Action                                   | Details |
| ---------------------------------------- | ----------- |
| <nobr>`enable_backups`</nobr>            | Enables backups for a Droplet |
| <nobr>`disable_backups`</nobr>           | Disables backups for a Droplet |
| <nobr>`reboot`</nobr>                    | Reboots a Droplet. A `reboot` action is an attempt to reboot the Droplet in a graceful way, similar to using the `reboot` command from the console. |
| <nobr>`power_cycle`</nobr>               | Power cycles a Droplet. A `powercycle` action is similar to pushing the reset button on a physical machine, it's similar to booting from scratch. |
| <nobr>`shutdown`</nobr>                  | Shutsdown a Droplet. A shutdown action is an attempt to shutdown the Droplet in a graceful way, similar to using the `shutdown` command from the console. Since a `shutdown` command can fail, this action guarantees that the command is issued, not that it succeeds. The preferred way to turn off a Droplet is to attempt a shutdown, with a reasonable timeout, followed by a `power_off` action to ensure the Droplet is off. |
| <nobr>`power_off`</nobr>                 | Powers off a Droplet. A `power_off` event is a hard shutdown and should only be used if the `shutdown` action is not successful. It is similar to cutting the power on a server and could lead to complications. |
| <nobr>`power_on`</nobr>                  | Powers on a Droplet. |
| <nobr>`restore`</nobr>                   | Restore a Droplet using a backup image. The image ID that is passed in must be a backup of the current Droplet instance. The operation will leave any embedded SSH keys intact. |
| <nobr>`password_reset`</nobr>            | Resets the root password for a Droplet. A new password will be provided via email. It must be changed after first use. |
| <nobr>`resize`</nobr>                    | Resizes a Droplet. Set the `size` attribute to a size slug. If a permanent resize with disk changes included is desired, set the `disk` attribute to `true`. |
| <nobr>`rebuild`</nobr>                   | Rebuilds a Droplet from a new base image. Set the `image` attribute to an image ID or slug. |
| <nobr>`rename`</nobr>                    | Renames a Droplet. |
| <nobr>`change_kernel`</nobr>             | Changes a Droplet's kernel. Only applies to Droplets with externally managed kernels. All Droplets created after March 2017 use internal kernels by default. |
| <nobr>`enable_ipv6`</nobr>               | Enables IPv6 for a Droplet. |
| <nobr>`snapshot`</nobr>                  | Takes a snapshot of a Droplet. |

```ts
async dropletActionsPost(
  dropletId: number,
  body?: DropletActionsPostBody,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2DropletsActionsResponse2>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletId` | `number` | Template, Required | A unique identifier for a Droplet instance.<br><br>**Constraints**: `>= 1` |
| `body` | [`DropletActionsPostBody \| undefined`](../../doc/models/containers/droplet-actions-post-body.md) | Body, Optional | This is a container for any-of cases. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The response will be a JSON object with a key called `action`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2DropletsActionsResponse2`](../../doc/models/v2-droplets-actions-response-2.md).

## Example Usage

```ts
const dropletId = 3164444;

const body: DropletActionsPostBody = {
  type: Type12.Reboot,
};

try {
  const response = await dropletActionsApi.dropletActionsPost(
    dropletId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Droplet Actions Get

To retrieve a Droplet action, send a GET request to
`/v2/droplets/$DROPLET_ID/actions/$ACTION_ID`.

The response will be a JSON object with a key called `action`. The value will
be a Droplet action object.

```ts
async dropletActionsGet(
  dropletId: number,
  actionId: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2ActionsResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletId` | `number` | Template, Required | A unique identifier for a Droplet instance.<br><br>**Constraints**: `>= 1` |
| `actionId` | `number` | Template, Required | A unique numeric ID that can be used to identify and reference an action.<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The result will be a JSON object with an action key.  This will be set to an action object containing the standard action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2ActionsResponse1`](../../doc/models/v2-actions-response-1.md).

## Example Usage

```ts
const dropletId = 3164444;

const actionId = 36804636;

try {
  const response = await dropletActionsApi.dropletActionsGet(
    dropletId,
    actionId
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |

