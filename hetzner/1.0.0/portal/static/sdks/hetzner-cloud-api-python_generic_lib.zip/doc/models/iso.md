
# Iso

*This model accepts additional fields of type Any.*

## Structure

`Iso`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deprecated` | `str` | Required | ISO 8601 timestamp of deprecation, null if ISO is still available. After the deprecation time it will no longer be possible to attach the ISO to Servers. |
| `description` | `str` | Required | Description of the ISO |
| `id` | `int` | Required | ID of the Resource |
| `name` | `str` | Required | Unique identifier of the ISO. Only set for public ISOs |
| `mtype` | [`Type26`](../../doc/models/type-26.md) | Required | Type of the ISO |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.iso import Iso
from hetznercloudapi.models.type_26 import Type26

iso = Iso(
    deprecated='2018-02-28T00:00:00+00:00',
    description='FreeBSD 11.0 x64',
    id=42,
    name='FreeBSD-11.0-RELEASE-amd64-dvd1',
    mtype=Type26.PUBLIC,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

