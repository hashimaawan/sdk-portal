
# Encryption Option

## Enumeration

`EncryptionOption`

## Fields

| Name |
|  --- |
| `SSE_S3` |
| `SSE_KMS` |
| `CSE_KMS` |

## Example

```python
from amazonathena.models.encryption_option import EncryptionOption

encryption_option = EncryptionOption.SSE_KMS
```

