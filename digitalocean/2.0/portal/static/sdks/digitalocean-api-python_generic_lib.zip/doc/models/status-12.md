
# Status 12

A status string indicating the current state of the load balancer. This can be `new`, `active`, or `errored`.

## Enumeration

`Status12`

## Fields

| Name |
|  --- |
| `NEW` |
| `ACTIVE` |
| `ERRORED` |

## Example

```python
from digitaloceanapi.models.status_12 import Status12

status_12 = Status12.ACTIVE
```

