
# Applied To

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applied_to_resources` | [`Array[AppliedToResource]`](../../doc/models/applied-to-resource.md) | Optional | - |
| `label_selector` | [`LabelSelector`](../../doc/models/label-selector.md) | Optional | - |
| `server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `type` | [`Type6Enum`](../../doc/models/type-6-enum.md) | Required | Type of resource referenced |

## Example

```ruby
applied_to = AppliedTo.new(
  Type6Enum::SERVER,
  [
    AppliedToResource.new(
      Server.new(
        14
      ),
      Type5Enum::SERVER
    )
  ],
  LabelSelector.new(
    'selector8'
  ),
  Server.new(
    14
  )
)
```

