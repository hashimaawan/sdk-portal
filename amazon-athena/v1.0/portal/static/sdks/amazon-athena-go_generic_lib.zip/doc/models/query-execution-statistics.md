
# Query Execution Statistics

The amount of data scanned during the query execution and the amount of time that it took to execute, and the type of statement that was run.

## Structure

`QueryExecutionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EngineExecutionTimeInMillis` | `*int` | Optional | - |
| `DataScannedInBytes` | `*int` | Optional | - |
| `DataManifestLocation` | `*string` | Optional | - |
| `TotalExecutionTimeInMillis` | `*int` | Optional | - |
| `QueryQueueTimeInMillis` | `*int` | Optional | - |
| `QueryPlanningTimeInMillis` | `*int` | Optional | - |
| `ServiceProcessingTimeInMillis` | `*int` | Optional | - |
| `ResultReuseInformation` | [`*models.ResultReuseInformation2`](../../doc/models/result-reuse-information-2.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    queryExecutionStatistics := models.QueryExecutionStatistics{
        EngineExecutionTimeInMillis:   models.ToPointer(98),
        DataScannedInBytes:            models.ToPointer(86),
        DataManifestLocation:          models.ToPointer("DataManifestLocation2"),
        TotalExecutionTimeInMillis:    models.ToPointer(136),
        QueryQueueTimeInMillis:        models.ToPointer(142),
    }

}
```

