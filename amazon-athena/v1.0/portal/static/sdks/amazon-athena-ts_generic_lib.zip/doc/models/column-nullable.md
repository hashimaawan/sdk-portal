
# Column Nullable

## Enumeration

`ColumnNullable`

## Fields

| Name |
|  --- |
| `NotNull` |
| `Nullable` |
| `Unknown` |

## Example

```ts
import { ColumnNullable } from 'amazon-athenalib';

const columnNullable = ColumnNullable.NotNull;
```

