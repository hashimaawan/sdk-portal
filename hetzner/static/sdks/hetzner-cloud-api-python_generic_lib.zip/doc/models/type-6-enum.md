
# Type 6 Enum

Type of resource referenced

## Enumeration

`Type6Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```python
from hetznercloudapi.models.type_6_enum import Type6Enum

type_6 = Type6Enum.SERVER
```

