
# X Amz Target 53 Enum

## Enumeration

`XAmzTarget53Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUntagResource` |

## Example

```ts
import { XAmzTarget53Enum } from 'amazon-athenalib';

const xAmzTarget53 = XAmzTarget53Enum.EnumAmazonAthenaUntagResource;
```

