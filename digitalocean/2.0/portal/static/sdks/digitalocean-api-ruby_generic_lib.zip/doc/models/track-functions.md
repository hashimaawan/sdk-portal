
# Track Functions

Enables tracking of function call counts and time used.

## Enumeration

`TrackFunctions`

## Fields

| Name |
|  --- |
| `ALL` |
| `PL` |
| `NONE` |

## Example

```ruby
track_functions = TrackFunctions::NONE
```

