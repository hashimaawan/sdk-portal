
# Protection 11

Protection configuration for the Network

## Structure

`Protection11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool` | Required | If true, prevents the Network from being deleted |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Protection11 protection11 = new Protection11
{
    Delete = false,
};
```

