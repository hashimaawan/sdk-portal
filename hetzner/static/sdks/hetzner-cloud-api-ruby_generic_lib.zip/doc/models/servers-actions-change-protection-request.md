
# Servers Actions Change Protection Request

## Structure

`ServersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Server from being deleted (currently delete and rebuild attribute needs to have the same value) |
| `rebuild` | `TrueClass \| FalseClass` | Optional | If true, prevents the Server from being rebuilt (currently delete and rebuild attribute needs to have the same value) |

## Example

```ruby
servers_actions_change_protection_request = ServersActionsChangeProtectionRequest.new(
  true,
  true
)
```

