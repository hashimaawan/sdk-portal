
# Public Net

Public network information

*This model accepts additional fields of type array.*

## Structure

`PublicNet`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `enabled` | `bool` | Required | Public Interface enabled or not | getEnabled(): bool | setEnabled(bool enabled): void |
| `ipv4` | [`Ipv4`](../../doc/models/ipv-4.md) | Required | IP address (v4) | getIpv4(): Ipv4 | setIpv4(Ipv4 ipv4): void |
| `ipv6` | [`Ipv6`](../../doc/models/ipv-6.md) | Required | IP address (v6) | getIpv6(): Ipv6 | setIpv6(Ipv6 ipv6): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\PublicNetBuilder;
use HetznerCloudApiLib\Models\Builders\Ipv4Builder;
use HetznerCloudApiLib\ApiHelper;
use HetznerCloudApiLib\Models\Builders\Ipv6Builder;

$publicNet = PublicNetBuilder::init(
    false,
    Ipv4Builder::init()
        ->dnsPtr('lb1.example.com')
        ->ip('1.2.3.4')
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    Ipv6Builder::init()
        ->dnsPtr('lb1.example.com')
        ->ip('2001:db8::1')
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

