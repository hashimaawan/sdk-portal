
# X Amz Target 20 Enum

## Enumeration

`XAmzTarget20Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetNamedQuery` |

## Example

```ts
import { XAmzTarget20Enum } from 'amazon-athenalib';

const xAmzTarget20 = XAmzTarget20Enum.EnumAmazonAthenaGetNamedQuery;
```

