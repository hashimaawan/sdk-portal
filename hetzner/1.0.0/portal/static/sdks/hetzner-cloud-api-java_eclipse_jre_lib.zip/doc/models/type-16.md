
# Type 16

Type of the Floating IP

## Enumeration

`Type16`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```java
import cloud.hetzner.api.models.Type16;

Type16 type16 = Type16.IPV4;
```

