
# Calculation Configuration

Contains configuration information for the calculation.

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code_block` | `str` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```python
from amazonathena.models.calculation_configuration import CalculationConfiguration

calculation_configuration = CalculationConfiguration(
    code_block='CodeBlock6'
)
```

