
# Type

Type of the Certificate

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

HetznerCloudApi.Standard.Models.Type type = HetznerCloudApi.Standard.Models.Type.Uploaded;
```

