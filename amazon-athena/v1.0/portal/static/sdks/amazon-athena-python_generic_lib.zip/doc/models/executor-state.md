
# Executor State

## Enumeration

`ExecutorState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```python
from amazonathena.models.executor_state import ExecutorState

executor_state = ExecutorState.TERMINATED
```

