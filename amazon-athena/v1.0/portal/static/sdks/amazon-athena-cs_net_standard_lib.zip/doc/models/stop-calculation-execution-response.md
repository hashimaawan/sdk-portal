
# Stop Calculation Execution Response

*This model accepts additional fields of type object.*

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `State` | [`CalculationExecutionState4?`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

StopCalculationExecutionResponse stopCalculationExecutionResponse = new StopCalculationExecutionResponse
{
    State = CalculationExecutionState4.Queued,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

