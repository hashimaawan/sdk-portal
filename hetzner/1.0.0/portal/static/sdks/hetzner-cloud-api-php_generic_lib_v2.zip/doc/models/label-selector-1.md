
# Label Selector 1

Configuration for type LabelSelector, required if type is `label_selector`

## Structure

`LabelSelector1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector | getSelector(): string | setSelector(string selector): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LabelSelector1Builder;

$labelSelector1 = LabelSelector1Builder::init(
    'selector2'
)->build();
```

