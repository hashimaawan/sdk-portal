
# Alerts 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Alerts1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `UUID \| String` | Optional, Read-only | A unique ID that can be used to identify and reference the alert. |
| `comparison` | [`Comparison`](../../doc/models/comparison.md) | Optional | The comparison operator used against the alert's threshold. |
| `name` | `String` | Optional | A human-friendly display name. |
| `notifications` | [`Notifications`](../../doc/models/notifications.md) | Optional | The notification settings for a trigger alert. |
| `period` | [`Period`](../../doc/models/period.md) | Optional | Period of time the threshold must be exceeded to trigger the alert. |
| `threshold` | `Integer` | Optional | The threshold at which the alert will enter a trigger state. The specific threshold is dependent on the alert type. |
| `type` | [`Type20`](../../doc/models/type-20.md) | Optional | The type of alert. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
alerts1 = Alerts1.new(
  id: '5a4981aa-9653-4bd1-bef5-d6bff52042e4',
  comparison: Comparison::GREATER_THAN,
  name: 'Landing page degraded performance',
  notifications: Notifications.new(
    email: [
      'email4',
      'email3'
    ],
    slack: [
      Slack.new(
        channel: 'channel6',
        url: 'url2',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      Slack.new(
        channel: 'channel6',
        url: 'url2',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      Slack.new(
        channel: 'channel6',
        url: 'url2',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  period: Period::ENUM_2M,
  threshold: 300,
  type: Type20::LATENCY,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

