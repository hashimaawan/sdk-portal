
# Type 3

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `BUILD` |
| `DEPLOY` |
| `RUN` |

## Example

```java
import com.digitalocean.api.models.Type3;

Type3 type3 = Type3.DEPLOY;
```

