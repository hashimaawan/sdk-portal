
# Label Selector 1

Configuration for type LabelSelector, required if type is `label_selector`

## Structure

`LabelSelector1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `str` | Required | Label selector |

## Example

```python
from hetznercloudapi.models.label_selector_1 import LabelSelector1

label_selector_1 = LabelSelector1(
    selector='selector0'
)
```

