
# V2 Databases Config Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DatabasesConfigRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `config` | [Config](../../doc/models/config.md) \| [Config1](../../doc/models/config-1.md) \| [Config2](../../doc/models/config-2.md) \| None | Optional | This is a container for any-of cases. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.config import Config
from digitaloceanapi.models.v_2_databases_config_request import V2DatabasesConfigRequest

v_2_databases_config_request = V2DatabasesConfigRequest(
    config=Config(
        backup_hour=23,
        backup_minute=59,
        binlog_retention_period=600,
        connect_timeout=196,
        default_time_zone='default_time_zone8',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

