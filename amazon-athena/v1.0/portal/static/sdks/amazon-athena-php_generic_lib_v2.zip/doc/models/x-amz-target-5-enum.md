
# X Amz Target 5 Enum

## Enumeration

`XAmzTarget5Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget5Enum;

$xAmzTarget5 = XAmzTarget5Enum::ENUM_AMAZONATHENACREATENOTEBOOK;
```

