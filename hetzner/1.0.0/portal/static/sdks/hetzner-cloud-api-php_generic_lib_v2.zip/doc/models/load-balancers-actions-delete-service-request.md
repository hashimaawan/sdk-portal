
# Load Balancers Actions Delete Service Request

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `listenPort` | `float` | Required | The listen port of the service you want to delete | getListenPort(): float | setListenPort(float listenPort): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LoadBalancersActionsDeleteServiceRequestBuilder;

$loadBalancersActionsDeleteServiceRequest = LoadBalancersActionsDeleteServiceRequestBuilder::init(
    4711
)->build();
```

