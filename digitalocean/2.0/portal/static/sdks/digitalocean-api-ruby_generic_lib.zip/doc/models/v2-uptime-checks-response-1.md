
# V2 Uptime Checks Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2UptimeChecksResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check` | [`Check`](../../doc/models/check.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_uptime_checks_response1 = V2UptimeChecksResponse1.new(
  check: Check.new(
    id: '00000c0a-0000-0000-0000-000000000000',
    enabled: false,
    name: 'name2',
    regions: [
      Region8::SE_ASIA
    ],
    target: 'target0',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

