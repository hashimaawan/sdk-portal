
# Type 21 Enum

## Enumeration

`Type21Enum`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```java
import cloud.hetzner.api.models.Type21Enum;

Type21Enum type21 = Type21Enum.BACKUP;
```

