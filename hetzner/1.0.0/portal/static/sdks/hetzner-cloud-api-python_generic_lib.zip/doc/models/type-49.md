
# Type 49

The type of the Primary IP

## Enumeration

`Type49`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_49 import Type49

type_49 = Type49.IPV4
```

