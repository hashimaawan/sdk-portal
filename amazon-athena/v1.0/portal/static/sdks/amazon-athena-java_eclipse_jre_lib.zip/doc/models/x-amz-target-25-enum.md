
# X Amz Target 25 Enum

## Enumeration

`XAmzTarget25Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget25Enum;

XAmzTarget25Enum xAmzTarget25 = XAmzTarget25Enum.ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS;
```

