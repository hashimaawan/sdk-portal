
# Result Set 2

*This model accepts additional fields of type interface{}.*

## Structure

`ResultSet2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rows` | [`[]models.Row`](../../doc/models/row.md) | Optional | - |
| `ResultSetMetadata` | [`*models.ResultSetMetadata2`](../../doc/models/result-set-metadata-2.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    resultSet2 := models.ResultSet2{
        Rows:                  []models.Row{
            models.Row{
                Data:                  []models.Datum{
                    models.Datum{
                        VarCharValue:          models.ToPointer("VarCharValue8"),
                        AdditionalProperties:  map[string]interface{}{
                            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                        },
                    },
                    models.Datum{
                        VarCharValue:          models.ToPointer("VarCharValue8"),
                        AdditionalProperties:  map[string]interface{}{
                            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                        },
                    },
                },
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        ResultSetMetadata:     models.ToPointer(models.ResultSetMetadata2{
            ColumnInfo:            []models.ColumnInfo{
                models.ColumnInfo{
                    CatalogName:           models.ToPointer("CatalogName0"),
                    SchemaName:            models.ToPointer("SchemaName0"),
                    TableName:             models.ToPointer("TableName2"),
                    Name:                  "Name6",
                    Label:                 models.ToPointer("Label4"),
                    Type:                  "Type6",
                    Precision:             models.ToPointer(48),
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                },
            },
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

