
# X Amz Target 4 Enum

## Enumeration

`XAmzTarget4Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget4Enum;

XAmzTarget4Enum xAmzTarget4 = XAmzTarget4Enum.ENUM_AMAZONATHENACREATENAMEDQUERY;
```

