
# X Amz Target 52 Enum

## Enumeration

`XAmzTarget52Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENATERMINATESESSION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget52 := models.XAmzTarget52Enum_ENUMAMAZONATHENATERMINATESESSION

}
```

