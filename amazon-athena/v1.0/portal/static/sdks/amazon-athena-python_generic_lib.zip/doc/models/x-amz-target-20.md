
# X Amz Target 20

## Enumeration

`XAmzTarget20`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_20 import XAmzTarget20

x_amz_target_20 = XAmzTarget20.ENUM_AMAZONATHENAGETNAMEDQUERY
```

