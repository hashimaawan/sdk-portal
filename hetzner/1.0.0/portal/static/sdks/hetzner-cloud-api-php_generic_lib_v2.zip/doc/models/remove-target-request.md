
# Remove Target Request

## Structure

`RemoveTargetRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ip` | [`?Ip`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. | getIp(): ?Ip | setIp(?Ip ip): void |
| `labelSelector` | [`?LabelSelector12`](../../doc/models/label-selector-12.md) | Optional | Configuration for label selector targets, required if type is `label_selector` | getLabelSelector(): ?LabelSelector12 | setLabelSelector(?LabelSelector12 labelSelector): void |
| `server` | [`?Server16`](../../doc/models/server-16.md) | Optional | Configuration for type Server, required if type is `server` | getServer(): ?Server16 | setServer(?Server16 server): void |
| `type` | [`string(Type29Enum)`](../../doc/models/type-29-enum.md) | Required | Type of the resource | getType(): string | setType(string type): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\RemoveTargetRequestBuilder;
use HetznerCloudAPILib\Models\Type29Enum;
use HetznerCloudAPILib\Models\Builders\IpBuilder;
use HetznerCloudAPILib\Models\Builders\LabelSelector12Builder;
use HetznerCloudAPILib\Models\Builders\Server16Builder;

$removeTargetRequest = RemoveTargetRequestBuilder::init(
    Type29Enum::IP
)
    ->ip(
        IpBuilder::init(
            'ip8'
        )->build()
    )
    ->labelSelector(
        LabelSelector12Builder::init(
            'selector8'
        )->build()
    )
    ->server(
        Server16Builder::init(
            217.74
        )->build()
    )->build();
```

