
# V2 Customers My Invoices Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2CustomersMyInvoicesResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `invoice_items` | [`Array[InvoiceItem]`](../../doc/models/invoice-item.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_customers_my_invoices_response1 = V2CustomersMyInvoicesResponse1.new(
  meta: Meta.new(
    total: 6,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  invoice_items: [
    InvoiceItem.new(
      amount: '12.34',
      description: 'a56e086a317d8410c8b4cfd1f4dc9f82',
      duration: '744',
      duration_unit: 'Hours',
      end_time: '2020-02-01T00:00:00Z',
      group_description: 'my-doks-cluster',
      product: 'Kubernetes Clusters',
      resource_uuid: '711157cb-37c8-4817-b371-44fa3504a39c',
      start_time: '2020-01-01T00:00:00Z',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    InvoiceItem.new(
      amount: '34.45',
      description: 'Spaces ($5/mo 250GB storage & 1TB bandwidth)',
      duration: '744',
      duration_unit: 'Hours',
      end_time: '2020-02-01T00:00:00Z',
      product: 'Spaces Subscription',
      start_time: '2020-01-01T00:00:00Z',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'https://api.digitalocean.com/v2/customers/my/invoices/22737513-0ea7-4206-8ceb-98a575af7681?page=3&per_page=2',
      mnext: 'https://api.digitalocean.com/v2/customers/my/invoices/22737513-0ea7-4206-8ceb-98a575af7681?page=2&per_page=2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

