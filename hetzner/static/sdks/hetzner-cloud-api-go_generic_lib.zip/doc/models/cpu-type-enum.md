
# Cpu Type Enum

Type of cpu

## Enumeration

`CpuTypeEnum`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    cpuType := models.CpuTypeEnum_SHARED

}
```

