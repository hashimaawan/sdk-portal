
# V2 Account Keys Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2AccountKeysRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | A human-readable display name for this key, used to easily identify the SSH keys when they are displayed. | getName(): ?string | setName(?string name): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2AccountKeysRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2AccountKeysRequest = V2AccountKeysRequestBuilder::init()
    ->name('My SSH Public Key')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

