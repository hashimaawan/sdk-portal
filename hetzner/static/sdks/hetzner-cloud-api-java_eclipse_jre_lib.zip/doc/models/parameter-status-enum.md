
# Parameter Status Enum

## Enumeration

`ParameterStatusEnum`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ERROR` |

## Example

```java
import cloud.hetzner.api.models.ParameterStatusEnum;

ParameterStatusEnum parameterStatus = ParameterStatusEnum.ERROR;
```

