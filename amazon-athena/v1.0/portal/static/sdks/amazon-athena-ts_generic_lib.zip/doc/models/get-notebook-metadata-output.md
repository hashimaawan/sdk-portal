
# Get Notebook Metadata Output

## Structure

`GetNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookMetadata` | [`NotebookMetadata1 \| undefined`](../../doc/models/notebook-metadata-1.md) | Optional | - |

## Example

```ts
import {
  GetNotebookMetadataOutput,
  NotebookType1Enum,
} from 'amazon-athenalib';

const getNotebookMetadataOutput: GetNotebookMetadataOutput = {
  notebookMetadata: {
    notebookId: 'NotebookId0',
    name: 'Name0',
    workGroup: 'WorkGroup2',
    creationTime: '2016-03-13T12:52:32.123Z',
    type: NotebookType1Enum.IPYNB,
  },
};
```

