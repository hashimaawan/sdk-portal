
# S3 Acl Option Enum

## Enumeration

`S3AclOptionEnum`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```python
from amazonathena.models.s_3_acl_option_enum import S3AclOptionEnum

s_3_acl_option = S3AclOptionEnum.BUCKET_OWNER_FULL_CONTROL
```

