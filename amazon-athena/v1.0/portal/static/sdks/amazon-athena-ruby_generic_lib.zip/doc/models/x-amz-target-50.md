
# X Amz Target 50

## Enumeration

`XAmzTarget50`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPQUERYEXECUTION` |

## Example

```ruby
x_amz_target50 = XAmzTarget50::ENUM_AMAZONATHENASTOPQUERYEXECUTION
```

