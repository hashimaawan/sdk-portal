
# Status 13

## Enumeration

`Status13`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `ERROR` |

## Example

```python
from digitaloceanapi.models.status_13 import Status13

status_13 = Status13.SUCCESS
```

