
# Load Balancers Actions Detach from Network Request

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `network` | `float` | Required | ID of an existing network to detach the Load Balancer from | getNetwork(): float | setNetwork(float network): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LoadBalancersActionsDetachFromNetworkRequestBuilder;

$loadBalancersActionsDetachFromNetworkRequest = LoadBalancersActionsDetachFromNetworkRequestBuilder::init(
    4711
)->build();
```

