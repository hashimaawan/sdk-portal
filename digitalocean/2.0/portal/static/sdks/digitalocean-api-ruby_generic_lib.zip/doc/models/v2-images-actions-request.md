
# V2 Images Actions Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2ImagesActionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type15`](../../doc/models/type-15.md) | Required | The action to be taken on the image. Can be either `convert` or `transfer`. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_images_actions_request = V2ImagesActionsRequest.new(
  type: Type15::CONVERT,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

