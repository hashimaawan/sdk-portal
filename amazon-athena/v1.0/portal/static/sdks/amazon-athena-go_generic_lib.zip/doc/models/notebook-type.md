
# Notebook Type

## Enumeration

`NotebookType`

## Fields

| Name |
|  --- |
| `Ipynb` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    notebookType := models.NotebookType_Ipynb

}
```

