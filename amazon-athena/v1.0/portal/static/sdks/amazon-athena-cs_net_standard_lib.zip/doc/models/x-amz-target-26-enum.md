
# X Amz Target 26 Enum

## Enumeration

`XAmzTarget26Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetSession` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget26Enum xAmzTarget26 = XAmzTarget26Enum.EnumAmazonAthenaGetSession;
```

