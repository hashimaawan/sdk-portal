
# Update Data Catalog Input

*This model accepts additional fields of type Any.*

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `mtype` | [`DataCatalogType3`](../../doc/models/data-catalog-type-3.md) | Required | - |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.data_catalog_type_3 import DataCatalogType3
from amazonathena.models.parameters import Parameters
from amazonathena.models.update_data_catalog_input import UpdateDataCatalogInput

update_data_catalog_input = UpdateDataCatalogInput(
    name='Name0',
    mtype=DataCatalogType3.HIVE,
    description='Description6',
    parameters=Parameters(
        additional_properties={
            'exampleAdditionalProperty': 'Parameters_additionalProperties2'
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

