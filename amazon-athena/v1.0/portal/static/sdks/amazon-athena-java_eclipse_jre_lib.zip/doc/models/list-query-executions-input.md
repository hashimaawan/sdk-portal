
# List Query Executions Input

## Structure

`ListQueryExecutionsInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NextToken` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getNextToken() | setNextToken(String nextToken) |
| `MaxResults` | `Integer` | Optional | **Constraints**: `>= 0`, `<= 50` | Integer getMaxResults() | setMaxResults(Integer maxResults) |
| `WorkGroup` | `String` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | String getWorkGroup() | setWorkGroup(String workGroup) |

## Example

```java
import com.amazonaws.useast1.athena.models.ListQueryExecutionsInput;

ListQueryExecutionsInput listQueryExecutionsInput = new ListQueryExecutionsInput.Builder()
    .nextToken("NextToken2")
    .maxResults(34)
    .workGroup("WorkGroup4")
    .build();
```

