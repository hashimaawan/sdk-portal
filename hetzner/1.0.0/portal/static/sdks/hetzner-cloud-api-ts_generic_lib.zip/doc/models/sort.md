
# Sort

## Enumeration

`Sort`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```ts
import { Sort } from 'hetzner-cloud-apilib';

const sort = Sort.EnumIdasc;
```

