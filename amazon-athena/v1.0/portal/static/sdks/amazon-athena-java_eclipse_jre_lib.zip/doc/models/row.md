
# Row

The rows that make up a query result table.

## Structure

`Row`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`List<Datum>`](../../doc/models/datum.md) | Optional | - | List<Datum> getData() | setData(List<Datum> data) |

## Example

```java
import com.amazonaws.useast1.athena.models.Datum;
import com.amazonaws.useast1.athena.models.Row;
import java.util.Arrays;

Row row = new Row.Builder()
    .data(Arrays.asList(
        new Datum.Builder()
            .varCharValue("VarCharValue8")
            .build()
    ))
    .build();
```

