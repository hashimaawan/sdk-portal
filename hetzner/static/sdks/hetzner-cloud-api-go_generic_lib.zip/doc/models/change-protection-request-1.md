
# Change Protection Request 1

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `*bool` | Optional | If true, prevents the Network from being deleted |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    changeProtectionRequest1 := models.ChangeProtectionRequest1{
        Delete:               models.ToPointer(true),
    }

}
```

