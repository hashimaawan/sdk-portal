
# V2 Apps Deployments Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2AppsDeploymentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `force_build` | `bool` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_apps_deployments_request import V2AppsDeploymentsRequest

v_2_apps_deployments_request = V2AppsDeploymentsRequest(
    force_build=True,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

