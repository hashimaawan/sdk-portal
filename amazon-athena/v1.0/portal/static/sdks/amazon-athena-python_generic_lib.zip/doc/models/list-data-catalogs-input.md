
# List Data Catalogs Input

## Structure

`ListDataCatalogsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `int` | Optional | **Constraints**: `>= 2`, `<= 50` |

## Example

```python
from amazonathena.models.list_data_catalogs_input import ListDataCatalogsInput

list_data_catalogs_input = ListDataCatalogsInput(
    next_token='NextToken4',
    max_results=50
)
```

