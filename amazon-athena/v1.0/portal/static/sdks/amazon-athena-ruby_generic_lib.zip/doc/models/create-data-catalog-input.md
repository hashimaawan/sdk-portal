
# Create Data Catalog Input

## Structure

`CreateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `type` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `tags` | [`Array[Tag]`](../../doc/models/tag.md) | Optional | - |

## Example

```ruby
create_data_catalog_input = CreateDataCatalogInput.new(
  'Name0',
  DataCatalogType1Enum::LAMBDA,
  'Description6',
  Parameters.new,
  [
    Tag.new(
      'Key0',
      'Value6'
    )
  ]
)
```

