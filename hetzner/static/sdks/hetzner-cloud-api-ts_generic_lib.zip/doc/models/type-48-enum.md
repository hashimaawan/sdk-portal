
# Type 48 Enum

The type of the Floating IP

## Enumeration

`Type48Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type48Enum } from 'hetzner-cloud-apilib';

const type48 = Type48Enum.Ipv4;
```

