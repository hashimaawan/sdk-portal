
# Type 24

Destination Image type to convert to

## Enumeration

`Type24`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |

## Example

```ruby
type24 = Type24::SNAPSHOT
```

