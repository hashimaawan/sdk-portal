
# Start Query Execution Output

*This model accepts additional fields of type unknown.*

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { StartQueryExecutionOutput } from 'amazon-athenalib';

const startQueryExecutionOutput: StartQueryExecutionOutput = {
  queryExecutionId: 'QueryExecutionId0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

