
# X Amz Target 51 Enum

## Enumeration

`XAmzTarget51Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATAGRESOURCE` |

## Example

```ruby
x_amz_target51 = XAmzTarget51Enum::ENUM_AMAZONATHENATAGRESOURCE
```

