
# Gitlab

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Gitlab`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `branch` | `str` | Optional | The name of the branch to use |
| `deploy_on_push` | `bool` | Optional | Whether to automatically deploy new commits made to the repo |
| `repo` | `str` | Optional | The name of the repo in the format owner/repo. Example: `digitalocean/sample-golang` |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.gitlab import Gitlab

gitlab = Gitlab(
    branch='main',
    deploy_on_push=True,
    repo='digitalocean/sample-golang',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

