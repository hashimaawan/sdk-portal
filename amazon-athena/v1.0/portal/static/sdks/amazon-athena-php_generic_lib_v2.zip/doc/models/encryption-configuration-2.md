
# Encryption Configuration 2

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `encryptionOption` | [`string(EncryptionOption1Enum)`](../../doc/models/encryption-option-1-enum.md) | Required | - | getEncryptionOption(): string | setEncryptionOption(string encryptionOption): void |
| `kmsKey` | `?string` | Optional | - | getKmsKey(): ?string | setKmsKey(?string kmsKey): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\EncryptionConfiguration2Builder;
use AmazonAthenaLib\Models\EncryptionOption1Enum;

$encryptionConfiguration2 = EncryptionConfiguration2Builder::init(
    EncryptionOption1Enum::SSE_S3
)
    ->kmsKey('KmsKey2')
    ->build();
```

