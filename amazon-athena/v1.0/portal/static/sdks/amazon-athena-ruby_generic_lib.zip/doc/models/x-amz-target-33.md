
# X Amz Target 33

## Enumeration

`XAmzTarget33`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATACATALOGS` |

## Example

```ruby
x_amz_target33 = XAmzTarget33::ENUM_AMAZONATHENALISTDATACATALOGS
```

