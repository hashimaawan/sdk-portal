
# Track Commit Timestamp

Record commit time of transactions.

## Enumeration

`TrackCommitTimestamp`

## Fields

| Name |
|  --- |
| `OFF` |
| `ON` |

## Example

```java
import com.digitalocean.api.models.TrackCommitTimestamp;

TrackCommitTimestamp trackCommitTimestamp = TrackCommitTimestamp.OFF;
```

