
# Labels

User-defined labels (key-value pairs)

## Structure

`Labels`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labelkey` | `string` | Optional | New label |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Labels labels = new Labels
{
    Labelkey = "value",
};
```

