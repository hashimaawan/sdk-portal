
# Resource Type 1

The type of resource that the snapshot originated from.

## Enumeration

`ResourceType1`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `VOLUME` |

## Example

```ruby
resource_type1 = ResourceType1::DROPLET
```

