
# Type 48

The type of the Floating IP

## Enumeration

`Type48`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type48 } from 'hetzner-cloud-apilib';

const type48 = Type48.Ipv4;
```

