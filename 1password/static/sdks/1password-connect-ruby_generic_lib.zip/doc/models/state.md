
# State

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `ARCHIVED` |
| `DELETED` |

## Example

```ruby
state = State::ARCHIVED
```

