
# Load Balancers Metrics Response

## Structure

`LoadBalancersMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `metrics` | [`Metrics`](../../doc/models/metrics.md) | Required | - |

## Example

```ts
import { LoadBalancersMetricsResponse } from 'hetzner-cloud-apilib';

const loadBalancersMetricsResponse: LoadBalancersMetricsResponse = {
  metrics: {
    end: '2017-01-01T23:00:00+00:00',
    start: '2017-01-01T00:00:00+00:00',
    step: 60,
    timeSeries: {
      'name_of_timeseries': {
        values: [
          null,
          null
        ],
      }
    },
  },
};
```

