
# X Amz Target 49

## Enumeration

`XAmzTarget49`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget49;

$xAmzTarget49 = XAmzTarget49::ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION;
```

