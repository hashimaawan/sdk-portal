
# List Engine Versions Output

## Structure

`ListEngineVersionsOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EngineVersions` | [`List<EngineVersion>`](../../doc/models/engine-version.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` | List<EngineVersion> getEngineVersions() | setEngineVersions(List<EngineVersion> engineVersions) |
| `NextToken` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getNextToken() | setNextToken(String nextToken) |

## Example

```java
import com.amazonaws.useast1.athena.models.EngineVersion;
import com.amazonaws.useast1.athena.models.ListEngineVersionsOutput;
import java.util.Arrays;

ListEngineVersionsOutput listEngineVersionsOutput = new ListEngineVersionsOutput.Builder()
    .engineVersions(Arrays.asList(
        new EngineVersion.Builder()
            .selectedEngineVersion("SelectedEngineVersion2")
            .effectiveEngineVersion("EffectiveEngineVersion2")
            .build()
    ))
    .nextToken("NextToken0")
    .build();
```

