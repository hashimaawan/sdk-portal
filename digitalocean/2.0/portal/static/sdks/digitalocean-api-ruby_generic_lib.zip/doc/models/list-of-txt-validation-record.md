
# List of Txt Validation Record

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`ListOfTxtValidationRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `txt_name` | `String` | Optional, Read-only | - |
| `txt_value` | `String` | Optional, Read-only | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
list_of_txt_validation_record = ListOfTxtValidationRecord.new(
  txt_name: '_acme-challenge.app.example.com',
  txt_value: 'lXLOcN6cPv0nproViNcUHcahD9TrIPlNgdwesj0pYpk',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

