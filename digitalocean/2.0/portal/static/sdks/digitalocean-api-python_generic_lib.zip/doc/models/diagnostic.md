
# Diagnostic

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Diagnostic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check_name` | `str` | Optional | The clusterlint check that resulted in the diagnostic. |
| `message` | `str` | Optional | Feedback about the object for users to fix. |
| `object` | [`Object`](../../doc/models/object.md) | Optional | Metadata about the Kubernetes API object the diagnostic is reported on. |
| `severity` | `str` | Optional | Can be one of error, warning or suggestion. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.diagnostic import Diagnostic
from digitaloceanapi.models.object import Object

diagnostic = Diagnostic(
    check_name='unused-config-map',
    message='Unused config map',
    object=Object(
        kind='kind0',
        name='name2',
        namespace='namespace0',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    severity='warning',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

