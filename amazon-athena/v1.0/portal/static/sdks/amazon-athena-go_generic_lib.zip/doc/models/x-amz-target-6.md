
# X Amz Target 6

## Enumeration

`XAmzTarget6`

## Fields

| Name |
|  --- |
| `EnumAmazonathenacreatepreparedstatement` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget6 := models.XAmzTarget6_EnumAmazonathenacreatepreparedstatement

}
```

