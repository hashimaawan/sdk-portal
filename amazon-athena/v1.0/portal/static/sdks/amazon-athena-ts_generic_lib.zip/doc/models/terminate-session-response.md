
# Terminate Session Response

*This model accepts additional fields of type unknown.*

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`SessionState1 \| undefined`](../../doc/models/session-state-1.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SessionState1, TerminateSessionResponse } from 'amazon-athenalib';

const terminateSessionResponse: TerminateSessionResponse = {
  state: SessionState1.Creating,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

