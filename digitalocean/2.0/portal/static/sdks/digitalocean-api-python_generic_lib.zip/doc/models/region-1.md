
# Region 1

The slug form of the geographical origin of the app. Default: `nearest available`

## Enumeration

`Region1`

## Fields

| Name |
|  --- |
| `AMS` |
| `NYC` |
| `FRA` |
| `SFO` |
| `SGP` |
| `BLR` |
| `TOR` |
| `LON` |
| `SYD` |

## Example

```python
from digitaloceanapi.models.region_1 import Region1

region_1 = Region1.SGP
```

