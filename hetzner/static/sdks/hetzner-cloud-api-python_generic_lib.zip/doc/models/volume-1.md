
# Volume 1

## Structure

`Volume1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `created` | `str` | Required | Point in time when the Resource was created (in ISO-8601 format) |
| `format` | `str` | Required | Filesystem of the Volume if formatted on creation, null if not formatted on creation |
| `id` | `int` | Required | ID of the Resource |
| `labels` | `Dict[str, str]` | Required | User-defined labels (key-value pairs) |
| `linux_device` | `str` | Required | Device path on the file system for the Volume |
| `location` | [`Location16`](../../doc/models/location-16.md) | Required | Location of the Volume. Volume can only be attached to Servers in the same Location. |
| `name` | `str` | Required | Name of the Resource. Must be unique per Project. |
| `protection` | [`Protection`](../../doc/models/protection.md) | Required | Protection configuration for the Resource |
| `server` | `int` | Required | ID of the Server the Volume is attached to, null if it is not attached at all |
| `size` | `float` | Required | Size in GB of the Volume |
| `status` | [`Status113Enum`](../../doc/models/status-113-enum.md) | Required | Current status of the Volume |

## Example

```python
from hetznercloudapi.models.location_16 import Location16
from hetznercloudapi.models.protection import Protection
from hetznercloudapi.models.status_113_enum import Status113Enum
from hetznercloudapi.models.volume_1 import Volume1

volume_1 = Volume1(
    created='2016-01-30T23:55:00+00:00',
    format='xfs',
    id=42,
    labels={
        'key0': 'labels6',
        'key1': 'labels7'
    },
    linux_device='/dev/disk/by-id/scsi-0HC_Volume_4711',
    location=Location16(
        city='Falkenstein',
        country='DE',
        description='Falkenstein DC Park 1',
        id=1,
        latitude=50.47612,
        longitude=12.370071,
        name='fsn1',
        network_zone='eu-central'
    ),
    name='my-resource',
    protection=Protection(
        delete=False
    ),
    server=12,
    size=42,
    status=Status113Enum.AVAILABLE
)
```

