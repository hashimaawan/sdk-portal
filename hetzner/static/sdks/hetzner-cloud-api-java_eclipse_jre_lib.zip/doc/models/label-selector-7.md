
# Label Selector 7

Label selector and a list of selected targets

## Structure

`LabelSelector7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Selector` | `String` | Required | Label selector | String getSelector() | setSelector(String selector) |

## Example

```java
import cloud.hetzner.api.models.LabelSelector7;

LabelSelector7 labelSelector7 = new LabelSelector7.Builder(
    "env=prod"
)
.build();
```

