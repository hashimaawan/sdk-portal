
# X Amz Target 4 Enum

## Enumeration

`XAmzTarget4Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateNamedQuery` |

## Example

```ts
import { XAmzTarget4Enum } from 'amazon-athenalib';

const xAmzTarget4 = XAmzTarget4Enum.EnumAmazonAthenaCreateNamedQuery;
```

