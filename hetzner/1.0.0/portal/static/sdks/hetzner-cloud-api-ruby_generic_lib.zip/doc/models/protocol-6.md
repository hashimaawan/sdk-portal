
# Protocol 6

Type of the health check

## Enumeration

`Protocol6`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |

## Example

```ruby
protocol6 = Protocol6::TCP
```

