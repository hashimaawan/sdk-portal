
# X Amz Target 3 Enum

## Enumeration

`XAmzTarget3Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEDATACATALOG` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget3Enum;

$xAmzTarget3 = XAmzTarget3Enum::ENUM_AMAZONATHENACREATEDATACATALOG;
```

