
# Change Type Request

*This model accepts additional fields of type Any.*

## Structure

`ChangeTypeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `load_balancer_type` | `str` | Required | ID or name of Load Balancer type the Load Balancer should migrate to |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.change_type_request import ChangeTypeRequest

change_type_request = ChangeTypeRequest(
    load_balancer_type='lb21',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

