
# Encryption Configuration

If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information.

## Structure

`EncryptionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EncryptionOption` | [`models.EncryptionOption1Enum`](../../doc/models/encryption-option-1-enum.md) | Required | - |
| `KmsKey` | `*string` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    encryptionConfiguration := models.EncryptionConfiguration{
        EncryptionOption:     models.EncryptionOption1Enum_SSEKMS,
        KmsKey:               models.ToPointer("KmsKey6"),
    }

}
```

