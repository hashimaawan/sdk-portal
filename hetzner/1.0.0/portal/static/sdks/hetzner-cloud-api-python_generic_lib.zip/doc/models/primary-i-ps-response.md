
# Primary I Ps Response

*This model accepts additional fields of type Any.*

## Structure

`PrimaryIPsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |
| `primary_ips` | [`List[PrimaryIp1]`](../../doc/models/primary-ip-1.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.datacenter_2 import Datacenter2
from hetznercloudapi.models.dns_ptr import DnsPtr
from hetznercloudapi.models.location import Location
from hetznercloudapi.models.meta import Meta
from hetznercloudapi.models.pagination import Pagination
from hetznercloudapi.models.primary_i_ps_response import PrimaryIPsResponse
from hetznercloudapi.models.primary_ip_1 import PrimaryIp1
from hetznercloudapi.models.protection import Protection
from hetznercloudapi.models.server_types import ServerTypes
from hetznercloudapi.models.type_50 import Type50

primary_i_ps_response = PrimaryIPsResponse(
    primary_ips=[
        PrimaryIp1(
            assignee_id=17,
            auto_delete=True,
            blocked=False,
            created='2016-01-30T23:55:00+00:00',
            datacenter=Datacenter2(
                description='Falkenstein DC Park 8',
                id=42,
                location=Location(
                    city='Falkenstein',
                    country='DE',
                    description='Falkenstein DC Park 1',
                    id=1,
                    latitude=50.47612,
                    longitude=12.370071,
                    name='fsn1',
                    network_zone='eu-central',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                name='fsn1-dc8',
                server_types=ServerTypes(
                    available=[
                        1,
                        2,
                        3
                    ],
                    available_for_migration=[
                        1,
                        2,
                        3
                    ],
                    supported=[
                        1,
                        2,
                        3
                    ],
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            dns_ptr=[
                DnsPtr(
                    dns_ptr='server.example.com',
                    ip='2001:db8::1',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            id=42,
            ip='131.232.99.1',
            labels={
                'key0': 'labels2',
                'key1': 'labels3',
                'key2': 'labels4'
            },
            name='my-resource',
            protection=Protection(
                delete=False,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            mtype=Type50.IPV4,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    meta=Meta(
        pagination=Pagination(
            last_page=77.7,
            next_page=209.18,
            page=17.58,
            per_page=13.34,
            previous_page=50.02,
            total_entries=206.64,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

