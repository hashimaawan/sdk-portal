
# Datum

A piece of data (a field in the table).

## Structure

`Datum`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `var_char_value` | `str` | Optional | - |

## Example

```python
from amazonathena.models.datum import Datum

datum = Datum(
    var_char_value='VarCharValue8'
)
```

