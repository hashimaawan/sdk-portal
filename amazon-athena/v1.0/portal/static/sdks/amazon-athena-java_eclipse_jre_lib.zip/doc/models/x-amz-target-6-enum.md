
# X Amz Target 6 Enum

## Enumeration

`XAmzTarget6Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget6Enum;

XAmzTarget6Enum xAmzTarget6 = XAmzTarget6Enum.ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT;
```

