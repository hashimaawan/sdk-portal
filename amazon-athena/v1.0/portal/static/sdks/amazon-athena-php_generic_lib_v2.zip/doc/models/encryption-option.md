
# Encryption Option

## Enumeration

`EncryptionOption`

## Fields

| Name |
|  --- |
| `SSE_S3` |
| `SSE_KMS` |
| `CSE_KMS` |

## Example

```php
use AmazonAthenaLib\Models\EncryptionOption;

$encryptionOption = EncryptionOption::SSE_S3;
```

