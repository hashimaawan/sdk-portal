
# Servers Actions Enable Rescue Request

*This model accepts additional fields of type unknown.*

## Structure

`ServersActionsEnableRescueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sshKeys` | `number[] \| undefined` | Optional | Array of SSH key IDs which should be injected into the rescue system. |
| `type` | [`Type65 \| undefined`](../../doc/models/type-65.md) | Optional | Type of rescue system to boot (default: `linux64`) |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  ServersActionsEnableRescueRequest,
  Type65,
} from 'hetzner-cloud-apilib';

const serversActionsEnableRescueRequest: ServersActionsEnableRescueRequest = {
  sshKeys: [
    2323
  ],
  type: Type65.Linux64,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

