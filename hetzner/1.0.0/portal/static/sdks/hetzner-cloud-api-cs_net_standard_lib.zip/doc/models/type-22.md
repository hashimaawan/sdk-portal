
# Type 22

Type of the Image

## Enumeration

`Type22`

## Fields

| Name |
|  --- |
| `MSystem` |
| `App` |
| `Snapshot` |
| `Backup` |
| `Temporary` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type22 type22 = Type22.Temporary;
```

