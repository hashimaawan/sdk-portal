
# S3 Acl Option Enum

## Enumeration

`S3AclOptionEnum`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```java
import com.amazonaws.useast1.athena.models.S3AclOptionEnum;

S3AclOptionEnum s3AclOption = S3AclOptionEnum.BUCKET_OWNER_FULL_CONTROL;
```

