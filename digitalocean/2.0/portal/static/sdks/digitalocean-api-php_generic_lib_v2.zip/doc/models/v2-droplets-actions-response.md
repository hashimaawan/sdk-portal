
# V2 Droplets Actions Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DropletsActionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `actions` | [`?(Action[])`](../../doc/models/action.md) | Optional | - | getActions(): ?array | setActions(?array actions): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DropletsActionsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\ActionBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\Models\Builders\RegionBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DropletsActionsResponse = V2DropletsActionsResponseBuilder::init()
    ->actions(
        [
            ActionBuilder::init()
                ->completedAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->id(154)
                ->region(
                    RegionBuilder::init(
                        false,
                        [
                            'features7',
                            'features8',
                            'features9'
                        ],
                        'name6',
                        [
                            'sizes6'
                        ],
                        'slug0'
                    )
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                )
                ->regionSlug('region_slug6')
                ->resourceId(238)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

