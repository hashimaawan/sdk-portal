
# Get Session Status Response

## Structure

`GetSessionStatusResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `status` | [`Status3 \| undefined`](../../doc/models/status-3.md) | Optional | - |

## Example

```ts
import {
  GetSessionStatusResponse,
  SessionState1Enum,
} from 'amazon-athenalib';

const getSessionStatusResponse: GetSessionStatusResponse = {
  sessionId: 'SessionId4',
  status: {
    startDateTime: '2016-03-13T12:52:32.123Z',
    lastModifiedDateTime: '2016-03-13T12:52:32.123Z',
    endDateTime: '2016-03-13T12:52:32.123Z',
    idleSinceDateTime: '2016-03-13T12:52:32.123Z',
    state: SessionState1Enum.TERMINATING,
  },
};
```

