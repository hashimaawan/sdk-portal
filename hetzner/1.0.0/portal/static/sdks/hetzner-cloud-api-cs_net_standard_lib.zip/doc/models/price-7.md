
# Price 7

*This model accepts additional fields of type object.*

## Structure

`Price7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Location` | `string` | Required | Name of the Location the price is for |
| `PriceHourly` | [`PriceHourly6`](../../doc/models/price-hourly-6.md) | Required | Hourly costs for a Load Balancer type in this network zone |
| `PriceMonthly` | [`PriceMonthly8`](../../doc/models/price-monthly-8.md) | Required | Monthly costs for a Load Balancer type in this network zone |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

Price7 price7 = new Price7
{
    Location = "fsn1",
    PriceHourly = new PriceHourly6
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    PriceMonthly = new PriceMonthly8
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

