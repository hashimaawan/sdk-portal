
# Parameter Status Enum

## Enumeration

`ParameterStatusEnum`

## Fields

| Name |
|  --- |
| `Running` |
| `Success` |
| `Error` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ParameterStatusEnum parameterStatus = ParameterStatusEnum.Error;
```

