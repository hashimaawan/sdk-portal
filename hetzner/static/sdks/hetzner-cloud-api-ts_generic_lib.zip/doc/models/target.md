
# Target

## Structure

`Target`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `healthStatus` | [`HealthStatus[] \| undefined`](../../doc/models/health-status.md) | Optional | - |
| `server` | [`Server11 \| undefined`](../../doc/models/server-11.md) | Optional | - |
| `type` | `string \| undefined` | Optional | - |
| `usePrivateIp` | `boolean \| undefined` | Optional | - |

## Example

```ts
import { Status30Enum, Target } from 'hetzner-cloud-apilib';

const target: Target = {
  healthStatus: [
    {
      listenPort: 142,
      status: Status30Enum.Unknown,
    },
    {
      listenPort: 142,
      status: Status30Enum.Unknown,
    },
    {
      listenPort: 142,
      status: Status30Enum.Unknown,
    }
  ],
  server: {
    id: 14,
  },
  type: 'server',
  usePrivateIp: false,
};
```

