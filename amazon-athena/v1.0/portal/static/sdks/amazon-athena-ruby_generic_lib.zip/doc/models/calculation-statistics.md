
# Calculation Statistics

Contains statistics for a notebook calculation.

*This model accepts additional fields of type Object.*

## Structure

`CalculationStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `Integer` | Optional | - |
| `progress` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
calculation_statistics = CalculationStatistics.new(
  dpu_execution_in_millis: 242,
  progress: 'Progress6',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

