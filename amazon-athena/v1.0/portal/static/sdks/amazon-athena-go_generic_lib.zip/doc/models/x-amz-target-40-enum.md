
# X Amz Target 40 Enum

## Enumeration

`XAmzTarget40Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget40 := models.XAmzTarget40Enum_ENUMAMAZONATHENALISTPREPAREDSTATEMENTS

}
```

