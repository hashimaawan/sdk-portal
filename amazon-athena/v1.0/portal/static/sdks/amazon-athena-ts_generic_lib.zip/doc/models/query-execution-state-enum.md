
# Query Execution State Enum

## Enumeration

`QueryExecutionStateEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```ts
import { QueryExecutionStateEnum } from 'amazon-athenalib';

const queryExecutionState = QueryExecutionStateEnum.CANCELLED;
```

