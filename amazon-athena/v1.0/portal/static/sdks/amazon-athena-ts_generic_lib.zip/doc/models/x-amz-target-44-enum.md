
# X Amz Target 44 Enum

## Enumeration

`XAmzTarget44Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListTagsForResource` |

## Example

```ts
import { XAmzTarget44Enum } from 'amazon-athenalib';

const xAmzTarget44 = XAmzTarget44Enum.EnumAmazonAthenaListTagsForResource;
```

