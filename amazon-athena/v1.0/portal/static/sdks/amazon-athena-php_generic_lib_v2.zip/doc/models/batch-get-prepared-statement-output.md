
# Batch Get Prepared Statement Output

*This model accepts additional fields of type array.*

## Structure

`BatchGetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `preparedStatements` | [`?(PreparedStatement[])`](../../doc/models/prepared-statement.md) | Optional | - | getPreparedStatements(): ?array | setPreparedStatements(?array preparedStatements): void |
| `unprocessedPreparedStatementNames` | [`?(UnprocessedPreparedStatementName[])`](../../doc/models/unprocessed-prepared-statement-name.md) | Optional | - | getUnprocessedPreparedStatementNames(): ?array | setUnprocessedPreparedStatementNames(?array unprocessedPreparedStatementNames): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\BatchGetPreparedStatementOutputBuilder;
use AmazonAthenaLib\Models\Builders\PreparedStatementBuilder;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\ApiHelper;
use AmazonAthenaLib\Models\Builders\UnprocessedPreparedStatementNameBuilder;

$batchGetPreparedStatementOutput = BatchGetPreparedStatementOutputBuilder::init()
    ->preparedStatements(
        [
            PreparedStatementBuilder::init()
                ->statementName('StatementName2')
                ->queryStatement('QueryStatement6')
                ->workGroupName('WorkGroupName6')
                ->description('Description2')
                ->lastModifiedTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            PreparedStatementBuilder::init()
                ->statementName('StatementName2')
                ->queryStatement('QueryStatement6')
                ->workGroupName('WorkGroupName6')
                ->description('Description2')
                ->lastModifiedTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->unprocessedPreparedStatementNames(
        [
            UnprocessedPreparedStatementNameBuilder::init()
                ->statementName('StatementName0')
                ->errorCode('ErrorCode2')
                ->errorMessage('ErrorMessage8')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            UnprocessedPreparedStatementNameBuilder::init()
                ->statementName('StatementName0')
                ->errorCode('ErrorCode2')
                ->errorMessage('ErrorMessage8')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            UnprocessedPreparedStatementNameBuilder::init()
                ->statementName('StatementName0')
                ->errorCode('ErrorCode2')
                ->errorMessage('ErrorMessage8')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

