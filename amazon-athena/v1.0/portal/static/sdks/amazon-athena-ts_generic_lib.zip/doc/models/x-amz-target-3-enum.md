
# X Amz Target 3 Enum

## Enumeration

`XAmzTarget3Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateDataCatalog` |

## Example

```ts
import { XAmzTarget3Enum } from 'amazon-athenalib';

const xAmzTarget3 = XAmzTarget3Enum.EnumAmazonAthenaCreateDataCatalog;
```

