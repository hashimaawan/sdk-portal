
# Load Balancers Actions Delete Service Request

*This model accepts additional fields of type array.*

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `listenPort` | `float` | Required | The listen port of the service you want to delete | getListenPort(): float | setListenPort(float listenPort): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\LoadBalancersActionsDeleteServiceRequestBuilder;
use HetznerCloudApiLib\ApiHelper;

$loadBalancersActionsDeleteServiceRequest = LoadBalancersActionsDeleteServiceRequestBuilder::init(
    4711
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

