
# Status 113

Current status of the Volume

## Enumeration

`Status113`

## Fields

| Name |
|  --- |
| `Creating` |
| `Available` |

## Example

```ts
import { Status113 } from 'hetzner-cloud-apilib';

const status113 = Status113.Creating;
```

