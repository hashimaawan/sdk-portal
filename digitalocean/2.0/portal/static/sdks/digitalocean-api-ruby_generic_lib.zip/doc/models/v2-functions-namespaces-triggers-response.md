
# V2 Functions Namespaces Triggers Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `triggers` | [`Array[Trigger]`](../../doc/models/trigger.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_functions_namespaces_triggers_response = V2FunctionsNamespacesTriggersResponse.new(
  triggers: [
    Trigger.new(
      created_at: 'created_at8',
      function: 'function6',
      is_enabled: false,
      name: 'name0',
      namespace: 'namespace2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

