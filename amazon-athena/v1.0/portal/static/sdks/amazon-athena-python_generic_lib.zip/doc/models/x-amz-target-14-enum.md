
# X Amz Target 14 Enum

## Enumeration

`XAmzTarget14Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAEXPORTNOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_14_enum import XAmzTarget14Enum

x_amz_target_14 = XAmzTarget14Enum.ENUM_AMAZONATHENAEXPORTNOTEBOOK
```

