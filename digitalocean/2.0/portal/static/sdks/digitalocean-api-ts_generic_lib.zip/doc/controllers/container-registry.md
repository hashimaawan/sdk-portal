# Container Registry

```ts
const containerRegistryApi = new ContainerRegistryApi(client);
```

## Class Name

`ContainerRegistryApi`

## Methods

* [Registry Delete](../../doc/controllers/container-registry.md#registry-delete)
* [Registry Get](../../doc/controllers/container-registry.md#registry-get)
* [Registry Create](../../doc/controllers/container-registry.md#registry-create)
* [Registry Get Docker Credentials](../../doc/controllers/container-registry.md#registry-get-docker-credentials)
* [Registry Get Options](../../doc/controllers/container-registry.md#registry-get-options)
* [Registry Get Subscription](../../doc/controllers/container-registry.md#registry-get-subscription)
* [Registry Update Subscription](../../doc/controllers/container-registry.md#registry-update-subscription)
* [Registry Validate Name](../../doc/controllers/container-registry.md#registry-validate-name)
* [Registry Get Garbage Collection](../../doc/controllers/container-registry.md#registry-get-garbage-collection)
* [Registry Run Garbage Collection](../../doc/controllers/container-registry.md#registry-run-garbage-collection)
* [Registry Update Garbage Collection](../../doc/controllers/container-registry.md#registry-update-garbage-collection)
* [Registry List Garbage Collections](../../doc/controllers/container-registry.md#registry-list-garbage-collections)
* [Registry List Repositories](../../doc/controllers/container-registry.md#registry-list-repositories)
* [Registry List Repositories V2](../../doc/controllers/container-registry.md#registry-list-repositories-v2)
* [Registry List Repository Manifests](../../doc/controllers/container-registry.md#registry-list-repository-manifests)
* [Registry Delete Repository Manifest](../../doc/controllers/container-registry.md#registry-delete-repository-manifest)
* [Registry List Repository Tags](../../doc/controllers/container-registry.md#registry-list-repository-tags)
* [Registry Delete Repository Tag](../../doc/controllers/container-registry.md#registry-delete-repository-tag)


# Registry Delete

To delete your container registry, destroying all container image data stored in it, send a DELETE request to `/v2/registry`.

```ts
async registryDelete(
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
try {
  const response = await containerRegistryApi.registryDelete();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Get

To get information about your container registry, send a GET request to `/v2/registry`.

```ts
async registryGet(
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with the key `registry` containing information about your registry.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryResponse`](../../doc/models/v2-registry-response.md).

## Example Usage

```ts
try {
  const response = await containerRegistryApi.registryGet();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Create

To create your container registry, send a POST request to `/v2/registry`.

The `name` becomes part of the URL for images stored in the registry. For
example, if your registry is called `example`, an image in it will have the
URL `registry.digitalocean.com/example/image:tag`.

```ts
async registryCreate(
  body: V2RegistryRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2RegistryRequest`](../../doc/models/v2-registry-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The response will be a JSON object with the key `registry` containing information about your registry.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryResponse`](../../doc/models/v2-registry-response.md).

## Example Usage

```ts
const body: V2RegistryRequest = {
  name: 'example',
  subscriptionTierSlug: SubscriptionTierSlug.Basic,
  region: Region6.Fra1,
};

try {
  const response = await containerRegistryApi.registryCreate(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Get Docker Credentials

In order to access your container registry with the Docker client or from a
Kubernetes cluster, you will need to configure authentication. The necessary
JSON configuration can be retrieved by sending a GET request to
`/v2/registry/docker-credentials`.

The response will be in the format of a Docker `config.json` file. To use the
config in your Kubernetes cluster, create a Secret with:

    kubectl create secret generic docr \
      --from-file=.dockerconfigjson=config.json \
      --type=kubernetes.io/dockerconfigjson

By default, the returned credentials have read-only access to your registry
and cannot be used to push images. This is appropriate for most Kubernetes
clusters. To retrieve read/write credentials, suitable for use with the Docker
client or in a CI system, read_write may be provided as query parameter. For
example: `/v2/registry/docker-credentials?read_write=true`

By default, the returned credentials will not expire. To retrieve credentials
with an expiry set, expiry_seconds may be provided as a query parameter. For
example: `/v2/registry/docker-credentials?expiry_seconds=3600` will return
credentials that expire after one hour.

```ts
async registryGetDockerCredentials(
  expirySeconds?: number,
  readWrite?: boolean,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryDockerCredentialsResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `expirySeconds` | `number \| undefined` | Query, Optional | The duration in seconds that the returned registry credentials will be valid. If not set or 0, the credentials will not expire.<br><br>**Default**: `0`<br><br>**Constraints**: `>= 0` |
| `readWrite` | `boolean \| undefined` | Query, Optional | By default, the registry credentials allow for read-only access. Set this query parameter to `true` to obtain read-write credentials.<br><br>**Default**: `false` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: A Docker `config.json` file for the container registry.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryDockerCredentialsResponse`](../../doc/models/v2-registry-docker-credentials-response.md).

## Example Usage

```ts
const expirySeconds = 3600;

const readWrite = true;

try {
  const response = await containerRegistryApi.registryGetDockerCredentials(
    expirySeconds,
    readWrite
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Get Options

This endpoint serves to provide additional information as to which option values are available when creating a container registry.
There are multiple subscription tiers available for container registry. Each tier allows a different number of image repositories to be created in your registry, and has a different amount of storage and transfer included.
There are multiple regions available for container registry and controls where your data is stored.
To list the available options, send a GET request to `/v2/registry/options`.

```ts
async registryGetOptions(
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryOptionsResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `options` which contains a key called `subscription_tiers` listing the available tiers.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryOptionsResponse`](../../doc/models/v2-registry-options-response.md).

## Example Usage

```ts
try {
  const response = await containerRegistryApi.registryGetOptions();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "options": {
    "available_regions": [
      "nyc3",
      "sfo3",
      "ams3",
      "sgp1",
      "fra1"
    ],
    "subscription_tiers": [
      {
        "allow_storage_overage": false,
        "eligibility_reasons": [
          "OverRepositoryLimit"
        ],
        "eligible": false,
        "included_bandwidth_bytes": 524288000,
        "included_repositories": 1,
        "included_storage_bytes": 524288000,
        "monthly_price_in_cents": 0,
        "name": "Starter",
        "slug": "starter"
      },
      {
        "allow_storage_overage": true,
        "eligible": true,
        "included_bandwidth_bytes": 5368709120,
        "included_repositories": 5,
        "included_storage_bytes": 5368709120,
        "monthly_price_in_cents": 500,
        "name": "Basic",
        "slug": "basic"
      },
      {
        "allow_storage_overage": true,
        "eligible": true,
        "included_bandwidth_bytes": 107374182400,
        "included_repositories": 0,
        "included_storage_bytes": 107374182400,
        "monthly_price_in_cents": 2000,
        "name": "Professional",
        "slug": "professional"
      }
    ]
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Get Subscription

A subscription is automatically created when you configure your container registry. To get information about your subscription, send a GET request to `/v2/registry/subscription`.

```ts
async registryGetSubscription(
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistrySubscriptionResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `subscription` containing information about your subscription.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistrySubscriptionResponse`](../../doc/models/v2-registry-subscription-response.md).

## Example Usage

```ts
try {
  const response = await containerRegistryApi.registryGetSubscription();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Update Subscription

After creating your registry, you can switch to a different subscription tier to better suit your needs. To do this, send a POST request to `/v2/registry/subscription`.

```ts
async registryUpdateSubscription(
  body?: V2RegistrySubscriptionRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistrySubscriptionResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2RegistrySubscriptionRequest \| undefined`](../../doc/models/v2-registry-subscription-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `subscription` containing information about your subscription.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistrySubscriptionResponse`](../../doc/models/v2-registry-subscription-response.md).

## Example Usage

```ts
const body: V2RegistrySubscriptionRequest = {
  tierSlug: TierSlug.Basic,
};

try {
  const response = await containerRegistryApi.registryUpdateSubscription(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Validate Name

To validate that a container registry name is available for use, send a POST
request to `/v2/registry/validate-name`.

If the name is both formatted correctly and available, the response code will
be 204 and contain no body. If the name is already in use, the response will
be a 409 Conflict.

```ts
async registryValidateName(
  body: V2RegistryValidateNameRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2RegistryValidateNameRequest`](../../doc/models/v2-registry-validate-name-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const body: V2RegistryValidateNameRequest = {
  name: 'example',
};

try {
  const response = await containerRegistryApi.registryValidateName(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 409 | Conflict | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Get Garbage Collection

To get information about the currently-active garbage collection for a registry, send a GET request to `/v2/registry/$REGISTRY_NAME/garbage-collection`.

```ts
async registryGetGarbageCollection(
  registryName: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryGarbageCollectionResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key of `garbage_collection`. This will be a json object with attributes representing the currently-active garbage collection.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryGarbageCollectionResponse`](../../doc/models/v2-registry-garbage-collection-response.md).

## Example Usage

```ts
const registryName = 'example';

try {
  const response = await containerRegistryApi.registryGetGarbageCollection(registryName);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Run Garbage Collection

Garbage collection enables users to clear out unreferenced blobs (layer &
manifest data) after deleting one or more manifests from a repository. If
there are no unreferenced blobs resulting from the deletion of one or more
manifests, garbage collection is effectively a noop.
[See here for more information](https://www.digitalocean.com/docs/container-registry/how-to/clean-up-container-registry/)
about how and why you should clean up your container registry periodically.

To request a garbage collection run on your registry, send a POST request to
`/v2/registry/$REGISTRY_NAME/garbage-collection`. This will initiate the
following sequence of events on your registry.

* Set the registry to read-only mode, meaning no further write-scoped
  JWTs will be issued to registry clients. Existing write-scoped JWTs will
  continue to work until they expire which can take up to 15 minutes.
* Wait until all existing write-scoped JWTs have expired.
* Scan all registry manifests to determine which blobs are unreferenced.
* Delete all unreferenced blobs from the registry.
* Record the number of blobs deleted and bytes freed, mark the garbage
  collection status as `success`.
* Remove the read-only mode restriction from the registry, meaning write-scoped
  JWTs will once again be issued to registry clients.

```ts
async registryRunGarbageCollection(
  registryName: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryGarbageCollectionResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The response will be a JSON object with a key of `garbage_collection`. This will be a json object with attributes representing the currently-active garbage collection.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryGarbageCollectionResponse`](../../doc/models/v2-registry-garbage-collection-response.md).

## Example Usage

```ts
const registryName = 'example';

try {
  const response = await containerRegistryApi.registryRunGarbageCollection(registryName);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Update Garbage Collection

To cancel the currently-active garbage collection for a registry, send a PUT request to `/v2/registry/$REGISTRY_NAME/garbage-collection/$GC_UUID` and specify one or more of the attributes below.

```ts
async registryUpdateGarbageCollection(
  registryName: string,
  garbageCollectionUuid: string,
  body: V2RegistryGarbageCollectionRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryGarbageCollectionResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `garbageCollectionUuid` | `string` | Template, Required | The UUID of a garbage collection run. |
| `body` | [`V2RegistryGarbageCollectionRequest`](../../doc/models/v2-registry-garbage-collection-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key of `garbage_collection`. This will be a json object with attributes representing the currently-active garbage collection.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryGarbageCollectionResponse`](../../doc/models/v2-registry-garbage-collection-response.md).

## Example Usage

```ts
const registryName = 'example';

const garbageCollectionUuid = 'eff0feee-49c7-4e8f-ba5c-a320c109c8a8';

const body: V2RegistryGarbageCollectionRequest = {
  cancel: true,
};

try {
  const response = await containerRegistryApi.registryUpdateGarbageCollection(
    registryName,
    garbageCollectionUuid,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry List Garbage Collections

To get information about past garbage collections for a registry, send a GET request to `/v2/registry/$REGISTRY_NAME/garbage-collections`.

```ts
async registryListGarbageCollections(
  registryName: string,
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryGarbageCollectionsResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key of `garbage_collections`. This will be set to an array containing objects representing each past garbage collection. Each will contain the standard Garbage Collection attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryGarbageCollectionsResponse`](../../doc/models/v2-registry-garbage-collections-response.md).

## Example Usage

```ts
const registryName = 'example';

const perPage = 2;

const page = 1;

try {
  const response = await containerRegistryApi.registryListGarbageCollections(
    registryName,
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "garbage_collections": [
    {
      "blobs_deleted": 42,
      "created_at": "2020-10-30T21:03:24.000Z",
      "freed_bytes": 667,
      "registry_name": "example",
      "status": "requested",
      "updated_at": "2020-10-30T21:03:44.000Z",
      "uuid": "eff0feee-49c7-4e8f-ba5c-a320c109c8a8"
    }
  ],
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry List Repositories

**This endpoint is deprecated.**

This endpoint has been deprecated in favor of the _List All Container Registry Repositories [V2]_ endpoint.

To list all repositories in your container registry, send a GET
request to `/v2/registry/$REGISTRY_NAME/repositories`.

```ts
async registryListRepositories(
  registryName: string,
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryRepositoriesResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response body will be a JSON object with a key of `repositories`. This will be set to an array containing objects each representing a repository.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryRepositoriesResponse`](../../doc/models/v2-registry-repositories-response.md).

## Example Usage

```ts
const registryName = 'example';

const perPage = 2;

const page = 1;

try {
  const response = await containerRegistryApi.registryListRepositories(
    registryName,
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry List Repositories V2

To list all repositories in your container registry, send a GET request to `/v2/registry/$REGISTRY_NAME/repositoriesV2`.

```ts
async registryListRepositoriesV2(
  registryName: string,
  perPage?: number,
  page?: number,
  pageToken?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryRepositoriesV2Response>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return. Ignored when 'page_token' is provided.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `pageToken` | `string \| undefined` | Query, Optional | Token to retrieve of the next or previous set of results more quickly than using 'page'. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response body will be a JSON object with a key of `repositories`. This will be set to an array containing objects each representing a repository.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryRepositoriesV2Response`](../../doc/models/v2-registry-repositories-v2-response.md).

## Example Usage

```ts
const registryName = 'example';

const perPage = 2;

const page = 1;

const pageToken = 'eyJUb2tlbiI6IkNnZGpiMjlz';

try {
  const response = await containerRegistryApi.registryListRepositoriesV2(
    registryName,
    perPage,
    page,
    pageToken
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry List Repository Manifests

To list all manifests in your container registry repository, send a GET
request to `/v2/registry/$REGISTRY_NAME/repositories/$REPOSITORY_NAME/digests`.

Note that if your repository name contains `/` characters, it must be
URL-encoded in the request URL. For example, to list manifests for
`registry.digitalocean.com/example/my/repo`, the path would be
`/v2/registry/example/repositories/my%2Frepo/digests`.

```ts
async registryListRepositoryManifests(
  registryName: string,
  repositoryName: string,
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryDigestsResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `repositoryName` | `string` | Template, Required | The name of a container registry repository. If the name contains `/` characters, they must be URL-encoded, e.g. `%2F`. |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response body will be a JSON object with a key of `manifests`. This will be set to an array containing objects each representing a manifest.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryDigestsResponse`](../../doc/models/v2-registry-digests-response.md).

## Example Usage

```ts
const registryName = 'example';

const repositoryName = 'repo-1';

const perPage = 2;

const page = 1;

try {
  const response = await containerRegistryApi.registryListRepositoryManifests(
    registryName,
    repositoryName,
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Delete Repository Manifest

To delete a container repository manifest by digest, send a DELETE request to
`/v2/registry/$REGISTRY_NAME/repositories/$REPOSITORY_NAME/digests/$MANIFEST_DIGEST`.

Note that if your repository name contains `/` characters, it must be
URL-encoded in the request URL. For example, to delete
`registry.digitalocean.com/example/my/repo@sha256:abcd`, the path would be
`/v2/registry/example/repositories/my%2Frepo/digests/sha256:abcd`.

A successful request will receive a 204 status code with no body in response.
This indicates that the request was processed successfully.

```ts
async registryDeleteRepositoryManifest(
  registryName: string,
  repositoryName: string,
  manifestDigest: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `repositoryName` | `string` | Template, Required | The name of a container registry repository. If the name contains `/` characters, they must be URL-encoded, e.g. `%2F`. |
| `manifestDigest` | `string` | Template, Required | The manifest digest of a container registry repository tag. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const registryName = 'example';

const repositoryName = 'repo-1';

const manifestDigest = 'sha256:cb8a924afdf0229ef7515d9e5b3024e23b3eb03ddbba287f4a19c6ac90b8d221';

try {
  const response = await containerRegistryApi.registryDeleteRepositoryManifest(
    registryName,
    repositoryName,
    manifestDigest
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry List Repository Tags

To list all tags in your container registry repository, send a GET
request to `/v2/registry/$REGISTRY_NAME/repositories/$REPOSITORY_NAME/tags`.

Note that if your repository name contains `/` characters, it must be
URL-encoded in the request URL. For example, to list tags for
`registry.digitalocean.com/example/my/repo`, the path would be
`/v2/registry/example/repositories/my%2Frepo/tags`.

```ts
async registryListRepositoryTags(
  registryName: string,
  repositoryName: string,
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2RegistryTagsResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `repositoryName` | `string` | Template, Required | The name of a container registry repository. If the name contains `/` characters, they must be URL-encoded, e.g. `%2F`. |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response body will be a JSON object with a key of `tags`. This will be set to an array containing objects each representing a tag.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2RegistryTagsResponse`](../../doc/models/v2-registry-tags-response.md).

## Example Usage

```ts
const registryName = 'example';

const repositoryName = 'repo-1';

const perPage = 2;

const page = 1;

try {
  const response = await containerRegistryApi.registryListRepositoryTags(
    registryName,
    repositoryName,
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Registry Delete Repository Tag

To delete a container repository tag, send a DELETE request to
`/v2/registry/$REGISTRY_NAME/repositories/$REPOSITORY_NAME/tags/$TAG`.

Note that if your repository name contains `/` characters, it must be
URL-encoded in the request URL. For example, to delete
`registry.digitalocean.com/example/my/repo:mytag`, the path would be
`/v2/registry/example/repositories/my%2Frepo/tags/mytag`.

A successful request will receive a 204 status code with no body in response.
This indicates that the request was processed successfully.

```ts
async registryDeleteRepositoryTag(
  registryName: string,
  repositoryName: string,
  repositoryTag: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registryName` | `string` | Template, Required | The name of a container registry. |
| `repositoryName` | `string` | Template, Required | The name of a container registry repository. If the name contains `/` characters, they must be URL-encoded, e.g. `%2F`. |
| `repositoryTag` | `string` | Template, Required | The name of a container registry repository tag. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const registryName = 'example';

const repositoryName = 'repo-1';

const repositoryTag = '06a447a';

try {
  const response = await containerRegistryApi.registryDeleteRepositoryTag(
    registryName,
    repositoryName,
    repositoryTag
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |

