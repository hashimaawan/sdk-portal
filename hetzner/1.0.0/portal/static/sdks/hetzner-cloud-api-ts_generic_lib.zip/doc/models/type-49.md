
# Type 49

The type of the Primary IP

## Enumeration

`Type49`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type49 } from 'hetzner-cloud-apilib';

const type49 = Type49.Ipv4;
```

