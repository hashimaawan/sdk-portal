
# Phase 1

## Enumeration

`Phase1`

## Fields

| Name |
|  --- |
| `Unknown` |
| `Pending` |
| `Configuring` |
| `Active` |
| `Error` |

## Example

```ts
import { Phase1 } from 'digitalocean-apilib';

const phase1 = Phase1.Error;
```

