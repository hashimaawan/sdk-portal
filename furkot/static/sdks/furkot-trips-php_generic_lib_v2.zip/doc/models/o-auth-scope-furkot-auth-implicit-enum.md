
# O Auth Scope Furkot Auth Implicit Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthImplicitEnum`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list users trips info |

## Example

```php
use FurkotTripsLib\Models\OAuthScopeFurkotAuthImplicitEnum;

$oAuthScopeFurkotAuthImplicit = OAuthScopeFurkotAuthImplicitEnum::READTRIPS;
```

