
# Oauth Scope Furkot Auth Access Code

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthAccessCode`

## Fields

| Name | Description |
|  --- | --- |
| `Readtrips` | list trips and stops info |

## Example

```ts
import { OauthScopeFurkotAuthAccessCode } from 'furkot-tripslib';

const oauthScopeFurkotAuthAccessCode = OauthScopeFurkotAuthAccessCode.Readtrips;
```

