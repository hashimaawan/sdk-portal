
# Image 3

The cost of Image per GB/month

## Structure

`Image3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price_per_gb_month` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - |

## Example

```python
from hetznercloudapi.models.image_3 import Image3
from hetznercloudapi.models.price_per_gb_month import PricePerGbMonth

image_3 = Image3(
    price_per_gb_month=PricePerGbMonth(
        gross='1.1900000000000000',
        net='1.0000000000'
    )
)
```

