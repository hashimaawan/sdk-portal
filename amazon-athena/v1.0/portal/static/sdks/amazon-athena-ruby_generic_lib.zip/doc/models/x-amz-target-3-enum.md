
# X Amz Target 3 Enum

## Enumeration

`XAmzTarget3Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEDATACATALOG` |

## Example

```ruby
x_amz_target3 = XAmzTarget3Enum::ENUM_AMAZONATHENACREATEDATACATALOG
```

