
# Server Public Net Firewall

## Structure

`ServerPublicNetFirewall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number \| undefined` | Optional | ID of the Resource |
| `status` | [`Status72Enum \| undefined`](../../doc/models/status-72-enum.md) | Optional | Status of the Firewall on the Server |

## Example

```ts
import { ServerPublicNetFirewall, Status72Enum } from 'hetzner-cloud-apilib';

const serverPublicNetFirewall: ServerPublicNetFirewall = {
  id: 42,
  status: Status72Enum.Applied,
};
```

