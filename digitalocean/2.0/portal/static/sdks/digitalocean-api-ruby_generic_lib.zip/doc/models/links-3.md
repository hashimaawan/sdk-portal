
# Links 3

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Links3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `actions` | [`Array[Action1]`](../../doc/models/action-1.md) | Optional | - |
| `droplets` | [`Array[Action1]`](../../doc/models/action-1.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
links3 = Links3.new(
  actions: [
    Action1.new(
      href: 'href0',
      id: 154,
      rel: 'rel4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Action1.new(
      href: 'href0',
      id: 154,
      rel: 'rel4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  droplets: [
    Action1.new(
      href: 'href2',
      id: 232,
      rel: 'rel6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Action1.new(
      href: 'href2',
      id: 232,
      rel: 'rel6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Action1.new(
      href: 'href2',
      id: 232,
      rel: 'rel6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

