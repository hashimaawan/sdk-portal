
# Change Loadbalancer Dns Ptr Request

## Structure

`ChangeLoadbalancerDnsPtrRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dnsPtr` | `?string` | Required | Hostname to set as a reverse DNS PTR entry | getDnsPtr(): ?string | setDnsPtr(?string dnsPtr): void |
| `ip` | `string` | Required | Public IP address for which the reverse DNS entry should be set | getIp(): string | setIp(string ip): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ChangeLoadbalancerDnsPtrRequestBuilder;

$changeLoadbalancerDnsPtrRequest = ChangeLoadbalancerDnsPtrRequestBuilder::init(
    '1.2.3.4'
)
    ->dnsPtr('lb1.example.com')
    ->build();
```

