
# X Amz Target 15 Enum

## Enumeration

`XAmzTarget15Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget15Enum;

XAmzTarget15Enum xAmzTarget15 = XAmzTarget15Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTION;
```

