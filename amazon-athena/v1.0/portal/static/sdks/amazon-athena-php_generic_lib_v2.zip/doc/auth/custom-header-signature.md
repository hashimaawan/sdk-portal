
# Custom Header Signature



Documentation for accessing and setting credentials for hmac.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| Authorization | `string` | Amazon Signature authorization v4 | `authorization` | `getAuthorization()` |



**Note:** Auth credentials can be set using `CustomHeaderAuthenticationCredentialsBuilder::init()` in `customHeaderAuthenticationCredentials` method in the client builder and accessed through `getCustomHeaderAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```php
use AmazonAthenaLib\Authentication\CustomHeaderAuthenticationCredentialsBuilder;
use AmazonAthenaLib\AmazonAthenaClientBuilder;

$client = AmazonAthenaClientBuilder::init()
    ->customHeaderAuthenticationCredentials(
        CustomHeaderAuthenticationCredentialsBuilder::init(
            'Authorization'
        )
    )
    ->build();
```


