
# Volumes Actions Resize Request

## Structure

`VolumesActionsResizeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Size` | `double` | Required | New Volume size in GB (must be greater than current size) |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

VolumesActionsResizeRequest volumesActionsResizeRequest = new VolumesActionsResizeRequest
{
    Size = 50,
};
```

