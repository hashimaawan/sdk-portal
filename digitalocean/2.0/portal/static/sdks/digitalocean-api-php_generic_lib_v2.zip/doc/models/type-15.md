
# Type 15

The action to be taken on the image. Can be either `convert` or `transfer`.

## Enumeration

`Type15`

## Fields

| Name |
|  --- |
| `CONVERT` |
| `TRANSFER` |

## Example

```php
use DigitalOceanApiLib\Models\Type15;

$type15 = Type15::CONVERT;
```

