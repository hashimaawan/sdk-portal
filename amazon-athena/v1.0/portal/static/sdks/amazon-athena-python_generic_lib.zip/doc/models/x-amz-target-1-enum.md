
# X Amz Target 1 Enum

## Enumeration

`XAmzTarget1Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_1_enum import XAmzTarget1Enum

x_amz_target_1 = XAmzTarget1Enum.ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT
```

