
# Get Calculation Execution Status Response

## Structure

`GetCalculationExecutionStatusResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | [`?Status1`](../../doc/models/status-1.md) | Optional | - | getStatus(): ?Status1 | setStatus(?Status1 status): void |
| `statistics` | [`?Statistics1`](../../doc/models/statistics-1.md) | Optional | - | getStatistics(): ?Statistics1 | setStatistics(?Statistics1 statistics): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetCalculationExecutionStatusResponseBuilder;
use AmazonAthenaLib\Models\Builders\Status1Builder;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\Models\CalculationExecutionState1Enum;
use AmazonAthenaLib\Models\Builders\Statistics1Builder;

$getCalculationExecutionStatusResponse = GetCalculationExecutionStatusResponseBuilder::init()
    ->status(
        Status1Builder::init()
            ->submissionDateTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->completionDateTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->state(CalculationExecutionState1Enum::CANCELING)
            ->stateChangeReason('StateChangeReason8')
            ->build()
    )
    ->statistics(
        Statistics1Builder::init()
            ->dpuExecutionInMillis(164)
            ->progress('Progress6')
            ->build()
    )
    ->build();
```

