
# Data Catalog Type 2 Enum

The data catalog type.

## Enumeration

`DataCatalogType2Enum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```ts
import { DataCatalogType2Enum } from 'amazon-athenalib';

const dataCatalogType2 = DataCatalogType2Enum.LAMBDA;
```

