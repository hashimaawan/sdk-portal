
# Type 5

The object type.

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `AUDIO_FEATURES` |

## Example

```ruby
type5 = Type5::AUDIO_FEATURES
```

