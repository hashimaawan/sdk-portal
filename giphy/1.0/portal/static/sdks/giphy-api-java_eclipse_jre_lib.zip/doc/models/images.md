
# Images

An object containing data for various available formats and sizes of this GIF.

*This model accepts additional fields of type Object.*

## Structure

`Images`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Downsized` | [`Image`](../../doc/models/image.md) | Optional | - | Image getDownsized() | setDownsized(Image downsized) |
| `DownsizedLarge` | [`Image`](../../doc/models/image.md) | Optional | - | Image getDownsizedLarge() | setDownsizedLarge(Image downsizedLarge) |
| `DownsizedMedium` | [`Image`](../../doc/models/image.md) | Optional | - | Image getDownsizedMedium() | setDownsizedMedium(Image downsizedMedium) |
| `DownsizedSmall` | [`Image`](../../doc/models/image.md) | Optional | - | Image getDownsizedSmall() | setDownsizedSmall(Image downsizedSmall) |
| `DownsizedStill` | [`Image`](../../doc/models/image.md) | Optional | - | Image getDownsizedStill() | setDownsizedStill(Image downsizedStill) |
| `FixedHeight` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedHeight() | setFixedHeight(Image fixedHeight) |
| `FixedHeightDownsampled` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedHeightDownsampled() | setFixedHeightDownsampled(Image fixedHeightDownsampled) |
| `FixedHeightSmall` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedHeightSmall() | setFixedHeightSmall(Image fixedHeightSmall) |
| `FixedHeightSmallStill` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedHeightSmallStill() | setFixedHeightSmallStill(Image fixedHeightSmallStill) |
| `FixedHeightStill` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedHeightStill() | setFixedHeightStill(Image fixedHeightStill) |
| `FixedWidth` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedWidth() | setFixedWidth(Image fixedWidth) |
| `FixedWidthDownsampled` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedWidthDownsampled() | setFixedWidthDownsampled(Image fixedWidthDownsampled) |
| `FixedWidthSmall` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedWidthSmall() | setFixedWidthSmall(Image fixedWidthSmall) |
| `FixedWidthSmallStill` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedWidthSmallStill() | setFixedWidthSmallStill(Image fixedWidthSmallStill) |
| `FixedWidthStill` | [`Image`](../../doc/models/image.md) | Optional | - | Image getFixedWidthStill() | setFixedWidthStill(Image fixedWidthStill) |
| `Looping` | [`Image`](../../doc/models/image.md) | Optional | - | Image getLooping() | setLooping(Image looping) |
| `Original` | [`Image`](../../doc/models/image.md) | Optional | - | Image getOriginal() | setOriginal(Image original) |
| `OriginalStill` | [`Image`](../../doc/models/image.md) | Optional | - | Image getOriginalStill() | setOriginalStill(Image originalStill) |
| `Preview` | [`Image`](../../doc/models/image.md) | Optional | - | Image getPreview() | setPreview(Image preview) |
| `PreviewGif` | [`Image`](../../doc/models/image.md) | Optional | - | Image getPreviewGif() | setPreviewGif(Image previewGif) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.giphy.api.ApiHelper;
import com.giphy.api.models.Image;
import com.giphy.api.models.Images;
import java.io.IOException;

Images images = new Images.Builder()
    .downsized(new Image.Builder()
        .frames("frames0")
        .height("height8")
        .mp4("mp40")
        .mp4Size("mp4_size2")
        .size("size2")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .downsizedLarge(new Image.Builder()
        .frames("frames6")
        .height("height4")
        .mp4("mp46")
        .mp4Size("mp4_size8")
        .size("size8")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .downsizedMedium(new Image.Builder()
        .frames("frames2")
        .height("height0")
        .mp4("mp42")
        .mp4Size("mp4_size4")
        .size("size4")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .downsizedSmall(new Image.Builder()
        .frames("frames0")
        .height("height8")
        .mp4("mp40")
        .mp4Size("mp4_size2")
        .size("size2")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
    .downsizedStill(new Image.Builder()
        .frames("frames4")
        .height("height4")
        .mp4("mp46")
        .mp4Size("mp4_size8")
        .size("size2")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

