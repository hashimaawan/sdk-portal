
# Alert

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Alert`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `disabled` | `boolean \| undefined` | Optional | Is the alert disabled? |
| `operator` | [`Operator \| undefined`](../../doc/models/operator.md) | Optional | **Default**: `Operator.UnspecifiedOperator` |
| `rule` | [`Rule \| undefined`](../../doc/models/rule.md) | Optional | **Default**: `Rule.UnspecifiedRule` |
| `value` | `number \| undefined` | Optional | Threshold value for alert |
| `window` | [`Window \| undefined`](../../doc/models/window.md) | Optional | **Default**: `Window.UnspecifiedWindow` |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Alert, Operator, Rule, Window } from 'digitalocean-apilib';

const alert: Alert = {
  disabled: false,
  operator: Operator.GreaterThan,
  rule: Rule.CpuUtilization,
  value: 2.32,
  window: Window.FiveMinutes,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

