
# List Notebook Metadata Input

## Structure

`ListNotebookMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Filters` | [`*models.Filters`](../../doc/models/filters.md) | Optional | - |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 50` |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listNotebookMetadataInput := models.ListNotebookMetadataInput{
        Filters:              models.ToPointer(models.Filters{
            Name:                 models.ToPointer("Name2"),
        }),
        NextToken:            models.ToPointer("NextToken2"),
        MaxResults:           models.ToPointer(50),
        WorkGroup:            "WorkGroup4",
    }

}
```

