
# Type 21 Enum

## Enumeration

`Type21Enum`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```python
from hetznercloudapi.models.type_21_enum import Type21Enum

type_21 = Type21Enum.BACKUP
```

