
# Data Catalog Type 2 Enum

The data catalog type.

## Enumeration

`DataCatalogType2Enum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```java
import com.amazonaws.useast1.athena.models.DataCatalogType2Enum;

DataCatalogType2Enum dataCatalogType2 = DataCatalogType2Enum.LAMBDA;
```

