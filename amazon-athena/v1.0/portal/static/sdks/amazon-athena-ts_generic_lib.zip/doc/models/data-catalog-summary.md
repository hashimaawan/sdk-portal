
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalogName` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `type` | [`DataCatalogType2Enum \| undefined`](../../doc/models/data-catalog-type-2-enum.md) | Optional | - |

## Example

```ts
import { DataCatalogSummary, DataCatalogType2Enum } from 'amazon-athenalib';

const dataCatalogSummary: DataCatalogSummary = {
  catalogName: 'CatalogName2',
  type: DataCatalogType2Enum.HIVE,
};
```

