
# Volume

The cost of Volume per GB/month

## Structure

`Volume`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price_per_gb_month` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - |

## Example

```python
from hetznercloudapi.models.price_per_gb_month import PricePerGbMonth
from hetznercloudapi.models.volume import Volume

volume = Volume(
    price_per_gb_month=PricePerGbMonth(
        gross='1.1900000000000000',
        net='1.0000000000'
    )
)
```

