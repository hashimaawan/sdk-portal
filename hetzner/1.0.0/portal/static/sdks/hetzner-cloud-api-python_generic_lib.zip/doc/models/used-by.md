
# Used By

*This model accepts additional fields of type Any.*

## Structure

`UsedBy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of resource referenced |
| `mtype` | `str` | Required | Type of resource referenced |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.used_by import UsedBy

used_by = UsedBy(
    id=4711,
    mtype='load_balancer',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

