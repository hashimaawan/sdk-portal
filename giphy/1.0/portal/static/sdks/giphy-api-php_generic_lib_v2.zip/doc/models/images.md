
# Images

An object containing data for various available formats and sizes of this GIF.

*This model accepts additional fields of type array.*

## Structure

`Images`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `downsized` | [`?Image`](../../doc/models/image.md) | Optional | - | getDownsized(): ?Image | setDownsized(?Image downsized): void |
| `downsizedLarge` | [`?Image`](../../doc/models/image.md) | Optional | - | getDownsizedLarge(): ?Image | setDownsizedLarge(?Image downsizedLarge): void |
| `downsizedMedium` | [`?Image`](../../doc/models/image.md) | Optional | - | getDownsizedMedium(): ?Image | setDownsizedMedium(?Image downsizedMedium): void |
| `downsizedSmall` | [`?Image`](../../doc/models/image.md) | Optional | - | getDownsizedSmall(): ?Image | setDownsizedSmall(?Image downsizedSmall): void |
| `downsizedStill` | [`?Image`](../../doc/models/image.md) | Optional | - | getDownsizedStill(): ?Image | setDownsizedStill(?Image downsizedStill): void |
| `fixedHeight` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedHeight(): ?Image | setFixedHeight(?Image fixedHeight): void |
| `fixedHeightDownsampled` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedHeightDownsampled(): ?Image | setFixedHeightDownsampled(?Image fixedHeightDownsampled): void |
| `fixedHeightSmall` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedHeightSmall(): ?Image | setFixedHeightSmall(?Image fixedHeightSmall): void |
| `fixedHeightSmallStill` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedHeightSmallStill(): ?Image | setFixedHeightSmallStill(?Image fixedHeightSmallStill): void |
| `fixedHeightStill` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedHeightStill(): ?Image | setFixedHeightStill(?Image fixedHeightStill): void |
| `fixedWidth` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedWidth(): ?Image | setFixedWidth(?Image fixedWidth): void |
| `fixedWidthDownsampled` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedWidthDownsampled(): ?Image | setFixedWidthDownsampled(?Image fixedWidthDownsampled): void |
| `fixedWidthSmall` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedWidthSmall(): ?Image | setFixedWidthSmall(?Image fixedWidthSmall): void |
| `fixedWidthSmallStill` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedWidthSmallStill(): ?Image | setFixedWidthSmallStill(?Image fixedWidthSmallStill): void |
| `fixedWidthStill` | [`?Image`](../../doc/models/image.md) | Optional | - | getFixedWidthStill(): ?Image | setFixedWidthStill(?Image fixedWidthStill): void |
| `looping` | [`?Image`](../../doc/models/image.md) | Optional | - | getLooping(): ?Image | setLooping(?Image looping): void |
| `original` | [`?Image`](../../doc/models/image.md) | Optional | - | getOriginal(): ?Image | setOriginal(?Image original): void |
| `originalStill` | [`?Image`](../../doc/models/image.md) | Optional | - | getOriginalStill(): ?Image | setOriginalStill(?Image originalStill): void |
| `preview` | [`?Image`](../../doc/models/image.md) | Optional | - | getPreview(): ?Image | setPreview(?Image preview): void |
| `previewGif` | [`?Image`](../../doc/models/image.md) | Optional | - | getPreviewGif(): ?Image | setPreviewGif(?Image previewGif): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use GiphyApiLib\Models\Builders\ImagesBuilder;
use GiphyApiLib\Models\Builders\ImageBuilder;
use GiphyApiLib\ApiHelper;

$images = ImagesBuilder::init()
    ->downsized(
        ImageBuilder::init()
            ->frames('frames0')
            ->height('height8')
            ->mp4('mp40')
            ->mp4Size('mp4_size2')
            ->size('size2')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->downsizedLarge(
        ImageBuilder::init()
            ->frames('frames6')
            ->height('height4')
            ->mp4('mp46')
            ->mp4Size('mp4_size8')
            ->size('size8')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->downsizedMedium(
        ImageBuilder::init()
            ->frames('frames2')
            ->height('height0')
            ->mp4('mp42')
            ->mp4Size('mp4_size4')
            ->size('size4')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->downsizedSmall(
        ImageBuilder::init()
            ->frames('frames0')
            ->height('height8')
            ->mp4('mp40')
            ->mp4Size('mp4_size2')
            ->size('size2')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->downsizedStill(
        ImageBuilder::init()
            ->frames('frames4')
            ->height('height4')
            ->mp4('mp46')
            ->mp4Size('mp4_size8')
            ->size('size2')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

