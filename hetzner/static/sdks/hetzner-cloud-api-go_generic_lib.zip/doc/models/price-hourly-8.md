
# Price Hourly 8

Hourly costs for a Server type in this Location

## Structure

`PriceHourly8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    priceHourly8 := models.PriceHourly8{
        Gross:                "1.1900000000000000",
        Net:                  "1.0000000000",
    }

}
```

