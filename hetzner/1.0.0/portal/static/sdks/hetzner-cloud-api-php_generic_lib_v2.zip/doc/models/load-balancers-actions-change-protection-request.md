
# Load Balancers Actions Change Protection Request

## Structure

`LoadBalancersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `delete` | `?bool` | Optional | If true, prevents the Load Balancer from being deleted | getDelete(): ?bool | setDelete(?bool delete): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LoadBalancersActionsChangeProtectionRequestBuilder;

$loadBalancersActionsChangeProtectionRequest = LoadBalancersActionsChangeProtectionRequestBuilder::init()
    ->delete(true)
    ->build();
```

