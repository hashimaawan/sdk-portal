
# Load Balancers Response 1

## Structure

`LoadBalancersResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Action` | [`Action`](../../doc/models/action.md) | Required | - |
| `LoadBalancer` | [`LoadBalancer`](../../doc/models/load-balancer.md) | Required | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

LoadBalancersResponse1 loadBalancersResponse1 = new LoadBalancersResponse1
{
    Action = new Action
    {
        Command = "start_server",
        Error = new Error
        {
            Code = "action_failed",
            Message = "Action failed",
        },
        Finished = "2016-01-30T23:55:00+00:00",
        Id = 42,
        Progress = 100,
        Resources = new List<Resource>
        {
            new Resource
            {
                Id = 42,
                Type = "server",
            },
        },
        Started = "2016-01-30T23:55:00+00:00",
        Status = StatusEnum.Running,
    },
    LoadBalancer = new LoadBalancer
    {
        Algorithm = new Algorithm
        {
            Type = Type28Enum.RoundRobin,
        },
        Created = "2016-01-30T23:55:00+00:00",
        Id = 42,
        IncludedTraffic = 10000,
        IngoingTraffic = 216,
        Labels = new Dictionary<string, string>
        {
            ["key0"] = "labels2",
            ["key1"] = "labels1",
        },
        LoadBalancerType = new LoadBalancerType
        {
            Deprecated = "2016-01-30T23:50:00+00:00",
            Description = "LB11",
            Id = 1,
            MaxAssignedCertificates = 10,
            MaxConnections = 20000,
            MaxServices = 5,
            MaxTargets = 25,
            Name = "lb11",
            Prices = new List<Price>
            {
                new Price
                {
                    Location = "fsn1",
                    PriceHourly = new PriceHourly
                    {
                        Gross = "1.1900000000000000",
                        Net = "1.0000000000",
                    },
                    PriceMonthly = new PriceMonthly
                    {
                        Gross = "1.1900000000000000",
                        Net = "1.0000000000",
                    },
                },
            },
        },
        Location = new Location
        {
            City = "Falkenstein",
            Country = "DE",
            Description = "Falkenstein DC Park 1",
            Id = 1,
            Latitude = 50.47612,
            Longitude = 12.370071,
            Name = "fsn1",
            NetworkZone = "eu-central",
        },
        Name = "my-resource",
        OutgoingTraffic = 42,
        PrivateNet = new List<PrivateNet>
        {
            new PrivateNet
            {
                Ip = "10.0.0.2",
                Network = 4711,
            },
        },
        Protection = new Protection
        {
            Delete = false,
        },
        PublicNet = new PublicNet
        {
            Enabled = false,
            Ipv4 = new Ipv4
            {
                DnsPtr = "lb1.example.com",
                Ip = "1.2.3.4",
            },
            Ipv6 = new Ipv6
            {
                DnsPtr = "lb1.example.com",
                Ip = "2001:db8::1",
            },
        },
        Services = new List<LoadBalancerService>
        {
            new LoadBalancerService
            {
                DestinationPort = 80,
                HealthCheck = new LoadBalancerServiceHealthCheck
                {
                    Interval = 15,
                    Port = 4711,
                    Protocol = Protocol6Enum.Http,
                    Retries = 3,
                    Timeout = 10,
                    Http = new Http
                    {
                        Domain = "domain4",
                        Path = "path2",
                        Response = "response8",
                        StatusCodes = new List<string>
                        {
                            "status_codes0",
                            "status_codes1",
                            "status_codes2",
                        },
                        Tls = false,
                    },
                },
                ListenPort = 443,
                Protocol = Protocol7Enum.Https,
                Proxyprotocol = false,
                Http = new LoadBalancerServiceHTTP
                {
                    Certificates = new List<int>
                    {
                        180,
                    },
                    CookieLifetime = 160,
                    CookieName = "cookie_name6",
                    RedirectHttp = false,
                    StickySessions = false,
                },
            },
        },
        Targets = new List<LoadBalancerTarget>
        {
            new LoadBalancerTarget
            {
                Type = Type29Enum.Ip,
                HealthStatus = new List<HealthStatus>
                {
                    new HealthStatus
                    {
                        ListenPort = 142,
                        Status = Status30Enum.Unknown,
                    },
                    new HealthStatus
                    {
                        ListenPort = 142,
                        Status = Status30Enum.Unknown,
                    },
                },
                Ip = new Ip
                {
                    Ip = "ip8",
                },
                LabelSelector = new LabelSelector7
                {
                    Selector = "selector8",
                },
                Server = new LoadBalancerTargetServer
                {
                    Id = 14,
                },
                Targets = new List<Target>
                {
                    new Target
                    {
                        HealthStatus = new List<HealthStatus>
                        {
                            new HealthStatus
                            {
                                ListenPort = 142,
                                Status = Status30Enum.Unknown,
                            },
                            new HealthStatus
                            {
                                ListenPort = 142,
                                Status = Status30Enum.Unknown,
                            },
                        },
                        Server = new Server11
                        {
                            Id = 14,
                        },
                        Type = "type2",
                        UsePrivateIp = false,
                    },
                    new Target
                    {
                        HealthStatus = new List<HealthStatus>
                        {
                            new HealthStatus
                            {
                                ListenPort = 142,
                                Status = Status30Enum.Unknown,
                            },
                            new HealthStatus
                            {
                                ListenPort = 142,
                                Status = Status30Enum.Unknown,
                            },
                        },
                        Server = new Server11
                        {
                            Id = 14,
                        },
                        Type = "type2",
                        UsePrivateIp = false,
                    },
                    new Target
                    {
                        HealthStatus = new List<HealthStatus>
                        {
                            new HealthStatus
                            {
                                ListenPort = 142,
                                Status = Status30Enum.Unknown,
                            },
                            new HealthStatus
                            {
                                ListenPort = 142,
                                Status = Status30Enum.Unknown,
                            },
                        },
                        Server = new Server11
                        {
                            Id = 14,
                        },
                        Type = "type2",
                        UsePrivateIp = false,
                    },
                },
            },
        },
    },
};
```

