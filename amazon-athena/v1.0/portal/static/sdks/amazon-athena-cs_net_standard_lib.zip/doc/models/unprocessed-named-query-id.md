
# Unprocessed Named Query Id

Information about a named query ID that could not be processed.

## Structure

`UnprocessedNamedQueryId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueryId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `ErrorCode` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ErrorMessage` | `string` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

UnprocessedNamedQueryId unprocessedNamedQueryId = new UnprocessedNamedQueryId
{
    NamedQueryId = "NamedQueryId0",
    ErrorCode = "ErrorCode8",
    ErrorMessage = "ErrorMessage8",
};
```

