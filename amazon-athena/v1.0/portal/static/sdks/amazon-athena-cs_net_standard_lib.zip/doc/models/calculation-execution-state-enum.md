
# Calculation Execution State Enum

## Enumeration

`CalculationExecutionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `QUEUED` |
| `RUNNING` |
| `CANCELING` |
| `CANCELED` |
| `COMPLETED` |
| `FAILED` |

## Example

```csharp
using AmazonAthena.Standard.Models;

CalculationExecutionStateEnum calculationExecutionState = CalculationExecutionStateEnum.COMPLETED;
```

