
# Type 39 Enum

Algorithm of the Load Balancer

## Enumeration

`Type39Enum`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```ts
import { Type39Enum } from 'hetzner-cloud-apilib';

const type39 = Type39Enum.RoundRobin;
```

