
# V2 Apps Response 2

*This model accepts additional fields of type Object.*

## Structure

`V2AppsResponse2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | - | String getId() | setId(String id) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.V2AppsResponse2;
import java.io.IOException;

V2AppsResponse2 v2AppsResponse2 = new V2AppsResponse2.Builder()
    .id("4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

