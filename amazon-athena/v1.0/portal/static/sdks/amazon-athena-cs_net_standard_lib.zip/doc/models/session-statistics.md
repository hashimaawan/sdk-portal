
# Session Statistics

Contains statistics for a session.

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DpuExecutionInMillis` | `int?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

SessionStatistics sessionStatistics = new SessionStatistics
{
    DpuExecutionInMillis = 188,
};
```

