
# Traffic

The cost of additional traffic per TB

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PricePerTb` | [`PricePerTb`](../../doc/models/price-per-tb.md) | Required | - | PricePerTb getPricePerTb() | setPricePerTb(PricePerTb pricePerTb) |

## Example

```java
import cloud.hetzner.api.models.PricePerTb;
import cloud.hetzner.api.models.Traffic;

Traffic traffic = new Traffic.Builder(
    new PricePerTb.Builder(
        "1.1900000000000000",
        "1.0000000000"
    )
    .build()
)
.build();
```

