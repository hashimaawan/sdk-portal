
# Application Dpu Sizes

Contains the application runtime IDs and their supported DPU sizes.

*This model accepts additional fields of type unknown.*

## Structure

`ApplicationDpuSizes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applicationRuntimeId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `supportedDpuSizes` | `number[] \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ApplicationDpuSizes } from 'amazon-athenalib';

const applicationDpuSizes: ApplicationDpuSizes = {
  applicationRuntimeId: 'ApplicationRuntimeId4',
  supportedDpuSizes: [
    17,
    18
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

