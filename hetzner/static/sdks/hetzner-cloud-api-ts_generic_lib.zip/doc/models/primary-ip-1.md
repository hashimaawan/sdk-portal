
# Primary IP 1

## Structure

`PrimaryIP1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `assigneeId` | `number \| null` | Required | ID of the resource the Primary IP is assigned to, null if it is not assigned at all |
| `assigneeType` | `string` | Required, Constant | Resource type the Primary IP can be assigned to<br><br>**Value**: `'server'` |
| `autoDelete` | `boolean` | Required | Delete this Primary IP when the resource it is assigned to is deleted |
| `blocked` | `boolean` | Required | Whether the IP is blocked |
| `created` | `string` | Required | Point in time when the Resource was created (in ISO-8601 format) |
| `datacenter` | [`Datacenter2`](../../doc/models/datacenter-2.md) | Required | Datacenter this Primary IP is located at |
| `dnsPtr` | [`DnsPtr[]`](../../doc/models/dns-ptr.md) | Required | Array of reverse DNS entries |
| `id` | `number` | Required | ID of the Resource |
| `ip` | `string` | Required | IP address |
| `labels` | `Record<string, string>` | Required | User-defined labels (key-value pairs) |
| `name` | `string` | Required | Name of the Resource. Must be unique per Project. |
| `protection` | [`Protection`](../../doc/models/protection.md) | Required | Protection configuration for the Resource |
| `type` | [`Type50Enum`](../../doc/models/type-50-enum.md) | Required | Type of the Primary IP |

## Example

```ts
import { PrimaryIP1, Type50Enum } from 'hetzner-cloud-apilib';

const primaryIP1: PrimaryIP1 = {
  assigneeId: 17,
  assigneeType: 'server',
  autoDelete: true,
  blocked: false,
  created: '2016-01-30T23:55:00+00:00',
  datacenter: {
    description: 'Falkenstein DC Park 8',
    id: 42,
    location: {
      city: 'Falkenstein',
      country: 'DE',
      description: 'Falkenstein DC Park 1',
      id: 1,
      latitude: 50.47612,
      longitude: 12.370071,
      name: 'fsn1',
      networkZone: 'eu-central',
    },
    name: 'fsn1-dc8',
    serverTypes: {
      available: [
        1,
        2,
        3
      ],
      availableForMigration: [
        1,
        2,
        3
      ],
      supported: [
        1,
        2,
        3
      ],
    },
  },
  dnsPtr: [
    {
      dnsPtr: 'server.example.com',
      ip: '2001:db8::1',
    }
  ],
  id: 42,
  ip: '131.232.99.1',
  labels: {
    'key0': 'labels4',
    'key1': 'labels3'
  },
  name: 'my-resource',
  protection: {
    mDelete: false,
  },
  type: Type50Enum.Ipv4,
};
```

