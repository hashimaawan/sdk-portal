
# Type 50

Type of the Primary IP

## Enumeration

`Type50`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type50 } from 'hetzner-cloud-apilib';

const type50 = Type50.Ipv4;
```

