
# Volumes Actions Resize Request

*This model accepts additional fields of type unknown.*

## Structure

`VolumesActionsResizeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `size` | `number` | Required | New Volume size in GB (must be greater than current size) |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { VolumesActionsResizeRequest } from 'hetzner-cloud-apilib';

const volumesActionsResizeRequest: VolumesActionsResizeRequest = {
  size: 50,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

