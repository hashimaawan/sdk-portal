# Uptime

[DigitalOcean Uptime Checks](https://docs.digitalocean.com/products/uptime/) provide the ability to monitor your endpoints from around the world, and alert you when they're slow, unavailable, or SSL certificates are expiring.
To interact with Uptime, you will generally send requests to the Uptime endpoint at `/v2/uptime/`.

```ts
const uptimeApi = new UptimeApi(client);
```

## Class Name

`UptimeApi`

## Methods

* [Uptime Checks List](../../doc/controllers/uptime.md#uptime-checks-list)
* [Uptime Check Create](../../doc/controllers/uptime.md#uptime-check-create)
* [Uptime Check Delete](../../doc/controllers/uptime.md#uptime-check-delete)
* [Uptime Check Get](../../doc/controllers/uptime.md#uptime-check-get)
* [Uptime Check Update](../../doc/controllers/uptime.md#uptime-check-update)
* [Uptime Check Alerts List](../../doc/controllers/uptime.md#uptime-check-alerts-list)
* [Uptime Alert Create](../../doc/controllers/uptime.md#uptime-alert-create)
* [Uptime Alert Delete](../../doc/controllers/uptime.md#uptime-alert-delete)
* [Uptime Alert Get](../../doc/controllers/uptime.md#uptime-alert-get)
* [Uptime Alert Update](../../doc/controllers/uptime.md#uptime-alert-update)
* [Uptime Check State Get](../../doc/controllers/uptime.md#uptime-check-state-get)


# Uptime Checks List

To list all of the Uptime checks on your account, send a GET request to `/v2/uptime/checks`.

```ts
async uptimeChecksList(
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `checks`. This will be set to an array of objects, each of which will contain the standard attributes associated with an uptime check

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksResponse`](../../doc/models/v2-uptime-checks-response.md).

## Example Usage

```ts
const perPage = 2;

const page = 1;

try {
  const response = await uptimeApi.uptimeChecksList(
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Check Create

To create an Uptime check, send a POST request to `/v2/uptime/checks` specifying the attributes
in the table below in the JSON body.

```ts
async uptimeCheckCreate(
  body: V2UptimeChecksRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2UptimeChecksRequest`](../../doc/models/v2-uptime-checks-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The response will be a JSON object with a key called `check`. The value of this will be an object that contains the standard attributes associated with an uptime check.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksResponse1`](../../doc/models/v2-uptime-checks-response-1.md).

## Example Usage

```ts
const body: V2UptimeChecksRequest = {
  enabled: true,
  name: 'Landing page check',
  regions: [
    Region8.UsEast,
    Region8.EuWest
  ],
  target: 'https://www.landingpage.com',
  type: Type19.Https,
};

try {
  const response = await uptimeApi.uptimeCheckCreate(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Check Delete

To delete an Uptime check, send a DELETE request to `/v2/uptime/checks/$CHECK_ID`. A 204 status
code with no body will be returned in response to a successful request.

Deleting a check will also delete alerts associated with the check.

```ts
async uptimeCheckDelete(
  checkId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

try {
  const response = await uptimeApi.uptimeCheckDelete(checkId);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Check Get

To show information about an existing check, send a GET request to `/v2/uptime/checks/$CHECK_ID`.

```ts
async uptimeCheckGet(
  checkId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `check`. The value of this will be an object that contains the standard attributes associated with an uptime check.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksResponse1`](../../doc/models/v2-uptime-checks-response-1.md).

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

try {
  const response = await uptimeApi.uptimeCheckGet(checkId);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Check Update

To update the settings of an Uptime check, send a PUT request to `/v2/uptime/checks/$CHECK_ID`.

```ts
async uptimeCheckUpdate(
  checkId: string,
  body: V2UptimeChecksRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `body` | [`V2UptimeChecksRequest`](../../doc/models/v2-uptime-checks-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `check`. The value of this will be an object that contains the standard attributes associated with an uptime check.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksResponse1`](../../doc/models/v2-uptime-checks-response-1.md).

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

const body: V2UptimeChecksRequest = {
  enabled: true,
  name: 'Landing page check',
  regions: [
    Region8.UsEast,
    Region8.EuWest
  ],
  target: 'https://www.landingpage.com',
  type: Type19.Https,
};

try {
  const response = await uptimeApi.uptimeCheckUpdate(
    checkId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Check Alerts List

To list all of the alerts for an Uptime check, send a GET request to `/v2/uptime/checks/$CHECK_ID/alerts`.

```ts
async uptimeCheckAlertsList(
  checkId: string,
  perPage?: number,
  page?: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksAlertsResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `perPage` | `number \| undefined` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `number \| undefined` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `alerts`. This will be set to an array of objects, each of which will contain the standard attributes associated with an uptime alert.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksAlertsResponse`](../../doc/models/v2-uptime-checks-alerts-response.md).

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

const perPage = 2;

const page = 1;

try {
  const response = await uptimeApi.uptimeCheckAlertsList(
    checkId,
    perPage,
    page
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Alert Create

To create an Uptime alert, send a POST request to `/v2/uptime/checks/$CHECK_ID/alerts` specifying the attributes
in the table below in the JSON body.

```ts
async uptimeAlertCreate(
  checkId: string,
  body: Alerts1,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksAlertsResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `body` | [`Alerts1`](../../doc/models/alerts-1.md) | Body, Required | The ''type'' field dictates the type of alert, and hence what type of value to pass into the threshold property.<br>Type \| Description \| Threshold Value<br>-----\|-------------\|--------------------<br>`latency` \| alerts on the response latency \| milliseconds<br>`down` \| alerts on a target registering as down in any region \| N/A (Not required)<br>`down_global` \| alerts on a target registering as down globally \| N/A (Not required)<br>`ssl_expiry` \| alerts on a SSL certificate expiring within $threshold days \| days |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The response will be a JSON object with a key called `alert`. The value of this will be an object that contains the standard attributes associated with an uptime alert.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksAlertsResponse1`](../../doc/models/v2-uptime-checks-alerts-response-1.md).

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

const body: Alerts1 = {
  comparison: Comparison.GreaterThan,
  name: 'Landing page degraded performance',
  period: Period.Enum2M,
  threshold: 300,
  type: Type20.Latency,
};

try {
  const response = await uptimeApi.uptimeAlertCreate(
    checkId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Alert Delete

To delete an Uptime alert, send a DELETE request to `/v2/uptime/checks/$CHECK_ID/alerts/$ALERT_ID`. A 204 status
code with no body will be returned in response to a successful request.

```ts
async uptimeAlertDelete(
  checkId: string,
  alertId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `alertId` | `string` | Template, Required | A unique identifier for an alert. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

const alertId = '17f0f0ae-b7e5-4ef6-86e3-aa569db58284';

try {
  const response = await uptimeApi.uptimeAlertDelete(
    checkId,
    alertId
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Alert Get

To show information about an existing alert, send a GET request to `/v2/uptime/checks/$CHECK_ID/alerts/$ALERT_ID`.

```ts
async uptimeAlertGet(
  checkId: string,
  alertId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksAlertsResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `alertId` | `string` | Template, Required | A unique identifier for an alert. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `alert`. The value of this will be an object that contains the standard attributes associated with an uptime alert.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksAlertsResponse1`](../../doc/models/v2-uptime-checks-alerts-response-1.md).

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

const alertId = '17f0f0ae-b7e5-4ef6-86e3-aa569db58284';

try {
  const response = await uptimeApi.uptimeAlertGet(
    checkId,
    alertId
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Alert Update

To update the settings of an Uptime alert, send a PUT request to `/v2/uptime/checks/$CHECK_ID/alerts/$ALERT_ID`.

```ts
async uptimeAlertUpdate(
  checkId: string,
  alertId: string,
  body: V2UptimeChecksAlertsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksAlertsResponse1>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `alertId` | `string` | Template, Required | A unique identifier for an alert. |
| `body` | [`V2UptimeChecksAlertsRequest`](../../doc/models/v2-uptime-checks-alerts-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `alert`. The value of this will be an object that contains the standard attributes associated with an uptime alert.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksAlertsResponse1`](../../doc/models/v2-uptime-checks-alerts-response-1.md).

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

const alertId = '17f0f0ae-b7e5-4ef6-86e3-aa569db58284';

const body: V2UptimeChecksAlertsRequest = {
  comparison: Comparison.GreaterThan,
  name: 'Landing page degraded performance',
  period: Period.Enum2M,
  threshold: 300,
  type: Type20.Latency,
};

try {
  const response = await uptimeApi.uptimeAlertUpdate(
    checkId,
    alertId,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |


# Uptime Check State Get

To show information about an existing check's state, send a GET request to `/v2/uptime/checks/$CHECK_ID/state`.

```ts
async uptimeCheckStateGet(
  checkId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<V2UptimeChecksStateResponse>>
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkId` | `string` | Template, Required | A unique identifier for a check. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The response will be a JSON object with a key called `state`. The value of this will be an object that contains the standard attributes associated with an uptime check's state.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`V2UptimeChecksStateResponse`](../../doc/models/v2-uptime-checks-state-response.md).

## Example Usage

```ts
const checkId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

try {
  const response = await uptimeApi.uptimeCheckStateGet(checkId);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof V21Clicks401Error) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 404 | The resource was not found. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| 500 | Server error. | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |
| Default | Unexpected error | [`V21Clicks401Error`](../../doc/models/v21-clicks-401-error.md) |

