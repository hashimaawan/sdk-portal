
# Resource Type 2

The type of the resource.

## Enumeration

`ResourceType2`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `IMAGE` |
| `VOLUME` |
| `VOLUME_SNAPSHOT` |

## Example

```python
from digitaloceanapi.models.resource_type_2 import ResourceType2

resource_type_2 = ResourceType2.DROPLET
```

