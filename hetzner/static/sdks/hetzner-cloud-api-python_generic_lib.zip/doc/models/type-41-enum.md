
# Type 41 Enum

## Enumeration

`Type41Enum`

## Fields

| Name |
|  --- |
| `OPEN_CONNECTIONS` |
| `CONNECTIONS_PER_SECOND` |
| `REQUESTS_PER_SECOND` |
| `BANDWIDTH` |

## Example

```python
from hetznercloudapi.models.type_41_enum import Type41Enum

type_41 = Type41Enum.OPEN_CONNECTIONS
```

