
# V2 Images Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2ImagesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `images` | [`List[Image1]`](../../doc/models/image-1.md) | Required | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.distribution import Distribution
from digitaloceanapi.models.image_1 import Image1
from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.region_2 import Region2
from digitaloceanapi.models.status_7 import Status7
from digitaloceanapi.models.type_9 import Type9
from digitaloceanapi.models.v_2_images_response import V2ImagesResponse

v_2_images_response = V2ImagesResponse(
    images=[
        Image1(
            created_at=dateutil.parser.parse('2020-05-04T22:23:02Z'),
            description='description2',
            distribution=Distribution.UBUNTU,
            error_message='error_message4',
            id=7555620,
            min_disk_size=20,
            name='Nifty New Snapshot',
            public=True,
            regions=[
                Region2.NYC1,
                Region2.NYC2
            ],
            size_gigabytes=2.34,
            slug='nifty1',
            status=Status7.NEW,
            tags=[
                'base-image',
                'prod'
            ],
            mtype=Type9.SNAPSHOT,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    meta=Meta(
        total=1,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    links=Links(
        pages=Pages(
            last='last6',
            next='next2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

