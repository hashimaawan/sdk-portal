
# Price Monthly

Monthly costs for a Resource in this Location

## Structure

`PriceMonthly`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `string` | Required | Price with VAT added |
| `net` | `string` | Required | Price without VAT |

## Example

```ts
import { PriceMonthly } from 'hetzner-cloud-apilib';

const priceMonthly: PriceMonthly = {
  gross: '1.1900000000000000',
  net: '1.0000000000',
};
```

