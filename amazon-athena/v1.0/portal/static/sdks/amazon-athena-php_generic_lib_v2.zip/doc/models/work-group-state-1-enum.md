
# Work Group State 1 Enum

The state of the workgroup.

## Enumeration

`WorkGroupState1Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```php
use AmazonAthenaLib\Models\WorkGroupState1Enum;

$workGroupState1 = WorkGroupState1Enum::ENABLED;
```

