
# Tier Slug

The slug of the subscription tier to sign up for.

## Enumeration

`TierSlug`

## Fields

| Name |
|  --- |
| `STARTER` |
| `BASIC` |
| `PROFESSIONAL` |

## Example

```php
use DigitalOceanApiLib\Models\TierSlug;

$tierSlug = TierSlug::PROFESSIONAL;
```

