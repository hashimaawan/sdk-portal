
# Datacenter 2

Datacenter this Primary IP is located at

## Structure

`Datacenter2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string` | Required | Description of the Datacenter |
| `id` | `number` | Required | ID of the Resource |
| `location` | [`Location`](../../doc/models/location.md) | Required | - |
| `name` | `string` | Required | Unique identifier of the Datacenter |
| `serverTypes` | [`ServerTypes`](../../doc/models/server-types.md) | Required | The Server types the Datacenter can handle |

## Example

```ts
import { Datacenter2 } from 'hetzner-cloud-apilib';

const datacenter2: Datacenter2 = {
  description: 'Falkenstein DC Park 8',
  id: 42,
  location: {
    city: 'Falkenstein',
    country: 'DE',
    description: 'Falkenstein DC Park 1',
    id: 1,
    latitude: 50.47612,
    longitude: 12.370071,
    name: 'fsn1',
    networkZone: 'eu-central',
  },
  name: 'fsn1-dc8',
  serverTypes: {
    available: [
      1,
      2,
      3
    ],
    availableForMigration: [
      1,
      2,
      3
    ],
    supported: [
      1,
      2,
      3
    ],
  },
};
```

