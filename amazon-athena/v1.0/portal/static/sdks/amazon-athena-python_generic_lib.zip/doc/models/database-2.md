
# Database 2

## Structure

`Database2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```python
from amazonathena.models.database_2 import Database2
from amazonathena.models.parameters import Parameters

database_2 = Database2(
    name='Name2',
    description='Description4',
    parameters=Parameters()
)
```

