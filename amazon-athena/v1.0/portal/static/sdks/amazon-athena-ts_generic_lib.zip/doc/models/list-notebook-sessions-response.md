
# List Notebook Sessions Response

## Structure

`ListNotebookSessionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookSessionsList` | [`NotebookSessionSummary[]`](../../doc/models/notebook-session-summary.md) | Required | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListNotebookSessionsResponse } from 'amazon-athenalib';

const listNotebookSessionsResponse: ListNotebookSessionsResponse = {
  notebookSessionsList: [
    {
      sessionId: 'SessionId4',
      creationTime: '2016-03-13T12:52:32.123Z',
    }
  ],
  nextToken: 'NextToken0',
};
```

