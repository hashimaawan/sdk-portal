
# Oauth Scope Furkot Auth Access Code

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthAccessCode`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list trips and stops info |

## Example

```java
import com.furkot.trips.models.OauthScopeFurkotAuthAccessCode;

OauthScopeFurkotAuthAccessCode oauthScopeFurkotAuthAccessCode = OauthScopeFurkotAuthAccessCode.READTRIPS;
```

