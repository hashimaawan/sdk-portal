
# Load Balancers Request

## Structure

`LoadBalancersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New Load Balancer name |

## Example

```ts
import { LoadBalancersRequest } from 'hetzner-cloud-apilib';

const loadBalancersRequest: LoadBalancersRequest = {
  labels: { 'labelkey': 'value' },
  name: 'new-name',
};
```

