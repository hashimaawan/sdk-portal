
# V2 Databases Migrate Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesMigrateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `region` | `String` | Required | A slug identifier for the region to which the database cluster will be migrated. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_migrate_request = V2DatabasesMigrateRequest.new(
  region: 'lon1',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

