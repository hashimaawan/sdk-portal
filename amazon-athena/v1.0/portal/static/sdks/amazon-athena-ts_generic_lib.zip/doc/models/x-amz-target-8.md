
# X Amz Target 8

## Enumeration

`XAmzTarget8`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateWorkGroup` |

## Example

```ts
import { XAmzTarget8 } from 'amazon-athenalib';

const xAmzTarget8 = XAmzTarget8.EnumAmazonAthenaCreateWorkGroup;
```

