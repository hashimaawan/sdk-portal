
# Created From

Information about the Server the Image was created from

## Structure

`CreatedFrom`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server the Image was created from |
| `Name` | `string` | Required | Server name at the time the Image was created |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    createdFrom := models.CreatedFrom{
        Id:                   1,
        Name:                 "Server",
    }

}
```

