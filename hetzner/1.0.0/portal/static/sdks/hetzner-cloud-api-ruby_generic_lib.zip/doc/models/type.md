
# Type

Type of the Certificate

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```ruby
type = Type::UPLOADED
```

