
# Type

Type of the gif. By default, this is almost always gif

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `GIF` |

## Example

```python
from giphyapi.models.mtype import Type

mtype = Type.GIF
```

