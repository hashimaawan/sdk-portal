# Account

Provides information about your current account.

```python
account_api = client.account
```

## Class Name

`AccountApi`


# Account Get

To show information about the current user account, send a GET request to `/v2/account`.

```python
def account_get(self)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: A JSON object keyed on account with an excerpt of the current user account data.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2AccountResponse`](../../doc/models/v2-account-response.md).

## Example Usage

```python
result = account_api.account_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

