
# Data Catalog Type 2 Enum

The data catalog type.

## Enumeration

`DataCatalogType2Enum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```php
use AmazonAthenaLib\Models\DataCatalogType2Enum;

$dataCatalogType2 = DataCatalogType2Enum::LAMBDA;
```

