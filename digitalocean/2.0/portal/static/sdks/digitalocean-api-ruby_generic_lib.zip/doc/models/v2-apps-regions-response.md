
# V2 Apps Regions Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AppsRegionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `regions` | [`Array[GeographicalInformationAboutAnAppOrigin]`](../../doc/models/geographical-information-about-an-app-origin.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_apps_regions_response = V2AppsRegionsResponse.new(
  regions: [
    GeographicalInformationAboutAnAppOrigin.new(
      continent: 'continent2',
      data_centers: [
        'data_centers9'
      ],
      default: false,
      disabled: false,
      flag: 'flag4',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

