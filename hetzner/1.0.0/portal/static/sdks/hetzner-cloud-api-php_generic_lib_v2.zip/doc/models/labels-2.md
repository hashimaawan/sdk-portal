
# Labels 2

User-defined labels (key-value pairs)

## Structure

`Labels2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `labelkey` | `?string` | Optional | - | getLabelkey(): ?string | setLabelkey(?string labelkey): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\Labels2Builder;

$labels2 = Labels2Builder::init()
    ->labelkey('value')
    ->build();
```

