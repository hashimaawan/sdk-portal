# Firewalls

[DigitalOcean Cloud Firewalls](https://www.digitalocean.com/docs/networking/firewalls/)
provide the ability to restrict network access to and from a Droplet
allowing you to define which ports will accept inbound or outbound
connections. By sending requests to the `/v2/firewalls` endpoint, you can
list, create, or delete firewalls as well as modify access rules.

```java
FirewallsApi firewallsApi = client.getFirewallsApi();
```

## Class Name

`FirewallsApi`

## Methods

* [Firewalls List](../../doc/controllers/firewalls.md#firewalls-list)
* [Firewalls Create](../../doc/controllers/firewalls.md#firewalls-create)
* [Firewalls Delete](../../doc/controllers/firewalls.md#firewalls-delete)
* [Firewalls Get](../../doc/controllers/firewalls.md#firewalls-get)
* [Firewalls Update](../../doc/controllers/firewalls.md#firewalls-update)
* [Firewalls Delete Droplets](../../doc/controllers/firewalls.md#firewalls-delete-droplets)
* [Firewalls Assign Droplets](../../doc/controllers/firewalls.md#firewalls-assign-droplets)
* [Firewalls Delete Rules](../../doc/controllers/firewalls.md#firewalls-delete-rules)
* [Firewalls Add Rules](../../doc/controllers/firewalls.md#firewalls-add-rules)
* [Firewalls Delete Tags](../../doc/controllers/firewalls.md#firewalls-delete-tags)
* [Firewalls Add Tags](../../doc/controllers/firewalls.md#firewalls-add-tags)


# Firewalls List

To list all of the firewalls available on your account, send a GET request to `/v2/firewalls`.

```java
CompletableFuture<ApiResponse<V2FirewallsResponse>> firewallsListAsync(
    final Integer perPage,
    final Integer page)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `Integer` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `Integer` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: To list all of the firewalls available on your account, send a GET request to `/v2/firewalls`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2FirewallsResponse`](../../doc/models/v2-firewalls-response.md).

## Example Usage

```java
Integer perPage = 2;
Integer page = 1;

firewallsApi.firewallsListAsync(perPage, page).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "firewalls": [
    {
      "created_at": "2017-05-23T21:23:59Z",
      "droplet_ids": [
        8043964
      ],
      "id": "fb6045f1-cf1d-4ca3-bfac-18832663025b",
      "inbound_rules": [
        {
          "ports": "80",
          "protocol": "tcp",
          "sources": {
            "load_balancer_uids": [
              "4de7ac8b-495b-4884-9a69-1050c6793cd6"
            ]
          }
        },
        {
          "ports": "22",
          "protocol": "tcp",
          "sources": {
            "addresses": [
              "18.0.0.0/8"
            ],
            "tags": [
              "gateway"
            ]
          }
        }
      ],
      "name": "firewall",
      "outbound_rules": [
        {
          "destinations": {
            "addresses": [
              "0.0.0.0/0",
              "::/0"
            ]
          },
          "ports": "80",
          "protocol": "tcp"
        }
      ],
      "pending_changes": [],
      "status": "succeeded",
      "tags": []
    }
  ],
  "links": {},
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Create

To create a new firewall, send a POST request to `/v2/firewalls`. The request
must contain at least one inbound or outbound access rule.

```java
CompletableFuture<ApiResponse<V2FirewallsResponse1>> firewallsCreateAsync(
    final V2FirewallsRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2FirewallsRequest`](../../doc/models/v2-firewalls-request.md) | Body, Optional | - |

## Response Type

**202**: The response will be a JSON object with a firewall key. This will be set to an object containing the standard firewall attributes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```java
V2FirewallsRequest body = new V2FirewallsRequest.Builder(
    "firewall",
    Arrays.asList(
        new InboundRule.Builder(
            "80",
            Protocol.TCP,
            new Sources.Builder()
                .loadBalancerUids(Arrays.asList(
                    "4de7ac8b-495b-4884-9a69-1050c6793cd6"
                ))
                .build()
        )
        .build(),
        new InboundRule.Builder(
            "22",
            Protocol.TCP,
            new Sources.Builder()
                .addresses(Arrays.asList(
                    "18.0.0.0/8"
                ))
                .tags(Arrays.asList(
                    "gateway"
                ))
                .build()
        )
        .build()
    ),
    Arrays.asList(
        new OutboundRule.Builder(
            "80",
            Protocol.TCP,
            new Destinations.Builder()
                .addresses(Arrays.asList(
                    "0.0.0.0/0",
                    "::/0"
                ))
                .build()
        )
        .build()
    )
)
.dropletIds(Arrays.asList(
        8043964
    ))
.build();

firewallsApi.firewallsCreateAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2017-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [
      {
        "droplet_id": 8043964,
        "removing": false,
        "status": "waiting"
      }
    ],
    "status": "waiting",
    "tags": []
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Delete

To delete a firewall send a DELETE request to `/v2/firewalls/$FIREWALL_ID`.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```java
CompletableFuture<ApiResponse<Void>> firewallsDeleteAsync(
    final UUID firewallId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");

firewallsApi.firewallsDeleteAsync(firewallId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Get

To show information about an existing firewall, send a GET request to `/v2/firewalls/$FIREWALL_ID`.

```java
CompletableFuture<ApiResponse<V2FirewallsResponse1>> firewallsGetAsync(
    final UUID firewallId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |

## Response Type

**200**: The response will be a JSON object with a firewall key. This will be set to an object containing the standard firewall attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");

firewallsApi.firewallsGetAsync(firewallId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2017-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [],
    "status": "succeeded",
    "tags": []
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Update

To update the configuration of an existing firewall, send a PUT request to
`/v2/firewalls/$FIREWALL_ID`. The request should contain a full representation
of the firewall including existing attributes. **Note that any attributes that
are not provided will be reset to their default values.**

```java
CompletableFuture<ApiResponse<V2FirewallsResponse1>> firewallsUpdateAsync(
    final UUID firewallId,
    final V2FirewallsRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsRequest`](../../doc/models/v2-firewalls-request.md) | Body, Optional | - |

## Response Type

**200**: The response will be a JSON object with a `firewall` key. This will be set to an object containing the standard firewall attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2FirewallsResponse1`](../../doc/models/v2-firewalls-response-1.md).

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");
V2FirewallsRequest body = new V2FirewallsRequest.Builder(
    "frontend-firewall",
    Arrays.asList(
        new InboundRule.Builder(
            "8080",
            Protocol.TCP,
            new Sources.Builder()
                .loadBalancerUids(Arrays.asList(
                    "4de7ac8b-495b-4884-9a69-1050c6793cd6"
                ))
                .build()
        )
        .build(),
        new InboundRule.Builder(
            "22",
            Protocol.TCP,
            new Sources.Builder()
                .addresses(Arrays.asList(
                    "18.0.0.0/8"
                ))
                .tags(Arrays.asList(
                    "gateway"
                ))
                .build()
        )
        .build()
    ),
    Arrays.asList(
        new OutboundRule.Builder(
            "8080",
            Protocol.TCP,
            new Destinations.Builder()
                .addresses(Arrays.asList(
                    "0.0.0.0/0",
                    "::/0"
                ))
                .build()
        )
        .build()
    )
)
.dropletIds(Arrays.asList(
        8043964
    ))
.tags(Arrays.asList(
        "frontend"
    ))
.build();

firewallsApi.firewallsUpdateAsync(firewallId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "firewall": {
    "created_at": "2020-05-23T21:24:00Z",
    "droplet_ids": [
      8043964
    ],
    "id": "bb4b2611-3d72-467b-8602-280330ecd65c",
    "inbound_rules": [
      {
        "ports": "80",
        "protocol": "tcp",
        "sources": {
          "load_balancer_uids": [
            "4de7ac8b-495b-4884-9a69-1050c6793cd6"
          ]
        }
      },
      {
        "ports": "22",
        "protocol": "tcp",
        "sources": {
          "addresses": [
            "18.0.0.0/8"
          ],
          "tags": [
            "gateway"
          ]
        }
      }
    ],
    "name": "frontend-firewall",
    "outbound_rules": [
      {
        "destinations": {
          "addresses": [
            "0.0.0.0/0",
            "::/0"
          ]
        },
        "ports": "80",
        "protocol": "tcp"
      }
    ],
    "pending_changes": [
      {
        "droplet_id": 8043964,
        "removing": false,
        "status": "waiting"
      }
    ],
    "status": "waiting",
    "tags": [
      "frontend"
    ]
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Delete Droplets

To remove a Droplet from a firewall, send a DELETE request to
`/v2/firewalls/$FIREWALL_ID/droplets`. In the body of the request, there should
be a `droplet_ids` attribute containing a list of Droplet IDs.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```java
CompletableFuture<ApiResponse<Void>> firewallsDeleteDropletsAsync(
    final UUID firewallId,
    final V2FirewallsDropletsRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsDropletsRequest`](../../doc/models/v2-firewalls-droplets-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");
V2FirewallsDropletsRequest body = new V2FirewallsDropletsRequest.Builder(
    Arrays.asList(
        49696269
    )
)
.build();

firewallsApi.firewallsDeleteDropletsAsync(firewallId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Assign Droplets

To assign a Droplet to a firewall, send a POST request to
`/v2/firewalls/$FIREWALL_ID/droplets`. In the body of the request, there
should be a `droplet_ids` attribute containing a list of Droplet IDs.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```java
CompletableFuture<ApiResponse<Void>> firewallsAssignDropletsAsync(
    final UUID firewallId,
    final V2FirewallsDropletsRequest1 body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsDropletsRequest1`](../../doc/models/v2-firewalls-droplets-request-1.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");
V2FirewallsDropletsRequest1 body = new V2FirewallsDropletsRequest1.Builder(
    Arrays.asList(
        49696269
    )
)
.build();

firewallsApi.firewallsAssignDropletsAsync(firewallId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Delete Rules

To remove access rules from a firewall, send a DELETE request to
`/v2/firewalls/$FIREWALL_ID/rules`. The body of the request may include an
`inbound_rules` and/or `outbound_rules` attribute containing an array of rules
to be removed.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```java
CompletableFuture<ApiResponse<Void>> firewallsDeleteRulesAsync(
    final UUID firewallId,
    final V2FirewallsRulesRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsRulesRequest`](../../doc/models/v2-firewalls-rules-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");
V2FirewallsRulesRequest body = new V2FirewallsRulesRequest.Builder(
    Arrays.asList(
        new InboundRule.Builder(
            "3306",
            Protocol.TCP,
            new Sources.Builder()
                .dropletIds(Arrays.asList(
                    49696269
                ))
                .build()
        )
        .build()
    ),
    Arrays.asList(
        new OutboundRule.Builder(
            "3306",
            Protocol.TCP,
            new Destinations.Builder()
                .dropletIds(Arrays.asList(
                    49696269
                ))
                .build()
        )
        .build()
    )
)
.build();

firewallsApi.firewallsDeleteRulesAsync(firewallId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Add Rules

To add additional access rules to a firewall, send a POST request to
`/v2/firewalls/$FIREWALL_ID/rules`. The body of the request may include an
inbound_rules and/or outbound_rules attribute containing an array of rules to
be added.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```java
CompletableFuture<ApiResponse<Void>> firewallsAddRulesAsync(
    final UUID firewallId,
    final V2FirewallsRulesRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsRulesRequest`](../../doc/models/v2-firewalls-rules-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");
V2FirewallsRulesRequest body = new V2FirewallsRulesRequest.Builder(
    Arrays.asList(
        new InboundRule.Builder(
            "3306",
            Protocol.TCP,
            new Sources.Builder()
                .dropletIds(Arrays.asList(
                    49696269
                ))
                .build()
        )
        .build()
    ),
    Arrays.asList(
        new OutboundRule.Builder(
            "3306",
            Protocol.TCP,
            new Destinations.Builder()
                .dropletIds(Arrays.asList(
                    49696269
                ))
                .build()
        )
        .build()
    )
)
.build();

firewallsApi.firewallsAddRulesAsync(firewallId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Delete Tags

To remove a tag representing a group of Droplets from a firewall, send a
DELETE request to `/v2/firewalls/$FIREWALL_ID/tags`. In the body of the
request, there should be a `tags` attribute containing a list of tag names.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```java
CompletableFuture<ApiResponse<Void>> firewallsDeleteTagsAsync(
    final UUID firewallId,
    final V2FirewallsTagsRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsTagsRequest`](../../doc/models/v2-firewalls-tags-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");
V2FirewallsTagsRequest body = new V2FirewallsTagsRequest.Builder(
    Arrays.asList(
        "frontend"
    )
)
.build();

firewallsApi.firewallsDeleteTagsAsync(firewallId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Firewalls Add Tags

To assign a tag representing a group of Droplets to a firewall, send a POST
request to `/v2/firewalls/$FIREWALL_ID/tags`. In the body of the request,
there should be a `tags` attribute containing a list of tag names.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```java
CompletableFuture<ApiResponse<Void>> firewallsAddTagsAsync(
    final UUID firewallId,
    final V2FirewallsTagsRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewallId` | `UUID` | Template, Required | A unique ID that can be used to identify and reference a firewall. |
| `body` | [`V2FirewallsTagsRequest`](../../doc/models/v2-firewalls-tags-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID firewallId = UUID.fromString("bb4b2611-3d72-467b-8602-280330ecd65c");
V2FirewallsTagsRequest body = new V2FirewallsTagsRequest.Builder(
    Arrays.asList(
        "frontend"
    )
)
.build();

firewallsApi.firewallsAddTagsAsync(firewallId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

