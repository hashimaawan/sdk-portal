
# Placement Group Response

*This model accepts additional fields of type unknown.*

## Structure

`PlacementGroupResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placementGroup` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { PlacementGroupResponse } from 'hetzner-cloud-apilib';

const placementGroupResponse: PlacementGroupResponse = {
  placementGroup: {
    created: '2016-01-30T23:55:00+00:00',
    id: 42,
    labels: {
      'key0': 'labels4'
    },
    name: 'my-resource',
    servers: [
      42
    ],
    type: 'spread',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

