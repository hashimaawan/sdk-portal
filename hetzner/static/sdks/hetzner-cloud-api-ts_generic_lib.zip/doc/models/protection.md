
# Protection

Protection configuration for the Resource

## Structure

`Protection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean` | Required | If true, prevents the Resource from being deleted |

## Example

```ts
import { Protection } from 'hetzner-cloud-apilib';

const protection: Protection = {
  mDelete: false,
};
```

