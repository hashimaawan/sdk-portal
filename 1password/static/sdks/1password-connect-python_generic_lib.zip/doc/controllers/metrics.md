# Metrics

```python
metrics_api = client.metrics
```

## Class Name

`MetricsApi`


# Get Prometheus Metrics

See Prometheus documentation for a complete data model.

:information_source: **Note** This endpoint does not require authentication.

```python
def get_prometheus_metrics(self)
```

## Response Type

**200**: Successfully returned Prometheus metrics

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `str`.

## Example Usage

```python
result = metrics_api.get_prometheus_metrics()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

