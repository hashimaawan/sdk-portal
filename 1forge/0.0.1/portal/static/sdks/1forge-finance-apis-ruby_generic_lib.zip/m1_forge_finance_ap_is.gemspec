Gem::Specification.new do |s|
  s.name = 'm1_forge_finance_ap_is'
  s.version = '0.0.1'
  s.summary = 'm1_forge_finance_ap_is'
  s.description = 'Stock and Forex Data and Realtime Quotes'
  s.authors = ['1Forge']
  s.email = ['contact@1forge.com']
  s.homepage = 'http://1forge.com'
  s.licenses = ['MIT']
  s.add_dependency('apimatic_core_interfaces', '~> 0.2.3')
  s.add_dependency('apimatic_core', '~> 0.3.20')
  s.add_dependency('apimatic_faraday_client_adapter', '~> 0.1.6')
  s.required_ruby_version = ['>= 2.6']
  s.files = Dir['{bin,lib,man,test,spec}/**/*', 'README*', 'LICENSE*']
  s.require_paths = ['lib']
end
