
# X Amz Target 49 Enum

## Enumeration

`XAmzTarget49Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget49Enum;

$xAmzTarget49 = XAmzTarget49Enum::ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION;
```

