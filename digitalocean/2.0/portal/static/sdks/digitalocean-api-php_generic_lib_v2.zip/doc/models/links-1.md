
# Links 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Links1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `actions` | [`?(Action1[])`](../../doc/models/action-1.md) | Optional | - | getActions(): ?array | setActions(?array actions): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Links1Builder;
use DigitalOceanApiLib\Models\Builders\Action1Builder;
use DigitalOceanApiLib\ApiHelper;

$links1 = Links1Builder::init()
    ->actions(
        [
            Action1Builder::init()
                ->href('href0')
                ->id(154)
                ->rel('rel4')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            Action1Builder::init()
                ->href('href0')
                ->id(154)
                ->rel('rel4')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

