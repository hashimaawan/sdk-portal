
# Load Balancers Actions Delete Service Request

*This model accepts additional fields of type unknown.*

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listenPort` | `number` | Required | The listen port of the service you want to delete |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  LoadBalancersActionsDeleteServiceRequest,
} from 'hetzner-cloud-apilib';

const loadBalancersActionsDeleteServiceRequest: LoadBalancersActionsDeleteServiceRequest = {
  listenPort: 4711,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

