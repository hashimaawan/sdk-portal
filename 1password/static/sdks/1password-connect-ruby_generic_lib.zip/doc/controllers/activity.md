# Activity

Access API Request Activity

```ruby
activity_api = client.activity
```

## Class Name

`ActivityApi`


# Get Api Activity

```ruby
def get_api_activity(limit: 50,
                     offset: 0)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `Integer` | Query, Optional | How many API Events should be retrieved in a single request.<br><br>**Default**: `50` |
| `offset` | `Integer` | Query, Optional | How far into the collection of API Events should the response start<br><br>**Default**: `0` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`Array[ApiRequest]`](../../doc/models/api-request.md).

## Example Usage

```ruby
limit = 10

offset = 50

result = activity_api.get_api_activity(
  limit: limit,
  offset: offset
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

