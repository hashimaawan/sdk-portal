
# Item Type 2

The ID type.

## Enumeration

`ItemType2`

## Fields

| Name |
|  --- |
| `ARTIST` |
| `USER` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.item_type_2 import ItemType2

item_type_2 = ItemType2.ARTIST
```

