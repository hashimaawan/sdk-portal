
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |

The API client can be initialized as follows:

## Code-Based Initialization

```csharp
using HetznerCloudAPI.Standard;

namespace ConsoleApp;

HetznerCloudAPIClient client = new HetznerCloudAPIClient.Builder()
    .HttpClientConfig(httpClientConfig =>
        httpClientConfig.Timeout(TimeSpan.FromSeconds(100)))
    .Build();
```

## Configuration-Based Initialization

```csharp
using HetznerCloudAPI.Standard;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp;

// Build the IConfiguration using .NET conventions (JSON, environment, etc.)
var configuration = new ConfigurationBuilder()
    .AddJsonFile("config.json")
    .AddEnvironmentVariables() // [optional] read environment variables
    .Build();

// Instantiate your SDK and configure it from IConfiguration
var client = HetznerCloudAPIClient
    .FromConfiguration(configuration.GetSection("HetznerCloudAPI"));
```

See the [Configuration-Based Initialization](../doc/configuration-based-initialization.md) section for details.

## Hetzner Cloud APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| ActionsController | Gets ActionsController controller. |
| CertificatesController | Gets CertificatesController controller. |
| CertificateActionsController | Gets CertificateActionsController controller. |
| DatacentersController | Gets DatacentersController controller. |
| FirewallsController | Gets FirewallsController controller. |
| FirewallActionsController | Gets FirewallActionsController controller. |
| FloatingIPsController | Gets FloatingIPsController controller. |
| FloatingIPActionsController | Gets FloatingIPActionsController controller. |
| ImagesController | Gets ImagesController controller. |
| ImageActionsController | Gets ImageActionsController controller. |
| ISOsController | Gets ISOsController controller. |
| LoadBalancersController | Gets LoadBalancersController controller. |
| LoadBalancerActionsController | Gets LoadBalancerActionsController controller. |
| LoadBalancerTypesController | Gets LoadBalancerTypesController controller. |
| LocationsController | Gets LocationsController controller. |
| PrimaryIPsController | Gets PrimaryIPsController controller. |
| PrimaryIPActionsController | Gets PrimaryIPActionsController controller. |
| NetworksController | Gets NetworksController controller. |
| NetworkActionsController | Gets NetworkActionsController controller. |
| PlacementGroupsController | Gets PlacementGroupsController controller. |
| PricingController | Gets PricingController controller. |
| ServersController | Gets ServersController controller. |
| ServerActionsController | Gets ServerActionsController controller. |
| ServerTypesController | Gets ServerTypesController controller. |
| SSHKeysController | Gets SSHKeysController controller. |
| VolumesController | Gets VolumesController controller. |
| VolumeActionsController | Gets VolumeActionsController controller. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the Hetzner Cloud APIClient using the values provided for the builder. | `Builder` |

## Hetzner Cloud APIClient Builder Class

Class to build instances of Hetzner Cloud APIClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |

