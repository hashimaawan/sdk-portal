
# X Amz Target 44 Enum

## Enumeration

`XAmzTarget44Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListTagsForResource` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget44Enum xAmzTarget44 = XAmzTarget44Enum.EnumAmazonAthenaListTagsForResource;
```

