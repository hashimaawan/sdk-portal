
# Get Prepared Statement Input

## Structure

`GetPreparedStatementInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statementName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```ts
import { GetPreparedStatementInput } from 'amazon-athenalib';

const getPreparedStatementInput: GetPreparedStatementInput = {
  statementName: 'StatementName6',
  workGroup: 'WorkGroup0',
};
```

