
# Load Balancer Service Http

Configuration option for protocols http and https

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancerServiceHttp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `certificates` | `Array[Integer]` | Optional | IDs of the Certificates to use for TLS/SSL termination by the Load Balancer; empty for TLS/SSL passthrough or if `protocol` is "http" |
| `cookie_lifetime` | `Integer` | Optional | Lifetime of the cookie used for sticky sessions |
| `cookie_name` | `String` | Optional | Name of the cookie used for sticky sessions |
| `redirect_http` | `TrueClass \| FalseClass` | Optional | Redirect HTTP requests to HTTPS. Only available if protocol is "https". Default `false` |
| `sticky_sessions` | `TrueClass \| FalseClass` | Optional | Use sticky sessions. Only available if protocol is "http" or "https". Default `false` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
load_balancer_service_http = LoadBalancerServiceHttp.new(
  certificates: [
    897
  ],
  cookie_lifetime: 300,
  cookie_name: 'HCLBSTICKY',
  redirect_http: true,
  sticky_sessions: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

