
# V2 Kubernetes Clusters Node Pools Recycle Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersNodePoolsRecycleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nodes` | `string[] \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  V2KubernetesClustersNodePoolsRecycleRequest,
} from 'digitalocean-apilib';

const v2KubernetesClustersNodePoolsRecycleRequest: V2KubernetesClustersNodePoolsRecycleRequest = {
  nodes: [
    'd8db5e1a-6103-43b5-a7b3-8a948210a9fc'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

