
# Status 24

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |
| `UNAVAILABLE` |

## Example

```ruby
status24 = Status24::AVAILABLE
```

