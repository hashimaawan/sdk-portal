
# Start Calculation Execution Response

*This model accepts additional fields of type unknown.*

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `state` | [`CalculationExecutionState4 \| undefined`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  CalculationExecutionState4,
  StartCalculationExecutionResponse,
} from 'amazon-athenalib';

const startCalculationExecutionResponse: StartCalculationExecutionResponse = {
  calculationExecutionId: 'CalculationExecutionId0',
  state: CalculationExecutionState4.Canceling,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

