
# Resource Type 1

The type of resource that the snapshot originated from.

## Enumeration

`ResourceType1`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `VOLUME` |

## Example

```java
import com.digitalocean.api.models.ResourceType1;

ResourceType1 resourceType1 = ResourceType1.DROPLET;
```

