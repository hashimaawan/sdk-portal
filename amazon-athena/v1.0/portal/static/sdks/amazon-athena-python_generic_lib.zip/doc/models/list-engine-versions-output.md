
# List Engine Versions Output

## Structure

`ListEngineVersionsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `engine_versions` | [`List[EngineVersion]`](../../doc/models/engine-version.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```python
from amazonathena.models.engine_version import EngineVersion
from amazonathena.models.list_engine_versions_output import ListEngineVersionsOutput

list_engine_versions_output = ListEngineVersionsOutput(
    engine_versions=[
        EngineVersion(
            selected_engine_version='SelectedEngineVersion2',
            effective_engine_version='EffectiveEngineVersion2'
        ),
        EngineVersion(
            selected_engine_version='SelectedEngineVersion2',
            effective_engine_version='EffectiveEngineVersion2'
        )
    ],
    next_token='NextToken2'
)
```

