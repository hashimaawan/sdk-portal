
# Many Devices

*This model accepts additional fields of type Object.*

## Structure

`ManyDevices`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `devices` | [`Array[DeviceObject]`](../../doc/models/device-object.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
many_devices = ManyDevices.new(
  devices: [
    DeviceObject.new(
      id: 'id4',
      is_active: false,
      is_private_session: false,
      is_restricted: false,
      name: 'Kitchen speaker',
      type: 'computer',
      volume_percent: 59,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

