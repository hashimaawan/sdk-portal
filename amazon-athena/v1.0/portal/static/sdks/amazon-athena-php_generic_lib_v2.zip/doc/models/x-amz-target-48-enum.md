
# X Amz Target 48 Enum

## Enumeration

`XAmzTarget48Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTSESSION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget48Enum;

$xAmzTarget48 = XAmzTarget48Enum::ENUM_AMAZONATHENASTARTSESSION;
```

