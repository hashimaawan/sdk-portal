
# Update Volume Request

## Structure

`UpdateVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labels` | [`*models.Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `Name` | `string` | Required | New Volume name |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    updateVolumeRequest := models.UpdateVolumeRequest{
        Labels:               models.ToPointer(models.Labels2{
            Labelkey:             models.ToPointer("labelkey4"),
        }),
        Name:                 "database-storage",
    }

}
```

