
# Options

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Options`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mongodb` | [`Mongodb \| undefined`](../../doc/models/mongodb.md) | Optional | - |
| `mysql` | [`Mysql \| undefined`](../../doc/models/mysql.md) | Optional | - |
| `pg` | [`Pg \| undefined`](../../doc/models/pg.md) | Optional | - |
| `redis` | [`Redis \| undefined`](../../doc/models/redis.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Options } from 'digitalocean-apilib';

const options: Options = {
  mongodb: {
    regions: [
      'regions3',
      'regions4'
    ],
    versions: [
      'versions3',
      'versions4'
    ],
    layouts: [
      {
        numNodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        numNodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  mysql: {
    regions: [
      'regions9',
      'regions0',
      'regions1'
    ],
    versions: [
      'versions9',
      'versions0',
      'versions1'
    ],
    layouts: [
      {
        numNodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        numNodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        numNodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  pg: {
    regions: [
      'regions3'
    ],
    versions: [
      'versions3'
    ],
    layouts: [
      {
        numNodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  redis: {
    regions: [
      'regions7'
    ],
    versions: [
      'versions7'
    ],
    layouts: [
      {
        numNodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

