
# V2 Databases Pools Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesPoolsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pools` | [`?(Pool[])`](../../doc/models/pool.md) | Optional, Read-only | An array of connection pool objects. | getPools(): ?array | setPools(?array pools): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesPoolsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\PoolBuilder;
use DigitalOceanApiLib\Models\Builders\ConnectionBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\PrivateConnectionBuilder;

$v2DatabasesPoolsResponse = V2DatabasesPoolsResponseBuilder::init()
    ->pools(
        [
            PoolBuilder::init(
                'db2',
                'mode0',
                'name2',
                68
            )
                ->connection(
                    ConnectionBuilder::init()
                        ->database('database2')
                        ->host('host0')
                        ->password('password2')
                        ->port(174)
                        ->ssl(false)
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                )
                ->privateConnection(
                    PrivateConnectionBuilder::init()
                        ->database('database4')
                        ->host('host4')
                        ->password('password8')
                        ->port(228)
                        ->ssl(false)
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                )
                ->user('user2')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

