
# V2 Kubernetes Clusters User Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUserResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kubernetes_cluster_user` | [`KubernetesClusterUser`](../../doc/models/kubernetes-cluster-user.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_kubernetes_clusters_user_response = V2KubernetesClustersUserResponse.new(
  kubernetes_cluster_user: KubernetesClusterUser.new(
    groups: [
      'groups8'
    ],
    username: 'username6',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

