
# State

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `Archived` |
| `Deleted` |

## Example

```ts
import { State } from 'm-1-password-connectlib';

const state = State.Archived;
```

