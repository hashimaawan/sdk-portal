
# Server Types 2

*This model accepts additional fields of type Object.*

## Structure

`ServerTypes2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `double` | Required | ID of the Server type the price is for | double getId() | setId(double id) |
| `Name` | `String` | Required | Name of the Server type the price is for | String getName() | setName(String name) |
| `Prices` | [`List<Price9>`](../../doc/models/price-9.md) | Required | Server type costs per Location | List<Price9> getPrices() | setPrices(List<Price9> prices) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.Price9;
import cloud.hetzner.api.models.PriceHourly8;
import cloud.hetzner.api.models.PriceMonthly10;
import cloud.hetzner.api.models.ServerTypes2;
import java.io.IOException;
import java.util.Arrays;

ServerTypes2 serverTypes2 = new ServerTypes2.Builder(
    4D,
    "cx11",
    Arrays.asList(
        new Price9.Builder(
            "fsn1",
            new PriceHourly8.Builder(
                "1.1900000000000000",
                "1.0000000000"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            new PriceMonthly10.Builder(
                "1.1900000000000000",
                "1.0000000000"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

