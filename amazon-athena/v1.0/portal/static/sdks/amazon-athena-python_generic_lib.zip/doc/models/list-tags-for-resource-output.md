
# List Tags for Resource Output

*This model accepts additional fields of type Any.*

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | [`List[Tag]`](../../doc/models/tag.md) | Optional | - |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.list_tags_for_resource_output import ListTagsForResourceOutput
from amazonathena.models.tag import Tag

list_tags_for_resource_output = ListTagsForResourceOutput(
    tags=[
        Tag(
            key='Key0',
            value='Value6',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    next_token='NextToken4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

