
# X Amz Target 3

## Enumeration

`XAmzTarget3`

## Fields

| Name |
|  --- |
| `EnumAmazonathenacreatedatacatalog` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget3 := models.XAmzTarget3_EnumAmazonathenacreatedatacatalog

}
```

