
# Add to Placement Group Request

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placement_group` | `int` | Required | ID of Placement Group the Server should be added to |

## Example

```python
from hetznercloudapi.models.add_to_placement_group_request import AddToPlacementGroupRequest

add_to_placement_group_request = AddToPlacementGroupRequest(
    placement_group=1
)
```

