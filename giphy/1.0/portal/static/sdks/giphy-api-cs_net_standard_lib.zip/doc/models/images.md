
# Images

An object containing data for various available formats and sizes of this GIF.

*This model accepts additional fields of type object.*

## Structure

`Images`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Downsized` | [`Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedLarge` | [`Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedMedium` | [`Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedSmall` | [`Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeight` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightDownsampled` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightSmall` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightSmallStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidth` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthDownsampled` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthSmall` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthSmallStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `Looping` | [`Image`](../../doc/models/image.md) | Optional | - |
| `Original` | [`Image`](../../doc/models/image.md) | Optional | - |
| `OriginalStill` | [`Image`](../../doc/models/image.md) | Optional | - |
| `Preview` | [`Image`](../../doc/models/image.md) | Optional | - |
| `PreviewGif` | [`Image`](../../doc/models/image.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using GiphyApi.Standard.Models;
using GiphyApi.Standard.Utilities;

Images images = new Images
{
    Downsized = new Image
    {
        Frames = "frames0",
        Height = "height8",
        Mp4 = "mp40",
        Mp4Size = "mp4_size2",
        Size = "size2",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    DownsizedLarge = new Image
    {
        Frames = "frames6",
        Height = "height4",
        Mp4 = "mp46",
        Mp4Size = "mp4_size8",
        Size = "size8",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    DownsizedMedium = new Image
    {
        Frames = "frames2",
        Height = "height0",
        Mp4 = "mp42",
        Mp4Size = "mp4_size4",
        Size = "size4",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    DownsizedSmall = new Image
    {
        Frames = "frames0",
        Height = "height8",
        Mp4 = "mp40",
        Mp4Size = "mp4_size2",
        Size = "size2",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    DownsizedStill = new Image
    {
        Frames = "frames4",
        Height = "height4",
        Mp4 = "mp46",
        Mp4Size = "mp4_size8",
        Size = "size2",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

