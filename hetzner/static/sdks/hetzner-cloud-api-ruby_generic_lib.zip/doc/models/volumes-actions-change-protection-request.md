
# Volumes Actions Change Protection Request

## Structure

`VolumesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Optional | If true, prevents the Volume from being deleted |

## Example

```ruby
volumes_actions_change_protection_request = VolumesActionsChangeProtectionRequest.new(
  true
)
```

