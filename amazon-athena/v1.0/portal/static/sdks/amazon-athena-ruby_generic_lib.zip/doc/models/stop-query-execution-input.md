
# Stop Query Execution Input

## Structure

`StopQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ruby
stop_query_execution_input = StopQueryExecutionInput.new(
  'QueryExecutionId6'
)
```

