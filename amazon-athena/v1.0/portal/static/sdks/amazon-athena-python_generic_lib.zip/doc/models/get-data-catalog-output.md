
# Get Data Catalog Output

*This model accepts additional fields of type Any.*

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data_catalog` | [`DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.data_catalog_2 import DataCatalog2
from amazonathena.models.data_catalog_type_1 import DataCatalogType1
from amazonathena.models.get_data_catalog_output import GetDataCatalogOutput
from amazonathena.models.parameters import Parameters

get_data_catalog_output = GetDataCatalogOutput(
    data_catalog=DataCatalog2(
        name='Name4',
        mtype=DataCatalogType1.GLUE,
        description='Description2',
        parameters=Parameters(
            additional_properties={
                'exampleAdditionalProperty': 'Parameters_additionalProperties2'
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

