
# Status 7

A status string indicating the state of a custom image. This may be `NEW`,
`available`, `pending`, `deleted`, or `retired`.

## Enumeration

`Status7`

## Fields

| Name |
|  --- |
| `NEW` |
| `AVAILABLE` |
| `PENDING` |
| `DELETED` |
| `RETIRED` |

## Example

```java
import com.digitalocean.api.models.Status7;

Status7 status7 = Status7.NEW;
```

