
# X Amz Target 59 Enum

## Enumeration

`XAmzTarget59Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEWORKGROUP` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget59Enum;

XAmzTarget59Enum xAmzTarget59 = XAmzTarget59Enum.ENUM_AMAZONATHENAUPDATEWORKGROUP;
```

