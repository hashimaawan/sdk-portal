
# X Amz Target 32 Enum

## Enumeration

`XAmzTarget32Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget32Enum;

$xAmzTarget32 = XAmzTarget32Enum::ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS;
```

