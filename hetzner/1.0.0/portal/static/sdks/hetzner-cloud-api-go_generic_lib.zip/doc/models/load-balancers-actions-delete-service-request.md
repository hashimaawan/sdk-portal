
# Load Balancers Actions Delete Service Request

*This model accepts additional fields of type interface{}.*

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ListenPort` | `float64` | Required | The listen port of the service you want to delete |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    loadBalancersActionsDeleteServiceRequest := models.LoadBalancersActionsDeleteServiceRequest{
        ListenPort:            float64(4711),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

