
# Label Selector

## Structure

`LabelSelector`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LabelSelector labelSelector = new LabelSelector
{
    Selector = "env=prod",
};
```

