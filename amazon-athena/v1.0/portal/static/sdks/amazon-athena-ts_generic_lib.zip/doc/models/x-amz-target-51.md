
# X Amz Target 51

## Enumeration

`XAmzTarget51`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaTagResource` |

## Example

```ts
import { XAmzTarget51 } from 'amazon-athenalib';

const xAmzTarget51 = XAmzTarget51.EnumAmazonAthenaTagResource;
```

