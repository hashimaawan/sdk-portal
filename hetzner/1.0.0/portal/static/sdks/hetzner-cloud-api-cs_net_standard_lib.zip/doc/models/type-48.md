
# Type 48

The type of the Floating IP

## Enumeration

`Type48`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type48 type48 = Type48.Ipv4;
```

