
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the Resource |
| `type` | `String` | Required | Type of resource referenced |

## Example

```ruby
resource = Resource.new(
  42,
  'server'
)
```

