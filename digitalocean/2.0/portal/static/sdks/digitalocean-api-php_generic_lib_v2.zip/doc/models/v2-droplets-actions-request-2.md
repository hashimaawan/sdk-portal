
# V2 Droplets Actions Request 2

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type12)`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. | getType(): string | setType(string type): void |
| `image` | `?int` | Optional | The ID of a backup of the current Droplet instance to restore from. | getImage(): ?int | setImage(?int image): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DropletsActionsRequest2Builder;
use DigitalOceanApiLib\Models\Type12;
use DigitalOceanApiLib\ApiHelper;

$v2DropletsActionsRequest2 = V2DropletsActionsRequest2Builder::init(
    Type12::REBOOT
)
    ->image(12389723)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

