
# V21 Clicks Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V21ClicksResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `m1Clicks` | [`?(M1Click[])`](../../doc/models/m1-click.md) | Optional | - | getM1Clicks(): ?array | setM1Clicks(?array m1Clicks): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V21ClicksResponseBuilder;
use DigitalOceanApiLib\Models\Builders\M1ClickBuilder;
use DigitalOceanApiLib\ApiHelper;

$v21ClicksResponse = V21ClicksResponseBuilder::init()
    ->m1Clicks(
        [
            M1ClickBuilder::init(
                'slug8',
                'type2'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            M1ClickBuilder::init(
                'slug8',
                'type2'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

