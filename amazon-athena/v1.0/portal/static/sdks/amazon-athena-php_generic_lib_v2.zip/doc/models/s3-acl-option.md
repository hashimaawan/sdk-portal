
# S3 Acl Option

## Enumeration

`S3AclOption`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```php
use AmazonAthenaLib\Models\S3AclOption;

$s3AclOption = S3AclOption::BUCKET_OWNER_FULL_CONTROL;
```

