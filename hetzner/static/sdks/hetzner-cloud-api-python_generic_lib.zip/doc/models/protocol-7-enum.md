
# Protocol 7 Enum

Protocol of the Load Balancer

## Enumeration

`Protocol7Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```python
from hetznercloudapi.models.protocol_7_enum import Protocol7Enum

protocol_7 = Protocol7Enum.HTTPS
```

