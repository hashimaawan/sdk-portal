
# Statement Type Enum

## Enumeration

`StatementTypeEnum`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    statementType := models.StatementTypeEnum_DDL

}
```

