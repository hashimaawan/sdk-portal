
# Label Selector 5

Configuration for type label_selector, required if type is `label_selector`

## Structure

`LabelSelector5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `String` | Required | Label selector |

## Example

```ruby
label_selector5 = LabelSelector5.new(
  'env=prod'
)
```

