
# Region 2 Enum

## Enumeration

`Region2Enum`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```php
use AmazonAthenaLib\Models\Region2Enum;

$region2 = Region2Enum::CNNORTH1;
```

