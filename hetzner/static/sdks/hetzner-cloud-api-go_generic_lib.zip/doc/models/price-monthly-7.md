
# Price Monthly 7

Monthly costs for a Floating IP type in this Location

## Structure

`PriceMonthly7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    priceMonthly7 := models.PriceMonthly7{
        Gross:                "1.1900000000000000",
        Net:                  "1.0000000000",
    }

}
```

