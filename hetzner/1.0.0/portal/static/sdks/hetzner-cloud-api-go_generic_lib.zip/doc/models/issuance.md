
# Issuance

Status of the issuance process of the Certificate

## Enumeration

`Issuance`

## Fields

| Name |
|  --- |
| `Pending` |
| `Completed` |
| `Failed` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    issuance := models.Issuance_Failed

}
```

