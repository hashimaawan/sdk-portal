
# Options

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Options`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mongodb` | [`Mongodb`](../../doc/models/mongodb.md) | Optional | - |
| `mysql` | [`Mysql`](../../doc/models/mysql.md) | Optional | - |
| `pg` | [`Pg`](../../doc/models/pg.md) | Optional | - |
| `redis` | [`Redis`](../../doc/models/redis.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
options = Options.new(
  mongodb: Mongodb.new(
    regions: [
      'regions3',
      'regions4'
    ],
    versions: [
      'versions3',
      'versions4'
    ],
    layouts: [
      Layout.new(
        num_nodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      Layout.new(
        num_nodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  mysql: Mysql.new(
    regions: [
      'regions9',
      'regions0',
      'regions1'
    ],
    versions: [
      'versions9',
      'versions0',
      'versions1'
    ],
    layouts: [
      Layout.new(
        num_nodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      Layout.new(
        num_nodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      Layout.new(
        num_nodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  pg: Pg.new(
    regions: [
      'regions3'
    ],
    versions: [
      'versions3'
    ],
    layouts: [
      Layout.new(
        num_nodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  redis: Redis.new(
    regions: [
      'regions7'
    ],
    versions: [
      'versions7'
    ],
    layouts: [
      Layout.new(
        num_nodes: 190,
        sizes: [
          'sizes2',
          'sizes3'
        ],
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

