
# V2 Functions Namespaces Triggers Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `triggers` | [`?(Trigger[])`](../../doc/models/trigger.md) | Optional | - | getTriggers(): ?array | setTriggers(?array triggers): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FunctionsNamespacesTriggersResponseBuilder;
use DigitalOceanApiLib\Models\Builders\TriggerBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2FunctionsNamespacesTriggersResponse = V2FunctionsNamespacesTriggersResponseBuilder::init()
    ->triggers(
        [
            TriggerBuilder::init()
                ->createdAt('created_at8')
                ->function('function6')
                ->isEnabled(false)
                ->name('name0')
                ->namespace('namespace2')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

