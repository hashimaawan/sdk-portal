
# X Amz Target 22 Enum

## Enumeration

`XAmzTarget22Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target22 = XAmzTarget22Enum::ENUM_AMAZONATHENAGETPREPAREDSTATEMENT
```

