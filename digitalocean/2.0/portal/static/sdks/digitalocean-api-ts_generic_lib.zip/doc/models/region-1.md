
# Region 1

The slug form of the geographical origin of the app. Default: `nearest available`

## Enumeration

`Region1`

## Fields

| Name |
|  --- |
| `Ams` |
| `Nyc` |
| `Fra` |
| `Sfo` |
| `Sgp` |
| `Blr` |
| `Tor` |
| `Lon` |
| `Syd` |

## Example

```ts
import { Region1 } from 'digitalocean-apilib';

const region1 = Region1.Sgp;
```

