
# Content Type

## Enumeration

`ContentType`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONYAML` |

## Example

```ruby
content_type = ContentType::ENUM_APPLICATIONJSON
```

