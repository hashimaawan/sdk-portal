
# Get Named Query Input

## Structure

`GetNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```python
from amazonathena.models.get_named_query_input import GetNamedQueryInput

get_named_query_input = GetNamedQueryInput(
    named_query_id='NamedQueryId8'
)
```

