
# Label Selector 12

Configuration for label selector targets, required if type is `label_selector`

## Structure

`LabelSelector12`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LabelSelector12 labelSelector12 = new LabelSelector12
{
    Selector = "env=prod",
};
```

