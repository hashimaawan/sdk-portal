
# Price Monthly 7

Monthly costs for a Floating IP type in this Location

## Structure

`PriceMonthly7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `string` | Required | Price with VAT added |
| `net` | `string` | Required | Price without VAT |

## Example

```ts
import { PriceMonthly7 } from 'hetzner-cloud-apilib';

const priceMonthly7: PriceMonthly7 = {
  gross: '1.1900000000000000',
  net: '1.0000000000',
};
```

