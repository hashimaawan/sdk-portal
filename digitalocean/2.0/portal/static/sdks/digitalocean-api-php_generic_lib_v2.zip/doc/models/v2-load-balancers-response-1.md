
# V2 Load Balancers Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2LoadBalancersResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `loadBalancer` | [`?LoadBalancer1`](../../doc/models/load-balancer-1.md) | Optional | - | getLoadBalancer(): ?LoadBalancer1 | setLoadBalancer(?LoadBalancer1 loadBalancer): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2LoadBalancersResponse1Builder;
use DigitalOceanApiLib\Models\Builders\LoadBalancer1Builder;
use DigitalOceanApiLib\Models\Builders\ForwardingRuleBuilder;
use DigitalOceanApiLib\Models\EntryProtocol;
use DigitalOceanApiLib\Models\TargetProtocol;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Algorithm;
use DigitalOceanApiLib\Utils\DateTimeHelper;

$v2LoadBalancersResponse1 = V2LoadBalancersResponse1Builder::init()
    ->loadBalancer(
        LoadBalancer1Builder::init(
            [
                ForwardingRuleBuilder::init(
                    220,
                    EntryProtocol::HTTP2,
                    104,
                    TargetProtocol::HTTPS
                )
                    ->certificateId('certificate_id4')
                    ->tlsPassthrough(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                ForwardingRuleBuilder::init(
                    220,
                    EntryProtocol::HTTP2,
                    104,
                    TargetProtocol::HTTPS
                )
                    ->certificateId('certificate_id4')
                    ->tlsPassthrough(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            ]
        )
            ->algorithm(Algorithm::ROUND_ROBIN)
            ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->disableLetsEncryptDnsRecords(false)
            ->enableBackendKeepalive(false)
            ->enableProxyProtocol(false)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

