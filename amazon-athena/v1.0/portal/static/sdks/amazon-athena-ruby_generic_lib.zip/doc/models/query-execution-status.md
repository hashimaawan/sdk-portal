
# Query Execution Status

The completion date, current state, submission time, and state change reason (if applicable) for the query execution.

*This model accepts additional fields of type Object.*

## Structure

`QueryExecutionStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`QueryExecutionState1`](../../doc/models/query-execution-state-1.md) | Optional | - |
| `state_change_reason` | `String` | Optional | - |
| `submission_date_time` | `DateTime` | Optional | - |
| `completion_date_time` | `DateTime` | Optional | - |
| `athena_error` | [`AthenaError2`](../../doc/models/athena-error-2.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
query_execution_status = QueryExecutionStatus.new(
  state: QueryExecutionState1::QUEUED,
  state_change_reason: 'StateChangeReason8',
  submission_date_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  completion_date_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  athena_error: AthenaError2.new(
    error_category: 3,
    error_type: 128,
    retryable: false,
    error_message: 'ErrorMessage8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

