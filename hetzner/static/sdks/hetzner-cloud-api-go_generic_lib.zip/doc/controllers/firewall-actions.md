# Firewall Actions

```go
firewallActionsController := client.FirewallActionsController()
```

## Class Name

`FirewallActionsController`

## Methods

* [Get All Actions for a Firewall](../../doc/controllers/firewall-actions.md#get-all-actions-for-a-firewall)
* [Apply to Resources](../../doc/controllers/firewall-actions.md#apply-to-resources)
* [Remove from Resources](../../doc/controllers/firewall-actions.md#remove-from-resources)
* [Set Rules](../../doc/controllers/firewall-actions.md#set-rules)
* [Get an Action for a Firewall](../../doc/controllers/firewall-actions.md#get-an-action-for-a-firewall)


# Get All Actions for a Firewall

Returns all Action objects for a Firewall. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```go
GetAllActionsForAFirewall(
    ctx context.Context,
    id int,
    sort *models.ParameterSortEnum,
    status *models.ParameterStatusEnum) (
    models.ApiResponse[models.ActionsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |
| `sort` | [`*models.ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`*models.ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := firewallActionsController.GetAllActionsForAFirewall(ctx, id, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "set_firewall_rules",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Apply to Resources

Applies one Firewall to multiple resources.

Currently servers (public network interface) and label selectors are supported.

#### Call specific error codes

| Code                          | Description                                                   |
|-------------------------------|---------------------------------------------------------------|
| `firewall_already_applied`    | Firewall was already applied on resource                      |
| `incompatible_network_type`   | The Network type is incompatible for the given resource       |
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```go
ApplyToResources(
    ctx context.Context,
    id int,
    body *models.ApplyToResourcesRequest) (
    models.ApiResponse[models.ActionsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`*models.ApplyToResourcesRequest`](../../doc/models/apply-to-resources-request.md) | Body, Optional | - |

## Response Type

**201**: The `actions` key contains multiple `apply_firewall` Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.ApplyToResourcesRequest{
    ApplyTo:              []models.FirewallApplyToResources{
        models.FirewallApplyToResources{
            Server:               models.ToPointer(models.Server9{
                Id:                   42,
            }),
            Type:                 models.ToPointer(models.Type7Enum_SERVER),
        },
    },
}

apiResponse, err := firewallActionsController.ApplyToResources(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "apply_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Remove from Resources

Removes one Firewall from multiple resources.

Currently only Servers (and their public network interfaces) are supported.

#### Call specific error codes

| Code                                  | Description                                                            |
|---------------------------------------|------------------------------------------------------------------------|
| `firewall_already_removed`            | Firewall was already removed from the resource                         |
| `firewall_resource_not_found`         | The resource the Firewall should be attached to was not found          |
| `firewall_managed_by_label_selector`  | Firewall was applied via label selector and cannot be removed manually |

```go
RemoveFromResources(
    ctx context.Context,
    id int,
    body *models.RemoveFromResourcesRequest) (
    models.ApiResponse[models.ActionsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`*models.RemoveFromResourcesRequest`](../../doc/models/remove-from-resources-request.md) | Body, Optional | - |

## Response Type

**201**: The `actions` key contains multiple `remove_firewall` Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.RemoveFromResourcesRequest{
    RemoveFrom:           []models.FirewallRemoveFromResources{
        models.FirewallRemoveFromResources{
            Server:               models.ToPointer(models.Server9{
                Id:                   42,
            }),
            Type:                 models.ToPointer(models.Type7Enum_SERVER),
        },
    },
}

apiResponse, err := firewallActionsController.RemoveFromResources(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "remove_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Set Rules

Sets the rules of a Firewall.

All existing rules will be overwritten. Pass an empty `rules` array to remove all rules.
The maximum amount of rules that can be defined is 50.

#### Call specific error codes

| Code                          | Description                                                   |
|-------------------------------|---------------------------------------------------------------|
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```go
SetRules(
    ctx context.Context,
    id int,
    body *models.SetRulesRequest) (
    models.ApiResponse[models.ActionsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `body` | [`*models.SetRulesRequest`](../../doc/models/set-rules-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains one `set_firewall_rules` Action plus one `apply_firewall` Action per resource where the Firewall is active

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionsResponse](../../doc/models/actions-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.SetRulesRequest{
    Rules:                []models.Rule{
        models.Rule{
            Description:          models.NewOptional(models.ToPointer("Allow port 80")),
            Direction:            models.DirectionEnum_IN,
            Port:                 models.ToPointer("80"),
            Protocol:             models.ProtocolEnum_TCP,
            SourceIps:            []string{
                "28.239.13.1/32",
                "28.239.14.0/24",
                "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
            },
        },
    },
}

apiResponse, err := firewallActionsController.SetRules(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "set_firewall_rules",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    },
    {
      "command": "apply_firewall",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 14,
      "progress": 100,
      "resources": [
        {
          "id": 38,
          "type": "firewall"
        },
        {
          "id": 42,
          "type": "server"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Get an Action for a Firewall

Returns a specific Action for a Firewall.

```go
GetAnActionForAFirewall(
    ctx context.Context,
    id int,
    actionId int) (
    models.ApiResponse[models.ActionResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Firewall |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Firewall Action

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ActionResponse](../../doc/models/action-response.md).

## Example Usage

```go
ctx := context.Background()

id := 112

actionId := 224

apiResponse, err := firewallActionsController.GetAnActionForAFirewall(ctx, id, actionId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "set_firewall_rules",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 38,
        "type": "firewall"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

