
# Rebuild Server Request

*This model accepts additional fields of type Any.*

## Structure

`RebuildServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image` | `str` | Required | ID or name of Image to rebuilt from. |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.rebuild_server_request import RebuildServerRequest

rebuild_server_request = RebuildServerRequest(
    image='ubuntu-20.04',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

