
# Many Episodes

*This model accepts additional fields of type object.*

## Structure

`ManyEpisodes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Episodes` | [`List<EpisodeObject>`](../../doc/models/episode-object.md) | Required | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Utilities;
using System.Collections.Generic;

ManyEpisodes manyEpisodes = new ManyEpisodes
{
    Episodes = new List<EpisodeObject>
    {
        new EpisodeObject
        {
            AudioPreviewUrl = "https://p.scdn.co/mp3-preview/2f37da1d4221f40b9d1a98cd191f4d6f1646ad17",
            Description = "A Spotify podcast sharing fresh insights on important topics of the moment—in a way only Spotify can. You’ll hear from experts in the music, podcast and tech industries as we discover and uncover stories about our work and the world around us.\n",
            HtmlDescription = "<p>A Spotify podcast sharing fresh insights on important topics of the moment—in a way only Spotify can. You’ll hear from experts in the music, podcast and tech industries as we discover and uncover stories about our work and the world around us.</p>\n",
            DurationMs = 1686230,
            MExplicit = false,
            ExternalUrls = new ExternalUrlObject
            {
                Spotify = "spotify6",
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
            Href = "https://api.spotify.com/v1/episodes/5Xt5DXGzch68nYYamXrNxZ",
            Id = "5Xt5DXGzch68nYYamXrNxZ",
            Images = new List<ImageObject>
            {
                new ImageObject
                {
                    Url = "https://i.scdn.co/image/ab67616d00001e02ff9ca10b55ce82ae553c8228\n",
                    Height = 300,
                    Width = 300,
                    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                },
            },
            IsExternallyHosted = false,
            IsPlayable = false,
            Languages = new List<string>
            {
                "fr",
                "en",
            },
            Name = "Starting Your Own Podcast: Tips, Tricks, and Advice From Anchor Creators\n",
            ReleaseDate = "1981-12-15",
            ReleaseDatePrecision = ReleaseDatePrecision.Day,
            Type = "episode",
            Uri = "spotify:episode:0zLhl3WsOCQHbe1BPTiHgr",
            Show = new ShowBase
            {
                AvailableMarkets = new List<string>
                {
                    "available_markets0",
                    "available_markets1",
                    "available_markets2",
                },
                Copyrights = new List<CopyrightObject>
                {
                    new CopyrightObject
                    {
                        Text = "text2",
                        Type = "type2",
                        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    },
                },
                Description = "description4",
                HtmlDescription = "html_description4",
                MExplicit = false,
                ExternalUrls = new ExternalUrlObject
                {
                    Spotify = "spotify6",
                    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                },
                Href = "href8",
                Id = "id6",
                Images = new List<ImageObject>
                {
                    new ImageObject
                    {
                        Url = "https://i.scdn.co/image/ab67616d00001e02ff9ca10b55ce82ae553c8228\n",
                        Height = 300,
                        Width = 300,
                        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    },
                },
                IsExternallyHosted = false,
                Languages = new List<string>
                {
                    "languages7",
                    "languages6",
                    "languages5",
                },
                MediaType = "media_type6",
                Name = "name6",
                Publisher = "publisher6",
                Type = "show",
                Uri = "uri0",
                TotalEpisodes = 198,
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
            Language = "en",
            ResumePoint = new ResumePointObject
            {
                FullyPlayed = false,
                ResumePositionMs = 254,
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
            Restrictions = new EpisodeRestrictionObject
            {
                Reason = "reason0",
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

