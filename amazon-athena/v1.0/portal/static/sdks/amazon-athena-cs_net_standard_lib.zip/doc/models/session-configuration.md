
# Session Configuration

Contains session configuration information.

## Structure

`SessionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ExecutionRole` | `string` | Optional | **Constraints**: *Minimum Length*: `20`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:iam::\d{12}:role/?[a-zA-Z_0-9+=,.@\-_/]+$` |
| `WorkingDirectory` | `string` | Optional | - |
| `IdleTimeoutSeconds` | `int?` | Optional | - |
| `EncryptionConfiguration` | [`EncryptionConfiguration`](../../doc/models/encryption-configuration.md) | Optional | If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information. |

## Example

```csharp
using AmazonAthena.Standard.Models;

SessionConfiguration sessionConfiguration = new SessionConfiguration
{
    ExecutionRole = "ExecutionRole2",
    WorkingDirectory = "WorkingDirectory6",
    IdleTimeoutSeconds = 188,
    EncryptionConfiguration = new EncryptionConfiguration
    {
        EncryptionOption = EncryptionOption1Enum.SSES3,
        KmsKey = "KmsKey6",
    },
};
```

