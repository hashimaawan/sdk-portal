
# Encryption Option Enum

## Enumeration

`EncryptionOptionEnum`

## Fields

| Name |
|  --- |
| `SSES3` |
| `SSEKMS` |
| `CSEKMS` |

## Example

```ts
import { EncryptionOptionEnum } from 'amazon-athenalib';

const encryptionOption = EncryptionOptionEnum.SSES3;
```

