
# X Amz Target 44 Enum

## Enumeration

`XAmzTarget44Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTAGSFORRESOURCE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget44Enum;

$xAmzTarget44 = XAmzTarget44Enum::ENUM_AMAZONATHENALISTTAGSFORRESOURCE;
```

