
# Parameters

## Structure

`Parameters`

## Fields

|  |
| 

## Example (as JSON)

```json
{}
```

