
# List Calculation Executions Response

*This model accepts additional fields of type Object.*

## Structure

`ListCalculationExecutionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NextToken` | `String` | Optional | **Constraints**: *Maximum Length*: `2048` | String getNextToken() | setNextToken(String nextToken) |
| `Calculations` | [`List<CalculationSummary>`](../../doc/models/calculation-summary.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` | List<CalculationSummary> getCalculations() | setCalculations(List<CalculationSummary> calculations) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.DateTimeHelper;
import com.amazonaws.useast1.athena.models.CalculationExecutionState1;
import com.amazonaws.useast1.athena.models.CalculationSummary;
import com.amazonaws.useast1.athena.models.ListCalculationExecutionsResponse;
import com.amazonaws.useast1.athena.models.Status1;
import java.io.IOException;
import java.util.Arrays;

ListCalculationExecutionsResponse listCalculationExecutionsResponse = new ListCalculationExecutionsResponse.Builder()
    .nextToken("NextToken8")
    .calculations(Arrays.asList(
        new CalculationSummary.Builder()
            .calculationExecutionId("CalculationExecutionId0")
            .description("Description2")
            .status(new Status1.Builder()
                .submissionDateTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
                .completionDateTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
                .state(CalculationExecutionState1.CANCELING)
                .stateChangeReason("StateChangeReason8")
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build())
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

