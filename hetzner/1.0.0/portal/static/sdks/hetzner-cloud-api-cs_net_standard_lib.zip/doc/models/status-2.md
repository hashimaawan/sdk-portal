
# Status 2

Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates

*This model accepts additional fields of type object.*

## Structure

`Status2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`Error2`](../../doc/models/error-2.md) | Optional | If issuance or renewal reports `failed`, this property contains information about what happened |
| `Issuance` | [`Issuance?`](../../doc/models/issuance.md) | Optional | Status of the issuance process of the Certificate |
| `Renewal` | [`Renewal?`](../../doc/models/renewal.md) | Optional | Status of the renewal process of the Certificate. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

Status2 status2 = new Status2
{
    Error = null,
    Issuance = Issuance.Completed,
    Renewal = Renewal.Scheduled,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

