
# Status 72

Status of the Firewall on the Server

## Enumeration

`Status72`

## Fields

| Name |
|  --- |
| `APPLIED` |
| `PENDING` |

## Example

```python
from hetznercloudapi.models.status_72 import Status72

status_72 = Status72.APPLIED
```

