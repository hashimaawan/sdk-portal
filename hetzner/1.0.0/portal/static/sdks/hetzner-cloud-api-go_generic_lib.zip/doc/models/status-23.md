
# Status 23

## Enumeration

`Status23`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    status23 := models.Status23_Available

}
```

