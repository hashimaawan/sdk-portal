
# V2 Images Actions Request 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2ImagesActionsRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type15`](../../doc/models/type-15.md) | Required | The action to be taken on the image. Can be either `convert` or `transfer`. |
| `region` | [`Region2`](../../doc/models/region-2.md) | Required | The slug identifier for the region where the resource will initially be  available. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_images_actions_request1 = V2ImagesActionsRequest1.new(
  type: Type15::CONVERT,
  region: Region2::NYC3,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

