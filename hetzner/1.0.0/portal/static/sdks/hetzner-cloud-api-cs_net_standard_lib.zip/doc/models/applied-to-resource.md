
# Applied to Resource

*This model accepts additional fields of type object.*

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `Type` | [`Type5?`](../../doc/models/type-5.md) | Optional | Type of resource referenced |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

AppliedToResource appliedToResource = new AppliedToResource
{
    Server = new Server
    {
        Id = 14,
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    Type = Type5.Server,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

