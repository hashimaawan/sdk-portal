
# X Amz Target 18

## Enumeration

`XAmzTarget18`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetdatacatalog` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget18 := models.XAmzTarget18_EnumAmazonathenagetdatacatalog

}
```

