
# Executor State Enum

## Enumeration

`ExecutorStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```java
import com.amazonaws.useast1.athena.models.ExecutorStateEnum;

ExecutorStateEnum executorState = ExecutorStateEnum.TERMINATED;
```

