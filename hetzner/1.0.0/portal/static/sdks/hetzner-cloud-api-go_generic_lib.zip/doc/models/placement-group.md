
# Placement Group

*This model accepts additional fields of type interface{}.*

## Structure

`PlacementGroup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Created` | `string` | Required | Point in time when the Resource was created (in ISO-8601 format) |
| `Id` | `int` | Required | ID of the Resource |
| `Labels` | `map[string]string` | Required | User-defined labels (key-value pairs) |
| `Name` | `string` | Required | Name of the Resource. Must be unique per Project. |
| `Servers` | `[]int` | Required | Array of IDs of Servers that are part of this Placement Group |
| `Type` | `string` | Required, Constant | Type of the Placement Group<br><br>**Value**: `"spread"` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    placementGroup := models.PlacementGroup{
        Created:               "2016-01-30T23:55:00+00:00",
        Id:                    42,
        Labels:                map[string]string{
            "key0": "labels4",
            "key1": "labels5",
            "key2": "labels6",
        },
        Name:                  "my-resource",
        Servers:               []int{
            42,
        },
        Type:                  "spread",
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

