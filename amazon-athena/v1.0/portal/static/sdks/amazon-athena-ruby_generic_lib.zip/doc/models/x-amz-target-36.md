
# X Amz Target 36

## Enumeration

`XAmzTarget36`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTEXECUTORS` |

## Example

```ruby
x_amz_target36 = XAmzTarget36::ENUM_AMAZONATHENALISTEXECUTORS
```

