
# Iso

## Structure

`Iso`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Deprecated` | `string` | Required | ISO 8601 timestamp of deprecation, null if ISO is still available. After the deprecation time it will no longer be possible to attach the ISO to Servers. |
| `Description` | `string` | Required | Description of the ISO |
| `Id` | `int` | Required | ID of the Resource |
| `Name` | `string` | Required | Unique identifier of the ISO. Only set for public ISOs |
| `Type` | [`Type26Enum`](../../doc/models/type-26-enum.md) | Required | Type of the ISO |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Iso iso = new Iso
{
    Deprecated = "2018-02-28T00:00:00+00:00",
    Description = "FreeBSD 11.0 x64",
    Id = 42,
    Name = "FreeBSD-11.0-RELEASE-amd64-dvd1",
    Type = Type26Enum.Public,
};
```

