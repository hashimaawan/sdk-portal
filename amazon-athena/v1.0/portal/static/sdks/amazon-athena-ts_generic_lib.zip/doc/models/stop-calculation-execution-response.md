
# Stop Calculation Execution Response

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`CalculationExecutionState4Enum \| undefined`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```ts
import {
  CalculationExecutionState4Enum,
  StopCalculationExecutionResponse,
} from 'amazon-athenalib';

const stopCalculationExecutionResponse: StopCalculationExecutionResponse = {
  state: CalculationExecutionState4Enum.QUEUED,
};
```

