
# Status 13

## Enumeration

`Status13`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `ERROR` |

## Example

```ruby
status13 = Status13::SUCCESS
```

