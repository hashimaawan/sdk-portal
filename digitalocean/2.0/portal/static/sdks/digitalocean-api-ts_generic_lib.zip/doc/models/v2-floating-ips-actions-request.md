
# V2 Floating Ips Actions Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FloatingIpsActionsRequest`

## Inherits From

[`BaseType`](../../doc/models/base-type.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletId` | `number` | Required | The ID of the Droplet that the floating IP will be assigned to. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FloatingIpsActionsRequest } from 'digitalocean-apilib';

const v2FloatingIpsActionsRequest: V2FloatingIpsActionsRequest = {
  dropletId: 758604968,
  type: 'V2 Floating Ips Actions Request',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

