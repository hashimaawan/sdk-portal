
# Data

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Data`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `result` | [`Result[]`](../../doc/models/result.md) | Required | Result of query. | getResult(): array | setResult(array result): void |
| `resultType` | `string` | Required, Constant | **Value**: `'matrix'` | getResultType(): string | setResultType(string resultType): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\DataBuilder;
use DigitalOceanApiLib\Models\Builders\ResultBuilder;
use DigitalOceanApiLib\ApiHelper;

$data = DataBuilder::init(
    [
        ResultBuilder::init(
            [
                'host_id' => '19201920'
            ],
            [
                [
                    1435781430,
                    '1'
                ],
                [
                    1435781445,
                    '1'
                ]
            ]
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

