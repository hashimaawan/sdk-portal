
# Item

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Item`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `?string` | Optional | Amount of the charge | getAmount(): ?string | setAmount(?string amount): void |
| `count` | `?string` | Optional | Number of times the charge was applied | getCount(): ?string | setCount(?string count): void |
| `name` | `?string` | Optional | Description of the charge | getName(): ?string | setName(?string name): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\ItemBuilder;
use DigitalOceanApiLib\ApiHelper;

$item = ItemBuilder::init()
    ->amount('10.00')
    ->count('1')
    ->name('Spaces Subscription')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

