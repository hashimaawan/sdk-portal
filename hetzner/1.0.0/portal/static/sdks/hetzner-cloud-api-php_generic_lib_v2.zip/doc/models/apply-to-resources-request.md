
# Apply to Resources Request

## Structure

`ApplyToResourcesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `applyTo` | [`FirewallApplyToResources[]`](../../doc/models/firewall-apply-to-resources.md) | Required | Resources the Firewall should be applied to | getApplyTo(): array | setApplyTo(array applyTo): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ApplyToResourcesRequestBuilder;
use HetznerCloudAPILib\Models\Builders\FirewallApplyToResourcesBuilder;
use HetznerCloudAPILib\Models\Builders\LabelSelector5Builder;
use HetznerCloudAPILib\Models\Builders\Server9Builder;
use HetznerCloudAPILib\Models\Type7Enum;

$applyToResourcesRequest = ApplyToResourcesRequestBuilder::init(
    [
        FirewallApplyToResourcesBuilder::init()
            ->labelSelector(
                LabelSelector5Builder::init(
                    'selector8'
                )->build()
            )
            ->server(
                Server9Builder::init(
                    14
                )->build()
            )
            ->type(Type7Enum::SERVER)
            ->build()
    ]
)->build();
```

