
# Product Charges

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`ProductCharges`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `String` | Optional | Total amount charged |
| `items` | [`Array[Item]`](../../doc/models/item.md) | Optional | List of amount, and grouped aggregates by resource type. |
| `name` | `String` | Optional | Description of usage charges |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
product_charges = ProductCharges.new(
  amount: '12.34',
  items: [
    Item.new(
      amount: '10.00',
      count: '1',
      name: 'Spaces Subscription',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Item.new(
      amount: '2.34',
      count: '1',
      name: 'Database Clusters',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  name: 'Product usage charges',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

