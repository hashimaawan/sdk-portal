# Floating I Ps

```go
floatingIPsApi := client.FloatingIPsApi()
```

## Class Name

`FloatingIPsApi`

## Methods

* [Get All Floating I Ps](../../doc/controllers/floating-i-ps.md#get-all-floating-i-ps)
* [Create a Floating IP](../../doc/controllers/floating-i-ps.md#create-a-floating-ip)
* [Delete a Floating IP](../../doc/controllers/floating-i-ps.md#delete-a-floating-ip)
* [Get a Floating IP](../../doc/controllers/floating-i-ps.md#get-a-floating-ip)
* [Update a Floating IP](../../doc/controllers/floating-i-ps.md#update-a-floating-ip)


# Get All Floating I Ps

Returns all Floating IP objects.

```go
GetAllFloatingIPs(
    ctx context.Context,
    name *string,
    labelSelector *string,
    sort *models.Sort2) (
    models.ApiResponse[models.FloatingIpsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `*string` | Query, Optional | Can be used to filter Floating IPs by their name. The response will only contain the Floating IP matching the specified name. |
| `labelSelector` | `*string` | Query, Optional | Can be used to filter Floating IPs by labels. The response will only contain Floating IPs matching the label selector. |
| `sort` | [`*models.Sort2`](../../doc/models/sort-2.md) | Query, Optional | Can be used multiple times. Choices id id:asc id:desc created created:asc created:desc |

## Response Type

**200**: The `floating_ips` key in the reply contains an array of Floating IP objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.FloatingIpsResponse](../../doc/models/floating-ips-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := floatingIPsApi.GetAllFloatingIPs(ctx, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Create a Floating IP

Creates a new Floating IP assigned to a Server. If you want to create a Floating IP that is not bound to a Server, you need to provide the `home_location` key instead of `server`. This can be either the ID or the name of the Location this IP shall be created in. Note that a Floating IP can be assigned to a Server in any Location later on. For optimal routing it is advised to use the Floating IP in the same Location it was created in.

```go
CreateAFloatingIp(
    ctx context.Context,
    body *models.CreateFloatingIpRequest) (
    models.ApiResponse[models.FloatingIpsResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`*models.CreateFloatingIpRequest`](../../doc/models/create-floating-ip-request.md) | Body, Optional | The `type` argument is required while `home_location` and `server` are mutually exclusive. |

## Response Type

**201**: The `floating_ip` key in the reply contains the object that was just created

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.FloatingIpsResponse1](../../doc/models/floating-ips-response-1.md).

## Example Usage

```go
ctx := context.Background()

body := models.CreateFloatingIpRequest{
    Description:           models.ToPointer("Web Frontend"),
    HomeLocation:          models.ToPointer("fsn1"),
    Labels:                models.ToPointer(interface{}("[labelkey, value]")),
    Name:                  models.ToPointer("Web Frontend"),
    Server:                models.ToPointer(42),
    Type:                  models.Type17_Ipv4,
}

apiResponse, err := floatingIPsApi.CreateAFloatingIp(ctx, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_floating_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "floating_ip": {
    "blocked": false,
    "created": "2016-01-30T23:50:00+00:00",
    "description": "Web Frontend",
    "dns_ptr": [
      {
        "dns_ptr": "server.example.com",
        "ip": "2001:db8::1"
      }
    ],
    "home_location": {
      "city": "Falkenstein",
      "country": "DE",
      "description": "Falkenstein DC Park 1",
      "id": 1,
      "latitude": 50.47612,
      "longitude": 12.370071,
      "name": "fsn1",
      "network_zone": "eu-central"
    },
    "id": 4711,
    "ip": "131.232.99.1",
    "labels": {
      "env": "dev"
    },
    "name": "Web Frontend",
    "protection": {
      "delete": false
    },
    "server": 42,
    "type": "ipv4"
  }
}
```


# Delete a Floating IP

Deletes a Floating IP. If it is currently assigned to a Server it will automatically get unassigned.

```go
DeleteAFloatingIp(
    ctx context.Context,
    id int) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |

## Response Type

**204**: Floating IP deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

id := 112

resp, err := floatingIPsApi.DeleteAFloatingIp(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```


# Get a Floating IP

Returns a specific Floating IP object.

```go
GetAFloatingIp(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.FloatingIpsResponse2],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |

## Response Type

**200**: The `floating_ip` key in the reply contains a Floating IP object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.FloatingIpsResponse2](../../doc/models/floating-ips-response-2.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := floatingIPsApi.GetAFloatingIp(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Update a Floating IP

Updates the description or labels of a Floating IP.
Also note that when updating labels, the Floating IP’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```go
UpdateAFloatingIp(
    ctx context.Context,
    id int,
    body *models.UpdateFloatingIpRequest) (
    models.ApiResponse[models.FloatingIpsResponse2],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Floating IP |
| `body` | [`*models.UpdateFloatingIpRequest`](../../doc/models/update-floating-ip-request.md) | Body, Optional | - |

## Response Type

**200**: The `floating_ip` key in the reply contains the modified Floating IP object with the new description

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.FloatingIpsResponse2](../../doc/models/floating-ips-response-2.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.UpdateFloatingIpRequest{
    Description:           models.ToPointer("Web Frontend"),
    Labels:                models.ToPointer(interface{}("[labelkey, value]")),
    Name:                  models.ToPointer("Web Frontend"),
}

apiResponse, err := floatingIPsApi.UpdateAFloatingIp(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "floating_ip": {
    "blocked": false,
    "created": "2016-01-30T23:50:00+00:00",
    "description": "Web Frontend",
    "dns_ptr": [
      {
        "dns_ptr": "server.example.com",
        "ip": "2001:db8::1"
      }
    ],
    "home_location": {
      "city": "Falkenstein",
      "country": "DE",
      "description": "Falkenstein DC Park 1",
      "id": 1,
      "latitude": 50.47612,
      "longitude": 12.370071,
      "name": "fsn1",
      "network_zone": "eu-central"
    },
    "id": 4711,
    "ip": "131.232.99.1",
    "labels": {
      "labelkey": "value"
    },
    "name": "Web Frontend",
    "protection": {
      "delete": false
    },
    "server": 42,
    "type": "ipv4"
  }
}
```

