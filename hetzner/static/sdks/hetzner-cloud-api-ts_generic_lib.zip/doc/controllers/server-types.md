# Server Types

```ts
const serverTypesController = new ServerTypesController(client);
```

## Class Name

`ServerTypesController`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```ts
async getAllServerTypes(
  name?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ServerTypesResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ServerTypesResponse`](../../doc/models/server-types-response.md).

## Example Usage

```ts
try {
  const response = await serverTypesController.getAllServerTypes();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```


# Get a Server Type

Gets a specific Server type object.

```ts
async getAServerType(
  id: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ServerTypesResponse1>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of Server Type |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ServerTypesResponse1`](../../doc/models/server-types-response-1.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await serverTypesController.getAServerType(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

