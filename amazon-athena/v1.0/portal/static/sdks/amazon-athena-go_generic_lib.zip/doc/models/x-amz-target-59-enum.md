
# X Amz Target 59 Enum

## Enumeration

`XAmzTarget59Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAUPDATEWORKGROUP` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget59 := models.XAmzTarget59Enum_ENUMAMAZONATHENAUPDATEWORKGROUP

}
```

