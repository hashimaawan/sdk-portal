
# Primary I Ps Response

*This model accepts additional fields of type Object.*

## Structure

`PrimaryIPsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meta` | [`Meta`](../../doc/models/meta.md) | Optional | - |
| `primary_ips` | [`Array[PrimaryIp1]`](../../doc/models/primary-ip-1.md) | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
primary_i_ps_response = PrimaryIPsResponse.new(
  primary_ips: [
    PrimaryIp1.new(
      assignee_id: 17,
      assignee_type: 'server',
      auto_delete: true,
      blocked: false,
      created: '2016-01-30T23:55:00+00:00',
      datacenter: Datacenter2.new(
        description: 'Falkenstein DC Park 8',
        id: 42,
        location: Location.new(
          city: 'Falkenstein',
          country: 'DE',
          description: 'Falkenstein DC Park 1',
          id: 1,
          latitude: 50.47612,
          longitude: 12.370071,
          name: 'fsn1',
          network_zone: 'eu-central',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        name: 'fsn1-dc8',
        server_types: ServerTypes.new(
          available: [
            1,
            2,
            3
          ],
          available_for_migration: [
            1,
            2,
            3
          ],
          supported: [
            1,
            2,
            3
          ],
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      dns_ptr: [
        DnsPtr.new(
          dns_ptr: 'server.example.com',
          ip: '2001:db8::1',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      id: 42,
      ip: '131.232.99.1',
      labels: {
        'key0' => 'labels2',
        'key1' => 'labels3',
        'key2' => 'labels4'
      },
      name: 'my-resource',
      protection: Protection.new(
        delete: false,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      type: Type50::IPV4,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  meta: Meta.new(
    pagination: Pagination.new(
      last_page: 77.7,
      next_page: 209.18,
      page: 17.58,
      per_page: 13.34,
      previous_page: 50.02,
      total_entries: 206.64,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

