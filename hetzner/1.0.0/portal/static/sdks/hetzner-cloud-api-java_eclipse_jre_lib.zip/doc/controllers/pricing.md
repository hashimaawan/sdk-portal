# Pricing

Returns prices for resources.

```java
PricingApi pricingApi = client.getPricingApi();
```

## Class Name

`PricingApi`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```java
CompletableFuture<ApiResponse<PricingResponse>> getAllPricesAsync()
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PricingResponse`](../../doc/models/pricing-response.md).

## Example Usage

```java
pricingApi.getAllPricesAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

