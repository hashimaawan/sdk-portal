
# X Amz Target 40 Enum

## Enumeration

`XAmzTarget40Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget40Enum;

XAmzTarget40Enum xAmzTarget40 = XAmzTarget40Enum.ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS;
```

