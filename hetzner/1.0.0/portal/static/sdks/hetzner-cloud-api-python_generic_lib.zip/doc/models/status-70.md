
# Status 70

## Enumeration

`Status70`

## Fields

| Name |
|  --- |
| `INITIALIZING` |
| `STARTING` |
| `RUNNING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `REBUILDING` |
| `MIGRATING` |
| `UNKNOWN` |

## Example

```python
from hetznercloudapi.models.status_70 import Status70

status_70 = Status70.DELETING
```

