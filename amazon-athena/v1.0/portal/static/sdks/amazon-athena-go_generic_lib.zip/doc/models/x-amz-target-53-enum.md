
# X Amz Target 53 Enum

## Enumeration

`XAmzTarget53Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAUNTAGRESOURCE` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget53 := models.XAmzTarget53Enum_ENUMAMAZONATHENAUNTAGRESOURCE

}
```

