
# X Amz Target 19

## Enumeration

`XAmzTarget19`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetdatabase` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget19 := models.XAmzTarget19_EnumAmazonathenagetdatabase

}
```

