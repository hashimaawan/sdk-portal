
# Get Notebook Metadata Input

## Structure

`GetNotebookMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```python
from amazonathena.models.get_notebook_metadata_input import GetNotebookMetadataInput

get_notebook_metadata_input = GetNotebookMetadataInput(
    notebook_id='NotebookId4'
)
```

