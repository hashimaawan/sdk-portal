
# X Amz Target 16 Enum

## Enumeration

`XAmzTarget16Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecutionCode` |

## Example

```ts
import { XAmzTarget16Enum } from 'amazon-athenalib';

const xAmzTarget16 = XAmzTarget16Enum.EnumAmazonAthenaGetCalculationExecutionCode;
```

