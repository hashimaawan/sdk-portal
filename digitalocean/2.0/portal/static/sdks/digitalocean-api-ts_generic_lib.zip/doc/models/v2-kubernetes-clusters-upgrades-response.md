
# V2 Kubernetes Clusters Upgrades Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUpgradesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `availableUpgradeVersions` | [`AvailableUpgradeVersion[] \| null \| undefined`](../../doc/models/available-upgrade-version.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2KubernetesClustersUpgradesResponse } from 'digitalocean-apilib';

const v2KubernetesClustersUpgradesResponse: V2KubernetesClustersUpgradesResponse = {
  availableUpgradeVersions: [
    {
      kubernetesVersion: 'kubernetes_version0',
      slug: 'slug2',
      supportedFeatures: [
        'supported_features3'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

