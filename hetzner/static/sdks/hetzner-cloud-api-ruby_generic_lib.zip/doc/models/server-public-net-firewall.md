
# Server Public Net Firewall

## Structure

`ServerPublicNetFirewall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | ID of the Resource |
| `status` | [`Status72Enum`](../../doc/models/status-72-enum.md) | Optional | Status of the Firewall on the Server |

## Example

```ruby
server_public_net_firewall = ServerPublicNetFirewall.new(
  42,
  Status72Enum::APPLIED
)
```

