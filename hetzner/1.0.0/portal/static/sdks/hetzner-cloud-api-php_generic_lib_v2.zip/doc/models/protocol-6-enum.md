
# Protocol 6 Enum

Type of the health check

## Enumeration

`Protocol6Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |

## Example

```php
use HetznerCloudAPILib\Models\Protocol6Enum;

$protocol6 = Protocol6Enum::TCP;
```

