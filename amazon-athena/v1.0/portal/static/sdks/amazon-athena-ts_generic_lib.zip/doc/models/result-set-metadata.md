
# Result Set Metadata

The metadata that describes the column structure and data types of a table of query results. To return a <code>ResultSetMetadata</code> object, use <a>GetQueryResults</a>.

## Structure

`ResultSetMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `columnInfo` | [`ColumnInfo[] \| undefined`](../../doc/models/column-info.md) | Optional | - |

## Example

```ts
import { ResultSetMetadata } from 'amazon-athenalib';

const resultSetMetadata: ResultSetMetadata = {
  columnInfo: [
    {
      name: 'Name6',
      type: 'Type6',
      catalogName: 'CatalogName0',
      schemaName: 'SchemaName0',
      tableName: 'TableName2',
      label: 'Label4',
      precision: 48,
    },
    {
      name: 'Name6',
      type: 'Type6',
      catalogName: 'CatalogName0',
      schemaName: 'SchemaName0',
      tableName: 'TableName2',
      label: 'Label4',
      precision: 48,
    }
  ],
};
```

