
# Load Balancers Actions Change Algorithm Request

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type39Enum`](../../doc/models/type-39-enum.md) | Required | Algorithm of the Load Balancer |

## Example

```ruby
load_balancers_actions_change_algorithm_request = LoadBalancersActionsChangeAlgorithmRequest.new(
  Type39Enum::ROUND_ROBIN
)
```

