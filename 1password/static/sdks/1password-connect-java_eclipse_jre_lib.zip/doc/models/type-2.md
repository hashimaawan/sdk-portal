
# Type 2

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `USER_CREATED` |
| `PERSONAL` |
| `EVERYONE` |
| `TRANSFER` |

## Example

```java
import local.m1password.models.Type2;

Type2 type2 = Type2.EVERYONE;
```

