
# Vault 3

*This model accepts additional fields of type interface{}.*

## Structure

`Vault3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `*string` | Optional | **Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    vault3 := models.Vault3{
        Id:                    models.ToPointer("id0"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

