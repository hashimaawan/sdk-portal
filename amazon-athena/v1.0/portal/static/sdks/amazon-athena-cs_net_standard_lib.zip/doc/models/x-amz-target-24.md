
# X Amz Target 24

## Enumeration

`XAmzTarget24`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryResults` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget24 xAmzTarget24 = XAmzTarget24.EnumAmazonAthenaGetQueryResults;
```

