
# V2 Floating Ips Actions Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FloatingIpsActionsRequest`

## Inherits From

[`BaseType`](../../doc/models/base-type.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_id` | `Integer` | Required | The ID of the Droplet that the floating IP will be assigned to. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_floating_ips_actions_request = V2FloatingIpsActionsRequest.new(
  droplet_id: 758604968,
  type: 'V2 Floating Ips Actions Request',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

