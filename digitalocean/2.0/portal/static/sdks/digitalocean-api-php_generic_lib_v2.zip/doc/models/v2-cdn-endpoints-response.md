
# V2 Cdn Endpoints Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `endpoints` | [`?(Endpoint[])`](../../doc/models/endpoint.md) | Optional | - | getEndpoints(): ?array | setEndpoints(?array endpoints): void |
| `links` | [`?Links`](../../doc/models/links.md) | Optional | - | getLinks(): ?Links | setLinks(?Links links): void |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - | getMeta(): Meta | setMeta(Meta meta): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2CdnEndpointsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\MetaBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\EndpointBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\Models\Ttl;
use DigitalOceanApiLib\Models\Builders\LinksBuilder;
use DigitalOceanApiLib\Models\Builders\PagesBuilder;

$v2CdnEndpointsResponse = V2CdnEndpointsResponseBuilder::init(
    MetaBuilder::init(
        1
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->endpoints(
        [
            EndpointBuilder::init(
                'static-images.nyc3.digitaloceanspaces.com'
            )
                ->certificateId('892071a0-bb95-49bc-8021-3afd67a210bf')
                ->createdAt(DateTimeHelper::fromRfc3339DateTime('2018-07-19T15:04:16Z'))
                ->customDomain('static.example.com')
                ->endpoint('static-images.nyc3.cdn.digitaloceanspaces.com')
                ->id('19f06b6a-3ace-4315-b086-499a0e521b76')
                ->ttl(Ttl::ENUM_3600)
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->links(
        LinksBuilder::init()
            ->pages(
                PagesBuilder::init()
                    ->last('last6')
                    ->next('next2')
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

