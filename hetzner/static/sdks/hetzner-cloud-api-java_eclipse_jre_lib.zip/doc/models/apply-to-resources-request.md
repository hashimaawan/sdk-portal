
# Apply to Resources Request

## Structure

`ApplyToResourcesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ApplyTo` | [`List<FirewallApplyToResources>`](../../doc/models/firewall-apply-to-resources.md) | Required | Resources the Firewall should be applied to | List<FirewallApplyToResources> getApplyTo() | setApplyTo(List<FirewallApplyToResources> applyTo) |

## Example

```java
import cloud.hetzner.api.models.ApplyToResourcesRequest;
import cloud.hetzner.api.models.FirewallApplyToResources;
import cloud.hetzner.api.models.LabelSelector5;
import cloud.hetzner.api.models.Server9;
import cloud.hetzner.api.models.Type7Enum;
import java.util.Arrays;

ApplyToResourcesRequest applyToResourcesRequest = new ApplyToResourcesRequest.Builder(
    Arrays.asList(
        new FirewallApplyToResources.Builder()
            .labelSelector(new LabelSelector5.Builder(
                "selector8"
            )
            .build())
            .server(new Server9.Builder(
                14
            )
            .build())
            .type(Type7Enum.SERVER)
            .build()
    )
)
.build();
```

