
# X Amz Target 20

## Enumeration

`XAmzTarget20`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget20;

$xAmzTarget20 = XAmzTarget20::ENUM_AMAZONATHENAGETNAMEDQUERY;
```

