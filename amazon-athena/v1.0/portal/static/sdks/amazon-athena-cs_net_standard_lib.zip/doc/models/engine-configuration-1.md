
# Engine Configuration 1

*This model accepts additional fields of type object.*

## Structure

`EngineConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CoordinatorDpuSize` | `int?` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `MaxConcurrentDpus` | `int` | Required | **Constraints**: `>= 2`, `<= 5000` |
| `DefaultExecutorDpuSize` | `int?` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `AdditionalConfigs` | [`AdditionalConfigs`](../../doc/models/additional-configs.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

EngineConfiguration1 engineConfiguration1 = new EngineConfiguration1
{
    MaxConcurrentDpus = 214,
    CoordinatorDpuSize = 1,
    DefaultExecutorDpuSize = 1,
    AdditionalConfigs = new AdditionalConfigs
    {
        ["exampleAdditionalProperty"] = "AdditionalConfigs_additionalProperties5",
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

