
# Get Session Status Request

## Structure

`GetSessionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ruby
get_session_status_request = GetSessionStatusRequest.new(
  'SessionId4'
)
```

