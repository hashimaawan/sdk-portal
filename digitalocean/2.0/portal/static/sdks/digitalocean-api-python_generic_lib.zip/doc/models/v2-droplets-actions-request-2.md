
# V2 Droplets Actions Request 2

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `image` | `int` | Optional | The ID of a backup of the current Droplet instance to restore from. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.type_12 import Type12
from digitaloceanapi.models.v_2_droplets_actions_request_2 import V2DropletsActionsRequest2

v_2_droplets_actions_request_2 = V2DropletsActionsRequest2(
    mtype=Type12.REBOOT,
    image=12389723,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

