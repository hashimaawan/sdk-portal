
# X Amz Target 28

## Enumeration

`XAmzTarget28`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetTableMetadata` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget28 xAmzTarget28 = XAmzTarget28.EnumAmazonAthenaGetTableMetadata;
```

