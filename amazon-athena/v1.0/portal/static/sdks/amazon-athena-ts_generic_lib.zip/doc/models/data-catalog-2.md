
# Data Catalog 2

## Structure

`DataCatalog2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `type` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `parameters` | [`Parameters \| undefined`](../../doc/models/parameters.md) | Optional | - |

## Example

```ts
import { DataCatalog2, DataCatalogType1Enum } from 'amazon-athenalib';

const dataCatalog2: DataCatalog2 = {
  name: 'Name6',
  type: DataCatalogType1Enum.LAMBDA,
  description: 'Description0',
  parameters: {},
};
```

