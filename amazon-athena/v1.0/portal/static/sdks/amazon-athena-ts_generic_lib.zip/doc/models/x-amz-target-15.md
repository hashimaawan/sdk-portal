
# X Amz Target 15

## Enumeration

`XAmzTarget15`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecution` |

## Example

```ts
import { XAmzTarget15 } from 'amazon-athenalib';

const xAmzTarget15 = XAmzTarget15.EnumAmazonAthenaGetCalculationExecution;
```

