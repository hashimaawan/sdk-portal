
# Protocol Enum

Type of traffic to allow

## Enumeration

`ProtocolEnum`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Udp` |
| `Icmp` |
| `Esp` |
| `Gre` |

## Example

```ts
import { ProtocolEnum } from 'hetzner-cloud-apilib';

const protocol = ProtocolEnum.Esp;
```

