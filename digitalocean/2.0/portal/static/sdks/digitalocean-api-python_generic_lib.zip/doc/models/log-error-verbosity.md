
# Log Error Verbosity

Controls the amount of detail written in the server log for each message that is logged.

## Enumeration

`LogErrorVerbosity`

## Fields

| Name |
|  --- |
| `TERSE` |
| `DEFAULT` |
| `VERBOSE` |

## Example

```python
from digitaloceanapi.models.log_error_verbosity import LogErrorVerbosity

log_error_verbosity = LogErrorVerbosity.DEFAULT
```

