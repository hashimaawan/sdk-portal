
# Dns Ptr

## Structure

`DnsPtr`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dnsPtr` | `string` | Required | DNS pointer for the specific IP address |
| `ip` | `string` | Required | Single IPv4 or IPv6 address |

## Example

```ts
import { DnsPtr } from 'hetzner-cloud-apilib';

const dnsPtr: DnsPtr = {
  dnsPtr: 'server.example.com',
  ip: '2001:db8::1',
};
```

