# Forex

```php
$forexApi = $client->getForexApi();
```

## Class Name

`ForexApi`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```php
function getQuotesForAllSymbols(): ApiResponse
```

## Response Type

**200**: A list of quotes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$forexApi = $client->getForexApi();
$apiResponse = $forexApi->getQuotesForAllSymbols();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```php
function getAListOfSymbolsForWhichWeProvideRealTimeQuotes(): ApiResponse
```

## Response Type

**200**: A list of symbols

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `string[]`.

## Example Usage

```php
$forexApi = $client->getForexApi();
$apiResponse = $forexApi->getAListOfSymbolsForWhichWeProvideRealTimeQuotes();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'string[]:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

