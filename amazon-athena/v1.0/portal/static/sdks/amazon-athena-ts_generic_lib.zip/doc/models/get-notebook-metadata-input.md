
# Get Notebook Metadata Input

*This model accepts additional fields of type unknown.*

## Structure

`GetNotebookMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetNotebookMetadataInput } from 'amazon-athenalib';

const getNotebookMetadataInput: GetNotebookMetadataInput = {
  notebookId: 'NotebookId0',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

