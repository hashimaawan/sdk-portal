
# Change Protection Request 1

*This model accepts additional fields of type Any.*

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `bool` | Optional | If true, prevents the Network from being deleted |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.change_protection_request_1 import ChangeProtectionRequest1

change_protection_request_1 = ChangeProtectionRequest1(
    delete=True,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

