
# Playlists Followers Request

*This model accepts additional fields of type Object.*

## Structure

`PlaylistsFollowersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `public` | `TrueClass \| FalseClass` | Optional | Defaults to `true`. If `true` the playlist will be included in user's public playlists, if `false` it will remain private. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
playlists_followers_request = PlaylistsFollowersRequest.new(
  public: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

