
# Update Placement Group Request

## Structure

`UpdatePlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New PlacementGroup name |

## Example

```ts
import { UpdatePlacementGroupRequest } from 'hetzner-cloud-apilib';

const updatePlacementGroupRequest: UpdatePlacementGroupRequest = {
  labels: { 'labelkey': 'value' },
  name: 'my Placement Group',
};
```

