
# X Amz Target 1

## Enumeration

`XAmzTarget1`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget1;

XAmzTarget1 xAmzTarget1 = XAmzTarget1.ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT;
```

