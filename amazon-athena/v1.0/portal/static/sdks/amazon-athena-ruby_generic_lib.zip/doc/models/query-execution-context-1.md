
# Query Execution Context 1

## Structure

`QueryExecutionContext1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `catalog` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ruby
query_execution_context1 = QueryExecutionContext1.new(
  'Database2',
  'Catalog8'
)
```

