
# Column Nullable 2

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```java
import com.amazonaws.useast1.athena.models.ColumnNullable2;

ColumnNullable2 columnNullable2 = ColumnNullable2.NOT_NULL;
```

