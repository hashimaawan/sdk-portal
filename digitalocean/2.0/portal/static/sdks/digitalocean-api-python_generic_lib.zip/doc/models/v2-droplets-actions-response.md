
# V2 Droplets Actions Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DropletsActionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `actions` | [`List[Action]`](../../doc/models/action.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.action import Action
from digitaloceanapi.models.region import Region
from digitaloceanapi.models.v_2_droplets_actions_response import V2DropletsActionsResponse

v_2_droplets_actions_response = V2DropletsActionsResponse(
    actions=[
        Action(
            completed_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            id=154,
            region=Region(
                available=False,
                features=[
                    'features7',
                    'features8',
                    'features9'
                ],
                name='name6',
                sizes=[
                    'sizes6'
                ],
                slug='slug0',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            region_slug='region_slug6',
            resource_id=238,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Action(
            completed_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            id=154,
            region=Region(
                available=False,
                features=[
                    'features7',
                    'features8',
                    'features9'
                ],
                name='name6',
                sizes=[
                    'sizes6'
                ],
                slug='slug0',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            region_slug='region_slug6',
            resource_id=238,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

