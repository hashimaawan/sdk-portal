
# Label Selector

*This model accepts additional fields of type unknown.*

## Structure

`LabelSelector`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { LabelSelector } from 'hetzner-cloud-apilib';

const labelSelector: LabelSelector = {
  selector: 'env=prod',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

