
# List Calculation Executions Request

## Structure

`ListCalculationExecutionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getSessionId(): string | setSessionId(string sessionId): void |
| `stateFilter` | [`?string(CalculationExecutionState3Enum)`](../../doc/models/calculation-execution-state-3-enum.md) | Optional | - | getStateFilter(): ?string | setStateFilter(?string stateFilter): void |
| `maxResults` | `?int` | Optional | **Constraints**: `>= 1`, `<= 100` | getMaxResults(): ?int | setMaxResults(?int maxResults): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Maximum Length*: `2048` | getNextToken(): ?string | setNextToken(?string nextToken): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListCalculationExecutionsRequestBuilder;
use AmazonAthenaLib\Models\CalculationExecutionState3Enum;

$listCalculationExecutionsRequest = ListCalculationExecutionsRequestBuilder::init(
    'SessionId2'
)
    ->stateFilter(CalculationExecutionState3Enum::QUEUED)
    ->maxResults(100)
    ->nextToken('NextToken0')
    ->build();
```

