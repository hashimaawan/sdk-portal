
# V2 Databases Online Migration Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesOnlineMigrationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `createdAt` | `string \| undefined` | Optional | The time the migration was initiated, in ISO 8601 format. |
| `id` | `string \| undefined` | Optional | The ID of the most recent migration. |
| `status` | [`Status5 \| undefined`](../../doc/models/status-5.md) | Optional | The current status of the migration. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Status5,
  V2DatabasesOnlineMigrationResponse,
} from 'digitalocean-apilib';

const v2DatabasesOnlineMigrationResponse: V2DatabasesOnlineMigrationResponse = {
  createdAt: '2020-10-29T15:57:38Z',
  id: '77b28fc8-19ff-11eb-8c9c-c68e24557488',
  status: Status5.Running,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

