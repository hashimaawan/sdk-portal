
# X Amz Target 16 Enum

## Enumeration

`XAmzTarget16Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget16 := models.XAmzTarget16Enum_ENUMAMAZONATHENAGETCALCULATIONEXECUTIONCODE

}
```

