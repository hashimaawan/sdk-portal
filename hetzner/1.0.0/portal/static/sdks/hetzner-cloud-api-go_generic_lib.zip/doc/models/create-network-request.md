
# Create Network Request

*This model accepts additional fields of type interface{}.*

## Structure

`CreateNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IpRange` | `string` | Required | IP range of the whole network which must span all included subnets. Must be one of the private IPv4 ranges of RFC1918. Minimum network size is /24. We highly recommend that you pick a larger network with a /16 netmask. |
| `Labels` | [`*models.Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `Name` | `string` | Required | Name of the network |
| `Routes` | [`[]models.Route`](../../doc/models/route.md) | Optional | Array of routes set in this network. The destination of the route must be one of the private IPv4 ranges of RFC1918. The gateway must be a subnet/IP of the ip_range of the network object. The destination must not overlap with an existing ip_range in any subnets or with any destinations in other routes or with the first IP of the networks ip_range or with 172.31.1.1. The gateway cannot be the first IP of the networks ip_range and also cannot be 172.31.1.1. |
| `Subnets` | [`[]models.Subnet1`](../../doc/models/subnet-1.md) | Optional | Array of subnets allocated. |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    createNetworkRequest := models.CreateNetworkRequest{
        IpRange:               "10.0.0.0/16",
        Labels:                models.ToPointer(models.Labels{
            Labelkey:              models.ToPointer("labelkey4"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        Name:                  "mynet",
        Routes:                []models.Route{
            models.Route{
                Destination:           "destination8",
                Gateway:               "gateway6",
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        Subnets:               []models.Subnet1{
            models.Subnet1{
                IpRange:               models.ToPointer("ip_range6"),
                NetworkZone:           "network_zone2",
                Type:                  models.Type42_Cloud,
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            models.Subnet1{
                IpRange:               models.ToPointer("ip_range6"),
                NetworkZone:           "network_zone2",
                Type:                  models.Type42_Cloud,
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            models.Subnet1{
                IpRange:               models.ToPointer("ip_range6"),
                NetworkZone:           "network_zone2",
                Type:                  models.Type42_Cloud,
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

