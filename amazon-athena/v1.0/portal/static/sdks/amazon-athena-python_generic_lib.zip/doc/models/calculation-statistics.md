
# Calculation Statistics

Contains statistics for a notebook calculation.

## Structure

`CalculationStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `int` | Optional | - |
| `progress` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```python
from amazonathena.models.calculation_statistics import CalculationStatistics

calculation_statistics = CalculationStatistics(
    dpu_execution_in_millis=242,
    progress='Progress6'
)
```

