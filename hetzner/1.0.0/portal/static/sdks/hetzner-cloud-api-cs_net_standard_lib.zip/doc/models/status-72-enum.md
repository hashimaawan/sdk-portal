
# Status 72 Enum

Status of the Firewall on the Server

## Enumeration

`Status72Enum`

## Fields

| Name |
|  --- |
| `Applied` |
| `Pending` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Status72Enum status72 = Status72Enum.Applied;
```

