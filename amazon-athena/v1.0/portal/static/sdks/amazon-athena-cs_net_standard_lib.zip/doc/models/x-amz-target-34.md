
# X Amz Target 34

## Enumeration

`XAmzTarget34`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListDatabases` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget34 xAmzTarget34 = XAmzTarget34.EnumAmazonAthenaListDatabases;
```

