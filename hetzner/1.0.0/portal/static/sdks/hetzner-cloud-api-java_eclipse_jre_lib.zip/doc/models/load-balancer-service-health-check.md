
# Load Balancer Service Health Check

Service health check

## Structure

`LoadBalancerServiceHealthCheck`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Http` | [`Http`](../../doc/models/http.md) | Optional | Additional configuration for protocol http | Http getHttp() | setHttp(Http http) |
| `Interval` | `int` | Required | Time interval in seconds health checks are performed | int getInterval() | setInterval(int interval) |
| `Port` | `int` | Required | Port the health check will be performed on | int getPort() | setPort(int port) |
| `Protocol` | [`Protocol6`](../../doc/models/protocol-6.md) | Required | Type of the health check | Protocol6 getProtocol() | setProtocol(Protocol6 protocol) |
| `Retries` | `int` | Required | Unsuccessful retries needed until a target is considered unhealthy; an unhealthy target needs the same number of successful retries to become healthy again | int getRetries() | setRetries(int retries) |
| `Timeout` | `int` | Required | Time in seconds after an attempt is considered a timeout | int getTimeout() | setTimeout(int timeout) |

## Example

```java
import cloud.hetzner.api.models.Http;
import cloud.hetzner.api.models.LoadBalancerServiceHealthCheck;
import cloud.hetzner.api.models.Protocol6;
import java.util.Arrays;

LoadBalancerServiceHealthCheck loadBalancerServiceHealthCheck = new LoadBalancerServiceHealthCheck.Builder(
    15,
    4711,
    Protocol6.HTTP,
    3,
    10
)
.http(new Http.Builder(
        "domain4",
        "path2"
    )
    .response("response8")
    .statusCodes(Arrays.asList(
            "status_codes0",
            "status_codes1",
            "status_codes2"
        ))
    .tls(false)
    .build())
.build();
```

