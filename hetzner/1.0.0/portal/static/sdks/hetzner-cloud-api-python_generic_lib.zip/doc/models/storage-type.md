
# Storage Type

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageType`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `NETWORK` |

## Example

```python
from hetznercloudapi.models.storage_type import StorageType

storage_type = StorageType.LOCAL
```

