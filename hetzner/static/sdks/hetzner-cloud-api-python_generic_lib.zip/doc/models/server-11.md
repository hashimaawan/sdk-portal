
# Server 11

## Structure

`Server11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Server |

## Example

```python
from hetznercloudapi.models.server_11 import Server11

server_11 = Server11(
    id=85
)
```

