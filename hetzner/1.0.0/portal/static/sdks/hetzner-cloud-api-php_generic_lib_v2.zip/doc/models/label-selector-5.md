
# Label Selector 5

Configuration for type label_selector, required if type is `label_selector`

## Structure

`LabelSelector5`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector | getSelector(): string | setSelector(string selector): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LabelSelector5Builder;

$labelSelector5 = LabelSelector5Builder::init(
    'env=prod'
)->build();
```

