
# Narrator Object

*This model accepts additional fields of type Object.*

## Structure

`NarratorObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | The name of the Narrator. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
narrator_object = NarratorObject.new(
  name: 'name4',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

