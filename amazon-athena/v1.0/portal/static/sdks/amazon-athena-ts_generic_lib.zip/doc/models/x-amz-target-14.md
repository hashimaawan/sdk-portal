
# X Amz Target 14

## Enumeration

`XAmzTarget14`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaExportNotebook` |

## Example

```ts
import { XAmzTarget14 } from 'amazon-athenalib';

const xAmzTarget14 = XAmzTarget14.EnumAmazonAthenaExportNotebook;
```

