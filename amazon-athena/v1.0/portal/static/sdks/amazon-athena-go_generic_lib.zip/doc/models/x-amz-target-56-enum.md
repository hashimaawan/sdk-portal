
# X Amz Target 56 Enum

## Enumeration

`XAmzTarget56Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAUPDATENOTEBOOK` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget56 := models.XAmzTarget56Enum_ENUMAMAZONATHENAUPDATENOTEBOOK

}
```

