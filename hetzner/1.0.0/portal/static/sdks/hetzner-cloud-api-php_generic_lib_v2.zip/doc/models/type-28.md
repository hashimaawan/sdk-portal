
# Type 28

Type of the algorithm

## Enumeration

`Type28`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```php
use HetznerCloudApiLib\Models\Type28;

$type28 = Type28::ROUND_ROBIN;
```

