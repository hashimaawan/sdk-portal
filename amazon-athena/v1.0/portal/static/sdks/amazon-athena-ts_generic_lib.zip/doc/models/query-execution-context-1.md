
# Query Execution Context 1

## Structure

`QueryExecutionContext1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `catalog` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ts
import { QueryExecutionContext1 } from 'amazon-athenalib';

const queryExecutionContext1: QueryExecutionContext1 = {
  database: 'Database0',
  catalog: 'Catalog6',
};
```

