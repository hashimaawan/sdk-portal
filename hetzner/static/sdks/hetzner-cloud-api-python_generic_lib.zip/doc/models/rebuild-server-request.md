
# Rebuild Server Request

## Structure

`RebuildServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image` | `str` | Required | ID or name of Image to rebuilt from. |

## Example

```python
from hetznercloudapi.models.rebuild_server_request import RebuildServerRequest

rebuild_server_request = RebuildServerRequest(
    image='ubuntu-20.04'
)
```

