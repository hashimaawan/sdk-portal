
# Executors Summary

Contains summary information about an executor.

## Structure

`ExecutorsSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `executor_id` | `String` | Required | **Constraints**: *Maximum Length*: `100000`, *Pattern*: `.*` |
| `executor_type` | [`ExecutorType2Enum`](../../doc/models/executor-type-2-enum.md) | Optional | - |
| `start_date_time` | `Integer` | Optional | - |
| `termination_date_time` | `Integer` | Optional | - |
| `executor_state` | [`ExecutorState3Enum`](../../doc/models/executor-state-3-enum.md) | Optional | - |
| `executor_size` | `Integer` | Optional | - |

## Example

```ruby
executors_summary = ExecutorsSummary.new(
  'ExecutorId2',
  ExecutorType2Enum::GATEWAY,
  204,
  160,
  ExecutorState3Enum::CREATING,
  118
)
```

