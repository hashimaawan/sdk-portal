
# X Amz Target 29 Enum

## Enumeration

`XAmzTarget29Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETWORKGROUP` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget29Enum;

$xAmzTarget29 = XAmzTarget29Enum::ENUM_AMAZONATHENAGETWORKGROUP;
```

