
# Mode Enum

travel mode

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```python
from furkottrips.models.mode_enum import ModeEnum

mode = ModeEnum.BICYCLE
```

