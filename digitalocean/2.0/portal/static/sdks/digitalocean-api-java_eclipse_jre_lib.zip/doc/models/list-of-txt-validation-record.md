
# List of Txt Validation Record

*This model accepts additional fields of type Object.*

## Structure

`ListOfTxtValidationRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TxtName` | `String` | Optional, Read-only | - | String getTxtName() | setTxtName(String txtName) |
| `TxtValue` | `String` | Optional, Read-only | - | String getTxtValue() | setTxtValue(String txtValue) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.ListOfTxtValidationRecord;
import java.io.IOException;

ListOfTxtValidationRecord listOfTxtValidationRecord = new ListOfTxtValidationRecord.Builder()
    .txtName("_acme-challenge.app.example.com")
    .txtValue("lXLOcN6cPv0nproViNcUHcahD9TrIPlNgdwesj0pYpk")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

