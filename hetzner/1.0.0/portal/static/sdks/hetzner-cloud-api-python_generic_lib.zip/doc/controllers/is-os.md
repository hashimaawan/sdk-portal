# IS Os

ISOs are read-only Images of DVDs. While we recommend using our Image functionality to install your Servers we also provide some stock ISOs so you can install more exotic operating systems by yourself.

On request our support uploads a private ISO just for you. These are marked with type `private` and only visible in your Project.

To attach an ISO to your Server use `POST /servers/{id}/actions/attach_iso`.

```python
is_os_api = client.is_os
```

## Class Name

`IsOsApi`

## Methods

* [Get All IS Os](../../doc/controllers/is-os.md#get-all-is-os)
* [Get an ISO](../../doc/controllers/is-os.md#get-an-iso)


# Get All IS Os

Returns all available ISO objects.

```python
def get_all_is_os(self,
                 name=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Query, Optional | Can be used to filter ISOs by their name. The response will only contain the ISO matching the specified name. |

## Response Type

**200**: The `isos` key in the reply contains an array of iso objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`IsosResponse`](../../doc/models/isos-response.md).

## Example Usage

```python
result = is_os_api.get_all_is_os()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Get an ISO

Returns a specific ISO object.

```python
def get_an_iso(self,
              id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the ISO |

## Response Type

**200**: The `iso` key in the reply contains an array of ISO objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`IsosResponse1`](../../doc/models/isos-response-1.md).

## Example Usage

```python
id = 112

result = is_os_api.get_an_iso(id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

