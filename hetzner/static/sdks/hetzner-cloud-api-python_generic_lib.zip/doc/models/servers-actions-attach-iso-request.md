
# Servers Actions Attach Iso Request

## Structure

`ServersActionsAttachIsoRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iso` | `str` | Required | ID or name of ISO to attach to the Server as listed in GET `/isos` |

## Example

```python
from hetznercloudapi.models.servers_actions_attach_iso_request import ServersActionsAttachIsoRequest

servers_actions_attach_iso_request = ServersActionsAttachIsoRequest(
    iso='FreeBSD-11.0-RELEASE-amd64-dvd1'
)
```

