# Server Types

```csharp
ServerTypesApi serverTypesApi = client.ServerTypesApi;
```

## Class Name

`ServerTypesApi`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```csharp
GetAllServerTypesAsync(
    string name = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ServerTypesResponse](../../doc/models/server-types-response.md).

## Example Usage

```csharp
try
{
    ApiResponse<ServerTypesResponse> result = await serverTypesApi.GetAllServerTypesAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Server Type

Gets a specific Server type object.

```csharp
GetAServerTypeAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Server Type |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.ServerTypesResponse1](../../doc/models/server-types-response-1.md).

## Example Usage

```csharp
int id = 112;
try
{
    ApiResponse<ServerTypesResponse1> result = await serverTypesApi.GetAServerTypeAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

