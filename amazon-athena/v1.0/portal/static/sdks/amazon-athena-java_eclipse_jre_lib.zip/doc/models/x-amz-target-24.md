
# X Amz Target 24

## Enumeration

`XAmzTarget24`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRESULTS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget24;

XAmzTarget24 xAmzTarget24 = XAmzTarget24.ENUM_AMAZONATHENAGETQUERYRESULTS;
```

