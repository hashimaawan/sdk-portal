
# Health Status

*This model accepts additional fields of type Object.*

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listen_port` | `Integer` | Optional | - |
| `status` | [`Status30`](../../doc/models/status-30.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
health_status = HealthStatus.new(
  listen_port: 443,
  status: Status30::HEALTHY,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

