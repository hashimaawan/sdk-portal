
# Terminate Session Response

*This model accepts additional fields of type interface{}.*

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `State` | [`*models.SessionState1`](../../doc/models/session-state-1.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    terminateSessionResponse := models.TerminateSessionResponse{
        State:                 models.ToPointer(models.SessionState1_Creating),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

