
# X Amz Target 41

## Enumeration

`XAmzTarget41`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTQUERYEXECUTIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget41;

$xAmzTarget41 = XAmzTarget41::ENUM_AMAZONATHENALISTQUERYEXECUTIONS;
```

