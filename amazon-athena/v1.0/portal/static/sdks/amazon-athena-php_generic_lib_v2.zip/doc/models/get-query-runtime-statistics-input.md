
# Get Query Runtime Statistics Input

## Structure

`GetQueryRuntimeStatisticsInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `queryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getQueryExecutionId(): string | setQueryExecutionId(string queryExecutionId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetQueryRuntimeStatisticsInputBuilder;

$getQueryRuntimeStatisticsInput = GetQueryRuntimeStatisticsInputBuilder::init(
    'QueryExecutionId0'
)->build();
```

