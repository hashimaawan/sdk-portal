
# List Notebook Sessions Request

## Structure

`ListNotebookSessionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `max_results` | `int` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```python
from amazonathena.models.list_notebook_sessions_request import ListNotebookSessionsRequest

list_notebook_sessions_request = ListNotebookSessionsRequest(
    notebook_id='NotebookId6',
    max_results=100,
    next_token='NextToken6'
)
```

