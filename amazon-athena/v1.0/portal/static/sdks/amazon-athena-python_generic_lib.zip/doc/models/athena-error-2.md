
# Athena Error 2

## Structure

`AthenaError2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_category` | `int` | Optional | **Constraints**: `>= 1`, `<= 3` |
| `error_type` | `int` | Optional | **Constraints**: `>= 0`, `<= 9999` |
| `retryable` | `bool` | Optional | - |
| `error_message` | `str` | Optional | - |

## Example

```python
from amazonathena.models.athena_error_2 import AthenaError2

athena_error_2 = AthenaError2(
    error_category=3,
    error_type=180,
    retryable=False,
    error_message='ErrorMessage8'
)
```

