
# Start Calculation Execution Request

## Structure

`StartCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `calculation_configuration` | [`GetCalculationExecutionCodeResponse`](../../doc/models/get-calculation-execution-code-response.md) | Optional | - |
| `code_block` | `String` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `client_request_token` | `String` | Optional | **Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128` |

## Example

```ruby
start_calculation_execution_request = StartCalculationExecutionRequest.new(
  'SessionId8',
  'Description6',
  GetCalculationExecutionCodeResponse.new(
    'CodeBlock4'
  ),
  'CodeBlock2',
  'ClientRequestToken4'
)
```

