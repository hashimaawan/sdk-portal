
# Firewall Apply to Resources

## Structure

`FirewallApplyToResources`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `LabelSelector` | [`LabelSelector5`](../../doc/models/label-selector-5.md) | Optional | Configuration for type label_selector, required if type is `label_selector` | LabelSelector5 getLabelSelector() | setLabelSelector(LabelSelector5 labelSelector) |
| `Server` | [`Server9`](../../doc/models/server-9.md) | Optional | Configuration for type server, required if type is `server` | Server9 getServer() | setServer(Server9 server) |
| `Type` | [`Type7Enum`](../../doc/models/type-7-enum.md) | Optional | Type of the resource | Type7Enum getType() | setType(Type7Enum type) |

## Example

```java
import cloud.hetzner.api.models.FirewallApplyToResources;
import cloud.hetzner.api.models.LabelSelector5;
import cloud.hetzner.api.models.Server9;
import cloud.hetzner.api.models.Type7Enum;

FirewallApplyToResources firewallApplyToResources = new FirewallApplyToResources.Builder()
    .labelSelector(new LabelSelector5.Builder(
        "selector8"
    )
    .build())
    .server(new Server9.Builder(
        14
    )
    .build())
    .type(Type7Enum.SERVER)
    .build();
```

