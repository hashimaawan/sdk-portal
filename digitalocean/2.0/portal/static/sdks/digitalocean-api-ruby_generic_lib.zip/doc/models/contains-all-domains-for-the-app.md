
# Contains All Domains for the App

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`ContainsAllDomainsForTheApp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `certificate_expires_at` | `DateTime` | Optional, Read-only | - |
| `id` | `String` | Optional | - |
| `phase` | [`Phase1`](../../doc/models/phase-1.md) | Optional | **Default**: `Phase1::UNKNOWN` |
| `progress` | [`Progress1`](../../doc/models/progress-1.md) | Optional | - |
| `rotate_validation_records` | `TrueClass \| FalseClass` | Optional, Read-only | - |
| `spec` | [`Domain`](../../doc/models/domain.md) | Optional | - |
| `validations` | [`Array[ListOfTxtValidationRecord]`](../../doc/models/list-of-txt-validation-record.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
contains_all_domains_for_the_app = ContainsAllDomainsForTheApp.new(
  certificate_expires_at: DateTimeHelper.from_rfc3339('2024-01-29T23:59:59Z'),
  id: '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf',
  phase: Phase1::ACTIVE,
  progress: Progress1.new(
    steps: [
      { 'key1' => 'val1', 'key2' => 'val2' },
      { 'key1' => 'val1', 'key2' => 'val2' },
      { 'key1' => 'val1', 'key2' => 'val2' }
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  rotate_validation_records: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

