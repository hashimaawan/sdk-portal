
# Type 21

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```python
from hetznercloudapi.models.type_21 import Type21

type_21 = Type21.BACKUP
```

