
# Mode

travel mode

## Enumeration

`Mode`

## Fields

| Name |
|  --- |
| `Car` |
| `Motorcycle` |
| `Bicycle` |
| `Walk` |
| `Other` |

## Example

```csharp
using FurkotTrips.Standard.Models;

Mode mode = Mode.Bicycle;
```

