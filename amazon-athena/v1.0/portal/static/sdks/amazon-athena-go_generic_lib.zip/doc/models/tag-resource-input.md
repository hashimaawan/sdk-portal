
# Tag Resource Input

## Structure

`TagResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResourceARN` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `Tags` | [`[]models.Tag`](../../doc/models/tag.md) | Required | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    tagResourceInput := models.TagResourceInput{
        ResourceARN:          "ResourceARN6",
        Tags:                 []models.Tag{
            models.Tag{
                Key:                  models.ToPointer("Key0"),
                Value:                models.ToPointer("Value6"),
            },
        },
    }

}
```

