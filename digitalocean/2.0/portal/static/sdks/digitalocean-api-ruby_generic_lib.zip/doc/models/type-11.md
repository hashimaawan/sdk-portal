
# Type 11

The type of the IPv6 network interface.

**Note**: IPv6 private  networking is not currently supported.

## Enumeration

`Type11`

## Fields

| Name |
|  --- |
| `PUBLIC` |

## Example

```ruby
type11 = Type11::PUBLIC
```

