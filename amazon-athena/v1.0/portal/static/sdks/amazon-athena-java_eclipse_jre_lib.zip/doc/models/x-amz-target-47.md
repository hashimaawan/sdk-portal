
# X Amz Target 47

## Enumeration

`XAmzTarget47`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTQUERYEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget47;

XAmzTarget47 xAmzTarget47 = XAmzTarget47.ENUM_AMAZONATHENASTARTQUERYEXECUTION;
```

