
# Update Firewall Request

## Structure

`UpdateFirewallRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New Firewall name |

## Example

```ruby
update_firewall_request = UpdateFirewallRequest.new(
  { 'labelkey' => 'value' },
  'new-name'
)
```

