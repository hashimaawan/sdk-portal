
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| connection | `Faraday::Connection` | The Faraday connection object passed by the SDK user for making requests |
| adapter | `Faraday::Adapter` | The Faraday adapter object passed by the SDK user for performing http requests |
| timeout | `Float` | The value to use for connection timeout. <br> **Default: 30** |
| max_retries | `Integer` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| retry_interval | `Float` | Pause in seconds between retries. <br> **Default: 1** |
| backoff_factor | `Float` | The amount to multiply each successive retry's interval amount by in order to provide backoff. <br> **Default: 2** |
| retry_statuses | `Array` | A list of HTTP statuses to retry. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array` | A list of HTTP methods to retry. <br> **Default: %i[get put get put]** |
| http_callback | `HttpCallBack` | The Http CallBack allows defining callables for pre and post API calls. |
| proxy_settings | [`ProxySettings`](../doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| logging_configuration | [`LoggingConfiguration`](../doc/logging-configuration.md) | The SDK logging configuration for API calls |

The API client can be initialized as follows:

## Code-Based Client Initialization

```ruby
require 'hetzner_cloud_api'
include HetznerCloudApi

client = Client.new(
  logging_configuration: LoggingConfiguration.new(
    log_level: Logger::INFO,
    request_logging_config: RequestLoggingConfiguration.new(
      log_body: true
    ),
    response_logging_config: ResponseLoggingConfiguration.new(
      log_headers: true
    )
  )
)
```

## Environment-Based Client Initialization

```ruby
require 'hetzner_cloud_api'
include HetznerCloudApi

# Create client from environment
client = Client.from_env
```

See the [`Environment-Based Client Initialization`](../doc/environment-based-client-initialization.md) section for details.

## Hetzner Cloud API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| actions | Gets ActionsApi |
| certificates | Gets CertificatesApi |
| certificate_actions | Gets CertificateActionsApi |
| datacenters | Gets DatacentersApi |
| firewalls | Gets FirewallsApi |
| firewall_actions | Gets FirewallActionsApi |
| floating_i_ps | Gets FloatingIPsApi |
| floating_ip_actions | Gets FloatingIpActionsApi |
| images | Gets ImagesApi |
| image_actions | Gets ImageActionsApi |
| is_os | Gets IsOsApi |
| load_balancers | Gets LoadBalancersApi |
| load_balancer_actions | Gets LoadBalancerActionsApi |
| load_balancer_types | Gets LoadBalancerTypesApi |
| locations | Gets LocationsApi |
| primary_i_ps | Gets PrimaryIPsApi |
| primary_ip_actions | Gets PrimaryIpActionsApi |
| networks | Gets NetworksApi |
| network_actions | Gets NetworkActionsApi |
| placement_groups | Gets PlacementGroupsApi |
| pricing | Gets PricingApi |
| servers | Gets ServersApi |
| server_actions | Gets ServerActionsApi |
| server_types | Gets ServerTypesApi |
| ssh_keys | Gets SshKeysApi |
| volumes | Gets VolumesApi |
| volume_actions | Gets VolumeActionsApi |

