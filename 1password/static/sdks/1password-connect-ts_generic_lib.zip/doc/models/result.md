
# Result

## Enumeration

`Result`

## Fields

| Name |
|  --- |
| `Success` |
| `Deny` |

## Example

```ts
import { Result } from 'm-1-password-connectlib';

const result = Result.Success;
```

