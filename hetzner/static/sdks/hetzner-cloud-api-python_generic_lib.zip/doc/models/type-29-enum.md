
# Type 29 Enum

Type of the resource

## Enumeration

`Type29Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |
| `IP` |

## Example

```python
from hetznercloudapi.models.type_29_enum import Type29Enum

type_29 = Type29Enum.IP
```

