
# Type 26 Enum

Type of the ISO

## Enumeration

`Type26Enum`

## Fields

| Name |
|  --- |
| `Public` |
| `Private` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type26Enum type26 = Type26Enum.Public;
```

