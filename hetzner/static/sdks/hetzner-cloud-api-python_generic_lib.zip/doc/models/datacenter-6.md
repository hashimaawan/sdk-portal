
# Datacenter 6

Datacenter this Resource is located at

## Structure

`Datacenter6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Required | Description of the Datacenter |
| `id` | `int` | Required | ID of the Resource |
| `location` | [`Location`](../../doc/models/location.md) | Required | - |
| `name` | `str` | Required | Unique identifier of the Datacenter |
| `server_types` | [`ServerTypes`](../../doc/models/server-types.md) | Required | The Server types the Datacenter can handle |

## Example

```python
from hetznercloudapi.models.datacenter_6 import Datacenter6
from hetznercloudapi.models.location import Location
from hetznercloudapi.models.server_types import ServerTypes

datacenter_6 = Datacenter6(
    description='Falkenstein DC Park 8',
    id=42,
    location=Location(
        city='Falkenstein',
        country='DE',
        description='Falkenstein DC Park 1',
        id=1,
        latitude=50.47612,
        longitude=12.370071,
        name='fsn1',
        network_zone='eu-central'
    ),
    name='fsn1-dc8',
    server_types=ServerTypes(
        available=[
            1,
            2,
            3
        ],
        available_for_migration=[
            1,
            2,
            3
        ],
        supported=[
            1,
            2,
            3
        ]
    )
)
```

