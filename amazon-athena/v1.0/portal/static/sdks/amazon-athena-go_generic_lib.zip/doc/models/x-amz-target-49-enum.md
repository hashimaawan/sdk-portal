
# X Amz Target 49 Enum

## Enumeration

`XAmzTarget49Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget49 := models.XAmzTarget49Enum_ENUMAMAZONATHENASTOPCALCULATIONEXECUTION

}
```

