
# Type

Type of the gif. By default, this is almost always gif

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Gif` |

## Example

```csharp
using GiphyApi.Standard.Models;

GiphyApi.Standard.Models.Type type = GiphyApi.Standard.Models.Type.Gif;
```

