
# Create Presigned Notebook Url Response

## Structure

`CreatePresignedNotebookUrlResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_url` | `String` | Required | - |
| `auth_token` | `String` | Required | **Constraints**: *Maximum Length*: `2048` |
| `auth_token_expiration_time` | `Integer` | Required | - |

## Example

```ruby
create_presigned_notebook_url_response = CreatePresignedNotebookUrlResponse.new(
  'NotebookUrl8',
  'AuthToken2',
  54
)
```

