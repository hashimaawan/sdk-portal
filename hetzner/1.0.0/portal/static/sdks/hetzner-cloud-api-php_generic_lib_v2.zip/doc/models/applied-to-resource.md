
# Applied to Resource

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `server` | [`?Server`](../../doc/models/server.md) | Optional | - | getServer(): ?Server | setServer(?Server server): void |
| `type` | [`?string(Type5Enum)`](../../doc/models/type-5-enum.md) | Optional | Type of resource referenced | getType(): ?string | setType(?string type): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\AppliedToResourceBuilder;
use HetznerCloudAPILib\Models\Builders\ServerBuilder;
use HetznerCloudAPILib\Models\Type5Enum;

$appliedToResource = AppliedToResourceBuilder::init()
    ->server(
        ServerBuilder::init(
            14
        )->build()
    )
    ->type(Type5Enum::SERVER)
    ->build();
```

