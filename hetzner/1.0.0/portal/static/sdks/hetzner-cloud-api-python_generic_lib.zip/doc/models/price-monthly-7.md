
# Price Monthly 7

Monthly costs for a Floating IP type in this Location

*This model accepts additional fields of type Any.*

## Structure

`PriceMonthly7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `str` | Required | Price with VAT added |
| `net` | `str` | Required | Price without VAT |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.price_monthly_7 import PriceMonthly7

price_monthly_7 = PriceMonthly7(
    gross='1.1900000000000000',
    net='1.0000000000',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

