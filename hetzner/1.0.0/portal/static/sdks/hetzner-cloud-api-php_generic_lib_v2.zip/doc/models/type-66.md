
# Type 66

## Enumeration

`Type66`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```php
use HetznerCloudApiLib\Models\Type66;

$type66 = Type66::NETWORK;
```

