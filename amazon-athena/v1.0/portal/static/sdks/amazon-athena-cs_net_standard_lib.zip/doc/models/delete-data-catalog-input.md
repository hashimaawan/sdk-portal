
# Delete Data Catalog Input

## Structure

`DeleteDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```csharp
using AmazonAthena.Standard.Models;

DeleteDataCatalogInput deleteDataCatalogInput = new DeleteDataCatalogInput
{
    Name = "Name2",
};
```

