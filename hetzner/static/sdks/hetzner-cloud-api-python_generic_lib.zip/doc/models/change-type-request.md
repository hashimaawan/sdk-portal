
# Change Type Request

## Structure

`ChangeTypeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `load_balancer_type` | `str` | Required | ID or name of Load Balancer type the Load Balancer should migrate to |

## Example

```python
from hetznercloudapi.models.change_type_request import ChangeTypeRequest

change_type_request = ChangeTypeRequest(
    load_balancer_type='lb21'
)
```

