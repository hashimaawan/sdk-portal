
# X Amz Target 5

## Enumeration

`XAmzTarget5`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_5 import XAmzTarget5

x_amz_target_5 = XAmzTarget5.ENUM_AMAZONATHENACREATENOTEBOOK
```

