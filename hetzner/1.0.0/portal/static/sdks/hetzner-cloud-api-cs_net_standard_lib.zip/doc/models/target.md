
# Target

## Structure

`Target`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `HealthStatus` | [`List<HealthStatus>`](../../doc/models/health-status.md) | Optional | - |
| `Server` | [`Server11`](../../doc/models/server-11.md) | Optional | - |
| `Type` | `string` | Optional | - |
| `UsePrivateIp` | `bool?` | Optional | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

Target target = new Target
{
    HealthStatus = new List<HealthStatus>
    {
        new HealthStatus
        {
            ListenPort = 142,
            Status = Status30Enum.Unknown,
        },
        new HealthStatus
        {
            ListenPort = 142,
            Status = Status30Enum.Unknown,
        },
        new HealthStatus
        {
            ListenPort = 142,
            Status = Status30Enum.Unknown,
        },
    },
    Server = new Server11
    {
        Id = 14,
    },
    Type = "server",
    UsePrivateIp = false,
};
```

