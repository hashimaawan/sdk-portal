
# X Amz Target 26

## Enumeration

`XAmzTarget26`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetSession` |

## Example

```ts
import { XAmzTarget26 } from 'amazon-athenalib';

const xAmzTarget26 = XAmzTarget26.EnumAmazonAthenaGetSession;
```

