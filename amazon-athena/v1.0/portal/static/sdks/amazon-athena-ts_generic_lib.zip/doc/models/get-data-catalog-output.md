
# Get Data Catalog Output

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dataCatalog` | [`DataCatalog2 \| undefined`](../../doc/models/data-catalog-2.md) | Optional | - |

## Example

```ts
import { DataCatalogType1Enum, GetDataCatalogOutput } from 'amazon-athenalib';

const getDataCatalogOutput: GetDataCatalogOutput = {
  dataCatalog: {
    name: 'Name4',
    type: DataCatalogType1Enum.GLUE,
    description: 'Description2',
    parameters: {},
  },
};
```

