
# V2 Kubernetes Clusters Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auto_upgrade` | `TrueClass \| FalseClass` | Optional | A boolean value indicating whether the cluster will be automatically upgraded to new patch releases during its maintenance window.<br><br>**Default**: `false` |
| `ha` | `TrueClass \| FalseClass` | Optional | A boolean value indicating whether the control plane is run in a highly available configuration in the cluster. Highly available control planes incur less downtime. The property cannot be disabled.<br><br>**Default**: `false` |
| `maintenance_policy` | [`MaintenancePolicy`](../../doc/models/maintenance-policy.md) | Optional | An object specifying the maintenance window policy for the Kubernetes cluster. |
| `name` | `String` | Required | A human-readable name for a Kubernetes cluster. |
| `surge_upgrade` | `TrueClass \| FalseClass` | Optional | A boolean value indicating whether surge upgrade is enabled/disabled for the cluster. Surge upgrade makes cluster upgrades fast and reliable by bringing up new nodes before destroying the outdated nodes.<br><br>**Default**: `false` |
| `tags` | `Array[String]` | Optional | An array of tags applied to the Kubernetes cluster. All clusters are automatically tagged `k8s` and `k8s:$K8S_CLUSTER_ID`. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_kubernetes_clusters_request = V2KubernetesClustersRequest.new(
  name: 'prod-cluster-01',
  auto_upgrade: true,
  ha: true,
  maintenance_policy: MaintenancePolicy.new(
    day: Day::ANY,
    duration: 'duration4',
    start_time: 'start_time2',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  surge_upgrade: true,
  tags: [
    'k8s',
    'k8s:bd5f5959-5e1e-4205-a714-a914373942af',
    'production',
    'web-team'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

