
# Get Session Status Request

## Structure

`GetSessionStatusRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getSessionId(): string | setSessionId(string sessionId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetSessionStatusRequestBuilder;

$getSessionStatusRequest = GetSessionStatusRequestBuilder::init(
    'SessionId6'
)->build();
```

