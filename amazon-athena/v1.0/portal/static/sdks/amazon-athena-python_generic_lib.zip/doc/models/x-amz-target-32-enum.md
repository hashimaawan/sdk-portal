
# X Amz Target 32 Enum

## Enumeration

`XAmzTarget32Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```python
from amazonathena.models.x_amz_target_32_enum import XAmzTarget32Enum

x_amz_target_32 = XAmzTarget32Enum.ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS
```

