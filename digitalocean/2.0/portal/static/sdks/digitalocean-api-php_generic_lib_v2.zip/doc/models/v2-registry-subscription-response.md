
# V2 Registry Subscription Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2RegistrySubscriptionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `subscription` | [`?Subscription`](../../doc/models/subscription.md) | Optional | - | getSubscription(): ?Subscription | setSubscription(?Subscription subscription): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2RegistrySubscriptionResponseBuilder;
use DigitalOceanApiLib\Models\Builders\SubscriptionBuilder;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\Models\Builders\Tier1Builder;
use DigitalOceanApiLib\ApiHelper;

$v2RegistrySubscriptionResponse = V2RegistrySubscriptionResponseBuilder::init()
    ->subscription(
        SubscriptionBuilder::init()
            ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->tier(
                Tier1Builder::init()
                    ->allowStorageOverage(false)
                    ->includedBandwidthBytes(46)
                    ->includedRepositories(68)
                    ->includedStorageBytes(112)
                    ->monthlyPriceInCents(110)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->updatedAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

