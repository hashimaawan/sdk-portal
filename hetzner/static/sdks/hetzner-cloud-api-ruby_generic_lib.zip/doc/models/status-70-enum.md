
# Status 70 Enum

## Enumeration

`Status70Enum`

## Fields

| Name |
|  --- |
| `INITIALIZING` |
| `STARTING` |
| `RUNNING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `REBUILDING` |
| `MIGRATING` |
| `UNKNOWN` |

## Example

```ruby
status70 = Status70Enum::MIGRATING
```

