# Servers

Servers are virtual machines that can be provisioned.

```java
ServersController serversController = client.getServersController();
```

## Class Name

`ServersController`

## Methods

* [Get All Servers](../../doc/controllers/servers.md#get-all-servers)
* [Create a Server](../../doc/controllers/servers.md#create-a-server)
* [Delete a Server](../../doc/controllers/servers.md#delete-a-server)
* [Get a Server](../../doc/controllers/servers.md#get-a-server)
* [Update a Server](../../doc/controllers/servers.md#update-a-server)
* [Get Metrics for a Server](../../doc/controllers/servers.md#get-metrics-for-a-server)


# Get All Servers

Returns all existing Server objects

```java
CompletableFuture<ServersResponse> getAllServersAsync(
    final String name,
    final String labelSelector,
    final SortEnum sort,
    final Status70Enum status)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `String` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `sort` | [`SortEnum`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`Status70Enum`](../../doc/models/status-70-enum.md) | Query, Optional | Can be used multiple times. The response will only contain Server matching the status |

## Response Type

**200**: A paged array of servers

[`ServersResponse`](../../doc/models/servers-response.md)

## Example Usage

```java
serversController.getAllServersAsync(null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Create a Server

Creates a new Server. Returns preliminary information about the Server as well as an Action that covers progress of creation.

```java
CompletableFuture<CreateServerResponse> createAServerAsync(
    final CreateServerRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateServerRequest`](../../doc/models/create-server-request.md) | Body, Optional | Please note that Server names must be unique per Project and valid hostnames as per RFC 1123 (i.e. may only contain letters, digits, periods, and dashes).<br><br>For `server_type` you can either use the ID as listed in `/server_types` or its name.<br><br>For `image` you can either use the ID as listed in `/images` or its name.<br><br>If you want to create the Server in a Location, you must set `location` to the ID or name as listed in `/locations`. This is the recommended way. You can be even more specific by setting `datacenter` to the ID or name as listed in `/datacenters`. However we only recommend this if you want to assign a specific Primary IP to the Server which is located in the specified Datacenter.<br><br>Some properties like `start_after_create` or `automount` will trigger Actions after the Server is created. Those Actions are listed in the `next_actions` field in the response.<br><br>For accessing your Server we strongly recommend to use SSH keys by passing the respective key IDs in `ssh_keys`. If you do not specify any `ssh_keys` we will generate a root password for you and return it in the response.<br><br>Please note that provided user-data is stored in our systems. While we take measures to protect it we highly recommend that you don’t use it to store passwords or other sensitive information.<br><br>#### Call specific error codes<br><br>\| Code                             \| Description                                                \|<br>\|----------------------------------\|------------------------------------------------------------\|<br>\| `placement_error`                \| An error during the placement occurred                     \|<br>\| `primary_ip_assigned`            \| The specified Primary IP is already assigned to a server   \|<br>\| `primary_ip_datacenter_mismatch` \| The specified Primary IP is in a different datacenter      \|<br>\| `primary_ip_version_mismatch`    \| The specified Primary IP has the wrong IP Version          \| |

## Response Type

**201**: The `server` key in the reply contains a Server object with this structure

[`CreateServerResponse`](../../doc/models/create-server-response.md)

## Example Usage

```java
CreateServerRequest body = new CreateServerRequest.Builder(
    "ubuntu-20.04",
    "my-server",
    "cx11"
)
.automount(false)
.datacenter("nbg1-dc3")
.firewalls(Arrays.asList(
        new Firewall4.Builder()
            .firewall(38)
            .build()
    ))
.location("nbg1")
.networks(Arrays.asList(
        456
    ))
.placementGroup(1)
.sshKeys(Arrays.asList(
        "my-ssh-key"
    ))
.startAfterCreate(true)
.userData("#cloud-config\nruncmd:\n- [touch, /root/cloud-init-worked]\n")
.volumes(Arrays.asList(
        123
    ))
.build();

serversController.createAServerAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_server",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 1,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  },
  "next_actions": [
    {
      "command": "start_server",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": null,
      "id": 13,
      "progress": 0,
      "resources": [
        {
          "id": 42,
          "type": "server"
        }
      ],
      "started": "2016-01-30T23:50:00+00:00",
      "status": "running"
    }
  ],
  "root_password": "YItygq1v3GYjjMomLaKc",
  "server": {
    "backup_window": "22-02",
    "created": "2016-01-30T23:50:00+00:00",
    "datacenter": {
      "description": "Falkenstein 1 DC 8",
      "id": 1,
      "location": {
        "city": "Falkenstein",
        "country": "DE",
        "description": "Falkenstein DC Park 1",
        "id": 1,
        "latitude": 50.47612,
        "longitude": 12.370071,
        "name": "fsn1",
        "network_zone": "eu-central"
      },
      "name": "fsn1-dc8",
      "server_types": {
        "available": [
          1,
          2,
          3
        ],
        "available_for_migration": [
          1,
          2,
          3
        ],
        "supported": [
          1,
          2,
          3
        ]
      }
    },
    "id": 42,
    "image": {
      "bound_to": null,
      "created": "2016-01-30T23:50:00+00:00",
      "created_from": {
        "id": 1,
        "name": "Server"
      },
      "deleted": null,
      "deprecated": "2018-02-28T00:00:00+00:00",
      "description": "Ubuntu 20.04 Standard 64 bit",
      "disk_size": 10,
      "id": 4711,
      "image_size": 2.3,
      "labels": {
        "env": "dev"
      },
      "name": "ubuntu-20.04",
      "os_flavor": "ubuntu",
      "os_version": "20.04",
      "protection": {
        "delete": false
      },
      "rapid_deploy": false,
      "status": "available",
      "type": "snapshot"
    },
    "included_traffic": 654321,
    "ingoing_traffic": 123456,
    "iso": {
      "deprecated": "2018-02-28T00:00:00+00:00",
      "description": "FreeBSD 11.0 x64",
      "id": 4711,
      "name": "FreeBSD-11.0-RELEASE-amd64-dvd1",
      "type": "public"
    },
    "labels": {
      "env": "dev"
    },
    "load_balancers": [],
    "locked": false,
    "name": "my-server",
    "outgoing_traffic": 123456,
    "primary_disk_size": 50,
    "private_net": [
      {
        "alias_ips": [],
        "ip": "10.0.0.2",
        "mac_address": "86:00:ff:2a:7d:e1",
        "network": 4711
      }
    ],
    "protection": {
      "delete": false,
      "rebuild": false
    },
    "public_net": {
      "firewalls": [
        {
          "id": 38,
          "status": "applied"
        }
      ],
      "floating_ips": [
        478
      ],
      "ipv4": {
        "blocked": false,
        "dns_ptr": "server01.example.com",
        "ip": "1.2.3.4"
      },
      "ipv6": {
        "blocked": false,
        "dns_ptr": [
          {
            "dns_ptr": "server.example.com",
            "ip": "2001:db8::1"
          }
        ],
        "ip": "2001:db8::/64"
      }
    },
    "rescue_enabled": false,
    "server_type": {
      "cores": 1,
      "cpu_type": "shared",
      "deprecated": true,
      "description": "CX11",
      "disk": 25,
      "id": 1,
      "memory": 1,
      "name": "cx11",
      "prices": [
        {
          "location": "fsn1",
          "price_hourly": {
            "gross": "1.1900000000000000",
            "net": "1.0000000000"
          },
          "price_monthly": {
            "gross": "1.1900000000000000",
            "net": "1.0000000000"
          }
        }
      ],
      "storage_type": "local"
    },
    "status": "initializing",
    "volumes": []
  }
}
```


# Delete a Server

Deletes a Server. This immediately removes the Server from your account, and it is no longer accessible.

```java
CompletableFuture<ServersResponse1> deleteAServerAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Server |

## Response Type

**200**: The `action` key in the reply contains an Action object with this structure

[`ServersResponse1`](../../doc/models/servers-response-1.md)

## Example Usage

```java
int id = 112;

serversController.deleteAServerAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a Server

Returns a specific Server object. The Server must exist inside the Project

```java
CompletableFuture<ServersResponse2> getAServerAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Server |

## Response Type

**200**: The `server` key in the reply contains a Server object with this structure

[`ServersResponse2`](../../doc/models/servers-response-2.md)

## Example Usage

```java
int id = 112;

serversController.getAServerAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Update a Server

Updates a Server. You can update a Server’s name and a Server’s labels.
Please note that Server names must be unique per Project and valid hostnames as per RFC 1123 (i.e. may only contain letters, digits, periods, and dashes).
Also note that when updating labels, the Server’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```java
CompletableFuture<ServersResponse2> updateAServerAsync(
    final int id,
    final UpdateServerRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Server |
| `body` | [`UpdateServerRequest`](../../doc/models/update-server-request.md) | Body, Optional | - |

## Response Type

**200**: The `server` key in the reply contains the updated Server

[`ServersResponse2`](../../doc/models/servers-response-2.md)

## Example Usage

```java
int id = 112;
UpdateServerRequest body = new UpdateServerRequest.Builder()
    .labels(ApiHelper.deserialize("{\"labelkey\":\"value\"}"))
    .name("my-server")
    .build();

serversController.updateAServerAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get Metrics for a Server

Get Metrics for specified Server.

You must specify the type of metric to get: cpu, disk or network. You can also specify more than one type by comma separation, e.g. cpu,disk.

Depending on the type you will get different time series data

| Type    | Timeseries              | Unit      | Description                                          |
|---------|-------------------------|-----------|------------------------------------------------------|
| cpu     | cpu                     | percent   | Percent CPU usage                                    |
| disk    | disk.0.iops.read        | iop/s     | Number of read IO operations per second              |
|         | disk.0.iops.write       | iop/s     | Number of write IO operations per second             |
|         | disk.0.bandwidth.read   | bytes/s   | Bytes read per second                                |
|         | disk.0.bandwidth.write  | bytes/s   | Bytes written per second                             |
| network | network.0.pps.in        | packets/s | Public Network interface packets per second received |
|         | network.0.pps.out       | packets/s | Public Network interface packets per second sent     |
|         | network.0.bandwidth.in  | bytes/s   | Public Network interface bytes/s received            |
|         | network.0.bandwidth.out | bytes/s   | Public Network interface bytes/s sent                |

Metrics are available for the last 30 days only.

If you do not provide the step argument we will automatically adjust it so that a maximum of 200 samples are returned.

We limit the number of samples returned to a maximum of 500 and will adjust the step parameter accordingly.

```java
CompletableFuture<ServersMetricsResponse> getMetricsForAServerAsync(
    final int id,
    final Type66Enum type,
    final String start,
    final String end,
    final String step)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Server |
| `type` | [`Type66Enum`](../../doc/models/type-66-enum.md) | Query, Required | Type of metrics to get |
| `start` | `String` | Query, Required | Start of period to get Metrics for (in ISO-8601 format) |
| `end` | `String` | Query, Required | End of period to get Metrics for (in ISO-8601 format) |
| `step` | `String` | Query, Optional | Resolution of results in seconds |

## Response Type

**200**: The `metrics` key in the reply contains a metrics object with this structure

[`ServersMetricsResponse`](../../doc/models/servers-metrics-response.md)

## Example Usage

```java
int id = 112;
Type66Enum type = Type66Enum.NETWORK;
String start = "start4";
String end = "end8";

serversController.getMetricsForAServerAsync(id, type, start, end, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

