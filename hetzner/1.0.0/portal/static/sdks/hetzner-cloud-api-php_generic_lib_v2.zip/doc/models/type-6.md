
# Type 6

Type of resource referenced

## Enumeration

`Type6`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```php
use HetznerCloudApiLib\Models\Type6;

$type6 = Type6::SERVER;
```

