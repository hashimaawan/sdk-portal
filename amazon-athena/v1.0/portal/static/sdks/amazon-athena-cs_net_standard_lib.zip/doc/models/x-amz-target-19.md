
# X Amz Target 19

## Enumeration

`XAmzTarget19`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetDatabase` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget19 xAmzTarget19 = XAmzTarget19.EnumAmazonAthenaGetDatabase;
```

