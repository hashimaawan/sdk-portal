
# X Amz Target 12

## Enumeration

`XAmzTarget12`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget12;

$xAmzTarget12 = XAmzTarget12::ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT;
```

