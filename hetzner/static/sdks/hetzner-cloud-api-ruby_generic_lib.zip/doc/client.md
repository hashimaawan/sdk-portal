
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| connection | `Faraday::Connection` | The Faraday connection object passed by the SDK user for making requests |
| adapter | `Faraday::Adapter` | The Faraday adapter object passed by the SDK user for performing http requests |
| timeout | `Float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `Integer` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| retry_interval | `Float` | Pause in seconds between retries. <br> **Default: 1** |
| backoff_factor | `Float` | The amount to multiply each successive retry's interval amount by in order to provide backoff. <br> **Default: 2** |
| retry_statuses | `Array` | A list of HTTP statuses to retry. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array` | A list of HTTP methods to retry. <br> **Default: %i[get put get put]** |
| http_callback | `HttpCallBack` | The Http CallBack allows defining callables for pre and post API calls. |
| proxy_settings | [`ProxySettings`](../doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |

The API client can be initialized as follows:

## Code-Based Client Initialization

```ruby
require 'hetzner_cloud_api'
include HetznerCloudApi

client = Client.new
```

## Environment-Based Client Initialization

```ruby
require 'hetzner_cloud_api'
include HetznerCloudApi

# Create client from environment
client = Client.from_env
```

See the [`Environment-Based Client Initialization`](../doc/environment-based-client-initialization.md) section for details.

## Hetzner Cloud API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| actions | Gets ActionsController |
| certificates | Gets CertificatesController |
| certificate_actions | Gets CertificateActionsController |
| datacenters | Gets DatacentersController |
| firewalls | Gets FirewallsController |
| firewall_actions | Gets FirewallActionsController |
| floating_i_ps | Gets FloatingIPsController |
| floating_ip_actions | Gets FloatingIPActionsController |
| images | Gets ImagesController |
| image_actions | Gets ImageActionsController |
| is_os | Gets ISOsController |
| load_balancers | Gets LoadBalancersController |
| load_balancer_actions | Gets LoadBalancerActionsController |
| load_balancer_types | Gets LoadBalancerTypesController |
| locations | Gets LocationsController |
| primary_i_ps | Gets PrimaryIPsController |
| primary_ip_actions | Gets PrimaryIPActionsController |
| networks | Gets NetworksController |
| network_actions | Gets NetworkActionsController |
| placement_groups | Gets PlacementGroupsController |
| pricing | Gets PricingController |
| servers | Gets ServersController |
| server_actions | Gets ServerActionsController |
| server_types | Gets ServerTypesController |
| ssh_keys | Gets SSHKeysController |
| volumes | Gets VolumesController |
| volume_actions | Gets VolumeActionsController |

