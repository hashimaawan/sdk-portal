
# Traffic

The cost of additional traffic per TB

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pricePerTb` | [`PricePerTb`](../../doc/models/price-per-tb.md) | Required | - |

## Example

```ts
import { Traffic } from 'hetzner-cloud-apilib';

const traffic: Traffic = {
  pricePerTb: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
  },
};
```

