
# Get Work Group Input

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```ruby
get_work_group_input = GetWorkGroupInput.new(
  'WorkGroup0'
)
```

