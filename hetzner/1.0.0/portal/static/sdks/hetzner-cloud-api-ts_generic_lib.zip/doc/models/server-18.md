
# Server 18

*This model accepts additional fields of type unknown.*

## Structure

`Server18`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `backupWindow` | `string \| null` | Required | Time window (UTC) in which the backup will run, or null if the backups are not enabled |
| `created` | `string` | Required | Point in time when the Resource was created (in ISO-8601 format) |
| `datacenter` | [`Datacenter6`](../../doc/models/datacenter-6.md) | Required | Datacenter this Resource is located at |
| `id` | `number` | Required | ID of the Resource |
| `image` | [`Image \| null`](../../doc/models/image.md) | Required | - |
| `includedTraffic` | `number \| null` | Required | Free Traffic for the current billing period in bytes |
| `ingoingTraffic` | `number \| null` | Required | Inbound Traffic for the current billing period in bytes |
| `iso` | [`Iso2 \| null`](../../doc/models/iso-2.md) | Required | ISO Image that is attached to this Server. Null if no ISO is attached. |
| `labels` | `Record<string, string>` | Required | User-defined labels (key-value pairs) |
| `loadBalancers` | `number[] \| undefined` | Optional | - |
| `locked` | `boolean` | Required | True if Server has been locked and is not available to user |
| `name` | `string` | Required | Name of the Server (must be unique per Project and a valid hostname as per RFC 1123) |
| `outgoingTraffic` | `number \| null` | Required | Outbound Traffic for the current billing period in bytes |
| `placementGroup` | [`PlacementGroupNullable \| null \| undefined`](../../doc/models/placement-group-nullable.md) | Optional | - |
| `primaryDiskSize` | `number` | Required | Size of the primary Disk |
| `privateNet` | [`PrivateNet4[]`](../../doc/models/private-net-4.md) | Required | Private networks information |
| `protection` | [`Protection20`](../../doc/models/protection-20.md) | Required | Protection configuration for the Server |
| `publicNet` | [`PublicNet4`](../../doc/models/public-net-4.md) | Required | Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip` |
| `rescueEnabled` | `boolean` | Required | True if rescue mode is enabled. Server will then boot into rescue system on next reboot |
| `serverType` | [`ServerType1`](../../doc/models/server-type-1.md) | Required | Type of Server - determines how much ram, disk and cpu a Server has |
| `status` | [`Status73`](../../doc/models/status-73.md) | Required | Status of the Server |
| `volumes` | `number[] \| undefined` | Optional | IDs of Volumes assigned to this Server |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  CpuType,
  OsFlavor,
  Server18,
  Status24,
  Status72,
  Status73,
  StorageType,
  Type22,
  Type26,
} from 'hetzner-cloud-apilib';

const server18: Server18 = {
  backupWindow: '22-02',
  created: '2016-01-30T23:55:00+00:00',
  datacenter: {
    description: 'Falkenstein DC Park 8',
    id: 42,
    location: {
      city: 'Falkenstein',
      country: 'DE',
      description: 'Falkenstein DC Park 1',
      id: 1,
      latitude: 50.47612,
      longitude: 12.370071,
      name: 'fsn1',
      networkZone: 'eu-central',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    name: 'fsn1-dc8',
    serverTypes: {
      available: [
        1,
        2,
        3
      ],
      availableForMigration: [
        1,
        2,
        3
      ],
      supported: [
        1,
        2,
        3
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  id: 42,
  image: {
    boundTo: null,
    created: '2016-01-30T23:55:00+00:00',
    createdFrom: {
      id: 1,
      name: 'Server',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    deleted: null,
    deprecated: '2018-02-28T00:00:00+00:00',
    description: 'Ubuntu 20.04 Standard 64 bit',
    diskSize: 10,
    id: 42,
    imageSize: 2.3,
    labels: {
      'key0': 'labels4'
    },
    name: 'ubuntu-20.04',
    osFlavor: OsFlavor.Ubuntu,
    osVersion: '20.04',
    protection: {
      mDelete: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    status: Status24.Unavailable,
    type: Type22.Snapshot,
    rapidDeploy: false,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  includedTraffic: 654321,
  ingoingTraffic: 123456,
  iso: {
    deprecated: '2018-02-28T00:00:00+00:00',
    description: 'FreeBSD 11.0 x64',
    id: 42,
    name: 'FreeBSD-11.0-RELEASE-amd64-dvd1',
    type: Type26.Public,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  labels: {
    'key0': 'labels4',
    'key1': 'labels3',
    'key2': 'labels2'
  },
  locked: false,
  name: 'my-resource',
  outgoingTraffic: 123456,
  primaryDiskSize: 50,
  privateNet: [
    {
      aliasIps: [
        'alias_ips4'
      ],
      ip: '10.0.0.2',
      macAddress: '86:00:ff:2a:7d:e1',
      network: 4711,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  protection: {
    mDelete: false,
    rebuild: false,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  publicNet: {
    floatingIps: [
      478
    ],
    ipv4: {
      blocked: false,
      dnsPtr: 'server01.example.com',
      ip: '1.2.3.4',
      id: 42,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    ipv6: {
      blocked: false,
      dnsPtr: [
        {
          dnsPtr: 'server.example.com',
          ip: '2001:db8::1',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        }
      ],
      ip: '2001:db8::/64',
      id: 42,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    firewalls: [
      {
        id: 250,
        status: Status72.Applied,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      {
        id: 250,
        status: Status72.Applied,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  rescueEnabled: false,
  serverType: {
    cores: 1,
    cpuType: CpuType.Shared,
    deprecated: false,
    description: 'CX11',
    disk: 25,
    id: 1,
    memory: 1,
    name: 'cx11',
    prices: [
      {
        location: 'fsn1',
        priceHourly: {
          gross: '1.1900000000000000',
          net: '1.0000000000',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        priceMonthly: {
          gross: '1.1900000000000000',
          net: '1.0000000000',
          additionalProperties: {
            'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
          },
        },
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      }
    ],
    storageType: StorageType.Local,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  status: Status73.Running,
  loadBalancers: [
    248
  ],
  placementGroup: {
    created: 'created8',
    id: 236,
    labels: {
      'key0': 'labels4'
    },
    name: 'name8',
    servers: [
      251,
      252,
      253
    ],
    type: 'type2',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  volumes: [
    199,
    200,
    201
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

