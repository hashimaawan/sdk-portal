
# Type 26

Type of the ISO

## Enumeration

`Type26`

## Fields

| Name |
|  --- |
| `PUBLIC` |
| `PRIVATE` |

## Example

```python
from hetznercloudapi.models.type_26 import Type26

type_26 = Type26.PUBLIC
```

