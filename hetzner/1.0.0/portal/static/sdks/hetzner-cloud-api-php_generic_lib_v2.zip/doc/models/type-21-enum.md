
# Type 21 Enum

## Enumeration

`Type21Enum`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```php
use HetznerCloudAPILib\Models\Type21Enum;

$type21 = Type21Enum::BACKUP;
```

