
# Labels 2

User-defined labels (key-value pairs)

## Structure

`Labels2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Labelkey` | `String` | Optional | - | String getLabelkey() | setLabelkey(String labelkey) |

## Example

```java
import cloud.hetzner.api.models.Labels2;

Labels2 labels2 = new Labels2.Builder()
    .labelkey("value")
    .build();
```

