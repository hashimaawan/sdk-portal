
# Statement Type Enum

## Enumeration

`StatementTypeEnum`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```java
import com.amazonaws.useast1.athena.models.StatementTypeEnum;

StatementTypeEnum statementType = StatementTypeEnum.DDL;
```

