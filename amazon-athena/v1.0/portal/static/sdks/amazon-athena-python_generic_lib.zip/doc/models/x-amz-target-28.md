
# X Amz Target 28

## Enumeration

`XAmzTarget28`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETTABLEMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_28 import XAmzTarget28

x_amz_target_28 = XAmzTarget28.ENUM_AMAZONATHENAGETTABLEMETADATA
```

