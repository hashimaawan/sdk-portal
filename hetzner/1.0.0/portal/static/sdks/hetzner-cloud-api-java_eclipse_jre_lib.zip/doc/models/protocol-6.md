
# Protocol 6

Type of the health check

## Enumeration

`Protocol6`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |

## Example

```java
import cloud.hetzner.api.models.Protocol6;

Protocol6 protocol6 = Protocol6.TCP;
```

