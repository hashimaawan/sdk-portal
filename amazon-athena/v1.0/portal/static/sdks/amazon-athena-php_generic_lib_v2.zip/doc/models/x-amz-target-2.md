
# X Amz Target 2

## Enumeration

`XAmzTarget2`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget2;

$xAmzTarget2 = XAmzTarget2::ENUM_AMAZONATHENABATCHGETQUERYEXECUTION;
```

