
# X Amz Target 32

## Enumeration

`XAmzTarget32`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget32;

$xAmzTarget32 = XAmzTarget32::ENUM_AMAZONATHENALISTCALCULATIONEXECUTIONS;
```

