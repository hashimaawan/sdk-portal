
# List Calculation Executions Request

## Structure

`ListCalculationExecutionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `StateFilter` | [`CalculationExecutionState3Enum?`](../../doc/models/calculation-execution-state-3-enum.md) | Optional | - |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `string` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ListCalculationExecutionsRequest listCalculationExecutionsRequest = new ListCalculationExecutionsRequest
{
    SessionId = "SessionId2",
    StateFilter = CalculationExecutionState3Enum.QUEUED,
    MaxResults = 100,
    NextToken = "NextToken0",
};
```

