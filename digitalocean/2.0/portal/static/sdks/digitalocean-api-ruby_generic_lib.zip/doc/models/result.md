
# Result

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Result`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `metric` | `Hash[String, String]` | Required | An object containing the metric labels. |
| `values` | Array[Array[Integer \| String]] | Required | This is 2d Array of a container for one-of cases. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
result = Result.new(
  metric: {
    'host_id' => '19201920'
  },
  values: [
    [
      1435781430,
      '1'
    ],
    [
      1435781445,
      '1'
    ]
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

