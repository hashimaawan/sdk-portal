
# Size 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Size1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | A Droplet size available for use in a Kubernetes node pool. |
| `slug` | `String` | Optional | The identifier for a size for use when creating a new cluster. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
size1 = Size1.new(
  name: 's-1vcpu-2gb',
  slug: 's-1vcpu-2gb',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

