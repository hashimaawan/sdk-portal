
# Delete Prepared Statement Input

## Structure

`DeletePreparedStatementInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `statementName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` | getStatementName(): string | setStatementName(string statementName): void |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): string | setWorkGroup(string workGroup): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DeletePreparedStatementInputBuilder;

$deletePreparedStatementInput = DeletePreparedStatementInputBuilder::init(
    'StatementName8',
    'WorkGroup2'
)->build();
```

