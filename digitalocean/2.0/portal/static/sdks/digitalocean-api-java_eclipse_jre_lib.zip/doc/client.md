
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| loggingConfig | [`Consumer<ApiLoggingConfiguration.Builder>`](../doc/api-logging-configuration-builder.md) | Set up Logging Configuration instance. |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```java
import com.digitalocean.api.DigitalOceanApiClient;
import com.digitalocean.api.authentication.BearerAuthModel;
import com.digitalocean.api.exceptions.ApiException;
import com.digitalocean.api.http.response.ApiResponse;
import org.slf4j.event.Level;

public class Program {
    public static void main(String[] args) {
        DigitalOceanApiClient client = new DigitalOceanApiClient.Builder()
            .loggingConfig(builder -> builder
                    .level(Level.DEBUG)
                    .requestConfig(logConfigBuilder -> logConfigBuilder.body(true))
                    .responseConfig(logConfigBuilder -> logConfigBuilder.headers(true)))
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .bearerAuthCredentials(new BearerAuthModel.Builder(
                    "AccessToken"
                )
                .build())
            .build();

    }
}
```

## DigitalOcean APIClient Class

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

### Apis

| Name | Description | Return Type |
|  --- | --- | --- |
| `getM1ClickApplicationsApi()` | Provides access to M1ClickApplications controller. | `M1ClickApplicationsApi` |
| `getAccountApi()` | Provides access to Account controller. | `AccountApi` |
| `getActionsApi()` | Provides access to Actions controller. | `ActionsApi` |
| `getAppsApi()` | Provides access to Apps controller. | `AppsApi` |
| `getBillingApi()` | Provides access to Billing controller. | `BillingApi` |
| `getBlockStorageApi()` | Provides access to BlockStorage controller. | `BlockStorageApi` |
| `getBlockStorageActionsApi()` | Provides access to BlockStorageActions controller. | `BlockStorageActionsApi` |
| `getCdnEndpointsApi()` | Provides access to CdnEndpoints controller. | `CdnEndpointsApi` |
| `getCertificatesApi()` | Provides access to Certificates controller. | `CertificatesApi` |
| `getContainerRegistryApi()` | Provides access to ContainerRegistry controller. | `ContainerRegistryApi` |
| `getDatabasesApi()` | Provides access to Databases controller. | `DatabasesApi` |
| `getDomainRecordsApi()` | Provides access to DomainRecords controller. | `DomainRecordsApi` |
| `getDomainsApi()` | Provides access to Domains controller. | `DomainsApi` |
| `getDropletActionsApi()` | Provides access to DropletActions controller. | `DropletActionsApi` |
| `getDropletsApi()` | Provides access to Droplets controller. | `DropletsApi` |
| `getFirewallsApi()` | Provides access to Firewalls controller. | `FirewallsApi` |
| `getFloatingIpActionsApi()` | Provides access to FloatingIpActions controller. | `FloatingIpActionsApi` |
| `getFloatingIPsApi()` | Provides access to FloatingIPs controller. | `FloatingIPsApi` |
| `getFunctionsApi()` | Provides access to Functions controller. | `FunctionsApi` |
| `getImageActionsApi()` | Provides access to ImageActions controller. | `ImageActionsApi` |
| `getImagesApi()` | Provides access to Images controller. | `ImagesApi` |
| `getKubernetesApi()` | Provides access to Kubernetes controller. | `KubernetesApi` |
| `getLoadBalancersApi()` | Provides access to LoadBalancers controller. | `LoadBalancersApi` |
| `getMonitoringApi()` | Provides access to Monitoring controller. | `MonitoringApi` |
| `getProjectResourcesApi()` | Provides access to ProjectResources controller. | `ProjectResourcesApi` |
| `getProjectsApi()` | Provides access to Projects controller. | `ProjectsApi` |
| `getRegionsApi()` | Provides access to Regions controller. | `RegionsApi` |
| `getReservedIpActionsApi()` | Provides access to ReservedIpActions controller. | `ReservedIpActionsApi` |
| `getReservedIPsApi()` | Provides access to ReservedIPs controller. | `ReservedIPsApi` |
| `getSizesApi()` | Provides access to Sizes controller. | `SizesApi` |
| `getSnapshotsApi()` | Provides access to Snapshots controller. | `SnapshotsApi` |
| `getSshKeysApi()` | Provides access to SshKeys controller. | `SshKeysApi` |
| `getTagsApi()` | Provides access to Tags controller. | `TagsApi` |
| `getUptimeApi()` | Provides access to Uptime controller. | `UptimeApi` |
| `getVpCsApi()` | Provides access to VpCs controller. | `VpCsApi` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getLoggingConfig()` | Logging Configuration instance. | [`ReadonlyLoggingConfiguration`](../doc/api-logging-configuration.md) |
| `getBearerAuthCredentials()` | The credentials to use with BearerAuth. | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

