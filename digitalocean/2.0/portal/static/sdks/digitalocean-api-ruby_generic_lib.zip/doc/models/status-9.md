
# Status 9

A status string indicating the current state of the firewall. This can be "waiting", "succeeded", or "failed".

## Enumeration

`Status9`

## Fields

| Name |
|  --- |
| `WAITING` |
| `SUCCEEDED` |
| `FAILED` |

## Example

```ruby
status9 = Status9::WAITING
```

