
# X Amz Target 58 Enum

## Enumeration

`XAmzTarget58Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget58Enum;

XAmzTarget58Enum xAmzTarget58 = XAmzTarget58Enum.ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT;
```

