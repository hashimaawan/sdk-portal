
# Getting Started with Giphy API

## Introduction

Giphy API

Official Giphy Documentation: [https://developers.giphy.com/docs/](https://developers.giphy.com/docs/)

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the giphyapi library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace giphyapi => ".\\giphy-api-go_generic_lib" // local path to the SDK

require giphyapi v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Test the SDK

`Go Testing` is used as the testing framework. To run the unit tests of the SDK, navigate to the root directory of the SDK and run the following command in the terminal:

```bash
$ go test
```

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| customQueryAuthenticationCredentials | [`CustomQueryAuthenticationCredentials`](doc/auth/custom-query-parameter.md) | The Credentials Setter for Custom Query Parameter |

The API client can be initialized as follows:

```go
package main

import (
    "giphyapi"
)

func main() {
    client := giphyapi.NewClient(
    giphyapi.CreateConfiguration(
            giphyapi.WithHttpConfiguration(
                giphyapi.CreateHttpConfiguration(
                    giphyapi.WithTimeout(0),
                ),
            ),
            giphyapi.WithCustomQueryAuthenticationCredentials(
                giphyapi.NewCustomQueryAuthenticationCredentials("api_key"),
            ),
        ),
    )
}
```

## Authorization

This API uses the following authentication schemes.

* [`api_key (Custom Query Parameter)`](doc/auth/custom-query-parameter.md)

## List of APIs

* [Gifs](doc/controllers/gifs.md)
* [Stickers](doc/controllers/stickers.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

