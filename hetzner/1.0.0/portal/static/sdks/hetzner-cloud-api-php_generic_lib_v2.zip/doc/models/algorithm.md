
# Algorithm

Algorithm of the Load Balancer

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type28Enum)`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm | getType(): string | setType(string type): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\AlgorithmBuilder;
use HetznerCloudAPILib\Models\Type28Enum;

$algorithm = AlgorithmBuilder::init(
    Type28Enum::ROUND_ROBIN
)->build();
```

