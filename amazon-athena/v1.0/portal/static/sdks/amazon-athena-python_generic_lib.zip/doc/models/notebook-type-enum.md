
# Notebook Type Enum

## Enumeration

`NotebookTypeEnum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```python
from amazonathena.models.notebook_type_enum import NotebookTypeEnum

notebook_type = NotebookTypeEnum.IPYNB
```

