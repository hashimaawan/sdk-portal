
# State

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `ARCHIVED` |
| `DELETED` |

## Example

```php
use M1PasswordConnectLib\Models\State;

$state = State::ARCHIVED;
```

