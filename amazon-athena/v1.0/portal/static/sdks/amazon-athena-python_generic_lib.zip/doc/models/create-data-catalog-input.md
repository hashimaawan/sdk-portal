
# Create Data Catalog Input

*This model accepts additional fields of type Any.*

## Structure

`CreateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `mtype` | [`DataCatalogType1`](../../doc/models/data-catalog-type-1.md) | Required | - |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `tags` | [`List[Tag]`](../../doc/models/tag.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.create_data_catalog_input import CreateDataCatalogInput
from amazonathena.models.data_catalog_type_1 import DataCatalogType1
from amazonathena.models.parameters import Parameters
from amazonathena.models.tag import Tag

create_data_catalog_input = CreateDataCatalogInput(
    name='Name0',
    mtype=DataCatalogType1.LAMBDA,
    description='Description6',
    parameters=Parameters(
        additional_properties={
            'exampleAdditionalProperty': 'Parameters_additionalProperties2'
        }
    ),
    tags=[
        Tag(
            key='Key0',
            value='Value6',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

