
# Result

## Enumeration

`Result`

## Fields

| Name |
|  --- |
| `Success` |
| `Deny` |

## Example

```go
package main

import (
    "m1PasswordConnect/models"
)

func main() {
    result := models.Result_Success

}
```

