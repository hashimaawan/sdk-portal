
# V2 Uptime Checks Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2UptimeChecksResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `check` | [`Check \| undefined`](../../doc/models/check.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Region8, V2UptimeChecksResponse1 } from 'digitalocean-apilib';

const v2UptimeChecksResponse1: V2UptimeChecksResponse1 = {
  check: {
    id: '00000c0a-0000-0000-0000-000000000000',
    enabled: false,
    name: 'name2',
    regions: [
      Region8.SeAsia
    ],
    target: 'target0',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

