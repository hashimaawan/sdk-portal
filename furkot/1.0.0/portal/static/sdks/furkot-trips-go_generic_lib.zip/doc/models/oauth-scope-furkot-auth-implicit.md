
# Oauth Scope Furkot Auth Implicit

OAuth 2 scopes supported by the API

## Enumeration

`OauthScopeFurkotAuthImplicit`

## Fields

| Name | Description |
|  --- | --- |
| `Readtrips` | list users trips info |

## Example

```go
package main

import (
    "furkotTrips/models"
)

func main() {
    oauthScopeFurkotAuthImplicit := models.OauthScopeFurkotAuthImplicit_Readtrips

}
```

