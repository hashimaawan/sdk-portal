
# Parameter Type

## Enumeration

`ParameterType`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

ParameterType parameterType = ParameterType.Uploaded;
```

