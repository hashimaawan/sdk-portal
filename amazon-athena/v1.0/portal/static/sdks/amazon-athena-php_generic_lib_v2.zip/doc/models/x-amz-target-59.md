
# X Amz Target 59

## Enumeration

`XAmzTarget59`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEWORKGROUP` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget59;

$xAmzTarget59 = XAmzTarget59::ENUM_AMAZONATHENAUPDATEWORKGROUP;
```

