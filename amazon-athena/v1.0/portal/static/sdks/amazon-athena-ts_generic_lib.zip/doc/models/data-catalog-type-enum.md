
# Data Catalog Type Enum

## Enumeration

`DataCatalogTypeEnum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```ts
import { DataCatalogTypeEnum } from 'amazon-athenalib';

const dataCatalogType = DataCatalogTypeEnum.HIVE;
```

