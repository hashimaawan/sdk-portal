
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |

The API client can be initialized as follows:

```java
import cloud.hetzner.api.HetznerCloudAPIClient;
import cloud.hetzner.api.exceptions.ApiException;

public class Program {
    public static void main(String[] args) {
        HetznerCloudAPIClient client = new HetznerCloudAPIClient.Builder()
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .build();

    }
}
```

## Hetzner Cloud APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getActionsController()` | Provides access to Actions controller. | `ActionsController` |
| `getCertificatesController()` | Provides access to Certificates controller. | `CertificatesController` |
| `getCertificateActionsController()` | Provides access to CertificateActions controller. | `CertificateActionsController` |
| `getDatacentersController()` | Provides access to Datacenters controller. | `DatacentersController` |
| `getFirewallsController()` | Provides access to Firewalls controller. | `FirewallsController` |
| `getFirewallActionsController()` | Provides access to FirewallActions controller. | `FirewallActionsController` |
| `getFloatingIPsController()` | Provides access to FloatingIPs controller. | `FloatingIPsController` |
| `getFloatingIPActionsController()` | Provides access to FloatingIPActions controller. | `FloatingIPActionsController` |
| `getImagesController()` | Provides access to Images controller. | `ImagesController` |
| `getImageActionsController()` | Provides access to ImageActions controller. | `ImageActionsController` |
| `getISOsController()` | Provides access to ISOs controller. | `ISOsController` |
| `getLoadBalancersController()` | Provides access to LoadBalancers controller. | `LoadBalancersController` |
| `getLoadBalancerActionsController()` | Provides access to LoadBalancerActions controller. | `LoadBalancerActionsController` |
| `getLoadBalancerTypesController()` | Provides access to LoadBalancerTypes controller. | `LoadBalancerTypesController` |
| `getLocationsController()` | Provides access to Locations controller. | `LocationsController` |
| `getPrimaryIPsController()` | Provides access to PrimaryIPs controller. | `PrimaryIPsController` |
| `getPrimaryIPActionsController()` | Provides access to PrimaryIPActions controller. | `PrimaryIPActionsController` |
| `getNetworksController()` | Provides access to Networks controller. | `NetworksController` |
| `getNetworkActionsController()` | Provides access to NetworkActions controller. | `NetworkActionsController` |
| `getPlacementGroupsController()` | Provides access to PlacementGroups controller. | `PlacementGroupsController` |
| `getPricingController()` | Provides access to Pricing controller. | `PricingController` |
| `getServersController()` | Provides access to Servers controller. | `ServersController` |
| `getServerActionsController()` | Provides access to ServerActions controller. | `ServerActionsController` |
| `getServerTypesController()` | Provides access to ServerTypes controller. | `ServerTypesController` |
| `getSSHKeysController()` | Provides access to SSHKeys controller. | `SSHKeysController` |
| `getVolumesController()` | Provides access to Volumes controller. | `VolumesController` |
| `getVolumeActionsController()` | Provides access to VolumeActions controller. | `VolumeActionsController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

