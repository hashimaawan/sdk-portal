
# Batch Get Query Execution Input

Contains an array of query execution IDs.

## Structure

`BatchGetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionIds` | `[]string` | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    batchGetQueryExecutionInput := models.BatchGetQueryExecutionInput{
        QueryExecutionIds:    []string{
            "QueryExecutionIds7",
            "QueryExecutionIds8",
            "QueryExecutionIds9",
        },
    }

}
```

