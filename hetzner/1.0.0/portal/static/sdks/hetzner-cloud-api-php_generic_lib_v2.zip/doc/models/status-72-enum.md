
# Status 72 Enum

Status of the Firewall on the Server

## Enumeration

`Status72Enum`

## Fields

| Name |
|  --- |
| `APPLIED` |
| `PENDING` |

## Example

```php
use HetznerCloudAPILib\Models\Status72Enum;

$status72 = Status72Enum::APPLIED;
```

