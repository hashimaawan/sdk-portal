
# Category

## Enumeration

`Category`

## Fields

| Name |
|  --- |
| `LOGIN` |
| `PASSWORD` |
| `API_CREDENTIAL` |
| `SERVER` |
| `DATABASE` |
| `CREDIT_CARD` |
| `MEMBERSHIP` |
| `PASSPORT` |
| `SOFTWARE_LICENSE` |
| `OUTDOOR_LICENSE` |
| `SECURE_NOTE` |
| `WIRELESS_ROUTER` |
| `BANK_ACCOUNT` |
| `DRIVER_LICENSE` |
| `IDENTITY` |
| `REWARD_PROGRAM` |
| `DOCUMENT` |
| `EMAIL_ACCOUNT` |
| `SOCIAL_SECURITY_NUMBER` |
| `MEDICAL_RECORD` |
| `SSH_KEY` |
| `CUSTOM` |

## Example

```php
use M1PasswordConnectLib\Models\Category;

$category = Category::SOCIAL_SECURITY_NUMBER;
```

