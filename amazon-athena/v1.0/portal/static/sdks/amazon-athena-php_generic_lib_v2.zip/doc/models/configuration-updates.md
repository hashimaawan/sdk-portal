
# Configuration Updates

## Structure

`ConfigurationUpdates`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `enforceWorkGroupConfiguration` | `?bool` | Optional | - | getEnforceWorkGroupConfiguration(): ?bool | setEnforceWorkGroupConfiguration(?bool enforceWorkGroupConfiguration): void |
| `resultConfigurationUpdates` | [`?ResultConfigurationUpdates2`](../../doc/models/result-configuration-updates-2.md) | Optional | - | getResultConfigurationUpdates(): ?ResultConfigurationUpdates2 | setResultConfigurationUpdates(?ResultConfigurationUpdates2 resultConfigurationUpdates): void |
| `publishCloudWatchMetricsEnabled` | `?bool` | Optional | - | getPublishCloudWatchMetricsEnabled(): ?bool | setPublishCloudWatchMetricsEnabled(?bool publishCloudWatchMetricsEnabled): void |
| `bytesScannedCutoffPerQuery` | `?int` | Optional | **Constraints**: `>= 10000000` | getBytesScannedCutoffPerQuery(): ?int | setBytesScannedCutoffPerQuery(?int bytesScannedCutoffPerQuery): void |
| `removeBytesScannedCutoffPerQuery` | `?bool` | Optional | - | getRemoveBytesScannedCutoffPerQuery(): ?bool | setRemoveBytesScannedCutoffPerQuery(?bool removeBytesScannedCutoffPerQuery): void |
| `requesterPaysEnabled` | `?bool` | Optional | - | getRequesterPaysEnabled(): ?bool | setRequesterPaysEnabled(?bool requesterPaysEnabled): void |
| `engineVersion` | [`?EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - | getEngineVersion(): ?EngineVersion1 | setEngineVersion(?EngineVersion1 engineVersion): void |
| `removeCustomerContentEncryptionConfiguration` | `?bool` | Optional | - | getRemoveCustomerContentEncryptionConfiguration(): ?bool | setRemoveCustomerContentEncryptionConfiguration(?bool removeCustomerContentEncryptionConfiguration): void |
| `additionalConfiguration` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | getAdditionalConfiguration(): ?string | setAdditionalConfiguration(?string additionalConfiguration): void |
| `executionRole` | `?string` | Optional | **Constraints**: *Minimum Length*: `20`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:iam::\d{12}:role/?[a-zA-Z_0-9+=,.@\-_/]+$` | getExecutionRole(): ?string | setExecutionRole(?string executionRole): void |
| `customerContentEncryptionConfiguration` | [`?CustomerContentEncryptionConfiguration`](../../doc/models/customer-content-encryption-configuration.md) | Optional | Specifies the KMS key that is used to encrypt the user's data stores in Athena. | getCustomerContentEncryptionConfiguration(): ?CustomerContentEncryptionConfiguration | setCustomerContentEncryptionConfiguration(?CustomerContentEncryptionConfiguration customerContentEncryptionConfiguration): void |
| `enableMinimumEncryptionConfiguration` | `?bool` | Optional | - | getEnableMinimumEncryptionConfiguration(): ?bool | setEnableMinimumEncryptionConfiguration(?bool enableMinimumEncryptionConfiguration): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ConfigurationUpdatesBuilder;
use AmazonAthenaLib\Models\Builders\ResultConfigurationUpdates2Builder;
use AmazonAthenaLib\Models\Builders\EncryptionConfiguration2Builder;
use AmazonAthenaLib\Models\EncryptionOption1Enum;

$configurationUpdates = ConfigurationUpdatesBuilder::init()
    ->enforceWorkGroupConfiguration(false)
    ->resultConfigurationUpdates(
        ResultConfigurationUpdates2Builder::init()
            ->outputLocation('OutputLocation0')
            ->removeOutputLocation(false)
            ->encryptionConfiguration(
                EncryptionConfiguration2Builder::init(
                    EncryptionOption1Enum::SSE_S3
                )
                    ->kmsKey('KmsKey6')
                    ->build()
            )
            ->removeEncryptionConfiguration(false)
            ->expectedBucketOwner('ExpectedBucketOwner0')
            ->build()
    )
    ->publishCloudWatchMetricsEnabled(false)
    ->bytesScannedCutoffPerQuery(10000000)
    ->removeBytesScannedCutoffPerQuery(false)
    ->build();
```

