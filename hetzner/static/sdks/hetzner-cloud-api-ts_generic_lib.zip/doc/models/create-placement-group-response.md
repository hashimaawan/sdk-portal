
# Create Placement Group Response

## Structure

`CreatePlacementGroupResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`NullableAction \| null \| undefined`](../../doc/models/nullable-action.md) | Optional | - |
| `placementGroup` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - |

## Example

```ts
import {
  CreatePlacementGroupResponse,
  StatusEnum,
} from 'hetzner-cloud-apilib';

const createPlacementGroupResponse: CreatePlacementGroupResponse = {
  placementGroup: {
    created: '2016-01-30T23:55:00+00:00',
    id: 42,
    labels: {
      'key0': 'labels4'
    },
    name: 'my-resource',
    servers: [
      42
    ],
    type: 'spread',
  },
  action: {
    command: 'command6',
    error: {
      code: 'code2',
      message: 'message4',
    },
    finished: 'finished0',
    id: 238,
    progress: 143.26,
    resources: [
      {
        id: 198,
        type: 'type0',
      },
      {
        id: 198,
        type: 'type0',
      },
      {
        id: 198,
        type: 'type0',
      }
    ],
    started: 'started8',
    status: StatusEnum.Running,
  },
};
```

