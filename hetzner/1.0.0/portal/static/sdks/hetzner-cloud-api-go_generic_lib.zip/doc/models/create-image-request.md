
# Create Image Request

*This model accepts additional fields of type interface{}.*

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `*string` | Optional | Description of the Image, will be auto-generated if not set |
| `Labels` | [`*models.Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `Type` | [`*models.Type63`](../../doc/models/type-63.md) | Optional | Type of Image to create (default: `snapshot`) |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    createImageRequest := models.CreateImageRequest{
        Description:           models.ToPointer("my image"),
        Labels:                models.ToPointer(models.Labels{
            Labelkey:              models.ToPointer("labelkey4"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        Type:                  models.ToPointer(models.Type63_Snapshot),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

