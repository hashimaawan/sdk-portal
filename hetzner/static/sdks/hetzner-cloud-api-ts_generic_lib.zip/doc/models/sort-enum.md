
# Sort Enum

## Enumeration

`SortEnum`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```ts
import { SortEnum } from 'hetzner-cloud-apilib';

const sort = SortEnum.EnumIdasc;
```

