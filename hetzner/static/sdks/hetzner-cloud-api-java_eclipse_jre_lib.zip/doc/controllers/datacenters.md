# Datacenters

Each Datacenter represents a *virtual* Datacenter which is made up of possible many physical Datacenters where Servers are hosted.

Datacenter names are composed from their Location and virtual Datacenter number, for example `fsn1-dc14` means virtual Datacenter `14` in Location `fsn1`.

Right now there is only one Datacenter for each Location. The Datacenter numbers for `fsn`, `nbg` and `hel` are arbitrarily set to `14`, `3` and `2` for historic reasons and do not represent real physical Hetzner datacenters.

```java
DatacentersController datacentersController = client.getDatacentersController();
```

## Class Name

`DatacentersController`

## Methods

* [Get All Datacenters](../../doc/controllers/datacenters.md#get-all-datacenters)
* [Get a Datacenter](../../doc/controllers/datacenters.md#get-a-datacenter)


# Get All Datacenters

Returns all Datacenter objects.

```java
CompletableFuture<DatacentersResponse> getAllDatacentersAsync(
    final String name)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter Datacenters by their name. The response will only contain the Datacenter matching the specified name. When the name does not match the Datacenter name format, an `invalid_input` error is returned. |

## Response Type

**200**: The reply contains the `datacenters` and `recommendation` keys

[`DatacentersResponse`](../../doc/models/datacenters-response.md)

## Example Usage

```java
datacentersController.getAllDatacentersAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a Datacenter

Returns a specific Datacenter object.

```java
CompletableFuture<DatacentersResponse1> getADatacenterAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Datacenter |

## Response Type

**200**: The `datacenter` key in the reply contains a Datacenter object with this structure

[`DatacentersResponse1`](../../doc/models/datacenters-response-1.md)

## Example Usage

```java
int id = 112;

datacentersController.getADatacenterAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

