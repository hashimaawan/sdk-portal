
# Get Session Request

## Structure

`GetSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```python
from amazonathena.models.get_session_request import GetSessionRequest

get_session_request = GetSessionRequest(
    session_id='SessionId4'
)
```

