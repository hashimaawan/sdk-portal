
# Column Nullable 2 Enum

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2Enum`

## Fields

| Name |
|  --- |
| `NOTNULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```ts
import { ColumnNullable2Enum } from 'amazon-athenalib';

const columnNullable2 = ColumnNullable2Enum.NOTNULL;
```

