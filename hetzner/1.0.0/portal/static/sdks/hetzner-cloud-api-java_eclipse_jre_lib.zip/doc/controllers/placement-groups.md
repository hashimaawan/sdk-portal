# Placement Groups

```java
PlacementGroupsApi placementGroupsApi = client.getPlacementGroupsApi();
```

## Class Name

`PlacementGroupsApi`

## Methods

* [Get All Placement Groups](../../doc/controllers/placement-groups.md#get-all-placement-groups)
* [Create a Placement Group](../../doc/controllers/placement-groups.md#create-a-placement-group)
* [Delete a Placement Group](../../doc/controllers/placement-groups.md#delete-a-placement-group)
* [Get a Placement Group](../../doc/controllers/placement-groups.md#get-a-placement-group)
* [Update a Placement Group](../../doc/controllers/placement-groups.md#update-a-placement-group)


# Get All Placement Groups

Returns all PlacementGroup objects.

```java
CompletableFuture<ApiResponse<PlacementGroupsResponse>> getAllPlacementGroupsAsync(
    final Sort sort,
    final String name,
    final String labelSelector,
    final ParameterType1 type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`Sort`](../../doc/models/sort.md) | Query, Optional | Can be used multiple times. |
| `name` | `String` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `String` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `type` | [`ParameterType1`](../../doc/models/parameter-type-1.md) | Query, Optional | Can be used multiple times. The response will only contain PlacementGroups matching the type. |

## Response Type

**200**: The `placement_groups` key contains an array of PlacementGroup objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PlacementGroupsResponse`](../../doc/models/placement-groups-response.md).

## Example Usage

```java
placementGroupsApi.getAllPlacementGroupsAsync(null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "placement_groups": [
    {
      "created": "2019-01-08T12:10:00+00:00",
      "id": 897,
      "labels": {
        "key": "value"
      },
      "name": "my Placement Group",
      "servers": [
        4711,
        4712
      ],
      "type": "spread"
    }
  ]
}
```


# Create a Placement Group

Creates a new PlacementGroup.

```java
CompletableFuture<ApiResponse<CreatePlacementGroupResponse>> createAPlacementGroupAsync(
    final CreatePlacementGroupRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreatePlacementGroupRequest`](../../doc/models/create-placement-group-request.md) | Body, Optional | - |

## Response Type

**201**: The `PlacementGroup` key contains the PlacementGroup that was just created.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`CreatePlacementGroupResponse`](../../doc/models/create-placement-group-response.md).

## Example Usage

```java
CreatePlacementGroupRequest body = new CreatePlacementGroupRequest.Builder(
    "my Placement Group",
    "spread"
)
.build();

placementGroupsApi.createAPlacementGroupAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [],
    "type": "spread"
  }
}
```


# Delete a Placement Group

Deletes a PlacementGroup.

```java
CompletableFuture<ApiResponse<Void>> deleteAPlacementGroupAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: PlacementGroup deleted

`void`

## Example Usage

```java
int id = 112;

placementGroupsApi.deleteAPlacementGroupAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a Placement Group

Gets a specific PlacementGroup object.

```java
CompletableFuture<ApiResponse<PlacementGroupResponse>> getAPlacementGroupAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `placement_group` key contains a PlacementGroup object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PlacementGroupResponse`](../../doc/models/placement-group-response.md).

## Example Usage

```java
int id = 112;

placementGroupsApi.getAPlacementGroupAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```


# Update a Placement Group

Updates the PlacementGroup properties.

Note that when updating labels, the PlacementGroup’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the PlacementGroup object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ApiResponse<PlacementGroupResponse>> updateAPlacementGroupAsync(
    final int id,
    final UpdatePlacementGroupRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`UpdatePlacementGroupRequest`](../../doc/models/update-placement-group-request.md) | Body, Optional | - |

## Response Type

**200**: The `certificate` key contains the PlacementGroup that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PlacementGroupResponse`](../../doc/models/placement-group-response.md).

## Example Usage

```java
int id = 112;
UpdatePlacementGroupRequest body = new UpdatePlacementGroupRequest.Builder()
    .labels(ApiHelper.deserialize("{\"labelkey\":\"value\"}"))
    .name("my Placement Group")
    .build();

placementGroupsApi.updateAPlacementGroupAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```

