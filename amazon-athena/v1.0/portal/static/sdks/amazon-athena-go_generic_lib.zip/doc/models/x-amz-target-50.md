
# X Amz Target 50

## Enumeration

`XAmzTarget50`

## Fields

| Name |
|  --- |
| `EnumAmazonathenastopqueryexecution` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget50 := models.XAmzTarget50_EnumAmazonathenastopqueryexecution

}
```

