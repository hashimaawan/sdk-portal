
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |

The API client can be initialized as follows:

```go
package main

import (
    "m1ForgeFinanceApIs"
)

func main() {
    client := m1ForgeFinanceApIs.NewClient(
    m1ForgeFinanceApIs.CreateConfiguration(
            m1ForgeFinanceApIs.WithHttpConfiguration(
                m1ForgeFinanceApIs.CreateHttpConfiguration(
                    m1ForgeFinanceApIs.WithTimeout(30),
                ),
            ),
            m1ForgeFinanceApIs.WithEnvironment(m1ForgeFinanceApIs.PRODUCTION),
            m1ForgeFinanceApIs.WithLoggerConfiguration(
                m1ForgeFinanceApIs.WithLevel("info"),
                m1ForgeFinanceApIs.WithRequestConfiguration(
                    m1ForgeFinanceApIs.WithRequestBody(true),
                ),
                m1ForgeFinanceApIs.WithResponseConfiguration(
                    m1ForgeFinanceApIs.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## 1Forge Finance APIs Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| ForexApi() | Gets ForexApi |

