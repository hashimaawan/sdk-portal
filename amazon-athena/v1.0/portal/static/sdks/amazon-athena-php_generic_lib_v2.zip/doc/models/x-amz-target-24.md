
# X Amz Target 24

## Enumeration

`XAmzTarget24`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRESULTS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget24;

$xAmzTarget24 = XAmzTarget24::ENUM_AMAZONATHENAGETQUERYRESULTS;
```

