
# V2 Registry Options Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2RegistryOptionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `options` | [`?Options2`](../../doc/models/options-2.md) | Optional | - | getOptions(): ?Options2 | setOptions(?Options2 options): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2RegistryOptionsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\Options2Builder;
use DigitalOceanApiLib\Models\Builders\SubscriptionTierBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2RegistryOptionsResponse = V2RegistryOptionsResponseBuilder::init()
    ->options(
        Options2Builder::init()
            ->availableRegions(
                [
                    'available_regions9'
                ]
            )
            ->subscriptionTiers(
                [
                    SubscriptionTierBuilder::init()
                        ->allowStorageOverage(false)
                        ->includedBandwidthBytes(172)
                        ->includedRepositories(194)
                        ->includedStorageBytes(242)
                        ->monthlyPriceInCents(236)
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build(),
                    SubscriptionTierBuilder::init()
                        ->allowStorageOverage(false)
                        ->includedBandwidthBytes(172)
                        ->includedRepositories(194)
                        ->includedStorageBytes(242)
                        ->monthlyPriceInCents(236)
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build(),
                    SubscriptionTierBuilder::init()
                        ->allowStorageOverage(false)
                        ->includedBandwidthBytes(172)
                        ->includedRepositories(194)
                        ->includedStorageBytes(242)
                        ->monthlyPriceInCents(236)
                        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                        ->build()
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

