# Pricing

Returns prices for resources.

```ruby
pricing_controller = client.pricing
```

## Class Name

`PricingController`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```ruby
def get_all_prices
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

[`PricingResponse`](../../doc/models/pricing-response.md)

## Example Usage

```ruby
result = pricing_controller.get_all_prices
puts result
```

