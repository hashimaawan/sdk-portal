
# Pagination

The Pagination Object contains information relating to the number of total results available as well as the number of results fetched and their relative positions.

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Count` | `Integer` | Optional | Total number of items returned. | Integer getCount() | setCount(Integer count) |
| `Offset` | `Integer` | Optional | Position in pagination. | Integer getOffset() | setOffset(Integer offset) |
| `TotalCount` | `Integer` | Optional | Total number of items available. | Integer getTotalCount() | setTotalCount(Integer totalCount) |

## Example

```java
import com.giphy.api.models.Pagination;

Pagination pagination = new Pagination.Builder()
    .count(25)
    .offset(75)
    .totalCount(250)
    .build();
```

