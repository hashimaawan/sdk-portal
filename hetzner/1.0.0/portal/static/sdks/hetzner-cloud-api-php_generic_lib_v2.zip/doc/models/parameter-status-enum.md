
# Parameter Status Enum

## Enumeration

`ParameterStatusEnum`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ERROR` |

## Example

```php
use HetznerCloudAPILib\Models\ParameterStatusEnum;

$parameterStatus = ParameterStatusEnum::ERROR;
```

