
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Type` | [`DataCatalogType2Enum?`](../../doc/models/data-catalog-type-2-enum.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

DataCatalogSummary dataCatalogSummary = new DataCatalogSummary
{
    CatalogName = "CatalogName2",
    Type = DataCatalogType2Enum.HIVE,
};
```

