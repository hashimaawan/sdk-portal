
# Load Balancers Actions Detach from Network Request

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `Float` | Required | ID of an existing network to detach the Load Balancer from |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
load_balancers_actions_detach_from_network_request = LoadBalancersActionsDetachFromNetworkRequest.new(
  network: 4711,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

