
# V2 Databases Sql Mode Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DatabasesSqlModeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sql_mode` | `String` | Required | A string specifying the configured SQL modes for the MySQL cluster. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_databases_sql_mode_response = V2DatabasesSqlModeResponse.new(
  sql_mode: 'ANSI,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION,NO_ZERO_DATE,NO_ZERO_IN_DATE,STRICT_ALL_TABLES',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

