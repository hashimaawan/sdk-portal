
# Options

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Options`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mongodb` | [`Mongodb`](../../doc/models/mongodb.md) | Optional | - |
| `mysql` | [`Mysql`](../../doc/models/mysql.md) | Optional | - |
| `pg` | [`Pg`](../../doc/models/pg.md) | Optional | - |
| `redis` | [`Redis`](../../doc/models/redis.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.layout import Layout
from digitaloceanapi.models.mongodb import Mongodb
from digitaloceanapi.models.mysql import Mysql
from digitaloceanapi.models.options import Options
from digitaloceanapi.models.pg import Pg
from digitaloceanapi.models.redis import Redis

options = Options(
    mongodb=Mongodb(
        regions=[
            'regions3',
            'regions4'
        ],
        versions=[
            'versions3',
            'versions4'
        ],
        layouts=[
            Layout(
                num_nodes=190,
                sizes=[
                    'sizes2',
                    'sizes3'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Layout(
                num_nodes=190,
                sizes=[
                    'sizes2',
                    'sizes3'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    mysql=Mysql(
        regions=[
            'regions9',
            'regions0',
            'regions1'
        ],
        versions=[
            'versions9',
            'versions0',
            'versions1'
        ],
        layouts=[
            Layout(
                num_nodes=190,
                sizes=[
                    'sizes2',
                    'sizes3'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Layout(
                num_nodes=190,
                sizes=[
                    'sizes2',
                    'sizes3'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Layout(
                num_nodes=190,
                sizes=[
                    'sizes2',
                    'sizes3'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    pg=Pg(
        regions=[
            'regions3'
        ],
        versions=[
            'versions3'
        ],
        layouts=[
            Layout(
                num_nodes=190,
                sizes=[
                    'sizes2',
                    'sizes3'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    redis=Redis(
        regions=[
            'regions7'
        ],
        versions=[
            'versions7'
        ],
        layouts=[
            Layout(
                num_nodes=190,
                sizes=[
                    'sizes2',
                    'sizes3'
                ],
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

