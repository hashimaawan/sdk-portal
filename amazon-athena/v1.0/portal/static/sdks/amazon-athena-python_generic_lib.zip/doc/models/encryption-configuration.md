
# Encryption Configuration

If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information.

## Structure

`EncryptionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryption_option` | [`EncryptionOption1Enum`](../../doc/models/encryption-option-1-enum.md) | Required | - |
| `kms_key` | `str` | Optional | - |

## Example

```python
from amazonathena.models.encryption_configuration import EncryptionConfiguration
from amazonathena.models.encryption_option_1_enum import EncryptionOption1Enum

encryption_configuration = EncryptionConfiguration(
    encryption_option=EncryptionOption1Enum.SSE_KMS,
    kms_key='KmsKey4'
)
```

