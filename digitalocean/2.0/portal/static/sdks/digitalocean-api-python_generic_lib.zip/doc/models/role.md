
# Role

A string representing the database user's role. The value will be either
"primary" or "normal".

## Enumeration

`Role`

## Fields

| Name |
|  --- |
| `PRIMARY` |
| `NORMAL` |

## Example

```python
from digitaloceanapi.models.role import Role

role = Role.PRIMARY
```

