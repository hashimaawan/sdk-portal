
# X Amz Target 23

## Enumeration

`XAmzTarget23`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryExecution` |

## Example

```ts
import { XAmzTarget23 } from 'amazon-athenalib';

const xAmzTarget23 = XAmzTarget23.EnumAmazonAthenaGetQueryExecution;
```

