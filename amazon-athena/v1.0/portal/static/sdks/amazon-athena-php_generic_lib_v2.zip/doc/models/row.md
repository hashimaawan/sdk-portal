
# Row

The rows that make up a query result table.

## Structure

`Row`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `data` | [`?(Datum[])`](../../doc/models/datum.md) | Optional | - | getData(): ?array | setData(?array data): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\RowBuilder;
use AmazonAthenaLib\Models\Builders\DatumBuilder;

$row = RowBuilder::init()
    ->data(
        [
            DatumBuilder::init()
                ->varCharValue('VarCharValue8')
                ->build()
        ]
    )
    ->build();
```

