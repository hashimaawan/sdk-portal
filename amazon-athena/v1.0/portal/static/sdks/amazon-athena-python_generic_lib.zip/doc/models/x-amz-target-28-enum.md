
# X Amz Target 28 Enum

## Enumeration

`XAmzTarget28Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETTABLEMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_28_enum import XAmzTarget28Enum

x_amz_target_28 = XAmzTarget28Enum.ENUM_AMAZONATHENAGETTABLEMETADATA
```

