
# Get Query Results Input

## Structure

`GetQueryResultsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `int` | Optional | **Constraints**: `>= 1`, `<= 1000` |

## Example

```python
from amazonathena.models.get_query_results_input import GetQueryResultsInput

get_query_results_input = GetQueryResultsInput(
    query_execution_id='QueryExecutionId4',
    next_token='NextToken0',
    max_results=116
)
```

