
# Type 26

Type of the ISO

## Enumeration

`Type26`

## Fields

| Name |
|  --- |
| `Public` |
| `Private` |

## Example

```ts
import { Type26 } from 'hetzner-cloud-apilib';

const type26 = Type26.Public;
```

