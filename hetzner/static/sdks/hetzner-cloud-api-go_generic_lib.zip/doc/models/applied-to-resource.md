
# Applied to Resource

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Server` | [`*models.Server`](../../doc/models/server.md) | Optional | - |
| `Type` | [`*models.Type5Enum`](../../doc/models/type-5-enum.md) | Optional | Type of resource referenced |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    appliedToResource := models.AppliedToResource{
        Server:               models.ToPointer(models.Server{
            Id:                   14,
        }),
        Type:                 models.ToPointer(models.Type5Enum_SERVER),
    }

}
```

