
# Phase 1

## Enumeration

`Phase1`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING` |
| `CONFIGURING` |
| `ACTIVE` |
| `ERROR` |

## Example

```php
use DigitalOceanApiLib\Models\Phase1;

$phase1 = Phase1::ERROR;
```

