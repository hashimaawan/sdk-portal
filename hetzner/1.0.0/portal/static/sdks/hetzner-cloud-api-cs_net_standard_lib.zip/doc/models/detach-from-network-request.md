
# Detach from Network Request

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Network` | `int` | Required | ID of an existing network to detach the Server from |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

DetachFromNetworkRequest detachFromNetworkRequest = new DetachFromNetworkRequest
{
    Network = 4711,
};
```

