
# V2 Databases Dbs Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesDbsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dbs` | [`?(Db[])`](../../doc/models/db.md) | Optional | - | getDbs(): ?array | setDbs(?array dbs): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesDbsResponseBuilder;
use DigitalOceanApiLib\Models\Builders\DbBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesDbsResponse = V2DatabasesDbsResponseBuilder::init()
    ->dbs(
        [
            DbBuilder::init(
                'name6'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            DbBuilder::init(
                'name6'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            DbBuilder::init(
                'name6'
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

