
# Sort 2 Enum

## Enumeration

`Sort2Enum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `CREATED` |
| `ENUM_CREATEDASC` |
| `ENUM_CREATEDDESC` |

## Example

```ruby
sort2 = Sort2Enum::ENUM_CREATEDASC
```

