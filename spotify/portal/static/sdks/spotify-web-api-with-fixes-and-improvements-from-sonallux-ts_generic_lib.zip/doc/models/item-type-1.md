
# Item Type 1

The ID type: currently only `artist` is supported.

## Enumeration

`ItemType1`

## Fields

| Name |
|  --- |
| `Artist` |

## Example

```ts
import {
  ItemType1,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const itemType1 = ItemType1.Artist;
```

