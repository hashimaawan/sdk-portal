
# X Amz Target 42 Enum

## Enumeration

`XAmzTarget42Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListSessions` |

## Example

```ts
import { XAmzTarget42Enum } from 'amazon-athenalib';

const xAmzTarget42 = XAmzTarget42Enum.EnumAmazonAthenaListSessions;
```

