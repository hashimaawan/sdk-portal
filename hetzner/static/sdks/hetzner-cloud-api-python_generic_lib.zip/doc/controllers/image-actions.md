# Image Actions

```python
image_actions_controller = client.image_actions
```

## Class Name

`ImageActionsController`

## Methods

* [Get All Actions for an Image](../../doc/controllers/image-actions.md#get-all-actions-for-an-image)
* [Change Image Protection](../../doc/controllers/image-actions.md#change-image-protection)
* [Get an Action for an Image](../../doc/controllers/image-actions.md#get-an-action-for-an-image)


# Get All Actions for an Image

Returns all Action objects for an Image. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```python
def get_all_actions_for_an_image(self,
                                id,
                                sort=None,
                                status=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `sort` | [`ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```python
id = 112

result = image_actions_controller.get_all_actions_for_an_image(id)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "change_protection",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 4711,
          "type": "image"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Change Image Protection

Changes the protection configuration of the Image. Can only be used on snapshots.

```python
def change_image_protection(self,
                           id,
                           body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `body` | [`ImagesActionsChangeProtectionRequest`](../../doc/models/images-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```python
id = 112

body = ImagesActionsChangeProtectionRequest(
    delete=True
)

result = image_actions_controller.change_image_protection(
    id,
    body=body
)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "image"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for an Image

Returns a specific Action for an Image.

```python
def get_an_action_for_an_image(self,
                              id,
                              action_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `action_id` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Image Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```python
id = 112

action_id = 224

result = image_actions_controller.get_an_action_for_an_image(
    id,
    action_id
)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "image"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

