
# Images Actions Change Protection Request

## Structure

`ImagesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the snapshot from being deleted |

## Example

```ts
import { ImagesActionsChangeProtectionRequest } from 'hetzner-cloud-apilib';

const imagesActionsChangeProtectionRequest: ImagesActionsChangeProtectionRequest = {
  mDelete: true,
};
```

