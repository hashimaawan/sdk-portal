
# Type 13

Describes the kind of image. It may be one of `snapshot` or `backup`. This specifies whether an image is a user-generated Droplet snapshot or automatically created Droplet backup.

## Enumeration

`Type13`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |
| `BACKUP` |

## Example

```python
from digitaloceanapi.models.type_13 import Type13

type_13 = Type13.SNAPSHOT
```

