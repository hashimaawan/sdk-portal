
# Server 2

Configuration for type Server, required if type is `server`

## Structure

`Server2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Server |

## Example

```ts
import { Server2 } from 'hetzner-cloud-apilib';

const server2: Server2 = {
  id: 162,
};
```

