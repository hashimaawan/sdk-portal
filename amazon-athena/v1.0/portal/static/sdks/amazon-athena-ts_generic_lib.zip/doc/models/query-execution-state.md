
# Query Execution State

## Enumeration

`QueryExecutionState`

## Fields

| Name |
|  --- |
| `Queued` |
| `Running` |
| `Succeeded` |
| `Failed` |
| `Cancelled` |

## Example

```ts
import { QueryExecutionState } from 'amazon-athenalib';

const queryExecutionState = QueryExecutionState.Cancelled;
```

