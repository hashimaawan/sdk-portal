
# Floating Ips Actions Response

*This model accepts additional fields of type interface{}.*

## Structure

`FloatingIpsActionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Actions` | [`[]models.Action`](../../doc/models/action.md) | Required | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    floatingIpsActionsResponse := models.FloatingIpsActionsResponse{
        Actions:               []models.Action{
            models.Action{
                Command:               "start_server",
                Error:                 models.ToPointer(models.Error{
                    Code:                  "action_failed",
                    Message:               "Action failed",
                    AdditionalProperties:  map[string]interface{}{
                        "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                    },
                }),
                Finished:              models.ToPointer("2016-01-30T23:55:00+00:00"),
                Id:                    42,
                Progress:              float64(100),
                Resources:             []models.Resource{
                    models.Resource{
                        Id:                    42,
                        Type:                  "server",
                        AdditionalProperties:  map[string]interface{}{
                            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                        },
                    },
                },
                Started:               "2016-01-30T23:55:00+00:00",
                Status:                models.Status_Success,
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

