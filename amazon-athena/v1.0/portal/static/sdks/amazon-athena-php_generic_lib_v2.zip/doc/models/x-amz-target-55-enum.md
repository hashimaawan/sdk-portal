
# X Amz Target 55 Enum

## Enumeration

`XAmzTarget55Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget55Enum;

$xAmzTarget55 = XAmzTarget55Enum::ENUM_AMAZONATHENAUPDATENAMEDQUERY;
```

