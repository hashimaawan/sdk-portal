
# X Amz Target 55

## Enumeration

`XAmzTarget55`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENAMEDQUERY` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget55;

$xAmzTarget55 = XAmzTarget55::ENUM_AMAZONATHENAUPDATENAMEDQUERY;
```

