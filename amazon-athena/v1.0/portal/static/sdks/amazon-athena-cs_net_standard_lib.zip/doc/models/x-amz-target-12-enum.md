
# X Amz Target 12 Enum

## Enumeration

`XAmzTarget12Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeletePreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget12Enum xAmzTarget12 = XAmzTarget12Enum.EnumAmazonAthenaDeletePreparedStatement;
```

