
# Unprocessed Query Execution Id

Describes a query execution that failed to process.

## Structure

`UnprocessedQueryExecutionId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `ErrorCode` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ErrorMessage` | `string` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

UnprocessedQueryExecutionId unprocessedQueryExecutionId = new UnprocessedQueryExecutionId
{
    QueryExecutionId = "QueryExecutionId6",
    ErrorCode = "ErrorCode2",
    ErrorMessage = "ErrorMessage8",
};
```

