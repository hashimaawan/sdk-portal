
# X Amz Target 53

## Enumeration

`XAmzTarget53`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUntagResource` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget53 xAmzTarget53 = XAmzTarget53.EnumAmazonAthenaUntagResource;
```

