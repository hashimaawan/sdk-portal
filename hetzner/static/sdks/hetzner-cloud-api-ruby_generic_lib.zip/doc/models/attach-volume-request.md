
# Attach Volume Request

## Structure

`AttachVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `automount` | `TrueClass \| FalseClass` | Optional | Auto-mount the Volume after attaching it |
| `server` | `Integer` | Required | ID of the Server the Volume will be attached to |

## Example

```ruby
attach_volume_request = AttachVolumeRequest.new(
  43,
  false
)
```

