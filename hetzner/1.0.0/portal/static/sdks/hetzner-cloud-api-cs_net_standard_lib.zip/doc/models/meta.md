
# Meta

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Pagination` | [`Pagination`](../../doc/models/pagination.md) | Required | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Meta meta = new Meta
{
    Pagination = new Pagination
    {
        LastPage = 4,
        NextPage = 4,
        Page = 3,
        PerPage = 25,
        PreviousPage = 2,
        TotalEntries = 100,
    },
};
```

