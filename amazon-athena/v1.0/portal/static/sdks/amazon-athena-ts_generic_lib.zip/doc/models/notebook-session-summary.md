
# Notebook Session Summary

Contains the notebook session ID and notebook session creation time.

*This model accepts additional fields of type unknown.*

## Structure

`NotebookSessionSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `creationTime` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { NotebookSessionSummary } from 'amazon-athenalib';

const notebookSessionSummary: NotebookSessionSummary = {
  sessionId: 'SessionId0',
  creationTime: '2016-03-13T12:52:32.123Z',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

