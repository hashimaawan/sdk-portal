# Activity

Access API Request Activity

```java
ActivityApi activityApi = client.getActivityApi();
```

## Class Name

`ActivityApi`


# Get Api Activity

```java
CompletableFuture<ApiResponse<List<ApiRequest>>> getApiActivityAsync(
    final Integer limit,
    final Integer offset)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `Integer` | Query, Optional | How many API Events should be retrieved in a single request.<br><br>**Default**: `50` |
| `offset` | `Integer` | Query, Optional | How far into the collection of API Events should the response start<br><br>**Default**: `0` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`List<ApiRequest>`](../../doc/models/api-request.md).

## Example Usage

```java
Integer limit = 10;
Integer offset = 50;

activityApi.getApiActivityAsync(limit, offset).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorResponseException) {
        ErrorResponseException errorResponseException = (ErrorResponseException) cause;
        errorResponseException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

