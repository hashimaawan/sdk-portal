
# V2 Databases Migrate Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesMigrateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `region` | `string` | Required | A slug identifier for the region to which the database cluster will be migrated. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2DatabasesMigrateRequest } from 'digitalocean-apilib';

const v2DatabasesMigrateRequest: V2DatabasesMigrateRequest = {
  region: 'lon1',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

