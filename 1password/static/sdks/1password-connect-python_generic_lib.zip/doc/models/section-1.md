
# Section 1

For files that are in a section, this field describes the section.

*This model accepts additional fields of type Any.*

## Structure

`Section1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from m1passwordconnect.models.section_1 import Section1

section_1 = Section1(
    id='id2',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

