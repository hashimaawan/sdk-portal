
# Terminate Session Response

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `State` | [`SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - | SessionState1Enum getState() | setState(SessionState1Enum state) |

## Example

```java
import com.amazonaws.useast1.athena.models.SessionState1Enum;
import com.amazonaws.useast1.athena.models.TerminateSessionResponse;

TerminateSessionResponse terminateSessionResponse = new TerminateSessionResponse.Builder()
    .state(SessionState1Enum.CREATING)
    .build();
```

