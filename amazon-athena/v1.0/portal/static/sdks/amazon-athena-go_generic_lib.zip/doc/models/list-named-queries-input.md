
# List Named Queries Input

## Structure

`ListNamedQueriesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 0`, `<= 50` |
| `WorkGroup` | `*string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listNamedQueriesInput := models.ListNamedQueriesInput{
        NextToken:            models.ToPointer("NextToken8"),
        MaxResults:           models.ToPointer(50),
        WorkGroup:            models.ToPointer("WorkGroup0"),
    }

}
```

