# API

```go
api := client.Api()
```

## Class Name

`Api`

## Methods

* [Trip GET](../../doc/controllers/api.md#trip-get)
* [Trip Stop by Trip Id GET](../../doc/controllers/api.md#trip-stop-by-trip-id-get)


# Trip GET

list user's trips

```go
TripGet(
    ctx context.Context) (
    models.ApiResponse[[]models.Trip],
    error)
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.Trip](../../doc/models/trip.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := api.TripGet(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Trip Stop by Trip Id GET

list stops for a trip identified by {trip_id}

```go
TripStopByTripIdGet(
    ctx context.Context,
    tripId string) (
    models.ApiResponse[[]models.Step],
    error)
```

## Authentication

This endpoint requires [furkot_auth_access_code](../../doc/auth/oauth-2-authorization-code-grant.md) **OR** [furkot_auth_implicit](../../doc/auth/oauth-2-implicit-grant.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tripId` | `string` | Template, Required | id of the trip |

## Requires scope

### furkot_auth_access_code

`read:trips`

### furkot_auth_implicit

`read:trips`

## Response Type

**200**: Successful response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.Step](../../doc/models/step.md).

## Example Usage

```go
ctx := context.Background()

tripId := "trip_id2"

apiResponse, err := api.TripStopByTripIdGet(ctx, tripId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

