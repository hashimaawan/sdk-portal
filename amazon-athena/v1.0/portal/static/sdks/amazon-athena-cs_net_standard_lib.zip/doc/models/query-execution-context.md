
# Query Execution Context

The database and data catalog context in which the query execution occurs.

## Structure

`QueryExecutionContext`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Database` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `Catalog` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```csharp
using AmazonAthena.Standard.Models;

QueryExecutionContext queryExecutionContext = new QueryExecutionContext
{
    Database = "Database0",
    Catalog = "Catalog6",
};
```

