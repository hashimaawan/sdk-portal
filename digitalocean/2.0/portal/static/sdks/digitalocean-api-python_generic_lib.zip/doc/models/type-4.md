
# Type 4

A string representing the type of the certificate. The value will be `custom` for a user-uploaded certificate or `lets_encrypt` for one automatically generated with Let's Encrypt.

## Enumeration

`Type4`

## Fields

| Name |
|  --- |
| `CUSTOM` |
| `LETS_ENCRYPT` |

## Example

```python
from digitaloceanapi.models.type_4 import Type4

type_4 = Type4.CUSTOM
```

