
# X Amz Target 57

## Enumeration

`XAmzTarget57`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNotebookMetadata` |

## Example

```ts
import { XAmzTarget57 } from 'amazon-athenalib';

const xAmzTarget57 = XAmzTarget57.EnumAmazonAthenaUpdateNotebookMetadata;
```

