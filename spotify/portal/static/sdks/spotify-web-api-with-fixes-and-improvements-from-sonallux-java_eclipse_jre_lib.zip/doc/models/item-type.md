
# Item Type

## Enumeration

`ItemType`

## Fields

| Name |
|  --- |
| `ALBUM` |
| `ARTIST` |
| `PLAYLIST` |
| `TRACK` |
| `SHOW` |
| `EPISODE` |
| `AUDIOBOOK` |

## Example

```java
import com.spotify.api.models.ItemType;

ItemType itemType = ItemType.ARTIST;
```

