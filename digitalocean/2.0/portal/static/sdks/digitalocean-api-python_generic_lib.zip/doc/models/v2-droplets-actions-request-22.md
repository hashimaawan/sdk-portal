
# V2 Droplets Actions Request 22

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest22`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `image` | str \| int \| None | Optional | This is a container for one-of cases. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.type_12 import Type12
from digitaloceanapi.models.v_2_droplets_actions_request_22 import V2DropletsActionsRequest22

v_2_droplets_actions_request_22 = V2DropletsActionsRequest22(
    mtype=Type12.REBOOT,
    image='ubuntu-20-04-x64',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

