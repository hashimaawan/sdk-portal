
# List Work Groups Input

## Structure

`ListWorkGroupsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ListWorkGroupsInput listWorkGroupsInput = new ListWorkGroupsInput
{
    NextToken = "NextToken8",
    MaxResults = 50,
};
```

