
# Delete Subnet Request

*This model accepts additional fields of type object.*

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IpRange` | `string` | Required | IP range of subnet to delete |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

DeleteSubnetRequest deleteSubnetRequest = new DeleteSubnetRequest
{
    IpRange = "10.0.1.0/24",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

