
# Environment

The environment of the project's resources.

## Enumeration

`Environment`

## Fields

| Name |
|  --- |
| `DEVELOPMENT` |
| `STAGING` |
| `PRODUCTION` |

## Example

```python
from digitaloceanapi.models.environment import Environment

environment = Environment.STAGING
```

