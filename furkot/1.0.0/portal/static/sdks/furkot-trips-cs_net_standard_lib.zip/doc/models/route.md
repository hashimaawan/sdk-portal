
# Route

route leading to the stop

*This model accepts additional fields of type object.*

## Structure

`Route`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Distance` | `long?` | Optional | route distance in meters |
| `Duration` | `long?` | Optional | route duration in seconds |
| `Mode` | [`Mode?`](../../doc/models/mode.md) | Optional | travel mode |
| `Polyline` | `string` | Optional | route path compatible with Google polyline encoding algorithm |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using FurkotTrips.Standard.Models;
using FurkotTrips.Standard.Utilities;

Route route = new Route
{
    Distance = 134L,
    Duration = 168L,
    Mode = Mode.Car,
    Polyline = "polyline0",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

