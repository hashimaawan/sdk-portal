
# Update Notebook Metadata Input

## Structure

`UpdateNotebookMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `clientRequestToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```ts
import { UpdateNotebookMetadataInput } from 'amazon-athenalib';

const updateNotebookMetadataInput: UpdateNotebookMetadataInput = {
  notebookId: 'NotebookId8',
  name: 'Name8',
  clientRequestToken: 'ClientRequestToken2',
};
```

