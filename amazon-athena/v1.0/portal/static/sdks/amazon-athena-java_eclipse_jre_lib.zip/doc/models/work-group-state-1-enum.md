
# Work Group State 1 Enum

The state of the workgroup.

## Enumeration

`WorkGroupState1Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```java
import com.amazonaws.useast1.athena.models.WorkGroupState1Enum;

WorkGroupState1Enum workGroupState1 = WorkGroupState1Enum.ENABLED;
```

