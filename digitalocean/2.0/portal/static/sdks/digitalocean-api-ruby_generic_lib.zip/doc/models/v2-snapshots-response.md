
# V2 Snapshots Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2SnapshotsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `snapshots` | [`Array[Snapshot]`](../../doc/models/snapshot.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_snapshots_response = V2SnapshotsResponse.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  snapshots: [
    Snapshot.new(
      id: 'id2',
      created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      min_disk_size: 112,
      name: 'name2',
      regions: [
        'regions7',
        'regions8'
      ],
      size_gigabytes: 148.48,
      resource_id: 'resource_id8',
      resource_type: ResourceType1::DROPLET,
      tags: [
        'tags7',
        'tags8',
        'tags9'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Snapshot.new(
      id: 'id2',
      created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      min_disk_size: 112,
      name: 'name2',
      regions: [
        'regions7',
        'regions8'
      ],
      size_gigabytes: 148.48,
      resource_id: 'resource_id8',
      resource_type: ResourceType1::DROPLET,
      tags: [
        'tags7',
        'tags8',
        'tags9'
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

