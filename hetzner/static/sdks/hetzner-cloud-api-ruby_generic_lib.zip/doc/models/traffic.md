
# Traffic

The cost of additional traffic per TB

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price_per_tb` | [`PricePerTb`](../../doc/models/price-per-tb.md) | Required | - |

## Example

```ruby
traffic = Traffic.new(
  PricePerTb.new(
    '1.1900000000000000',
    '1.0000000000'
  )
)
```

