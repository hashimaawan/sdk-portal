
# Result

## Enumeration

`Result`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `DENY` |

## Example

```ruby
result = Result::SUCCESS
```

