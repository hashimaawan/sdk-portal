
# Default Toast Compression

Specifies the default TOAST compression method for values of compressible columns (the default is lz4).

## Enumeration

`DefaultToastCompression`

## Fields

| Name |
|  --- |
| `LZ4` |
| `PGLZ` |

## Example

```php
use DigitalOceanApiLib\Models\DefaultToastCompression;

$defaultToastCompression = DefaultToastCompression::LZ4;
```

