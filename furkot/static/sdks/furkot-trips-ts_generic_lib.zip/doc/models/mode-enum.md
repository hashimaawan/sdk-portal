
# Mode Enum

travel mode

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `Car` |
| `Motorcycle` |
| `Bicycle` |
| `Walk` |
| `Other` |

## Example

```ts
import { ModeEnum } from 'furkot-tripslib';

const mode = ModeEnum.Bicycle;
```

