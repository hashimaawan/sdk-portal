
# Status 16

## Enumeration

`Status16`

## Fields

| Name |
|  --- |
| `DOWN` |
| `UP` |
| `CHECKING` |

## Example

```php
use DigitalOceanApiLib\Models\Status16;

$status16 = Status16::DOWN;
```

