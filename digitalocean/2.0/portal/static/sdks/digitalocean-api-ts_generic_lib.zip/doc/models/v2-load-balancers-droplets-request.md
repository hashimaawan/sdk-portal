
# V2 Load Balancers Droplets Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2LoadBalancersDropletsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dropletIds` | `number[] \| undefined` | Optional | An array containing the IDs of the Droplets assigned to the load balancer. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2LoadBalancersDropletsRequest } from 'digitalocean-apilib';

const v2LoadBalancersDropletsRequest: V2LoadBalancersDropletsRequest = {
  dropletIds: [
    3164444,
    3164445
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

