
# Volumes Actions Change Protection Request

## Structure

`VolumesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Delete` | `Boolean` | Optional | If true, prevents the Volume from being deleted | Boolean getDelete() | setDelete(Boolean delete) |

## Example

```java
import cloud.hetzner.api.models.VolumesActionsChangeProtectionRequest;

VolumesActionsChangeProtectionRequest volumesActionsChangeProtectionRequest = new VolumesActionsChangeProtectionRequest.Builder()
    .delete(true)
    .build();
```

