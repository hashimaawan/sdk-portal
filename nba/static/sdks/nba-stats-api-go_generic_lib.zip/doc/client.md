
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |

The API client can be initialized as follows:

```go
package main

import (
    "nbastatsapi"
)

func main() {
    client := nbastatsapi.NewClient(
    nbastatsapi.CreateConfiguration(
            nbastatsapi.WithHttpConfiguration(
                nbastatsapi.CreateHttpConfiguration(
                    nbastatsapi.WithTimeout(0),
                ),
            ),
        ),
    )
}
```

## NBA Stats API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| APIController() | Gets APIController |

