
# List Notebook Sessions Response

## Structure

`ListNotebookSessionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_sessions_list` | [`Array[NotebookSessionSummary]`](../../doc/models/notebook-session-summary.md) | Required | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_notebook_sessions_response = ListNotebookSessionsResponse.new(
  [
    NotebookSessionSummary.new(
      'SessionId4',
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z')
    )
  ],
  'NextToken8'
)
```

