
# V2 Floating Ips Response 2

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FloatingIpsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floating_ip` | [`FloatingIp1`](../../doc/models/floating-ip-1.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_floating_ips_response2 = V2FloatingIpsResponse2.new(
  floating_ip: FloatingIp1.new(
    droplet: { 'key1' => 'val1', 'key2' => 'val2' },
    ip: 'ip2',
    locked: false,
    project_id: '0000167e-0000-0000-0000-000000000000',
    region: Region.new(
      available: false,
      features: [
        'features7',
        'features8',
        'features9'
      ],
      name: 'name6',
      sizes: [
        'sizes6'
      ],
      slug: 'slug0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

