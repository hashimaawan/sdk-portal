
# Data Catalog Type 2

The data catalog type.

## Enumeration

`DataCatalogType2`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```java
import com.amazonaws.useast1.athena.models.DataCatalogType2;

DataCatalogType2 dataCatalogType2 = DataCatalogType2.LAMBDA;
```

