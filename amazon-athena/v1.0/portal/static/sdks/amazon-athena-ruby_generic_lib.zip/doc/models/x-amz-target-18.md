
# X Amz Target 18

## Enumeration

`XAmzTarget18`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATACATALOG` |

## Example

```ruby
x_amz_target18 = XAmzTarget18::ENUM_AMAZONATHENAGETDATACATALOG
```

