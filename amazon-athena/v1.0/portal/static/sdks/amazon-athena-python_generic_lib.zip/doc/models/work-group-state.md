
# Work Group State

## Enumeration

`WorkGroupState`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```python
from amazonathena.models.work_group_state import WorkGroupState

work_group_state = WorkGroupState.ENABLED
```

