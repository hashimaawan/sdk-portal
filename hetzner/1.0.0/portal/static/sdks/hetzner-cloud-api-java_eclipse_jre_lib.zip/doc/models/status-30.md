
# Status 30

## Enumeration

`Status30`

## Fields

| Name |
|  --- |
| `HEALTHY` |
| `UNHEALTHY` |
| `UNKNOWN` |

## Example

```java
import cloud.hetzner.api.models.Status30;

Status30 status30 = Status30.HEALTHY;
```

