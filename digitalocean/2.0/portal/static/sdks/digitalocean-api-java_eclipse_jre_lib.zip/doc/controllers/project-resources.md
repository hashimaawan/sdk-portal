# Project Resources

```java
ProjectResourcesApi projectResourcesApi = client.getProjectResourcesApi();
```

## Class Name

`ProjectResourcesApi`

## Methods

* [Projects List Resources Default](../../doc/controllers/project-resources.md#projects-list-resources-default)
* [Projects Assign Resources Default](../../doc/controllers/project-resources.md#projects-assign-resources-default)
* [Projects List Resources](../../doc/controllers/project-resources.md#projects-list-resources)
* [Projects Assign Resources](../../doc/controllers/project-resources.md#projects-assign-resources)


# Projects List Resources Default

To list all your resources in your default project, send a GET request to `/v2/projects/default/resources`.

```java
CompletableFuture<ApiResponse<V2ProjectsDefaultResourcesResponse>> projectsListResourcesDefaultAsync()
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse`](../../doc/models/v2-projects-default-resources-response.md).

## Example Usage

```java
projectResourcesApi.projectsListResourcesDefaultAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects Assign Resources Default

To assign resources to your default project, send a POST request to `/v2/projects/default/resources`.

```java
CompletableFuture<ApiResponse<V2ProjectsDefaultResourcesResponse1>> projectsAssignResourcesDefaultAsync(
    final V2ProjectsDefaultResourcesRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2ProjectsDefaultResourcesRequest`](../../doc/models/v2-projects-default-resources-request.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse1`](../../doc/models/v2-projects-default-resources-response-1.md).

## Example Usage

```java
V2ProjectsDefaultResourcesRequest body = new V2ProjectsDefaultResourcesRequest.Builder()
    .resources(Arrays.asList(
        "do:droplet:13457723",
        "do:domain:example.com"
    ))
    .build();

projectResourcesApi.projectsAssignResourcesDefaultAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects List Resources

To list all your resources in a project, send a GET request to `/v2/projects/$PROJECT_ID/resources`.

```java
CompletableFuture<ApiResponse<V2ProjectsDefaultResourcesResponse>> projectsListResourcesAsync(
    final UUID projectId,
    final Integer perPage,
    final Integer page)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `projectId` | `UUID` | Template, Required | A unique identifier for a project. |
| `perPage` | `Integer` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `Integer` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse`](../../doc/models/v2-projects-default-resources-response.md).

## Example Usage

```java
UUID projectId = UUID.fromString("4de7ac8b-495b-4884-9a69-1050c6793cd6");
Integer perPage = 2;
Integer page = 1;

projectResourcesApi.projectsListResourcesAsync(projectId, perPage, page).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects Assign Resources

To assign resources to a project, send a POST request to `/v2/projects/$PROJECT_ID/resources`.

```java
CompletableFuture<ApiResponse<V2ProjectsDefaultResourcesResponse1>> projectsAssignResourcesAsync(
    final UUID projectId,
    final V2ProjectsDefaultResourcesRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `projectId` | `UUID` | Template, Required | A unique identifier for a project. |
| `body` | [`V2ProjectsDefaultResourcesRequest`](../../doc/models/v2-projects-default-resources-request.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse1`](../../doc/models/v2-projects-default-resources-response-1.md).

## Example Usage

```java
UUID projectId = UUID.fromString("4de7ac8b-495b-4884-9a69-1050c6793cd6");
V2ProjectsDefaultResourcesRequest body = new V2ProjectsDefaultResourcesRequest.Builder()
    .resources(Arrays.asList(
        "do:droplet:13457723",
        "do:domain:example.com"
    ))
    .build();

projectResourcesApi.projectsAssignResourcesAsync(projectId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

