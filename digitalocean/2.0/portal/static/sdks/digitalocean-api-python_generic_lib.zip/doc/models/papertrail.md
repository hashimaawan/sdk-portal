
# Papertrail

Papertrail configuration.

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Papertrail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endpoint` | `str` | Required | Papertrail syslog endpoint. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.papertrail import Papertrail

papertrail = Papertrail(
    endpoint='https://mypapertrailendpoint.com',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

