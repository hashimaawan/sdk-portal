
# Application Dpu Sizes

Contains the application runtime IDs and their supported DPU sizes.

*This model accepts additional fields of type interface{}.*

## Structure

`ApplicationDpuSizes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ApplicationRuntimeId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `SupportedDpuSizes` | `[]int` | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    applicationDpuSizes := models.ApplicationDpuSizes{
        ApplicationRuntimeId:  models.ToPointer("ApplicationRuntimeId4"),
        SupportedDpuSizes:     []int{
            17,
            18,
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

