
# Query Stage Plan

## Structure

`QueryStagePlan`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | - | String getName() | setName(String name) |
| `Identifier` | `String` | Optional | - | String getIdentifier() | setIdentifier(String identifier) |
| `Children` | [`List<QueryStagePlanNode>`](../../doc/models/query-stage-plan-node.md) | Optional | - | List<QueryStagePlanNode> getChildren() | setChildren(List<QueryStagePlanNode> children) |
| `RemoteSources` | `List<String>` | Optional | - | List<String> getRemoteSources() | setRemoteSources(List<String> remoteSources) |

## Example

```java
import com.amazonaws.useast1.athena.models.QueryStagePlan;
import com.amazonaws.useast1.athena.models.QueryStagePlanNode;
import java.util.Arrays;

QueryStagePlan queryStagePlan = new QueryStagePlan.Builder()
    .name("Name0")
    .identifier("Identifier6")
    .children(Arrays.asList(
        new QueryStagePlanNode.Builder()
            .name("Name6")
            .identifier("Identifier2")
            .children(Arrays.asList(
                new QueryStagePlanNode.Builder()
                    .build()
            ))
            .remoteSources(Arrays.asList(
                "RemoteSources4",
                "RemoteSources5",
                "RemoteSources6"
            ))
            .build()
    ))
    .remoteSources(Arrays.asList(
        "RemoteSources8",
        "RemoteSources9",
        "RemoteSources0"
    ))
    .build();
```

