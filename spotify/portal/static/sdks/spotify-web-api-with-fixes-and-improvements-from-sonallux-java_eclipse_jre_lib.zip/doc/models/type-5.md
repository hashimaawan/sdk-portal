
# Type 5

The object type.

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `AUDIO_FEATURES` |

## Example

```java
import com.spotify.api.models.Type5;

Type5 type5 = Type5.AUDIO_FEATURES;
```

