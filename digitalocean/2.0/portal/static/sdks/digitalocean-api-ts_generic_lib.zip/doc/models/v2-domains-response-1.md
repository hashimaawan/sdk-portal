
# V2 Domains Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DomainsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `domain` | [`Domain1 \| undefined`](../../doc/models/domain-1.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2DomainsResponse1 } from 'digitalocean-apilib';

const v2DomainsResponse1: V2DomainsResponse1 = {
  domain: {
    ipAddress: 'ip_address6',
    name: 'example.com',
    ttl: 1800,
    zoneFile: null,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

