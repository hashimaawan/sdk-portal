
# Type 29 Enum

Type of the resource

## Enumeration

`Type29Enum`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |
| `Ip` |

## Example

```ts
import { Type29Enum } from 'hetzner-cloud-apilib';

const type29 = Type29Enum.Server;
```

