
# Apply To

## Structure

`ApplyTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LabelSelector` | [`LabelSelector1`](../../doc/models/label-selector-1.md) | Optional | Configuration for type LabelSelector, required if type is `label_selector` |
| `Server` | [`Server2`](../../doc/models/server-2.md) | Optional | Configuration for type Server, required if type is `server` |
| `Type` | [`Type7Enum`](../../doc/models/type-7-enum.md) | Required | Type of the resource |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ApplyTo applyTo = new ApplyTo
{
    Type = Type7Enum.Server,
    LabelSelector = new LabelSelector1
    {
        Selector = "selector8",
    },
    Server = new Server2
    {
        Id = 14,
    },
};
```

