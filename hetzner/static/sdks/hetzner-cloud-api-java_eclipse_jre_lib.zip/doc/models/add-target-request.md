
# Add Target Request

## Structure

`AddTargetRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ip` | [`Ip`](../../doc/models/ip.md) | Optional | IP targets where the traffic should be routed through. It is only possible to use the (Public or vSwitch) IPs of Hetzner Online Root Servers belonging to the project owner. IPs belonging to other users are blocked. Additionally IPs belonging to services provided by Hetzner Cloud (Servers, Load Balancers, ...) are blocked as well. | Ip getIp() | setIp(Ip ip) |
| `LabelSelector` | [`LabelSelector12`](../../doc/models/label-selector-12.md) | Optional | Configuration for label selector targets, required if type is `label_selector` | LabelSelector12 getLabelSelector() | setLabelSelector(LabelSelector12 labelSelector) |
| `Server` | [`Server16`](../../doc/models/server-16.md) | Optional | Configuration for type Server, required if type is `server` | Server16 getServer() | setServer(Server16 server) |
| `Type` | [`Type29Enum`](../../doc/models/type-29-enum.md) | Required | Type of the resource | Type29Enum getType() | setType(Type29Enum type) |
| `UsePrivateIp` | `Boolean` | Optional | Use the private network IP instead of the public IP of the Server, requires the Server and Load Balancer to be in the same network. Default value is false. | Boolean getUsePrivateIp() | setUsePrivateIp(Boolean usePrivateIp) |

## Example

```java
import cloud.hetzner.api.models.AddTargetRequest;
import cloud.hetzner.api.models.Ip;
import cloud.hetzner.api.models.LabelSelector12;
import cloud.hetzner.api.models.Server16;
import cloud.hetzner.api.models.Type29Enum;

AddTargetRequest addTargetRequest = new AddTargetRequest.Builder(
    Type29Enum.SERVER
)
.ip(new Ip.Builder(
        "ip8"
    )
    .build())
.labelSelector(new LabelSelector12.Builder(
        "selector8"
    )
    .build())
.server(new Server16.Builder(
        217.74D
    )
    .build())
.usePrivateIp(true)
.build();
```

