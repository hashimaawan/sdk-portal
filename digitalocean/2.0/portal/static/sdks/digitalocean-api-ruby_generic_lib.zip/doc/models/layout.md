
# Layout

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Layout`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `num_nodes` | `Integer` | Optional | - |
| `sizes` | `Array[String]` | Optional, Read-only | An array of objects containing the slugs available with various node counts |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
layout = Layout.new(
  num_nodes: 1,
  sizes: [
    'db-s-1vcpu-1gb',
    'db-s-1vcpu-2gb'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

