# 1-Click Applications

```php
$m1ClickApplicationsApi = $client->getM1ClickApplicationsApi();
```

## Class Name

`M1ClickApplicationsApi`

## Methods

* [One Clicks List](../../doc/controllers/1-click-applications.md#one-clicks-list)
* [One Clicks Install Kubernetes](../../doc/controllers/1-click-applications.md#one-clicks-install-kubernetes)


# One Clicks List

To list all available 1-Click applications, send a GET request to `/v2/1-clicks`. The `type` may
be provided as query paramater in order to restrict results to a certain type of 1-Click, for
example: `/v2/1-clicks?type=droplet`. Current supported types are `kubernetes` and `droplet`.

The response will be a JSON object with a key called `1_clicks`. This will be set to an array of
1-Click application data, each of which will contain the the slug and type for the 1-Click.

```php
function oneClicksList(?string $type = null): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`?string(Type)`](../../doc/models/type.md) | Query, Optional | Restrict results to a certain type of 1-Click. |

## Response Type

**200**: A JSON object with a key of `1_clicks`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V21ClicksResponse`](../../doc/models/v21-clicks-response.md).

## Example Usage

```php
$type = Type::KUBERNETES;

$m1ClickApplicationsApi = $client->getM1ClickApplicationsApi();
$apiResponse = $m1ClickApplicationsApi->oneClicksList($type);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V21ClicksResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "1_clicks": [
    {
      "slug": "monitoring",
      "type": "kubernetes"
    },
    {
      "slug": "wordpress-18-04",
      "type": "droplet"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# One Clicks Install Kubernetes

To install a Kubernetes 1-Click application on a cluster, send a POST request to
`/v2/1-clicks/kubernetes`. The `addon_slugs` and `cluster_uuid` must be provided as body
parameter in order to specify which 1-Click application(s) to install. To list all available
1-Click Kubernetes applications, send a request to `/v2/1-clicks?type=kubernetes`.

```php
function oneClicksInstallKubernetes(V21ClicksKubernetesRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V21ClicksKubernetesRequest`](../../doc/models/v21-clicks-kubernetes-request.md) | Body, Required | - |

## Response Type

**200**: The response will verify that a job has been successfully created to install a 1-Click. The
post-installation lifecycle of a 1-Click application can not be managed via the DigitalOcean
API. For additional details specific to the 1-Click, find and view its
[DigitalOcean Marketplace](https://marketplace.digitalocean.com) page.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V21ClicksKubernetesResponse`](../../doc/models/v21-clicks-kubernetes-response.md).

## Example Usage

```php
$body = V21ClicksKubernetesRequestBuilder::init(
    [
        'kube-state-metrics',
        'loki'
    ],
    '50a994b6-c303-438f-9495-7e896cfe6b08'
)->build();

$m1ClickApplicationsApi = $client->getM1ClickApplicationsApi();
$apiResponse = $m1ClickApplicationsApi->oneClicksInstallKubernetes($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V21ClicksKubernetesResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "message": "Successfully kicked off addon job."
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

