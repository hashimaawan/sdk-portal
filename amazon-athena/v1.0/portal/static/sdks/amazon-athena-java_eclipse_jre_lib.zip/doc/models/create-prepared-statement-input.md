
# Create Prepared Statement Input

## Structure

`CreatePreparedStatementInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `StatementName` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` | String getStatementName() | setStatementName(String statementName) |
| `WorkGroup` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | String getWorkGroup() | setWorkGroup(String workGroup) |
| `QueryStatement` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` | String getQueryStatement() | setQueryStatement(String queryStatement) |
| `Description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getDescription() | setDescription(String description) |

## Example

```java
import com.amazonaws.useast1.athena.models.CreatePreparedStatementInput;

CreatePreparedStatementInput createPreparedStatementInput = new CreatePreparedStatementInput.Builder(
    "StatementName2",
    "WorkGroup6",
    "QueryStatement6"
)
.description("Description2")
.build();
```

