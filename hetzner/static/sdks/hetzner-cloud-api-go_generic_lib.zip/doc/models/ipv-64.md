
# Ipv 64

IPv6 network assigned to this Server and its reverse DNS entry

## Structure

`Ipv64`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Blocked` | `bool` | Required | If the IP is blocked by our anti abuse dept |
| `DnsPtr` | [`[]models.DnsPtr8`](../../doc/models/dns-ptr-8.md) | Required | Reverse DNS PTR entries for the IPv6 addresses of this Server, `null` by default |
| `Id` | `*int` | Optional | ID of the Resource |
| `Ip` | `string` | Required | IP address (v6) of this Server |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    ipv64 := models.Ipv64{
        Blocked:              false,
        DnsPtr:               []models.DnsPtr8{
            models.DnsPtr8{
                DnsPtr:               "server.example.com",
                Ip:                   "2001:db8::1",
            },
        },
        Id:                   models.ToPointer(42),
        Ip:                   "2001:db8::/64",
    }

}
```

