
# Applied To

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applied_to_resources` | [`List[AppliedToResource]`](../../doc/models/applied-to-resource.md) | Optional | - |
| `label_selector` | [`LabelSelector`](../../doc/models/label-selector.md) | Optional | - |
| `server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `mtype` | [`Type6Enum`](../../doc/models/type-6-enum.md) | Required | Type of resource referenced |

## Example

```python
from hetznercloudapi.models.applied_to import AppliedTo
from hetznercloudapi.models.applied_to_resource import AppliedToResource
from hetznercloudapi.models.label_selector import LabelSelector
from hetznercloudapi.models.server import Server
from hetznercloudapi.models.type_5_enum import Type5Enum
from hetznercloudapi.models.type_6_enum import Type6Enum

applied_to = AppliedTo(
    mtype=Type6Enum.SERVER,
    applied_to_resources=[
        AppliedToResource(
            server=Server(
                id=14
            ),
            mtype=Type5Enum.SERVER
        )
    ],
    label_selector=LabelSelector(
        selector='selector8'
    ),
    server=Server(
        id=14
    )
)
```

