
# Registry

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Registry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `created_at` | `DateTime` | Optional, Read-only | A time value given in ISO8601 combined date and time format that represents when the registry was created. |
| `name` | `String` | Optional | A globally unique name for the container registry. Must be lowercase and be composed only of numbers, letters and `-`, up to a limit of 63 characters.<br><br>**Constraints**: *Maximum Length*: `63`, *Pattern*: `^[a-z0-9-]{1,63}$` |
| `region` | `String` | Optional | Slug of the region where registry data is stored |
| `storage_usage_bytes` | `Integer` | Optional, Read-only | The amount of storage used in the registry in bytes. |
| `storage_usage_bytes_updated_at` | `DateTime` | Optional, Read-only | The time at which the storage usage was updated. Storage usage is calculated asynchronously, and may not immediately reflect pushes to the registry. |
| `subscription` | [`Subscription`](../../doc/models/subscription.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
registry = Registry.new(
  created_at: DateTimeHelper.from_rfc3339('2020-03-21T16:02:37Z'),
  name: 'example',
  region: 'fra1',
  storage_usage_bytes: 29393920,
  storage_usage_bytes_updated_at: DateTimeHelper.from_rfc3339('2020-11-04T21:39:49.530562231Z'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

