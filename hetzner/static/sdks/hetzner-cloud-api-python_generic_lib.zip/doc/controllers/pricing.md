# Pricing

Returns prices for resources.

```python
pricing_controller = client.pricing
```

## Class Name

`PricingController`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```python
def get_all_prices(self)
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

[`PricingResponse`](../../doc/models/pricing-response.md)

## Example Usage

```python
result = pricing_controller.get_all_prices()
print(result)
```

