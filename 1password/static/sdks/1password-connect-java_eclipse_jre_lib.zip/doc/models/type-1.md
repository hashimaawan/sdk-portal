
# Type 1

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `STRING` |
| `EMAIL` |
| `CONCEALED` |
| `URL` |
| `TOTP` |
| `DATE` |
| `MONTH_YEAR` |
| `MENU` |

## Example

```java
import local.m1password.models.Type1;

Type1 type1 = Type1.CONCEALED;
```

