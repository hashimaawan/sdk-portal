
# Labels 2

User-defined labels (key-value pairs)

*This model accepts additional fields of type object.*

## Structure

`Labels2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labelkey` | `string` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

Labels2 labels2 = new Labels2
{
    Labelkey = "value",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

