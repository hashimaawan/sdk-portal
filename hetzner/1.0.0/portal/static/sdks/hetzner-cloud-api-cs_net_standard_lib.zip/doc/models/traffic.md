
# Traffic

The cost of additional traffic per TB

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PricePerTb` | [`PricePerTb`](../../doc/models/price-per-tb.md) | Required | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Traffic traffic = new Traffic
{
    PricePerTb = new PricePerTb
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
    },
};
```

