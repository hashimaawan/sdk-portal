
# Result Configuration Updates

The information about the updates in the query results, such as output location and encryption configuration for the query results.

## Structure

`ResultConfigurationUpdates`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `outputLocation` | `?string` | Optional | - | getOutputLocation(): ?string | setOutputLocation(?string outputLocation): void |
| `removeOutputLocation` | `?bool` | Optional | - | getRemoveOutputLocation(): ?bool | setRemoveOutputLocation(?bool removeOutputLocation): void |
| `encryptionConfiguration` | [`?EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - | getEncryptionConfiguration(): ?EncryptionConfiguration2 | setEncryptionConfiguration(?EncryptionConfiguration2 encryptionConfiguration): void |
| `removeEncryptionConfiguration` | `?bool` | Optional | - | getRemoveEncryptionConfiguration(): ?bool | setRemoveEncryptionConfiguration(?bool removeEncryptionConfiguration): void |
| `expectedBucketOwner` | `?string` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` | getExpectedBucketOwner(): ?string | setExpectedBucketOwner(?string expectedBucketOwner): void |
| `removeExpectedBucketOwner` | `?bool` | Optional | - | getRemoveExpectedBucketOwner(): ?bool | setRemoveExpectedBucketOwner(?bool removeExpectedBucketOwner): void |
| `aclConfiguration` | [`?AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - | getAclConfiguration(): ?AclConfiguration1 | setAclConfiguration(?AclConfiguration1 aclConfiguration): void |
| `removeAclConfiguration` | `?bool` | Optional | - | getRemoveAclConfiguration(): ?bool | setRemoveAclConfiguration(?bool removeAclConfiguration): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultConfigurationUpdatesBuilder;
use AmazonAthenaLib\Models\Builders\EncryptionConfiguration2Builder;
use AmazonAthenaLib\Models\EncryptionOption1Enum;

$resultConfigurationUpdates = ResultConfigurationUpdatesBuilder::init()
    ->outputLocation('OutputLocation6')
    ->removeOutputLocation(false)
    ->encryptionConfiguration(
        EncryptionConfiguration2Builder::init(
            EncryptionOption1Enum::SSE_S3
        )
            ->kmsKey('KmsKey6')
            ->build()
    )
    ->removeEncryptionConfiguration(false)
    ->expectedBucketOwner('ExpectedBucketOwner6')
    ->build();
```

