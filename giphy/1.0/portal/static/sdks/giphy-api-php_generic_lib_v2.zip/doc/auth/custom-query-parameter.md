
# Custom Query Parameter



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| api_key | `string` | - | `apiKey` | `getApiKey()` |



**Note:** Auth credentials can be set using `CustomQueryAuthenticationCredentialsBuilder::init()` in `customQueryAuthenticationCredentials` method in the client builder and accessed through `getCustomQueryAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```php
use GiphyAPILib\Authentication\CustomQueryAuthenticationCredentialsBuilder;
use GiphyAPILib\GiphyAPIClientBuilder;

$client = GiphyAPIClientBuilder::init()
    ->customQueryAuthenticationCredentials(
        CustomQueryAuthenticationCredentialsBuilder::init(
            'api_key'
        )
    )
    ->build();
```


