
# Status 24 Enum

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24Enum`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |
| `Unavailable` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Status24Enum status24 = Status24Enum.Available;
```

