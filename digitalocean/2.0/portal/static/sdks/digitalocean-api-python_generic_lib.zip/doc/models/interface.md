
# Interface

## Enumeration

`Interface`

## Fields

| Name |
|  --- |
| `PRIVATE` |
| `PUBLIC` |

## Example

```python
from digitaloceanapi.models.interface import Interface

interface = Interface.PRIVATE
```

