
# V2 Domains Response 1

*This model accepts additional fields of type Object.*

## Structure

`V2DomainsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Domain` | [`Domain1`](../../doc/models/domain-1.md) | Optional | - | Domain1 getDomain() | setDomain(Domain1 domain) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Domain1;
import com.digitalocean.api.models.V2DomainsResponse1;
import java.io.IOException;

V2DomainsResponse1 v2DomainsResponse1 = new V2DomainsResponse1.Builder()
    .domain(new Domain1.Builder()
        .ipAddress("ip_address6")
        .name("example.com")
        .ttl(1800)
        .zoneFile(null)
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

