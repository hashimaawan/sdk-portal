
# Create Image Request

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `String` | Optional | Description of the Image, will be auto-generated if not set |
| `labels` | [`Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `type` | [`Type63Enum`](../../doc/models/type-63-enum.md) | Optional | Type of Image to create (default: `snapshot`) |

## Example

```ruby
create_image_request = CreateImageRequest.new(
  'my image',
  Labels.new(
    'labelkey4'
  ),
  Type63Enum::SNAPSHOT
)
```

