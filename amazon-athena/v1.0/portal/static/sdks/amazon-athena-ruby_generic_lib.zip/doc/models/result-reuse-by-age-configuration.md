
# Result Reuse by Age Configuration

Specifies whether previous query results are reused, and if so, their maximum age.

## Structure

`ResultReuseByAgeConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enabled` | `TrueClass \| FalseClass` | Required | - |
| `max_age_in_minutes` | `Integer` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```ruby
result_reuse_by_age_configuration = ResultReuseByAgeConfiguration.new(
  false,
  32
)
```

