
# Statement Type Enum

## Enumeration

`StatementTypeEnum`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```ts
import { StatementTypeEnum } from 'amazon-athenalib';

const statementType = StatementTypeEnum.DDL;
```

