
# Price 8

*This model accepts additional fields of type unknown.*

## Structure

`Price8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location` | `string` | Required | Name of the Location the price is for |
| `priceHourly` | [`PriceHourly7`](../../doc/models/price-hourly-7.md) | Required | Hourly costs for a Primary IP type in this Location |
| `priceMonthly` | [`PriceMonthly9`](../../doc/models/price-monthly-9.md) | Required | Monthly costs for a Primary IP type in this Location |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Price8 } from 'hetzner-cloud-apilib';

const price8: Price8 = {
  location: 'fsn1',
  priceHourly: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  priceMonthly: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

