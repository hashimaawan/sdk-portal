
# X Amz Target 13

## Enumeration

`XAmzTarget13`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEWORKGROUP` |

## Example

```ruby
x_amz_target13 = XAmzTarget13::ENUM_AMAZONATHENADELETEWORKGROUP
```

