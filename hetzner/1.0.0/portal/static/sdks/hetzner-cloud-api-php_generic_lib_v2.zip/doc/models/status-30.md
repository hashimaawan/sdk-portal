
# Status 30

## Enumeration

`Status30`

## Fields

| Name |
|  --- |
| `HEALTHY` |
| `UNHEALTHY` |
| `UNKNOWN` |

## Example

```php
use HetznerCloudApiLib\Models\Status30;

$status30 = Status30::HEALTHY;
```

