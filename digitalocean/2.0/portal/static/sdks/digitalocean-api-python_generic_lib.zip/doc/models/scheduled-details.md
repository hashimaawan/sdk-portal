
# Scheduled Details

Trigger details for SCHEDULED type, where body is optional.

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`ScheduledDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Body`](../../doc/models/body.md) | Optional | Optional data to be sent to function while triggering the function. |
| `cron` | `str` | Required | valid cron expression string which is required for SCHEDULED type triggers. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.body import Body
from digitaloceanapi.models.scheduled_details import ScheduledDetails

scheduled_details = ScheduledDetails(
    cron='* * * * *',
    body=Body(
        name='name6',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

