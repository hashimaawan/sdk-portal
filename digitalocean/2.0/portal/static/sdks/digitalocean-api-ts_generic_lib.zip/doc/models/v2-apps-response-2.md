
# V2 Apps Response 2

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AppsResponse2 } from 'digitalocean-apilib';

const v2AppsResponse2: V2AppsResponse2 = {
  id: '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

