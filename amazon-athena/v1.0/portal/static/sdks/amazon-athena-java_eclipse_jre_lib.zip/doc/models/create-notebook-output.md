
# Create Notebook Output

## Structure

`CreateNotebookOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NotebookId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` | String getNotebookId() | setNotebookId(String notebookId) |

## Example

```java
import com.amazonaws.useast1.athena.models.CreateNotebookOutput;

CreateNotebookOutput createNotebookOutput = new CreateNotebookOutput.Builder()
    .notebookId("NotebookId6")
    .build();
```

