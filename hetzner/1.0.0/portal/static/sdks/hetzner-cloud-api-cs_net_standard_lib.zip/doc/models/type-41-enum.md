
# Type 41 Enum

## Enumeration

`Type41Enum`

## Fields

| Name |
|  --- |
| `OpenConnections` |
| `ConnectionsPerSecond` |
| `RequestsPerSecond` |
| `Bandwidth` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type41Enum type41 = Type41Enum.RequestsPerSecond;
```

