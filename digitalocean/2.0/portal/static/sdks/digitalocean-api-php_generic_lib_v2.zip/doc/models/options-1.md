
# Options 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Options1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `regions` | [`?(Region4[])`](../../doc/models/region-4.md) | Optional | - | getRegions(): ?array | setRegions(?array regions): void |
| `sizes` | [`?(Size1[])`](../../doc/models/size-1.md) | Optional | - | getSizes(): ?array | setSizes(?array sizes): void |
| `versions` | [`?(AvailableUpgradeVersion[])`](../../doc/models/available-upgrade-version.md) | Optional | - | getVersions(): ?array | setVersions(?array versions): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Options1Builder;
use DigitalOceanApiLib\Models\Builders\Region4Builder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\Size1Builder;
use DigitalOceanApiLib\Models\Builders\AvailableUpgradeVersionBuilder;

$options1 = Options1Builder::init()
    ->regions(
        [
            Region4Builder::init()
                ->name('name0')
                ->slug('slug6')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->sizes(
        [
            Size1Builder::init()
                ->name('name0')
                ->slug('slug6')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            Size1Builder::init()
                ->name('name0')
                ->slug('slug6')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->versions(
        [
            AvailableUpgradeVersionBuilder::init()
                ->kubernetesVersion('kubernetes_version6')
                ->slug('slug4')
                ->supportedFeatures(
                    [
                        'supported_features7',
                        'supported_features8'
                    ]
                )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

