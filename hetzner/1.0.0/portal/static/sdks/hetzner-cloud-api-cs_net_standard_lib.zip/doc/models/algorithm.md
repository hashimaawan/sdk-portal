
# Algorithm

Algorithm of the Load Balancer

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Algorithm algorithm = new Algorithm
{
    Type = Type28Enum.RoundRobin,
};
```

