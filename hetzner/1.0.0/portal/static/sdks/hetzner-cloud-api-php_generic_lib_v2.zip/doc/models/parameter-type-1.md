
# Parameter Type 1

## Enumeration

`ParameterType1`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```php
use HetznerCloudApiLib\Models\ParameterType1;

$parameterType1 = ParameterType1::SPREAD;
```

