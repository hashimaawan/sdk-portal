
# Floating Ip 5

*This model accepts additional fields of type Object.*

## Structure

`FloatingIp5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prices` | [`Array[Price6]`](../../doc/models/price-6.md) | Required | Floating IP type costs per Location |
| `type` | [`Type48`](../../doc/models/type-48.md) | Required | The type of the Floating IP |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
floating_ip5 = FloatingIp5.new(
  prices: [
    Price6.new(
      location: 'fsn1',
      price_monthly: PriceMonthly7.new(
        gross: '1.1900000000000000',
        net: '1.0000000000',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  type: Type48::IPV4,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

