
# Placement Group Response

## Structure

`PlacementGroupResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placement_group` | [`PlacementGroup`](../../doc/models/placement-group.md) | Required | - |

## Example

```python
from hetznercloudapi.models.placement_group import PlacementGroup
from hetznercloudapi.models.placement_group_response import PlacementGroupResponse

placement_group_response = PlacementGroupResponse(
    placement_group=PlacementGroup(
        created='2016-01-30T23:55:00+00:00',
        id=42,
        labels={
            'key0': 'labels4'
        },
        name='my-resource',
        servers=[
            42
        ]
    )
)
```

