
# Status 73 Enum

Status of the Server

## Enumeration

`Status73Enum`

## Fields

| Name |
|  --- |
| `Running` |
| `Initializing` |
| `Starting` |
| `Stopping` |
| `Off` |
| `Deleting` |
| `Migrating` |
| `Rebuilding` |
| `Unknown` |

## Example

```ts
import { Status73Enum } from 'hetzner-cloud-apilib';

const status73 = Status73Enum.Starting;
```

