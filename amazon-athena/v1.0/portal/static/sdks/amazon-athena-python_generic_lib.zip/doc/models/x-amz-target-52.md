
# X Amz Target 52

## Enumeration

`XAmzTarget52`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATERMINATESESSION` |

## Example

```python
from amazonathena.models.x_amz_target_52 import XAmzTarget52

x_amz_target_52 = XAmzTarget52.ENUM_AMAZONATHENATERMINATESESSION
```

