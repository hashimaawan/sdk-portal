
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `ITEM` |
| `VAULT` |

## Example

```java
import local.m1password.models.Type;

Type type = Type.ITEM;
```

