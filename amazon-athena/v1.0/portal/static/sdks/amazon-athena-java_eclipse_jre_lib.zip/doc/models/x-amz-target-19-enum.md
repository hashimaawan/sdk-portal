
# X Amz Target 19 Enum

## Enumeration

`XAmzTarget19Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATABASE` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget19Enum;

XAmzTarget19Enum xAmzTarget19 = XAmzTarget19Enum.ENUM_AMAZONATHENAGETDATABASE;
```

