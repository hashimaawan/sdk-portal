
# Customer Content Encryption Configuration

Specifies the KMS key that is used to encrypt the user's data stores in Athena.

## Structure

`CustomerContentEncryptionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kms_key` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:kms:([a-z0-9\-]+):\d{12}:key/?[a-zA-Z_0-9+=,.@\-_/]+$\|^arn:aws[a-z\-]*:kms:([a-z0-9\-]+):\d{12}:alias/?[a-zA-Z_0-9+=,.@\-_/]+$\|^alias/[a-zA-Z0-9/_-]+$\|[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```python
from amazonathena.models.customer_content_encryption_configuration import CustomerContentEncryptionConfiguration

customer_content_encryption_configuration = CustomerContentEncryptionConfiguration(
    kms_key='KmsKey0'
)
```

