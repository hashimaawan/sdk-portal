
# Load Balancer Algorithm

Algorithm of the Load Balancer

## Structure

`LoadBalancerAlgorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```ruby
load_balancer_algorithm = LoadBalancerAlgorithm.new(
  Type28Enum::ROUND_ROBIN
)
```

