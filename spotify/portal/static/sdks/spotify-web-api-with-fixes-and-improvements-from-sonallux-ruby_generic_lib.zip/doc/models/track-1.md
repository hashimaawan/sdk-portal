
# Track 1

*This model accepts additional fields of type Object.*

## Structure

`Track1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `uri` | `String` | Optional | Spotify URI |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
track1 = Track1.new(
  uri: 'uri0',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

