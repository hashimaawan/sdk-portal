
# O Auth Scope Furkot Auth Access Code Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthAccessCodeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list trips and stops info |

## Example

```php
use FurkotTripsLib\Models\OAuthScopeFurkotAuthAccessCodeEnum;

$oAuthScopeFurkotAuthAccessCode = OAuthScopeFurkotAuthAccessCodeEnum::READTRIPS;
```

