
# Getting Started with Furkot Trips

## Introduction

Furkot provides Rest API to access user trip data.
Using Furkot API an application can list user trips and display stops for a specific trip.
Furkot API uses OAuth2 protocol to authorize applications to access data on behalf of users.

Furkot API description: [https://help.furkot.com/widgets/furkot-api.html](https://help.furkot.com/widgets/furkot-api.html)

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the furkotTrips library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace furkotTrips => ".\\furkot-trips-go_generic_lib" // local path to the SDK

require furkotTrips v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |
| furkotAuthAccessCodeCredentials | [`FurkotAuthAccessCodeCredentials`](doc/auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |
| furkotAuthImplicitCredentials | [`FurkotAuthImplicitCredentials`](doc/auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

```go
package main

import (
    "furkotTrips"
    "furkotTrips/models"
)

func main() {
    client := furkotTrips.NewClient(
    furkotTrips.CreateConfiguration(
            furkotTrips.WithHttpConfiguration(
                furkotTrips.CreateHttpConfiguration(
                    furkotTrips.WithTimeout(30),
                ),
            ),
            furkotTrips.WithEnvironment(furkotTrips.PRODUCTION),
            furkotTrips.WithFurkotAuthAccessCodeCredentials(
                furkotTrips.NewFurkotAuthAccessCodeCredentials(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScopeFurkotAuthAccessCode{
        models.OauthScopeFurkotAuthAccessCode_Readtrips,
    }),
            ),
            furkotTrips.WithFurkotAuthImplicitCredentials(
                furkotTrips.NewFurkotAuthImplicitCredentials(
                    "OAuthClientId",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScopeFurkotAuthImplicit{
        models.OauthScopeFurkotAuthImplicit_Readtrips,
    }),
            ),
            furkotTrips.WithLoggerConfiguration(
                furkotTrips.WithLevel("info"),
                furkotTrips.WithRequestConfiguration(
                    furkotTrips.WithRequestBody(true),
                ),
                furkotTrips.WithResponseConfiguration(
                    furkotTrips.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| Production | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`furkot_auth_access_code (OAuth 2 Authorization Code Grant)`](doc/auth/oauth-2-authorization-code-grant.md)
* [`furkot_auth_implicit (OAuth 2 Implicit Grant)`](doc/auth/oauth-2-implicit-grant.md)

## List of APIs

* [API](doc/controllers/api.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

