
# Phase 1

## Enumeration

`Phase1`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING` |
| `CONFIGURING` |
| `ACTIVE` |
| `ERROR` |

## Example

```java
import com.digitalocean.api.models.Phase1;

Phase1 phase1 = Phase1.ERROR;
```

