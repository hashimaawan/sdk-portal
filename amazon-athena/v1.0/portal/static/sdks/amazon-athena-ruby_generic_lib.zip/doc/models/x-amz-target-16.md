
# X Amz Target 16

## Enumeration

`XAmzTarget16`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```ruby
x_amz_target16 = XAmzTarget16::ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE
```

