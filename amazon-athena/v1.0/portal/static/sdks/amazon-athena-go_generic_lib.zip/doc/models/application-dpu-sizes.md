
# Application DPU Sizes

Contains the application runtime IDs and their supported DPU sizes.

## Structure

`ApplicationDPUSizes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ApplicationRuntimeId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `SupportedDPUSizes` | `[]int` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    applicationDPUSizes := models.ApplicationDPUSizes{
        ApplicationRuntimeId: models.ToPointer("ApplicationRuntimeId2"),
        SupportedDPUSizes:    []int{
            57,
        },
    }

}
```

