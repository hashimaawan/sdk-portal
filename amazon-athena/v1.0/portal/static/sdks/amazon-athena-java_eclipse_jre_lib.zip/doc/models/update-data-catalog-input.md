
# Update Data Catalog Input

*This model accepts additional fields of type Object.*

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getName() | setName(String name) |
| `Type` | [`DataCatalogType3`](../../doc/models/data-catalog-type-3.md) | Required | - | DataCatalogType3 getType() | setType(DataCatalogType3 type) |
| `Description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getDescription() | setDescription(String description) |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - | Parameters getParameters() | setParameters(Parameters parameters) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.models.DataCatalogType3;
import com.amazonaws.useast1.athena.models.Parameters;
import com.amazonaws.useast1.athena.models.UpdateDataCatalogInput;
import java.io.IOException;

UpdateDataCatalogInput updateDataCatalogInput = new UpdateDataCatalogInput.Builder(
    "Name4",
    DataCatalogType3.GLUE
)
.description("Description2")
.parameters(new Parameters.Builder()
    .additionalProperty("exampleAdditionalProperty", "Parameters_additionalProperties2")
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

