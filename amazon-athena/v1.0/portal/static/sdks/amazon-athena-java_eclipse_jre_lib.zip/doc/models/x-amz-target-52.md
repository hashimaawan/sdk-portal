
# X Amz Target 52

## Enumeration

`XAmzTarget52`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATERMINATESESSION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget52;

XAmzTarget52 xAmzTarget52 = XAmzTarget52.ENUM_AMAZONATHENATERMINATESESSION;
```

