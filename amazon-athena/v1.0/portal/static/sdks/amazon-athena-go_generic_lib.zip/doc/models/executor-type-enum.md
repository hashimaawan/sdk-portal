
# Executor Type Enum

## Enumeration

`ExecutorTypeEnum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    executorType := models.ExecutorTypeEnum_GATEWAY

}
```

