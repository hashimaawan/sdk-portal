
# Alerts

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Alerts`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `string[]` | Required | An email to notify on an alert trigger. |
| `slack` | [`Slack[]`](../../doc/models/slack.md) | Required | Slack integration details. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Alerts } from 'digitalocean-apilib';

const alerts: Alerts = {
  email: [
    'bob@exmaple.com'
  ],
  slack: [
    {
      channel: 'Production Alerts',
      url: 'https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

