
# Load Balancers Actions Change Algorithm Request

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type39Enum`](../../doc/models/type-39-enum.md) | Required | Algorithm of the Load Balancer |

## Example

```ts
import {
  LoadBalancersActionsChangeAlgorithmRequest,
  Type39Enum,
} from 'hetzner-cloud-apilib';

const loadBalancersActionsChangeAlgorithmRequest: LoadBalancersActionsChangeAlgorithmRequest = {
  type: Type39Enum.RoundRobin,
};
```

