# IS Os

ISOs are read-only Images of DVDs. While we recommend using our Image functionality to install your Servers we also provide some stock ISOs so you can install more exotic operating systems by yourself.

On request our support uploads a private ISO just for you. These are marked with type `private` and only visible in your Project.

To attach an ISO to your Server use `POST /servers/{id}/actions/attach_iso`.

```php
$iSOsController = $client->getISOsController();
```

## Class Name

`ISOsController`

## Methods

* [Get All IS Os](../../doc/controllers/is-os.md#get-all-is-os)
* [Get an ISO](../../doc/controllers/is-os.md#get-an-iso)


# Get All IS Os

Returns all available ISO objects.

```php
function getAllISOs(?string $name = null): IsosResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `?string` | Query, Optional | Can be used to filter ISOs by their name. The response will only contain the ISO matching the specified name. |

## Response Type

**200**: The `isos` key in the reply contains an array of iso objects with this structure

[`IsosResponse`](../../doc/models/isos-response.md)

## Example Usage

```php
$iSOsController = $client->getISOsController();

try {
    $result = $iSOsController->getAllISOs();
    echo 'IsosResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get an ISO

Returns a specific ISO object.

```php
function getAnISO(int $id): IsosResponse1
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the ISO |

## Response Type

**200**: The `iso` key in the reply contains an array of ISO objects with this structure

[`IsosResponse1`](../../doc/models/isos-response-1.md)

## Example Usage

```php
$id = 112;

$iSOsController = $client->getISOsController();

try {
    $result = $iSOsController->getAnISO($id);
    echo 'IsosResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

