
# Executor Type

## Enumeration

`ExecutorType`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```python
from amazonathena.models.executor_type import ExecutorType

executor_type = ExecutorType.WORKER
```

