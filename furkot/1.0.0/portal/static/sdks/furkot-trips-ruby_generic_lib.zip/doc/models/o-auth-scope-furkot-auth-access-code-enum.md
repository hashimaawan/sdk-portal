
# O Auth Scope Furkot Auth Access Code Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthAccessCodeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list trips and stops info |

## Example

```ruby
o_auth_scope_furkot_auth_access_code = OAuthScopeFurkotAuthAccessCodeEnum::READTRIPS
```

