
# V2 Load Balancers Droplets Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2LoadBalancersDropletsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dropletIds` | `?(int[])` | Optional | An array containing the IDs of the Droplets assigned to the load balancer. | getDropletIds(): ?array | setDropletIds(?array dropletIds): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2LoadBalancersDropletsRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2LoadBalancersDropletsRequest = V2LoadBalancersDropletsRequestBuilder::init()
    ->dropletIds(
        [
            3164444,
            3164445
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

