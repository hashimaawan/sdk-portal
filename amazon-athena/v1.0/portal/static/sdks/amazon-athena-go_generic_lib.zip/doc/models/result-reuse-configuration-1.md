
# Result Reuse Configuration 1

*This model accepts additional fields of type interface{}.*

## Structure

`ResultReuseConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResultReuseByAgeConfiguration` | [`*models.ResultReuseByAgeConfiguration2`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    resultReuseConfiguration1 := models.ResultReuseConfiguration1{
        ResultReuseByAgeConfiguration: models.ToPointer(models.ResultReuseByAgeConfiguration2{
            Enabled:               false,
            MaxAgeInMinutes:       models.ToPointer(26),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        AdditionalProperties:          map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

