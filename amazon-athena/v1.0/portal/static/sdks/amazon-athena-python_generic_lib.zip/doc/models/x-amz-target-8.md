
# X Amz Target 8

## Enumeration

`XAmzTarget8`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEWORKGROUP` |

## Example

```python
from amazonathena.models.x_amz_target_8 import XAmzTarget8

x_amz_target_8 = XAmzTarget8.ENUM_AMAZONATHENACREATEWORKGROUP
```

