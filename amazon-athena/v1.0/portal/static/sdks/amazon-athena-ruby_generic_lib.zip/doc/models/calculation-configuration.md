
# Calculation Configuration

Contains configuration information for the calculation.

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code_block` | `String` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```ruby
calculation_configuration = CalculationConfiguration.new(
  'CodeBlock6'
)
```

