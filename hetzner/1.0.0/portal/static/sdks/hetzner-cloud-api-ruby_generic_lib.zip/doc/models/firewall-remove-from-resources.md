
# Firewall Remove from Resources

*This model accepts additional fields of type Object.*

## Structure

`FirewallRemoveFromResources`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label_selector` | [`LabelSelector5`](../../doc/models/label-selector-5.md) | Optional | Configuration for type label_selector, required if type is `label_selector` |
| `server` | [`Server9`](../../doc/models/server-9.md) | Optional | Configuration for type server, required if type is `server` |
| `type` | [`Type7`](../../doc/models/type-7.md) | Optional | Type of the resource |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
firewall_remove_from_resources = FirewallRemoveFromResources.new(
  label_selector: LabelSelector5.new(
    selector: 'selector8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  server: Server9.new(
    id: 14,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  type: Type7::SERVER,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

