
# Algorithm

Algorithm of the Load Balancer

*This model accepts additional fields of type array.*

## Structure

`Algorithm`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type28)`](../../doc/models/type-28.md) | Required | Type of the algorithm | getType(): string | setType(string type): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\AlgorithmBuilder;
use HetznerCloudApiLib\Models\Type28;
use HetznerCloudApiLib\ApiHelper;

$algorithm = AlgorithmBuilder::init(
    Type28::ROUND_ROBIN
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

