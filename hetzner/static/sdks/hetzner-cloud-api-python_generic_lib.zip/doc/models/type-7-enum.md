
# Type 7 Enum

Type of the resource

## Enumeration

`Type7Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```python
from hetznercloudapi.models.type_7_enum import Type7Enum

type_7 = Type7Enum.SERVER
```

