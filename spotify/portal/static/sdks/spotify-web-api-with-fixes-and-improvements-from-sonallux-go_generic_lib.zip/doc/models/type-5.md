
# Type 5

The object type.

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `AudioFeatures` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    type5 := models.Type5_AudioFeatures

}
```

