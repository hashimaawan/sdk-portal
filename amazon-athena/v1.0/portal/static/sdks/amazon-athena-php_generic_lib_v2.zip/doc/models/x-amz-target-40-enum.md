
# X Amz Target 40 Enum

## Enumeration

`XAmzTarget40Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget40Enum;

$xAmzTarget40 = XAmzTarget40Enum::ENUM_AMAZONATHENALISTPREPAREDSTATEMENTS;
```

