# Volume Actions

```ruby
volume_actions_controller = client.volume_actions
```

## Class Name

`VolumeActionsController`

## Methods

* [Get All Actions for a Volume](../../doc/controllers/volume-actions.md#get-all-actions-for-a-volume)
* [Attach Volume to a Server](../../doc/controllers/volume-actions.md#attach-volume-to-a-server)
* [Change Volume Protection](../../doc/controllers/volume-actions.md#change-volume-protection)
* [Detach Volume](../../doc/controllers/volume-actions.md#detach-volume)
* [Resize Volume](../../doc/controllers/volume-actions.md#resize-volume)
* [Get an Action for a Volume](../../doc/controllers/volume-actions.md#get-an-action-for-a-volume)


# Get All Actions for a Volume

Returns all Action objects for a Volume. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```ruby
def get_all_actions_for_a_volume(id,
                                 sort: nil,
                                 status: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Volume |
| `sort` | [`ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```ruby
id = 112

result = volume_actions_controller.get_all_actions_for_a_volume(id)
puts result
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "attach_volume",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        },
        {
          "id": 13,
          "type": "volume"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Attach Volume to a Server

Attaches a Volume to a Server. Works only if the Server is in the same Location as the Volume.

```ruby
def attach_volume_to_a_server(id,
                              body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Volume |
| `body` | [`AttachVolumeRequest`](../../doc/models/attach-volume-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `attach_volume` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```ruby
id = 112

body = AttachVolumeRequest.new(
  43,
  false
)

result = volume_actions_controller.attach_volume_to_a_server(
  id,
  body: body
)
puts result
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 43,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Volume Protection

Changes the protection configuration of a Volume.

```ruby
def change_volume_protection(id,
                             body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Volume |
| `body` | [`VolumesActionsChangeProtectionRequest`](../../doc/models/volumes-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```ruby
id = 112

body = VolumesActionsChangeProtectionRequest.new(
  true
)

result = volume_actions_controller.change_volume_protection(
  id,
  body: body
)
puts result
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Detach Volume

Detaches a Volume from the Server it’s attached to. You may attach it to a Server again at a later time.

```ruby
def detach_volume(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Volume |

## Response Type

**201**: The `action` key contains the `detach_volume` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```ruby
id = 112

result = volume_actions_controller.detach_volume(id)
puts result
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "detach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Resize Volume

Changes the size of a Volume. Note that downsizing a Volume is not possible.

```ruby
def resize_volume(id,
                  body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Volume |
| `body` | [`VolumesActionsResizeRequest`](../../doc/models/volumes-actions-resize-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `resize_volume` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```ruby
id = 112

body = VolumesActionsResizeRequest.new(
  50
)

result = volume_actions_controller.resize_volume(
  id,
  body: body
)
puts result
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "resize_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 554,
        "type": "volume"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Get an Action for a Volume

Returns a specific Action for a Volume.

```ruby
def get_an_action_for_a_volume(id,
                               action_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Volume |
| `action_id` | `Integer` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Volume Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```ruby
id = 112

action_id = 224

result = volume_actions_controller.get_an_action_for_a_volume(
  id,
  action_id
)
puts result
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "attach_volume",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 42,
        "type": "server"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

