
# Engine Version 1

## Structure

`EngineVersion1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selected_engine_version` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `effective_engine_version` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```ruby
engine_version1 = EngineVersion1.new(
  'SelectedEngineVersion8',
  'EffectiveEngineVersion8'
)
```

