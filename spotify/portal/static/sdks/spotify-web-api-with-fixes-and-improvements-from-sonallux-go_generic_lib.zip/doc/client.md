
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| authorizationCodeAuth | [`AuthorizationCodeAuth`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux"
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    client := spotifyWebApiWithFixesAndImprovementsFromSonallux.NewClient(
    spotifyWebApiWithFixesAndImprovementsFromSonallux.CreateConfiguration(
            spotifyWebApiWithFixesAndImprovementsFromSonallux.WithHttpConfiguration(
                spotifyWebApiWithFixesAndImprovementsFromSonallux.CreateHttpConfiguration(
                    spotifyWebApiWithFixesAndImprovementsFromSonallux.WithTimeout(30),
                ),
            ),
            spotifyWebApiWithFixesAndImprovementsFromSonallux.WithEnvironment(spotifyWebApiWithFixesAndImprovementsFromSonallux.PRODUCTION),
            spotifyWebApiWithFixesAndImprovementsFromSonallux.WithAuthorizationCodeAuthCredentials(
                spotifyWebApiWithFixesAndImprovementsFromSonallux.NewAuthorizationCodeAuthCredentials(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri",
                ).
                WithOauthScopes([]models.OauthScope{
        models.OauthScope_AppRemoteControl,
        models.OauthScope_PlaylistReadPrivate,
    }),
            ),
            spotifyWebApiWithFixesAndImprovementsFromSonallux.WithLoggerConfiguration(
                spotifyWebApiWithFixesAndImprovementsFromSonallux.WithLevel("info"),
                spotifyWebApiWithFixesAndImprovementsFromSonallux.WithRequestConfiguration(
                    spotifyWebApiWithFixesAndImprovementsFromSonallux.WithRequestBody(true),
                ),
                spotifyWebApiWithFixesAndImprovementsFromSonallux.WithResponseConfiguration(
                    spotifyWebApiWithFixesAndImprovementsFromSonallux.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Spotify Web API with fixes and improvements from sonallux Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| AlbumsApi() | Gets AlbumsApi |
| ArtistsApi() | Gets ArtistsApi |
| AudiobooksApi() | Gets AudiobooksApi |
| CategoriesApi() | Gets CategoriesApi |
| ChaptersApi() | Gets ChaptersApi |
| EpisodesApi() | Gets EpisodesApi |
| GenresApi() | Gets GenresApi |
| MarketsApi() | Gets MarketsApi |
| PlayerApi() | Gets PlayerApi |
| PlaylistsApi() | Gets PlaylistsApi |
| SearchApi() | Gets SearchApi |
| ShowsApi() | Gets ShowsApi |
| TracksApi() | Gets TracksApi |
| UsersApi() | Gets UsersApi |
| OauthAuthorizationApi() | Gets OauthAuthorizationApi |

