
# List Notebook Sessions Response

*This model accepts additional fields of type array.*

## Structure

`ListNotebookSessionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notebookSessionsList` | [`NotebookSessionSummary[]`](../../doc/models/notebook-session-summary.md) | Required | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `10` | getNotebookSessionsList(): array | setNotebookSessionsList(array notebookSessionsList): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListNotebookSessionsResponseBuilder;
use AmazonAthenaLib\Models\Builders\NotebookSessionSummaryBuilder;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\ApiHelper;

$listNotebookSessionsResponse = ListNotebookSessionsResponseBuilder::init(
    [
        NotebookSessionSummaryBuilder::init()
            ->sessionId('SessionId4')
            ->creationTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->nextToken('NextToken0')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

