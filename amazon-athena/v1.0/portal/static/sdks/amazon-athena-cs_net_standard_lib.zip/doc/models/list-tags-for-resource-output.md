
# List Tags for Resource Output

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Tags` | [`List<Tag>`](../../doc/models/tag.md) | Optional | - |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

ListTagsForResourceOutput listTagsForResourceOutput = new ListTagsForResourceOutput
{
    Tags = new List<Tag>
    {
        new Tag
        {
            Key = "Key0",
            MValue = "Value6",
        },
        new Tag
        {
            Key = "Key0",
            MValue = "Value6",
        },
        new Tag
        {
            Key = "Key0",
            MValue = "Value6",
        },
    },
    NextToken = "NextToken4",
};
```

