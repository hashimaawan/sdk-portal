
# Query Stage Plan

## Structure

`QueryStagePlan`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | - |
| `Identifier` | `string` | Optional | - |
| `Children` | [`List<QueryStagePlanNode>`](../../doc/models/query-stage-plan-node.md) | Optional | - |
| `RemoteSources` | `List<string>` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

QueryStagePlan queryStagePlan = new QueryStagePlan
{
    Name = "Name0",
    Identifier = "Identifier6",
    Children = new List<QueryStagePlanNode>
    {
        new QueryStagePlanNode
        {
            Name = "Name6",
            Identifier = "Identifier2",
            Children = new List<QueryStagePlanNode>
            {
                new QueryStagePlanNode
                {
                },
            },
            RemoteSources = new List<string>
            {
                "RemoteSources4",
                "RemoteSources5",
                "RemoteSources6",
            },
        },
    },
    RemoteSources = new List<string>
    {
        "RemoteSources8",
        "RemoteSources9",
        "RemoteSources0",
    },
};
```

