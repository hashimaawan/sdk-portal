
# Update Firewall Request

*This model accepts additional fields of type Any.*

## Structure

`UpdateFirewallRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Optional | New Firewall name |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.update_firewall_request import UpdateFirewallRequest

update_firewall_request = UpdateFirewallRequest(
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    name='new-name',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

