
# X Amz Target 17

## Enumeration

`XAmzTarget17`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget17;

XAmzTarget17 xAmzTarget17 = XAmzTarget17.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS;
```

