
# Work Group State Enum

## Enumeration

`WorkGroupStateEnum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```java
import com.amazonaws.useast1.athena.models.WorkGroupStateEnum;

WorkGroupStateEnum workGroupState = WorkGroupStateEnum.ENABLED;
```

