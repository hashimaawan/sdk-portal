
# Type 5 Enum

Type of resource referenced

## Enumeration

`Type5Enum`

## Fields

| Name |
|  --- |
| `Server` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type5Enum type5 = Type5Enum.Server;
```

