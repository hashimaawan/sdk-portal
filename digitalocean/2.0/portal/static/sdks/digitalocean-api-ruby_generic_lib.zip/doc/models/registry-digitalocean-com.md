
# Registry Digitalocean Com

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`RegistryDigitaloceanCom`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auth` | `String` | Optional | A base64 encoded string containing credentials for the container registry. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
registry_digitalocean_com = RegistryDigitaloceanCom.new(
  auth: 'YjdkMDNhNjk0N2IyMTdlZmI2ZjNlYzNiZDM1MDQ1ODI6YjdkMDNhNjk0N2IyMTdlZmI2ZjNlYzNiZDM1MDQ1ODIK',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

