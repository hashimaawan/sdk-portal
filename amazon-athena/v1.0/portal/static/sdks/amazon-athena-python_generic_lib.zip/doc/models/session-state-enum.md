
# Session State Enum

## Enumeration

`SessionStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```python
from amazonathena.models.session_state_enum import SessionStateEnum

session_state = SessionStateEnum.IDLE
```

