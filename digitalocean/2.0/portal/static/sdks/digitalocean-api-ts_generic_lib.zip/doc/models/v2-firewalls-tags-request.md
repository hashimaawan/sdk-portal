
# V2 Firewalls Tags Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FirewallsTagsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | `string[] \| null` | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FirewallsTagsRequest } from 'digitalocean-apilib';

const v2FirewallsTagsRequest: V2FirewallsTagsRequest = {
  tags: [
    'tags1'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

