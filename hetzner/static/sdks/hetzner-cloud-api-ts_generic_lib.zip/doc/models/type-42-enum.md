
# Type 42 Enum

Type of Subnetwork

## Enumeration

`Type42Enum`

## Fields

| Name |
|  --- |
| `Cloud` |
| `Server` |
| `Vswitch` |

## Example

```ts
import { Type42Enum } from 'hetzner-cloud-apilib';

const type42 = Type42Enum.Cloud;
```

