
# Compare

## Enumeration

`Compare`

## Fields

| Name |
|  --- |
| `GreaterThan` |
| `LessThan` |

## Example

```ts
import { Compare } from 'digitalocean-apilib';

const compare = Compare.GreaterThan;
```

