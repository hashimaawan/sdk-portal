
# Query Execution State Enum

## Enumeration

`QueryExecutionStateEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```ruby
query_execution_state = QueryExecutionStateEnum::SUCCEEDED
```

