
# Type 49 Enum

The type of the Primary IP

## Enumeration

`Type49Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```ruby
type49 = Type49Enum::IPV4
```

