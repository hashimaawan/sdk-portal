
# Load Balancers Actions Delete Service Request

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ListenPort` | `double` | Required | The listen port of the service you want to delete | double getListenPort() | setListenPort(double listenPort) |

## Example

```java
import cloud.hetzner.api.models.LoadBalancersActionsDeleteServiceRequest;

LoadBalancersActionsDeleteServiceRequest loadBalancersActionsDeleteServiceRequest = new LoadBalancersActionsDeleteServiceRequest.Builder(
    4711D
)
.build();
```

