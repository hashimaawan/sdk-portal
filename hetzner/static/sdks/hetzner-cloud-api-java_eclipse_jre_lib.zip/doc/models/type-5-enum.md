
# Type 5 Enum

Type of resource referenced

## Enumeration

`Type5Enum`

## Fields

| Name |
|  --- |
| `SERVER` |

## Example

```java
import cloud.hetzner.api.models.Type5Enum;

Type5Enum type5 = Type5Enum.SERVER;
```

