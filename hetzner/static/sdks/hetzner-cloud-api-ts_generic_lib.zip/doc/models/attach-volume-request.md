
# Attach Volume Request

## Structure

`AttachVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `automount` | `boolean \| undefined` | Optional | Auto-mount the Volume after attaching it |
| `server` | `number` | Required | ID of the Server the Volume will be attached to |

## Example

```ts
import { AttachVolumeRequest } from 'hetzner-cloud-apilib';

const attachVolumeRequest: AttachVolumeRequest = {
  server: 43,
  automount: false,
};
```

