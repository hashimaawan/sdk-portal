
# Protection

Protection configuration for the Resource

## Structure

`Protection`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `delete` | `bool` | Required | If true, prevents the Resource from being deleted | getDelete(): bool | setDelete(bool delete): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\ProtectionBuilder;

$protection = ProtectionBuilder::init(
    false
)->build();
```

