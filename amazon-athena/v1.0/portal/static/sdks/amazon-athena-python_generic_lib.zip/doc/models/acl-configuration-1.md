
# Acl Configuration 1

*This model accepts additional fields of type Any.*

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s_3_acl_option` | [`S3AclOption1`](../../doc/models/s3-acl-option-1.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.acl_configuration_1 import AclConfiguration1
from amazonathena.models.s_3_acl_option_1 import S3AclOption1

acl_configuration_1 = AclConfiguration1(
    s_3_acl_option=S3AclOption1.BUCKET_OWNER_FULL_CONTROL,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

