
# Get Table Metadata Input

*This model accepts additional fields of type unknown.*

## Structure

`GetTableMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalogName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `databaseName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `tableName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetTableMetadataInput } from 'amazon-athenalib';

const getTableMetadataInput: GetTableMetadataInput = {
  catalogName: 'CatalogName2',
  databaseName: 'DatabaseName2',
  tableName: 'TableName4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

