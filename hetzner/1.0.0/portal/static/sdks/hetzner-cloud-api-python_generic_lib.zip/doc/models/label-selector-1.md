
# Label Selector 1

Configuration for type LabelSelector, required if type is `label_selector`

*This model accepts additional fields of type Any.*

## Structure

`LabelSelector1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `str` | Required | Label selector |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.label_selector_1 import LabelSelector1

label_selector_1 = LabelSelector1(
    selector='selector0',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

