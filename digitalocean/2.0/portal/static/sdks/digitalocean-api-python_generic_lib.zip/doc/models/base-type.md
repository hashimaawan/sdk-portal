
# Base Type

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`BaseType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `str` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.base_type import BaseType

base_type = BaseType(
    mtype='BaseType',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

