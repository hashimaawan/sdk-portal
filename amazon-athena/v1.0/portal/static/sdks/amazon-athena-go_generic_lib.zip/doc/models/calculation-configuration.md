
# Calculation Configuration

Contains configuration information for the calculation.

## Structure

`CalculationConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CodeBlock` | `*string` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    calculationConfiguration := models.CalculationConfiguration{
        CodeBlock:            models.ToPointer("CodeBlock2"),
    }

}
```

