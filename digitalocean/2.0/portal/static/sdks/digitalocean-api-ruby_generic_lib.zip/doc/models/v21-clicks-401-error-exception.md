
# V21 Clicks 401 Error Exception

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V21Clicks401ErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | A short identifier corresponding to the HTTP status code returned. For  example, the ID for a response returning a 404 status code would be "not_found." |
| `message` | `String` | Required | A message providing additional information about the error, including  details to help resolve it when possible. |
| `request_id` | `String` | Optional | Optionally, some endpoints may include a request ID that should be  provided when reporting bugs or opening support tickets to help  identify the issue. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
begin
  # make the API call
rescue V21Clicks401ErrorException => e
  puts "Caught V21Clicks401ErrorException: #{e.message}"
end
```

