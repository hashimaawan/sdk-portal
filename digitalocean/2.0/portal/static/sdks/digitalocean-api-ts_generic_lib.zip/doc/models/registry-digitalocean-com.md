
# Registry Digitalocean Com

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`RegistryDigitaloceanCom`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `auth` | `string \| undefined` | Optional | A base64 encoded string containing credentials for the container registry. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { RegistryDigitaloceanCom } from 'digitalocean-apilib';

const registryDigitaloceanCom: RegistryDigitaloceanCom = {
  auth: 'YjdkMDNhNjk0N2IyMTdlZmI2ZjNlYzNiZDM1MDQ1ODI6YjdkMDNhNjk0N2IyMTdlZmI2ZjNlYzNiZDM1MDQ1ODIK',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

