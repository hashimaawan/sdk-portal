
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`hetznerCloudApiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `hetznerCloudApi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "hetznerCloudApi"
    "net/http"
)

func main() {
    httpConfiguration := hetznerCloudApi.CreateHttpConfiguration(
        hetznerCloudApi.WithTimeout(30),
        hetznerCloudApi.WithTransport(http.DefaultTransport),
        hetznerCloudApi.WithRetryConfiguration(hetznerCloudApi.DefaultRetryConfiguration()),
    )
}
```

