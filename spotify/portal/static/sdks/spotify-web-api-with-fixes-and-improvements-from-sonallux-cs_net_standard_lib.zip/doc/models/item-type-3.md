
# Item Type 3

The ID type: either `artist` or `user`.

## Enumeration

`ItemType3`

## Fields

| Name |
|  --- |
| `Artist` |
| `User` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

ItemType3 itemType3 = ItemType3.Artist;
```

