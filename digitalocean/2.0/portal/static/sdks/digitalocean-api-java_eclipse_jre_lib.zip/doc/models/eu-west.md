
# Eu West

*This model accepts additional fields of type Object.*

## Structure

`EuWest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`Status16`](../../doc/models/status-16.md) | Optional | - | Status16 getStatus() | setStatus(Status16 status) |
| `StatusChangedAt` | `String` | Optional | - | String getStatusChangedAt() | setStatusChangedAt(String statusChangedAt) |
| `ThirtyDayUptimePercentage` | `Double` | Optional | - | Double getThirtyDayUptimePercentage() | setThirtyDayUptimePercentage(Double thirtyDayUptimePercentage) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.EuWest;
import com.digitalocean.api.models.Status16;
import java.io.IOException;

EuWest euWest = new EuWest.Builder()
    .status(Status16.UP)
    .statusChangedAt("2022-03-17T22:28:51Z")
    .thirtyDayUptimePercentage(97.99D)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

