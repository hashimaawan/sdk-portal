
# Row

The rows that make up a query result table.

## Structure

`Row`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`List[Datum]`](../../doc/models/datum.md) | Optional | - |

## Example

```python
from amazonathena.models.datum import Datum
from amazonathena.models.row import Row

row = Row(
    data=[
        Datum(
            var_char_value='VarCharValue8'
        )
    ]
)
```

