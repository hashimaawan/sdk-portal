
# Server Backup

Will increase base Server costs by specific percentage

## Structure

`ServerBackup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `percentage` | `String` | Required | Percentage by how much the base price will increase |

## Example

```ruby
server_backup = ServerBackup.new(
  '20.0000000000'
)
```

