
# Change Protection Request 2

## Structure

`ChangeProtectionRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the Primary IP from being deleted |

## Example

```ts
import { ChangeProtectionRequest2 } from 'hetzner-cloud-apilib';

const changeProtectionRequest2: ChangeProtectionRequest2 = {
  mDelete: true,
};
```

