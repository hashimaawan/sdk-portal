
# Stickers Random Response

*This model accepts additional fields of type object.*

## Structure

`StickersRandomResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Data` | [`Gif`](../../doc/models/gif.md) | Optional | - |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Optional | The Meta Object contains basic information regarding the request, whether it was successful, and the response given by the API.  Check `responses` to see a description of types of response codes the API might give you under different cirumstances. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using GiphyApi.Standard.Models;
using GiphyApi.Standard.Utilities;
using System.Collections.Generic;
using System.Globalization;

StickersRandomResponse stickersRandomResponse = new StickersRandomResponse
{
    Data = new Gif
    {
        BitlyUrl = "bitly_url0",
        ContentUrl = "content_url4",
        CreateDatetime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
            provider: CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind),
        EmbdedUrl = "embded_url8",
        FeaturedTags = new List<string>
        {
            "featured_tags0",
        },
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    Meta = new Meta
    {
        Msg = "msg8",
        ResponseId = "response_id0",
        Status = 98,
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

