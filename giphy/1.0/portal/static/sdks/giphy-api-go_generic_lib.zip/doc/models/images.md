
# Images

An object containing data for various available formats and sizes of this GIF.

*This model accepts additional fields of type interface{}.*

## Structure

`Images`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Downsized` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedLarge` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedMedium` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedSmall` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `DownsizedStill` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeight` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightDownsampled` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightSmall` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightSmallStill` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedHeightStill` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidth` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthDownsampled` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthSmall` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthSmallStill` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `FixedWidthStill` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `Looping` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `Original` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `OriginalStill` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `Preview` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `PreviewGif` | [`*models.Image`](../../doc/models/image.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "giphyApi/models"
)

func main() {
    images := models.Images{
        Downsized:              models.ToPointer(models.Image{
            Frames:                models.ToPointer("frames0"),
            Height:                models.ToPointer("height8"),
            Mp4:                   models.ToPointer("mp40"),
            Mp4Size:               models.ToPointer("mp4_size2"),
            Size:                  models.ToPointer("size2"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        DownsizedLarge:         models.ToPointer(models.Image{
            Frames:                models.ToPointer("frames6"),
            Height:                models.ToPointer("height4"),
            Mp4:                   models.ToPointer("mp46"),
            Mp4Size:               models.ToPointer("mp4_size8"),
            Size:                  models.ToPointer("size8"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        DownsizedMedium:        models.ToPointer(models.Image{
            Frames:                models.ToPointer("frames2"),
            Height:                models.ToPointer("height0"),
            Mp4:                   models.ToPointer("mp42"),
            Mp4Size:               models.ToPointer("mp4_size4"),
            Size:                  models.ToPointer("size4"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        DownsizedSmall:         models.ToPointer(models.Image{
            Frames:                models.ToPointer("frames0"),
            Height:                models.ToPointer("height8"),
            Mp4:                   models.ToPointer("mp40"),
            Mp4Size:               models.ToPointer("mp4_size2"),
            Size:                  models.ToPointer("size2"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        DownsizedStill:         models.ToPointer(models.Image{
            Frames:                models.ToPointer("frames4"),
            Height:                models.ToPointer("height4"),
            Mp4:                   models.ToPointer("mp46"),
            Mp4Size:               models.ToPointer("mp4_size8"),
            Size:                  models.ToPointer("size2"),
            AdditionalProperties:  map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        AdditionalProperties:   map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

