
# Delete Work Group Input

## Structure

`DeleteWorkGroupInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): string | setWorkGroup(string workGroup): void |
| `recursiveDeleteOption` | `?bool` | Optional | - | getRecursiveDeleteOption(): ?bool | setRecursiveDeleteOption(?bool recursiveDeleteOption): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DeleteWorkGroupInputBuilder;

$deleteWorkGroupInput = DeleteWorkGroupInputBuilder::init(
    'WorkGroup0'
)
    ->recursiveDeleteOption(false)
    ->build();
```

