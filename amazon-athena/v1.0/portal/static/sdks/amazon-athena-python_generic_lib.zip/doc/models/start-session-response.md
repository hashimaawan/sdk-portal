
# Start Session Response

*This model accepts additional fields of type Any.*

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `state` | [`SessionState1`](../../doc/models/session-state-1.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.session_state_1 import SessionState1
from amazonathena.models.start_session_response import StartSessionResponse

start_session_response = StartSessionResponse(
    session_id='SessionId6',
    state=SessionState1.DEGRADED,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

