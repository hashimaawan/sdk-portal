
# Status 2

## Enumeration

`Status2`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING` |
| `RUNNING` |
| `ERROR` |
| `SUCCESS` |

## Example

```ruby
status2 = Status2::PENDING
```

