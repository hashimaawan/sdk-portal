
# Calculation Statistics

Contains statistics for a notebook calculation.

## Structure

`CalculationStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpuExecutionInMillis` | `number \| undefined` | Optional | - |
| `progress` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { CalculationStatistics } from 'amazon-athenalib';

const calculationStatistics: CalculationStatistics = {
  dpuExecutionInMillis: 248,
  progress: 'Progress8',
};
```

