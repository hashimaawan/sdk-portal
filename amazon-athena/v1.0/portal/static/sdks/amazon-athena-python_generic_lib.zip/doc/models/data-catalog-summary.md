
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalog_name` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `mtype` | [`DataCatalogType2Enum`](../../doc/models/data-catalog-type-2-enum.md) | Optional | - |

## Example

```python
from amazonathena.models.data_catalog_summary import DataCatalogSummary
from amazonathena.models.data_catalog_type_2_enum import DataCatalogType2Enum

data_catalog_summary = DataCatalogSummary(
    catalog_name='CatalogName4',
    mtype=DataCatalogType2Enum.HIVE
)
```

