
# Cpu Type Enum

Type of cpu

## Enumeration

`CpuTypeEnum`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```ruby
cpu_type = CpuTypeEnum::SHARED
```

