
# Apply To

## Structure

`ApplyTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label_selector` | [`LabelSelector1`](../../doc/models/label-selector-1.md) | Optional | Configuration for type LabelSelector, required if type is `label_selector` |
| `server` | [`Server2`](../../doc/models/server-2.md) | Optional | Configuration for type Server, required if type is `server` |
| `type` | [`Type7Enum`](../../doc/models/type-7-enum.md) | Required | Type of the resource |

## Example

```ruby
apply_to = ApplyTo.new(
  Type7Enum::SERVER,
  LabelSelector1.new(
    'selector8'
  ),
  Server2.new(
    14
  )
)
```

