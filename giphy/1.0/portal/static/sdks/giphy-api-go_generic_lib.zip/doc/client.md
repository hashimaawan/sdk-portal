
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| customQueryAuthenticationCredentials | [`CustomQueryAuthenticationCredentials`](auth/custom-query-parameter.md) | The Credentials Setter for Custom Query Parameter |

The API client can be initialized as follows:

```go
package main

import (
    "giphyapi"
)

func main() {
    client := giphyapi.NewClient(
    giphyapi.CreateConfiguration(
            giphyapi.WithHttpConfiguration(
                giphyapi.CreateHttpConfiguration(
                    giphyapi.WithTimeout(0),
                ),
            ),
            giphyapi.WithCustomQueryAuthenticationCredentials(
                giphyapi.NewCustomQueryAuthenticationCredentials("api_key"),
            ),
        ),
    )
}
```

## Giphy API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| GifsController() | Gets GifsController |
| StickersController() | Gets StickersController |

