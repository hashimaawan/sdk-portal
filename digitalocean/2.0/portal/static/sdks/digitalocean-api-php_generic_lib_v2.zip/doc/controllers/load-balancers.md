# Load Balancers

```php
$loadBalancersApi = $client->getLoadBalancersApi();
```

## Class Name

`LoadBalancersApi`

## Methods

* [Load Balancers List](../../doc/controllers/load-balancers.md#load-balancers-list)
* [Load Balancers Create](../../doc/controllers/load-balancers.md#load-balancers-create)
* [Load Balancers Delete](../../doc/controllers/load-balancers.md#load-balancers-delete)
* [Load Balancers Get](../../doc/controllers/load-balancers.md#load-balancers-get)
* [Load Balancers Update](../../doc/controllers/load-balancers.md#load-balancers-update)
* [Load Balancers Remove Droplets](../../doc/controllers/load-balancers.md#load-balancers-remove-droplets)
* [Load Balancers Add Droplets](../../doc/controllers/load-balancers.md#load-balancers-add-droplets)
* [Load Balancers Remove Forwarding Rules](../../doc/controllers/load-balancers.md#load-balancers-remove-forwarding-rules)
* [Load Balancers Add Forwarding Rules](../../doc/controllers/load-balancers.md#load-balancers-add-forwarding-rules)


# Load Balancers List

To list all of the load balancer instances on your account, send a GET request
to `/v2/load_balancers`.

```php
function loadBalancersList(?int $perPage = 20, ?int $page = 1): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: A JSON object with a key of `load_balancers`. This will be set to an array of objects, each of which will contain the standard load balancer attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2LoadBalancersResponse`](../../doc/models/v2-load-balancers-response.md).

## Example Usage

```php
$perPage = 2;

$page = 1;

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersList(
    $perPage,
    $page
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2LoadBalancersResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "links": {},
  "load_balancers": [
    {
      "algorithm": "round_robin",
      "created_at": "2017-02-01T22:22:58Z",
      "disable_lets_encrypt_dns_records": false,
      "droplet_ids": [
        3164444,
        3164445
      ],
      "enable_backend_keepalive": false,
      "enable_proxy_protocol": false,
      "firewall": {
        "allow": [
          "ip:1.2.3.4",
          "cidr:2.3.4.0/24"
        ],
        "deny": [
          "cidr:1.2.0.0/16",
          "ip:2.3.4.5"
        ]
      },
      "forwarding_rules": [
        {
          "certificate_id": "",
          "entry_port": 80,
          "entry_protocol": "http",
          "target_port": 80,
          "target_protocol": "http",
          "tls_passthrough": false
        },
        {
          "certificate_id": "",
          "entry_port": 443,
          "entry_protocol": "https",
          "target_port": 443,
          "target_protocol": "https",
          "tls_passthrough": true
        }
      ],
      "health_check": {
        "check_interval_seconds": 10,
        "healthy_threshold": 5,
        "path": "/",
        "port": 80,
        "protocol": "http",
        "response_timeout_seconds": 5,
        "unhealthy_threshold": 3
      },
      "id": "4de7ac8b-495b-4884-9a69-1050c6793cd6",
      "ip": "104.131.186.241",
      "name": "example-lb-01",
      "redirect_http_to_https": false,
      "region": {
        "available": true,
        "features": [
          "private_networking",
          "backups",
          "ipv6",
          "metadata",
          "install_agent"
        ],
        "name": "New York 3",
        "sizes": [
          "s-1vcpu-1gb",
          "s-1vcpu-2gb",
          "s-1vcpu-3gb",
          "s-2vcpu-2gb",
          "s-3vcpu-1gb",
          "s-2vcpu-4gb",
          "s-4vcpu-8gb",
          "s-6vcpu-16gb",
          "s-8vcpu-32gb",
          "s-12vcpu-48gb",
          "s-16vcpu-64gb",
          "s-20vcpu-96gb",
          "s-24vcpu-128gb",
          "s-32vcpu-192gb"
        ],
        "slug": "nyc3"
      },
      "size": "lb-small",
      "status": "new",
      "sticky_sessions": {
        "type": "none"
      },
      "tag": "",
      "vpc_uuid": "c33931f2-a26a-4e61-b85c-4e95a2ec431b"
    },
    {
      "algorithm": "round_robin",
      "created_at": "2020-09-08T18:58:04Z",
      "disable_lets_encrypt_dns_records": false,
      "droplet_ids": [
        55806512,
        55806515,
        55806524
      ],
      "enable_backend_keepalive": false,
      "enable_proxy_protocol": false,
      "firewall": {
        "allow": [
          "ip:1.2.3.4",
          "cidr:2.3.4.0/24"
        ],
        "deny": [
          "cidr:1.2.0.0/16",
          "ip:2.3.4.5"
        ]
      },
      "forwarding_rules": [
        {
          "certificate_id": "892071a0-bb95-49bc-8021-3afd67a210bf",
          "entry_port": 443,
          "entry_protocol": "https",
          "target_port": 8080,
          "target_protocol": "http",
          "tls_passthrough": false
        }
      ],
      "health_check": {
        "check_interval_seconds": 10,
        "healthy_threshold": 5,
        "path": "/",
        "port": 443,
        "protocol": "https",
        "response_timeout_seconds": 5,
        "unhealthy_threshold": 3
      },
      "http_idle_timeout_seconds": 60,
      "id": "56775c3f-04ab-4fb3-a7ed-40ef9bc8eece",
      "ip": "45.55.125.24",
      "name": "prod-web-lb-01",
      "project_id": "9cc10173-e9ea-4176-9dbc-a4cee4c4ff30",
      "redirect_http_to_https": true,
      "region": {
        "available": true,
        "features": [
          "private_networking",
          "backups",
          "ipv6",
          "metadata",
          "install_agent"
        ],
        "name": "New York 3",
        "sizes": [
          "s-1vcpu-1gb",
          "s-1vcpu-2gb",
          "s-1vcpu-3gb",
          "s-2vcpu-2gb",
          "s-3vcpu-1gb",
          "s-2vcpu-4gb",
          "s-4vcpu-8gb",
          "s-6vcpu-16gb",
          "s-8vcpu-32gb",
          "s-12vcpu-48gb",
          "s-16vcpu-64gb",
          "s-20vcpu-96gb",
          "s-24vcpu-128gb",
          "s-32vcpu-192gb"
        ],
        "slug": "nyc3"
      },
      "size": "lb-small",
      "status": "active",
      "sticky_sessions": {
        "cookie_name": "DO-LB",
        "cookie_ttl_seconds": 300,
        "type": "cookies"
      },
      "tag": "prod:web",
      "vpc_uuid": "587d698c-de84-11e8-80bc-3cfdfea9fcd1"
    }
  ],
  "meta": {
    "total": 2
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Load Balancers Create

To create a new load balancer instance, send a POST request to
`/v2/load_balancers`.

You can specify the Droplets that will sit behind the load balancer using one
of two methods:

* Set `droplet_ids` to a list of specific Droplet IDs.
* Set `tag` to the name of a tag. All Droplets with this tag applied will be
  assigned to the load balancer. Additional Droplets will be automatically
  assigned as they are tagged.

These methods are mutually exclusive.

```php
function loadBalancersCreate($body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [AssignDropletsById](../../doc/models/assign-droplets-by-id.md)\|[AssignDropletsByTag](../../doc/models/assign-droplets-by-tag.md) | Body, Required | This is a container for one-of cases. |

## Response Type

**202**: Accepted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2LoadBalancersResponse1`](../../doc/models/v2-load-balancers-response-1.md).

## Example Usage

```php
$body = AssignDropletsByIdBuilder::init(
    [
        3164444,
        3164445
    ],
    Region2::NYC3,
    [
        ForwardingRuleBuilder::init(
            80,
            EntryProtocol::HTTP,
            80,
            TargetProtocol::HTTP
        )->build(),
        ForwardingRuleBuilder::init(
            443,
            EntryProtocol::HTTPS,
            443,
            TargetProtocol::HTTPS
        )
            ->tlsPassthrough(true)
            ->build()
    ]
)
    ->firewall(
        Firewall1Builder::init()
            ->allow(
                [
                    'ip:1.2.3.4',
                    'cidr:2.3.4.0/24'
                ]
            )
            ->deny(
                [
                    'cidr:1.2.0.0/16',
                    'ip:2.3.4.5'
                ]
            )
            ->build()
    )
    ->httpIdleTimeoutSeconds(60)
    ->name('example-lb-01')
    ->projectId('9cc10173-e9ea-4176-9dbc-a4cee4c4ff30')
    ->build();

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersCreate($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2LoadBalancersResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "load_balancer": {
    "algorithm": "round_robin",
    "created_at": "2017-02-01T22:22:58Z",
    "disable_lets_encrypt_dns_records": false,
    "droplet_ids": [
      3164444,
      3164445
    ],
    "enable_backend_keepalive": false,
    "enable_proxy_protocol": false,
    "firewall": {
      "allow": [
        "ip:1.2.3.4",
        "cidr:2.3.4.0/24"
      ],
      "deny": [
        "cidr:1.2.0.0/16",
        "ip:2.3.4.5"
      ]
    },
    "forwarding_rules": [
      {
        "certificate_id": "",
        "entry_port": 80,
        "entry_protocol": "http",
        "target_port": 80,
        "target_protocol": "http",
        "tls_passthrough": false
      },
      {
        "certificate_id": "",
        "entry_port": 443,
        "entry_protocol": "https",
        "target_port": 443,
        "target_protocol": "https",
        "tls_passthrough": true
      }
    ],
    "health_check": {
      "check_interval_seconds": 10,
      "healthy_threshold": 5,
      "path": "/",
      "port": 80,
      "protocol": "http",
      "response_timeout_seconds": 5,
      "unhealthy_threshold": 3
    },
    "http_idle_timeout_seconds": 60,
    "id": "4de7ac8b-495b-4884-9a69-1050c6793cd6",
    "ip": "104.131.186.241",
    "name": "example-lb-01",
    "project_id": "9cc10173-e9ea-4176-9dbc-a4cee4c4ff30",
    "redirect_http_to_https": false,
    "region": {
      "available": true,
      "features": [
        "private_networking",
        "backups",
        "ipv6",
        "metadata",
        "install_agent"
      ],
      "name": "New York 3",
      "sizes": [
        "s-1vcpu-1gb",
        "s-1vcpu-2gb",
        "s-1vcpu-3gb",
        "s-2vcpu-2gb",
        "s-3vcpu-1gb",
        "s-2vcpu-4gb",
        "s-4vcpu-8gb",
        "s-6vcpu-16gb",
        "s-8vcpu-32gb",
        "s-12vcpu-48gb",
        "s-16vcpu-64gb",
        "s-20vcpu-96gb",
        "s-24vcpu-128gb",
        "s-32vcpu-192gb"
      ],
      "slug": "nyc3"
    },
    "size": "lb-small",
    "status": "new",
    "sticky_sessions": {
      "type": "none"
    },
    "tag": "",
    "vpc_uuid": "c33931f2-a26a-4e61-b85c-4e95a2ec431b"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Load Balancers Delete

To delete a load balancer instance, disassociating any Droplets assigned to it
and removing it from your account, send a DELETE request to
`/v2/load_balancers/$LOAD_BALANCER_ID`.

A successful request will receive a 204 status code with no body in response.
This indicates that the request was processed successfully.

```php
function loadBalancersDelete(string $lbId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lbId` | `string` | Template, Required | A unique identifier for a load balancer. |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$lbId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersDelete($lbId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Load Balancers Get

To show information about a load balancer instance, send a GET request to
`/v2/load_balancers/$LOAD_BALANCER_ID`.

```php
function loadBalancersGet(string $lbId): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lbId` | `string` | Template, Required | A unique identifier for a load balancer. |

## Response Type

**200**: The response will be a JSON object with a key called `load_balancer`. The
value of this will be an object that contains the standard attributes
associated with a load balancer

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2LoadBalancersResponse1`](../../doc/models/v2-load-balancers-response-1.md).

## Example Usage

```php
$lbId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersGet($lbId);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2LoadBalancersResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "load_balancer": {
    "algorithm": "round_robin",
    "created_at": "2017-02-01T22:22:58Z",
    "disable_lets_encrypt_dns_records": false,
    "droplet_ids": [
      3164444,
      3164445
    ],
    "enable_backend_keepalive": false,
    "enable_proxy_protocol": false,
    "firewall": {
      "allow": [
        "ip:1.2.3.4",
        "cidr:2.3.4.0/24"
      ],
      "deny": [
        "cidr:1.2.0.0/16",
        "ip:2.3.4.5"
      ]
    },
    "forwarding_rules": [
      {
        "certificate_id": "",
        "entry_port": 80,
        "entry_protocol": "http",
        "target_port": 80,
        "target_protocol": "http",
        "tls_passthrough": false
      },
      {
        "certificate_id": "",
        "entry_port": 443,
        "entry_protocol": "https",
        "target_port": 443,
        "target_protocol": "https",
        "tls_passthrough": true
      }
    ],
    "health_check": {
      "check_interval_seconds": 10,
      "healthy_threshold": 5,
      "path": "/",
      "port": 80,
      "protocol": "http",
      "response_timeout_seconds": 5,
      "unhealthy_threshold": 3
    },
    "http_idle_timeout_seconds": 60,
    "id": "4de7ac8b-495b-4884-9a69-1050c6793cd6",
    "ip": "104.131.186.241",
    "name": "example-lb-01",
    "project_id": "9cc10173-e9ea-4176-9dbc-a4cee4c4ff30",
    "redirect_http_to_https": false,
    "region": {
      "available": true,
      "features": [
        "private_networking",
        "backups",
        "ipv6",
        "metadata",
        "install_agent"
      ],
      "name": "New York 3",
      "sizes": [
        "s-1vcpu-1gb",
        "s-1vcpu-2gb",
        "s-1vcpu-3gb",
        "s-2vcpu-2gb",
        "s-3vcpu-1gb",
        "s-2vcpu-4gb",
        "s-4vcpu-8gb",
        "s-6vcpu-16gb",
        "s-8vcpu-32gb",
        "s-12vcpu-48gb",
        "s-16vcpu-64gb",
        "s-20vcpu-96gb",
        "s-24vcpu-128gb",
        "s-32vcpu-192gb"
      ],
      "slug": "nyc3"
    },
    "size": "lb-small",
    "status": "new",
    "sticky_sessions": {
      "type": "none"
    },
    "tag": "",
    "vpc_uuid": "c33931f2-a26a-4e61-b85c-4e95a2ec431b"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Load Balancers Update

To update a load balancer's settings, send a PUT request to
`/v2/load_balancers/$LOAD_BALANCER_ID`. The request should contain a full
representation of the load balancer including existing attributes. It may
contain _one of_ the `droplets_ids` or `tag` attributes as they are mutually
exclusive. **Note that any attribute that is not provided will be reset to its
default value.**

```php
function loadBalancersUpdate(string $lbId, $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lbId` | `string` | Template, Required | A unique identifier for a load balancer. |
| `body` | [AssignDropletsById](../../doc/models/assign-droplets-by-id.md)\|[AssignDropletsByTag](../../doc/models/assign-droplets-by-tag.md) | Body, Required | This is a container for one-of cases. |

## Response Type

**200**: The response will be a JSON object with a key called `load_balancer`. The
value of this will be an object containing the standard attributes of a
load balancer.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2LoadBalancersResponse1`](../../doc/models/v2-load-balancers-response-1.md).

## Example Usage

```php
$lbId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$body = AssignDropletsByIdBuilder::init(
    [
        3164444,
        3164445
    ],
    Region2::NYC3,
    [
        ForwardingRuleBuilder::init(
            80,
            EntryProtocol::HTTP,
            80,
            TargetProtocol::HTTP
        )
            ->certificateId('')
            ->tlsPassthrough(false)
            ->build(),
        ForwardingRuleBuilder::init(
            443,
            EntryProtocol::HTTPS,
            443,
            TargetProtocol::HTTPS
        )
            ->certificateId('')
            ->tlsPassthrough(true)
            ->build()
    ]
)
    ->algorithm(Algorithm::ROUND_ROBIN)
    ->enableBackendKeepalive(true)
    ->enableProxyProtocol(true)
    ->firewall(
        Firewall1Builder::init()
            ->allow(
                [
                    'ip:1.2.3.4',
                    'cidr:2.3.4.0/24'
                ]
            )
            ->deny(
                [
                    'cidr:1.2.0.0/16',
                    'ip:2.3.4.5'
                ]
            )
            ->build()
    )
    ->healthCheck(
        HealthCheck1Builder::init()
            ->checkIntervalSeconds(10)
            ->healthyThreshold(5)
            ->path('/')
            ->port(80)
            ->protocol(Protocol1::HTTP)
            ->responseTimeoutSeconds(5)
            ->unhealthyThreshold(3)
            ->build()
    )
    ->httpIdleTimeoutSeconds(60)
    ->name('updated-example-lb-01')
    ->projectId('9cc10173-e9ea-4176-9dbc-a4cee4c4ff30')
    ->redirectHttpToHttps(false)
    ->stickySessions(
        StickySessionsBuilder::init()
            ->type(Type16::NONE)
            ->build()
    )
    ->vpcUuid('c33931f2-a26a-4e61-b85c-4e95a2ec431b')
    ->build();

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersUpdate(
    $lbId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2LoadBalancersResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "load_balancer": {
    "algorithm": "round_robin",
    "created_at": "2017-02-01T22:22:58Z",
    "disable_lets_encrypt_dns_records": false,
    "droplet_ids": [
      3164444,
      3164445
    ],
    "enable_backend_keepalive": true,
    "enable_proxy_protocol": true,
    "firewall": {
      "allow": [
        "ip:1.2.3.4",
        "cidr:2.3.4.0/24"
      ],
      "deny": [
        "cidr:1.2.0.0/16",
        "ip:2.3.4.5"
      ]
    },
    "forwarding_rules": [
      {
        "certificate_id": "",
        "entry_port": 80,
        "entry_protocol": "http",
        "target_port": 80,
        "target_protocol": "http",
        "tls_passthrough": false
      },
      {
        "certificate_id": "",
        "entry_port": 443,
        "entry_protocol": "https",
        "target_port": 443,
        "target_protocol": "https",
        "tls_passthrough": true
      }
    ],
    "health_check": {
      "check_interval_seconds": 10,
      "healthy_threshold": 5,
      "path": "/",
      "port": 80,
      "protocol": "http",
      "response_timeout_seconds": 5,
      "unhealthy_threshold": 3
    },
    "http_idle_timeout_seconds": 60,
    "id": "4de7ac8b-495b-4884-9a69-1050c6793cd6",
    "ip": "104.131.186.241",
    "name": "updated-example-lb-01",
    "project_id": "9cc10173-e9ea-4176-9dbc-a4cee4c4ff30",
    "redirect_http_to_https": false,
    "region": {
      "available": true,
      "features": [
        "private_networking",
        "backups",
        "ipv6",
        "metadata",
        "install_agent"
      ],
      "name": "New York 3",
      "sizes": [
        "s-1vcpu-1gb",
        "s-1vcpu-2gb",
        "s-1vcpu-3gb",
        "s-2vcpu-2gb",
        "s-3vcpu-1gb",
        "s-2vcpu-4gb",
        "s-4vcpu-8gb",
        "s-6vcpu-16gb",
        "s-8vcpu-32gb",
        "s-12vcpu-48gb",
        "s-16vcpu-64gb",
        "s-20vcpu-96gb",
        "s-24vcpu-128gb",
        "s-32vcpu-192gb"
      ],
      "slug": "nyc3"
    },
    "size": "lb-small",
    "status": "new",
    "sticky_sessions": {
      "type": "none"
    },
    "tag": "",
    "vpc_uuid": "c33931f2-a26a-4e61-b85c-4e95a2ec431b"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Load Balancers Remove Droplets

To remove a Droplet from a load balancer instance, send a DELETE request to
`/v2/load_balancers/$LOAD_BALANCER_ID/droplets`. In the body of the request,
there should be a `droplet_ids` attribute containing a list of Droplet IDs.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function loadBalancersRemoveDroplets(string $lbId, V2LoadBalancersDropletsRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lbId` | `string` | Template, Required | A unique identifier for a load balancer. |
| `body` | [`V2LoadBalancersDropletsRequest`](../../doc/models/v2-load-balancers-droplets-request.md) | Body, Required | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$lbId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$body = V2LoadBalancersDropletsRequestBuilder::init()
    ->dropletIds(
        [
            3164444,
            3164445
        ]
    )
    ->build();

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersRemoveDroplets(
    $lbId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Load Balancers Add Droplets

To assign a Droplet to a load balancer instance, send a POST request to
`/v2/load_balancers/$LOAD_BALANCER_ID/droplets`. In the body of the request,
there should be a `droplet_ids` attribute containing a list of Droplet IDs.
Individual Droplets can not be added to a load balancer configured with a
Droplet tag. Attempting to do so will result in a "422 Unprocessable Entity"
response from the API.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function loadBalancersAddDroplets(string $lbId, V2LoadBalancersDropletsRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lbId` | `string` | Template, Required | A unique identifier for a load balancer. |
| `body` | [`V2LoadBalancersDropletsRequest`](../../doc/models/v2-load-balancers-droplets-request.md) | Body, Required | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$lbId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$body = V2LoadBalancersDropletsRequestBuilder::init()
    ->dropletIds(
        [
            3164444,
            3164445
        ]
    )
    ->build();

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersAddDroplets(
    $lbId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Load Balancers Remove Forwarding Rules

To remove forwarding rules from a load balancer instance, send a DELETE
request to `/v2/load_balancers/$LOAD_BALANCER_ID/forwarding_rules`. In the
body of the request, there should be a `forwarding_rules` attribute containing
an array of rules to be removed.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function loadBalancersRemoveForwardingRules(
    string $lbId,
    V2LoadBalancersForwardingRulesRequest $body
): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lbId` | `string` | Template, Required | A unique identifier for a load balancer. |
| `body` | [`V2LoadBalancersForwardingRulesRequest`](../../doc/models/v2-load-balancers-forwarding-rules-request.md) | Body, Required | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$lbId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$body = V2LoadBalancersForwardingRulesRequestBuilder::init(
    [
        ForwardingRuleBuilder::init(
            443,
            EntryProtocol::HTTPS,
            80,
            TargetProtocol::HTTP
        )
            ->certificateId('892071a0-bb95-49bc-8021-3afd67a210bf')
            ->tlsPassthrough(false)
            ->build()
    ]
)->build();

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersRemoveForwardingRules(
    $lbId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Load Balancers Add Forwarding Rules

To add an additional forwarding rule to a load balancer instance, send a POST
request to `/v2/load_balancers/$LOAD_BALANCER_ID/forwarding_rules`. In the body
of the request, there should be a `forwarding_rules` attribute containing an
array of rules to be added.

No response body will be sent back, but the response code will indicate
success. Specifically, the response code will be a 204, which means that the
action was successful with no returned body data.

```php
function loadBalancersAddForwardingRules(string $lbId, V2LoadBalancersForwardingRulesRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lbId` | `string` | Template, Required | A unique identifier for a load balancer. |
| `body` | [`V2LoadBalancersForwardingRulesRequest`](../../doc/models/v2-load-balancers-forwarding-rules-request.md) | Body, Required | - |

## Response Type

**204**: The action was successful and the response body is empty.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$lbId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$body = V2LoadBalancersForwardingRulesRequestBuilder::init(
    [
        ForwardingRuleBuilder::init(
            443,
            EntryProtocol::HTTPS,
            80,
            TargetProtocol::HTTP
        )
            ->certificateId('892071a0-bb95-49bc-8021-3afd67a210bf')
            ->tlsPassthrough(false)
            ->build()
    ]
)->build();

$loadBalancersApi = $client->getLoadBalancersApi();
$apiResponse = $loadBalancersApi->loadBalancersAddForwardingRules(
    $lbId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

