
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Type` | [`*models.DataCatalogType2Enum`](../../doc/models/data-catalog-type-2-enum.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    dataCatalogSummary := models.DataCatalogSummary{
        CatalogName:          models.ToPointer("CatalogName2"),
        Type:                 models.ToPointer(models.DataCatalogType2Enum_HIVE),
    }

}
```

