
# Datacenter 6

Datacenter this Resource is located at

## Structure

`Datacenter6`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `description` | `string` | Required | Description of the Datacenter | getDescription(): string | setDescription(string description): void |
| `id` | `int` | Required | ID of the Resource | getId(): int | setId(int id): void |
| `location` | [`Location`](../../doc/models/location.md) | Required | - | getLocation(): Location | setLocation(Location location): void |
| `name` | `string` | Required | Unique identifier of the Datacenter | getName(): string | setName(string name): void |
| `serverTypes` | [`ServerTypes`](../../doc/models/server-types.md) | Required | The Server types the Datacenter can handle | getServerTypes(): ServerTypes | setServerTypes(ServerTypes serverTypes): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\Datacenter6Builder;
use HetznerCloudAPILib\Models\Builders\LocationBuilder;
use HetznerCloudAPILib\Models\Builders\ServerTypesBuilder;

$datacenter6 = Datacenter6Builder::init(
    'Falkenstein DC Park 8',
    42,
    LocationBuilder::init(
        'Falkenstein',
        'DE',
        'Falkenstein DC Park 1',
        1,
        50.47612,
        12.370071,
        'fsn1',
        'eu-central'
    )->build(),
    'fsn1-dc8',
    ServerTypesBuilder::init(
        [
            1,
            2,
            3
        ],
        [
            1,
            2,
            3
        ],
        [
            1,
            2,
            3
        ]
    )->build()
)->build();
```

