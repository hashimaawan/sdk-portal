
# Work Group Summary

The summary information for the workgroup, which includes its name, state, description, and the date and time it was created.

*This model accepts additional fields of type interface{}.*

## Structure

`WorkGroupSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `*string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `State` | [`*models.WorkGroupState1`](../../doc/models/work-group-state-1.md) | Optional | - |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `CreationTime` | `*time.Time` | Optional | - |
| `EngineVersion` | [`*models.EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonAthena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    workGroupSummary := models.WorkGroupSummary{
        Name:                  models.ToPointer("Name4"),
        State:                 models.ToPointer(models.WorkGroupState1_Enabled),
        Description:           models.ToPointer("Description8"),
        CreationTime:          models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
        EngineVersion:         models.ToPointer(models.EngineVersion1{
            SelectedEngineVersion:  models.ToPointer("SelectedEngineVersion4"),
            EffectiveEngineVersion: models.ToPointer("EffectiveEngineVersion6"),
            AdditionalProperties:   map[string]interface{}{
                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
            },
        }),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

