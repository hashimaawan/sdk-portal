
# V2 Kubernetes Clusters Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kubernetes_clusters` | [`List[KubernetesCluster]`](../../doc/models/kubernetes-cluster.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.kubernetes_cluster import KubernetesCluster
from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.node_pool import NodePool
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.v_2_kubernetes_clusters_response import V2KubernetesClustersResponse

v_2_kubernetes_clusters_response = V2KubernetesClustersResponse(
    meta=Meta(
        total=1,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    kubernetes_clusters=[
        KubernetesCluster(
            name='name2',
            node_pools=[
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            region='region8',
            version='version8',
            auto_upgrade=False,
            cluster_subnet='cluster_subnet4',
            created_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            endpoint='endpoint0',
            ha=False,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        KubernetesCluster(
            name='name2',
            node_pools=[
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            region='region8',
            version='version8',
            auto_upgrade=False,
            cluster_subnet='cluster_subnet4',
            created_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            endpoint='endpoint0',
            ha=False,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        KubernetesCluster(
            name='name2',
            node_pools=[
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                NodePool(
                    size='size6',
                    count=206,
                    name='name4',
                    auto_scale=False,
                    id='000013be-0000-0000-0000-000000000000',
                    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
                    max_nodes=118,
                    min_nodes=54,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            region='region8',
            version='version8',
            auto_upgrade=False,
            cluster_subnet='cluster_subnet4',
            created_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            endpoint='endpoint0',
            ha=False,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    links=Links(
        pages=Pages(
            last='last6',
            next='next2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

