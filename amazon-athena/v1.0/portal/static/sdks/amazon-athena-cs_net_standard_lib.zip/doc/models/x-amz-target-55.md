
# X Amz Target 55

## Enumeration

`XAmzTarget55`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNamedQuery` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget55 xAmzTarget55 = XAmzTarget55.EnumAmazonAthenaUpdateNamedQuery;
```

