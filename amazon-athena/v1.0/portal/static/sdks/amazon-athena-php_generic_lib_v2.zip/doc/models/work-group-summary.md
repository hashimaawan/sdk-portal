
# Work Group Summary

The summary information for the workgroup, which includes its name, state, description, and the date and time it was created.

## Structure

`WorkGroupSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getName(): ?string | setName(?string name): void |
| `state` | [`?string(WorkGroupState1Enum)`](../../doc/models/work-group-state-1-enum.md) | Optional | - | getState(): ?string | setState(?string state): void |
| `description` | `?string` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` | getDescription(): ?string | setDescription(?string description): void |
| `creationTime` | `?DateTime` | Optional | - | getCreationTime(): ?\DateTime | setCreationTime(?\DateTime creationTime): void |
| `engineVersion` | [`?EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - | getEngineVersion(): ?EngineVersion1 | setEngineVersion(?EngineVersion1 engineVersion): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\WorkGroupSummaryBuilder;
use AmazonAthenaLib\Models\WorkGroupState1Enum;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\Models\Builders\EngineVersion1Builder;

$workGroupSummary = WorkGroupSummaryBuilder::init()
    ->name('Name4')
    ->state(WorkGroupState1Enum::ENABLED)
    ->description('Description8')
    ->creationTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->engineVersion(
        EngineVersion1Builder::init()
            ->selectedEngineVersion('SelectedEngineVersion4')
            ->effectiveEngineVersion('EffectiveEngineVersion6')
            ->build()
    )
    ->build();
```

