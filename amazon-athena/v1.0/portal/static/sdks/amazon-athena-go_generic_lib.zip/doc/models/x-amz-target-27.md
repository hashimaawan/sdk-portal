
# X Amz Target 27

## Enumeration

`XAmzTarget27`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetsessionstatus` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget27 := models.XAmzTarget27_EnumAmazonathenagetsessionstatus

}
```

