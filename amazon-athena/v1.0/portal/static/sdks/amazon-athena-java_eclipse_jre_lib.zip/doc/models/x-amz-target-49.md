
# X Amz Target 49

## Enumeration

`XAmzTarget49`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget49;

XAmzTarget49 xAmzTarget49 = XAmzTarget49.ENUM_AMAZONATHENASTOPCALCULATIONEXECUTION;
```

