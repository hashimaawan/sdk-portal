
# Many Chapters

*This model accepts additional fields of type object.*

## Structure

`ManyChapters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Chapters` | [`List<ChapterObject>`](../../doc/models/chapter-object.md) | Required | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Utilities;
using System.Collections.Generic;

ManyChapters manyChapters = new ManyChapters
{
    Chapters = new List<ChapterObject>
    {
        new ChapterObject
        {
            AudioPreviewUrl = "https://p.scdn.co/mp3-preview/2f37da1d4221f40b9d1a98cd191f4d6f1646ad17",
            ChapterNumber = 1,
            Description = "We kept on ascending, with occasional periods of quick descent, but in the main always ascending. Suddenly, I became conscious of the fact that the driver was in the act of pulling up the horses in the courtyard of a vast ruined castle, from whose tall black windows came no ray of light, and whose broken battlements showed a jagged line against the moonlit sky.\n",
            HtmlDescription = "<p>We kept on ascending, with occasional periods of quick descent, but in the main always ascending. Suddenly, I became conscious of the fact that the driver was in the act of pulling up the horses in the courtyard of a vast ruined castle, from whose tall black windows came no ray of light, and whose broken battlements showed a jagged line against the moonlit sky.</p>\n",
            DurationMs = 1686230,
            MExplicit = false,
            ExternalUrls = new ExternalUrlObject
            {
                Spotify = "spotify6",
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
            Href = "https://api.spotify.com/v1/episodes/5Xt5DXGzch68nYYamXrNxZ",
            Id = "5Xt5DXGzch68nYYamXrNxZ",
            Images = new List<ImageObject>
            {
                new ImageObject
                {
                    Url = "https://i.scdn.co/image/ab67616d00001e02ff9ca10b55ce82ae553c8228\n",
                    Height = 300,
                    Width = 300,
                    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                },
            },
            IsPlayable = false,
            Languages = new List<string>
            {
                "fr",
                "en",
            },
            Name = "Starting Your Own Podcast: Tips, Tricks, and Advice From Anchor Creators\n",
            ReleaseDate = "1981-12-15",
            ReleaseDatePrecision = ReleaseDatePrecision.Day,
            Type = "episode",
            Uri = "spotify:episode:0zLhl3WsOCQHbe1BPTiHgr",
            Audiobook = new AudiobookBase
            {
                Authors = new List<AuthorObject>
                {
                    new AuthorObject
                    {
                        Name = "name0",
                        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    },
                },
                AvailableMarkets = new List<string>
                {
                    "available_markets2",
                    "available_markets3",
                    "available_markets4",
                },
                Copyrights = new List<CopyrightObject>
                {
                    new CopyrightObject
                    {
                        Text = "text2",
                        Type = "type2",
                        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    },
                },
                Description = "description2",
                HtmlDescription = "html_description2",
                MExplicit = false,
                ExternalUrls = new ExternalUrlObject
                {
                    Spotify = "spotify6",
                    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                },
                Href = "href0",
                Id = "id8",
                Images = new List<ImageObject>
                {
                    new ImageObject
                    {
                        Url = "https://i.scdn.co/image/ab67616d00001e02ff9ca10b55ce82ae553c8228\n",
                        Height = 300,
                        Width = 300,
                        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    },
                },
                Languages = new List<string>
                {
                    "languages3",
                    "languages4",
                },
                MediaType = "media_type4",
                Name = "name8",
                Narrators = new List<NarratorObject>
                {
                    new NarratorObject
                    {
                        Name = "name0",
                        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    },
                },
                Publisher = "publisher4",
                Type = "audiobook",
                Uri = "uri2",
                TotalChapters = 186,
                Edition = "Unabridged",
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
            AvailableMarkets = new List<string>
            {
                "available_markets6",
                "available_markets7",
            },
            ResumePoint = new ResumePointObject
            {
                FullyPlayed = false,
                ResumePositionMs = 254,
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
            Restrictions = new ChapterRestrictionObject
            {
                Reason = "reason0",
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

