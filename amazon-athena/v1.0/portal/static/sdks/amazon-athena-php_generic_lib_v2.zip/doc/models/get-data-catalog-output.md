
# Get Data Catalog Output

*This model accepts additional fields of type array.*

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dataCatalog` | [`?DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - | getDataCatalog(): ?DataCatalog2 | setDataCatalog(?DataCatalog2 dataCatalog): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetDataCatalogOutputBuilder;
use AmazonAthenaLib\Models\Builders\DataCatalog2Builder;
use AmazonAthenaLib\Models\DataCatalogType1;
use AmazonAthenaLib\Models\Builders\ParametersBuilder;
use AmazonAthenaLib\ApiHelper;

$getDataCatalogOutput = GetDataCatalogOutputBuilder::init()
    ->dataCatalog(
        DataCatalog2Builder::init(
            'Name4',
            DataCatalogType1::GLUE
        )
            ->description('Description2')
            ->parameters(
                ParametersBuilder::init()
                    ->additionalProperty('exampleAdditionalProperty', 'Parameters_additionalProperties2')
                    ->build()
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

