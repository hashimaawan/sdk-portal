
# Type 17

Floating IP type

## Enumeration

`Type17`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type17 type17 = Type17.Ipv4;
```

