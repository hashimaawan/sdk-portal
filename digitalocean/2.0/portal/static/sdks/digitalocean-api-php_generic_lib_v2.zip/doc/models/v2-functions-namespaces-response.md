
# V2 Functions Namespaces Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `namespaces` | [`?(MNamespace[])`](../../doc/models/m-namespace.md) | Optional | - | getNamespaces(): ?array | setNamespaces(?array namespaces): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FunctionsNamespacesResponseBuilder;
use DigitalOceanApiLib\Models\Builders\MNamespaceBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2FunctionsNamespacesResponse = V2FunctionsNamespacesResponseBuilder::init()
    ->namespaces(
        [
            MNamespaceBuilder::init()
                ->apiHost('api_host8')
                ->createdAt('created_at0')
                ->key('key2')
                ->label('label2')
                ->namespace('namespace0')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build(),
            MNamespaceBuilder::init()
                ->apiHost('api_host8')
                ->createdAt('created_at0')
                ->key('key2')
                ->label('label2')
                ->namespace('namespace0')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

