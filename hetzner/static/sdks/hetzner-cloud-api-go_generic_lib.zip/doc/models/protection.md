
# Protection

Protection configuration for the Resource

## Structure

`Protection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool` | Required | If true, prevents the Resource from being deleted |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    protection := models.Protection{
        Delete:               false,
    }

}
```

