
# X Amz Target 3 Enum

## Enumeration

`XAmzTarget3Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEDATACATALOG` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget3Enum;

XAmzTarget3Enum xAmzTarget3 = XAmzTarget3Enum.ENUM_AMAZONATHENACREATEDATACATALOG;
```

