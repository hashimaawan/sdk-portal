
# Session Statistics

Contains statistics for a session.

*This model accepts additional fields of type interface{}.*

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DpuExecutionInMillis` | `*int` | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    sessionStatistics := models.SessionStatistics{
        DpuExecutionInMillis:  models.ToPointer(188),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

