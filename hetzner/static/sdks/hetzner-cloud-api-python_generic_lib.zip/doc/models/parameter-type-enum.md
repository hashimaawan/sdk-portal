
# Parameter Type Enum

## Enumeration

`ParameterTypeEnum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```python
from hetznercloudapi.models.parameter_type_enum import ParameterTypeEnum

parameter_type = ParameterTypeEnum.UPLOADED
```

