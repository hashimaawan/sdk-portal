
# Servers Actions Change Dns Ptr Request

## Structure

`ServersActionsChangeDnsPtrRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DnsPtr` | `String` | Required | Hostname to set as a reverse DNS PTR entry, reset to original value if `null` | String getDnsPtr() | setDnsPtr(String dnsPtr) |
| `Ip` | `String` | Required | Primary IP address for which the reverse DNS entry should be set | String getIp() | setIp(String ip) |

## Example

```java
import cloud.hetzner.api.models.ServersActionsChangeDnsPtrRequest;

ServersActionsChangeDnsPtrRequest serversActionsChangeDnsPtrRequest = new ServersActionsChangeDnsPtrRequest.Builder(
    "server01.example.com",
    "1.2.3.4"
)
.build();
```

