
# X Amz Target 51 Enum

## Enumeration

`XAmzTarget51Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENATAGRESOURCE` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget51 := models.XAmzTarget51Enum_ENUMAMAZONATHENATAGRESOURCE

}
```

