
# Default Toast Compression

Specifies the default TOAST compression method for values of compressible columns (the default is lz4).

## Enumeration

`DefaultToastCompression`

## Fields

| Name |
|  --- |
| `Lz4` |
| `Pglz` |

## Example

```ts
import { DefaultToastCompression } from 'digitalocean-apilib';

const defaultToastCompression = DefaultToastCompression.Lz4;
```

