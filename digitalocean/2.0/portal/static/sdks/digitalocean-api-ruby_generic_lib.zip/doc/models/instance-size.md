
# Instance Size

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`InstanceSize`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cpu_type` | [`MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores`](../../doc/models/m-shared-shared-vcpu-cores-dedicated-dedicated-vcpu-cores.md) | Optional | **Default**: `MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores::UNSPECIFIED` |
| `cpus` | `String` | Optional | - |
| `memory_bytes` | `String` | Optional | - |
| `name` | `String` | Optional | - |
| `slug` | `String` | Optional | - |
| `tier_downgrade_to` | `String` | Optional | - |
| `tier_slug` | `String` | Optional | - |
| `tier_upgrade_to` | `String` | Optional | - |
| `usd_per_month` | `String` | Optional | - |
| `usd_per_second` | `String` | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
instance_size = InstanceSize.new(
  cpu_type: MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores::SHARED,
  cpus: '3',
  memory_bytes: '1048',
  name: 'name',
  slug: 'basic',
  tier_downgrade_to: 'basic',
  tier_slug: 'basic',
  tier_upgrade_to: 'basic',
  usd_per_month: '23',
  usd_per_second: '0.00000001232',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

