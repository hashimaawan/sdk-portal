
# Result Configuration

The location in Amazon S3 where query and calculation results are stored and the encryption option, if any, used for query and calculation results. These are known as "client-side settings". If workgroup settings override client-side settings, then the query uses the workgroup settings.

*This model accepts additional fields of type array.*

## Structure

`ResultConfiguration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `outputLocation` | `?string` | Optional | - | getOutputLocation(): ?string | setOutputLocation(?string outputLocation): void |
| `encryptionConfiguration` | [`?EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - | getEncryptionConfiguration(): ?EncryptionConfiguration2 | setEncryptionConfiguration(?EncryptionConfiguration2 encryptionConfiguration): void |
| `expectedBucketOwner` | `?string` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` | getExpectedBucketOwner(): ?string | setExpectedBucketOwner(?string expectedBucketOwner): void |
| `aclConfiguration` | [`?AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - | getAclConfiguration(): ?AclConfiguration1 | setAclConfiguration(?AclConfiguration1 aclConfiguration): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultConfigurationBuilder;
use AmazonAthenaLib\Models\Builders\EncryptionConfiguration2Builder;
use AmazonAthenaLib\Models\EncryptionOption1;
use AmazonAthenaLib\ApiHelper;
use AmazonAthenaLib\Models\Builders\AclConfiguration1Builder;
use AmazonAthenaLib\Models\S3AclOption1;

$resultConfiguration = ResultConfigurationBuilder::init()
    ->outputLocation('OutputLocation4')
    ->encryptionConfiguration(
        EncryptionConfiguration2Builder::init(
            EncryptionOption1::SSE_S3
        )
            ->kmsKey('KmsKey6')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->expectedBucketOwner('ExpectedBucketOwner4')
    ->aclConfiguration(
        AclConfiguration1Builder::init(
            S3AclOption1::BUCKET_OWNER_FULL_CONTROL
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

