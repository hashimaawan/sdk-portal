
# Bad Request Exception

*This model accepts additional fields of type object.*

## Structure

`BadRequestException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`ErrorObject`](../../doc/models/error-object.md) | Required | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
try
{
    // make the API call
}
catch (ApiException e)
{
    if (e is BadRequestException)
    {
        // TODO: Handle BadRequestException
        Console.WriteLine(e.Message);
    }
}
```

