
# Coordinates

geographical coordinates of the stop

## Structure

`Coordinates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lat` | `number \| undefined` | Optional | latitude |
| `lon` | `number \| undefined` | Optional | longitude |

## Example

```ts
import { Coordinates } from 'furkot-tripslib';

const coordinates: Coordinates = {
  lat: 182.98,
  lon: 16.08,
};
```

