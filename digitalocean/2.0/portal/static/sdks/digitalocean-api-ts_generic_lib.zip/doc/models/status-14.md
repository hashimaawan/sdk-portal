
# Status 14

The status of assigning and fetching the resources.

## Enumeration

`Status14`

## Fields

| Name |
|  --- |
| `Ok` |
| `NotFound` |
| `Assigned` |
| `AlreadyAssigned` |
| `ServiceDown` |

## Example

```ts
import { Status14 } from 'digitalocean-apilib';

const status14 = Status14.NotFound;
```

