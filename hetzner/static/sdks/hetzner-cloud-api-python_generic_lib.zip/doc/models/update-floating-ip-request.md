
# Update Floating IP Request

## Structure

`UpdateFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Optional | New Description to set |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Optional | New unique name to set |

## Example

```python
import jsonpickle

from hetznercloudapi.models.update_floating_ip_request import UpdateFloatingIPRequest

update_floating_ip_request = UpdateFloatingIPRequest(
    description='Web Frontend',
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    name='Web Frontend'
)
```

