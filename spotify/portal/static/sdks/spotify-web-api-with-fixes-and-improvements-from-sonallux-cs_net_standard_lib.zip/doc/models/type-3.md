
# Type 3

The object type.

## Enumeration

`Type3`

## Fields

| Name |
|  --- |
| `User` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

Type3 type3 = Type3.User;
```

