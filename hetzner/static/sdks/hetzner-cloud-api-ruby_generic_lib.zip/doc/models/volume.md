
# Volume

The cost of Volume per GB/month

## Structure

`Volume`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price_per_gb_month` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - |

## Example

```ruby
volume = Volume.new(
  PricePerGbMonth.new(
    '1.1900000000000000',
    '1.0000000000'
  )
)
```

