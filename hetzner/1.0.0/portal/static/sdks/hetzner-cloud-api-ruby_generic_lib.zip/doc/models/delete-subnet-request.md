
# Delete Subnet Request

*This model accepts additional fields of type Object.*

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip_range` | `String` | Required | IP range of subnet to delete |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
delete_subnet_request = DeleteSubnetRequest.new(
  ip_range: '10.0.1.0/24',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

