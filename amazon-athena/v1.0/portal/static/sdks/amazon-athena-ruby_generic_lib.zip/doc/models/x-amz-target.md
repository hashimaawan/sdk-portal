
# X Amz Target

## Enumeration

`XAmzTarget`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```ruby
x_amz_target = XAmzTarget::ENUM_AMAZONATHENABATCHGETNAMEDQUERY
```

