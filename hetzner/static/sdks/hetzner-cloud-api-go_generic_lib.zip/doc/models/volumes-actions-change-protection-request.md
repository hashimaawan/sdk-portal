
# Volumes Actions Change Protection Request

## Structure

`VolumesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `*bool` | Optional | If true, prevents the Volume from being deleted |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    volumesActionsChangeProtectionRequest := models.VolumesActionsChangeProtectionRequest{
        Delete:               models.ToPointer(true),
    }

}
```

