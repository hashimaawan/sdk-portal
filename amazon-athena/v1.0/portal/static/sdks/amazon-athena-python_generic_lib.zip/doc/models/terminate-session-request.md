
# Terminate Session Request

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```python
from amazonathena.models.terminate_session_request import TerminateSessionRequest

terminate_session_request = TerminateSessionRequest(
    session_id='SessionId8'
)
```

