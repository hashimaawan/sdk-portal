
# Status 23 Enum

## Enumeration

`Status23Enum`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Status23Enum status23 = Status23Enum.Available;
```

