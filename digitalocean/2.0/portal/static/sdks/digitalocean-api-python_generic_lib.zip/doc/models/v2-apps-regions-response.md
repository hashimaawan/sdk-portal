
# V2 Apps Regions Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2AppsRegionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `regions` | [`List[GeographicalInformationAboutAnAppOrigin]`](../../doc/models/geographical-information-about-an-app-origin.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.geographical_information_about_an_app_origin import GeographicalInformationAboutAnAppOrigin
from digitaloceanapi.models.v_2_apps_regions_response import V2AppsRegionsResponse

v_2_apps_regions_response = V2AppsRegionsResponse(
    regions=[
        GeographicalInformationAboutAnAppOrigin(
            continent='continent2',
            data_centers=[
                'data_centers9'
            ],
            default=False,
            disabled=False,
            flag='flag4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        GeographicalInformationAboutAnAppOrigin(
            continent='continent2',
            data_centers=[
                'data_centers9'
            ],
            default=False,
            disabled=False,
            flag='flag4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

