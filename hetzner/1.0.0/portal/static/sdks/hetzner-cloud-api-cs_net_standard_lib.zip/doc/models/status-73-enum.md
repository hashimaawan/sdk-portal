
# Status 73 Enum

Status of the Server

## Enumeration

`Status73Enum`

## Fields

| Name |
|  --- |
| `Running` |
| `Initializing` |
| `Starting` |
| `Stopping` |
| `Off` |
| `Deleting` |
| `Migrating` |
| `Rebuilding` |
| `Unknown` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Status73Enum status73 = Status73Enum.Starting;
```

