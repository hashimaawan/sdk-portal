
# X Amz Target 46 Enum

## Enumeration

`XAmzTarget46Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```ruby
x_amz_target46 = XAmzTarget46Enum::ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION
```

