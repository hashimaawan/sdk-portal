
# Type

Type of the Certificate

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```php
use HetznerCloudApiLib\Models\Type;

$type = Type::UPLOADED;
```

