
# X Amz Target 48

## Enumeration

`XAmzTarget48`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTSESSION` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget48;

XAmzTarget48 xAmzTarget48 = XAmzTarget48.ENUM_AMAZONATHENASTARTSESSION;
```

