
# Type 21

The volume action to initiate.

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `Attach` |
| `Detach` |
| `Resize` |

## Example

```ts
import { Type21 } from 'digitalocean-apilib';

const type21 = Type21.Detach;
```

