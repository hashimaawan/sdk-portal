
# Notebook Type Enum

## Enumeration

`NotebookTypeEnum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```java
import com.amazonaws.useast1.athena.models.NotebookTypeEnum;

NotebookTypeEnum notebookType = NotebookTypeEnum.IPYNB;
```

