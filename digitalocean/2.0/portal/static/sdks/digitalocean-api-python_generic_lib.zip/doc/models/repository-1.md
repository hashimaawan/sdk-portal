
# Repository 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Repository1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `latest_manifest` | [`LatestManifest`](../../doc/models/latest-manifest.md) | Optional | - |
| `manifest_count` | `int` | Optional | The number of manifests in the repository. |
| `name` | `str` | Optional | The name of the repository. |
| `registry_name` | `str` | Optional | The name of the container registry. |
| `tag_count` | `int` | Optional | The number of tags in the repository. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.blob import Blob
from digitaloceanapi.models.latest_manifest import LatestManifest
from digitaloceanapi.models.repository_1 import Repository1

repository_1 = Repository1(
    latest_manifest=LatestManifest(
        blobs=[
            Blob(
                compressed_size_bytes=12,
                digest='digest2',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Blob(
                compressed_size_bytes=12,
                digest='digest2',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            Blob(
                compressed_size_bytes=12,
                digest='digest2',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            )
        ],
        compressed_size_bytes=154,
        digest='digest0',
        registry_name='registry_name4',
        repository='repository4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    manifest_count=1,
    name='repo-1',
    registry_name='example',
    tag_count=1,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

