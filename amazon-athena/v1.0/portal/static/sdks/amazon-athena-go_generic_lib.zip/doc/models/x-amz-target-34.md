
# X Amz Target 34

## Enumeration

`XAmzTarget34`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistdatabases` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget34 := models.XAmzTarget34_EnumAmazonathenalistdatabases

}
```

