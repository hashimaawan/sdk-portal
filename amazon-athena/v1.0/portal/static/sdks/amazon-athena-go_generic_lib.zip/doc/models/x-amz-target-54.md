
# X Amz Target 54

## Enumeration

`XAmzTarget54`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaupdatedatacatalog` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget54 := models.XAmzTarget54_EnumAmazonathenaupdatedatacatalog

}
```

