
# Price Hourly 6

Hourly costs for a Load Balancer type in this network zone

## Structure

`PriceHourly6`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Gross` | `String` | Required | Price with VAT added | String getGross() | setGross(String gross) |
| `Net` | `String` | Required | Price without VAT | String getNet() | setNet(String net) |

## Example

```java
import cloud.hetzner.api.models.PriceHourly6;

PriceHourly6 priceHourly6 = new PriceHourly6.Builder(
    "1.1900000000000000",
    "1.0000000000"
)
.build();
```

