
# Update Named Query Input

## Structure

`UpdateNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `QueryString` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    updateNamedQueryInput := models.UpdateNamedQueryInput{
        NamedQueryId:         "NamedQueryId8",
        Name:                 "Name4",
        Description:          models.ToPointer("Description2"),
        QueryString:          "QueryString6",
    }

}
```

