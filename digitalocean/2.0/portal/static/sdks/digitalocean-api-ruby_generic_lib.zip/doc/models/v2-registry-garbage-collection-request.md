
# V2 Registry Garbage Collection Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cancel` | `TrueClass \| FalseClass` | Optional | A boolean value indicating that the garbage collection should be cancelled. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_registry_garbage_collection_request = V2RegistryGarbageCollectionRequest.new(
  cancel: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

