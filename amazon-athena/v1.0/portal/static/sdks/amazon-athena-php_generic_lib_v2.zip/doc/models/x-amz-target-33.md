
# X Amz Target 33

## Enumeration

`XAmzTarget33`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATACATALOGS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget33;

$xAmzTarget33 = XAmzTarget33::ENUM_AMAZONATHENALISTDATACATALOGS;
```

