
# List Executors Request

## Structure

`ListExecutorsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `executorStateFilter` | [`ExecutorState1Enum \| undefined`](../../doc/models/executor-state-1-enum.md) | Optional | - |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```ts
import { ExecutorState1Enum, ListExecutorsRequest } from 'amazon-athenalib';

const listExecutorsRequest: ListExecutorsRequest = {
  sessionId: 'SessionId0',
  executorStateFilter: ExecutorState1Enum.CREATING,
  maxResults: 100,
  nextToken: 'NextToken8',
};
```

