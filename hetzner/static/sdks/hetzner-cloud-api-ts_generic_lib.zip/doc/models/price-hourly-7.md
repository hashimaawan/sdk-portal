
# Price Hourly 7

Hourly costs for a Primary IP type in this Location

## Structure

`PriceHourly7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `string` | Required | Price with VAT added |
| `net` | `string` | Required | Price without VAT |

## Example

```ts
import { PriceHourly7 } from 'hetzner-cloud-apilib';

const priceHourly7: PriceHourly7 = {
  gross: '1.1900000000000000',
  net: '1.0000000000',
};
```

