
# Status 2

Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates

## Structure

`Status2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`Error2`](../../doc/models/error-2.md) | Optional | If issuance or renewal reports `failed`, this property contains information about what happened |
| `Issuance` | [`IssuanceEnum?`](../../doc/models/issuance-enum.md) | Optional | Status of the issuance process of the Certificate |
| `Renewal` | [`RenewalEnum?`](../../doc/models/renewal-enum.md) | Optional | Status of the renewal process of the Certificate. |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Status2 status2 = new Status2
{
    Error = null,
    Issuance = IssuanceEnum.Completed,
    Renewal = RenewalEnum.Scheduled,
};
```

