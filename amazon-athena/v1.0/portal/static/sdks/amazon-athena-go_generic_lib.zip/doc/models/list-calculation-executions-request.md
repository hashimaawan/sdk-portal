
# List Calculation Executions Request

*This model accepts additional fields of type interface{}.*

## Structure

`ListCalculationExecutionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `StateFilter` | [`*models.CalculationExecutionState3`](../../doc/models/calculation-execution-state-3.md) | Optional | - |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `*string` | Optional | **Constraints**: *Maximum Length*: `2048` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    listCalculationExecutionsRequest := models.ListCalculationExecutionsRequest{
        SessionId:             "SessionId2",
        StateFilter:           models.ToPointer(models.CalculationExecutionState3_Queued),
        MaxResults:            models.ToPointer(100),
        NextToken:             models.ToPointer("NextToken0"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

