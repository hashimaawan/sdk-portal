
# Item Type 3

The ID type: either `artist` or `user`.

## Enumeration

`ItemType3`

## Fields

| Name |
|  --- |
| `ARTIST` |
| `USER` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.item_type_3 import ItemType3

item_type_3 = ItemType3.ARTIST
```

