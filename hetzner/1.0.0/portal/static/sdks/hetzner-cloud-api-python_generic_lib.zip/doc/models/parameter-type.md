
# Parameter Type

## Enumeration

`ParameterType`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```python
from hetznercloudapi.models.parameter_type import ParameterType

parameter_type = ParameterType.UPLOADED
```

