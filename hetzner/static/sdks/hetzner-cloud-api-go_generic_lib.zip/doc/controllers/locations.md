# Locations

Datacenters are organized by Locations. Datacenters in the same Location are connected with very low latency links.

```go
locationsController := client.LocationsController()
```

## Class Name

`LocationsController`

## Methods

* [Get All Locations](../../doc/controllers/locations.md#get-all-locations)
* [Get a Location](../../doc/controllers/locations.md#get-a-location)


# Get All Locations

Returns all Location objects.

```go
GetAllLocations(
    ctx context.Context,
    name *string) (
    models.ApiResponse[models.LocationsResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `*string` | Query, Optional | Can be used to filter Locations by their name. The response will only contain the Location matching the specified name. |

## Response Type

**200**: The `locations` key in the reply contains an array of Location objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.LocationsResponse](../../doc/models/locations-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := locationsController.GetAllLocations(ctx, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get a Location

Returns a specific Location object.

```go
GetALocation(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.LocationsResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Location |

## Response Type

**200**: The `location` key in the reply contains a Location object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.LocationsResponse1](../../doc/models/locations-response-1.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := locationsController.GetALocation(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

