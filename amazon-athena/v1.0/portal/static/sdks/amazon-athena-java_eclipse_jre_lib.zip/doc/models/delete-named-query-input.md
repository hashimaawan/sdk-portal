
# Delete Named Query Input

## Structure

`DeleteNamedQueryInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NamedQueryId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | String getNamedQueryId() | setNamedQueryId(String namedQueryId) |

## Example

```java
import com.amazonaws.useast1.athena.models.DeleteNamedQueryInput;

DeleteNamedQueryInput deleteNamedQueryInput = new DeleteNamedQueryInput.Builder(
    "NamedQueryId4"
)
.build();
```

