
# X Amz Target 20 Enum

## Enumeration

`XAmzTarget20Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETNAMEDQUERY` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget20 := models.XAmzTarget20Enum_ENUMAMAZONATHENAGETNAMEDQUERY

}
```

