
# Error

Error message for the Action if error occurred, otherwise null

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Required | Fixed machine readable code |
| `Message` | `string` | Required | Humanized error message |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Error error = new Error
{
    Code = "action_failed",
    Message = "Action failed",
};
```

