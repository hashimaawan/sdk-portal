
# Papertrail

Papertrail configuration.

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Papertrail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endpoint` | `String` | Required | Papertrail syslog endpoint. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
papertrail = Papertrail.new(
  endpoint: 'https://mypapertrailendpoint.com',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

