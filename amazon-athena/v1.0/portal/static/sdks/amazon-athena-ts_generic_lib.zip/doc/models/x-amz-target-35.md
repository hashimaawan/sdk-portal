
# X Amz Target 35

## Enumeration

`XAmzTarget35`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListEngineVersions` |

## Example

```ts
import { XAmzTarget35 } from 'amazon-athenalib';

const xAmzTarget35 = XAmzTarget35.EnumAmazonAthenaListEngineVersions;
```

