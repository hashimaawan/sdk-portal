
# Load Balancer Types Response 1

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancerTypesResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `LoadBalancerType` | [`LoadBalancerType`](../../doc/models/load-balancer-type.md) | Optional | - | LoadBalancerType getLoadBalancerType() | setLoadBalancerType(LoadBalancerType loadBalancerType) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.LoadBalancerType;
import cloud.hetzner.api.models.LoadBalancerTypesResponse1;
import cloud.hetzner.api.models.Price;
import cloud.hetzner.api.models.PriceHourly;
import cloud.hetzner.api.models.PriceMonthly;
import java.io.IOException;
import java.util.Arrays;

LoadBalancerTypesResponse1 loadBalancerTypesResponse1 = new LoadBalancerTypesResponse1.Builder()
    .loadBalancerType(new LoadBalancerType.Builder(
        "deprecated2",
        "description4",
        205.06D,
        211.64D,
        136.32D,
        199.18D,
        152.52D,
        "name6",
        Arrays.asList(
            new Price.Builder(
                "location8",
                new PriceHourly.Builder(
                    "gross4",
                    "net2"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build(),
                new PriceMonthly.Builder(
                    "gross2",
                    "net0"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            new Price.Builder(
                "location8",
                new PriceHourly.Builder(
                    "gross4",
                    "net2"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build(),
                new PriceMonthly.Builder(
                    "gross2",
                    "net0"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            new Price.Builder(
                "location8",
                new PriceHourly.Builder(
                    "gross4",
                    "net2"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build(),
                new PriceMonthly.Builder(
                    "gross2",
                    "net0"
                )
                .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
        )
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

