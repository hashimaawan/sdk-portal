
# Work Group State 1

The state of the workgroup.

## Enumeration

`WorkGroupState1`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```python
from amazonathena.models.work_group_state_1 import WorkGroupState1

work_group_state_1 = WorkGroupState1.ENABLED
```

