
# Create Presigned Notebook Url Request

## Structure

`CreatePresignedNotebookUrlRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ts
import { CreatePresignedNotebookUrlRequest } from 'amazon-athenalib';

const createPresignedNotebookUrlRequest: CreatePresignedNotebookUrlRequest = {
  sessionId: 'SessionId0',
};
```

