# Forex

```java
ForexApi forexApi = client.getForexApi();
```

## Class Name

`ForexApi`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```java
CompletableFuture<ApiResponse<Void>> getQuotesForAllSymbolsAsync()
```

## Response Type

**200**: A list of quotes

`void`

## Example Usage

```java
forexApi.getQuotesForAllSymbolsAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```java
CompletableFuture<ApiResponse<List<String>>> getAListOfSymbolsForWhichWeProvideRealTimeQuotesAsync()
```

## Response Type

**200**: A list of symbols

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type `List<String>`.

## Example Usage

```java
forexApi.getAListOfSymbolsForWhichWeProvideRealTimeQuotesAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

