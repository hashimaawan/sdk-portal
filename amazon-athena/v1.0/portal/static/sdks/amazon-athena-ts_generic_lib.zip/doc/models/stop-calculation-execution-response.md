
# Stop Calculation Execution Response

*This model accepts additional fields of type unknown.*

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`CalculationExecutionState4 \| undefined`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  CalculationExecutionState4,
  StopCalculationExecutionResponse,
} from 'amazon-athenalib';

const stopCalculationExecutionResponse: StopCalculationExecutionResponse = {
  state: CalculationExecutionState4.Queued,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

