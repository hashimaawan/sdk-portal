
# Window 1

## Enumeration

`Window1`

## Fields

| Name |
|  --- |
| `Enum5M` |
| `Enum10M` |
| `Enum30M` |
| `Enum1H` |

## Example

```ts
import { Window1 } from 'digitalocean-apilib';

const window1 = Window1.Enum30M;
```

