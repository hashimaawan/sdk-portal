
# Region 2 Enum

## Enumeration

`Region2Enum`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```ruby
region2 = Region2Enum::CNNORTH1
```

