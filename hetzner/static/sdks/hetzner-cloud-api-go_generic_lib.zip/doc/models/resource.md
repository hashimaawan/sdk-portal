
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Resource |
| `Type` | `string` | Required | Type of resource referenced |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    resource := models.Resource{
        Id:                   42,
        Type:                 "server",
    }

}
```

