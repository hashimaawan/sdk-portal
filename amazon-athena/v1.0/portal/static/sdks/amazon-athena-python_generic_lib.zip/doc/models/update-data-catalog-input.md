
# Update Data Catalog Input

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `mtype` | [`DataCatalogType3Enum`](../../doc/models/data-catalog-type-3-enum.md) | Required | - |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```python
from amazonathena.models.data_catalog_type_3_enum import DataCatalogType3Enum
from amazonathena.models.parameters import Parameters
from amazonathena.models.update_data_catalog_input import UpdateDataCatalogInput

update_data_catalog_input = UpdateDataCatalogInput(
    name='Name0',
    mtype=DataCatalogType3Enum.HIVE,
    description='Description6',
    parameters=Parameters()
)
```

