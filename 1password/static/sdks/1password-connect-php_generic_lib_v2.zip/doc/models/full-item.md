
# Full Item

*This model accepts additional fields of type array.*

## Structure

`FullItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `category` | [`string(Category)`](../../doc/models/category.md) | Required | - | getCategory(): string | setCategory(string category): void |
| `createdAt` | `?DateTime` | Optional, Read-only | - | getCreatedAt(): ?\DateTime | setCreatedAt(?\DateTime createdAt): void |
| `favorite` | `?bool` | Optional | **Default**: `false` | getFavorite(): ?bool | setFavorite(?bool favorite): void |
| `id` | `?string` | Optional | **Constraints**: *Pattern*: `^[\da-z]{26}$` | getId(): ?string | setId(?string id): void |
| `lastEditedBy` | `?string` | Optional, Read-only | - | getLastEditedBy(): ?string | setLastEditedBy(?string lastEditedBy): void |
| `state` | [`?string(State)`](../../doc/models/state.md) | Optional, Read-only | - | getState(): ?string | setState(?string state): void |
| `tags` | `?(string[])` | Optional | - | getTags(): ?array | setTags(?array tags): void |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |
| `updatedAt` | `?DateTime` | Optional, Read-only | - | getUpdatedAt(): ?\DateTime | setUpdatedAt(?\DateTime updatedAt): void |
| `urls` | [`?(Url[])`](../../doc/models/url.md) | Optional | - | getUrls(): ?array | setUrls(?array urls): void |
| `vault` | [`Vault1`](../../doc/models/vault-1.md) | Required | - | getVault(): Vault1 | setVault(Vault1 vault): void |
| `version` | `?int` | Optional | - | getVersion(): ?int | setVersion(?int version): void |
| `fields` | [`?(Field[])`](../../doc/models/field.md) | Optional | - | getFields(): ?array | setFields(?array fields): void |
| `files` | [`?(File[])`](../../doc/models/file.md) | Optional | - | getFiles(): ?array | setFiles(?array files): void |
| `sections` | [`?(Section2[])`](../../doc/models/section-2.md) | Optional | - | getSections(): ?array | setSections(?array sections): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use M1PasswordConnectLib\Models\Builders\FullItemBuilder;
use M1PasswordConnectLib\Models\Category;
use M1PasswordConnectLib\Models\Builders\Vault1Builder;
use M1PasswordConnectLib\ApiHelper;
use M1PasswordConnectLib\Utils\DateTimeHelper;
use M1PasswordConnectLib\Models\State;
use M1PasswordConnectLib\Models\Builders\UrlBuilder;

$fullItem = FullItemBuilder::init(
    Category::MEMBERSHIP,
    Vault1Builder::init(
        'id6'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->favorite(false)
    ->id('id0')
    ->lastEditedBy('lastEditedBy6')
    ->state(State::ARCHIVED)
    ->urls(
        [
            UrlBuilder::init(
                'https://example.com'
            )
                ->primary(true)
                ->build(),
            UrlBuilder::init(
                'https://example.org'
            )->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

