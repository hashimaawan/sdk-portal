
# X Amz Target 37 Enum

## Enumeration

`XAmzTarget37Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNAMEDQUERIES` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget37Enum;

XAmzTarget37Enum xAmzTarget37 = XAmzTarget37Enum.ENUM_AMAZONATHENALISTNAMEDQUERIES;
```

