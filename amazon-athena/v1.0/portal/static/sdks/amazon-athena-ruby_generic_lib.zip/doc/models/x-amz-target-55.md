
# X Amz Target 55

## Enumeration

`XAmzTarget55`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENAMEDQUERY` |

## Example

```ruby
x_amz_target55 = XAmzTarget55::ENUM_AMAZONATHENAUPDATENAMEDQUERY
```

