
# Time Series

*This model accepts additional fields of type unknown.*

## Structure

`TimeSeries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `values` | [`TimeSeriesValues[]`](../../doc/models/containers/time-series-values.md) | Required | This is 2d Array of a container for one-of cases. |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { TimeSeries } from 'hetzner-cloud-apilib';

const timeSeries: TimeSeries = {
  values: [
    null,
    null
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

