
# Update Certificate Request

## Structure

`UpdateCertificateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New Certificate name |

## Example

```ruby
update_certificate_request = UpdateCertificateRequest.new(
  { 'labelkey' => 'value' },
  'my website cert'
)
```

