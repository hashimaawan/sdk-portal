
# Status 5

The current status of the migration.

## Enumeration

`Status5`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `CANCELED` |
| `ERROR` |
| `DONE` |

## Example

```python
from digitaloceanapi.models.status_5 import Status5

status_5 = Status5.RUNNING
```

