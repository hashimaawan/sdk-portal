
# Protocol 6

Type of the health check

## Enumeration

`Protocol6`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |

## Example

```python
from hetznercloudapi.models.protocol_6 import Protocol6

protocol_6 = Protocol6.TCP
```

