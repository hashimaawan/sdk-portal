
# Encryption Configuration

If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information.

## Structure

`EncryptionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryptionOption` | [`EncryptionOption1Enum`](../../doc/models/encryption-option-1-enum.md) | Required | - |
| `kmsKey` | `string \| undefined` | Optional | - |

## Example

```ts
import {
  EncryptionConfiguration,
  EncryptionOption1Enum,
} from 'amazon-athenalib';

const encryptionConfiguration: EncryptionConfiguration = {
  encryptionOption: EncryptionOption1Enum.SSEKMS,
  kmsKey: 'KmsKey6',
};
```

