
# Status 3

## Structure

`Status3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `start_date_time` | `DateTime` | Optional | - |
| `last_modified_date_time` | `DateTime` | Optional | - |
| `end_date_time` | `DateTime` | Optional | - |
| `idle_since_date_time` | `DateTime` | Optional | - |
| `state` | [`SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |
| `state_change_reason` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
status3 = Status3.new(
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  SessionState1Enum::CREATING
)
```

