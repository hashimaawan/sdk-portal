
# Label Selector 1

Configuration for type LabelSelector, required if type is `label_selector`

## Structure

`LabelSelector1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LabelSelector1 labelSelector1 = new LabelSelector1
{
    Selector = "selector2",
};
```

