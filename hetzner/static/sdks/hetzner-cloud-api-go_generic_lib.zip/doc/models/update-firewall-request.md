
# Update Firewall Request

## Structure

`UpdateFirewallRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labels` | `*interface{}` | Optional | User-defined labels (key-value pairs) |
| `Name` | `*string` | Optional | New Firewall name |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    updateFirewallRequest := models.UpdateFirewallRequest{
        Labels:               models.ToPointer(interface{}("[labelkey, value]")),
        Name:                 models.ToPointer("new-name"),
    }

}
```

