
# X Amz Target 17

## Enumeration

`XAmzTarget17`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS` |

## Example

```python
from amazonathena.models.x_amz_target_17 import XAmzTarget17

x_amz_target_17 = XAmzTarget17.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONSTATUS
```

