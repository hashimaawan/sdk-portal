
# Type 41 Enum

## Enumeration

`Type41Enum`

## Fields

| Name |
|  --- |
| `OPEN_CONNECTIONS` |
| `CONNECTIONS_PER_SECOND` |
| `REQUESTS_PER_SECOND` |
| `BANDWIDTH` |

## Example

```ruby
type41 = Type41Enum::REQUESTS_PER_SECOND
```

