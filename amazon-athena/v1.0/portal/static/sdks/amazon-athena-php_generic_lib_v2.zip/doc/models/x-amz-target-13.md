
# X Amz Target 13

## Enumeration

`XAmzTarget13`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEWORKGROUP` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget13;

$xAmzTarget13 = XAmzTarget13::ENUM_AMAZONATHENADELETEWORKGROUP;
```

