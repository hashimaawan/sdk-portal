
# X Amz Target 38

## Enumeration

`XAmzTarget38`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```ruby
x_amz_target38 = XAmzTarget38::ENUM_AMAZONATHENALISTNOTEBOOKMETADATA
```

