
# Get Prepared Statement Input

## Structure

`GetPreparedStatementInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `statementName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` | getStatementName(): string | setStatementName(string statementName): void |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): string | setWorkGroup(string workGroup): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetPreparedStatementInputBuilder;

$getPreparedStatementInput = GetPreparedStatementInputBuilder::init(
    'StatementName6',
    'WorkGroup0'
)->build();
```

