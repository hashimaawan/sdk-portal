# Load Balancers

```php
$loadBalancersController = $client->getLoadBalancersController();
```

## Class Name

`LoadBalancersController`

## Methods

* [Get All Load Balancers](../../doc/controllers/load-balancers.md#get-all-load-balancers)
* [Create a Load Balancer](../../doc/controllers/load-balancers.md#create-a-load-balancer)
* [Delete a Load Balancer](../../doc/controllers/load-balancers.md#delete-a-load-balancer)
* [Get a Load Balancer](../../doc/controllers/load-balancers.md#get-a-load-balancer)
* [Update a Load Balancer](../../doc/controllers/load-balancers.md#update-a-load-balancer)
* [Get Metrics for a Load Balancer](../../doc/controllers/load-balancers.md#get-metrics-for-a-load-balancer)


# Get All Load Balancers

Gets all existing Load Balancers that you have available.

```php
function getAllLoadBalancers(
    ?string $sort = null,
    ?string $name = null,
    ?string $labelSelector = null
): LoadBalancersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`?string(SortEnum)`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `?string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `?string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `load_balancers` key contains a list of Load Balancers

[`LoadBalancersResponse`](../../doc/models/load-balancers-response.md)

## Example Usage

```php
$loadBalancersController = $client->getLoadBalancersController();

try {
    $result = $loadBalancersController->getAllLoadBalancers();
    echo 'LoadBalancersResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Create a Load Balancer

Creates a Load Balancer.

#### Call specific error codes

| Code                                    | Description                                                                                           |
|-----------------------------------------|-------------------------------------------------------------------------------------------------------|
| `cloud_resource_ip_not_allowed`         | The IP you are trying to add as a target belongs to a Hetzner Cloud resource                          |
| `ip_not_owned`                          | The IP is not owned by the owner of the project of the Load Balancer                                  |
| `load_balancer_not_attached_to_network` | The Load Balancer is not attached to a network                                                        |
| `robot_unavailable`                     | Robot was not available. The caller may retry the operation after a short delay.                      |
| `server_not_attached_to_network`        | The server you are trying to add as a target is not attached to the same network as the Load Balancer |
| `source_port_already_used`              | The source port you are trying to add is already in use                                               |
| `target_already_defined`                | The Load Balancer target you are trying to define is already defined                                  |

```php
function createALoadBalancer(?CreateLoadBalancerRequest $body = null): LoadBalancersResponse1
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?CreateLoadBalancerRequest`](../../doc/models/create-load-balancer-request.md) | Body, Optional | - |

## Response Type

**201**: The `load_balancer` key contains the Load Balancer that was just created

[`LoadBalancersResponse1`](../../doc/models/load-balancers-response-1.md)

## Example Usage

```php
$body = CreateLoadBalancerRequestBuilder::init(
    LoadBalancerAlgorithmBuilder::init(
        Type28Enum::ROUND_ROBIN
    )->build(),
    'lb11',
    'Web Frontend'
)
    ->network(123)
    ->networkZone('eu-central')
    ->publicInterface(true)
    ->build();

$loadBalancersController = $client->getLoadBalancersController();

try {
    $result = $loadBalancersController->createALoadBalancer($body);
    echo 'LoadBalancersResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "create_load_balancer",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "load_balancer"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  },
  "load_balancer": {
    "algorithm": {
      "type": "round_robin"
    },
    "created": "2016-01-30T23:50:00+00:00",
    "id": 4711,
    "included_traffic": 654321,
    "ingoing_traffic": 123456,
    "labels": {
      "env": "dev"
    },
    "load_balancer_type": {
      "deprecated": "2016-01-30T23:50:00+00:00",
      "description": "LB11",
      "id": 1,
      "max_assigned_certificates": 10,
      "max_connections": 20000,
      "max_services": 5,
      "max_targets": 25,
      "name": "lb11",
      "prices": [
        {
          "location": "fsn1",
          "price_hourly": {
            "gross": "1.1900000000000000",
            "net": "1.0000000000"
          },
          "price_monthly": {
            "gross": "1.1900000000000000",
            "net": "1.0000000000"
          }
        }
      ]
    },
    "location": {
      "city": "Falkenstein",
      "country": "DE",
      "description": "Falkenstein DC Park 1",
      "id": 1,
      "latitude": 50.47612,
      "longitude": 12.370071,
      "name": "fsn1",
      "network_zone": "eu-central"
    },
    "name": "Web Frontend",
    "outgoing_traffic": 123456,
    "private_net": [
      {
        "ip": "10.0.0.2",
        "network": 4711
      }
    ],
    "protection": {
      "delete": false
    },
    "public_net": {
      "enabled": false,
      "ipv4": {
        "ip": "1.2.3.4"
      },
      "ipv6": {
        "ip": "2001:db8::1"
      }
    },
    "services": [
      {
        "destination_port": 80,
        "health_check": {
          "http": {
            "domain": "example.com",
            "path": "/",
            "response": "{\"status\": \"ok\"}",
            "status_codes": [
              "2??,3??"
            ],
            "tls": false
          },
          "interval": 15,
          "port": 4711,
          "protocol": "http",
          "retries": 3,
          "timeout": 10
        },
        "http": {
          "certificates": [
            897
          ],
          "cookie_lifetime": 300,
          "cookie_name": "HCLBSTICKY",
          "redirect_http": true,
          "sticky_sessions": true
        },
        "listen_port": 443,
        "protocol": "http",
        "proxyprotocol": false
      }
    ],
    "targets": [
      {
        "health_status": [
          {
            "listen_port": 443,
            "status": "healthy"
          }
        ],
        "server": {
          "id": 80
        },
        "targets": [
          {
            "health_status": [
              {
                "listen_port": 443,
                "status": "healthy"
              }
            ],
            "label_selector": null,
            "server": {
              "id": 80
            },
            "type": "server",
            "use_private_ip": true
          }
        ],
        "type": "server",
        "use_private_ip": true
      }
    ]
  }
}
```


# Delete a Load Balancer

Deletes a Load Balancer.

```php
function deleteALoadBalancer(int $id): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |

## Response Type

**204**: Load Balancer deleted

`void`

## Example Usage

```php
$id = 112;

$loadBalancersController = $client->getLoadBalancersController();

try {
    $loadBalancersController->deleteALoadBalancer($id);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get a Load Balancer

Gets a specific Load Balancer object.

```php
function getALoadBalancer(int $id): LoadBalancersResponse2
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |

## Response Type

**200**: The `load_balancer` key contains the Load Balancer

[`LoadBalancersResponse2`](../../doc/models/load-balancers-response-2.md)

## Example Usage

```php
$id = 112;

$loadBalancersController = $client->getLoadBalancersController();

try {
    $result = $loadBalancersController->getALoadBalancer($id);
    echo 'LoadBalancersResponse2:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Update a Load Balancer

Updates a Load Balancer. You can update a Load Balancer’s name and a Load Balancer’s labels.

Note that when updating labels, the Load Balancer’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the Load Balancer object changes during the request, the response will be a “conflict” error.

```php
function updateALoadBalancer(int $id, ?LoadBalancersRequest $body = null): LoadBalancersResponse2
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `body` | [`?LoadBalancersRequest`](../../doc/models/load-balancers-request.md) | Body, Optional | - |

## Response Type

**200**: The `load_balancer` key contains the updated Load Balancer

[`LoadBalancersResponse2`](../../doc/models/load-balancers-response-2.md)

## Example Usage

```php
$id = 112;

$body = LoadBalancersRequestBuilder::init()
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('new-name')
    ->build();

$loadBalancersController = $client->getLoadBalancersController();

try {
    $result = $loadBalancersController->updateALoadBalancer(
        $id,
        $body
    );
    echo 'LoadBalancersResponse2:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Example Response *(as JSON)*

```json
{
  "load_balancer": {
    "algorithm": {
      "type": "round_robin"
    },
    "created": "2016-01-30T23:50:00+00:00",
    "id": 4711,
    "included_traffic": 654321,
    "ingoing_traffic": 123456,
    "labels": {
      "labelkey": "value"
    },
    "load_balancer_type": {
      "deprecated": "2016-01-30T23:50:00+00:00",
      "description": "LB11",
      "id": 1,
      "max_assigned_certificates": 10,
      "max_connections": 20000,
      "max_services": 5,
      "max_targets": 25,
      "name": "lb11",
      "prices": [
        {
          "location": "fsn1",
          "price_hourly": {
            "gross": "1.1900000000000000",
            "net": "1.0000000000"
          },
          "price_monthly": {
            "gross": "1.1900000000000000",
            "net": "1.0000000000"
          }
        }
      ]
    },
    "location": {
      "city": "Falkenstein",
      "country": "DE",
      "description": "Falkenstein DC Park 1",
      "id": 1,
      "latitude": 50.47612,
      "longitude": 12.370071,
      "name": "fsn1",
      "network_zone": "eu-central"
    },
    "name": "new-name",
    "outgoing_traffic": 123456,
    "private_net": [
      {
        "ip": "10.0.0.2",
        "network": 4711
      }
    ],
    "protection": {
      "delete": false
    },
    "public_net": {
      "enabled": false,
      "ipv4": {
        "ip": "1.2.3.4"
      },
      "ipv6": {
        "ip": "2001:db8::1"
      }
    },
    "services": [
      {
        "destination_port": 80,
        "health_check": {
          "http": {
            "domain": "example.com",
            "path": "/",
            "response": "{\"status\": \"ok\"}",
            "status_codes": [
              "2??,3??"
            ],
            "tls": false
          },
          "interval": 15,
          "port": 4711,
          "protocol": "http",
          "retries": 3,
          "timeout": 10
        },
        "http": {
          "certificates": [
            897
          ],
          "cookie_lifetime": 300,
          "cookie_name": "HCLBSTICKY",
          "redirect_http": true,
          "sticky_sessions": true
        },
        "listen_port": 443,
        "protocol": "http",
        "proxyprotocol": false
      }
    ],
    "targets": [
      {
        "health_status": [
          {
            "listen_port": 443,
            "status": "healthy"
          }
        ],
        "ip": {
          "ip": "203.0.113.1"
        },
        "label_selector": {
          "selector": "env=prod"
        },
        "server": {
          "id": 80
        },
        "targets": [
          {
            "health_status": [
              {
                "listen_port": 443,
                "status": "healthy"
              }
            ],
            "label_selector": null,
            "server": {
              "id": 80
            },
            "type": "server",
            "use_private_ip": true
          }
        ],
        "type": "server",
        "use_private_ip": true
      }
    ]
  }
}
```


# Get Metrics for a Load Balancer

You must specify the type of metric to get: `open_connections`, `connections_per_second`, `requests_per_second` or `bandwidth`. You can also specify more than one type by comma separation, e.g. `requests_per_second,bandwidth`.

Depending on the type you will get different time series data:

|Type | Timeseries | Unit | Description |
|---- |------------|------|-------------|
| open_connections | open_connections | number | Open connections |
| connections_per_second | connections_per_second | connections/s | Connections per second |
| requests_per_second | requests_per_second | requests/s | Requests per second |
| bandwidth | bandwidth.in | bytes/s | Ingress bandwidth |
|| bandwidth.out | bytes/s | Egress bandwidth |

Metrics are available for the last 30 days only.

If you do not provide the step argument we will automatically adjust it so that 200 samples are returned.

We limit the number of samples to a maximum of 500 and will adjust the step parameter accordingly.

```php
function getMetricsForALoadBalancer(
    int $id,
    string $type,
    string $start,
    string $end,
    ?string $step = null
): LoadBalancersMetricsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Load Balancer |
| `type` | [`string(Type41Enum)`](../../doc/models/type-41-enum.md) | Query, Required | Type of metrics to get |
| `start` | `string` | Query, Required | Start of period to get Metrics for (in ISO-8601 format) |
| `end` | `string` | Query, Required | End of period to get Metrics for (in ISO-8601 format) |
| `step` | `?string` | Query, Optional | Resolution of results in seconds |

## Response Type

**200**: The `metrics` key in the reply contains a metrics object with this structure

[`LoadBalancersMetricsResponse`](../../doc/models/load-balancers-metrics-response.md)

## Example Usage

```php
$id = 112;

$type = Type41Enum::REQUESTS_PER_SECOND;

$start = 'start4';

$end = 'end8';

$loadBalancersController = $client->getLoadBalancersController();

try {
    $result = $loadBalancersController->getMetricsForALoadBalancer(
        $id,
        $type,
        $start,
        $end
    );
    echo 'LoadBalancersMetricsResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

