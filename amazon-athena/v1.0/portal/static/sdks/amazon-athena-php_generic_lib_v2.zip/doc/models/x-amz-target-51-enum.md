
# X Amz Target 51 Enum

## Enumeration

`XAmzTarget51Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATAGRESOURCE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget51Enum;

$xAmzTarget51 = XAmzTarget51Enum::ENUM_AMAZONATHENATAGRESOURCE;
```

