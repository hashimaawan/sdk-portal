
# Instance Size Slug

The instance size to use for this component. Default: `basic-xxs`

## Enumeration

`InstanceSizeSlug`

## Fields

| Name |
|  --- |
| `BASICXXS` |
| `BASICXS` |
| `BASICS` |
| `BASICM` |
| `PROFESSIONALXS` |
| `PROFESSIONALS` |
| `PROFESSIONALM` |
| `PROFESSIONAL1L` |
| `PROFESSIONALL` |
| `PROFESSIONALXL` |

## Example

```php
use DigitalOceanApiLib\Models\InstanceSizeSlug;

$instanceSizeSlug = InstanceSizeSlug::PROFESSIONALL;
```

