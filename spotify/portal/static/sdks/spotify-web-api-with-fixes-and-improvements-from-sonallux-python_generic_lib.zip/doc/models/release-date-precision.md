
# Release Date Precision

The precision with which `release_date` value is known.

## Enumeration

`ReleaseDatePrecision`

## Fields

| Name |
|  --- |
| `YEAR` |
| `MONTH` |
| `DAY` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.release_date_precision import ReleaseDatePrecision

release_date_precision = ReleaseDatePrecision.YEAR
```

