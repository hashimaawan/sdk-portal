
# Type 2

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `USER_CREATED` |
| `PERSONAL` |
| `EVERYONE` |
| `TRANSFER` |

## Example

```python
from m1passwordconnect.models.type_2 import Type2

type_2 = Type2.EVERYONE
```

