
# V2 Kubernetes Clusters Clusterlint Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersClusterlintResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `run_id` | `str` | Optional | ID of the clusterlint run that can be used later to fetch the diagnostics. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_kubernetes_clusters_clusterlint_response_1 import V2KubernetesClustersClusterlintResponse1

v_2_kubernetes_clusters_clusterlint_response_1 = V2KubernetesClustersClusterlintResponse1(
    run_id='50c2f44c-011d-493e-aee5-361a4a0d1844',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

