
# Work Group State Enum

## Enumeration

`WorkGroupStateEnum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ruby
work_group_state = WorkGroupStateEnum::ENABLED
```

