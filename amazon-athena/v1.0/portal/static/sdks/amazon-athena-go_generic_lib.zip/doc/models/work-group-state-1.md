
# Work Group State 1

The state of the workgroup.

## Enumeration

`WorkGroupState1`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    workGroupState1 := models.WorkGroupState1_Enabled

}
```

