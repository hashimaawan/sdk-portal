
# Many Episodes

*This model accepts additional fields of type Any.*

## Structure

`ManyEpisodes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `episodes` | [`List[EpisodeObject]`](../../doc/models/episode-object.md) | Required | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from spotifywebapiwithfixesandimprovementsfromsonallux.models.copyright_object import CopyrightObject
from spotifywebapiwithfixesandimprovementsfromsonallux.models.episode_object import EpisodeObject
from spotifywebapiwithfixesandimprovementsfromsonallux.models.episode_restriction_object import EpisodeRestrictionObject
from spotifywebapiwithfixesandimprovementsfromsonallux.models.external_url_object import ExternalUrlObject
from spotifywebapiwithfixesandimprovementsfromsonallux.models.image_object import ImageObject
from spotifywebapiwithfixesandimprovementsfromsonallux.models.many_episodes import ManyEpisodes
from spotifywebapiwithfixesandimprovementsfromsonallux.models.release_date_precision import ReleaseDatePrecision
from spotifywebapiwithfixesandimprovementsfromsonallux.models.resume_point_object import ResumePointObject
from spotifywebapiwithfixesandimprovementsfromsonallux.models.show_base import ShowBase

many_episodes = ManyEpisodes(
    episodes=[
        EpisodeObject(
            audio_preview_url='https://p.scdn.co/mp3-preview/2f37da1d4221f40b9d1a98cd191f4d6f1646ad17',
            description='A Spotify podcast sharing fresh insights on important topics of the moment—in a way only Spotify can. You’ll hear from experts in the music, podcast and tech industries as we discover and uncover stories about our work and the world around us.\n',
            html_description='<p>A Spotify podcast sharing fresh insights on important topics of the moment—in a way only Spotify can. You’ll hear from experts in the music, podcast and tech industries as we discover and uncover stories about our work and the world around us.</p>\n',
            duration_ms=1686230,
            explicit=False,
            external_urls=ExternalUrlObject(
                spotify='spotify6',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            href='https://api.spotify.com/v1/episodes/5Xt5DXGzch68nYYamXrNxZ',
            id='5Xt5DXGzch68nYYamXrNxZ',
            images=[
                ImageObject(
                    url='https://i.scdn.co/image/ab67616d00001e02ff9ca10b55ce82ae553c8228\n',
                    height=300,
                    width=300,
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            is_externally_hosted=False,
            is_playable=False,
            languages=[
                'fr',
                'en'
            ],
            name='Starting Your Own Podcast: Tips, Tricks, and Advice From Anchor Creators\n',
            release_date='1981-12-15',
            release_date_precision=ReleaseDatePrecision.DAY,
            uri='spotify:episode:0zLhl3WsOCQHbe1BPTiHgr',
            show=ShowBase(
                available_markets=[
                    'available_markets0',
                    'available_markets1',
                    'available_markets2'
                ],
                copyrights=[
                    CopyrightObject(
                        text='text2',
                        mtype='type2',
                        additional_properties={
                            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                        }
                    )
                ],
                description='description4',
                html_description='html_description4',
                explicit=False,
                external_urls=ExternalUrlObject(
                    spotify='spotify6',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                href='href8',
                id='id6',
                images=[
                    ImageObject(
                        url='https://i.scdn.co/image/ab67616d00001e02ff9ca10b55ce82ae553c8228\n',
                        height=300,
                        width=300,
                        additional_properties={
                            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                        }
                    )
                ],
                is_externally_hosted=False,
                languages=[
                    'languages7',
                    'languages6',
                    'languages5'
                ],
                media_type='media_type6',
                name='name6',
                publisher='publisher6',
                uri='uri0',
                total_episodes=198,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            language='en',
            resume_point=ResumePointObject(
                fully_played=False,
                resume_position_ms=254,
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            restrictions=EpisodeRestrictionObject(
                reason='reason0',
                additional_properties={
                    'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                }
            ),
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

