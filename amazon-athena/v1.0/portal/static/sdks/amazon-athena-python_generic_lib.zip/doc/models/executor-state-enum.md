
# Executor State Enum

## Enumeration

`ExecutorStateEnum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```python
from amazonathena.models.executor_state_enum import ExecutorStateEnum

executor_state = ExecutorStateEnum.TERMINATED
```

