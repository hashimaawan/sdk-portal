
# Result Set Metadata 2

## Structure

`ResultSetMetadata2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `columnInfo` | [`?(ColumnInfo[])`](../../doc/models/column-info.md) | Optional | - | getColumnInfo(): ?array | setColumnInfo(?array columnInfo): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultSetMetadata2Builder;
use AmazonAthenaLib\Models\Builders\ColumnInfoBuilder;

$resultSetMetadata2 = ResultSetMetadata2Builder::init()
    ->columnInfo(
        [
            ColumnInfoBuilder::init(
                'Name6',
                'Type6'
            )
                ->catalogName('CatalogName0')
                ->schemaName('SchemaName0')
                ->tableName('TableName2')
                ->label('Label4')
                ->precision(48)
                ->build(),
            ColumnInfoBuilder::init(
                'Name6',
                'Type6'
            )
                ->catalogName('CatalogName0')
                ->schemaName('SchemaName0')
                ->tableName('TableName2')
                ->label('Label4')
                ->precision(48)
                ->build()
        ]
    )
    ->build();
```

