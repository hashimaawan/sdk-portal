
# A Criterion for Routing Http Traffic to a Component

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`ACriterionForRoutingHttpTrafficToAComponent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `path` | `str` | Optional | An HTTP path prefix. Paths must start with / and must be unique across all components within an app. |
| `preserve_path_prefix` | `bool` | Optional | An optional flag to preserve the path that is forwarded to the backend service. By default, the HTTP request path will be trimmed from the left when forwarded to the component. For example, a component with `path=/api` will have requests to `/api/list` trimmed to `/list`. If this value is `true`, the path will remain `/api/list`. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.a_criterion_for_routing_http_traffic_to_a_component import ACriterionForRoutingHttpTrafficToAComponent

a_criterion_for_routing_http_traffic_to_a_component = ACriterionForRoutingHttpTrafficToAComponent(
    path='/api',
    preserve_path_prefix=True,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

