
# Notebook Type 1 Enum

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1Enum`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```ts
import { NotebookType1Enum } from 'amazon-athenalib';

const notebookType1 = NotebookType1Enum.IPYNB;
```

