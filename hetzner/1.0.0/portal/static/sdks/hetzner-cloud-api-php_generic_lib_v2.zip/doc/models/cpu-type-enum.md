
# Cpu Type Enum

Type of cpu

## Enumeration

`CpuTypeEnum`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```php
use HetznerCloudAPILib\Models\CpuTypeEnum;

$cpuType = CpuTypeEnum::SHARED;
```

