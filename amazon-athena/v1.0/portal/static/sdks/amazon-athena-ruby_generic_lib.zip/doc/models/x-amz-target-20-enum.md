
# X Amz Target 20 Enum

## Enumeration

`XAmzTarget20Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNAMEDQUERY` |

## Example

```ruby
x_amz_target20 = XAmzTarget20Enum::ENUM_AMAZONATHENAGETNAMEDQUERY
```

