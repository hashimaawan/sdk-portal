
# V2 Load Balancers Forwarding Rules Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2LoadBalancersForwardingRulesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `forwarding_rules` | [`List[ForwardingRule]`](../../doc/models/forwarding-rule.md) | Required | **Constraints**: *Minimum Items*: `1` |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.entry_protocol import EntryProtocol
from digitaloceanapi.models.forwarding_rule import ForwardingRule
from digitaloceanapi.models.target_protocol import TargetProtocol
from digitaloceanapi.models.v_2_load_balancers_forwarding_rules_request import V2LoadBalancersForwardingRulesRequest

v_2_load_balancers_forwarding_rules_request = V2LoadBalancersForwardingRulesRequest(
    forwarding_rules=[
        ForwardingRule(
            entry_port=443,
            entry_protocol=EntryProtocol.HTTPS,
            target_port=80,
            target_protocol=TargetProtocol.HTTP,
            certificate_id='892071a0-bb95-49bc-8021-3afd67a210bf',
            tls_passthrough=False,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

