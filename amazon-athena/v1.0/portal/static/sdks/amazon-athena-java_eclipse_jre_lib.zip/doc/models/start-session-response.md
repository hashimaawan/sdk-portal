
# Start Session Response

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SessionId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getSessionId() | setSessionId(String sessionId) |
| `State` | [`SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - | SessionState1Enum getState() | setState(SessionState1Enum state) |

## Example

```java
import com.amazonaws.useast1.athena.models.SessionState1Enum;
import com.amazonaws.useast1.athena.models.StartSessionResponse;

StartSessionResponse startSessionResponse = new StartSessionResponse.Builder()
    .sessionId("SessionId4")
    .state(SessionState1Enum.CREATING)
    .build();
```

