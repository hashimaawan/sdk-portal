
# Status 30

## Enumeration

`Status30`

## Fields

| Name |
|  --- |
| `Healthy` |
| `Unhealthy` |
| `Unknown` |

## Example

```ts
import { Status30 } from 'hetzner-cloud-apilib';

const status30 = Status30.Healthy;
```

