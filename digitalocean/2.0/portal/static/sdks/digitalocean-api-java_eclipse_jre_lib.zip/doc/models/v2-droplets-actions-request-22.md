
# V2 Droplets Actions Request 22

*This model accepts additional fields of type Object.*

## Structure

`V2DropletsActionsRequest22`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. | Type12 getType() | setType(Type12 type) |
| `Image` | [`V2DropletsActionsRequest22Image`](../../doc/models/containers/v2-droplets-actions-request-22-image.md) | Optional | This is a container for one-of cases. | V2DropletsActionsRequest22Image getImage() | setImage(V2DropletsActionsRequest22Image image) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Type12;
import com.digitalocean.api.models.V2DropletsActionsRequest22;
import com.digitalocean.api.models.containers.V2DropletsActionsRequest22Image;
import java.io.IOException;

V2DropletsActionsRequest22 v2DropletsActionsRequest22 = new V2DropletsActionsRequest22.Builder(
    Type12.REBOOT
)
.image(V2DropletsActionsRequest22Image.fromString(
        "ubuntu-20-04-x64"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

