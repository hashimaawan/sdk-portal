
# X Amz Target 35

## Enumeration

`XAmzTarget35`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistengineversions` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget35 := models.XAmzTarget35_EnumAmazonathenalistengineversions

}
```

