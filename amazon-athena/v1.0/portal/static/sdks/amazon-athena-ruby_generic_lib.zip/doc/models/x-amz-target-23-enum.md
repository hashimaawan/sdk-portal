
# X Amz Target 23 Enum

## Enumeration

`XAmzTarget23Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYEXECUTION` |

## Example

```ruby
x_amz_target23 = XAmzTarget23Enum::ENUM_AMAZONATHENAGETQUERYEXECUTION
```

