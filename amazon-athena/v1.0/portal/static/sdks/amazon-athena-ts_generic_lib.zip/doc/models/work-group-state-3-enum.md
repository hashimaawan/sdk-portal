
# Work Group State 3 Enum

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ts
import { WorkGroupState3Enum } from 'amazon-athenalib';

const workGroupState3 = WorkGroupState3Enum.ENABLED;
```

