
# Applied To

*This model accepts additional fields of type unknown.*

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appliedToResources` | [`AppliedToResource[] \| undefined`](../../doc/models/applied-to-resource.md) | Optional | - |
| `labelSelector` | [`LabelSelector \| undefined`](../../doc/models/label-selector.md) | Optional | - |
| `server` | [`Server \| undefined`](../../doc/models/server.md) | Optional | - |
| `type` | [`Type6`](../../doc/models/type-6.md) | Required | Type of resource referenced |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { AppliedTo, Type5, Type6 } from 'hetzner-cloud-apilib';

const appliedTo: AppliedTo = {
  type: Type6.Server,
  appliedToResources: [
    {
      server: {
        id: 14,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      type: Type5.Server,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      server: {
        id: 14,
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      type: Type5.Server,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  labelSelector: {
    selector: 'selector8',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  server: {
    id: 14,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

