
# X Amz Target 55

## Enumeration

`XAmzTarget55`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNamedQuery` |

## Example

```ts
import { XAmzTarget55 } from 'amazon-athenalib';

const xAmzTarget55 = XAmzTarget55.EnumAmazonAthenaUpdateNamedQuery;
```

