
# Assign Primary IP Request

## Structure

`AssignPrimaryIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AssigneeId` | `int` | Required | ID of a resource of type `assignee_type` |
| `AssigneeType` | `string` | Required, Constant | Type of resource assigning the Primary IP to<br><br>**Value**: `"server"` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

AssignPrimaryIPRequest assignPrimaryIPRequest = new AssignPrimaryIPRequest
{
    AssigneeId = 4711,
    AssigneeType = "server",
};
```

