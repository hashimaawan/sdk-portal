
# Status Enum

Status of the Action

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ERROR` |

## Example

```java
import cloud.hetzner.api.models.StatusEnum;

StatusEnum status = StatusEnum.ERROR;
```

