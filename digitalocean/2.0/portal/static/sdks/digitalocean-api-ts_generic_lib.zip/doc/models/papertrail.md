
# Papertrail

Papertrail configuration.

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Papertrail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endpoint` | `string` | Required | Papertrail syslog endpoint. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Papertrail } from 'digitalocean-apilib';

const papertrail: Papertrail = {
  endpoint: 'https://mypapertrailendpoint.com',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

