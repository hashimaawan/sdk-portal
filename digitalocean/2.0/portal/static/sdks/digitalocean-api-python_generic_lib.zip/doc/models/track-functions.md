
# Track Functions

Enables tracking of function call counts and time used.

## Enumeration

`TrackFunctions`

## Fields

| Name |
|  --- |
| `ALL` |
| `PL` |
| `NONE` |

## Example

```python
from digitaloceanapi.models.track_functions import TrackFunctions

track_functions = TrackFunctions.NONE
```

