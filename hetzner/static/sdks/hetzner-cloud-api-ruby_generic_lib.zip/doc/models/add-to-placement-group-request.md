
# Add to Placement Group Request

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `placement_group` | `Integer` | Required | ID of Placement Group the Server should be added to |

## Example

```ruby
add_to_placement_group_request = AddToPlacementGroupRequest.new(
  1
)
```

