
# Update Work Group Input

## Structure

`UpdateWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `configuration_updates` | [`ConfigurationUpdates`](../../doc/models/configuration-updates.md) | Optional | - |
| `state` | [`WorkGroupState2Enum`](../../doc/models/work-group-state-2-enum.md) | Optional | - |

## Example

```ruby
update_work_group_input = UpdateWorkGroupInput.new(
  'WorkGroup0',
  'Description8',
  ConfigurationUpdates.new(
    false,
    ResultConfigurationUpdates2.new(
      'OutputLocation0',
      false,
      EncryptionConfiguration2.new(
        EncryptionOption1Enum::SSE_S3,
        'KmsKey6'
      ),
      false,
      'ExpectedBucketOwner0',
      nil,
      AclConfiguration1.new(
        envrr
      )
    ),
    false,
    10000000,
    false,
    nil,
    EngineVersion1.new,
    nil,
    nil,
    nil,
    CustomerContentEncryptionConfiguration.new
  ),
  WorkGroupState2Enum::ENABLED
)
```

