
# Type 10

The type of the IPv4 network interface.

## Enumeration

`Type10`

## Fields

| Name |
|  --- |
| `PUBLIC` |
| `PRIVATE` |

## Example

```ruby
type10 = Type10::PUBLIC
```

