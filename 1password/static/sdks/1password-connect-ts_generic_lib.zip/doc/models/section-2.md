
# Section 2

*This model accepts additional fields of type unknown.*

## Structure

`Section2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string \| undefined` | Optional | - |
| `label` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Section2 } from 'm-1-password-connectlib';

const section2: Section2 = {
  id: 'id4',
  label: 'label4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

