
# X Amz Target 24 Enum

## Enumeration

`XAmzTarget24Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRESULTS` |

## Example

```ruby
x_amz_target24 = XAmzTarget24Enum::ENUM_AMAZONATHENAGETQUERYRESULTS
```

