
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`furkotTripsRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `furkotTrips.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "furkotTrips"
    "net/http"
)

func main() {
    httpConfiguration := furkotTrips.CreateHttpConfiguration(
        furkotTrips.WithTimeout(30),
        furkotTrips.WithTransport(http.DefaultTransport),
        furkotTrips.WithRetryConfiguration(furkotTrips.DefaultRetryConfiguration()),
    )
}
```

