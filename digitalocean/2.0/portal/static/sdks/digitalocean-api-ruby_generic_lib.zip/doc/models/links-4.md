
# Links 4

The links object contains the `self` object, which contains the resource relationship.

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Links4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mself` | `String` | Optional | A URI that can be used to retrieve the resource. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
links4 = Links4.new(
  mself: 'https://api.digitalocean.com/v2/droplets/13457723',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

