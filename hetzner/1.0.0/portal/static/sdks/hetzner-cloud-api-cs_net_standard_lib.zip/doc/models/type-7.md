
# Type 7

Type of the resource

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type7 type7 = Type7.Server;
```

