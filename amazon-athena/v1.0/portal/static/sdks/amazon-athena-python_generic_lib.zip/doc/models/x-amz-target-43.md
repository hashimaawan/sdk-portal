
# X Amz Target 43

## Enumeration

`XAmzTarget43`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTABLEMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_43 import XAmzTarget43

x_amz_target_43 = XAmzTarget43.ENUM_AMAZONATHENALISTTABLEMETADATA
```

