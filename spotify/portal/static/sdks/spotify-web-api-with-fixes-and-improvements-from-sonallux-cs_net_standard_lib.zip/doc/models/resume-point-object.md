
# Resume Point Object

*This model accepts additional fields of type object.*

## Structure

`ResumePointObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FullyPlayed` | `bool?` | Optional | Whether or not the episode has been fully played by the user. |
| `ResumePositionMs` | `int?` | Optional | The user's most recent position in the episode in milliseconds. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Utilities;

ResumePointObject resumePointObject = new ResumePointObject
{
    FullyPlayed = false,
    ResumePositionMs = 106,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

