
# Applied To

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppliedToResources` | [`[]models.AppliedToResource`](../../doc/models/applied-to-resource.md) | Optional | - |
| `LabelSelector` | [`*models.LabelSelector`](../../doc/models/label-selector.md) | Optional | - |
| `Server` | [`*models.Server`](../../doc/models/server.md) | Optional | - |
| `Type` | [`models.Type6Enum`](../../doc/models/type-6-enum.md) | Required | Type of resource referenced |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    appliedTo := models.AppliedTo{
        AppliedToResources:   []models.AppliedToResource{
            models.AppliedToResource{
                Server:               models.ToPointer(models.Server{
                    Id:                   14,
                }),
                Type:                 models.ToPointer(models.Type5Enum_SERVER),
            },
            models.AppliedToResource{
                Server:               models.ToPointer(models.Server{
                    Id:                   14,
                }),
                Type:                 models.ToPointer(models.Type5Enum_SERVER),
            },
        },
        LabelSelector:        models.ToPointer(models.LabelSelector{
            Selector:             "selector8",
        }),
        Server:               models.ToPointer(models.Server{
            Id:                   14,
        }),
        Type:                 models.Type6Enum_SERVER,
    }

}
```

