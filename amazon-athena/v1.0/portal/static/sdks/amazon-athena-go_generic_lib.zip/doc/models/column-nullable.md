
# Column Nullable

## Enumeration

`ColumnNullable`

## Fields

| Name |
|  --- |
| `NotNull` |
| `Nullable` |
| `Unknown` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    columnNullable := models.ColumnNullable_NotNull

}
```

