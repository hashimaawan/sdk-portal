
# Update Image Request

## Structure

`UpdateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `String` | Optional | New description of Image |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `type` | [`Type24Enum`](../../doc/models/type-24-enum.md) | Optional | Destination Image type to convert to |

## Example

```ruby
update_image_request = UpdateImageRequest.new(
  'My new Image description',
  { 'labelkey' => 'value' },
  Type24Enum::SNAPSHOT
)
```

