
# Notebook Type 1

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1`

## Fields

| Name |
|  --- |
| `Ipynb` |

## Example

```csharp
using AmazonAthena.Standard.Models;

NotebookType1 notebookType1 = NotebookType1.Ipynb;
```

