
# Load Balancers Actions Attach to Network Request

## Structure

`LoadBalancersActionsAttachToNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip` | `String` | Optional | IP to request to be assigned to this Load Balancer; if you do not provide this then you will be auto assigned an IP address |
| `network` | `Float` | Required | ID of an existing network to attach the Load Balancer to |

## Example

```ruby
load_balancers_actions_attach_to_network_request = LoadBalancersActionsAttachToNetworkRequest.new(
  4711,
  '10.0.1.1'
)
```

