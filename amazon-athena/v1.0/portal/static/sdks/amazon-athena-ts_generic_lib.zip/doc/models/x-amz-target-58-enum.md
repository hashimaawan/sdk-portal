
# X Amz Target 58 Enum

## Enumeration

`XAmzTarget58Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdatePreparedStatement` |

## Example

```ts
import { XAmzTarget58Enum } from 'amazon-athenalib';

const xAmzTarget58 = XAmzTarget58Enum.EnumAmazonAthenaUpdatePreparedStatement;
```

