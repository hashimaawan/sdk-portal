
# Start Calculation Execution Response

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `state` | [`CalculationExecutionState4Enum`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```ruby
start_calculation_execution_response = StartCalculationExecutionResponse.new(
  'CalculationExecutionId0',
  CalculationExecutionState4Enum::CANCELING
)
```

