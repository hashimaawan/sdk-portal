
# Status 13

## Enumeration

`Status13`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `ERROR` |

## Example

```java
import com.digitalocean.api.models.Status13;

Status13 status13 = Status13.SUCCESS;
```

