
# Type 5

Type of resource referenced

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `Server` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type5 type5 = Type5.Server;
```

