
# Error 2

If issuance or renewal reports `failed`, this property contains information about what happened

*This model accepts additional fields of type interface{}.*

## Structure

`Error2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `*string` | Optional | - |
| `Message` | `*string` | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    error2 := models.Error2{
        Code:                  models.ToPointer("code2"),
        Message:               models.ToPointer("message4"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

