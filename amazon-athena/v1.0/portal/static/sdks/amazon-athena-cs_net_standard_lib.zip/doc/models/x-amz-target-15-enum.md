
# X Amz Target 15 Enum

## Enumeration

`XAmzTarget15Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecution` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget15Enum xAmzTarget15 = XAmzTarget15Enum.EnumAmazonAthenaGetCalculationExecution;
```

