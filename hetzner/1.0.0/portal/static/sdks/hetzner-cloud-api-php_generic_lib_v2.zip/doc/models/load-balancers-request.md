
# Load Balancers Request

## Structure

`LoadBalancersRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `labels` | `?array` | Optional | User-defined labels (key-value pairs) | getLabels(): ?array | setLabels(?array labels): void |
| `name` | `?string` | Optional | New Load Balancer name | getName(): ?string | setName(?string name): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LoadBalancersRequestBuilder;
use HetznerCloudAPILib\ApiHelper;

$loadBalancersRequest = LoadBalancersRequestBuilder::init()
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('new-name')
    ->build();
```

