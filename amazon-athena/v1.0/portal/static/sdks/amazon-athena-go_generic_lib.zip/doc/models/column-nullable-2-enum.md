
# Column Nullable 2 Enum

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2Enum`

## Fields

| Name |
|  --- |
| `NOTNULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    columnNullable2 := models.ColumnNullable2Enum_NOTNULL

}
```

