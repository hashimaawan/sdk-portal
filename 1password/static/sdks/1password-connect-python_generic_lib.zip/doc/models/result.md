
# Result

## Enumeration

`Result`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `DENY` |

## Example

```python
from m1passwordconnect.models.result import Result

result = Result.SUCCESS
```

