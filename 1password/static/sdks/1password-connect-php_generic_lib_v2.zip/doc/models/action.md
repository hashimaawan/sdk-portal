
# Action

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `READ` |
| `CREATE` |
| `UPDATE` |
| `DELETE` |

## Example

```php
use M1PasswordConnectLib\Models\Action;

$action = Action::UPDATE;
```

