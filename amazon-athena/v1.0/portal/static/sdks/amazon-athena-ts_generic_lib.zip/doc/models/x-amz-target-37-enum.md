
# X Amz Target 37 Enum

## Enumeration

`XAmzTarget37Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListNamedQueries` |

## Example

```ts
import { XAmzTarget37Enum } from 'amazon-athenalib';

const xAmzTarget37 = XAmzTarget37Enum.EnumAmazonAthenaListNamedQueries;
```

