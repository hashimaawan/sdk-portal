
# Stop Calculation Execution Response

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `State` | [`CalculationExecutionState4Enum`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - | CalculationExecutionState4Enum getState() | setState(CalculationExecutionState4Enum state) |

## Example

```java
import com.amazonaws.useast1.athena.models.CalculationExecutionState4Enum;
import com.amazonaws.useast1.athena.models.StopCalculationExecutionResponse;

StopCalculationExecutionResponse stopCalculationExecutionResponse = new StopCalculationExecutionResponse.Builder()
    .state(CalculationExecutionState4Enum.QUEUED)
    .build();
```

