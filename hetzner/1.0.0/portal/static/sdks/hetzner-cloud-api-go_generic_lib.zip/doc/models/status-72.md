
# Status 72

Status of the Firewall on the Server

## Enumeration

`Status72`

## Fields

| Name |
|  --- |
| `Applied` |
| `Pending` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    status72 := models.Status72_Applied

}
```

