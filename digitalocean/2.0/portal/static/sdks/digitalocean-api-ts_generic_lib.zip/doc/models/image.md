
# Image

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Image`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registry` | `string \| undefined` | Optional | The registry name. Must be left empty for the `DOCR` registry type. |
| `registryType` | [`RegistryType \| undefined`](../../doc/models/registry-type.md) | Optional | - DOCKER_HUB: The DockerHub container registry type.<br>- DOCR: The DigitalOcean container registry type. |
| `repository` | `string \| undefined` | Optional | The repository name. |
| `tag` | `string \| undefined` | Optional | The repository tag. Defaults to `latest` if not provided.<br><br>**Default**: `'latest'` |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Image, RegistryType } from 'digitalocean-apilib';

const image: Image = {
  registry: 'registry.hub.docker.com',
  registryType: RegistryType.Docr,
  repository: 'origin/master',
  tag: 'latest',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

