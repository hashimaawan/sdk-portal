
# Work Group State 3

The state of the workgroup: ENABLED or DISABLED.

## Enumeration

`WorkGroupState3`

## Fields

| Name |
|  --- |
| `Enabled` |
| `Disabled` |

## Example

```ts
import { WorkGroupState3 } from 'amazon-athenalib';

const workGroupState3 = WorkGroupState3.Enabled;
```

