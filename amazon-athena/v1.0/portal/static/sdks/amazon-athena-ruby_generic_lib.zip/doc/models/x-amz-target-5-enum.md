
# X Amz Target 5 Enum

## Enumeration

`XAmzTarget5Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENOTEBOOK` |

## Example

```ruby
x_amz_target5 = XAmzTarget5Enum::ENUM_AMAZONATHENACREATENOTEBOOK
```

