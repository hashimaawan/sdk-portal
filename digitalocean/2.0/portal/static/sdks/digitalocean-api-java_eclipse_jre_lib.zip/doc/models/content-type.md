
# Content Type

## Enumeration

`ContentType`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONYAML` |

## Example

```java
import com.digitalocean.api.models.ContentType;

ContentType contentType = ContentType.ENUM_APPLICATIONJSON;
```

