
# Stop Calculation Execution Request

*This model accepts additional fields of type unknown.*

## Structure

`StopCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { StopCalculationExecutionRequest } from 'amazon-athenalib';

const stopCalculationExecutionRequest: StopCalculationExecutionRequest = {
  calculationExecutionId: 'CalculationExecutionId2',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

