
# V2 Droplets Actions Request 22

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest22`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type12)`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. | getType(): string | setType(string type): void |
| `image` | string\|int\|null | Optional | This is a container for one-of cases. | getImage(): | setImage( image): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DropletsActionsRequest22Builder;
use DigitalOceanApiLib\Models\Type12;
use DigitalOceanApiLib\ApiHelper;

$v2DropletsActionsRequest22 = V2DropletsActionsRequest22Builder::init(
    Type12::REBOOT
)
    ->image(
        'ubuntu-20-04-x64'
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

