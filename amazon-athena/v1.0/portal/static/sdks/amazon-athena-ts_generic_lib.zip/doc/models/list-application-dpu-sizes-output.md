
# List Application DPU Sizes Output

## Structure

`ListApplicationDPUSizesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applicationDPUSizes` | [`ApplicationDPUSizes[] \| undefined`](../../doc/models/application-dpu-sizes.md) | Optional | - |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListApplicationDPUSizesOutput } from 'amazon-athenalib';

const listApplicationDPUSizesOutput: ListApplicationDPUSizesOutput = {
  applicationDPUSizes: [
    {
      applicationRuntimeId: 'ApplicationRuntimeId0',
      supportedDPUSizes: [
        113,
        114
      ],
    },
    {
      applicationRuntimeId: 'ApplicationRuntimeId0',
      supportedDPUSizes: [
        113,
        114
      ],
    }
  ],
  nextToken: 'NextToken0',
};
```

