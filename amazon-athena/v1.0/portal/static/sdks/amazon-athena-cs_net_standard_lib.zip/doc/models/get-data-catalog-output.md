
# Get Data Catalog Output

*This model accepts additional fields of type object.*

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DataCatalog` | [`DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

GetDataCatalogOutput getDataCatalogOutput = new GetDataCatalogOutput
{
    DataCatalog = new DataCatalog2
    {
        Name = "Name4",
        Type = DataCatalogType1.Glue,
        Description = "Description2",
        Parameters = new Parameters
        {
            ["exampleAdditionalProperty"] = "Parameters_additionalProperties2",
        },
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

