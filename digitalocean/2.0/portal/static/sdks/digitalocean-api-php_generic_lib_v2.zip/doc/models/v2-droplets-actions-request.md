
# V2 Droplets Actions Request

Specifies the action that will be taken on the Droplet.

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type12)`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. | getType(): string | setType(string type): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DropletsActionsRequestBuilder;
use DigitalOceanApiLib\Models\Type12;
use DigitalOceanApiLib\ApiHelper;

$v2DropletsActionsRequest = V2DropletsActionsRequestBuilder::init(
    Type12::REBOOT
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

