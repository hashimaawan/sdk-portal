
# V2 Databases Upgrade Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesUpgradeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `version` | `?string` | Optional | A string representing the version of the database engine in use for the cluster. | getVersion(): ?string | setVersion(?string version): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesUpgradeRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesUpgradeRequest = V2DatabasesUpgradeRequestBuilder::init()
    ->version('10')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

