
# V2 Certificates Response

*This model accepts additional fields of type Object.*

## Structure

`V2CertificatesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Certificates` | [`List<Certificate>`](../../doc/models/certificate.md) | Optional | - | List<Certificate> getCertificates() | setCertificates(List<Certificate> certificates) |
| `Links` | [`Links`](../../doc/models/links.md) | Optional | - | Links getLinks() | setLinks(Links links) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Required | - | Meta getMeta() | setMeta(Meta meta) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.DateTimeHelper;
import com.digitalocean.api.models.Certificate;
import com.digitalocean.api.models.Links;
import com.digitalocean.api.models.Meta;
import com.digitalocean.api.models.Pages;
import com.digitalocean.api.models.V2CertificatesResponse;
import com.digitalocean.api.models.containers.LinksPages;
import java.io.IOException;
import java.util.Arrays;
import java.util.UUID;

V2CertificatesResponse v2CertificatesResponse = new V2CertificatesResponse.Builder(
    new Meta.Builder(
        1
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.certificates(Arrays.asList(
        new Certificate.Builder()
            .createdAt(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
            .dnsNames(Arrays.asList(
                "dns_names6"
            ))
            .id(UUID.fromString("000019c8-0000-0000-0000-000000000000"))
            .name("name0")
            .notAfter(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
        new Certificate.Builder()
            .createdAt(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
            .dnsNames(Arrays.asList(
                "dns_names6"
            ))
            .id(UUID.fromString("000019c8-0000-0000-0000-000000000000"))
            .name("name0")
            .notAfter(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
        new Certificate.Builder()
            .createdAt(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
            .dnsNames(Arrays.asList(
                "dns_names6"
            ))
            .id(UUID.fromString("000019c8-0000-0000-0000-000000000000"))
            .name("name0")
            .notAfter(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ))
.links(new Links.Builder()
        .pages(LinksPages.fromPages(
            new Pages.Builder()
                .last("last6")
                .next("next2")
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

