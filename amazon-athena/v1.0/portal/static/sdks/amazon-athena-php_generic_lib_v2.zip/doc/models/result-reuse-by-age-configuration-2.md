
# Result Reuse by Age Configuration 2

## Structure

`ResultReuseByAgeConfiguration2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `enabled` | `bool` | Required | - | getEnabled(): bool | setEnabled(bool enabled): void |
| `maxAgeInMinutes` | `?int` | Optional | **Constraints**: `>= 0`, `<= 10080` | getMaxAgeInMinutes(): ?int | setMaxAgeInMinutes(?int maxAgeInMinutes): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultReuseByAgeConfiguration2Builder;

$resultReuseByAgeConfiguration2 = ResultReuseByAgeConfiguration2Builder::init(
    false
)
    ->maxAgeInMinutes(44)
    ->build();
```

