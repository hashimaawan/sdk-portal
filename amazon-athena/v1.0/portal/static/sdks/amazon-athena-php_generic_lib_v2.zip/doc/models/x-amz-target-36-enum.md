
# X Amz Target 36 Enum

## Enumeration

`XAmzTarget36Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTEXECUTORS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget36Enum;

$xAmzTarget36 = XAmzTarget36Enum::ENUM_AMAZONATHENALISTEXECUTORS;
```

