
# Query Runtime Statistics Timeline

Timeline statistics such as query queue time, planning time, execution time, service processing time, and total execution time.

*This model accepts additional fields of type object.*

## Structure

`QueryRuntimeStatisticsTimeline`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryQueueTimeInMillis` | `int?` | Optional | - |
| `QueryPlanningTimeInMillis` | `int?` | Optional | - |
| `EngineExecutionTimeInMillis` | `int?` | Optional | - |
| `ServiceProcessingTimeInMillis` | `int?` | Optional | - |
| `TotalExecutionTimeInMillis` | `int?` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

QueryRuntimeStatisticsTimeline queryRuntimeStatisticsTimeline = new QueryRuntimeStatisticsTimeline
{
    QueryQueueTimeInMillis = 122,
    QueryPlanningTimeInMillis = 48,
    EngineExecutionTimeInMillis = 78,
    ServiceProcessingTimeInMillis = 96,
    TotalExecutionTimeInMillis = 140,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

