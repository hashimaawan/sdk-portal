
# Type 10

The type of the IPv4 network interface.

## Enumeration

`Type10`

## Fields

| Name |
|  --- |
| `PUBLIC` |
| `PRIVATE` |

## Example

```python
from digitaloceanapi.models.type_10 import Type10

type_10 = Type10.PUBLIC
```

