
# X Amz Target 33 Enum

## Enumeration

`XAmzTarget33Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATACATALOGS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget33Enum;

$xAmzTarget33 = XAmzTarget33Enum::ENUM_AMAZONATHENALISTDATACATALOGS;
```

