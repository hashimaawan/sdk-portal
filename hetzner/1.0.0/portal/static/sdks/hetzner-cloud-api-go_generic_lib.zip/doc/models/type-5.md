
# Type 5

Type of resource referenced

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `Server` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type5 := models.Type5_Server

}
```

