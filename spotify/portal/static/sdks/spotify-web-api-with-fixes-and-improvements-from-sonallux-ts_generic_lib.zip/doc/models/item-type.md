
# Item Type

## Enumeration

`ItemType`

## Fields

| Name |
|  --- |
| `Album` |
| `Artist` |
| `Playlist` |
| `Track` |
| `Show` |
| `Episode` |
| `Audiobook` |

## Example

```ts
import {
  ItemType,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const itemType = ItemType.Artist;
```

