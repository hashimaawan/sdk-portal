
# Slack

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Slack`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `channel` | `string` | Required | Slack channel to notify of an alert trigger. | getChannel(): string | setChannel(string channel): void |
| `url` | `string` | Required | Slack Webhook URL. | getUrl(): string | setUrl(string url): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\SlackBuilder;
use DigitalOceanApiLib\ApiHelper;

$slack = SlackBuilder::init(
    'Production Alerts',
    'https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

