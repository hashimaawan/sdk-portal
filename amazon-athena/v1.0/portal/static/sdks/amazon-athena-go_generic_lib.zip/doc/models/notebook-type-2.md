
# Notebook Type 2

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2`

## Fields

| Name |
|  --- |
| `Ipynb` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    notebookType2 := models.NotebookType2_Ipynb

}
```

