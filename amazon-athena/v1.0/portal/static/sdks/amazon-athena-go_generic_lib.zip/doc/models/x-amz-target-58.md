
# X Amz Target 58

## Enumeration

`XAmzTarget58`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaupdatepreparedstatement` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget58 := models.XAmzTarget58_EnumAmazonathenaupdatepreparedstatement

}
```

