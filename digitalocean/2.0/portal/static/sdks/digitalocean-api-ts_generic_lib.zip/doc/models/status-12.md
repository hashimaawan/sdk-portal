
# Status 12

A status string indicating the current state of the load balancer. This can be `new`, `active`, or `errored`.

## Enumeration

`Status12`

## Fields

| Name |
|  --- |
| `New` |
| `Active` |
| `Errored` |

## Example

```ts
import { Status12 } from 'digitalocean-apilib';

const status12 = Status12.New;
```

