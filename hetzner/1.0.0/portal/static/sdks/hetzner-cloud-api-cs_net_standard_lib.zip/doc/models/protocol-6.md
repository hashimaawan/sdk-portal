
# Protocol 6

Type of the health check

## Enumeration

`Protocol6`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Protocol6 protocol6 = Protocol6.Tcp;
```

