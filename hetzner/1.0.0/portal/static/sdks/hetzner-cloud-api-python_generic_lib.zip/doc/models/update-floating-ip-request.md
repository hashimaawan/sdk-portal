
# Update Floating Ip Request

*This model accepts additional fields of type Any.*

## Structure

`UpdateFloatingIpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Optional | New Description to set |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Optional | New unique name to set |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.update_floating_ip_request import UpdateFloatingIpRequest

update_floating_ip_request = UpdateFloatingIpRequest(
    description='Web Frontend',
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    name='Web Frontend',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

