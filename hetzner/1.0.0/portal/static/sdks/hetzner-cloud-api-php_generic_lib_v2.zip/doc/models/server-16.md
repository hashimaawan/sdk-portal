
# Server 16

Configuration for type Server, required if type is `server`

## Structure

`Server16`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `float` | Required | ID of the Server | getId(): float | setId(float id): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\Server16Builder;

$server16 = Server16Builder::init(
    80
)->build();
```

