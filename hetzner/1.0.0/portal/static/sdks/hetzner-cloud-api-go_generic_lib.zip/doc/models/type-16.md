
# Type 16

Type of the Floating IP

## Enumeration

`Type16`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type16 := models.Type16_Ipv4

}
```

