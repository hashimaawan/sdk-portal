
# Parameter Status

## Enumeration

`ParameterStatus`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ERROR` |

## Example

```ruby
parameter_status = ParameterStatus::ERROR
```

