
# X Amz Target 43 Enum

## Enumeration

`XAmzTarget43Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListTableMetadata` |

## Example

```ts
import { XAmzTarget43Enum } from 'amazon-athenalib';

const xAmzTarget43 = XAmzTarget43Enum.EnumAmazonAthenaListTableMetadata;
```

