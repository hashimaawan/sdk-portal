
# X Amz Target 47

## Enumeration

`XAmzTarget47`

## Fields

| Name |
|  --- |
| `EnumAmazonathenastartqueryexecution` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget47 := models.XAmzTarget47_EnumAmazonathenastartqueryexecution

}
```

