
# X Amz Target 41

## Enumeration

`XAmzTarget41`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListQueryExecutions` |

## Example

```ts
import { XAmzTarget41 } from 'amazon-athenalib';

const xAmzTarget41 = XAmzTarget41.EnumAmazonAthenaListQueryExecutions;
```

