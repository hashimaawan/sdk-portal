# Files

```ts
const filesApi = new FilesApi(client);
```

## Class Name

`FilesApi`

## Methods

* [Get Item Files](../../doc/controllers/files.md#get-item-files)
* [Get Details of File by Id](../../doc/controllers/files.md#get-details-of-file-by-id)
* [Download File by ID](../../doc/controllers/files.md#download-file-by-id)


# Get Item Files

```ts
async getItemFiles(
  vaultUuid: string,
  itemUuid: string,
  inlineFiles?: boolean,
  requestOptions?: RequestOptions
): Promise<ApiResponse<File[]>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Items from |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to fetch files from |
| `inlineFiles` | `boolean \| undefined` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`File[]`](../../doc/models/file.md).

## Example Usage

```ts
const vaultUuid = '00002186-0000-0000-0000-000000000000';

const itemUuid = '0000141a-0000-0000-0000-000000000000';

const inlineFiles = true;

try {
  const response = await filesApi.getItemFiles(
    vaultUuid,
    itemUuid,
    inlineFiles
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | Item not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 413 | File content too large to display | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Get Details of File by Id

```ts
async getDetailsOfFileById(
  vaultUuid: string,
  itemUuid: string,
  fileUuid: string,
  inlineFiles?: boolean,
  requestOptions?: RequestOptions
): Promise<ApiResponse<File>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Item from |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to fetch File from |
| `fileUuid` | `string` | Template, Required | The UUID of the File to fetch |
| `inlineFiles` | `boolean \| undefined` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`File`](../../doc/models/file.md).

## Example Usage

```ts
const vaultUuid = '00002186-0000-0000-0000-000000000000';

const itemUuid = '0000141a-0000-0000-0000-000000000000';

const fileUuid = '000008e0-0000-0000-0000-000000000000';

const inlineFiles = true;

try {
  const response = await filesApi.getDetailsOfFileById(
    vaultUuid,
    itemUuid,
    fileUuid,
    inlineFiles
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 403 | Unauthorized access | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | File not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 413 | File content too large to display | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Download File by ID

```ts
async downloadFileById(
  vaultUuid: string,
  itemUuid: string,
  fileUuid: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<NodeJS.ReadableStream | Blob>>
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault the item is in |
| `itemUuid` | `string` | Template, Required | The UUID of the Item the File is in |
| `fileUuid` | `string` | Template, Required | UUID of the file to get content from |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type `NodeJS.ReadableStream | Blob`.

## Example Usage

```ts
const vaultUuid = '00002186-0000-0000-0000-000000000000';

const itemUuid = '0000141a-0000-0000-0000-000000000000';

const fileUuid = 'fileUuid2';

try {
  const response = await filesApi.downloadFileById(
    vaultUuid,
    itemUuid,
    fileUuid
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorResponseError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 404 | File not found | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

