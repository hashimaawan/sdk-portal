
# Storage Type Enum

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageTypeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `NETWORK` |

## Example

```php
use HetznerCloudAPILib\Models\StorageTypeEnum;

$storageType = StorageTypeEnum::LOCAL;
```

