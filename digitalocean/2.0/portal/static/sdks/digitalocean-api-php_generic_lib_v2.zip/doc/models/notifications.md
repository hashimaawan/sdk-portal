
# Notifications

The notification settings for a trigger alert.

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Notifications`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `email` | `string[]` | Required | An email to notify on an alert trigger. | getEmail(): array | setEmail(array email): void |
| `slack` | [`Slack[]`](../../doc/models/slack.md) | Required | Slack integration details. | getSlack(): array | setSlack(array slack): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\NotificationsBuilder;
use DigitalOceanApiLib\Models\Builders\SlackBuilder;
use DigitalOceanApiLib\ApiHelper;

$notifications = NotificationsBuilder::init(
    [
        'bob@example.com'
    ],
    [
        SlackBuilder::init(
            'Production Alerts',
            'https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ'
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

