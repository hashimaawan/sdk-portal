
# Result Set Metadata

The metadata that describes the column structure and data types of a table of query results. To return a <code>ResultSetMetadata</code> object, use <a>GetQueryResults</a>.

## Structure

`ResultSetMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ColumnInfo` | [`List<ColumnInfo>`](../../doc/models/column-info.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

ResultSetMetadata resultSetMetadata = new ResultSetMetadata
{
    ColumnInfo = new List<ColumnInfo>
    {
        new ColumnInfo
        {
            Name = "Name6",
            Type = "Type6",
            CatalogName = "CatalogName0",
            SchemaName = "SchemaName0",
            TableName = "TableName2",
            Label = "Label4",
            Precision = 48,
        },
        new ColumnInfo
        {
            Name = "Name6",
            Type = "Type6",
            CatalogName = "CatalogName0",
            SchemaName = "SchemaName0",
            TableName = "TableName2",
            Label = "Label4",
            Precision = 48,
        },
    },
};
```

