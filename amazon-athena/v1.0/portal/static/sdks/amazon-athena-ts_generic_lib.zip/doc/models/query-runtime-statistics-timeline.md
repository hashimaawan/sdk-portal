
# Query Runtime Statistics Timeline

Timeline statistics such as query queue time, planning time, execution time, service processing time, and total execution time.

*This model accepts additional fields of type unknown.*

## Structure

`QueryRuntimeStatisticsTimeline`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryQueueTimeInMillis` | `number \| undefined` | Optional | - |
| `queryPlanningTimeInMillis` | `number \| undefined` | Optional | - |
| `engineExecutionTimeInMillis` | `number \| undefined` | Optional | - |
| `serviceProcessingTimeInMillis` | `number \| undefined` | Optional | - |
| `totalExecutionTimeInMillis` | `number \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { QueryRuntimeStatisticsTimeline } from 'amazon-athenalib';

const queryRuntimeStatisticsTimeline: QueryRuntimeStatisticsTimeline = {
  queryQueueTimeInMillis: 122,
  queryPlanningTimeInMillis: 48,
  engineExecutionTimeInMillis: 78,
  serviceProcessingTimeInMillis: 96,
  totalExecutionTimeInMillis: 140,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

