# Activity

Access API Request Activity

```csharp
ActivityApi activityApi = client.ActivityApi;
```

## Class Name

`ActivityApi`


# Get Api Activity

```csharp
GetApiActivityAsync(
    int? limit = 50,
    int? offset = 0)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `int?` | Query, Optional | How many API Events should be retrieved in a single request.<br><br>**Default**: `50` |
| `offset` | `int?` | Query, Optional | How far into the collection of API Events should the response start<br><br>**Default**: `0` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [List<Models.ApiRequest>](../../doc/models/api-request.md).

## Example Usage

```csharp
int? limit = 10;
int? offset = 50;
try
{
    ApiResponse<List<ApiRequest>> result = await activityApi.GetApiActivityAsync(
        limit,
        offset
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

