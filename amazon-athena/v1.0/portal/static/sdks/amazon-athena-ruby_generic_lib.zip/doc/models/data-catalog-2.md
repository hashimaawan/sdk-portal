
# Data Catalog 2

## Structure

`DataCatalog2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `type` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```ruby
data_catalog2 = DataCatalog2.new(
  'Name4',
  DataCatalogType1Enum::LAMBDA,
  'Description2',
  Parameters.new
)
```

