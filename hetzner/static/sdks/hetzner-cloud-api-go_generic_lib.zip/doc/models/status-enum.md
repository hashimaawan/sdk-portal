
# Status Enum

Status of the Action

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ENUMERROR` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    status := models.StatusEnum_ENUMERROR

}
```

