
# X Amz Target 46 Enum

## Enumeration

`XAmzTarget46Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget46 := models.XAmzTarget46Enum_ENUMAMAZONATHENASTARTCALCULATIONEXECUTION

}
```

