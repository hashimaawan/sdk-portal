
# X Amz Target 46 Enum

## Enumeration

`XAmzTarget46Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget46Enum;

$xAmzTarget46 = XAmzTarget46Enum::ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION;
```

