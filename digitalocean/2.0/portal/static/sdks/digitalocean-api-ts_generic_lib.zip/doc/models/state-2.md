
# State 2

A string indicating the current status of the cluster.

## Enumeration

`State2`

## Fields

| Name |
|  --- |
| `Running` |
| `Provisioning` |
| `Degraded` |
| `Error` |
| `Deleted` |
| `Upgrading` |
| `Deleting` |

## Example

```ts
import { State2 } from 'digitalocean-apilib';

const state2 = State2.Deleting;
```

