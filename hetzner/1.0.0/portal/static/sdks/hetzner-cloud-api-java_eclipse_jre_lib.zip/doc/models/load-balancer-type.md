
# Load Balancer Type

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancerType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Deprecated` | `String` | Required | Point in time when the Load Balancer type is deprecated (in ISO-8601 format) | String getDeprecated() | setDeprecated(String deprecated) |
| `Description` | `String` | Required | Description of the Load Balancer type | String getDescription() | setDescription(String description) |
| `Id` | `double` | Required | ID of the Load Balancer type | double getId() | setId(double id) |
| `MaxAssignedCertificates` | `double` | Required | Number of SSL Certificates that can be assigned to a single Load Balancer | double getMaxAssignedCertificates() | setMaxAssignedCertificates(double maxAssignedCertificates) |
| `MaxConnections` | `double` | Required | Number of maximum simultaneous open connections | double getMaxConnections() | setMaxConnections(double maxConnections) |
| `MaxServices` | `double` | Required | Number of services a Load Balancer of this type can have | double getMaxServices() | setMaxServices(double maxServices) |
| `MaxTargets` | `double` | Required | Number of targets a single Load Balancer can have | double getMaxTargets() | setMaxTargets(double maxTargets) |
| `Name` | `String` | Required | Unique identifier of the Load Balancer type | String getName() | setName(String name) |
| `Prices` | [`List<Price>`](../../doc/models/price.md) | Required | Prices in different network zones | List<Price> getPrices() | setPrices(List<Price> prices) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.LoadBalancerType;
import cloud.hetzner.api.models.Price;
import cloud.hetzner.api.models.PriceHourly;
import cloud.hetzner.api.models.PriceMonthly;
import java.io.IOException;
import java.util.Arrays;

LoadBalancerType loadBalancerType = new LoadBalancerType.Builder(
    "2016-01-30T23:50:00+00:00",
    "LB11",
    1D,
    10D,
    20000D,
    5D,
    25D,
    "lb11",
    Arrays.asList(
        new Price.Builder(
            "fsn1",
            new PriceHourly.Builder(
                "1.1900000000000000",
                "1.0000000000"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build(),
            new PriceMonthly.Builder(
                "1.1900000000000000",
                "1.0000000000"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

