
# X Amz Target 52

## Enumeration

`XAmzTarget52`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaTerminateSession` |

## Example

```ts
import { XAmzTarget52 } from 'amazon-athenalib';

const xAmzTarget52 = XAmzTarget52.EnumAmazonAthenaTerminateSession;
```

