
# Data Catalog Type 3

Specifies the type of data catalog to update. Specify <code>LAMBDA</code> for a federated catalog, <code>HIVE</code> for an external hive metastore, or <code>GLUE</code> for an Glue Data Catalog.

## Enumeration

`DataCatalogType3`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```python
from amazonathena.models.data_catalog_type_3 import DataCatalogType3

data_catalog_type_3 = DataCatalogType3.GLUE
```

