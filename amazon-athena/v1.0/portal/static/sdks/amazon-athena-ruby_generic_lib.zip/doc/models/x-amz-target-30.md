
# X Amz Target 30

## Enumeration

`XAmzTarget30`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAIMPORTNOTEBOOK` |

## Example

```ruby
x_amz_target30 = XAmzTarget30::ENUM_AMAZONATHENAIMPORTNOTEBOOK
```

