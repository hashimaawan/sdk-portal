
# List Notebook Metadata Output

## Structure

`ListNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `NotebookMetadataList` | [`List<NotebookMetadata>`](../../doc/models/notebook-metadata.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;
using System.Globalization;

ListNotebookMetadataOutput listNotebookMetadataOutput = new ListNotebookMetadataOutput
{
    NextToken = "NextToken2",
    NotebookMetadataList = new List<NotebookMetadata>
    {
        new NotebookMetadata
        {
            NotebookId = "NotebookId4",
            Name = "Name4",
            WorkGroup = "WorkGroup6",
            CreationTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                provider: CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind),
            Type = NotebookType1Enum.IPYNB,
        },
    },
};
```

