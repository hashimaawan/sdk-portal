
# V2 Functions Namespaces Triggers Request 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isEnabled` | `boolean \| undefined` | Optional | Indicates weather the trigger is paused or unpaused. |
| `scheduledDetails` | [`ScheduledDetails \| undefined`](../../doc/models/scheduled-details.md) | Optional | Trigger details for SCHEDULED type, where body is optional. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FunctionsNamespacesTriggersRequest1 } from 'digitalocean-apilib';

const v2FunctionsNamespacesTriggersRequest1: V2FunctionsNamespacesTriggersRequest1 = {
  isEnabled: true,
  scheduledDetails: {
    cron: 'cron2',
    body: {
      name: 'name6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

