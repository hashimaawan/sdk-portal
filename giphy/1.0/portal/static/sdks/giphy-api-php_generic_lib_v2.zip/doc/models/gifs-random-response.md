
# Gifs Random Response

*This model accepts additional fields of type array.*

## Structure

`GifsRandomResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `data` | [`?Gif`](../../doc/models/gif.md) | Optional | - | getData(): ?Gif | setData(?Gif data): void |
| `meta` | [`?Meta`](../../doc/models/meta.md) | Optional | The Meta Object contains basic information regarding the request, whether it was successful, and the response given by the API.  Check `responses` to see a description of types of response codes the API might give you under different cirumstances. | getMeta(): ?Meta | setMeta(?Meta meta): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use GiphyApiLib\Models\Builders\GifsRandomResponseBuilder;
use GiphyApiLib\Models\Builders\GifBuilder;
use GiphyApiLib\Utils\DateTimeHelper;
use GiphyApiLib\ApiHelper;
use GiphyApiLib\Models\Builders\MetaBuilder;

$gifsRandomResponse = GifsRandomResponseBuilder::init()
    ->data(
        GifBuilder::init()
            ->bitlyUrl('bitly_url0')
            ->contentUrl('content_url4')
            ->createDatetime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->embdedUrl('embded_url8')
            ->featuredTags(
                [
                    'featured_tags0'
                ]
            )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->meta(
        MetaBuilder::init()
            ->msg('msg8')
            ->responseId('response_id0')
            ->status(98)
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

