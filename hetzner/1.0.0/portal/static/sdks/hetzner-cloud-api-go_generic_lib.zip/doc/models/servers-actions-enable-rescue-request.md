
# Servers Actions Enable Rescue Request

*This model accepts additional fields of type interface{}.*

## Structure

`ServersActionsEnableRescueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SshKeys` | `[]int` | Optional | Array of SSH key IDs which should be injected into the rescue system. |
| `Type` | [`*models.Type65`](../../doc/models/type-65.md) | Optional | Type of rescue system to boot (default: `linux64`) |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    serversActionsEnableRescueRequest := models.ServersActionsEnableRescueRequest{
        SshKeys:               []int{
            2323,
        },
        Type:                  models.ToPointer(models.Type65_Linux64),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

