
# Type

The object type.

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Artist` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    mType := models.Type_Artist

}
```

