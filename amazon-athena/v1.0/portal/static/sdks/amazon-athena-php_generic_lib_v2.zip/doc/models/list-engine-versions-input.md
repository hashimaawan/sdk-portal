
# List Engine Versions Input

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |
| `maxResults` | `?int` | Optional | **Constraints**: `>= 1`, `<= 10` | getMaxResults(): ?int | setMaxResults(?int maxResults): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListEngineVersionsInputBuilder;

$listEngineVersionsInput = ListEngineVersionsInputBuilder::init()
    ->nextToken('NextToken6')
    ->maxResults(10)
    ->build();
```

