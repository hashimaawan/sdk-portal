
# Sort 8 Enum

## Enumeration

`Sort8Enum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUMIDASC` |
| `ENUMIDDESC` |
| `NAME` |
| `ENUMNAMEASC` |
| `ENUMNAMEDESC` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    sort8 := models.Sort8Enum_ENUMNAMEASC

}
```

