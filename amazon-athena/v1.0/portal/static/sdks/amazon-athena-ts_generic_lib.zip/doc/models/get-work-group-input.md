
# Get Work Group Input

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |

## Example

```ts
import { GetWorkGroupInput } from 'amazon-athenalib';

const getWorkGroupInput: GetWorkGroupInput = {
  workGroup: 'WorkGroup8',
};
```

