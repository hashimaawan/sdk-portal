
# Statement Type Enum

## Enumeration

`StatementTypeEnum`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```ruby
statement_type = StatementTypeEnum::DDL
```

