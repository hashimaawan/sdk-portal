
# Type Enum

Type of the gif. By default, this is almost always gif

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `GIF` |

## Example

```python
from giphyapi.models.type_enum import TypeEnum

mtype = TypeEnum.GIF
```

