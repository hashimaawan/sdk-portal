
# Locations Response

*This model accepts additional fields of type Object.*

## Structure

`LocationsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Locations` | [`List<Location>`](../../doc/models/location.md) | Required | - | List<Location> getLocations() | setLocations(List<Location> locations) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.Location;
import cloud.hetzner.api.models.LocationsResponse;
import java.io.IOException;
import java.util.Arrays;

LocationsResponse locationsResponse = new LocationsResponse.Builder(
    Arrays.asList(
        new Location.Builder(
            "Falkenstein",
            "DE",
            "Falkenstein DC Park 1",
            1D,
            50.47612D,
            12.370071D,
            "fsn1",
            "eu-central"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

