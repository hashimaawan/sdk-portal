
# Parameter Status Enum

## Enumeration

`ParameterStatusEnum`

## Fields

| Name |
|  --- |
| `Running` |
| `Success` |
| `Error` |

## Example

```ts
import { ParameterStatusEnum } from 'hetzner-cloud-apilib';

const parameterStatus = ParameterStatusEnum.Error;
```

