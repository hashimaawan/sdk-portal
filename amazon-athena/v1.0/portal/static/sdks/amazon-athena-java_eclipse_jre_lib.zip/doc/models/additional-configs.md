
# Additional Configs

*This model accepts additional fields of type String.*

## Structure

`AdditionalConfigs`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AdditionalProperties` | `Map<String, String>` | Optional | **Constraints**: *Maximum Length*: `51200` | String getAdditionalProperty(String key) | additionalProperty(String key, String value) |

## Example (as JSON)

```json
{
  "exampleAdditionalProperty": "AdditionalConfigs_additionalProperties5"
}
```

