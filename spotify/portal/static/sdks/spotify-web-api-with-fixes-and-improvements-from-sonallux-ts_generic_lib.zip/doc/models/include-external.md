
# Include External

If `include_external=audio` is specified it signals that the client can play externally hosted audio content, and marks
the content as playable in the response. By default externally hosted audio content is marked as unplayable in the response.

## Enumeration

`IncludeExternal`

## Fields

| Name |
|  --- |
| `Audio` |

## Example

```ts
import {
  IncludeExternal,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const includeExternal = IncludeExternal.Audio;
```

