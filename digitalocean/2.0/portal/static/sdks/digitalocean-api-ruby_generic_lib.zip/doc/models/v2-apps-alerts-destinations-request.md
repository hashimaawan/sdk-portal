
# V2 Apps Alerts Destinations Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AppsAlertsDestinationsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `emails` | `Array[String]` | Optional | - |
| `slack_webhooks` | [`Array[SlackWebhooksToSendAlertsTo]`](../../doc/models/slack-webhooks-to-send-alerts-to.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_apps_alerts_destinations_request = V2AppsAlertsDestinationsRequest.new(
  emails: [
    'sammy@digitalocean.com'
  ],
  slack_webhooks: [
    SlackWebhooksToSendAlertsTo.new(
      channel: 'channel8',
      url: 'url0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    SlackWebhooksToSendAlertsTo.new(
      channel: 'channel8',
      url: 'url0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    SlackWebhooksToSendAlertsTo.new(
      channel: 'channel8',
      url: 'url0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

