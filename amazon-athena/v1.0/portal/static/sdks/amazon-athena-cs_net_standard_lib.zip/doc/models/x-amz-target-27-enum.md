
# X Amz Target 27 Enum

## Enumeration

`XAmzTarget27Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetSessionStatus` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget27Enum xAmzTarget27 = XAmzTarget27Enum.EnumAmazonAthenaGetSessionStatus;
```

