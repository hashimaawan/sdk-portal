
# Price Monthly 6

## Structure

`PriceMonthly6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `String` | Required | Price with VAT added |
| `net` | `String` | Required | Price without VAT |

## Example

```ruby
price_monthly6 = PriceMonthly6.new(
  '1.1900000000000000',
  '1.0000000000'
)
```

