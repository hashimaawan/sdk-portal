
# X Amz Target 52 Enum

## Enumeration

`XAmzTarget52Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATERMINATESESSION` |

## Example

```python
from amazonathena.models.x_amz_target_52_enum import XAmzTarget52Enum

x_amz_target_52 = XAmzTarget52Enum.ENUM_AMAZONATHENATERMINATESESSION
```

