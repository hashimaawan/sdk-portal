
# List Work Groups Input

## Structure

`ListWorkGroupsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```ts
import { ListWorkGroupsInput } from 'amazon-athenalib';

const listWorkGroupsInput: ListWorkGroupsInput = {
  nextToken: 'NextToken8',
  maxResults: 50,
};
```

