
# V2 Apps Rollback Validate Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2AppsRollbackValidateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`Error`](../../doc/models/error.md) | Optional | - |
| `valid` | `bool` | Optional | Indicates whether the app can be rolled back to the specified deployment. |
| `warnings` | [`List[Warning]`](../../doc/models/warning.md) | Optional | Contains a list of warnings that may cause the rollback to run under unideal circumstances. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.code import Code
from digitaloceanapi.models.error import Error
from digitaloceanapi.models.v_2_apps_rollback_validate_response import V2AppsRollbackValidateResponse
from digitaloceanapi.models.warning import Warning

v_2_apps_rollback_validate_response = V2AppsRollbackValidateResponse(
    error=Error(
        code=Code.INCOMPATIBLE_PHASE,
        components=[
            'components3'
        ],
        message='message4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    valid=False,
    warnings=[
        Warning(
            code=Code.EXCEEDED_REVISION_LIMIT,
            components=[
                'components3'
            ],
            message='message4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Warning(
            code=Code.EXCEEDED_REVISION_LIMIT,
            components=[
                'components3'
            ],
            message='message4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Warning(
            code=Code.EXCEEDED_REVISION_LIMIT,
            components=[
                'components3'
            ],
            message='message4',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

