
# V2 Images Actions Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ImagesActionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type15`](../../doc/models/type-15.md) | Required | The action to be taken on the image. Can be either `convert` or `transfer`. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type15, V2ImagesActionsRequest } from 'digitalocean-apilib';

const v2ImagesActionsRequest: V2ImagesActionsRequest = {
  type: Type15.Convert,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

