
# Log Error Verbosity

Controls the amount of detail written in the server log for each message that is logged.

## Enumeration

`LogErrorVerbosity`

## Fields

| Name |
|  --- |
| `TERSE` |
| `DEFAULT_` |
| `VERBOSE` |

## Example

```php
use DigitalOceanApiLib\Models\LogErrorVerbosity;

$logErrorVerbosity = LogErrorVerbosity::DEFAULT_;
```

