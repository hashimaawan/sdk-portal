
# Health Status

## Structure

`HealthStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ListenPort` | `int?` | Optional | - |
| `Status` | [`Status30Enum?`](../../doc/models/status-30-enum.md) | Optional | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

HealthStatus healthStatus = new HealthStatus
{
    ListenPort = 443,
    Status = Status30Enum.Healthy,
};
```

