
# Custom Query Parameter



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| api_key | `str` | - | `api_key` |



**Note:** Auth credentials can be set using `CustomQueryAuthenticationCredentials` object, passed in as named parameter `custom_query_authentication_credentials` in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```python
from giphyapi.giphyapi_client import GiphyapiClient
from giphyapi.http.auth.custom_query_authentication import CustomQueryAuthenticationCredentials

client = GiphyapiClient(
    custom_query_authentication_credentials=CustomQueryAuthenticationCredentials(
        api_key='api_key'
    )
)
```


