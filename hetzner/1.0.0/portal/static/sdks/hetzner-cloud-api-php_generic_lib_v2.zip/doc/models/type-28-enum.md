
# Type 28 Enum

Type of the algorithm

## Enumeration

`Type28Enum`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```php
use HetznerCloudAPILib\Models\Type28Enum;

$type28 = Type28Enum::ROUND_ROBIN;
```

