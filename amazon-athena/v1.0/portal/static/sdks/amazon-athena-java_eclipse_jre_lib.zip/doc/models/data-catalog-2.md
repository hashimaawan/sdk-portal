
# Data Catalog 2

*This model accepts additional fields of type Object.*

## Structure

`DataCatalog2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getName() | setName(String name) |
| `Description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getDescription() | setDescription(String description) |
| `Type` | [`DataCatalogType1`](../../doc/models/data-catalog-type-1.md) | Required | - | DataCatalogType1 getType() | setType(DataCatalogType1 type) |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - | Parameters getParameters() | setParameters(Parameters parameters) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.models.DataCatalog2;
import com.amazonaws.useast1.athena.models.DataCatalogType1;
import com.amazonaws.useast1.athena.models.Parameters;
import java.io.IOException;

DataCatalog2 dataCatalog2 = new DataCatalog2.Builder(
    "Name6",
    DataCatalogType1.LAMBDA
)
.description("Description0")
.parameters(new Parameters.Builder()
    .additionalProperty("exampleAdditionalProperty", "Parameters_additionalProperties2")
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

