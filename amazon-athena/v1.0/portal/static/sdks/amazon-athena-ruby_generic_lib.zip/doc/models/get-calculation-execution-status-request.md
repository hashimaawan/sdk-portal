
# Get Calculation Execution Status Request

## Structure

`GetCalculationExecutionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```ruby
get_calculation_execution_status_request = GetCalculationExecutionStatusRequest.new(
  'CalculationExecutionId0'
)
```

