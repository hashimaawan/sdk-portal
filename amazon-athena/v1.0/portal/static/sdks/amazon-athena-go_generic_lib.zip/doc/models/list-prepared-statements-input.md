
# List Prepared Statements Input

## Structure

`ListPreparedStatementsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listPreparedStatementsInput := models.ListPreparedStatementsInput{
        WorkGroup:            "WorkGroup2",
        NextToken:            models.ToPointer("NextToken0"),
        MaxResults:           models.ToPointer(50),
    }

}
```

