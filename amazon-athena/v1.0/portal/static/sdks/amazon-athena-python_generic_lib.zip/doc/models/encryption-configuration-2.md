
# Encryption Configuration 2

*This model accepts additional fields of type Any.*

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryption_option` | [`EncryptionOption1`](../../doc/models/encryption-option-1.md) | Required | - |
| `kms_key` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.encryption_configuration_2 import EncryptionConfiguration2
from amazonathena.models.encryption_option_1 import EncryptionOption1

encryption_configuration_2 = EncryptionConfiguration2(
    encryption_option=EncryptionOption1.CSE_KMS,
    kms_key='KmsKey4',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

