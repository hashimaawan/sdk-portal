
# Section 1

For files that are in a section, this field describes the section.

*This model accepts additional fields of type Object.*

## Structure

`Section1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
section1 = Section1.new(
  id: 'id2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

