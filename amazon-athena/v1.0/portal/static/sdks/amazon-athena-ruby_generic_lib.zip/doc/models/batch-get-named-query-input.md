
# Batch Get Named Query Input

Contains an array of named query IDs.

## Structure

`BatchGetNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query_ids` | `Array[String]` | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ruby
batch_get_named_query_input = BatchGetNamedQueryInput.new(
  [
    'NamedQueryIds3',
    'NamedQueryIds2',
    'NamedQueryIds1'
  ]
)
```

