
# Layout

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Layout`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `numNodes` | `number \| undefined` | Optional | - |
| `sizes` | `string[] \| undefined` | Optional, Read-only | An array of objects containing the slugs available with various node counts |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Layout } from 'digitalocean-apilib';

const layout: Layout = {
  numNodes: 1,
  sizes: [
    'db-s-1vcpu-1gb',
    'db-s-1vcpu-2gb'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

