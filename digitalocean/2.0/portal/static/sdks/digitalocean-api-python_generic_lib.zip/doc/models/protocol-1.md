
# Protocol 1

The protocol used for health checks sent to the backend Droplets. The possible values are `http`, `https`, or `tcp`.

## Enumeration

`Protocol1`

## Fields

| Name |
|  --- |
| `HTTP` |
| `HTTPS` |
| `TCP` |

## Example

```python
from digitaloceanapi.models.protocol_1 import Protocol1

protocol_1 = Protocol1.TCP
```

