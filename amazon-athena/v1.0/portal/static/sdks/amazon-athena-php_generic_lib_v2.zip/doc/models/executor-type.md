
# Executor Type

## Enumeration

`ExecutorType`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```php
use AmazonAthenaLib\Models\ExecutorType;

$executorType = ExecutorType::GATEWAY;
```

