
# Result Configuration Updates

The information about the updates in the query results, such as output location and encryption configuration for the query results.

## Structure

`ResultConfigurationUpdates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OutputLocation` | `string` | Optional | - |
| `RemoveOutputLocation` | `bool?` | Optional | - |
| `EncryptionConfiguration` | [`EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - |
| `RemoveEncryptionConfiguration` | `bool?` | Optional | - |
| `ExpectedBucketOwner` | `string` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` |
| `RemoveExpectedBucketOwner` | `bool?` | Optional | - |
| `AclConfiguration` | [`AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - |
| `RemoveAclConfiguration` | `bool?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

ResultConfigurationUpdates resultConfigurationUpdates = new ResultConfigurationUpdates
{
    OutputLocation = "OutputLocation6",
    RemoveOutputLocation = false,
    EncryptionConfiguration = new EncryptionConfiguration2
    {
        EncryptionOption = EncryptionOption1Enum.SSES3,
        KmsKey = "KmsKey6",
    },
    RemoveEncryptionConfiguration = false,
    ExpectedBucketOwner = "ExpectedBucketOwner6",
};
```

