
# Internal Tmp Mem Storage Engine

The storage engine for in-memory internal temporary tables.

## Enumeration

`InternalTmpMemStorageEngine`

## Fields

| Name |
|  --- |
| `TEMPTABLE` |
| `MEMORY` |

## Example

```ruby
internal_tmp_mem_storage_engine = InternalTmpMemStorageEngine::TEMPTABLE
```

