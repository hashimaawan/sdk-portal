
# V2 Kubernetes Registry Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2KubernetesRegistryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterUuids` | `string[] \| undefined` | Optional | An array containing the UUIDs of Kubernetes clusters. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2KubernetesRegistryRequest } from 'digitalocean-apilib';

const v2KubernetesRegistryRequest: V2KubernetesRegistryRequest = {
  clusterUuids: [
    'bd5f5959-5e1e-4205-a714-a914373942af',
    '50c2f44c-011d-493e-aee5-361a4a0d1844'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

