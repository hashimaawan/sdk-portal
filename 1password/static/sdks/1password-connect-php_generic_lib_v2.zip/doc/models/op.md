
# Op

## Enumeration

`Op`

## Fields

| Name |
|  --- |
| `ADD` |
| `REMOVE` |
| `REPLACE` |

## Example

```php
use M1PasswordConnectLib\Models\Op;

$op = Op::REMOVE;
```

