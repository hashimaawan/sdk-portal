
# Load Balancers Actions Detach from Network Request

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `float` | Required | ID of an existing network to detach the Load Balancer from |

## Example

```python
from hetznercloudapi.models.load_balancers_actions_detach_from_network_request import LoadBalancersActionsDetachFromNetworkRequest

load_balancers_actions_detach_from_network_request = LoadBalancersActionsDetachFromNetworkRequest(
    network=4711
)
```

