# Placement Groups

```ts
const placementGroupsController = new PlacementGroupsController(client);
```

## Class Name

`PlacementGroupsController`

## Methods

* [Get All Placement Groups](../../doc/controllers/placement-groups.md#get-all-placement-groups)
* [Create a Placement Group](../../doc/controllers/placement-groups.md#create-a-placement-group)
* [Delete a Placement Group](../../doc/controllers/placement-groups.md#delete-a-placement-group)
* [Get a Placement Group](../../doc/controllers/placement-groups.md#get-a-placement-group)
* [Update a Placement Group](../../doc/controllers/placement-groups.md#update-a-placement-group)


# Get All Placement Groups

Returns all PlacementGroup objects.

```ts
async getAllPlacementGroups(
  sort?: SortEnum,
  name?: string,
  labelSelector?: string,
  type?: ParameterType1Enum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PlacementGroupsResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`SortEnum \| undefined`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `string \| undefined` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `string \| undefined` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `type` | [`ParameterType1Enum \| undefined`](../../doc/models/parameter-type-1-enum.md) | Query, Optional | Can be used multiple times. The response will only contain PlacementGroups matching the type. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `placement_groups` key contains an array of PlacementGroup objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`PlacementGroupsResponse`](../../doc/models/placement-groups-response.md).

## Example Usage

```ts
try {
  const response = await placementGroupsController.getAllPlacementGroups();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "placement_groups": [
    {
      "created": "2019-01-08T12:10:00+00:00",
      "id": 897,
      "labels": {
        "key": "value"
      },
      "name": "my Placement Group",
      "servers": [
        4711,
        4712
      ],
      "type": "spread"
    }
  ]
}
```


# Create a Placement Group

Creates a new PlacementGroup.

```ts
async createAPlacementGroup(
  body?: CreatePlacementGroupRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<CreatePlacementGroupResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreatePlacementGroupRequest \| undefined`](../../doc/models/create-placement-group-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**201**: The `PlacementGroup` key contains the PlacementGroup that was just created.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`CreatePlacementGroupResponse`](../../doc/models/create-placement-group-response.md).

## Example Usage

```ts
const body: CreatePlacementGroupRequest = {
  name: 'my Placement Group',
  type: 'spread',
};

try {
  const response = await placementGroupsController.createAPlacementGroup(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [],
    "type": "spread"
  }
}
```


# Delete a Placement Group

Deletes a PlacementGroup.

```ts
async deleteAPlacementGroup(
  id: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the resource |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**204**: PlacementGroup deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ts
const id = 112;

try {
  const response = await placementGroupsController.deleteAPlacementGroup(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```


# Get a Placement Group

Gets a specific PlacementGroup object.

```ts
async getAPlacementGroup(
  id: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PlacementGroupResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the resource |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `placement_group` key contains a PlacementGroup object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`PlacementGroupResponse`](../../doc/models/placement-group-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await placementGroupsController.getAPlacementGroup(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```


# Update a Placement Group

Updates the PlacementGroup properties.

Note that when updating labels, the PlacementGroup’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the PlacementGroup object changes during the request, the response will be a “conflict” error.

```ts
async updateAPlacementGroup(
  id: number,
  body?: UpdatePlacementGroupRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PlacementGroupResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the resource |
| `body` | [`UpdatePlacementGroupRequest \| undefined`](../../doc/models/update-placement-group-request.md) | Body, Optional | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `certificate` key contains the PlacementGroup that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`PlacementGroupResponse`](../../doc/models/placement-group-response.md).

## Example Usage

```ts
const id = 112;

const body: UpdatePlacementGroupRequest = {
  labels: { 'labelkey': 'value' },
  name: 'my Placement Group',
};

try {
  const response = await placementGroupsController.updateAPlacementGroup(
    id,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```

