
# Terminate Session Request

## Structure

`TerminateSessionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```csharp
using AmazonAthena.Standard.Models;

TerminateSessionRequest terminateSessionRequest = new TerminateSessionRequest
{
    SessionId = "SessionId0",
};
```

