
# X Amz Target 7 Enum

## Enumeration

`XAmzTarget7Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL` |

## Example

```python
from amazonathena.models.x_amz_target_7_enum import XAmzTarget7Enum

x_amz_target_7 = XAmzTarget7Enum.ENUM_AMAZONATHENACREATEPRESIGNEDNOTEBOOKURL
```

