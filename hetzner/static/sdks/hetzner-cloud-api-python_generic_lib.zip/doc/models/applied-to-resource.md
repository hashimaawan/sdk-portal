
# Applied to Resource

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `mtype` | [`Type5Enum`](../../doc/models/type-5-enum.md) | Optional | Type of resource referenced |

## Example

```python
from hetznercloudapi.models.applied_to_resource import AppliedToResource
from hetznercloudapi.models.server import Server
from hetznercloudapi.models.type_5_enum import Type5Enum

applied_to_resource = AppliedToResource(
    server=Server(
        id=14
    ),
    mtype=Type5Enum.SERVER
)
```

