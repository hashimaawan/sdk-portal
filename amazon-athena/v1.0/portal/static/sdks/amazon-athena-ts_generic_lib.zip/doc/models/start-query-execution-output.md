
# Start Query Execution Output

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { StartQueryExecutionOutput } from 'amazon-athenalib';

const startQueryExecutionOutput: StartQueryExecutionOutput = {
  queryExecutionId: 'QueryExecutionId0',
};
```

