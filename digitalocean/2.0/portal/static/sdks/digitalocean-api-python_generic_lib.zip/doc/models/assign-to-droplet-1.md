
# Assign to Droplet 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`AssignToDroplet1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_id` | `int` | Required | The ID of the Droplet that the reserved IP will be assigned to. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.assign_to_droplet_1 import AssignToDroplet1

assign_to_droplet_1 = AssignToDroplet1(
    droplet_id=2457247,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

