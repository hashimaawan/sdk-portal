
# Engine Configuration 1

*This model accepts additional fields of type interface{}.*

## Structure

`EngineConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CoordinatorDpuSize` | `*int` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `MaxConcurrentDpus` | `int` | Required | **Constraints**: `>= 2`, `<= 5000` |
| `DefaultExecutorDpuSize` | `*int` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `AdditionalConfigs` | [`*models.AdditionalConfigs`](../../doc/models/additional-configs.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    engineConfiguration1 := models.EngineConfiguration1{
        CoordinatorDpuSize:     models.ToPointer(1),
        MaxConcurrentDpus:      214,
        DefaultExecutorDpuSize: models.ToPointer(1),
        AdditionalConfigs:      models.ToPointer(models.AdditionalConfigs{
            AdditionalProperties:  map[string]string{
                "exampleAdditionalProperty": "AdditionalConfigs_additionalProperties5",
            },
        }),
        AdditionalProperties:   map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

