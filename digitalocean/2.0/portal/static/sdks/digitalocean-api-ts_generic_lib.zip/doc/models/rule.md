
# Rule

## Enumeration

`Rule`

## Fields

| Name |
|  --- |
| `UnspecifiedRule` |
| `CpuUtilization` |
| `MemUtilization` |
| `RestartCount` |
| `DeploymentFailed` |
| `DeploymentLive` |
| `DomainFailed` |
| `DomainLive` |
| `FunctionsActivationCount` |
| `FunctionsAverageDurationMs` |
| `FunctionsErrorRatePerMinute` |
| `FunctionsAverageWaitTimeMs` |
| `FunctionsErrorCount` |
| `FunctionsGbRatePerSecond` |

## Example

```ts
import { Rule } from 'digitalocean-apilib';

const rule = Rule.FunctionsErrorRatePerMinute;
```

