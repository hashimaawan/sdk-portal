
# Protection

Protection configuration for the Resource

*This model accepts additional fields of type Object.*

## Structure

`Protection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete` | `TrueClass \| FalseClass` | Required | If true, prevents the Resource from being deleted |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
protection = Protection.new(
  delete: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

