
# X Amz Target 39

## Enumeration

`XAmzTarget39`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget39;

XAmzTarget39 xAmzTarget39 = XAmzTarget39.ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS;
```

