
# X Amz Target 50 Enum

## Enumeration

`XAmzTarget50Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPQUERYEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget50Enum;

$xAmzTarget50 = XAmzTarget50Enum::ENUM_AMAZONATHENASTOPQUERYEXECUTION;
```

