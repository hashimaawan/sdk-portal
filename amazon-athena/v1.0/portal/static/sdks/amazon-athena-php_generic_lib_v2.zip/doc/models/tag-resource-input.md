
# Tag Resource Input

*This model accepts additional fields of type array.*

## Structure

`TagResourceInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `resourceArn` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` | getResourceArn(): string | setResourceArn(string resourceArn): void |
| `tags` | [`Tag[]`](../../doc/models/tag.md) | Required | - | getTags(): array | setTags(array tags): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\TagResourceInputBuilder;
use AmazonAthenaLib\Models\Builders\TagBuilder;
use AmazonAthenaLib\ApiHelper;

$tagResourceInput = TagResourceInputBuilder::init(
    'ResourceARN6',
    [
        TagBuilder::init()
            ->key('Key0')
            ->value('Value6')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    ]
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

