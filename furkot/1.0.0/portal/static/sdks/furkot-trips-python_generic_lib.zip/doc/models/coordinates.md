
# Coordinates

geographical coordinates of the stop

*This model accepts additional fields of type Any.*

## Structure

`Coordinates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lat` | `float` | Optional | latitude |
| `lon` | `float` | Optional | longitude |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from furkottrips.models.coordinates import Coordinates

coordinates = Coordinates(
    lat=182.98,
    lon=16.08,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

