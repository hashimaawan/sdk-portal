
# Load Balancers Actions Change Protection Request

## Structure

`LoadBalancersActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the Load Balancer from being deleted |

## Example

```ts
import {
  LoadBalancersActionsChangeProtectionRequest,
} from 'hetzner-cloud-apilib';

const loadBalancersActionsChangeProtectionRequest: LoadBalancersActionsChangeProtectionRequest = {
  mDelete: true,
};
```

