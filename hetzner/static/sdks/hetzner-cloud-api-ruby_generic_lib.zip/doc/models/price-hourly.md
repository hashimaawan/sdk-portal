
# Price Hourly

Hourly costs for a Resource in this Location

## Structure

`PriceHourly`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `String` | Required | Price with VAT added |
| `net` | `String` | Required | Price without VAT |

## Example

```ruby
price_hourly = PriceHourly.new(
  '1.1900000000000000',
  '1.0000000000'
)
```

