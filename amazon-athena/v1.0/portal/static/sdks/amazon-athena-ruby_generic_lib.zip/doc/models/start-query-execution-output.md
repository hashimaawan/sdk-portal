
# Start Query Execution Output

*This model accepts additional fields of type Object.*

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
start_query_execution_output = StartQueryExecutionOutput.new(
  query_execution_id: 'QueryExecutionId8',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

