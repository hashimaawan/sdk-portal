# Actions

Actions show the results and progress of asynchronous requests to the API.

```ruby
actions_api = client.actions
```

## Class Name

`ActionsApi`

## Methods

* [Get All Actions](../../doc/controllers/actions.md#get-all-actions)
* [Get an Action](../../doc/controllers/actions.md#get-an-action)


# Get All Actions

Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```ruby
def get_all_actions(id: nil,
                    sort: nil,
                    status: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Query, Optional | Can be used multiple times, the response will contain only Actions with specified IDs |
| `sort` | [`ParameterSort`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatus`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`ActionsResponse`](../../doc/models/actions-response.md).

## Example Usage

```ruby
result = actions_api.get_all_actions

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get an Action

Returns a specific Action object.

```ruby
def get_an_action(id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | ID of the Resource |

## Response Type

**200**: The `action` key in the reply has this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ruby
id = 112

result = actions_api.get_an_action(id)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

