
# Result Reuse Information 2

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reusedPreviousResult` | `boolean` | Required | - |

## Example

```ts
import { ResultReuseInformation2 } from 'amazon-athenalib';

const resultReuseInformation2: ResultReuseInformation2 = {
  reusedPreviousResult: false,
};
```

