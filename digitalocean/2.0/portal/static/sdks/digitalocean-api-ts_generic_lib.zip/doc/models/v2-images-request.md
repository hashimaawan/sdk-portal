
# V2 Images Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ImagesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string \| undefined` | Optional | An optional free-form text field to describe an image. |
| `distribution` | [`Distribution \| undefined`](../../doc/models/distribution.md) | Optional | The name of a custom image's distribution. Currently, the valid values are  `Arch Linux`, `CentOS`, `CoreOS`, `Debian`, `Fedora`, `Fedora Atomic`,  `FreeBSD`, `Gentoo`, `openSUSE`, `RancherOS`, `Rocky Linux`, `Ubuntu`, and `Unknown`.  Any other value will be accepted but ignored, and `Unknown` will be used in its place. |
| `name` | `string` | Required | The display name that has been given to an image.  This is what is shown in the control panel and is generally a descriptive title for the image in question. |
| `region` | [`Region2`](../../doc/models/region-2.md) | Required | The slug identifier for the region where the resource will initially be  available. |
| `tags` | `string[] \| null \| undefined` | Optional | A flat array of tag names as strings to be applied to the resource. Tag names may be for either existing or new tags. |
| `url` | `string` | Required | A URL from which the custom Linux virtual machine image may be retrieved.  The image it points to must be in the raw, qcow2, vhdx, vdi, or vmdk format.  It may be compressed using gzip or bzip2 and must be smaller than 100 GB after being decompressed. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Distribution, Region2, V2ImagesRequest } from 'digitalocean-apilib';

const v2ImagesRequest: V2ImagesRequest = {
  name: 'ubuntu-18.04-minimal',
  region: Region2.Nyc3,
  url: 'http://cloud-images.ubuntu.com/minimal/releases/bionic/release/ubuntu-18.04-minimal-cloudimg-amd64.img',
  description: 'Cloud-optimized image w/ small footprint',
  distribution: Distribution.Ubuntu,
  tags: [
    'base-image',
    'prod'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

