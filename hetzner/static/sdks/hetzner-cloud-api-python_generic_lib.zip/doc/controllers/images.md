# Images

Images are blueprints for your VM disks. They can be of different types:

### System Images

Distribution Images maintained by us, e.g. “Ubuntu 20.04”

### Snapshot Images

Maintained by you, for example “Ubuntu 20.04 with my own settings”. These are billed per GB per month.

### Backup Images

Daily Backups of your Server. Will automatically be created for Servers which have backups enabled (`POST /servers/{id}/actions/enable_backup`)

Bound to exactly one Server. If you delete the Server, you also delete all backups bound to it. You may convert backup Images to snapshot Images to keep them.

These are billed at 20% of your instance price for 7 backup slots.

### App Images

Prebuild images with specific software configurations, e.g. “Wordpress”. All app images are created by us.

```python
images_controller = client.images
```

## Class Name

`ImagesController`

## Methods

* [Get All Images](../../doc/controllers/images.md#get-all-images)
* [Delete an Image](../../doc/controllers/images.md#delete-an-image)
* [Get an Image](../../doc/controllers/images.md#get-an-image)
* [Update an Image](../../doc/controllers/images.md#update-an-image)


# Get All Images

Returns all Image objects. You can select specific Image types only and sort the results by using URI parameters.

```python
def get_all_images(self,
                  sort=None,
                  mtype=None,
                  status=None,
                  bound_to=None,
                  include_deprecated=None,
                  name=None,
                  label_selector=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`SortEnum`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `mtype` | [`Type21Enum`](../../doc/models/type-21-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`Status23Enum`](../../doc/models/status-23-enum.md) | Query, Optional | Can be used multiple times. The response will only contain Images matching the status. |
| `bound_to` | `str` | Query, Optional | Can be used multiple times. Server ID linked to the Image. Only available for Images of type `backup` |
| `include_deprecated` | `bool` | Query, Optional | Can be used multiple times. |
| `name` | `str` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `label_selector` | `str` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `images` key in the reply contains an array of Image objects with this structure

[`ImagesResponse`](../../doc/models/images-response.md)

## Example Usage

```python
result = images_controller.get_all_images()
print(result)
```


# Delete an Image

Deletes an Image. Only Images of type `snapshot` and `backup` can be deleted.

```python
def delete_an_image(self,
                   id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |

## Response Type

**204**: Image deleted

`void`

## Example Usage

```python
id = 112

images_controller.delete_an_image(id)
```


# Get an Image

Returns a specific Image object.

```python
def get_an_image(self,
                id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |

## Response Type

**200**: The `image` key in the reply contains an Image object with this structure

[`ImagesResponse1`](../../doc/models/images-response-1.md)

## Example Usage

```python
id = 112

result = images_controller.get_an_image(id)
print(result)
```


# Update an Image

Updates the Image. You may change the description, convert a Backup Image to a Snapshot Image or change the Image labels. Only Images of type `snapshot` and `backup` can be updated.

Note that when updating labels, the current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```python
def update_an_image(self,
                   id,
                   body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `body` | [`UpdateImageRequest`](../../doc/models/update-image-request.md) | Body, Optional | - |

## Response Type

**200**: The image key in the reply contains the modified Image object

[`ImagesResponse1`](../../doc/models/images-response-1.md)

## Example Usage

```python
id = 112

body = UpdateImageRequest(
    description='My new Image description',
    labels=jsonpickle.decode('{"labelkey":"value"}')
)

result = images_controller.update_an_image(
    id,
    body=body
)
print(result)
```

## Example Response *(as JSON)*

```json
{
  "image": {
    "bound_to": null,
    "build_id": "c313fe40383af26094a5a92026054320ab55abc7",
    "created": "2016-01-30T23:50:00+00:00",
    "created_from": {
      "id": 1,
      "name": "Server"
    },
    "deleted": null,
    "deprecated": "2018-02-28T00:00:00+00:00",
    "description": "My new Image description",
    "disk_size": 10,
    "id": 4711,
    "image_size": 2.3,
    "labels": {
      "labelkey": "value"
    },
    "name": null,
    "os_flavor": "ubuntu",
    "os_version": "20.04",
    "protection": {
      "delete": false
    },
    "rapid_deploy": false,
    "status": "available",
    "type": "snapshot"
  }
}
```

