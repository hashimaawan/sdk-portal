
# Progress 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Progress1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `steps` | [`Array[Object]`](../../doc/models/object.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
progress1 = Progress1.new(
  steps: [
    { 'key1' => 'val1', 'key2' => 'val2' },
    { 'key1' => 'val1', 'key2' => 'val2' }
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

