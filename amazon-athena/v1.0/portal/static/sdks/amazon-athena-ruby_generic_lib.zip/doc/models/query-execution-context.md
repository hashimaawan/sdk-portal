
# Query Execution Context

The database and data catalog context in which the query execution occurs.

## Structure

`QueryExecutionContext`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `catalog` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```ruby
query_execution_context = QueryExecutionContext.new(
  'Database4',
  'Catalog0'
)
```

