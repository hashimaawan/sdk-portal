
# V2 Cdn Endpoints Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endpoints` | [`Endpoint[] \| undefined`](../../doc/models/endpoint.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Ttl, V2CdnEndpointsResponse } from 'digitalocean-apilib';

const v2CdnEndpointsResponse: V2CdnEndpointsResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  endpoints: [
    {
      origin: 'static-images.nyc3.digitaloceanspaces.com',
      certificateId: '892071a0-bb95-49bc-8021-3afd67a210bf',
      createdAt: '2018-07-19T15:04:16Z',
      customDomain: 'static.example.com',
      endpoint: 'static-images.nyc3.cdn.digitaloceanspaces.com',
      id: '19f06b6a-3ace-4315-b086-499a0e521b76',
      ttl: Ttl.Enum3600,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

