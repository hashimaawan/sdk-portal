
# Status 24 Enum

Whether the Image can be used or if it's still being created or unavailable

## Enumeration

`Status24Enum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |
| `UNAVAILABLE` |

## Example

```python
from hetznercloudapi.models.status_24_enum import Status24Enum

status_24 = Status24Enum.UNAVAILABLE
```

