
# Ssh Keys Response 1

*This model accepts additional fields of type Object.*

## Structure

`SshKeysResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SshKey` | [`SshKey`](../../doc/models/ssh-key.md) | Required | - | SshKey getSshKey() | setSshKey(SshKey sshKey) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.SshKey;
import cloud.hetzner.api.models.SshKeysResponse1;
import java.io.IOException;
import java.util.LinkedHashMap;

SshKeysResponse1 sshKeysResponse1 = new SshKeysResponse1.Builder(
    new SshKey.Builder(
        "2016-01-30T23:55:00+00:00",
        "b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f",
        42,
        new LinkedHashMap<String, String>() {{
            put("key0", "labels0");
        }},
        "my-resource",
        "ssh-rsa AAAjjk76kgf...Xt"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

