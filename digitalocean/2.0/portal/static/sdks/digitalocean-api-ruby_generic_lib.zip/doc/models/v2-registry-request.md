
# V2 Registry Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2RegistryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | A globally unique name for the container registry. Must be lowercase and be composed only of numbers, letters and `-`, up to a limit of 63 characters.<br><br>**Constraints**: *Maximum Length*: `63`, *Pattern*: `^[a-z0-9-]{1,63}$` |
| `region` | [`Region6`](../../doc/models/region-6.md) | Optional | Slug of the region where registry data is stored. When not provided, a region will be selected. |
| `subscription_tier_slug` | [`SubscriptionTierSlug`](../../doc/models/subscription-tier-slug.md) | Required | The slug of the subscription tier to sign up for. Valid values can be retrieved using the options endpoint. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_registry_request = V2RegistryRequest.new(
  name: 'example',
  subscription_tier_slug: SubscriptionTierSlug::BASIC,
  region: Region6::FRA1,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

