
# Executor Type 2 Enum

The type of executor used for the application (<code>COORDINATOR</code>, <code>GATEWAY</code>, or <code>WORKER</code>).

## Enumeration

`ExecutorType2Enum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```python
from amazonathena.models.executor_type_2_enum import ExecutorType2Enum

executor_type_2 = ExecutorType2Enum.GATEWAY
```

