
# Filter Definition

A string for searching notebook names.

## Structure

`FilterDefinition`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` | getName(): ?string | setName(?string name): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\FilterDefinitionBuilder;

$filterDefinition = FilterDefinitionBuilder::init()
    ->name('Name2')
    ->build();
```

