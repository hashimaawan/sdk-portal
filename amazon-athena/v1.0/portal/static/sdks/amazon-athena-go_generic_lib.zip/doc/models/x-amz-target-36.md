
# X Amz Target 36

## Enumeration

`XAmzTarget36`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistexecutors` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget36 := models.XAmzTarget36_EnumAmazonathenalistexecutors

}
```

