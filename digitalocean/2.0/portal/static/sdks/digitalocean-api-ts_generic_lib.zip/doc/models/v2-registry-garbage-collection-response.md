
# V2 Registry Garbage Collection Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `garbageCollection` | [`GarbageCollection \| undefined`](../../doc/models/garbage-collection.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Status15,
  V2RegistryGarbageCollectionResponse,
} from 'digitalocean-apilib';

const v2RegistryGarbageCollectionResponse: V2RegistryGarbageCollectionResponse = {
  garbageCollection: {
    blobsDeleted: 40,
    createdAt: '2016-03-13T12:52:32.123Z',
    freedBytes: 86,
    registryName: 'registry_name6',
    status: Status15.Succeeded,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

