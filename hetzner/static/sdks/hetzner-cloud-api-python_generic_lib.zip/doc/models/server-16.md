
# Server 16

Configuration for type Server, required if type is `server`

## Structure

`Server16`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `float` | Required | ID of the Server |

## Example

```python
from hetznercloudapi.models.server_16 import Server16

server_16 = Server16(
    id=80
)
```

