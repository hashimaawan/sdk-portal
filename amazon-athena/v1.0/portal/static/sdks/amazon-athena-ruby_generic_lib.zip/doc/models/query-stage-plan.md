
# Query Stage Plan

## Structure

`QueryStagePlan`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | - |
| `identifier` | `String` | Optional | - |
| `children` | [`Array[QueryStagePlanNode]`](../../doc/models/query-stage-plan-node.md) | Optional | - |
| `remote_sources` | `Array[String]` | Optional | - |

## Example

```ruby
query_stage_plan = QueryStagePlan.new(
  'Name0',
  'Identifier6',
  [
    QueryStagePlanNode.new(
      'Name6',
      'Identifier2',
      [
        QueryStagePlanNode.new(
          nil,
          nil,
          [],
          []
        )
      ],
      [
        'RemoteSources4',
        'RemoteSources5',
        'RemoteSources6'
      ]
    ),
    QueryStagePlanNode.new(
      'Name6',
      'Identifier2',
      [
        QueryStagePlanNode.new(
          nil,
          nil,
          [],
          []
        )
      ],
      [
        'RemoteSources4',
        'RemoteSources5',
        'RemoteSources6'
      ]
    ),
    QueryStagePlanNode.new(
      'Name6',
      'Identifier2',
      [
        QueryStagePlanNode.new(
          nil,
          nil,
          [],
          []
        )
      ],
      [
        'RemoteSources4',
        'RemoteSources5',
        'RemoteSources6'
      ]
    )
  ],
  [
    'RemoteSources8'
  ]
)
```

