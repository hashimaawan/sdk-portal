
# X Amz Target 26

## Enumeration

`XAmzTarget26`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetsession` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget26 := models.XAmzTarget26_EnumAmazonathenagetsession

}
```

