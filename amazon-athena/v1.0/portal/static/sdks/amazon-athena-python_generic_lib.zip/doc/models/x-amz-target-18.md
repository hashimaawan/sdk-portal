
# X Amz Target 18

## Enumeration

`XAmzTarget18`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATACATALOG` |

## Example

```python
from amazonathena.models.x_amz_target_18 import XAmzTarget18

x_amz_target_18 = XAmzTarget18.ENUM_AMAZONATHENAGETDATACATALOG
```

