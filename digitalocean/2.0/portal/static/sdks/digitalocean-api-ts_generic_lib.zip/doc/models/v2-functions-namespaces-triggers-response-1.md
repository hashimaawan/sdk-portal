
# V2 Functions Namespaces Triggers Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trigger` | [`Trigger \| undefined`](../../doc/models/trigger.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FunctionsNamespacesTriggersResponse1 } from 'digitalocean-apilib';

const v2FunctionsNamespacesTriggersResponse1: V2FunctionsNamespacesTriggersResponse1 = {
  trigger: {
    createdAt: 'created_at6',
    mFunction: 'function6',
    isEnabled: false,
    name: 'name8',
    namespace: 'namespace4',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

