
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `0` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`nbastatsapiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `nbastatsapi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "nbastatsapi"
    "net/http"
)

func main() {
    httpConfiguration := nbastatsapi.CreateHttpConfiguration(
        nbastatsapi.WithTimeout(0),
        nbastatsapi.WithTransport(http.DefaultTransport),
        nbastatsapi.WithRetryConfiguration(nbastatsapi.DefaultRetryConfiguration()),
    )
}
```

