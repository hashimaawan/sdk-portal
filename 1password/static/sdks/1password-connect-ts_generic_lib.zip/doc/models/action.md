
# Action

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `Read` |
| `Create` |
| `Update` |
| `Delete` |

## Example

```ts
import { Action } from 'm-1-password-connectlib';

const action = Action.Update;
```

