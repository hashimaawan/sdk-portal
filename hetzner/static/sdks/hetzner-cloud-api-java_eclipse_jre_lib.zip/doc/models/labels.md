
# Labels

User-defined labels (key-value pairs)

## Structure

`Labels`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Labelkey` | `String` | Optional | New label | String getLabelkey() | setLabelkey(String labelkey) |

## Example

```java
import cloud.hetzner.api.models.Labels;

Labels labels = new Labels.Builder()
    .labelkey("value")
    .build();
```

