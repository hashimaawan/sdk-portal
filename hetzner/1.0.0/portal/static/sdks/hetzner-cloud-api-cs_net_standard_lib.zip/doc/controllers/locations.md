# Locations

Datacenters are organized by Locations. Datacenters in the same Location are connected with very low latency links.

```csharp
LocationsController locationsController = client.LocationsController;
```

## Class Name

`LocationsController`

## Methods

* [Get All Locations](../../doc/controllers/locations.md#get-all-locations)
* [Get a Location](../../doc/controllers/locations.md#get-a-location)


# Get All Locations

Returns all Location objects.

```csharp
GetAllLocationsAsync(
    string name = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Query, Optional | Can be used to filter Locations by their name. The response will only contain the Location matching the specified name. |

## Response Type

**200**: The `locations` key in the reply contains an array of Location objects with this structure

[`Task<Models.LocationsResponse>`](../../doc/models/locations-response.md)

## Example Usage

```csharp
try
{
    LocationsResponse result = await locationsController.GetAllLocationsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Location

Returns a specific Location object.

```csharp
GetALocationAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Location |

## Response Type

**200**: The `location` key in the reply contains a Location object with this structure

[`Task<Models.LocationsResponse1>`](../../doc/models/locations-response-1.md)

## Example Usage

```csharp
int id = 112;
try
{
    LocationsResponse1 result = await locationsController.GetALocationAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

