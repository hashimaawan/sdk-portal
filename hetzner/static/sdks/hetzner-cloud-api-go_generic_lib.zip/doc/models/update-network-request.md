
# Update Network Request

## Structure

`UpdateNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Labels` | [`*models.Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `Name` | `*string` | Optional | New network name |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    updateNetworkRequest := models.UpdateNetworkRequest{
        Labels:               models.ToPointer(models.Labels2{
            Labelkey:             models.ToPointer("labelkey4"),
        }),
        Name:                 models.ToPointer("new-name"),
    }

}
```

