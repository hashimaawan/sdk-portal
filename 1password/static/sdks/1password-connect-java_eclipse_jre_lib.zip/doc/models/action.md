
# Action

## Enumeration

`Action`

## Fields

| Name |
|  --- |
| `READ` |
| `CREATE` |
| `UPDATE` |
| `DELETE` |

## Example

```java
import local.m1password.models.Action;

Action action = Action.UPDATE;
```

