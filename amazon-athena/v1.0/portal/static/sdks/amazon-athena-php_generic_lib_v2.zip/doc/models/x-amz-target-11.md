
# X Amz Target 11

## Enumeration

`XAmzTarget11`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENOTEBOOK` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget11;

$xAmzTarget11 = XAmzTarget11::ENUM_AMAZONATHENADELETENOTEBOOK;
```

