
# X Amz Target 33 Enum

## Enumeration

`XAmzTarget33Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTDATACATALOGS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget33 := models.XAmzTarget33Enum_ENUMAMAZONATHENALISTDATACATALOGS

}
```

