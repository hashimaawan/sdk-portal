
# Backup Restore

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`BackupRestore`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `backup_created_at` | `datetime` | Optional | The timestamp of an existing database cluster backup in ISO8601 combined date and time format. The most recent backup will be used if excluded. |
| `database_name` | `str` | Required | The name of an existing database cluster from which the backup will be restored. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.backup_restore import BackupRestore

backup_restore = BackupRestore(
    database_name='backend',
    backup_created_at=dateutil.parser.parse('2019-01-31T19:25:22Z'),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

