
# X Amz Target 4 Enum

## Enumeration

`XAmzTarget4Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATENAMEDQUERY` |

## Example

```python
from amazonathena.models.x_amz_target_4_enum import XAmzTarget4Enum

x_amz_target_4 = XAmzTarget4Enum.ENUM_AMAZONATHENACREATENAMEDQUERY
```

