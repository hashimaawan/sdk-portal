
# Type 2

The object type: "track".

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `TRACK` |

## Example

```java
import com.spotify.api.models.Type2;

Type2 type2 = Type2.TRACK;
```

