
# Update Image Request

## Structure

`UpdateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Optional | New description of Image |
| `Labels` | `object` | Optional | User-defined labels (key-value pairs) |
| `Type` | [`Type24Enum?`](../../doc/models/type-24-enum.md) | Optional | Destination Image type to convert to |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using HetznerCloudAPI.Standard.Utilities;

UpdateImageRequest updateImageRequest = new UpdateImageRequest
{
    Description = "My new Image description",
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Type = Type24Enum.Snapshot,
};
```

