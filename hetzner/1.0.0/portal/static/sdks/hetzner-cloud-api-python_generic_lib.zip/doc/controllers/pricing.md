# Pricing

Returns prices for resources.

```python
pricing_api = client.pricing
```

## Class Name

`PricingApi`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```python
def get_all_prices(self)
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`PricingResponse`](../../doc/models/pricing-response.md).

## Example Usage

```python
result = pricing_api.get_all_prices()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

