
# Type 22 Enum

Type of the Image

## Enumeration

`Type22Enum`

## Fields

| Name |
|  --- |
| `System` |
| `App` |
| `Snapshot` |
| `Backup` |
| `Temporary` |

## Example

```ts
import { Type22Enum } from 'hetzner-cloud-apilib';

const type22 = Type22Enum.Temporary;
```

