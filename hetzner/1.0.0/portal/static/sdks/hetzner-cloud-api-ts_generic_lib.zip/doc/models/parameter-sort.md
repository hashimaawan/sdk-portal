
# Parameter Sort

## Enumeration

`ParameterSort`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Command` |
| `EnumCommandasc` |
| `EnumCommanddesc` |
| `Status` |
| `EnumStatusasc` |
| `EnumStatusdesc` |
| `Progress` |
| `EnumProgressasc` |
| `EnumProgressdesc` |
| `Started` |
| `EnumStartedasc` |
| `EnumStarteddesc` |
| `Finished` |
| `EnumFinishedasc` |
| `EnumFinisheddesc` |

## Example

```ts
import { ParameterSort } from 'hetzner-cloud-apilib';

const parameterSort = ParameterSort.EnumStatusdesc;
```

