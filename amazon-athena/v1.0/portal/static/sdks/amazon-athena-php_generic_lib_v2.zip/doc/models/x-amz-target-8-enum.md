
# X Amz Target 8 Enum

## Enumeration

`XAmzTarget8Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEWORKGROUP` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget8Enum;

$xAmzTarget8 = XAmzTarget8Enum::ENUM_AMAZONATHENACREATEWORKGROUP;
```

