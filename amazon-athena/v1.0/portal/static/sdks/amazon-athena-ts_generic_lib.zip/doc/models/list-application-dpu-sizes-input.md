
# List Application Dpu Sizes Input

*This model accepts additional fields of type unknown.*

## Structure

`ListApplicationDpuSizesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ListApplicationDpuSizesInput } from 'amazon-athenalib';

const listApplicationDpuSizesInput: ListApplicationDpuSizesInput = {
  maxResults: 56,
  nextToken: 'NextToken6',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

