
# Time Series

## Structure

`TimeSeries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `values` | List[List[float \| str]] | Required | This is 2d List of a container for one-of cases. |

## Example

```python
from hetznercloudapi.models.time_series import TimeSeries

time_series = TimeSeries(
    values=[
        [
            161.02,
            161.03
        ],
        [
            161.02,
            161.03
        ]
    ]
)
```

