
# Result Reuse by Age Configuration

Specifies whether previous query results are reused, and if so, their maximum age.

*This model accepts additional fields of type interface{}.*

## Structure

`ResultReuseByAgeConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Enabled` | `bool` | Required | - |
| `MaxAgeInMinutes` | `*int` | Optional | **Constraints**: `>= 0`, `<= 10080` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    resultReuseByAgeConfiguration := models.ResultReuseByAgeConfiguration{
        Enabled:               false,
        MaxAgeInMinutes:       models.ToPointer(134),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

