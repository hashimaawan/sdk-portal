
# Parameter Status Enum

## Enumeration

`ParameterStatusEnum`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `SUCCESS` |
| `ENUMERROR` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    parameterStatus := models.ParameterStatusEnum_ENUMERROR

}
```

