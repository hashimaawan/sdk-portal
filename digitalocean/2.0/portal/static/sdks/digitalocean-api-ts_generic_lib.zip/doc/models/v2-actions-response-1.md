
# V2 Actions Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ActionsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action \| undefined`](../../doc/models/action.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2ActionsResponse1 } from 'digitalocean-apilib';

const v2ActionsResponse1: V2ActionsResponse1 = {
  action: {
    completedAt: '2016-03-13T12:52:32.123Z',
    id: 238,
    region: {
      available: false,
      features: [
        'features7',
        'features8',
        'features9'
      ],
      name: 'name6',
      sizes: [
        'sizes6'
      ],
      slug: 'slug0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    regionSlug: 'region_slug0',
    resourceId: 66,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

