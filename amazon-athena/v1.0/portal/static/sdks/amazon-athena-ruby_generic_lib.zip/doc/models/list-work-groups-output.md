
# List Work Groups Output

## Structure

`ListWorkGroupsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_groups` | [`Array[WorkGroupSummary]`](../../doc/models/work-group-summary.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `50` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_work_groups_output = ListWorkGroupsOutput.new(
  [
    WorkGroupSummary.new(
      'Name4',
      WorkGroupState1Enum::ENABLED,
      'Description0',
      DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      EngineVersion1.new(
        'SelectedEngineVersion4',
        'EffectiveEngineVersion6'
      )
    )
  ],
  'NextToken2'
)
```

