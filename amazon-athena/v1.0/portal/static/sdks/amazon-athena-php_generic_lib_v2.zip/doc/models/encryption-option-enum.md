
# Encryption Option Enum

## Enumeration

`EncryptionOptionEnum`

## Fields

| Name |
|  --- |
| `SSE_S3` |
| `SSE_KMS` |
| `CSE_KMS` |

## Example

```php
use AmazonAthenaLib\Models\EncryptionOptionEnum;

$encryptionOption = EncryptionOptionEnum::SSE_S3;
```

