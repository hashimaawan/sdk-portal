
# Status 23

## Enumeration

`Status23`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |

## Example

```java
import cloud.hetzner.api.models.Status23;

Status23 status23 = Status23.AVAILABLE;
```

