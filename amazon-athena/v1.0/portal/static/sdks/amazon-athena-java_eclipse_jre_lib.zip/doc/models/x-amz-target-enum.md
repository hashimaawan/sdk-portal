
# X Amz Target Enum

## Enumeration

`XAmzTargetEnum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETNAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTargetEnum;

XAmzTargetEnum xAmzTarget = XAmzTargetEnum.ENUM_AMAZONATHENABATCHGETNAMEDQUERY;
```

