
# X Amz Target 59

## Enumeration

`XAmzTarget59`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEWORKGROUP` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget59;

XAmzTarget59 xAmzTarget59 = XAmzTarget59.ENUM_AMAZONATHENAUPDATEWORKGROUP;
```

