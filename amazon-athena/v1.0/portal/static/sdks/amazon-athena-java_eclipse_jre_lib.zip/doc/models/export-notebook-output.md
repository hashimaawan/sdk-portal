
# Export Notebook Output

## Structure

`ExportNotebookOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NotebookMetadata` | [`NotebookMetadata1`](../../doc/models/notebook-metadata-1.md) | Optional | - | NotebookMetadata1 getNotebookMetadata() | setNotebookMetadata(NotebookMetadata1 notebookMetadata) |
| `Payload` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `10485760` | String getPayload() | setPayload(String payload) |

## Example

```java
import com.amazonaws.useast1.athena.DateTimeHelper;
import com.amazonaws.useast1.athena.models.ExportNotebookOutput;
import com.amazonaws.useast1.athena.models.NotebookMetadata1;
import com.amazonaws.useast1.athena.models.NotebookType1Enum;

ExportNotebookOutput exportNotebookOutput = new ExportNotebookOutput.Builder()
    .notebookMetadata(new NotebookMetadata1.Builder()
        .notebookId("NotebookId0")
        .name("Name0")
        .workGroup("WorkGroup2")
        .creationTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .type(NotebookType1Enum.IPYNB)
        .build())
    .payload("Payload2")
    .build();
```

