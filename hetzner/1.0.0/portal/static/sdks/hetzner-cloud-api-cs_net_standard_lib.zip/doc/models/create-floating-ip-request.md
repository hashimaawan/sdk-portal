
# Create Floating Ip Request

*This model accepts additional fields of type object.*

## Structure

`CreateFloatingIpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Optional | - |
| `HomeLocation` | `string` | Optional | Home Location (routing is optimized for that Location). Only optional if Server argument is passed. |
| `Labels` | `object` | Optional | User-defined labels (key-value pairs) |
| `Name` | `string` | Optional | - |
| `Server` | `int?` | Optional | Server to assign the Floating IP to |
| `Type` | [`Type17`](../../doc/models/type-17.md) | Required | Floating IP type |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;

CreateFloatingIpRequest createFloatingIpRequest = new CreateFloatingIpRequest
{
    Type = Type17.Ipv4,
    Description = "Web Frontend",
    HomeLocation = "fsn1",
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "Web Frontend",
    Server = 42,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

