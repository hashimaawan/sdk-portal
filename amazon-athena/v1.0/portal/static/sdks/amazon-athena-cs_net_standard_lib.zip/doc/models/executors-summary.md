
# Executors Summary

Contains summary information about an executor.

## Structure

`ExecutorsSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ExecutorId` | `string` | Required | **Constraints**: *Maximum Length*: `100000`, *Pattern*: `.*` |
| `ExecutorType` | [`ExecutorType2Enum?`](../../doc/models/executor-type-2-enum.md) | Optional | - |
| `StartDateTime` | `int?` | Optional | - |
| `TerminationDateTime` | `int?` | Optional | - |
| `ExecutorState` | [`ExecutorState3Enum?`](../../doc/models/executor-state-3-enum.md) | Optional | - |
| `ExecutorSize` | `int?` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

ExecutorsSummary executorsSummary = new ExecutorsSummary
{
    ExecutorId = "ExecutorId8",
    ExecutorType = ExecutorType2Enum.WORKER,
    StartDateTime = 52,
    TerminationDateTime = 56,
    ExecutorState = ExecutorState3Enum.CREATING,
    ExecutorSize = 222,
};
```

