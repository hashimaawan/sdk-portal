
# Type 16

An attribute indicating how and if requests from a client will be persistently served by the same backend Droplet. The possible values are `cookies` or `none`.

## Enumeration

`Type16`

## Fields

| Name |
|  --- |
| `COOKIES` |
| `NONE` |

## Example

```ruby
type16 = Type16::COOKIES
```

