
# Create Data Catalog Input

*This model accepts additional fields of type interface{}.*

## Structure

`CreateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Type` | [`models.DataCatalogType1`](../../doc/models/data-catalog-type-1.md) | Required | - |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Parameters` | [`*models.Parameters`](../../doc/models/parameters.md) | Optional | - |
| `Tags` | [`[]models.Tag`](../../doc/models/tag.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    createDataCatalogInput := models.CreateDataCatalogInput{
        Name:                  "Name6",
        Type:                  models.DataCatalogType1_Glue,
        Description:           models.ToPointer("Description2"),
        Parameters:            models.ToPointer(models.Parameters{
            AdditionalProperties:  map[string]string{
                "exampleAdditionalProperty": "Parameters_additionalProperties2",
            },
        }),
        Tags:                  []models.Tag{
            models.Tag{
                Key:                   models.ToPointer("Key0"),
                Value:                 models.ToPointer("Value6"),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            models.Tag{
                Key:                   models.ToPointer("Key0"),
                Value:                 models.ToPointer("Value6"),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
            models.Tag{
                Key:                   models.ToPointer("Key0"),
                Value:                 models.ToPointer("Value6"),
                AdditionalProperties:  map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

