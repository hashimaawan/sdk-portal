
# Load Balancer Algorithm

Algorithm of the Load Balancer

## Structure

`LoadBalancerAlgorithm`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm | Type28Enum getType() | setType(Type28Enum type) |

## Example

```java
import cloud.hetzner.api.models.LoadBalancerAlgorithm;
import cloud.hetzner.api.models.Type28Enum;

LoadBalancerAlgorithm loadBalancerAlgorithm = new LoadBalancerAlgorithm.Builder(
    Type28Enum.ROUND_ROBIN
)
.build();
```

