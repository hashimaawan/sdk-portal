
# Change IP Range Request

## Structure

`ChangeIPRangeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ipRange` | `string` | Required | The new prefix for the whole Network |

## Example

```ts
import { ChangeIPRangeRequest } from 'hetzner-cloud-apilib';

const changeIPRangeRequest: ChangeIPRangeRequest = {
  ipRange: '10.0.0.0/12',
};
```

