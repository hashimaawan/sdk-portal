
# X Amz Target 23 Enum

## Enumeration

`XAmzTarget23Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETQUERYEXECUTION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget23 := models.XAmzTarget23Enum_ENUMAMAZONATHENAGETQUERYEXECUTION

}
```

