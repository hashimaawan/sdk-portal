
# Get Calculation Execution Status Request

*This model accepts additional fields of type array.*

## Structure

`GetCalculationExecutionStatusRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | getCalculationExecutionId(): string | setCalculationExecutionId(string calculationExecutionId): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetCalculationExecutionStatusRequestBuilder;
use AmazonAthenaLib\ApiHelper;

$getCalculationExecutionStatusRequest = GetCalculationExecutionStatusRequestBuilder::init(
    'CalculationExecutionId8'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

