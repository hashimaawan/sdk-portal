
# Track Commit Timestamp

Record commit time of transactions.

## Enumeration

`TrackCommitTimestamp`

## Fields

| Name |
|  --- |
| `Off` |
| `On` |

## Example

```ts
import { TrackCommitTimestamp } from 'digitalocean-apilib';

const trackCommitTimestamp = TrackCommitTimestamp.Off;
```

