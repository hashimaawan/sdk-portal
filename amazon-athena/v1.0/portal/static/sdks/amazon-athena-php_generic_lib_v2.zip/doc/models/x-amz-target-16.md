
# X Amz Target 16

## Enumeration

`XAmzTarget16`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget16;

$xAmzTarget16 = XAmzTarget16::ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE;
```

