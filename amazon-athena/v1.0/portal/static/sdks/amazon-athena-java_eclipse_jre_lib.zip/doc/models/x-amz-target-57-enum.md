
# X Amz Target 57 Enum

## Enumeration

`XAmzTarget57Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget57Enum;

XAmzTarget57Enum xAmzTarget57 = XAmzTarget57Enum.ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA;
```

