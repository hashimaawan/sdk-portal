
# Unprocessed Named Query Id

Information about a named query ID that could not be processed.

## Structure

`UnprocessedNamedQueryId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `named_query_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `error_code` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `error_message` | `str` | Optional | - |

## Example

```python
from amazonathena.models.unprocessed_named_query_id import UnprocessedNamedQueryId

unprocessed_named_query_id = UnprocessedNamedQueryId(
    named_query_id='NamedQueryId8',
    error_code='ErrorCode6',
    error_message='ErrorMessage6'
)
```

