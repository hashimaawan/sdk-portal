
# Type 2

The object type: "track".

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `Track` |

## Example

```ts
import {
  Type2,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const type2 = Type2.Track;
```

