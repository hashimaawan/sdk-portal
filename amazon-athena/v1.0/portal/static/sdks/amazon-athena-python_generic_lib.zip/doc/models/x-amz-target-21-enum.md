
# X Amz Target 21 Enum

## Enumeration

`XAmzTarget21Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_21_enum import XAmzTarget21Enum

x_amz_target_21 = XAmzTarget21Enum.ENUM_AMAZONATHENAGETNOTEBOOKMETADATA
```

