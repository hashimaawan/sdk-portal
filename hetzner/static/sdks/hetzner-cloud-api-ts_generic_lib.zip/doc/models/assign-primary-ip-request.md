
# Assign Primary IP Request

## Structure

`AssignPrimaryIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `assigneeId` | `number` | Required | ID of a resource of type `assignee_type` |
| `assigneeType` | `string` | Required, Constant | Type of resource assigning the Primary IP to<br><br>**Value**: `'server'` |

## Example

```ts
import { AssignPrimaryIPRequest } from 'hetzner-cloud-apilib';

const assignPrimaryIPRequest: AssignPrimaryIPRequest = {
  assigneeId: 4711,
  assigneeType: 'server',
};
```

