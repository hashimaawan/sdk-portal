
# Stickers Random Response

## Structure

`StickersRandomResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`Gif`](../../doc/models/gif.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Optional | The Meta Object contains basic information regarding the request, whether it was successful, and the response given by the API.  Check `responses` to see a description of types of response codes the API might give you under different cirumstances. |

## Example

```python
import dateutil.parser

from giphyapi.models.gif import Gif
from giphyapi.models.meta import Meta
from giphyapi.models.stickers_random_response import StickersRandomResponse

stickers_random_response = StickersRandomResponse(
    data=Gif(
        bitly_url='bitly_url0',
        content_url='content_url4',
        create_datetime=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
        embded_url='embded_url8',
        featured_tags=[
            'featured_tags0'
        ]
    ),
    meta=Meta(
        msg='msg8',
        response_id='response_id0',
        status=98
    )
)
```

