
# Result Set Metadata 2

## Structure

`ResultSetMetadata2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `column_info` | [`Array[ColumnInfo]`](../../doc/models/column-info.md) | Optional | - |

## Example

```ruby
result_set_metadata2 = ResultSetMetadata2.new(
  [
    ColumnInfo.new(
      'Name6',
      'Type6',
      'CatalogName0',
      'SchemaName0',
      'TableName2',
      'Label4',
      48,
      nil,
      envrr
    )
  ]
)
```

