
# Type 39 Enum

Algorithm of the Load Balancer

## Enumeration

`Type39Enum`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```ruby
type39 = Type39Enum::ROUND_ROBIN
```

