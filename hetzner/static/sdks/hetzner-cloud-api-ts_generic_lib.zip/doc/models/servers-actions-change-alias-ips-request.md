
# Servers Actions Change Alias Ips Request

## Structure

`ServersActionsChangeAliasIpsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aliasIps` | `string[]` | Required | New alias IPs to set for this Server |
| `network` | `number` | Required | ID of an existing Network already attached to the Server |

## Example

```ts
import { ServersActionsChangeAliasIpsRequest } from 'hetzner-cloud-apilib';

const serversActionsChangeAliasIpsRequest: ServersActionsChangeAliasIpsRequest = {
  aliasIps: [
    '10.0.1.2'
  ],
  network: 4711,
};
```

