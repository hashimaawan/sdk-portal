
# Executor State

## Enumeration

`ExecutorState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `REGISTERED` |
| `TERMINATING` |
| `TERMINATED` |
| `FAILED` |

## Example

```php
use AmazonAthenaLib\Models\ExecutorState;

$executorState = ExecutorState::TERMINATED;
```

