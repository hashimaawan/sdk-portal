
# Notebook Type 1

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```ruby
notebook_type1 = NotebookType1::IPYNB
```

