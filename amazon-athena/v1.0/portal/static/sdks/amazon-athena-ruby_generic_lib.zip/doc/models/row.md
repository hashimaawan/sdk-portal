
# Row

The rows that make up a query result table.

## Structure

`Row`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | [`Array[Datum]`](../../doc/models/datum.md) | Optional | - |

## Example

```ruby
row = Row.new(
  [
    Datum.new(
      'VarCharValue8'
    )
  ]
)
```

