
# Price 7

*This model accepts additional fields of type array.*

## Structure

`Price7`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `location` | `string` | Required | Name of the Location the price is for | getLocation(): string | setLocation(string location): void |
| `priceHourly` | [`PriceHourly6`](../../doc/models/price-hourly-6.md) | Required | Hourly costs for a Load Balancer type in this network zone | getPriceHourly(): PriceHourly6 | setPriceHourly(PriceHourly6 priceHourly): void |
| `priceMonthly` | [`PriceMonthly8`](../../doc/models/price-monthly-8.md) | Required | Monthly costs for a Load Balancer type in this network zone | getPriceMonthly(): PriceMonthly8 | setPriceMonthly(PriceMonthly8 priceMonthly): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\Price7Builder;
use HetznerCloudApiLib\Models\Builders\PriceHourly6Builder;
use HetznerCloudApiLib\ApiHelper;
use HetznerCloudApiLib\Models\Builders\PriceMonthly8Builder;

$price7 = Price7Builder::init(
    'fsn1',
    PriceHourly6Builder::init(
        '1.1900000000000000',
        '1.0000000000'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build(),
    PriceMonthly8Builder::init(
        '1.1900000000000000',
        '1.0000000000'
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

