
# X Amz Target 32 Enum

## Enumeration

`XAmzTarget32Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListCalculationExecutions` |

## Example

```ts
import { XAmzTarget32Enum } from 'amazon-athenalib';

const xAmzTarget32 = XAmzTarget32Enum.EnumAmazonAthenaListCalculationExecutions;
```

