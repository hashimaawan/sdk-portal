# Actions

Actions show the results and progress of asynchronous requests to the API.

```java
ActionsController actionsController = client.getActionsController();
```

## Class Name

`ActionsController`

## Methods

* [Get All Actions](../../doc/controllers/actions.md#get-all-actions)
* [Get an Action](../../doc/controllers/actions.md#get-an-action)


# Get All Actions

Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```java
CompletableFuture<ActionsResponse> getAllActionsAsync(
    final Integer id,
    final ParameterSortEnum sort,
    final ParameterStatusEnum status)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Query, Optional | Can be used multiple times, the response will contain only Actions with specified IDs |
| `sort` | [`ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```java
actionsController.getAllActionsAsync(null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get an Action

Returns a specific Action object.

```java
CompletableFuture<ActionResponse> getAnActionAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |

## Response Type

**200**: The `action` key in the reply has this structure

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;

actionsController.getAnActionAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

