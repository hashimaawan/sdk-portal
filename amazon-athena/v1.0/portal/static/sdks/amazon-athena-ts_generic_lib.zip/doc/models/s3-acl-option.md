
# S3 Acl Option

## Enumeration

`S3AclOption`

## Fields

| Name |
|  --- |
| `BucketOwnerFullControl` |

## Example

```ts
import { S3AclOption } from 'amazon-athenalib';

const s3AclOption = S3AclOption.BucketOwnerFullControl;
```

