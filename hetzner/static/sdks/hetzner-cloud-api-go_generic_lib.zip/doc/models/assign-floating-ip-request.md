
# Assign Floating IP Request

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `floating_ip_assigned`        | The floating IP is already assigned                           |

## Structure

`AssignFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Server` | `int` | Required | ID of the Server the Floating IP shall be assigned to |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    assignFloatingIPRequest := models.AssignFloatingIPRequest{
        Server:               42,
    }

}
```

