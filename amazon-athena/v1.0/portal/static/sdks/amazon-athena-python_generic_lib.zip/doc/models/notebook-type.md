
# Notebook Type

## Enumeration

`NotebookType`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```python
from amazonathena.models.notebook_type import NotebookType

notebook_type = NotebookType.IPYNB
```

