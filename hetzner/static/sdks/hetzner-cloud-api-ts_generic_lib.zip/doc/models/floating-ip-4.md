
# Floating Ip 4

The cost of one Floating IP per month

## Structure

`FloatingIp4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `priceMonthly` | [`PriceMonthly6`](../../doc/models/price-monthly-6.md) | Required | - |

## Example

```ts
import { FloatingIp4 } from 'hetzner-cloud-apilib';

const floatingIp4: FloatingIp4 = {
  priceMonthly: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
  },
};
```

