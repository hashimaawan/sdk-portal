
# Engine

- MYSQL: MySQL
- PG: PostgreSQL
- REDIS: Redis

## Enumeration

`Engine`

## Fields

| Name |
|  --- |
| `UNSET` |
| `MYSQL` |
| `PG` |
| `REDIS` |

## Example

```java
import com.digitalocean.api.models.Engine;

Engine engine = Engine.PG;
```

