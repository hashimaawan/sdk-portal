
# Encryption Configuration 2

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EncryptionOption` | [`EncryptionOption1Enum`](../../doc/models/encryption-option-1-enum.md) | Required | - | EncryptionOption1Enum getEncryptionOption() | setEncryptionOption(EncryptionOption1Enum encryptionOption) |
| `KmsKey` | `String` | Optional | - | String getKmsKey() | setKmsKey(String kmsKey) |

## Example

```java
import com.amazonaws.useast1.athena.models.EncryptionConfiguration2;
import com.amazonaws.useast1.athena.models.EncryptionOption1Enum;

EncryptionConfiguration2 encryptionConfiguration2 = new EncryptionConfiguration2.Builder(
    EncryptionOption1Enum.SSE_S3
)
.kmsKey("KmsKey2")
.build();
```

