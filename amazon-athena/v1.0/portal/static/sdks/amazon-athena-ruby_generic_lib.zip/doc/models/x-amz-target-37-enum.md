
# X Amz Target 37 Enum

## Enumeration

`XAmzTarget37Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNAMEDQUERIES` |

## Example

```ruby
x_amz_target37 = XAmzTarget37Enum::ENUM_AMAZONATHENALISTNAMEDQUERIES
```

