
# X Amz Target 55 Enum

## Enumeration

`XAmzTarget55Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUpdateNamedQuery` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget55Enum xAmzTarget55 = XAmzTarget55Enum.EnumAmazonAthenaUpdateNamedQuery;
```

