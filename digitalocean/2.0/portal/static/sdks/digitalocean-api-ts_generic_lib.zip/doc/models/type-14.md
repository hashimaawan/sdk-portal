
# Type 14

## Enumeration

`Type14`

## Fields

| Name |
|  --- |
| `Application` |
| `Distribution` |

## Example

```ts
import { Type14 } from 'digitalocean-apilib';

const type14 = Type14.Application;
```

