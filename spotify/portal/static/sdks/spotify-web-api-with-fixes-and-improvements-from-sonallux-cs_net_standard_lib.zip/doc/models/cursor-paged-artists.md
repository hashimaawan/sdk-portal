
# Cursor Paged Artists

*This model accepts additional fields of type object.*

## Structure

`CursorPagedArtists`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Artists` | [`CursorPagingSimplifiedArtistObject`](../../doc/models/cursor-paging-simplified-artist-object.md) | Required | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Utilities;

CursorPagedArtists cursorPagedArtists = new CursorPagedArtists
{
    Artists = new CursorPagingSimplifiedArtistObject
    {
        Href = "href2",
        Limit = 214,
        Next = "next2",
        Cursors = new CursorObject
        {
            After = "after8",
            Before = "before6",
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
        Total = 52,
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

