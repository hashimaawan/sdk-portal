
# Application DPU Sizes

Contains the application runtime IDs and their supported DPU sizes.

## Structure

`ApplicationDPUSizes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ApplicationRuntimeId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | String getApplicationRuntimeId() | setApplicationRuntimeId(String applicationRuntimeId) |
| `SupportedDPUSizes` | `List<Integer>` | Optional | - | List<Integer> getSupportedDPUSizes() | setSupportedDPUSizes(List<Integer> supportedDPUSizes) |

## Example

```java
import com.amazonaws.useast1.athena.models.ApplicationDPUSizes;
import java.util.Arrays;

ApplicationDPUSizes applicationDPUSizes = new ApplicationDPUSizes.Builder()
    .applicationRuntimeId("ApplicationRuntimeId2")
    .supportedDPUSizes(Arrays.asList(
        57
    ))
    .build();
```

