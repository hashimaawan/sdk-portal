
# Server

## Structure

`Server`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Resource | int getId() | setId(int id) |

## Example

```java
import cloud.hetzner.api.models.Server;

Server server = new Server.Builder(
    42
)
.build();
```

