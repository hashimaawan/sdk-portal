
# X Amz Target 16

## Enumeration

`XAmzTarget16`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetcalculationexecutioncode` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget16 := models.XAmzTarget16_EnumAmazonathenagetcalculationexecutioncode

}
```

