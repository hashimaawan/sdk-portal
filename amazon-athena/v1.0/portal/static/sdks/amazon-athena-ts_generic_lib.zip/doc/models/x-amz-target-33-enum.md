
# X Amz Target 33 Enum

## Enumeration

`XAmzTarget33Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListDataCatalogs` |

## Example

```ts
import { XAmzTarget33Enum } from 'amazon-athenalib';

const xAmzTarget33 = XAmzTarget33Enum.EnumAmazonAthenaListDataCatalogs;
```

