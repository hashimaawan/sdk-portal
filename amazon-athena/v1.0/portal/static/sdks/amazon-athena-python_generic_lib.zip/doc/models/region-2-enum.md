
# Region 2 Enum

## Enumeration

`Region2Enum`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```python
from amazonathena.models.region_2_enum import Region2Enum

region_2 = Region2Enum.CNNORTH1
```

