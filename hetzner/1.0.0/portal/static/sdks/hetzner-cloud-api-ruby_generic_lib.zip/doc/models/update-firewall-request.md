
# Update Firewall Request

*This model accepts additional fields of type Object.*

## Structure

`UpdateFirewallRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New Firewall name |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
update_firewall_request = UpdateFirewallRequest.new(
  labels: { 'labelkey' => 'value' },
  name: 'new-name',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

