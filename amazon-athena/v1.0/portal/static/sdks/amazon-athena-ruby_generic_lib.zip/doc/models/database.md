
# Database

Contains metadata information for a database in a data catalog.

## Structure

`Database`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```ruby
database = Database.new(
  'Name0',
  'Description6',
  Parameters.new
)
```

