
# Update Certificate Request

*This model accepts additional fields of type unknown.*

## Structure

`UpdateCertificateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `unknown \| undefined` | Optional | User-defined labels (key-value pairs) |
| `name` | `string \| undefined` | Optional | New Certificate name |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { UpdateCertificateRequest } from 'hetzner-cloud-apilib';

const updateCertificateRequest: UpdateCertificateRequest = {
  labels: { 'labelkey': 'value' },
  name: 'my website cert',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

