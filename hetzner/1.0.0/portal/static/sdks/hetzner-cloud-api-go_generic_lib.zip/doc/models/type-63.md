
# Type 63

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63`

## Fields

| Name |
|  --- |
| `Snapshot` |
| `Backup` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type63 := models.Type63_Snapshot

}
```

