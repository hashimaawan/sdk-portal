
# V2 Apps Components Logs Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AppsComponentsLogsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `historic_urls` | `Array[String]` | Optional | - |
| `live_url` | `String` | Optional | A URL of the real-time live logs. This URL may use either the `https://` or `wss://` protocols and will keep pushing live logs as they become available. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_apps_components_logs_response = V2AppsComponentsLogsResponse.new(
  historic_urls: [
    'historic_urls7'
  ],
  live_url: 'ws://logs/build',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

