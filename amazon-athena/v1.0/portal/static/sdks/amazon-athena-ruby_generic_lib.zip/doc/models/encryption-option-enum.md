
# Encryption Option Enum

## Enumeration

`EncryptionOptionEnum`

## Fields

| Name |
|  --- |
| `SSE_S3` |
| `SSE_KMS` |
| `CSE_KMS` |

## Example

```ruby
encryption_option = EncryptionOptionEnum::SSE_KMS
```

