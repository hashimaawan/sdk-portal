
# X Amz Target 59

## Enumeration

`XAmzTarget59`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaupdateworkgroup` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget59 := models.XAmzTarget59_EnumAmazonathenaupdateworkgroup

}
```

