
# Resource Type

## Enumeration

`ResourceType`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `VOLUME` |

## Example

```java
import com.digitalocean.api.models.ResourceType;

ResourceType resourceType = ResourceType.DROPLET;
```

