
# Type 19

The type of health check to perform.

## Enumeration

`Type19`

## Fields

| Name |
|  --- |
| `PING` |
| `HTTP` |
| `HTTPS` |

## Example

```java
import com.digitalocean.api.models.Type19;

Type19 type19 = Type19.HTTP;
```

