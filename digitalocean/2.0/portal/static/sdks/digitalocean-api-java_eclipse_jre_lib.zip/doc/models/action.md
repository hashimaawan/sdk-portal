
# Action

*This model accepts additional fields of type Object.*

## Structure

`Action`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CompletedAt` | `LocalDateTime` | Optional | A time value given in ISO8601 combined date and time format that represents when the action was completed. | LocalDateTime getCompletedAt() | setCompletedAt(LocalDateTime completedAt) |
| `Id` | `Integer` | Optional | A unique numeric ID that can be used to identify and reference an action. | Integer getId() | setId(Integer id) |
| `Region` | [`Region`](../../doc/models/region.md) | Optional | - | Region getRegion() | setRegion(Region region) |
| `RegionSlug` | `String` | Optional | - | String getRegionSlug() | setRegionSlug(String regionSlug) |
| `ResourceId` | `Integer` | Optional | A unique identifier for the resource that the action is associated with. | Integer getResourceId() | setResourceId(Integer resourceId) |
| `ResourceType` | `String` | Optional | The type of resource that the action is associated with. | String getResourceType() | setResourceType(String resourceType) |
| `StartedAt` | `LocalDateTime` | Optional | A time value given in ISO8601 combined date and time format that represents when the action was initiated. | LocalDateTime getStartedAt() | setStartedAt(LocalDateTime startedAt) |
| `Status` | [`Status1`](../../doc/models/status-1.md) | Optional | The current status of the action. This can be "in-progress", "completed", or "errored".<br><br>**Default**: `Status1.INPROGRESS` | Status1 getStatus() | setStatus(Status1 status) |
| `Type` | `String` | Optional | This is the type of action that the object represents. For example, this could be "transfer" to represent the state of an image transfer action. | String getType() | setType(String type) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.DateTimeHelper;
import com.digitalocean.api.models.Action;
import com.digitalocean.api.models.Region;
import com.digitalocean.api.models.Status1;
import java.io.IOException;
import java.util.Arrays;

Action action = new Action.Builder()
    .completedAt(DateTimeHelper.fromRfc8601DateTime("2020-11-14T16:30:06Z"))
    .id(36804636)
    .region(new Region.Builder(
        false,
        Arrays.asList(
            "features7",
            "features8",
            "features9"
        ),
        "name6",
        Arrays.asList(
            "sizes6"
        ),
        "slug0"
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build())
    .regionSlug("region_slug0")
    .resourceId(3164444)
    .resourceType("droplet")
    .startedAt(DateTimeHelper.fromRfc8601DateTime("2020-11-14T16:29:21Z"))
    .status(Status1.COMPLETED)
    .type("create")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

