
# Pages 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Pages1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first` | `string \| undefined` | Optional | URI of the first page of the results. |
| `prev` | `string \| undefined` | Optional | URI of the previous page of the results. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Pages1 } from 'digitalocean-apilib';

const pages1: Pages1 = {
  first: 'https://api.digitalocean.com/v2/images?page=1',
  prev: 'https://api.digitalocean.com/v2/images?page=1',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

