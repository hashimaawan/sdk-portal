
# X Amz Target 45

## Enumeration

`XAmzTarget45`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistworkgroups` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget45 := models.XAmzTarget45_EnumAmazonathenalistworkgroups

}
```

