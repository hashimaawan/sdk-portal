
# Applied to Resource

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server` | [`Server \| undefined`](../../doc/models/server.md) | Optional | - |
| `type` | [`Type5Enum \| undefined`](../../doc/models/type-5-enum.md) | Optional | Type of resource referenced |

## Example

```ts
import { AppliedToResource, Type5Enum } from 'hetzner-cloud-apilib';

const appliedToResource: AppliedToResource = {
  server: {
    id: 14,
  },
  type: Type5Enum.Server,
};
```

