
# Stop Query Execution Input

## Structure

`StopQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { StopQueryExecutionInput } from 'amazon-athenalib';

const stopQueryExecutionInput: StopQueryExecutionInput = {
  queryExecutionId: 'QueryExecutionId4',
};
```

