
# V2 Functions Namespaces Triggers Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trigger` | [`Trigger`](../../doc/models/trigger.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.trigger import Trigger
from digitaloceanapi.models.v_2_functions_namespaces_triggers_response_1 import V2FunctionsNamespacesTriggersResponse1

v_2_functions_namespaces_triggers_response_1 = V2FunctionsNamespacesTriggersResponse1(
    trigger=Trigger(
        created_at='created_at6',
        function='function6',
        is_enabled=False,
        name='name8',
        namespace='namespace4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

