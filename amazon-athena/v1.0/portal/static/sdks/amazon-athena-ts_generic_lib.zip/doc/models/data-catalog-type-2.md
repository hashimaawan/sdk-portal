
# Data Catalog Type 2

The data catalog type.

## Enumeration

`DataCatalogType2`

## Fields

| Name |
|  --- |
| `Lambda` |
| `Glue` |
| `Hive` |

## Example

```ts
import { DataCatalogType2 } from 'amazon-athenalib';

const dataCatalogType2 = DataCatalogType2.Lambda;
```

