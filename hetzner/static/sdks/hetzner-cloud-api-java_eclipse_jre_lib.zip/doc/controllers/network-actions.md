# Network Actions

```java
NetworkActionsController networkActionsController = client.getNetworkActionsController();
```

## Class Name

`NetworkActionsController`

## Methods

* [Get All Actions for a Network](../../doc/controllers/network-actions.md#get-all-actions-for-a-network)
* [Add a Route to a Network](../../doc/controllers/network-actions.md#add-a-route-to-a-network)
* [Add a Subnet to a Network](../../doc/controllers/network-actions.md#add-a-subnet-to-a-network)
* [Change IP Range of a Network](../../doc/controllers/network-actions.md#change-ip-range-of-a-network)
* [Change Network Protection](../../doc/controllers/network-actions.md#change-network-protection)
* [Delete a Route from a Network](../../doc/controllers/network-actions.md#delete-a-route-from-a-network)
* [Delete a Subnet from a Network](../../doc/controllers/network-actions.md#delete-a-subnet-from-a-network)
* [Get an Action for a Network](../../doc/controllers/network-actions.md#get-an-action-for-a-network)


# Get All Actions for a Network

Returns all Action objects for a Network. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```java
CompletableFuture<ActionsResponse> getAllActionsForANetworkAsync(
    final int id,
    final ParameterSortEnum sort,
    final ParameterStatusEnum status)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `sort` | [`ParameterSortEnum`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`ActionsResponse`](../../doc/models/actions-response.md)

## Example Usage

```java
int id = 112;

networkActionsController.getAllActionsForANetworkAsync(id, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "add_subnet",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 42,
          "type": "server"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Add a Route to a Network

Adds a route entry to a Network.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ActionResponse> addARouteToANetworkAsync(
    final int id,
    final AddDeleteRouteRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`AddDeleteRouteRequest`](../../doc/models/add-delete-route-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `add_route` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
AddDeleteRouteRequest body = new AddDeleteRouteRequest.Builder(
    "10.100.1.0/24",
    "10.0.1.1"
)
.build();

networkActionsController.addARouteToANetworkAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_route",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Add a Subnet to a Network

Adds a new subnet object to the Network. If you do not specify an `ip_range` for the subnet we will automatically pick the first available /24 range for you if possible.

Note: if the parent Network object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ActionResponse> addASubnetToANetworkAsync(
    final int id,
    final AddSubnetRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`AddSubnetRequest`](../../doc/models/add-subnet-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `add_subnet` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
AddSubnetRequest body = new AddSubnetRequest.Builder(
    "eu-central",
    Type42Enum.SERVER
)
.ipRange("10.0.1.0/24")
.vswitchId(1000)
.build();

networkActionsController.addASubnetToANetworkAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_subnet",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change IP Range of a Network

Changes the IP range of a Network. IP ranges can only be extended and never shrunk. You can only add IPs at the end of an existing IP range. This means that the IP part of your existing range must stay the same and you can only change its netmask.

For example if you have a range `10.0.0.0/16` you want to extend then your new range must also start with the IP `10.0.0.0`. Your CIDR netmask `/16` may change to a number that is smaller than `16` thereby increasing the IP range. So valid entries would be `10.0.0.0/15`, `10.0.0.0/14`, `10.0.0.0/13` and so on.

After changing the IP range you will have to adjust the routes on your connected Servers by either rebooting them or manually changing the routes to your private Network interface.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ActionResponse> changeIPRangeOfANetworkAsync(
    final int id,
    final ChangeIPRangeRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`ChangeIPRangeRequest`](../../doc/models/change-ip-range-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_ip_range` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
ChangeIPRangeRequest body = new ChangeIPRangeRequest.Builder(
    "10.0.0.0/12"
)
.build();

networkActionsController.changeIPRangeOfANetworkAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_ip_range",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Network Protection

Changes the protection configuration of a Network.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ActionResponse> changeNetworkProtectionAsync(
    final int id,
    final ChangeProtectionRequest1 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`ChangeProtectionRequest1`](../../doc/models/change-protection-request-1.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
ChangeProtectionRequest1 body = new ChangeProtectionRequest1.Builder()
    .delete(true)
    .build();

networkActionsController.changeNetworkProtectionAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Delete a Route from a Network

Delete a route entry from a Network.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ActionResponse> deleteARouteFromANetworkAsync(
    final int id,
    final AddDeleteRouteRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`AddDeleteRouteRequest`](../../doc/models/add-delete-route-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `delete_route` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
AddDeleteRouteRequest body = new AddDeleteRouteRequest.Builder(
    "10.100.1.0/24",
    "10.0.1.1"
)
.build();

networkActionsController.deleteARouteFromANetworkAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "delete_route",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Delete a Subnet from a Network

Deletes a single subnet entry from a Network. You cannot delete subnets which still have Servers attached. If you have Servers attached you first need to detach all Servers that use IPs from this subnet before you can delete the subnet.

Note: if the Network object changes during the request, the response will be a “conflict” error.

```java
CompletableFuture<ActionResponse> deleteASubnetFromANetworkAsync(
    final int id,
    final DeleteSubnetRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `body` | [`DeleteSubnetRequest`](../../doc/models/delete-subnet-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `delete_subnet` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
DeleteSubnetRequest body = new DeleteSubnetRequest.Builder(
    "10.0.1.0/24"
)
.build();

networkActionsController.deleteASubnetFromANetworkAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "delete_subnet",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Get an Action for a Network

Returns a specific Action for a Network.

```java
CompletableFuture<ActionResponse> getAnActionForANetworkAsync(
    final int id,
    final int actionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Network |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Network Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
int actionId = 224;

networkActionsController.getAnActionForANetworkAsync(id, actionId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "add_subnet",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "network"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

