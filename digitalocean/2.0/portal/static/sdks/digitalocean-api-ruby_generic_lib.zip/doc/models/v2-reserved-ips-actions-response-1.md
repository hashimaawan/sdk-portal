
# V2 Reserved Ips Actions Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2ReservedIpsActionsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action2`](../../doc/models/action-2.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_reserved_ips_actions_response1 = V2ReservedIpsActionsResponse1.new(
  action: Action2.new(
    completed_at: DateTimeHelper.from_rfc3339('2015-11-12T17:51:14Z'),
    id: 72531856,
    region: Region.new(
      available: true,
      features: [
        'private_networking',
        'backups',
        'ipv6',
        'metadata'
      ],
      name: 'New York 3',
      sizes: [
        's-1vcpu-1gb',
        's-1vcpu-2gb',
        's-1vcpu-3gb',
        's-2vcpu-2gb',
        's-3vcpu-1gb',
        's-2vcpu-4gb',
        's-4vcpu-8gb',
        's-6vcpu-16gb',
        's-8vcpu-32gb',
        's-12vcpu-48gb',
        's-16vcpu-64gb',
        's-20vcpu-96gb',
        's-24vcpu-128gb',
        's-32vcpu-192gb'
      ],
      slug: 'nyc3',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    region_slug: 'nyc3',
    resource_id: 758604968,
    resource_type: 'reserved_ip',
    started_at: DateTimeHelper.from_rfc3339('2015-11-12T17:51:03Z'),
    status: Status1::COMPLETED,
    type: 'assign_ip',
    project_id: '746c6152-2fa2-11ed-92d3-27aaa54e4988',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

