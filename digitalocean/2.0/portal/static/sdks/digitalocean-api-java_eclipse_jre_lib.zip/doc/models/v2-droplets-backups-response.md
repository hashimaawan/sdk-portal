
# V2 Droplets Backups Response

*This model accepts additional fields of type Object.*

## Structure

`V2DropletsBackupsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Backups` | [`List<Backup1>`](../../doc/models/backup-1.md) | Optional | - | List<Backup1> getBackups() | setBackups(List<Backup1> backups) |
| `Links` | [`Links`](../../doc/models/links.md) | Optional | - | Links getLinks() | setLinks(Links links) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Required | - | Meta getMeta() | setMeta(Meta meta) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.DateTimeHelper;
import com.digitalocean.api.models.Backup1;
import com.digitalocean.api.models.Links;
import com.digitalocean.api.models.Meta;
import com.digitalocean.api.models.Pages;
import com.digitalocean.api.models.Type13;
import com.digitalocean.api.models.V2DropletsBackupsResponse;
import com.digitalocean.api.models.containers.LinksPages;
import java.io.IOException;
import java.util.Arrays;

V2DropletsBackupsResponse v2DropletsBackupsResponse = new V2DropletsBackupsResponse.Builder(
    new Meta.Builder(
        1
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build()
)
.backups(Arrays.asList(
        new Backup1.Builder(
            196,
            DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"),
            242,
            "name4",
            Arrays.asList(
                "regions9",
                "regions0",
                "regions1"
            ),
            180.5D,
            Type13.SNAPSHOT
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build(),
        new Backup1.Builder(
            196,
            DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"),
            242,
            "name4",
            Arrays.asList(
                "regions9",
                "regions0",
                "regions1"
            ),
            180.5D,
            Type13.SNAPSHOT
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ))
.links(new Links.Builder()
        .pages(LinksPages.fromPages(
            new Pages.Builder()
                .last("last6")
                .next("next2")
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
                .build()
        ))
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

