
# Type 66 Enum

## Enumeration

`Type66Enum`

## Fields

| Name |
|  --- |
| `CPU` |
| `DISK` |
| `NETWORK` |

## Example

```php
use HetznerCloudAPILib\Models\Type66Enum;

$type66 = Type66Enum::NETWORK;
```

