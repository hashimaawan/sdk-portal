
# V2 Databases Users Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user` | [`User`](../../doc/models/user.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.auth_plugin import AuthPlugin
from digitaloceanapi.models.mysql_settings import MysqlSettings
from digitaloceanapi.models.role import Role
from digitaloceanapi.models.user import User
from digitaloceanapi.models.v_2_databases_users_response_1 import V2DatabasesUsersResponse1

v_2_databases_users_response_1 = V2DatabasesUsersResponse1(
    user=User(
        name='app-01',
        mysql_settings=MysqlSettings(
            auth_plugin=AuthPlugin.MYSQL_NATIVE_PASSWORD,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        password='jge5lfxtzhx42iff',
        role=Role.NORMAL,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

