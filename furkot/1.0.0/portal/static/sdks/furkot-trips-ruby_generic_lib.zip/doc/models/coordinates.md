
# Coordinates

geographical coordinates of the stop

## Structure

`Coordinates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lat` | `Float` | Optional | latitude |
| `lon` | `Float` | Optional | longitude |

## Example

```ruby
coordinates = Coordinates.new(
  182.98,
  16.08
)
```

