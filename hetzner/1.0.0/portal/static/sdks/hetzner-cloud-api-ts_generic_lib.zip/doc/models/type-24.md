
# Type 24

Destination Image type to convert to

## Enumeration

`Type24`

## Fields

| Name |
|  --- |
| `Snapshot` |

## Example

```ts
import { Type24 } from 'hetzner-cloud-apilib';

const type24 = Type24.Snapshot;
```

