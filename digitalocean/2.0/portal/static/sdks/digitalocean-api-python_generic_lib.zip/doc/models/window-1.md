
# Window 1

## Enumeration

`Window1`

## Fields

| Name |
|  --- |
| `ENUM_5M` |
| `ENUM_10M` |
| `ENUM_30M` |
| `ENUM_1H` |

## Example

```python
from digitaloceanapi.models.window_1 import Window1

window_1 = Window1.ENUM_5M
```

