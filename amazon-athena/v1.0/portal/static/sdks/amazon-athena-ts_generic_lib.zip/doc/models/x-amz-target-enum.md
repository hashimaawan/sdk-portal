
# X Amz Target Enum

## Enumeration

`XAmzTargetEnum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetNamedQuery` |

## Example

```ts
import { XAmzTargetEnum } from 'amazon-athenalib';

const xAmzTarget = XAmzTargetEnum.EnumAmazonAthenaBatchGetNamedQuery;
```

