
# X Amz Target 37

## Enumeration

`XAmzTarget37`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNAMEDQUERIES` |

## Example

```ruby
x_amz_target37 = XAmzTarget37::ENUM_AMAZONATHENALISTNAMEDQUERIES
```

