
# Get Query Results Input

## Structure

`GetQueryResultsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 1000` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getQueryResultsInput := models.GetQueryResultsInput{
        QueryExecutionId:     "QueryExecutionId6",
        NextToken:            models.ToPointer("NextToken2"),
        MaxResults:           models.ToPointer(42),
    }

}
```

