
# Comparison

The comparison operator used against the alert's threshold.

## Enumeration

`Comparison`

## Fields

| Name |
|  --- |
| `GreaterThan` |
| `LessThan` |

## Example

```ts
import { Comparison } from 'digitalocean-apilib';

const comparison = Comparison.GreaterThan;
```

