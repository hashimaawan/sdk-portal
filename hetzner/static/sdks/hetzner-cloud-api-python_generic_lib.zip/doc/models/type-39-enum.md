
# Type 39 Enum

Algorithm of the Load Balancer

## Enumeration

`Type39Enum`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```python
from hetznercloudapi.models.type_39_enum import Type39Enum

type_39 = Type39Enum.ROUND_ROBIN
```

