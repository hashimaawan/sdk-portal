
# X Amz Target 4

## Enumeration

`XAmzTarget4`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateNamedQuery` |

## Example

```ts
import { XAmzTarget4 } from 'amazon-athenalib';

const xAmzTarget4 = XAmzTarget4.EnumAmazonAthenaCreateNamedQuery;
```

