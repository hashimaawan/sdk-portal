
# Label Selector 5

Configuration for type label_selector, required if type is `label_selector`

*This model accepts additional fields of type Object.*

## Structure

`LabelSelector5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `String` | Required | Label selector |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
label_selector5 = LabelSelector5.new(
  selector: 'env=prod',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

