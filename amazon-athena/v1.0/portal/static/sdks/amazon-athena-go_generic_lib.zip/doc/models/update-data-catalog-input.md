
# Update Data Catalog Input

## Structure

`UpdateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Type` | [`models.DataCatalogType3Enum`](../../doc/models/data-catalog-type-3-enum.md) | Required | - |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Parameters` | [`*models.Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    updateDataCatalogInput := models.UpdateDataCatalogInput{
        Name:                 "Name4",
        Type:                 models.DataCatalogType3Enum_GLUE,
        Description:          models.ToPointer("Description2"),
        Parameters:           models.ToPointer(models.Parameters{
        }),
    }

}
```

