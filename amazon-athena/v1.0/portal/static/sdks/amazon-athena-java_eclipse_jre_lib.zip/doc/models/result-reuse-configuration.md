
# Result Reuse Configuration

Specifies the query result reuse behavior for the query.

## Structure

`ResultReuseConfiguration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ResultReuseByAgeConfiguration` | [`ResultReuseByAgeConfiguration2`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - | ResultReuseByAgeConfiguration2 getResultReuseByAgeConfiguration() | setResultReuseByAgeConfiguration(ResultReuseByAgeConfiguration2 resultReuseByAgeConfiguration) |

## Example

```java
import com.amazonaws.useast1.athena.models.ResultReuseByAgeConfiguration2;
import com.amazonaws.useast1.athena.models.ResultReuseConfiguration;

ResultReuseConfiguration resultReuseConfiguration = new ResultReuseConfiguration.Builder()
    .resultReuseByAgeConfiguration(new ResultReuseByAgeConfiguration2.Builder(
        false
    )
    .maxAgeInMinutes(26)
    .build())
    .build();
```

