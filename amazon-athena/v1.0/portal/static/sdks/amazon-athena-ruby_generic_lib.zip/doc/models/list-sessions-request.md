
# List Sessions Request

## Structure

`ListSessionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `state_filter` | [`SessionState3Enum`](../../doc/models/session-state-3-enum.md) | Optional | - |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `next_token` | `String` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```ruby
list_sessions_request = ListSessionsRequest.new(
  'WorkGroup8',
  SessionState3Enum::IDLE,
  100,
  'NextToken6'
)
```

