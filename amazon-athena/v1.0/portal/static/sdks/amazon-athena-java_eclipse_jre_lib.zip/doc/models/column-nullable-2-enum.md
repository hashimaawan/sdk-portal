
# Column Nullable 2 Enum

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2Enum`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```java
import com.amazonaws.useast1.athena.models.ColumnNullable2Enum;

ColumnNullable2Enum columnNullable2 = ColumnNullable2Enum.NOT_NULL;
```

