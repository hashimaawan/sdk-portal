
# Status 23 Enum

## Enumeration

`Status23Enum`

## Fields

| Name |
|  --- |
| `Available` |
| `Creating` |

## Example

```ts
import { Status23Enum } from 'hetzner-cloud-apilib';

const status23 = Status23Enum.Available;
```

