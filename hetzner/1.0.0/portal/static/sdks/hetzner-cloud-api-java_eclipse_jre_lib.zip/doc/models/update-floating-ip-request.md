
# Update Floating Ip Request

*This model accepts additional fields of type Object.*

## Structure

`UpdateFloatingIpRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Description` | `String` | Optional | New Description to set | String getDescription() | setDescription(String description) |
| `Labels` | `Object` | Optional | User-defined labels (key-value pairs) | Object getLabels() | setLabels(Object labels) |
| `Name` | `String` | Optional | New unique name to set | String getName() | setName(String name) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.UpdateFloatingIpRequest;
import java.io.IOException;

UpdateFloatingIpRequest updateFloatingIpRequest = new UpdateFloatingIpRequest.Builder()
    .description("Web Frontend")
    .labels(ApiHelper.deserialize("{\"labelkey\":\"value\"}"))
    .name("Web Frontend")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

