
# S3 Acl Option

## Enumeration

`S3AclOption`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```python
from amazonathena.models.s_3_acl_option import S3AclOption

s_3_acl_option = S3AclOption.BUCKET_OWNER_FULL_CONTROL
```

