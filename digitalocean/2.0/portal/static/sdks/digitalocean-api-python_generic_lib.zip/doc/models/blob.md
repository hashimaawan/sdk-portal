
# Blob

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Blob`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `compressed_size_bytes` | `int` | Optional | The compressed size of the blob in bytes. |
| `digest` | `str` | Optional | The digest of the blob |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.blob import Blob

blob = Blob(
    compressed_size_bytes=2803255,
    digest='sha256:cb8a924afdf0229ef7515d9e5b3024e23b3eb03ddbba287f4a19c6ac90b8d221',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

