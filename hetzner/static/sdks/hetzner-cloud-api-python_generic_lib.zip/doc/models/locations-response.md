
# Locations Response

## Structure

`LocationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `locations` | [`List[Location]`](../../doc/models/location.md) | Required | - |

## Example

```python
from hetznercloudapi.models.location import Location
from hetznercloudapi.models.locations_response import LocationsResponse

locations_response = LocationsResponse(
    locations=[
        Location(
            city='Falkenstein',
            country='DE',
            description='Falkenstein DC Park 1',
            id=1,
            latitude=50.47612,
            longitude=12.370071,
            name='fsn1',
            network_zone='eu-central'
        )
    ]
)
```

