
# V2 Domains Records Request 4

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DomainsRecordsRequest4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data` | `str` | Required | Variable data depending on record type. For example, the "data" value for an A record would be the IPv4 address to which the domain will be mapped. For a CAA record, it would contain the domain name of the CA being granted permission to issue certificates. |
| `flags` | `int` | Optional | An unsigned integer between 0-255 used for CAA records. |
| `id` | `int` | Optional, Read-only | A unique identifier for each domain record. |
| `name` | `str` | Optional | The host name, alias, or service being defined by the record. |
| `port` | `int` | Optional | The port for SRV records. |
| `priority` | `int` | Required | The priority for SRV and MX records. |
| `tag` | `str` | Optional | The parameter tag for CAA records. Valid values are "issue", "issuewild", or "iodef" |
| `ttl` | `int` | Optional | This value is the time to live for the record, in seconds. This defines the time frame that clients can cache queried information before a refresh should be requested. |
| `mtype` | `str` | Required | The type of the DNS record. For example: A, CNAME, TXT, ... |
| `weight` | `int` | Optional | The weight for SRV records. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_domains_records_request_4 import V2DomainsRecordsRequest4

v_2_domains_records_request_4 = V2DomainsRecordsRequest4(
    data='ns1.digitalocean.com',
    priority=None,
    mtype='NS',
    flags=228,
    id=28448429,
    name='@',
    port=104,
    tag='tag0',
    ttl=1800,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

