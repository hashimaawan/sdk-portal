# Files

```csharp
FilesApi filesApi = client.FilesApi;
```

## Class Name

`FilesApi`

## Methods

* [Get Item Files](../../doc/controllers/files.md#get-item-files)
* [Get Details of File by Id](../../doc/controllers/files.md#get-details-of-file-by-id)
* [Download File by ID](../../doc/controllers/files.md#download-file-by-id)


# Get Item Files

```csharp
GetItemFilesAsync(
    Guid vaultUuid,
    Guid itemUuid,
    bool? inlineFiles = null)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `Guid` | Template, Required | The UUID of the Vault to fetch Items from |
| `itemUuid` | `Guid` | Template, Required | The UUID of the Item to fetch files from |
| `inlineFiles` | `bool?` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [List<Models.File>](../../doc/models/file.md).

## Example Usage

```csharp
Guid vaultUuid = new Guid("00002186-0000-0000-0000-000000000000");
Guid itemUuid = new Guid("0000141a-0000-0000-0000-000000000000");
bool? inlineFiles = true;
try
{
    ApiResponse<List<File>> result = await filesApi.GetItemFilesAsync(
        vaultUuid,
        itemUuid,
        inlineFiles
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Details of File by Id

```csharp
GetDetailsOfFileByIdAsync(
    Guid vaultUuid,
    Guid itemUuid,
    Guid fileUuid,
    bool? inlineFiles = null)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `Guid` | Template, Required | The UUID of the Vault to fetch Item from |
| `itemUuid` | `Guid` | Template, Required | The UUID of the Item to fetch File from |
| `fileUuid` | `Guid` | Template, Required | The UUID of the File to fetch |
| `inlineFiles` | `bool?` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.File](../../doc/models/file.md).

## Example Usage

```csharp
Guid vaultUuid = new Guid("00002186-0000-0000-0000-000000000000");
Guid itemUuid = new Guid("0000141a-0000-0000-0000-000000000000");
Guid fileUuid = new Guid("000008e0-0000-0000-0000-000000000000");
bool? inlineFiles = true;
try
{
    ApiResponse<File> result = await filesApi.GetDetailsOfFileByIdAsync(
        vaultUuid,
        itemUuid,
        fileUuid,
        inlineFiles
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Download File by ID

```csharp
DownloadFileByIdAsync(
    Guid vaultUuid,
    Guid itemUuid,
    string fileUuid)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `Guid` | Template, Required | The UUID of the Vault the item is in |
| `itemUuid` | `Guid` | Template, Required | The UUID of the Item the File is in |
| `fileUuid` | `string` | Template, Required | UUID of the file to get content from |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type Stream.

## Example Usage

```csharp
Guid vaultUuid = new Guid("00002186-0000-0000-0000-000000000000");
Guid itemUuid = new Guid("0000141a-0000-0000-0000-000000000000");
string fileUuid = "fileUuid2";
try
{
    ApiResponse<Stream> result = await filesApi.DownloadFileByIdAsync(
        vaultUuid,
        itemUuid,
        fileUuid
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorResponseException)
    {
       // TODO: Handle ErrorResponseException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

