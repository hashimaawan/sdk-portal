
# Op

## Enumeration

`Op`

## Fields

| Name |
|  --- |
| `ADD` |
| `REMOVE` |
| `REPLACE` |

## Example

```java
import local.m1password.models.Op;

Op op = Op.REMOVE;
```

