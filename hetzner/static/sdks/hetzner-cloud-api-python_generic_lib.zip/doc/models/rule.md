
# Rule

## Structure

`Rule`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Optional | Description of the Rule<br><br>**Constraints**: *Maximum Length*: `255` |
| `destination_ips` | `List[str]` | Optional | List of permitted IPv4/IPv6 addresses in CIDR notation. Use `0.0.0.0/0` to allow all IPv4 addresses and `::/0` to allow all IPv6 addresses. You can specify 100 CIDRs at most. |
| `direction` | [`DirectionEnum`](../../doc/models/direction-enum.md) | Required | Select traffic direction on which rule should be applied. Use `source_ips` for direction `in` and `destination_ips` for direction `out`. |
| `port` | `str` | Optional | Port or port range to which traffic will be allowed, only applicable for protocols TCP and UDP. A port range can be specified by separating two ports with a dash, e.g `1024-5000`. |
| `protocol` | [`ProtocolEnum`](../../doc/models/protocol-enum.md) | Required | Type of traffic to allow |
| `source_ips` | `List[str]` | Optional | List of permitted IPv4/IPv6 addresses in CIDR notation. Use `0.0.0.0/0` to allow all IPv4 addresses and `::/0` to allow all IPv6 addresses. You can specify 100 CIDRs at most. |

## Example

```python
from hetznercloudapi.models.direction_enum import DirectionEnum
from hetznercloudapi.models.protocol_enum import ProtocolEnum
from hetznercloudapi.models.rule import Rule

rule = Rule(
    direction=DirectionEnum.ENUM_IN,
    protocol=ProtocolEnum.ESP,
    description='description0',
    destination_ips=[
        '28.239.13.1/32',
        '28.239.14.0/24',
        'ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128'
    ],
    port='80',
    source_ips=[
        '28.239.13.1/32',
        '28.239.14.0/24',
        'ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128'
    ]
)
```

