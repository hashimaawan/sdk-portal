
# Status 23

## Enumeration

`Status23`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `CREATING` |

## Example

```php
use HetznerCloudApiLib\Models\Status23;

$status23 = Status23::AVAILABLE;
```

