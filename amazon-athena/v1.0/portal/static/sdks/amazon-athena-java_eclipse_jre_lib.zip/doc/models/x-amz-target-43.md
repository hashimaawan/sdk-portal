
# X Amz Target 43

## Enumeration

`XAmzTarget43`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTTABLEMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget43;

XAmzTarget43 xAmzTarget43 = XAmzTarget43.ENUM_AMAZONATHENALISTTABLEMETADATA;
```

