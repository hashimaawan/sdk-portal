
# X Amz Target 43 Enum

## Enumeration

`XAmzTarget43Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTTABLEMETADATA` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget43 := models.XAmzTarget43Enum_ENUMAMAZONATHENALISTTABLEMETADATA

}
```

