
# Batch Get Named Query Input

Contains an array of named query IDs.

## Structure

`BatchGetNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namedQueryIds` | `string[]` | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { BatchGetNamedQueryInput } from 'amazon-athenalib';

const batchGetNamedQueryInput: BatchGetNamedQueryInput = {
  namedQueryIds: [
    'NamedQueryIds3',
    'NamedQueryIds4'
  ],
};
```

