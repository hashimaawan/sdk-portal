
# Statement Type

## Enumeration

`StatementType`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```java
import com.amazonaws.useast1.athena.models.StatementType;

StatementType statementType = StatementType.DDL;
```

