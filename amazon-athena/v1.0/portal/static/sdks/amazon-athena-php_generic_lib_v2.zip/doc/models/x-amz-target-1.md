
# X Amz Target 1

## Enumeration

`XAmzTarget1`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget1;

$xAmzTarget1 = XAmzTarget1::ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT;
```

