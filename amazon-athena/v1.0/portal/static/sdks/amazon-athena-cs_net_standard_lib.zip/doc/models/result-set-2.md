
# Result Set 2

## Structure

`ResultSet2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Rows` | [`List<Row>`](../../doc/models/row.md) | Optional | - |
| `ResultSetMetadata` | [`ResultSetMetadata2`](../../doc/models/result-set-metadata-2.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

ResultSet2 resultSet2 = new ResultSet2
{
    Rows = new List<Row>
    {
        new Row
        {
            Data = new List<Datum>
            {
                new Datum
                {
                    VarCharValue = "VarCharValue8",
                },
                new Datum
                {
                    VarCharValue = "VarCharValue8",
                },
            },
        },
    },
    ResultSetMetadata = new ResultSetMetadata2
    {
        ColumnInfo = new List<ColumnInfo>
        {
            new ColumnInfo
            {
                Name = "Name6",
                Type = "Type6",
                CatalogName = "CatalogName0",
                SchemaName = "SchemaName0",
                TableName = "TableName2",
                Label = "Label4",
                Precision = 48,
            },
        },
    },
};
```

