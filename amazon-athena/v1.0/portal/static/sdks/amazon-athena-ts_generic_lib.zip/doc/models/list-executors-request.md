
# List Executors Request

*This model accepts additional fields of type unknown.*

## Structure

`ListExecutorsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `executorStateFilter` | [`ExecutorState1 \| undefined`](../../doc/models/executor-state-1.md) | Optional | - |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `2048` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ExecutorState1, ListExecutorsRequest } from 'amazon-athenalib';

const listExecutorsRequest: ListExecutorsRequest = {
  sessionId: 'SessionId0',
  executorStateFilter: ExecutorState1.Creating,
  maxResults: 100,
  nextToken: 'NextToken8',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

