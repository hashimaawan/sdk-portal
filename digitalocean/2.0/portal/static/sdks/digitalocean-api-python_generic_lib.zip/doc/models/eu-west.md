
# Eu West

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`EuWest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`Status16`](../../doc/models/status-16.md) | Optional | - |
| `status_changed_at` | `str` | Optional | - |
| `thirty_day_uptime_percentage` | `float` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.eu_west import EuWest
from digitaloceanapi.models.status_16 import Status16

eu_west = EuWest(
    status=Status16.UP,
    status_changed_at='2022-03-17T22:28:51Z',
    thirty_day_uptime_percentage=97.99,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

