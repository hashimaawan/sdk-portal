
# X Amz Target 34

## Enumeration

`XAmzTarget34`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListDatabases` |

## Example

```ts
import { XAmzTarget34 } from 'amazon-athenalib';

const xAmzTarget34 = XAmzTarget34.EnumAmazonAthenaListDatabases;
```

