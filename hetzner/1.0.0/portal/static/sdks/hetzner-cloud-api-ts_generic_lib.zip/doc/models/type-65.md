
# Type 65

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65`

## Fields

| Name |
|  --- |
| `Linux64` |
| `Linux32` |

## Example

```ts
import { Type65 } from 'hetzner-cloud-apilib';

const type65 = Type65.Linux64;
```

