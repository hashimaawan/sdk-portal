
# X Amz Target 15 Enum

## Enumeration

`XAmzTarget15Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_15_enum import XAmzTarget15Enum

x_amz_target_15 = XAmzTarget15Enum.ENUM_AMAZONATHENAGETCALCULATIONEXECUTION
```

