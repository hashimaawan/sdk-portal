
# X Amz Target 31

## Enumeration

`XAmzTarget31`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistapplicationdpusizes` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget31 := models.XAmzTarget31_EnumAmazonathenalistapplicationdpusizes

}
```

