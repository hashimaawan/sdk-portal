
# X Amz Target 6

## Enumeration

`XAmzTarget6`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreatePreparedStatement` |

## Example

```ts
import { XAmzTarget6 } from 'amazon-athenalib';

const xAmzTarget6 = XAmzTarget6.EnumAmazonAthenaCreatePreparedStatement;
```

