
# Assign Floating IP Request

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `floating_ip_assigned`        | The floating IP is already assigned                           |

## Structure

`AssignFloatingIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server` | `number` | Required | ID of the Server the Floating IP shall be assigned to |

## Example

```ts
import { AssignFloatingIPRequest } from 'hetzner-cloud-apilib';

const assignFloatingIPRequest: AssignFloatingIPRequest = {
  server: 42,
};
```

