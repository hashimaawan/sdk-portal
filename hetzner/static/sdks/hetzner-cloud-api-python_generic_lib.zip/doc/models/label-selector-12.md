
# Label Selector 12

Configuration for label selector targets, required if type is `label_selector`

## Structure

`LabelSelector12`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `str` | Required | Label selector |

## Example

```python
from hetznercloudapi.models.label_selector_12 import LabelSelector12

label_selector_12 = LabelSelector12(
    selector='env=prod'
)
```

