
# Database

Contains metadata information for a database in a data catalog.

## Structure

`Database`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters \| undefined`](../../doc/models/parameters.md) | Optional | - |

## Example

```ts
import { Database } from 'amazon-athenalib';

const database: Database = {
  name: 'Name0',
  description: 'Description6',
  parameters: {},
};
```

