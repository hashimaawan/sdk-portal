
# Protocol

The type of traffic to be allowed. This may be one of `tcp`, `udp`, or `icmp`.

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Udp` |
| `Icmp` |

## Example

```ts
import { Protocol } from 'digitalocean-apilib';

const protocol = Protocol.Tcp;
```

