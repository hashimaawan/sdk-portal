
# Get Query Results Input

## Structure

`GetQueryResultsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 1000` |

## Example

```ruby
get_query_results_input = GetQueryResultsInput.new(
  'QueryExecutionId4',
  'NextToken0',
  116
)
```

