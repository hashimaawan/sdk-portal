
# Comparison

The comparison operator used against the alert's threshold.

## Enumeration

`Comparison`

## Fields

| Name |
|  --- |
| `GREATER_THAN` |
| `LESS_THAN` |

## Example

```ruby
comparison = Comparison::GREATER_THAN
```

