
# V2 Droplets Actions Request

Specifies the action that will be taken on the Droplet.

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_droplets_actions_request = V2DropletsActionsRequest.new(
  type: Type12::REBOOT,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

