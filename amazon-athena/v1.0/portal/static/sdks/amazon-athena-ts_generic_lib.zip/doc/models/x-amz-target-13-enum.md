
# X Amz Target 13 Enum

## Enumeration

`XAmzTarget13Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteWorkGroup` |

## Example

```ts
import { XAmzTarget13Enum } from 'amazon-athenalib';

const xAmzTarget13 = XAmzTarget13Enum.EnumAmazonAthenaDeleteWorkGroup;
```

