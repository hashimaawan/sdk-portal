
# Load Balancer

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`LoadBalancer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Optional | The ID of a resource associated with a Kubernetes cluster. |
| `name` | `str` | Optional | The name of a resource associated with a Kubernetes cluster. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.load_balancer import LoadBalancer

load_balancer = LoadBalancer(
    id='edb0478d-7436-11ea-86e6-0a58ac144b91',
    name='volume-001',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

