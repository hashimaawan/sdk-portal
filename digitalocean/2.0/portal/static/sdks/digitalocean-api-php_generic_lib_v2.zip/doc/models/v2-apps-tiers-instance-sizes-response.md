
# V2 Apps Tiers Instance Sizes Response

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2AppsTiersInstanceSizesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `discountPercent` | `?float` | Optional | - | getDiscountPercent(): ?float | setDiscountPercent(?float discountPercent): void |
| `instanceSizes` | [`?(InstanceSize[])`](../../doc/models/instance-size.md) | Optional | - | getInstanceSizes(): ?array | setInstanceSizes(?array instanceSizes): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2AppsTiersInstanceSizesResponseBuilder;
use DigitalOceanApiLib\Models\Builders\InstanceSizeBuilder;
use DigitalOceanApiLib\Models\MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores;
use DigitalOceanApiLib\ApiHelper;

$v2AppsTiersInstanceSizesResponse = V2AppsTiersInstanceSizesResponseBuilder::init()
    ->discountPercent(2.32)
    ->instanceSizes(
        [
            InstanceSizeBuilder::init()
                ->cpuType(MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores::DEDICATED)
                ->cpus('cpus4')
                ->memoryBytes('memory_bytes8')
                ->name('name8')
                ->slug('slug8')
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

