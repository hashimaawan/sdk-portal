
# Session Statistics

Contains statistics for a session.

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DpuExecutionInMillis` | `Integer` | Optional | - | Integer getDpuExecutionInMillis() | setDpuExecutionInMillis(Integer dpuExecutionInMillis) |

## Example

```java
import com.amazonaws.useast1.athena.models.SessionStatistics;

SessionStatistics sessionStatistics = new SessionStatistics.Builder()
    .dpuExecutionInMillis(188)
    .build();
```

