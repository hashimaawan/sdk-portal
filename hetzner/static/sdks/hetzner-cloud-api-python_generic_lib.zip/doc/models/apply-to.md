
# Apply To

## Structure

`ApplyTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label_selector` | [`LabelSelector1`](../../doc/models/label-selector-1.md) | Optional | Configuration for type LabelSelector, required if type is `label_selector` |
| `server` | [`Server2`](../../doc/models/server-2.md) | Optional | Configuration for type Server, required if type is `server` |
| `mtype` | [`Type7Enum`](../../doc/models/type-7-enum.md) | Required | Type of the resource |

## Example

```python
from hetznercloudapi.models.apply_to import ApplyTo
from hetznercloudapi.models.label_selector_1 import LabelSelector1
from hetznercloudapi.models.server_2 import Server2
from hetznercloudapi.models.type_7_enum import Type7Enum

apply_to = ApplyTo(
    mtype=Type7Enum.SERVER,
    label_selector=LabelSelector1(
        selector='selector8'
    ),
    server=Server2(
        id=14
    )
)
```

