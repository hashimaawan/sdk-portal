
# Floating Ip 4

The cost of one Floating IP per month

## Structure

`FloatingIp4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PriceMonthly` | [`PriceMonthly6`](../../doc/models/price-monthly-6.md) | Required | - |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

FloatingIp4 floatingIp4 = new FloatingIp4
{
    PriceMonthly = new PriceMonthly6
    {
        Gross = "1.1900000000000000",
        Net = "1.0000000000",
    },
};
```

