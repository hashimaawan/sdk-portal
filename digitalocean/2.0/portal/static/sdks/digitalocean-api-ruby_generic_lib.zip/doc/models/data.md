
# Data

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Data`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result` | [`Array[Result]`](../../doc/models/result.md) | Required | Result of query. |
| `result_type` | `String` | Required, Constant | **Value**: `'matrix'` |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
data = Data.new(
  result: [
    Result.new(
      metric: {
        'host_id' => '19201920'
      },
      values: [
        [
          1435781430,
          '1'
        ],
        [
          1435781445,
          '1'
        ]
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  result_type: 'matrix',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

