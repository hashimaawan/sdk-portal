
# Status 113

Current status of the Volume

## Enumeration

`Status113`

## Fields

| Name |
|  --- |
| `Creating` |
| `Available` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    status113 := models.Status113_Creating

}
```

