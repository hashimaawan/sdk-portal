
# Engine Configuration 1

## Structure

`EngineConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CoordinatorDpuSize` | `int?` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `MaxConcurrentDpus` | `int` | Required | **Constraints**: `>= 2`, `<= 5000` |
| `DefaultExecutorDpuSize` | `int?` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `AdditionalConfigs` | [`AdditionalConfigs`](../../doc/models/additional-configs.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

EngineConfiguration1 engineConfiguration1 = new EngineConfiguration1
{
    MaxConcurrentDpus = 214,
    CoordinatorDpuSize = 1,
    DefaultExecutorDpuSize = 1,
    AdditionalConfigs = new AdditionalConfigs
    {
    },
};
```

