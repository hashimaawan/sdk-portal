
# Sort 8

## Enumeration

`Sort8`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Sort8 sort8 = Sort8.EnumNameasc;
```

