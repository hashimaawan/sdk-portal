
# Mode

travel mode

## Enumeration

`Mode`

## Fields

| Name |
|  --- |
| `CAR` |
| `MOTORCYCLE` |
| `BICYCLE` |
| `WALK` |
| `OTHER` |

## Example

```php
use FurkotTripsLib\Models\Mode;

$mode = Mode::BICYCLE;
```

