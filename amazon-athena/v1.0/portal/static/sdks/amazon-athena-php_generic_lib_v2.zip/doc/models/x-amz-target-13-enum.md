
# X Amz Target 13 Enum

## Enumeration

`XAmzTarget13Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEWORKGROUP` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget13Enum;

$xAmzTarget13 = XAmzTarget13Enum::ENUM_AMAZONATHENADELETEWORKGROUP;
```

