
# Type 15

The action to be taken on the image. Can be either `convert` or `transfer`.

## Enumeration

`Type15`

## Fields

| Name |
|  --- |
| `Convert` |
| `Transfer` |

## Example

```ts
import { Type15 } from 'digitalocean-apilib';

const type15 = Type15.Convert;
```

