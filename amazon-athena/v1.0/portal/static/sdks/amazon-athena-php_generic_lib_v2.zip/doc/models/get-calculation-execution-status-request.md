
# Get Calculation Execution Status Request

## Structure

`GetCalculationExecutionStatusRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | getCalculationExecutionId(): string | setCalculationExecutionId(string calculationExecutionId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetCalculationExecutionStatusRequestBuilder;

$getCalculationExecutionStatusRequest = GetCalculationExecutionStatusRequestBuilder::init(
    'CalculationExecutionId8'
)->build();
```

