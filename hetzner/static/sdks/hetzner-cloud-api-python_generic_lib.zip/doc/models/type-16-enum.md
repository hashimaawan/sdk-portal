
# Type 16 Enum

Type of the Floating IP

## Enumeration

`Type16Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_16_enum import Type16Enum

type_16 = Type16Enum.IPV4
```

