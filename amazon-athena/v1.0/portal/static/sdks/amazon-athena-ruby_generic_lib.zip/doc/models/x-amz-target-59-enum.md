
# X Amz Target 59 Enum

## Enumeration

`XAmzTarget59Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEWORKGROUP` |

## Example

```ruby
x_amz_target59 = XAmzTarget59Enum::ENUM_AMAZONATHENAUPDATEWORKGROUP
```

