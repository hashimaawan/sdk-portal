
# Author Object

*This model accepts additional fields of type Object.*

## Structure

`AuthorObject`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | The name of the author. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
author_object = AuthorObject.new(
  name: 'name8',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

