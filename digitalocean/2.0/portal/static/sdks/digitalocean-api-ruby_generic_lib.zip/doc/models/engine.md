
# Engine

- MYSQL: MySQL
- PG: PostgreSQL
- REDIS: Redis

## Enumeration

`Engine`

## Fields

| Name |
|  --- |
| `UNSET` |
| `MYSQL` |
| `PG` |
| `REDIS` |

## Example

```ruby
engine = Engine::PG
```

