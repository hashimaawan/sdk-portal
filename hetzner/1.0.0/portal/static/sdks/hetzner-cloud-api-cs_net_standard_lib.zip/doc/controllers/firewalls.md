# Firewalls

Firewalls can limit the network access to or from your resources.

* When applying a firewall with no `in` rule all inbound traffic will be dropped. The default for `in` is `DROP`.
* When applying a firewall with no `out` rule all outbound traffic will be accepted. The default for `out` is `ACCEPT`.

```csharp
FirewallsController firewallsController = client.FirewallsController;
```

## Class Name

`FirewallsController`

## Methods

* [Get All Firewalls](../../doc/controllers/firewalls.md#get-all-firewalls)
* [Create a Firewall](../../doc/controllers/firewalls.md#create-a-firewall)
* [Delete a Firewall](../../doc/controllers/firewalls.md#delete-a-firewall)
* [Get a Firewall](../../doc/controllers/firewalls.md#get-a-firewall)
* [Update a Firewall](../../doc/controllers/firewalls.md#update-a-firewall)


# Get All Firewalls

Returns all Firewall objects.

```csharp
GetAllFirewallsAsync(
    Models.SortEnum? sort = null,
    string name = null,
    string labelSelector = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`SortEnum?`](../../doc/models/sort-enum.md) | Query, Optional | Can be used multiple times. |
| `name` | `string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `firewalls` key contains an array of Firewall objects

[`Task<Models.FirewallsResponse>`](../../doc/models/firewalls-response.md)

## Example Usage

```csharp
try
{
    FirewallsResponse result = await firewallsController.GetAllFirewallsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Create a Firewall

Creates a new Firewall.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_already_added`        | Server added more than one time to resource                   |
| `incompatible_network_type`   | The Network type is incompatible for the given resource       |
| `firewall_resource_not_found` | The resource the Firewall should be attached to was not found |

```csharp
CreateAFirewallAsync(
    Models.CreateFirewallRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateFirewallRequest`](../../doc/models/create-firewall-request.md) | Body, Optional | - |

## Response Type

**201**: The `firewall` key contains the Firewall that was just created

[`Task<Models.CreateFirewallResponse>`](../../doc/models/create-firewall-response.md)

## Example Usage

```csharp
CreateFirewallRequest body = new CreateFirewallRequest
{
    Name = "Corporate Intranet Protection",
    ApplyTo = new List<ApplyTo>
    {
        new ApplyTo
        {
            Type = Type7Enum.Server,
            Server = new Server2
            {
                Id = 42,
            },
        },
    },
    Labels = ApiHelper.JsonDeserialize<object>("{\"env\":\"dev\"}"),
    Rules = new List<Rule>
    {
        new Rule
        {
            Direction = DirectionEnum.In,
            Protocol = ProtocolEnum.Tcp,
            Description = "Allow port 80",
            Port = "80",
            SourceIps = new List<string>
            {
                "28.239.13.1/32",
                "28.239.14.0/24",
                "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128",
            },
        },
    },
};

try
{
    CreateFirewallResponse result = await firewallsController.CreateAFirewallAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Delete a Firewall

Deletes a Firewall.

#### Call specific error codes

| Code                 | Description                               |
|--------------------- |-------------------------------------------|
| `resource_in_use`    | Firewall must not be in use to be deleted |

```csharp
DeleteAFirewallAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: Firewall deleted

`Task`

## Example Usage

```csharp
int id = 112;
try
{
    await firewallsController.DeleteAFirewallAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Firewall

Gets a specific Firewall object.

```csharp
GetAFirewallAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `firewall` key contains a Firewall object

[`Task<Models.FirewallResponse>`](../../doc/models/firewall-response.md)

## Example Usage

```csharp
int id = 112;
try
{
    FirewallResponse result = await firewallsController.GetAFirewallAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Update a Firewall

Updates the Firewall.

Note that when updating labels, the Firewall's current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the Firewall object changes during the request, the response will be a “conflict” error.

```csharp
UpdateAFirewallAsync(
    int id,
    Models.UpdateFirewallRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`UpdateFirewallRequest`](../../doc/models/update-firewall-request.md) | Body, Optional | - |

## Response Type

**200**: The `firewall` key contains the Firewall that was just updated

[`Task<Models.FirewallResponse>`](../../doc/models/firewall-response.md)

## Example Usage

```csharp
int id = 112;
UpdateFirewallRequest body = new UpdateFirewallRequest
{
    Labels = ApiHelper.JsonDeserialize<object>("{\"labelkey\":\"value\"}"),
    Name = "new-name",
};

try
{
    FirewallResponse result = await firewallsController.UpdateAFirewallAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

