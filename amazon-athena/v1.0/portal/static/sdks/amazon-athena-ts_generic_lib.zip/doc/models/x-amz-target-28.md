
# X Amz Target 28

## Enumeration

`XAmzTarget28`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetTableMetadata` |

## Example

```ts
import { XAmzTarget28 } from 'amazon-athenalib';

const xAmzTarget28 = XAmzTarget28.EnumAmazonAthenaGetTableMetadata;
```

