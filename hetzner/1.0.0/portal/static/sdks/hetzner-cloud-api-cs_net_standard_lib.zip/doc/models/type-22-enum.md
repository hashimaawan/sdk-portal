
# Type 22 Enum

Type of the Image

## Enumeration

`Type22Enum`

## Fields

| Name |
|  --- |
| `MSystem` |
| `App` |
| `Snapshot` |
| `Backup` |
| `Temporary` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type22Enum type22 = Type22Enum.Temporary;
```

