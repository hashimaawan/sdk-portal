
# Region 8

## Enumeration

`Region8`

## Fields

| Name |
|  --- |
| `US_EAST` |
| `US_WEST` |
| `EU_WEST` |
| `SE_ASIA` |

## Example

```python
from digitaloceanapi.models.region_8 import Region8

region_8 = Region8.EU_WEST
```

