
# Tag Resource Input

## Structure

`TagResourceInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `resourceARN` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` | getResourceARN(): string | setResourceARN(string resourceARN): void |
| `tags` | [`Tag[]`](../../doc/models/tag.md) | Required | - | getTags(): array | setTags(array tags): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\TagResourceInputBuilder;
use AmazonAthenaLib\Models\Builders\TagBuilder;

$tagResourceInput = TagResourceInputBuilder::init(
    'ResourceARN6',
    [
        TagBuilder::init()
            ->key('Key0')
            ->value('Value6')
            ->build()
    ]
)->build();
```

