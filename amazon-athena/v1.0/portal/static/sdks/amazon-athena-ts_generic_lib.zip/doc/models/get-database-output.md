
# Get Database Output

*This model accepts additional fields of type unknown.*

## Structure

`GetDatabaseOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `database` | [`Database2 \| undefined`](../../doc/models/database-2.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetDatabaseOutput } from 'amazon-athenalib';

const getDatabaseOutput: GetDatabaseOutput = {
  database: {
    name: 'Name2',
    description: 'Description8',
    parameters: {
      additionalProperties: {
        'exampleAdditionalProperty': 'Parameters_additionalProperties2'
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

