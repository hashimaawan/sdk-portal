
# Prepared Statement 1

*This model accepts additional fields of type Object.*

## Structure

`PreparedStatement1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statement_name` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256`, *Pattern*: `[a-zA-Z_][a-zA-Z0-9_@:]{1,256}` |
| `query_statement` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `work_group_name` | `String` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `last_modified_time` | `DateTime` | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
prepared_statement1 = PreparedStatement1.new(
  statement_name: 'StatementName8',
  query_statement: 'QueryStatement2',
  work_group_name: 'WorkGroupName2',
  description: 'Description6',
  last_modified_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

