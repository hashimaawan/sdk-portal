
# V2 Kubernetes Clusters User Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersUserResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kubernetesClusterUser` | [`KubernetesClusterUser \| undefined`](../../doc/models/kubernetes-cluster-user.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2KubernetesClustersUserResponse } from 'digitalocean-apilib';

const v2KubernetesClustersUserResponse: V2KubernetesClustersUserResponse = {
  kubernetesClusterUser: {
    groups: [
      'groups8'
    ],
    username: 'username6',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

