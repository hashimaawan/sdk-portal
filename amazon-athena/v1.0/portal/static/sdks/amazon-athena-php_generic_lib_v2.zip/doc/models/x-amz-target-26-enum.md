
# X Amz Target 26 Enum

## Enumeration

`XAmzTarget26Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETSESSION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget26Enum;

$xAmzTarget26 = XAmzTarget26Enum::ENUM_AMAZONATHENAGETSESSION;
```

