
# X Amz Target 28

## Enumeration

`XAmzTarget28`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETTABLEMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget28;

XAmzTarget28 xAmzTarget28 = XAmzTarget28.ENUM_AMAZONATHENAGETTABLEMETADATA;
```

