
# Datum

A piece of data (a field in the table).

## Structure

`Datum`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `varCharValue` | `string \| undefined` | Optional | - |

## Example

```ts
import { Datum } from 'amazon-athenalib';

const datum: Datum = {
  varCharValue: 'VarCharValue8',
};
```

