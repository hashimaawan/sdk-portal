
# V2 Droplets Actions Request 24

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest24`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type12)`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. | getType(): string | setType(string type): void |
| `kernel` | `?int` | Optional | A unique number used to identify and reference a specific kernel. | getKernel(): ?int | setKernel(?int kernel): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DropletsActionsRequest24Builder;
use DigitalOceanApiLib\Models\Type12;
use DigitalOceanApiLib\ApiHelper;

$v2DropletsActionsRequest24 = V2DropletsActionsRequest24Builder::init(
    Type12::REBOOT
)
    ->kernel(12389723)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

