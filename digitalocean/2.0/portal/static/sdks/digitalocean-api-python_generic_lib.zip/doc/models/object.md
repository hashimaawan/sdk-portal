
# Object

Metadata about the Kubernetes API object the diagnostic is reported on.

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Object`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | `str` | Optional | The kind of Kubernetes API object |
| `name` | `str` | Optional | Name of the object |
| `namespace` | `str` | Optional | The namespace the object resides in the cluster. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.object import Object

object = Object(
    kind='config map',
    name='foo',
    namespace='kube-system',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

