
# Image 3

The cost of Image per GB/month

## Structure

`Image3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price_per_gb_month` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - |

## Example

```ruby
image3 = Image3.new(
  PricePerGbMonth.new(
    '1.1900000000000000',
    '1.0000000000'
  )
)
```

