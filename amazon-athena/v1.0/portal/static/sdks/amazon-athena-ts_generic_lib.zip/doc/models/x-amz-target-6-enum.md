
# X Amz Target 6 Enum

## Enumeration

`XAmzTarget6Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreatePreparedStatement` |

## Example

```ts
import { XAmzTarget6Enum } from 'amazon-athenalib';

const xAmzTarget6 = XAmzTarget6Enum.EnumAmazonAthenaCreatePreparedStatement;
```

