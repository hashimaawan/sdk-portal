
# Encryption Option Enum

## Enumeration

`EncryptionOptionEnum`

## Fields

| Name |
|  --- |
| `SSES3` |
| `SSEKMS` |
| `CSEKMS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    encryptionOption := models.EncryptionOptionEnum_SSES3

}
```

