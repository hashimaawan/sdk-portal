
# S3 Acl Option

## Enumeration

`S3AclOption`

## Fields

| Name |
|  --- |
| `BucketOwnerFullControl` |

## Example

```csharp
using AmazonAthena.Standard.Models;

S3AclOption s3AclOption = S3AclOption.BucketOwnerFullControl;
```

