
# X Amz Target 12 Enum

## Enumeration

`XAmzTarget12Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget12Enum;

XAmzTarget12Enum xAmzTarget12 = XAmzTarget12Enum.ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT;
```

