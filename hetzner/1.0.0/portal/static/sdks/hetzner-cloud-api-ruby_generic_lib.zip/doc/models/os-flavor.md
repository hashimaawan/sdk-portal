
# Os Flavor

Flavor of operating system contained in the Image

## Enumeration

`OsFlavor`

## Fields

| Name |
|  --- |
| `UBUNTU` |
| `CENTOS` |
| `DEBIAN` |
| `FEDORA` |
| `UNKNOWN` |

## Example

```ruby
os_flavor = OsFlavor::UNKNOWN
```

