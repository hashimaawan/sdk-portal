
# V2 Functions Namespaces Triggers Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesTriggersResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trigger` | [`Trigger`](../../doc/models/trigger.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_functions_namespaces_triggers_response1 = V2FunctionsNamespacesTriggersResponse1.new(
  trigger: Trigger.new(
    created_at: 'created_at6',
    function: 'function6',
    is_enabled: false,
    name: 'name8',
    namespace: 'namespace4',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

