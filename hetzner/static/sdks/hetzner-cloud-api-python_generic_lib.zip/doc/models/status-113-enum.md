
# Status 113 Enum

Current status of the Volume

## Enumeration

`Status113Enum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `AVAILABLE` |

## Example

```python
from hetznercloudapi.models.status_113_enum import Status113Enum

status_113 = Status113Enum.CREATING
```

