# Pricing

Returns prices for resources.

```php
$pricingController = $client->getPricingController();
```

## Class Name

`PricingController`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```php
function getAllPrices(): PricingResponse
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

[`PricingResponse`](../../doc/models/pricing-response.md)

## Example Usage

```php
$pricingController = $client->getPricingController();

try {
    $result = $pricingController->getAllPrices();
    echo 'PricingResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

