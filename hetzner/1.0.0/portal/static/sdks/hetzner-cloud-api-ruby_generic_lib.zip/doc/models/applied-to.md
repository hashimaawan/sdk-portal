
# Applied To

*This model accepts additional fields of type Object.*

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applied_to_resources` | [`Array[AppliedToResource]`](../../doc/models/applied-to-resource.md) | Optional | - |
| `label_selector` | [`LabelSelector`](../../doc/models/label-selector.md) | Optional | - |
| `server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `type` | [`Type6`](../../doc/models/type-6.md) | Required | Type of resource referenced |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
applied_to = AppliedTo.new(
  type: Type6::SERVER,
  applied_to_resources: [
    AppliedToResource.new(
      server: Server.new(
        id: 14,
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      ),
      type: Type5::SERVER,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  label_selector: LabelSelector.new(
    selector: 'selector8',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  server: Server.new(
    id: 14,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

