
# X Amz Target 9

## Enumeration

`XAmzTarget9`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEDATACATALOG` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget9;

$xAmzTarget9 = XAmzTarget9::ENUM_AMAZONATHENADELETEDATACATALOG;
```

