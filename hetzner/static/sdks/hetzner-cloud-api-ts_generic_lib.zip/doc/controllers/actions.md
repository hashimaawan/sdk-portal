# Actions

Actions show the results and progress of asynchronous requests to the API.

```ts
const actionsController = new ActionsController(client);
```

## Class Name

`ActionsController`

## Methods

* [Get All Actions](../../doc/controllers/actions.md#get-all-actions)
* [Get an Action](../../doc/controllers/actions.md#get-an-action)


# Get All Actions

Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```ts
async getAllActions(
  id?: number,
  sort?: ParameterSortEnum,
  status?: ParameterStatusEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionsResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number \| undefined` | Query, Optional | Can be used multiple times, the response will contain only Actions with specified IDs |
| `sort` | [`ParameterSortEnum \| undefined`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum \| undefined`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionsResponse`](../../doc/models/actions-response.md).

## Example Usage

```ts
try {
  const response = await actionsController.getAllActions();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```


# Get an Action

Returns a specific Action object.

```ts
async getAnAction(
  id: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ActionResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Template, Required | ID of the Resource |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The `action` key in the reply has this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```ts
const id = 112;

try {
  const response = await actionsController.getAnAction(id);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
  }
}
```

