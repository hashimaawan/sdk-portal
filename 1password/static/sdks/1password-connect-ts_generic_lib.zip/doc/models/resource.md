
# Resource

*This model accepts additional fields of type unknown.*

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | [`Item2 \| undefined`](../../doc/models/item-2.md) | Optional | - |
| `itemVersion` | `number \| undefined` | Optional | - |
| `type` | [`Type \| undefined`](../../doc/models/type.md) | Optional | - |
| `vault` | [`Vault3 \| undefined`](../../doc/models/vault-3.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Resource, Type } from 'm-1-password-connectlib';

const resource: Resource = {
  item: {
    id: 'id2',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  itemVersion: 108,
  type: Type.Item,
  vault: {
    id: 'id6',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

