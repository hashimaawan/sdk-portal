
# Start Calculation Execution Response

*This model accepts additional fields of type object.*

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `State` | [`CalculationExecutionState4?`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

StartCalculationExecutionResponse startCalculationExecutionResponse = new StartCalculationExecutionResponse
{
    CalculationExecutionId = "CalculationExecutionId0",
    State = CalculationExecutionState4.Canceling,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

