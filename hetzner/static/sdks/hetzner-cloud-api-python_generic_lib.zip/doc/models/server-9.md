
# Server 9

Configuration for type server, required if type is `server`

## Structure

`Server9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Required | ID of the Server |

## Example

```python
from hetznercloudapi.models.server_9 import Server9

server_9 = Server9(
    id=244
)
```

