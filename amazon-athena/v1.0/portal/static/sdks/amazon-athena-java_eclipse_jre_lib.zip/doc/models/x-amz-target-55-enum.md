
# X Amz Target 55 Enum

## Enumeration

`XAmzTarget55Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget55Enum;

XAmzTarget55Enum xAmzTarget55 = XAmzTarget55Enum.ENUM_AMAZONATHENAUPDATENAMEDQUERY;
```

