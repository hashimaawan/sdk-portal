
# Type 7

The type of resource that the firewall rule allows to access the database cluster.

## Enumeration

`Type7`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `K8S` |
| `IP_ADDR` |
| `TAG` |
| `APP` |

## Example

```php
use DigitalOceanApiLib\Models\Type7;

$type7 = Type7::APP;
```

