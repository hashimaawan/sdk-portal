
# Database 2

## Structure

`Database2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

Database2 database2 = new Database2
{
    Name = "Name4",
    Description = "Description2",
    Parameters = new Parameters
    {
    },
};
```

