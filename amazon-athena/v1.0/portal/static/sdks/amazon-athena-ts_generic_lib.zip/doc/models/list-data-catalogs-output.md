
# List Data Catalogs Output

## Structure

`ListDataCatalogsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dataCatalogsSummary` | [`DataCatalogSummary[] \| undefined`](../../doc/models/data-catalog-summary.md) | Optional | - |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import {
  DataCatalogType2Enum,
  ListDataCatalogsOutput,
} from 'amazon-athenalib';

const listDataCatalogsOutput: ListDataCatalogsOutput = {
  dataCatalogsSummary: [
    {
      catalogName: 'CatalogName4',
      type: DataCatalogType2Enum.HIVE,
    },
    {
      catalogName: 'CatalogName4',
      type: DataCatalogType2Enum.HIVE,
    },
    {
      catalogName: 'CatalogName4',
      type: DataCatalogType2Enum.HIVE,
    }
  ],
  nextToken: 'NextToken0',
};
```

