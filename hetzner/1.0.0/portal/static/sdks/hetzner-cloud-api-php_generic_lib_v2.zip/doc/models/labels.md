
# Labels

User-defined labels (key-value pairs)

## Structure

`Labels`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `labelkey` | `?string` | Optional | New label | getLabelkey(): ?string | setLabelkey(?string labelkey): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LabelsBuilder;

$labels = LabelsBuilder::init()
    ->labelkey('value')
    ->build();
```

