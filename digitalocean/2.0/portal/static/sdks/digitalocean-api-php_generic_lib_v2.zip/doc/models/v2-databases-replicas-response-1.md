
# V2 Databases Replicas Response 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesReplicasResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `replica` | [`?Replica`](../../doc/models/replica.md) | Optional | - | getReplica(): ?Replica | setReplica(?Replica replica): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesReplicasResponse1Builder;
use DigitalOceanApiLib\Models\Builders\ReplicaBuilder;
use DigitalOceanApiLib\Models\Builders\ConnectionBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Utils\DateTimeHelper;
use DigitalOceanApiLib\Models\Builders\PrivateConnectionBuilder;

$v2DatabasesReplicasResponse1 = V2DatabasesReplicasResponse1Builder::init()
    ->replica(
        ReplicaBuilder::init(
            'name6'
        )
            ->connection(
                ConnectionBuilder::init()
                    ->database('database2')
                    ->host('host0')
                    ->password('password2')
                    ->port(174)
                    ->ssl(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->createdAt(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
            ->id('000007e0-0000-0000-0000-000000000000')
            ->privateConnection(
                PrivateConnectionBuilder::init()
                    ->database('database4')
                    ->host('host4')
                    ->password('password8')
                    ->port(228)
                    ->ssl(false)
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
            ->privateNetworkUuid('private_network_uuid6')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

