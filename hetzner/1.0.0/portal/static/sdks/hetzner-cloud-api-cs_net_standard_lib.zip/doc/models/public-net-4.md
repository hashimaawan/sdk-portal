
# Public Net 4

Public network information. The Server's IPv4 address can be found in `public_net->ipv4->ip`

*This model accepts additional fields of type object.*

## Structure

`PublicNet4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Firewalls` | [`List<ServerPublicNetFirewall>`](../../doc/models/server-public-net-firewall.md) | Optional | Firewalls applied to the public network interface of this Server |
| `FloatingIps` | `List<int>` | Required | IDs of Floating IPs assigned to this Server |
| `Ipv4` | [`Ipv44`](../../doc/models/ipv-44.md) | Required | IP address (v4) and its reverse DNS entry of this Server |
| `Ipv6` | [`Ipv64`](../../doc/models/ipv-64.md) | Required | IPv6 network assigned to this Server and its reverse DNS entry |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;
using System.Collections.Generic;

PublicNet4 publicNet4 = new PublicNet4
{
    FloatingIps = new List<int>
    {
        478,
    },
    Ipv4 = new Ipv44
    {
        Blocked = false,
        DnsPtr = "server01.example.com",
        Ip = "1.2.3.4",
        Id = 42,
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    Ipv6 = new Ipv64
    {
        Blocked = false,
        DnsPtr = new List<DnsPtr8>
        {
            new DnsPtr8
            {
                DnsPtr = "server.example.com",
                Ip = "2001:db8::1",
                ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
        },
        Ip = "2001:db8::/64",
        Id = 42,
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    Firewalls = new List<ServerPublicNetFirewall>
    {
        new ServerPublicNetFirewall
        {
            Id = 250,
            Status = Status72.Applied,
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

