
# Session Statistics

Contains statistics for a session.

*This model accepts additional fields of type unknown.*

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpuExecutionInMillis` | `number \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SessionStatistics } from 'amazon-athenalib';

const sessionStatistics: SessionStatistics = {
  dpuExecutionInMillis: 188,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

