
# Result Configuration Updates 2

*This model accepts additional fields of type array.*

## Structure

`ResultConfigurationUpdates2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `outputLocation` | `?string` | Optional | - | getOutputLocation(): ?string | setOutputLocation(?string outputLocation): void |
| `removeOutputLocation` | `?bool` | Optional | - | getRemoveOutputLocation(): ?bool | setRemoveOutputLocation(?bool removeOutputLocation): void |
| `encryptionConfiguration` | [`?EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - | getEncryptionConfiguration(): ?EncryptionConfiguration2 | setEncryptionConfiguration(?EncryptionConfiguration2 encryptionConfiguration): void |
| `removeEncryptionConfiguration` | `?bool` | Optional | - | getRemoveEncryptionConfiguration(): ?bool | setRemoveEncryptionConfiguration(?bool removeEncryptionConfiguration): void |
| `expectedBucketOwner` | `?string` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` | getExpectedBucketOwner(): ?string | setExpectedBucketOwner(?string expectedBucketOwner): void |
| `removeExpectedBucketOwner` | `?bool` | Optional | - | getRemoveExpectedBucketOwner(): ?bool | setRemoveExpectedBucketOwner(?bool removeExpectedBucketOwner): void |
| `aclConfiguration` | [`?AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - | getAclConfiguration(): ?AclConfiguration1 | setAclConfiguration(?AclConfiguration1 aclConfiguration): void |
| `removeAclConfiguration` | `?bool` | Optional | - | getRemoveAclConfiguration(): ?bool | setRemoveAclConfiguration(?bool removeAclConfiguration): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ResultConfigurationUpdates2Builder;
use AmazonAthenaLib\Models\Builders\EncryptionConfiguration2Builder;
use AmazonAthenaLib\Models\EncryptionOption1;
use AmazonAthenaLib\ApiHelper;

$resultConfigurationUpdates2 = ResultConfigurationUpdates2Builder::init()
    ->outputLocation('OutputLocation4')
    ->removeOutputLocation(false)
    ->encryptionConfiguration(
        EncryptionConfiguration2Builder::init(
            EncryptionOption1::SSE_S3
        )
            ->kmsKey('KmsKey6')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->removeEncryptionConfiguration(false)
    ->expectedBucketOwner('ExpectedBucketOwner4')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

