
# Session Statistics

Contains statistics for a session.

*This model accepts additional fields of type Any.*

## Structure

`SessionStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `int` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.session_statistics import SessionStatistics

session_statistics = SessionStatistics(
    dpu_execution_in_millis=136,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

