
# X Amz Target 38

## Enumeration

`XAmzTarget38`

## Fields

| Name |
|  --- |
| `EnumAmazonathenalistnotebookmetadata` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget38 := models.XAmzTarget38_EnumAmazonathenalistnotebookmetadata

}
```

