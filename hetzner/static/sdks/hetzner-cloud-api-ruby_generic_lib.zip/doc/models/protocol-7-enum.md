
# Protocol 7 Enum

Protocol of the Load Balancer

## Enumeration

`Protocol7Enum`

## Fields

| Name |
|  --- |
| `TCP` |
| `HTTP` |
| `HTTPS` |

## Example

```ruby
protocol7 = Protocol7Enum::HTTP
```

