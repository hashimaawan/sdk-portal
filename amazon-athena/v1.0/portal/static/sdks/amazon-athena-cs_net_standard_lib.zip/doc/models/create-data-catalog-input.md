
# Create Data Catalog Input

## Structure

`CreateDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `Type` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `Tags` | [`List<Tag>`](../../doc/models/tag.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using System.Collections.Generic;

CreateDataCatalogInput createDataCatalogInput = new CreateDataCatalogInput
{
    Name = "Name6",
    Type = DataCatalogType1Enum.GLUE,
    Description = "Description2",
    Parameters = new Parameters
    {
    },
    Tags = new List<Tag>
    {
        new Tag
        {
            Key = "Key0",
            MValue = "Value6",
        },
        new Tag
        {
            Key = "Key0",
            MValue = "Value6",
        },
        new Tag
        {
            Key = "Key0",
            MValue = "Value6",
        },
    },
};
```

