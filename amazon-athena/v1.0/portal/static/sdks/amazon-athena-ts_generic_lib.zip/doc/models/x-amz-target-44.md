
# X Amz Target 44

## Enumeration

`XAmzTarget44`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListTagsForResource` |

## Example

```ts
import { XAmzTarget44 } from 'amazon-athenalib';

const xAmzTarget44 = XAmzTarget44.EnumAmazonAthenaListTagsForResource;
```

