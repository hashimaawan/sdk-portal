
# X Amz Target 17 Enum

## Enumeration

`XAmzTarget17Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETCALCULATIONEXECUTIONSTATUS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget17 := models.XAmzTarget17Enum_ENUMAMAZONATHENAGETCALCULATIONEXECUTIONSTATUS

}
```

