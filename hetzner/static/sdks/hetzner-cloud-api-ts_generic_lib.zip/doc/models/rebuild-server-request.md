
# Rebuild Server Request

## Structure

`RebuildServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image` | `string` | Required | ID or name of Image to rebuilt from. |

## Example

```ts
import { RebuildServerRequest } from 'hetzner-cloud-apilib';

const rebuildServerRequest: RebuildServerRequest = {
  image: 'ubuntu-20.04',
};
```

