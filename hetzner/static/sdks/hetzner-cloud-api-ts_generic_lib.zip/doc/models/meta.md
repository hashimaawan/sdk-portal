
# Meta

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination` | [`Pagination`](../../doc/models/pagination.md) | Required | - |

## Example

```ts
import { Meta } from 'hetzner-cloud-apilib';

const meta: Meta = {
  pagination: {
    lastPage: 4,
    nextPage: 4,
    page: 3,
    perPage: 25,
    previousPage: 2,
    totalEntries: 100,
  },
};
```

