
# X Amz Target 13

## Enumeration

`XAmzTarget13`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEWORKGROUP` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget13;

XAmzTarget13 xAmzTarget13 = XAmzTarget13.ENUM_AMAZONATHENADELETEWORKGROUP;
```

