
# Status Enum

Status of the Action

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `Success` |
| `Running` |
| `Error` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

StatusEnum status = StatusEnum.Error;
```

