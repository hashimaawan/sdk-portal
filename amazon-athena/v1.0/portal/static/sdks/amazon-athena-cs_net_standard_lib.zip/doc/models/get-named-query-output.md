
# Get Named Query Output

## Structure

`GetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQuery` | [`NamedQuery1`](../../doc/models/named-query-1.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetNamedQueryOutput getNamedQueryOutput = new GetNamedQueryOutput
{
    NamedQuery = new NamedQuery1
    {
        Name = "Name0",
        Database = "Database8",
        QueryString = "QueryString2",
        Description = "Description6",
        NamedQueryId = "NamedQueryId2",
        WorkGroup = "WorkGroup2",
    },
};
```

