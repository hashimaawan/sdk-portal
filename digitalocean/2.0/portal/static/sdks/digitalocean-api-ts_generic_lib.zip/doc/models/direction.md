
# Direction

## Enumeration

`Direction`

## Fields

| Name |
|  --- |
| `Inbound` |
| `Outbound` |

## Example

```ts
import { Direction } from 'digitalocean-apilib';

const direction = Direction.Inbound;
```

