
# Get Calculation Execution Code Response

*This model accepts additional fields of type unknown.*

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `codeBlock` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetCalculationExecutionCodeResponse } from 'amazon-athenalib';

const getCalculationExecutionCodeResponse: GetCalculationExecutionCodeResponse = {
  codeBlock: 'CodeBlock4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

