
# Result Reuse Configuration

Specifies the query result reuse behavior for the query.

## Structure

`ResultReuseConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result_reuse_by_age_configuration` | [`ResultReuseByAgeConfiguration2`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |

## Example

```python
from amazonathena.models.result_reuse_by_age_configuration_2 import ResultReuseByAgeConfiguration2
from amazonathena.models.result_reuse_configuration import ResultReuseConfiguration

result_reuse_configuration = ResultReuseConfiguration(
    result_reuse_by_age_configuration=ResultReuseByAgeConfiguration2(
        enabled=False,
        max_age_in_minutes=26
    )
)
```

