
# Alert

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Alert`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `disabled` | `bool` | Optional | Is the alert disabled? |
| `operator` | [`Operator`](../../doc/models/operator.md) | Optional | **Default**: `"UNSPECIFIED_OPERATOR"` |
| `rule` | [`Rule`](../../doc/models/rule.md) | Optional | **Default**: `"UNSPECIFIED_RULE"` |
| `value` | `float` | Optional | Threshold value for alert |
| `window` | [`Window`](../../doc/models/window.md) | Optional | **Default**: `"UNSPECIFIED_WINDOW"` |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.alert import Alert
from digitaloceanapi.models.operator import Operator
from digitaloceanapi.models.rule import Rule
from digitaloceanapi.models.window import Window

alert = Alert(
    disabled=False,
    operator=Operator.GREATER_THAN,
    rule=Rule.CPU_UTILIZATION,
    value=2.32,
    window=Window.FIVE_MINUTES,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

