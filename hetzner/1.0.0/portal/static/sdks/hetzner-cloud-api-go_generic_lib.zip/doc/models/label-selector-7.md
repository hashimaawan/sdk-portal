
# Label Selector 7

Label selector and a list of selected targets

*This model accepts additional fields of type interface{}.*

## Structure

`LabelSelector7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    labelSelector7 := models.LabelSelector7{
        Selector:              "env=prod",
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

