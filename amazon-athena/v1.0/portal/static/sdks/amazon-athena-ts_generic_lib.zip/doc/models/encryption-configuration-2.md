
# Encryption Configuration 2

*This model accepts additional fields of type unknown.*

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `encryptionOption` | [`EncryptionOption1`](../../doc/models/encryption-option-1.md) | Required | - |
| `kmsKey` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  EncryptionConfiguration2,
  EncryptionOption1,
} from 'amazon-athenalib';

const encryptionConfiguration2: EncryptionConfiguration2 = {
  encryptionOption: EncryptionOption1.SseS3,
  kmsKey: 'KmsKey2',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

