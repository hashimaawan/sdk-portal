
# Window

## Enumeration

`Window`

## Fields

| Name |
|  --- |
| `UNSPECIFIED_WINDOW` |
| `FIVE_MINUTES` |
| `TEN_MINUTES` |
| `THIRTY_MINUTES` |
| `ONE_HOUR` |

## Example

```php
use DigitalOceanApiLib\Models\Window;

$window = Window::ONE_HOUR;
```

