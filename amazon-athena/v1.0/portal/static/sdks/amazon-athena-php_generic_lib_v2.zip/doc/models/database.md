
# Database

Contains metadata information for a database in a data catalog.

## Structure

`Database`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | getName(): string | setName(string name): void |
| `description` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getDescription(): ?string | setDescription(?string description): void |
| `parameters` | [`?Parameters`](../../doc/models/parameters.md) | Optional | - | getParameters(): ?Parameters | setParameters(?Parameters parameters): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DatabaseBuilder;
use AmazonAthenaLib\Models\Builders\ParametersBuilder;

$database = DatabaseBuilder::init(
    'Name0'
)
    ->description('Description6')
    ->parameters(
        ParametersBuilder::init()->build()
    )->build();
```

