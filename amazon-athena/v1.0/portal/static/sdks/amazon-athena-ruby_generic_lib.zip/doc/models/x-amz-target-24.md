
# X Amz Target 24

## Enumeration

`XAmzTarget24`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRESULTS` |

## Example

```ruby
x_amz_target24 = XAmzTarget24::ENUM_AMAZONATHENAGETQUERYRESULTS
```

