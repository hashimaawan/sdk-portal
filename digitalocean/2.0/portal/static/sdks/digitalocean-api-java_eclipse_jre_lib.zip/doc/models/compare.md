
# Compare

## Enumeration

`Compare`

## Fields

| Name |
|  --- |
| `GREATERTHAN` |
| `LESSTHAN` |

## Example

```java
import com.digitalocean.api.models.Compare;

Compare compare = Compare.GREATERTHAN;
```

