
# Executor Type

## Enumeration

`ExecutorType`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```ruby
executor_type = ExecutorType::WORKER
```

