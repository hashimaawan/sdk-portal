
# Parameter Type 1

## Enumeration

`ParameterType1`

## Fields

| Name |
|  --- |
| `Spread` |

## Example

```ts
import { ParameterType1 } from 'hetzner-cloud-apilib';

const parameterType1 = ParameterType1.Spread;
```

