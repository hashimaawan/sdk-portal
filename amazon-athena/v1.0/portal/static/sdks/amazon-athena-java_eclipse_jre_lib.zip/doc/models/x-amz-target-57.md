
# X Amz Target 57

## Enumeration

`XAmzTarget57`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget57;

XAmzTarget57 xAmzTarget57 = XAmzTarget57.ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA;
```

