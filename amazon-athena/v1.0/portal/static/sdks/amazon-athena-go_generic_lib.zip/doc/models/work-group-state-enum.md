
# Work Group State Enum

## Enumeration

`WorkGroupStateEnum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    workGroupState := models.WorkGroupStateEnum_ENABLED

}
```

