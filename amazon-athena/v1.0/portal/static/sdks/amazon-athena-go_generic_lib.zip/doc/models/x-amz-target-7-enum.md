
# X Amz Target 7 Enum

## Enumeration

`XAmzTarget7Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENACREATEPRESIGNEDNOTEBOOKURL` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget7 := models.XAmzTarget7Enum_ENUMAMAZONATHENACREATEPRESIGNEDNOTEBOOKURL

}
```

