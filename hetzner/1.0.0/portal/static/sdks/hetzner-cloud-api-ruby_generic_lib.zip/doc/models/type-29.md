
# Type 29

Type of the resource

## Enumeration

`Type29`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |
| `IP` |

## Example

```ruby
type29 = Type29::SERVER
```

