# Files

```php
$filesApi = $client->getFilesApi();
```

## Class Name

`FilesApi`

## Methods

* [Get Item Files](../../doc/controllers/files.md#get-item-files)
* [Get Details of File by Id](../../doc/controllers/files.md#get-details-of-file-by-id)
* [Download File by ID](../../doc/controllers/files.md#download-file-by-id)


# Get Item Files

```php
function getItemFiles(string $vaultUuid, string $itemUuid, ?bool $inlineFiles = null): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Items from |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to fetch files from |
| `inlineFiles` | `?bool` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`File[]`](../../doc/models/file.md).

## Example Usage

```php
$vaultUuid = '00002186-0000-0000-0000-000000000000';

$itemUuid = '0000141a-0000-0000-0000-000000000000';

$inlineFiles = true;

$filesApi = $client->getFilesApi();
$apiResponse = $filesApi->getItemFiles(
    $vaultUuid,
    $itemUuid,
    $inlineFiles
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'File[]:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Details of File by Id

```php
function getDetailsOfFileById(
    string $vaultUuid,
    string $itemUuid,
    string $fileUuid,
    ?bool $inlineFiles = null
): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Item from |
| `itemUuid` | `string` | Template, Required | The UUID of the Item to fetch File from |
| `fileUuid` | `string` | Template, Required | The UUID of the File to fetch |
| `inlineFiles` | `?bool` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`File`](../../doc/models/file.md).

## Example Usage

```php
$vaultUuid = '00002186-0000-0000-0000-000000000000';

$itemUuid = '0000141a-0000-0000-0000-000000000000';

$fileUuid = '000008e0-0000-0000-0000-000000000000';

$inlineFiles = true;

$filesApi = $client->getFilesApi();
$apiResponse = $filesApi->getDetailsOfFileById(
    $vaultUuid,
    $itemUuid,
    $fileUuid,
    $inlineFiles
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'File:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Download File by ID

```php
function downloadFileById(string $vaultUuid, string $itemUuid, string $fileUuid): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault the item is in |
| `itemUuid` | `string` | Template, Required | The UUID of the Item the File is in |
| `fileUuid` | `string` | Template, Required | UUID of the file to get content from |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type `string`.

## Example Usage

```php
$vaultUuid = '00002186-0000-0000-0000-000000000000';

$itemUuid = '0000141a-0000-0000-0000-000000000000';

$fileUuid = 'fileUuid2';

$filesApi = $client->getFilesApi();
$apiResponse = $filesApi->downloadFileById(
    $vaultUuid,
    $itemUuid,
    $fileUuid
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'string:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

