
# Datacenter 2

Datacenter this Primary IP is located at

## Structure

`Datacenter2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Required | Description of the Datacenter |
| `Id` | `int` | Required | ID of the Resource |
| `Location` | [`Location`](../../doc/models/location.md) | Required | - |
| `Name` | `string` | Required | Unique identifier of the Datacenter |
| `ServerTypes` | [`ServerTypes`](../../doc/models/server-types.md) | Required | The Server types the Datacenter can handle |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

Datacenter2 datacenter2 = new Datacenter2
{
    Description = "Falkenstein DC Park 8",
    Id = 42,
    Location = new Location
    {
        City = "Falkenstein",
        Country = "DE",
        Description = "Falkenstein DC Park 1",
        Id = 1,
        Latitude = 50.47612,
        Longitude = 12.370071,
        Name = "fsn1",
        NetworkZone = "eu-central",
    },
    Name = "fsn1-dc8",
    ServerTypes = new ServerTypes
    {
        Available = new List<double>
        {
            1,
            2,
            3,
        },
        AvailableForMigration = new List<double>
        {
            1,
            2,
            3,
        },
        Supported = new List<double>
        {
            1,
            2,
            3,
        },
    },
};
```

