
# Type 24 Enum

Destination Image type to convert to

## Enumeration

`Type24Enum`

## Fields

| Name |
|  --- |
| `SNAPSHOT` |

## Example

```ruby
type24 = Type24Enum::SNAPSHOT
```

