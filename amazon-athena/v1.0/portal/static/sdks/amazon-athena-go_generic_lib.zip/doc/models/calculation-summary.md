
# Calculation Summary

Summary information for a notebook calculation.

## Structure

`CalculationSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `Description` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Status` | [`*models.Status1`](../../doc/models/status-1.md) | Optional | - |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonathena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    calculationSummary := models.CalculationSummary{
        CalculationExecutionId: models.ToPointer("CalculationExecutionId4"),
        Description:            models.ToPointer("Description6"),
        Status:                 models.ToPointer(models.Status1{
            SubmissionDateTime:   models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
            CompletionDateTime:   models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
            State:                models.ToPointer(models.CalculationExecutionState1Enum_CANCELING),
            StateChangeReason:    models.ToPointer("StateChangeReason8"),
        }),
    }

}
```

