
# Eu West

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`EuWest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`Status16 \| undefined`](../../doc/models/status-16.md) | Optional | - |
| `statusChangedAt` | `string \| undefined` | Optional | - |
| `thirtyDayUptimePercentage` | `number \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { EuWest, Status16 } from 'digitalocean-apilib';

const euWest: EuWest = {
  status: Status16.Up,
  statusChangedAt: '2022-03-17T22:28:51Z',
  thirtyDayUptimePercentage: 97.99,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

