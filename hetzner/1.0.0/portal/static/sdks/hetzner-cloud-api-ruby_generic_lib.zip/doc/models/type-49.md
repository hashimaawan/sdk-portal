
# Type 49

The type of the Primary IP

## Enumeration

`Type49`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```ruby
type49 = Type49::IPV4
```

