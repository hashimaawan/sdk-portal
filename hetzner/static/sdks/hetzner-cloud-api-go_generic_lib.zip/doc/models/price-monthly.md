
# Price Monthly

Monthly costs for a Resource in this Location

## Structure

`PriceMonthly`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    priceMonthly := models.PriceMonthly{
        Gross:                "1.1900000000000000",
        Net:                  "1.0000000000",
    }

}
```

