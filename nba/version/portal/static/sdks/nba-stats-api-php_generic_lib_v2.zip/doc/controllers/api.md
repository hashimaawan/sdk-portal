# API

```php
$aPIController = $client->getAPIController();
```

## Class Name

`APIController`

## Methods

* [Allstarballotpredictor GET](../../doc/controllers/api.md#allstarballotpredictor-get)
* [Boxscore GET](../../doc/controllers/api.md#boxscore-get)
* [Boxscoreadvanced GET](../../doc/controllers/api.md#boxscoreadvanced-get)
* [Boxscoreadvancedv 2 GET](../../doc/controllers/api.md#boxscoreadvancedv-2-get)
* [Boxscorefourfactors GET](../../doc/controllers/api.md#boxscorefourfactors-get)
* [Boxscorefourfactorsv 2 GET](../../doc/controllers/api.md#boxscorefourfactorsv-2-get)
* [Boxscoremisc GET](../../doc/controllers/api.md#boxscoremisc-get)
* [Boxscoremiscv 2 GET](../../doc/controllers/api.md#boxscoremiscv-2-get)
* [Boxscoreplayertrackv 2 GET](../../doc/controllers/api.md#boxscoreplayertrackv-2-get)
* [Boxscorescoring GET](../../doc/controllers/api.md#boxscorescoring-get)
* [Boxscorescoringv 2 GET](../../doc/controllers/api.md#boxscorescoringv-2-get)
* [Boxscoresummaryv 2 GET](../../doc/controllers/api.md#boxscoresummaryv-2-get)
* [Boxscoretraditionalv 2 GET](../../doc/controllers/api.md#boxscoretraditionalv-2-get)
* [Boxscoreusage GET](../../doc/controllers/api.md#boxscoreusage-get)
* [Boxscoreusagev 2 GET](../../doc/controllers/api.md#boxscoreusagev-2-get)
* [Common Team Years GET](../../doc/controllers/api.md#common-team-years-get)
* [Commonallplayers GET](../../doc/controllers/api.md#commonallplayers-get)
* [Commonplayerinfo GET](../../doc/controllers/api.md#commonplayerinfo-get)
* [Commonplayoffseries GET](../../doc/controllers/api.md#commonplayoffseries-get)
* [Commonteamroster GET](../../doc/controllers/api.md#commonteamroster-get)
* [Draftcombinedrillresults GET](../../doc/controllers/api.md#draftcombinedrillresults-get)
* [Draftcombinenonstationaryshooting GET](../../doc/controllers/api.md#draftcombinenonstationaryshooting-get)
* [Draftcombineplayeranthro GET](../../doc/controllers/api.md#draftcombineplayeranthro-get)
* [Draftcombinespotshooting GET](../../doc/controllers/api.md#draftcombinespotshooting-get)
* [Draftcombinestats GET](../../doc/controllers/api.md#draftcombinestats-get)
* [Drafthistory GET](../../doc/controllers/api.md#drafthistory-get)
* [Franchisehistory GET](../../doc/controllers/api.md#franchisehistory-get)
* [Homepageleaders GET](../../doc/controllers/api.md#homepageleaders-get)
* [Homepagev 2 GET](../../doc/controllers/api.md#homepagev-2-get)
* [Leaderstiles GET](../../doc/controllers/api.md#leaderstiles-get)
* [Leaguedashlineups GET](../../doc/controllers/api.md#leaguedashlineups-get)
* [Leaguedashplayerbiostats GET](../../doc/controllers/api.md#leaguedashplayerbiostats-get)
* [Leaguedashplayerclutch GET](../../doc/controllers/api.md#leaguedashplayerclutch-get)
* [Leaguedashplayerptshot GET](../../doc/controllers/api.md#leaguedashplayerptshot-get)
* [Leaguedashplayershotlocations GET](../../doc/controllers/api.md#leaguedashplayershotlocations-get)
* [Leaguedashplayerstats GET](../../doc/controllers/api.md#leaguedashplayerstats-get)
* [Leaguedashptdefend GET](../../doc/controllers/api.md#leaguedashptdefend-get)
* [Leaguedashptteamdefend GET](../../doc/controllers/api.md#leaguedashptteamdefend-get)
* [Leaguedashteamclutch GET](../../doc/controllers/api.md#leaguedashteamclutch-get)
* [Leaguedashteamptshot GET](../../doc/controllers/api.md#leaguedashteamptshot-get)
* [Leaguedashteamshotlocations GET](../../doc/controllers/api.md#leaguedashteamshotlocations-get)
* [Leaguedashteamstats GET](../../doc/controllers/api.md#leaguedashteamstats-get)
* [Leagueleaders GET](../../doc/controllers/api.md#leagueleaders-get)
* [Playbyplay GET](../../doc/controllers/api.md#playbyplay-get)
* [Playbyplayv 2 GET](../../doc/controllers/api.md#playbyplayv-2-get)
* [Playercareerstats GET](../../doc/controllers/api.md#playercareerstats-get)
* [Playercompare GET](../../doc/controllers/api.md#playercompare-get)
* [Playerdashboardbyclutch GET](../../doc/controllers/api.md#playerdashboardbyclutch-get)
* [Playerdashboardbygamesplits GET](../../doc/controllers/api.md#playerdashboardbygamesplits-get)
* [Playerdashboardbygeneralsplits GET](../../doc/controllers/api.md#playerdashboardbygeneralsplits-get)
* [Playerdashboardbylastngames GET](../../doc/controllers/api.md#playerdashboardbylastngames-get)
* [Playerdashboardbyopponent GET](../../doc/controllers/api.md#playerdashboardbyopponent-get)
* [Playerdashboardbyshootingsplits GET](../../doc/controllers/api.md#playerdashboardbyshootingsplits-get)
* [Playerdashboardbyteamperformance GET](../../doc/controllers/api.md#playerdashboardbyteamperformance-get)
* [Playerdashboardbyyearoveryear GET](../../doc/controllers/api.md#playerdashboardbyyearoveryear-get)
* [Playerdashptpass GET](../../doc/controllers/api.md#playerdashptpass-get)
* [Playerdashptreb GET](../../doc/controllers/api.md#playerdashptreb-get)
* [Playerdashptreboundlogs GET](../../doc/controllers/api.md#playerdashptreboundlogs-get)
* [Playerdashptshotdefend GET](../../doc/controllers/api.md#playerdashptshotdefend-get)
* [Playerdashptshotlog GET](../../doc/controllers/api.md#playerdashptshotlog-get)
* [Playerdashptshots GET](../../doc/controllers/api.md#playerdashptshots-get)
* [Playergamelog GET](../../doc/controllers/api.md#playergamelog-get)
* [Playerprofile GET](../../doc/controllers/api.md#playerprofile-get)
* [Playerprofilev 2 GET](../../doc/controllers/api.md#playerprofilev-2-get)
* [Playersvsplayers GET](../../doc/controllers/api.md#playersvsplayers-get)
* [Playervsplayer GET](../../doc/controllers/api.md#playervsplayer-get)
* [Playoffpicture GET](../../doc/controllers/api.md#playoffpicture-get)
* [Scoreboard GET](../../doc/controllers/api.md#scoreboard-get)
* [Scoreboard V2 GET](../../doc/controllers/api.md#scoreboard-v2-get)
* [Shotchartdetail GET](../../doc/controllers/api.md#shotchartdetail-get)
* [Shotchartlineupdetail GET](../../doc/controllers/api.md#shotchartlineupdetail-get)
* [Teamdashboardbyclutch GET](../../doc/controllers/api.md#teamdashboardbyclutch-get)
* [Teamdashboardbygamesplits GET](../../doc/controllers/api.md#teamdashboardbygamesplits-get)
* [Teamdashboardbygeneralsplits GET](../../doc/controllers/api.md#teamdashboardbygeneralsplits-get)
* [Teamdashboardbylastngames GET](../../doc/controllers/api.md#teamdashboardbylastngames-get)
* [Teamdashboardbyopponent GET](../../doc/controllers/api.md#teamdashboardbyopponent-get)
* [Teamdashboardbyshootingsplits GET](../../doc/controllers/api.md#teamdashboardbyshootingsplits-get)
* [Teamdashboardbyteamperformance GET](../../doc/controllers/api.md#teamdashboardbyteamperformance-get)
* [Teamdashboardbyyearoveryear GET](../../doc/controllers/api.md#teamdashboardbyyearoveryear-get)
* [Teamdashlineups GET](../../doc/controllers/api.md#teamdashlineups-get)
* [Teamdashptpass GET](../../doc/controllers/api.md#teamdashptpass-get)
* [Teamdashptreb GET](../../doc/controllers/api.md#teamdashptreb-get)
* [Teamdashptshots GET](../../doc/controllers/api.md#teamdashptshots-get)
* [Teamgamelog GET](../../doc/controllers/api.md#teamgamelog-get)
* [Teaminfocommon GET](../../doc/controllers/api.md#teaminfocommon-get)
* [Teamplayerdashboard GET](../../doc/controllers/api.md#teamplayerdashboard-get)
* [Teamplayeronoffdetails GET](../../doc/controllers/api.md#teamplayeronoffdetails-get)
* [Teamplayeronoffsummary GET](../../doc/controllers/api.md#teamplayeronoffsummary-get)
* [Teamvsplayer GET](../../doc/controllers/api.md#teamvsplayer-get)
* [Teamyearbyyearstats GET](../../doc/controllers/api.md#teamyearbyyearstats-get)
* [Video Status GET](../../doc/controllers/api.md#video-status-get)


# Allstarballotpredictor GET

```php
function allstarballotpredictorGET(
    string $westPlayer1,
    string $westPlayer2,
    string $westPlayer3,
    string $westPlayer4,
    string $westPlayer5,
    string $eastPlayer1,
    string $eastPlayer2,
    string $eastPlayer3,
    string $eastPlayer4,
    string $eastPlayer5,
    ?string $pointCap = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `westPlayer1` | `string` | Query, Required | - |
| `westPlayer2` | `string` | Query, Required | - |
| `westPlayer3` | `string` | Query, Required | - |
| `westPlayer4` | `string` | Query, Required | - |
| `westPlayer5` | `string` | Query, Required | - |
| `eastPlayer1` | `string` | Query, Required | - |
| `eastPlayer2` | `string` | Query, Required | - |
| `eastPlayer3` | `string` | Query, Required | - |
| `eastPlayer4` | `string` | Query, Required | - |
| `eastPlayer5` | `string` | Query, Required | - |
| `pointCap` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$westPlayer1 = 'WestPlayer10';

$westPlayer2 = 'WestPlayer24';

$westPlayer3 = 'WestPlayer32';

$westPlayer4 = 'WestPlayer48';

$westPlayer5 = 'WestPlayer56';

$eastPlayer1 = 'EastPlayer18';

$eastPlayer2 = 'EastPlayer26';

$eastPlayer3 = 'EastPlayer32';

$eastPlayer4 = 'EastPlayer44';

$eastPlayer5 = 'EastPlayer54';

$aPIController = $client->getAPIController();

try {
    $aPIController->allstarballotpredictorGET(
        $westPlayer1,
        $westPlayer2,
        $westPlayer3,
        $westPlayer4,
        $westPlayer5,
        $eastPlayer1,
        $eastPlayer2,
        $eastPlayer3,
        $eastPlayer4,
        $eastPlayer5
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscore GET

```php
function boxscoreGET(
    ?string $gameID = null,
    ?string $startPeriod = null,
    ?string $endPeriod = null,
    ?string $startRange = null,
    ?string $endRange = null,
    ?string $rangeType = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `?string` | Query, Optional | - |
| `startPeriod` | `?string` | Query, Optional | - |
| `endPeriod` | `?string` | Query, Optional | - |
| `startRange` | `?string` | Query, Optional | - |
| `endRange` | `?string` | Query, Optional | - |
| `rangeType` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoreGET();
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoreadvanced GET

```php
function boxscoreadvancedGET(
    ?string $gameID = null,
    ?string $startPeriod = null,
    ?string $endPeriod = null,
    ?string $startRange = null,
    ?string $endRange = null,
    ?string $rangeType = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `?string` | Query, Optional | - |
| `startPeriod` | `?string` | Query, Optional | - |
| `endPeriod` | `?string` | Query, Optional | - |
| `startRange` | `?string` | Query, Optional | - |
| `endRange` | `?string` | Query, Optional | - |
| `rangeType` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoreadvancedGET();
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoreadvancedv 2 GET

```php
function boxscoreadvancedv2GET(
    string $gameID,
    string $startPeriod,
    string $endPeriod,
    string $startRange,
    string $endRange,
    string $rangeType
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |
| `startPeriod` | `string` | Query, Required | - |
| `endPeriod` | `string` | Query, Required | - |
| `startRange` | `string` | Query, Required | - |
| `endRange` | `string` | Query, Required | - |
| `rangeType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$startPeriod = 'StartPeriod4';

$endPeriod = 'EndPeriod0';

$startRange = 'StartRange0';

$endRange = 'EndRange2';

$rangeType = 'RangeType0';

$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoreadvancedv2GET(
        $gameID,
        $startPeriod,
        $endPeriod,
        $startRange,
        $endRange,
        $rangeType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscorefourfactors GET

```php
function boxscorefourfactorsGET(
    ?string $gameID = null,
    ?string $startPeriod = null,
    ?string $endPeriod = null,
    ?string $startRange = null,
    ?string $endRange = null,
    ?string $rangeType = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `?string` | Query, Optional | - |
| `startPeriod` | `?string` | Query, Optional | - |
| `endPeriod` | `?string` | Query, Optional | - |
| `startRange` | `?string` | Query, Optional | - |
| `endRange` | `?string` | Query, Optional | - |
| `rangeType` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$aPIController = $client->getAPIController();

try {
    $aPIController->boxscorefourfactorsGET();
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscorefourfactorsv 2 GET

```php
function boxscorefourfactorsv2GET(
    string $gameID,
    string $startPeriod,
    string $endPeriod,
    string $startRange,
    string $endRange,
    string $rangeType
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |
| `startPeriod` | `string` | Query, Required | - |
| `endPeriod` | `string` | Query, Required | - |
| `startRange` | `string` | Query, Required | - |
| `endRange` | `string` | Query, Required | - |
| `rangeType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$startPeriod = 'StartPeriod4';

$endPeriod = 'EndPeriod0';

$startRange = 'StartRange0';

$endRange = 'EndRange2';

$rangeType = 'RangeType0';

$aPIController = $client->getAPIController();

try {
    $aPIController->boxscorefourfactorsv2GET(
        $gameID,
        $startPeriod,
        $endPeriod,
        $startRange,
        $endRange,
        $rangeType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoremisc GET

```php
function boxscoremiscGET(
    ?string $gameID = null,
    ?string $startPeriod = null,
    ?string $endPeriod = null,
    ?string $startRange = null,
    ?string $endRange = null,
    ?string $rangeType = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `?string` | Query, Optional | - |
| `startPeriod` | `?string` | Query, Optional | - |
| `endPeriod` | `?string` | Query, Optional | - |
| `startRange` | `?string` | Query, Optional | - |
| `endRange` | `?string` | Query, Optional | - |
| `rangeType` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoremiscGET();
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoremiscv 2 GET

```php
function boxscoremiscv2GET(
    string $gameID,
    string $startPeriod,
    string $endPeriod,
    string $startRange,
    string $endRange,
    string $rangeType
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |
| `startPeriod` | `string` | Query, Required | - |
| `endPeriod` | `string` | Query, Required | - |
| `startRange` | `string` | Query, Required | - |
| `endRange` | `string` | Query, Required | - |
| `rangeType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$startPeriod = 'StartPeriod4';

$endPeriod = 'EndPeriod0';

$startRange = 'StartRange0';

$endRange = 'EndRange2';

$rangeType = 'RangeType0';

$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoremiscv2GET(
        $gameID,
        $startPeriod,
        $endPeriod,
        $startRange,
        $endRange,
        $rangeType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoreplayertrackv 2 GET

```php
function boxscoreplayertrackv2GET(string $gameID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoreplayertrackv2GET($gameID);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscorescoring GET

```php
function boxscorescoringGET(
    ?string $gameID = null,
    ?string $startPeriod = null,
    ?string $endPeriod = null,
    ?string $startRange = null,
    ?string $endRange = null,
    ?string $rangeType = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `?string` | Query, Optional | - |
| `startPeriod` | `?string` | Query, Optional | - |
| `endPeriod` | `?string` | Query, Optional | - |
| `startRange` | `?string` | Query, Optional | - |
| `endRange` | `?string` | Query, Optional | - |
| `rangeType` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$aPIController = $client->getAPIController();

try {
    $aPIController->boxscorescoringGET();
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscorescoringv 2 GET

```php
function boxscorescoringv2GET(
    string $gameID,
    string $startPeriod,
    string $endPeriod,
    string $startRange,
    string $endRange,
    string $rangeType
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |
| `startPeriod` | `string` | Query, Required | - |
| `endPeriod` | `string` | Query, Required | - |
| `startRange` | `string` | Query, Required | - |
| `endRange` | `string` | Query, Required | - |
| `rangeType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$startPeriod = 'StartPeriod4';

$endPeriod = 'EndPeriod0';

$startRange = 'StartRange0';

$endRange = 'EndRange2';

$rangeType = 'RangeType0';

$aPIController = $client->getAPIController();

try {
    $aPIController->boxscorescoringv2GET(
        $gameID,
        $startPeriod,
        $endPeriod,
        $startRange,
        $endRange,
        $rangeType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoresummaryv 2 GET

```php
function boxscoresummaryv2GET(string $gameID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoresummaryv2GET($gameID);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoretraditionalv 2 GET

```php
function boxscoretraditionalv2GET(
    string $gameID,
    string $startPeriod,
    string $endPeriod,
    string $startRange,
    string $endRange,
    string $rangeType
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |
| `startPeriod` | `string` | Query, Required | - |
| `endPeriod` | `string` | Query, Required | - |
| `startRange` | `string` | Query, Required | - |
| `endRange` | `string` | Query, Required | - |
| `rangeType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$startPeriod = 'StartPeriod4';

$endPeriod = 'EndPeriod0';

$startRange = 'StartRange0';

$endRange = 'EndRange2';

$rangeType = 'RangeType0';

$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoretraditionalv2GET(
        $gameID,
        $startPeriod,
        $endPeriod,
        $startRange,
        $endRange,
        $rangeType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoreusage GET

```php
function boxscoreusageGET(
    ?string $gameID = null,
    ?string $startPeriod = null,
    ?string $endPeriod = null,
    ?string $startRange = null,
    ?string $endRange = null,
    ?string $rangeType = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `?string` | Query, Optional | - |
| `startPeriod` | `?string` | Query, Optional | - |
| `endPeriod` | `?string` | Query, Optional | - |
| `startRange` | `?string` | Query, Optional | - |
| `endRange` | `?string` | Query, Optional | - |
| `rangeType` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoreusageGET();
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Boxscoreusagev 2 GET

```php
function boxscoreusagev2GET(
    string $gameID,
    string $startPeriod,
    string $endPeriod,
    string $startRange,
    string $endRange,
    string $rangeType
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |
| `startPeriod` | `string` | Query, Required | - |
| `endPeriod` | `string` | Query, Required | - |
| `startRange` | `string` | Query, Required | - |
| `endRange` | `string` | Query, Required | - |
| `rangeType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$startPeriod = 'StartPeriod4';

$endPeriod = 'EndPeriod0';

$startRange = 'StartRange0';

$endRange = 'EndRange2';

$rangeType = 'RangeType0';

$aPIController = $client->getAPIController();

try {
    $aPIController->boxscoreusagev2GET(
        $gameID,
        $startPeriod,
        $endPeriod,
        $startRange,
        $endRange,
        $rangeType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Common Team Years GET

```php
function commonTeamYearsGET(string $leagueID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$aPIController = $client->getAPIController();

try {
    $aPIController->commonTeamYearsGET($leagueID);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Commonallplayers GET

```php
function commonallplayersGET(string $leagueID, string $season, string $isOnlyCurrentSeason): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `isOnlyCurrentSeason` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$season = 'Season0';

$isOnlyCurrentSeason = 'IsOnlyCurrentSeason6';

$aPIController = $client->getAPIController();

try {
    $aPIController->commonallplayersGET(
        $leagueID,
        $season,
        $isOnlyCurrentSeason
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Commonplayerinfo GET

```php
function commonplayerinfoGET(string $playerID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `playerID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$playerID = 'PlayerID6';

$aPIController = $client->getAPIController();

try {
    $aPIController->commonplayerinfoGET($playerID);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Commonplayoffseries GET

```php
function commonplayoffseriesGET(string $leagueID, string $season): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$season = 'Season0';

$aPIController = $client->getAPIController();

try {
    $aPIController->commonplayoffseriesGET(
        $leagueID,
        $season
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Commonteamroster GET

```php
function commonteamrosterGET(string $season, string $teamID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$season = 'Season0';

$teamID = 'TeamID8';

$aPIController = $client->getAPIController();

try {
    $aPIController->commonteamrosterGET(
        $season,
        $teamID
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Draftcombinedrillresults GET

```php
function draftcombinedrillresultsGET(string $leagueID, string $seasonYear): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `seasonYear` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$seasonYear = 'SeasonYear6';

$aPIController = $client->getAPIController();

try {
    $aPIController->draftcombinedrillresultsGET(
        $leagueID,
        $seasonYear
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Draftcombinenonstationaryshooting GET

```php
function draftcombinenonstationaryshootingGET(string $leagueID, string $seasonYear): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `seasonYear` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$seasonYear = 'SeasonYear6';

$aPIController = $client->getAPIController();

try {
    $aPIController->draftcombinenonstationaryshootingGET(
        $leagueID,
        $seasonYear
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Draftcombineplayeranthro GET

```php
function draftcombineplayeranthroGET(string $leagueID, string $seasonYear): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `seasonYear` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$seasonYear = 'SeasonYear6';

$aPIController = $client->getAPIController();

try {
    $aPIController->draftcombineplayeranthroGET(
        $leagueID,
        $seasonYear
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Draftcombinespotshooting GET

```php
function draftcombinespotshootingGET(string $leagueID, string $seasonYear): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `seasonYear` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$seasonYear = 'SeasonYear6';

$aPIController = $client->getAPIController();

try {
    $aPIController->draftcombinespotshootingGET(
        $leagueID,
        $seasonYear
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Draftcombinestats GET

```php
function draftcombinestatsGET(string $leagueID, string $seasonYear): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `seasonYear` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$seasonYear = 'SeasonYear6';

$aPIController = $client->getAPIController();

try {
    $aPIController->draftcombinestatsGET(
        $leagueID,
        $seasonYear
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Drafthistory GET

```php
function drafthistoryGET(string $leagueID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$aPIController = $client->getAPIController();

try {
    $aPIController->drafthistoryGET($leagueID);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Franchisehistory GET

```php
function franchisehistoryGET(string $leagueID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$aPIController = $client->getAPIController();

try {
    $aPIController->franchisehistoryGET($leagueID);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Homepageleaders GET

```php
function homepageleadersGET(
    string $statCategory,
    string $leagueID,
    string $season,
    string $seasonType,
    string $playerOrTeam,
    string $playerScope,
    string $gameScope,
    ?string $game = null,
    ?string $player = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statCategory` | `string` | Query, Required | - |
| `leagueID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerOrTeam` | `string` | Query, Required | - |
| `playerScope` | `string` | Query, Required | - |
| `gameScope` | `string` | Query, Required | - |
| `game` | `?string` | Query, Optional | - |
| `player` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$statCategory = 'StatCategory6';

$leagueID = 'LeagueID4';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerOrTeam = 'PlayerOrTeam8';

$playerScope = 'PlayerScope2';

$gameScope = 'GameScope0';

$aPIController = $client->getAPIController();

try {
    $aPIController->homepageleadersGET(
        $statCategory,
        $leagueID,
        $season,
        $seasonType,
        $playerOrTeam,
        $playerScope,
        $gameScope
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Homepagev 2 GET

```php
function homepagev2GET(
    string $statType,
    string $leagueID,
    string $season,
    string $seasonType,
    string $playerOrTeam,
    string $playerScope,
    string $gameScope,
    ?string $game = null,
    ?string $player = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statType` | `string` | Query, Required | - |
| `leagueID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerOrTeam` | `string` | Query, Required | - |
| `playerScope` | `string` | Query, Required | - |
| `gameScope` | `string` | Query, Required | - |
| `game` | `?string` | Query, Optional | - |
| `player` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$statType = 'StatType8';

$leagueID = 'LeagueID4';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerOrTeam = 'PlayerOrTeam8';

$playerScope = 'PlayerScope2';

$gameScope = 'GameScope0';

$aPIController = $client->getAPIController();

try {
    $aPIController->homepagev2GET(
        $statType,
        $leagueID,
        $season,
        $seasonType,
        $playerOrTeam,
        $playerScope,
        $gameScope
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaderstiles GET

```php
function leaderstilesGET(
    string $stat,
    string $leagueID,
    string $season,
    string $seasonType,
    string $playerOrTeam,
    string $playerScope,
    string $gameScope,
    ?string $game = null,
    ?string $player = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stat` | `string` | Query, Required | - |
| `leagueID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerOrTeam` | `string` | Query, Required | - |
| `playerScope` | `string` | Query, Required | - |
| `gameScope` | `string` | Query, Required | - |
| `game` | `?string` | Query, Optional | - |
| `player` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$stat = 'Stat2';

$leagueID = 'LeagueID4';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerOrTeam = 'PlayerOrTeam8';

$playerScope = 'PlayerScope2';

$gameScope = 'GameScope0';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaderstilesGET(
        $stat,
        $leagueID,
        $season,
        $seasonType,
        $playerOrTeam,
        $playerScope,
        $gameScope
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashlineups GET

```php
function leaguedashlineupsGET(
    string $groupQuantity,
    string $seasonType,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `groupQuantity` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$groupQuantity = 'GroupQuantity0';

$seasonType = 'SeasonType8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashlineupsGET(
        $groupQuantity,
        $seasonType,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashplayerbiostats GET

```php
function leaguedashplayerbiostatsGET(
    string $perMode,
    string $leagueID,
    string $season,
    string $seasonType
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `leagueID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$leagueID = 'LeagueID4';

$season = 'Season0';

$seasonType = 'SeasonType8';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashplayerbiostatsGET(
        $perMode,
        $leagueID,
        $season,
        $seasonType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashplayerclutch GET

```php
function leaguedashplayerclutchGET(
    string $clutchTime,
    string $aheadBehind,
    string $pointDiff,
    string $gameScope,
    string $playerExperience,
    string $playerPosition,
    string $starterBench,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clutchTime` | `string` | Query, Required | - |
| `aheadBehind` | `string` | Query, Required | - |
| `pointDiff` | `string` | Query, Required | - |
| `gameScope` | `string` | Query, Required | - |
| `playerExperience` | `string` | Query, Required | - |
| `playerPosition` | `string` | Query, Required | - |
| `starterBench` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$clutchTime = 'ClutchTime4';

$aheadBehind = 'AheadBehind8';

$pointDiff = 'PointDiff6';

$gameScope = 'GameScope0';

$playerExperience = 'PlayerExperience4';

$playerPosition = 'PlayerPosition8';

$starterBench = 'StarterBench0';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashplayerclutchGET(
        $clutchTime,
        $aheadBehind,
        $pointDiff,
        $gameScope,
        $playerExperience,
        $playerPosition,
        $starterBench,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashplayerptshot GET

```php
function leaguedashplayerptshotGET(string $leagueID, string $perMode, string $season, string $seasonType): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashplayerptshotGET(
        $leagueID,
        $perMode,
        $season,
        $seasonType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashplayershotlocations GET

```php
function leaguedashplayershotlocationsGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames,
    string $distanceRange,
    string $gameScope,
    string $playerExperience,
    string $playerPosition,
    string $starterBench
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |
| `distanceRange` | `string` | Query, Required | - |
| `gameScope` | `string` | Query, Required | - |
| `playerExperience` | `string` | Query, Required | - |
| `playerPosition` | `string` | Query, Required | - |
| `starterBench` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$distanceRange = 'DistanceRange6';

$gameScope = 'GameScope0';

$playerExperience = 'PlayerExperience4';

$playerPosition = 'PlayerPosition8';

$starterBench = 'StarterBench0';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashplayershotlocationsGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames,
        $distanceRange,
        $gameScope,
        $playerExperience,
        $playerPosition,
        $starterBench
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashplayerstats GET

```php
function leaguedashplayerstatsGET(
    string $gameScope,
    string $playerExperience,
    string $playerPosition,
    string $starterBench,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameScope` | `string` | Query, Required | - |
| `playerExperience` | `string` | Query, Required | - |
| `playerPosition` | `string` | Query, Required | - |
| `starterBench` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameScope = 'GameScope0';

$playerExperience = 'PlayerExperience4';

$playerPosition = 'PlayerPosition8';

$starterBench = 'StarterBench0';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashplayerstatsGET(
        $gameScope,
        $playerExperience,
        $playerPosition,
        $starterBench,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashptdefend GET

```php
function leaguedashptdefendGET(
    string $leagueID,
    string $perMode,
    string $season,
    string $seasonType,
    string $defenseCategory
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `defenseCategory` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$defenseCategory = 'DefenseCategory0';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashptdefendGET(
        $leagueID,
        $perMode,
        $season,
        $seasonType,
        $defenseCategory
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashptteamdefend GET

```php
function leaguedashptteamdefendGET(
    string $leagueID,
    string $perMode,
    string $season,
    string $seasonType,
    string $defenseCategory
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `defenseCategory` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$defenseCategory = 'DefenseCategory0';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashptteamdefendGET(
        $leagueID,
        $perMode,
        $season,
        $seasonType,
        $defenseCategory
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashteamclutch GET

```php
function leaguedashteamclutchGET(
    string $clutchTime,
    string $aheadBehind,
    string $pointDiff,
    string $gameScope,
    string $playerExperience,
    string $playerPosition,
    string $starterBench,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clutchTime` | `string` | Query, Required | - |
| `aheadBehind` | `string` | Query, Required | - |
| `pointDiff` | `string` | Query, Required | - |
| `gameScope` | `string` | Query, Required | - |
| `playerExperience` | `string` | Query, Required | - |
| `playerPosition` | `string` | Query, Required | - |
| `starterBench` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$clutchTime = 'ClutchTime4';

$aheadBehind = 'AheadBehind8';

$pointDiff = 'PointDiff6';

$gameScope = 'GameScope0';

$playerExperience = 'PlayerExperience4';

$playerPosition = 'PlayerPosition8';

$starterBench = 'StarterBench0';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashteamclutchGET(
        $clutchTime,
        $aheadBehind,
        $pointDiff,
        $gameScope,
        $playerExperience,
        $playerPosition,
        $starterBench,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashteamptshot GET

```php
function leaguedashteamptshotGET(string $leagueID, string $perMode, string $season, string $seasonType): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashteamptshotGET(
        $leagueID,
        $perMode,
        $season,
        $seasonType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashteamshotlocations GET

```php
function leaguedashteamshotlocationsGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames,
    string $distanceRange,
    string $gameScope,
    string $playerExperience,
    string $playerPosition,
    string $starterBench
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |
| `distanceRange` | `string` | Query, Required | - |
| `gameScope` | `string` | Query, Required | - |
| `playerExperience` | `string` | Query, Required | - |
| `playerPosition` | `string` | Query, Required | - |
| `starterBench` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$distanceRange = 'DistanceRange6';

$gameScope = 'GameScope0';

$playerExperience = 'PlayerExperience4';

$playerPosition = 'PlayerPosition8';

$starterBench = 'StarterBench0';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashteamshotlocationsGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames,
        $distanceRange,
        $gameScope,
        $playerExperience,
        $playerPosition,
        $starterBench
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leaguedashteamstats GET

```php
function leaguedashteamstatsGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->leaguedashteamstatsGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Leagueleaders GET

```php
function leagueleadersGET(
    string $leagueID,
    string $perMode,
    string $season,
    string $seasonType,
    string $scope,
    ?string $statCategory = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `scope` | `string` | Query, Required | - |
| `statCategory` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$scope = 'Scope0';

$aPIController = $client->getAPIController();

try {
    $aPIController->leagueleadersGET(
        $leagueID,
        $perMode,
        $season,
        $seasonType,
        $scope
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playbyplay GET

```php
function playbyplayGET(string $gameID, string $startPeriod, string $endPeriod): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |
| `startPeriod` | `string` | Query, Required | - |
| `endPeriod` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$startPeriod = 'StartPeriod4';

$endPeriod = 'EndPeriod0';

$aPIController = $client->getAPIController();

try {
    $aPIController->playbyplayGET(
        $gameID,
        $startPeriod,
        $endPeriod
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playbyplayv 2 GET

```php
function playbyplayv2GET(string $gameID, string $startPeriod, string $endPeriod): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameID` | `string` | Query, Required | - |
| `startPeriod` | `string` | Query, Required | - |
| `endPeriod` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameID = 'GameID8';

$startPeriod = 'StartPeriod4';

$endPeriod = 'EndPeriod0';

$aPIController = $client->getAPIController();

try {
    $aPIController->playbyplayv2GET(
        $gameID,
        $startPeriod,
        $endPeriod
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playercareerstats GET

```php
function playercareerstatsGET(string $perMode, string $playerID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$playerID = 'PlayerID6';

$aPIController = $client->getAPIController();

try {
    $aPIController->playercareerstatsGET(
        $perMode,
        $playerID
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playercompare GET

```php
function playercompareGET(
    string $playerIDList,
    string $vsPlayerIDList,
    string $seasonType,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `playerIDList` | `string` | Query, Required | - |
| `vsPlayerIDList` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$playerIDList = 'PlayerIDList4';

$vsPlayerIDList = 'VsPlayerIDList2';

$seasonType = 'SeasonType8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playercompareGET(
        $playerIDList,
        $vsPlayerIDList,
        $seasonType,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashboardbyclutch GET

```php
function playerdashboardbyclutchGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $playerID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashboardbyclutchGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $playerID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashboardbygamesplits GET

```php
function playerdashboardbygamesplitsGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $playerID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashboardbygamesplitsGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $playerID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashboardbygeneralsplits GET

```php
function playerdashboardbygeneralsplitsGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $playerID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashboardbygeneralsplitsGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $playerID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashboardbylastngames GET

```php
function playerdashboardbylastngamesGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $playerID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashboardbylastngamesGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $playerID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashboardbyopponent GET

```php
function playerdashboardbyopponentGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $playerID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashboardbyopponentGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $playerID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashboardbyshootingsplits GET

```php
function playerdashboardbyshootingsplitsGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $playerID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashboardbyshootingsplitsGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $playerID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashboardbyteamperformance GET

```php
function playerdashboardbyteamperformanceGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $playerID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashboardbyteamperformanceGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $playerID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashboardbyyearoveryear GET

```php
function playerdashboardbyyearoveryearGET(
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $playerID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashboardbyyearoveryearGET(
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $playerID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashptpass GET

```php
function playerdashptpassGET(
    string $perMode,
    string $season,
    string $seasonType,
    string $playerID,
    string $teamID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$teamID = 'TeamID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashptpassGET(
        $perMode,
        $season,
        $seasonType,
        $playerID,
        $teamID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashptreb GET

```php
function playerdashptrebGET(
    string $perMode,
    string $season,
    string $seasonType,
    string $playerID,
    string $teamID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$teamID = 'TeamID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashptrebGET(
        $perMode,
        $season,
        $seasonType,
        $playerID,
        $teamID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashptreboundlogs GET

```php
function playerdashptreboundlogsGET(
    ?string $season = null,
    ?string $seasonType = null,
    ?string $playerID = null,
    ?string $teamID = null,
    ?string $outcome = null,
    ?string $location = null,
    ?string $month = null,
    ?string $seasonSegment = null,
    ?string $dateFrom = null,
    ?string $dateTo = null,
    ?string $opponentTeamID = null,
    ?string $vsConference = null,
    ?string $vsDivision = null,
    ?string $gameSegment = null,
    ?string $period = null,
    ?string $lastNGames = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `?string` | Query, Optional | - |
| `seasonType` | `?string` | Query, Optional | - |
| `playerID` | `?string` | Query, Optional | - |
| `teamID` | `?string` | Query, Optional | - |
| `outcome` | `?string` | Query, Optional | - |
| `location` | `?string` | Query, Optional | - |
| `month` | `?string` | Query, Optional | - |
| `seasonSegment` | `?string` | Query, Optional | - |
| `dateFrom` | `?string` | Query, Optional | - |
| `dateTo` | `?string` | Query, Optional | - |
| `opponentTeamID` | `?string` | Query, Optional | - |
| `vsConference` | `?string` | Query, Optional | - |
| `vsDivision` | `?string` | Query, Optional | - |
| `gameSegment` | `?string` | Query, Optional | - |
| `period` | `?string` | Query, Optional | - |
| `lastNGames` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashptreboundlogsGET();
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashptshotdefend GET

```php
function playerdashptshotdefendGET(
    string $perMode,
    string $season,
    string $seasonType,
    string $playerID,
    string $teamID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$teamID = 'TeamID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashptshotdefendGET(
        $perMode,
        $season,
        $seasonType,
        $playerID,
        $teamID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashptshotlog GET

```php
function playerdashptshotlogGET(
    ?string $leagueID = null,
    ?string $season = null,
    ?string $seasonType = null,
    ?string $playerID = null,
    ?string $teamID = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `?string` | Query, Optional | - |
| `season` | `?string` | Query, Optional | - |
| `seasonType` | `?string` | Query, Optional | - |
| `playerID` | `?string` | Query, Optional | - |
| `teamID` | `?string` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashptshotlogGET();
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerdashptshots GET

```php
function playerdashptshotsGET(
    string $perMode,
    string $season,
    string $seasonType,
    string $playerID,
    string $teamID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$playerID = 'PlayerID6';

$teamID = 'TeamID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerdashptshotsGET(
        $perMode,
        $season,
        $seasonType,
        $playerID,
        $teamID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playergamelog GET

```php
function playergamelogGET(string $playerID, string $season, string $seasonType): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `playerID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$playerID = 'PlayerID6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$aPIController = $client->getAPIController();

try {
    $aPIController->playergamelogGET(
        $playerID,
        $season,
        $seasonType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerprofile GET

```php
function playerprofileGET(
    string $leagueID,
    string $playerID,
    string $season,
    string $seasonType,
    string $graphStartSeason,
    string $graphEndSeason,
    string $graphStat
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `graphStartSeason` | `string` | Query, Required | - |
| `graphEndSeason` | `string` | Query, Required | - |
| `graphStat` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$playerID = 'PlayerID6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$graphStartSeason = 'GraphStartSeason2';

$graphEndSeason = 'GraphEndSeason6';

$graphStat = 'GraphStat0';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerprofileGET(
        $leagueID,
        $playerID,
        $season,
        $seasonType,
        $graphStartSeason,
        $graphEndSeason,
        $graphStat
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playerprofilev 2 GET

```php
function playerprofilev2GET(string $perMode, string $playerID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$playerID = 'PlayerID6';

$aPIController = $client->getAPIController();

try {
    $aPIController->playerprofilev2GET(
        $perMode,
        $playerID
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playersvsplayers GET

```php
function playersvsplayersGET(
    string $playerTeamID,
    string $playerID1,
    string $playerID2,
    string $playerID3,
    string $playerID4,
    string $playerID5,
    string $vsTeamID,
    string $vsPlayerID1,
    string $vsPlayerID2,
    string $vsPlayerID3,
    string $vsPlayerID4,
    string $vsPlayerID5,
    string $seasonType,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `playerTeamID` | `string` | Query, Required | - |
| `playerID1` | `string` | Query, Required | - |
| `playerID2` | `string` | Query, Required | - |
| `playerID3` | `string` | Query, Required | - |
| `playerID4` | `string` | Query, Required | - |
| `playerID5` | `string` | Query, Required | - |
| `vsTeamID` | `string` | Query, Required | - |
| `vsPlayerID1` | `string` | Query, Required | - |
| `vsPlayerID2` | `string` | Query, Required | - |
| `vsPlayerID3` | `string` | Query, Required | - |
| `vsPlayerID4` | `string` | Query, Required | - |
| `vsPlayerID5` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$playerTeamID = 'PlayerTeamID4';

$playerID1 = 'PlayerID18';

$playerID2 = 'PlayerID24';

$playerID3 = 'PlayerID32';

$playerID4 = 'PlayerID44';

$playerID5 = 'PlayerID54';

$vsTeamID = 'VsTeamID8';

$vsPlayerID1 = 'VsPlayerID12';

$vsPlayerID2 = 'VsPlayerID28';

$vsPlayerID3 = 'VsPlayerID38';

$vsPlayerID4 = 'VsPlayerID46';

$vsPlayerID5 = 'VsPlayerID56';

$seasonType = 'SeasonType8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playersvsplayersGET(
        $playerTeamID,
        $playerID1,
        $playerID2,
        $playerID3,
        $playerID4,
        $playerID5,
        $vsTeamID,
        $vsPlayerID1,
        $vsPlayerID2,
        $vsPlayerID3,
        $vsPlayerID4,
        $vsPlayerID5,
        $seasonType,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playervsplayer GET

```php
function playervsplayerGET(
    string $playerID,
    string $vsPlayerID,
    string $seasonType,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `playerID` | `string` | Query, Required | - |
| `vsPlayerID` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$playerID = 'PlayerID6';

$vsPlayerID = 'VsPlayerID8';

$seasonType = 'SeasonType8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->playervsplayerGET(
        $playerID,
        $vsPlayerID,
        $seasonType,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Playoffpicture GET

```php
function playoffpictureGET(string $leagueID, string $seasonID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `seasonID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$seasonID = 'SeasonID6';

$aPIController = $client->getAPIController();

try {
    $aPIController->playoffpictureGET(
        $leagueID,
        $seasonID
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Scoreboard GET

```php
function scoreboardGET(string $gameDate, string $leagueID, string $dayOffset): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameDate` | `string` | Query, Required | - |
| `leagueID` | `string` | Query, Required | - |
| `dayOffset` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameDate = 'GameDate8';

$leagueID = 'LeagueID4';

$dayOffset = 'DayOffset6';

$aPIController = $client->getAPIController();

try {
    $aPIController->scoreboardGET(
        $gameDate,
        $leagueID,
        $dayOffset
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Scoreboard V2 GET

```php
function scoreboardV2GET(string $gameDate, string $leagueID, string $dayOffset): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gameDate` | `string` | Query, Required | - |
| `leagueID` | `string` | Query, Required | - |
| `dayOffset` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$gameDate = 'GameDate8';

$leagueID = 'LeagueID4';

$dayOffset = 'DayOffset6';

$aPIController = $client->getAPIController();

try {
    $aPIController->scoreboardV2GET(
        $gameDate,
        $leagueID,
        $dayOffset
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Shotchartdetail GET

```php
function shotchartdetailGET(
    string $seasonType,
    string $teamID,
    string $playerID,
    string $gameID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $position,
    string $rookieYear,
    string $gameSegment,
    string $period,
    string $lastNGames,
    string $contextMeasure
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `seasonType` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `playerID` | `string` | Query, Required | - |
| `gameID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `position` | `string` | Query, Required | - |
| `rookieYear` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |
| `contextMeasure` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$seasonType = 'SeasonType8';

$teamID = 'TeamID8';

$playerID = 'PlayerID6';

$gameID = 'GameID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$position = 'Position8';

$rookieYear = 'RookieYear8';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$contextMeasure = 'ContextMeasure2';

$aPIController = $client->getAPIController();

try {
    $aPIController->shotchartdetailGET(
        $seasonType,
        $teamID,
        $playerID,
        $gameID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $position,
        $rookieYear,
        $gameSegment,
        $period,
        $lastNGames,
        $contextMeasure
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Shotchartlineupdetail GET

```php
function shotchartlineupdetailGET(
    string $leagueID,
    string $season,
    string $seasonType,
    string $teamID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames,
    string $gameID,
    string $gROUPID,
    string $contextMeasure,
    string $contextFilter
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |
| `gameID` | `string` | Query, Required | - |
| `gROUPID` | `string` | Query, Required | - |
| `contextMeasure` | `string` | Query, Required | - |
| `contextFilter` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$season = 'Season0';

$seasonType = 'SeasonType8';

$teamID = 'TeamID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$gameID = 'GameID8';

$gROUPID = 'GROUP_ID6';

$contextMeasure = 'ContextMeasure2';

$contextFilter = 'ContextFilter6';

$aPIController = $client->getAPIController();

try {
    $aPIController->shotchartlineupdetailGET(
        $leagueID,
        $season,
        $seasonType,
        $teamID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames,
        $gameID,
        $gROUPID,
        $contextMeasure,
        $contextFilter
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashboardbyclutch GET

```php
function teamdashboardbyclutchGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashboardbyclutchGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashboardbygamesplits GET

```php
function teamdashboardbygamesplitsGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashboardbygamesplitsGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashboardbygeneralsplits GET

```php
function teamdashboardbygeneralsplitsGET(
    string $seasonType,
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `seasonType` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$seasonType = 'SeasonType8';

$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashboardbygeneralsplitsGET(
        $seasonType,
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashboardbylastngames GET

```php
function teamdashboardbylastngamesGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashboardbylastngamesGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashboardbyopponent GET

```php
function teamdashboardbyopponentGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashboardbyopponentGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashboardbyshootingsplits GET

```php
function teamdashboardbyshootingsplitsGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashboardbyshootingsplitsGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashboardbyteamperformance GET

```php
function teamdashboardbyteamperformanceGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashboardbyteamperformanceGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashboardbyyearoveryear GET

```php
function teamdashboardbyyearoveryearGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashboardbyyearoveryearGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashlineups GET

```php
function teamdashlineupsGET(
    string $groupQuantity,
    string $gameID,
    string $seasonType,
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `groupQuantity` | `string` | Query, Required | - |
| `gameID` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$groupQuantity = 'GroupQuantity0';

$gameID = 'GameID8';

$seasonType = 'SeasonType8';

$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashlineupsGET(
        $groupQuantity,
        $gameID,
        $seasonType,
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashptpass GET

```php
function teamdashptpassGET(
    string $perMode,
    string $season,
    string $seasonType,
    string $teamID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$teamID = 'TeamID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashptpassGET(
        $perMode,
        $season,
        $seasonType,
        $teamID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashptreb GET

```php
function teamdashptrebGET(
    string $perMode,
    string $season,
    string $seasonType,
    string $teamID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$teamID = 'TeamID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashptrebGET(
        $perMode,
        $season,
        $seasonType,
        $teamID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamdashptshots GET

```php
function teamdashptshotsGET(
    string $perMode,
    string $season,
    string $seasonType,
    string $teamID,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perMode` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$perMode = 'PerMode6';

$season = 'Season0';

$seasonType = 'SeasonType8';

$teamID = 'TeamID8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamdashptshotsGET(
        $perMode,
        $season,
        $seasonType,
        $teamID,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamgamelog GET

```php
function teamgamelogGET(string $teamID, string $season, string $seasonType): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$season = 'Season0';

$seasonType = 'SeasonType8';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamgamelogGET(
        $teamID,
        $season,
        $seasonType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teaminfocommon GET

```php
function teaminfocommonGET(string $season, string $teamID, string $leagueID, string $seasonType): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `leagueID` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$season = 'Season0';

$teamID = 'TeamID8';

$leagueID = 'LeagueID4';

$seasonType = 'SeasonType8';

$aPIController = $client->getAPIController();

try {
    $aPIController->teaminfocommonGET(
        $season,
        $teamID,
        $leagueID,
        $seasonType
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamplayerdashboard GET

```php
function teamplayerdashboardGET(
    string $seasonType,
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `seasonType` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$seasonType = 'SeasonType8';

$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamplayerdashboardGET(
        $seasonType,
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamplayeronoffdetails GET

```php
function teamplayeronoffdetailsGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamplayeronoffdetailsGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamplayeronoffsummary GET

```php
function teamplayeronoffsummaryGET(
    string $teamID,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $seasonType,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$seasonType = 'SeasonType8';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamplayeronoffsummaryGET(
        $teamID,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $seasonType,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamvsplayer GET

```php
function teamvsplayerGET(
    string $teamID,
    string $vsPlayerID,
    string $seasonType,
    string $measureType,
    string $perMode,
    string $plusMinus,
    string $paceAdjust,
    string $rank,
    string $season,
    string $outcome,
    string $location,
    string $month,
    string $seasonSegment,
    string $dateFrom,
    string $dateTo,
    string $opponentTeamID,
    string $vsConference,
    string $vsDivision,
    string $gameSegment,
    string $period,
    string $lastNGames
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `teamID` | `string` | Query, Required | - |
| `vsPlayerID` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `measureType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `plusMinus` | `string` | Query, Required | - |
| `paceAdjust` | `string` | Query, Required | - |
| `rank` | `string` | Query, Required | - |
| `season` | `string` | Query, Required | - |
| `outcome` | `string` | Query, Required | - |
| `location` | `string` | Query, Required | - |
| `month` | `string` | Query, Required | - |
| `seasonSegment` | `string` | Query, Required | - |
| `dateFrom` | `string` | Query, Required | - |
| `dateTo` | `string` | Query, Required | - |
| `opponentTeamID` | `string` | Query, Required | - |
| `vsConference` | `string` | Query, Required | - |
| `vsDivision` | `string` | Query, Required | - |
| `gameSegment` | `string` | Query, Required | - |
| `period` | `string` | Query, Required | - |
| `lastNGames` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$teamID = 'TeamID8';

$vsPlayerID = 'VsPlayerID8';

$seasonType = 'SeasonType8';

$measureType = 'MeasureType8';

$perMode = 'PerMode6';

$plusMinus = 'PlusMinus0';

$paceAdjust = 'PaceAdjust2';

$rank = 'Rank2';

$season = 'Season0';

$outcome = 'Outcome4';

$location = 'Location4';

$month = 'Month0';

$seasonSegment = 'SeasonSegment8';

$dateFrom = 'DateFrom6';

$dateTo = 'DateTo0';

$opponentTeamID = 'OpponentTeamID6';

$vsConference = 'VsConference6';

$vsDivision = 'VsDivision6';

$gameSegment = 'GameSegment6';

$period = 'Period2';

$lastNGames = 'LastNGames4';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamvsplayerGET(
        $teamID,
        $vsPlayerID,
        $seasonType,
        $measureType,
        $perMode,
        $plusMinus,
        $paceAdjust,
        $rank,
        $season,
        $outcome,
        $location,
        $month,
        $seasonSegment,
        $dateFrom,
        $dateTo,
        $opponentTeamID,
        $vsConference,
        $vsDivision,
        $gameSegment,
        $period,
        $lastNGames
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Teamyearbyyearstats GET

```php
function teamyearbyyearstatsGET(string $leagueID, string $seasonType, string $perMode, string $teamID): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `seasonType` | `string` | Query, Required | - |
| `perMode` | `string` | Query, Required | - |
| `teamID` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$seasonType = 'SeasonType8';

$perMode = 'PerMode6';

$teamID = 'TeamID8';

$aPIController = $client->getAPIController();

try {
    $aPIController->teamyearbyyearstatsGET(
        $leagueID,
        $seasonType,
        $perMode,
        $teamID
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |


# Video Status GET

```php
function videoStatusGET(string $leagueID, string $gameDate): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `leagueID` | `string` | Query, Required | - |
| `gameDate` | `string` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```php
$leagueID = 'LeagueID4';

$gameDate = 'GameDate8';

$aPIController = $client->getAPIController();

try {
    $aPIController->videoStatusGET(
        $leagueID,
        $gameDate
    );
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `ApiException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `ApiException` |

