
# Type 63 Enum

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63Enum`

## Fields

| Name |
|  --- |
| `Snapshot` |
| `Backup` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type63Enum type63 = Type63Enum.Snapshot;
```

