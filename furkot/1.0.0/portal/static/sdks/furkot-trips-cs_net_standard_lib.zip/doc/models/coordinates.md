
# Coordinates

geographical coordinates of the stop

## Structure

`Coordinates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Lat` | `double?` | Optional | latitude |
| `Lon` | `double?` | Optional | longitude |

## Example

```csharp
using FurkotTrips.Standard.Models;

Coordinates coordinates = new Coordinates
{
    Lat = 182.98,
    Lon = 16.08,
};
```

