
# Data Catalog Type 1 Enum

The type of data catalog to create: <code>LAMBDA</code> for a federated catalog, <code>HIVE</code> for an external hive metastore, or <code>GLUE</code> for an Glue Data Catalog.

## Enumeration

`DataCatalogType1Enum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```csharp
using AmazonAthena.Standard.Models;

DataCatalogType1Enum dataCatalogType1 = DataCatalogType1Enum.GLUE;
```

