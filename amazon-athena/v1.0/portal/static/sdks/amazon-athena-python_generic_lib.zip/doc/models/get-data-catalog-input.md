
# Get Data Catalog Input

## Structure

`GetDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```python
from amazonathena.models.get_data_catalog_input import GetDataCatalogInput

get_data_catalog_input = GetDataCatalogInput(
    name='Name2'
)
```

