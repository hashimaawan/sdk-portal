
# Get Session Response

## Structure

`GetSessionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SessionId` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getSessionId() | setSessionId(String sessionId) |
| `Description` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getDescription() | setDescription(String description) |
| `WorkGroup` | `String` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | String getWorkGroup() | setWorkGroup(String workGroup) |
| `EngineVersion` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | String getEngineVersion() | setEngineVersion(String engineVersion) |
| `EngineConfiguration` | [`EngineConfiguration1`](../../doc/models/engine-configuration-1.md) | Optional | - | EngineConfiguration1 getEngineConfiguration() | setEngineConfiguration(EngineConfiguration1 engineConfiguration) |
| `NotebookVersion` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | String getNotebookVersion() | setNotebookVersion(String notebookVersion) |
| `SessionConfiguration` | [`SessionConfiguration2`](../../doc/models/session-configuration-2.md) | Optional | - | SessionConfiguration2 getSessionConfiguration() | setSessionConfiguration(SessionConfiguration2 sessionConfiguration) |
| `Status` | [`Status3`](../../doc/models/status-3.md) | Optional | - | Status3 getStatus() | setStatus(Status3 status) |
| `Statistics` | [`Statistics3`](../../doc/models/statistics-3.md) | Optional | - | Statistics3 getStatistics() | setStatistics(Statistics3 statistics) |

## Example

```java
import com.amazonaws.useast1.athena.models.AdditionalConfigs;
import com.amazonaws.useast1.athena.models.EngineConfiguration1;
import com.amazonaws.useast1.athena.models.GetSessionResponse;

GetSessionResponse getSessionResponse = new GetSessionResponse.Builder()
    .sessionId("SessionId6")
    .description("Description4")
    .workGroup("WorkGroup4")
    .engineVersion("EngineVersion8")
    .engineConfiguration(new EngineConfiguration1.Builder(
        94
    )
    .coordinatorDpuSize(1)
    .defaultExecutorDpuSize(1)
    .additionalConfigs(new AdditionalConfigs.Builder()
            .build())
    .build())
    .build();
```

