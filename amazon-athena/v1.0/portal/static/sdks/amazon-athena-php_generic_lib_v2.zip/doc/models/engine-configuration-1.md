
# Engine Configuration 1

## Structure

`EngineConfiguration1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `coordinatorDpuSize` | `?int` | Optional | **Constraints**: `>= 1`, `<= 1` | getCoordinatorDpuSize(): ?int | setCoordinatorDpuSize(?int coordinatorDpuSize): void |
| `maxConcurrentDpus` | `int` | Required | **Constraints**: `>= 2`, `<= 5000` | getMaxConcurrentDpus(): int | setMaxConcurrentDpus(int maxConcurrentDpus): void |
| `defaultExecutorDpuSize` | `?int` | Optional | **Constraints**: `>= 1`, `<= 1` | getDefaultExecutorDpuSize(): ?int | setDefaultExecutorDpuSize(?int defaultExecutorDpuSize): void |
| `additionalConfigs` | [`?AdditionalConfigs`](../../doc/models/additional-configs.md) | Optional | - | getAdditionalConfigs(): ?AdditionalConfigs | setAdditionalConfigs(?AdditionalConfigs additionalConfigs): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\EngineConfiguration1Builder;
use AmazonAthenaLib\Models\Builders\AdditionalConfigsBuilder;

$engineConfiguration1 = EngineConfiguration1Builder::init(
    214
)
    ->coordinatorDpuSize(1)
    ->defaultExecutorDpuSize(1)
    ->additionalConfigs(
        AdditionalConfigsBuilder::init()->build()
    )->build();
```

