
# X Amz Target 5

## Enumeration

`XAmzTarget5`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateNotebook` |

## Example

```ts
import { XAmzTarget5 } from 'amazon-athenalib';

const xAmzTarget5 = XAmzTarget5.EnumAmazonAthenaCreateNotebook;
```

