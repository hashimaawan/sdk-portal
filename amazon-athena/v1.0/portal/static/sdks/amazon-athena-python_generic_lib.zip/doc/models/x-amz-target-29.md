
# X Amz Target 29

## Enumeration

`XAmzTarget29`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETWORKGROUP` |

## Example

```python
from amazonathena.models.x_amz_target_29 import XAmzTarget29

x_amz_target_29 = XAmzTarget29.ENUM_AMAZONATHENAGETWORKGROUP
```

