
# Type 65

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65`

## Fields

| Name |
|  --- |
| `LINUX64` |
| `LINUX32` |

## Example

```java
import cloud.hetzner.api.models.Type65;

Type65 type65 = Type65.LINUX64;
```

