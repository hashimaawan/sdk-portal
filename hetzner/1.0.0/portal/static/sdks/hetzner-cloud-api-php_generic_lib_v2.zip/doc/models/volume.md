
# Volume

The cost of Volume per GB/month

## Structure

`Volume`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pricePerGbMonth` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - | getPricePerGbMonth(): PricePerGbMonth | setPricePerGbMonth(PricePerGbMonth pricePerGbMonth): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\VolumeBuilder;
use HetznerCloudAPILib\Models\Builders\PricePerGbMonthBuilder;

$volume = VolumeBuilder::init(
    PricePerGbMonthBuilder::init(
        '1.1900000000000000',
        '1.0000000000'
    )->build()
)->build();
```

