
# Type 28

Type of the algorithm

## Enumeration

`Type28`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```ts
import { Type28 } from 'hetzner-cloud-apilib';

const type28 = Type28.RoundRobin;
```

