
# Data Catalog Type

## Enumeration

`DataCatalogType`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```java
import com.amazonaws.useast1.athena.models.DataCatalogType;

DataCatalogType dataCatalogType = DataCatalogType.HIVE;
```

