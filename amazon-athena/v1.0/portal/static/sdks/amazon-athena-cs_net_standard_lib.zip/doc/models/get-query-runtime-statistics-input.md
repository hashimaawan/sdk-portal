
# Get Query Runtime Statistics Input

## Structure

`GetQueryRuntimeStatisticsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```csharp
using AmazonAthena.Standard.Models;

GetQueryRuntimeStatisticsInput getQueryRuntimeStatisticsInput = new GetQueryRuntimeStatisticsInput
{
    QueryExecutionId = "QueryExecutionId0",
};
```

