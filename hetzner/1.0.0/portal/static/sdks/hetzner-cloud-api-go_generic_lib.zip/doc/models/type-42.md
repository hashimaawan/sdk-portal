
# Type 42

Type of Subnetwork

## Enumeration

`Type42`

## Fields

| Name |
|  --- |
| `Cloud` |
| `Server` |
| `Vswitch` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type42 := models.Type42_Cloud

}
```

