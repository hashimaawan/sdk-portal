
# X Amz Target 22

## Enumeration

`XAmzTarget22`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget22;

XAmzTarget22 xAmzTarget22 = XAmzTarget22.ENUM_AMAZONATHENAGETPREPAREDSTATEMENT;
```

