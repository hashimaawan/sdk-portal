
# Start Session Response

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sessionId` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getSessionId(): ?string | setSessionId(?string sessionId): void |
| `state` | [`?string(SessionState1Enum)`](../../doc/models/session-state-1-enum.md) | Optional | - | getState(): ?string | setState(?string state): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\StartSessionResponseBuilder;
use AmazonAthenaLib\Models\SessionState1Enum;

$startSessionResponse = StartSessionResponseBuilder::init()
    ->sessionId('SessionId4')
    ->state(SessionState1Enum::CREATING)
    ->build();
```

