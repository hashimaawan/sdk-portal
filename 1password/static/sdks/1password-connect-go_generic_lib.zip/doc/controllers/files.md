# Files

```go
filesApi := client.FilesApi()
```

## Class Name

`FilesApi`

## Methods

* [Get Item Files](../../doc/controllers/files.md#get-item-files)
* [Get Details of File by Id](../../doc/controllers/files.md#get-details-of-file-by-id)
* [Download File by ID](../../doc/controllers/files.md#download-file-by-id)


# Get Item Files

```go
GetItemFiles(
    ctx context.Context,
    vaultUuid uuid.UUID,
    itemUuid uuid.UUID,
    inlineFiles *bool) (
    models.ApiResponse[[]models.File],
    error)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `uuid.UUID` | Template, Required | The UUID of the Vault to fetch Items from |
| `itemUuid` | `uuid.UUID` | Template, Required | The UUID of the Item to fetch files from |
| `inlineFiles` | `*bool` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.File](../../doc/models/file.md).

## Example Usage

```go
ctx := context.Background()

vaultUuid := uuid.MustParse("00002186-0000-0000-0000-000000000000")

itemUuid := uuid.MustParse("0000141a-0000-0000-0000-000000000000")

inlineFiles := true

apiResponse, err := filesApi.GetItemFiles(ctx, vaultUuid, itemUuid, &inlineFiles)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorResponse:
            log.Fatalln("ErrorResponseException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Item not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Details of File by Id

```go
GetDetailsOfFileById(
    ctx context.Context,
    vaultUuid uuid.UUID,
    itemUuid uuid.UUID,
    fileUuid uuid.UUID,
    inlineFiles *bool) (
    models.ApiResponse[models.File],
    error)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `uuid.UUID` | Template, Required | The UUID of the Vault to fetch Item from |
| `itemUuid` | `uuid.UUID` | Template, Required | The UUID of the Item to fetch File from |
| `fileUuid` | `uuid.UUID` | Template, Required | The UUID of the File to fetch |
| `inlineFiles` | `*bool` | Query, Optional | Tells server to return the base64-encoded file contents in the response. |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.File](../../doc/models/file.md).

## Example Usage

```go
ctx := context.Background()

vaultUuid := uuid.MustParse("00002186-0000-0000-0000-000000000000")

itemUuid := uuid.MustParse("0000141a-0000-0000-0000-000000000000")

fileUuid := uuid.MustParse("000008e0-0000-0000-0000-000000000000")

inlineFiles := true

apiResponse, err := filesApi.GetDetailsOfFileById(ctx, vaultUuid, itemUuid, fileUuid, &inlineFiles)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorResponse:
            log.Fatalln("ErrorResponseException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 413 | File content too large to display | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Download File by ID

```go
DownloadFileById(
    ctx context.Context,
    vaultUuid uuid.UUID,
    itemUuid uuid.UUID,
    fileUuid string) (
    models.ApiResponse[[]byte],
    error)
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `uuid.UUID` | Template, Required | The UUID of the Vault the item is in |
| `itemUuid` | `uuid.UUID` | Template, Required | The UUID of the Item the File is in |
| `fileUuid` | `string` | Template, Required | UUID of the file to get content from |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type []byte.

## Example Usage

```go
ctx := context.Background()

vaultUuid := uuid.MustParse("00002186-0000-0000-0000-000000000000")

itemUuid := uuid.MustParse("0000141a-0000-0000-0000-000000000000")

fileUuid := "fileUuid2"

apiResponse, err := filesApi.DownloadFileById(ctx, vaultUuid, itemUuid, fileUuid)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorResponse:
            log.Fatalln("ErrorResponseException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | File not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

