
# Applied to Resource

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `type` | [`Type5Enum`](../../doc/models/type-5-enum.md) | Optional | Type of resource referenced |

## Example

```ruby
applied_to_resource = AppliedToResource.new(
  Server.new(
    14
  ),
  Type5Enum::SERVER
)
```

