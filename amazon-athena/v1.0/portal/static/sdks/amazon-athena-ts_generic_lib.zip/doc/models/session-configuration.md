
# Session Configuration

Contains session configuration information.

## Structure

`SessionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `executionRole` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `20`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:iam::\d{12}:role/?[a-zA-Z_0-9+=,.@\-_/]+$` |
| `workingDirectory` | `string \| undefined` | Optional | - |
| `idleTimeoutSeconds` | `number \| undefined` | Optional | - |
| `encryptionConfiguration` | [`EncryptionConfiguration \| undefined`](../../doc/models/encryption-configuration.md) | Optional | If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information. |

## Example

```ts
import {
  EncryptionOption1Enum,
  SessionConfiguration,
} from 'amazon-athenalib';

const sessionConfiguration: SessionConfiguration = {
  executionRole: 'ExecutionRole2',
  workingDirectory: 'WorkingDirectory6',
  idleTimeoutSeconds: 188,
  encryptionConfiguration: {
    encryptionOption: EncryptionOption1Enum.SSES3,
    kmsKey: 'KmsKey6',
  },
};
```

