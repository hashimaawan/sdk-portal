
# Load Balancers Actions Attach to Network Request

*This model accepts additional fields of type Any.*

## Structure

`LoadBalancersActionsAttachToNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip` | `str` | Optional | IP to request to be assigned to this Load Balancer; if you do not provide this then you will be auto assigned an IP address |
| `network` | `float` | Required | ID of an existing network to attach the Load Balancer to |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.load_balancers_actions_attach_to_network_request import LoadBalancersActionsAttachToNetworkRequest

load_balancers_actions_attach_to_network_request = LoadBalancersActionsAttachToNetworkRequest(
    network=4711,
    ip='10.0.1.1',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

