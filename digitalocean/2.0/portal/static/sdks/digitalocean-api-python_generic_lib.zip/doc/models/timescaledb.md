
# Timescaledb

TimescaleDB extension configuration values

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Timescaledb`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `max_background_workers` | `int` | Optional | The number of background workers for timescaledb operations.  Set to the sum of your number of databases and the total number of concurrent background workers you want running at any given point in time.<br><br>**Constraints**: `>= 1`, `<= 4096` |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.timescaledb import Timescaledb

timescaledb = Timescaledb(
    max_background_workers=8,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

