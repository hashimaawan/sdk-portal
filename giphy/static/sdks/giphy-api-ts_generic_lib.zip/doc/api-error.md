
# ApiError

Thrown when the HTTP status code is not okay.

The ApiError extends the ApiResponse interface, so all ApiResponse properties are available.

## Properties

| Name | Type | Description |
|  --- | --- | --- |
| request | [`HttpRequest`](../doc/http-request.md) | Original request that resulted in this response. |
| statusCode | `number` | Response status code. |
| headers | `Record<string, string>` | Response headers. |
| result | `T` | Response data. |
| body | `string \| Blob \| NodeJS.ReadableStream` | Original body from the response. |

