
# Session Configuration

Contains session configuration information.

## Structure

`SessionConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `execution_role` | `String` | Optional | **Constraints**: *Minimum Length*: `20`, *Maximum Length*: `2048`, *Pattern*: `^arn:aws[a-z\-]*:iam::\d{12}:role/?[a-zA-Z_0-9+=,.@\-_/]+$` |
| `working_directory` | `String` | Optional | - |
| `idle_timeout_seconds` | `Integer` | Optional | - |
| `encryption_configuration` | [`EncryptionConfiguration`](../../doc/models/encryption-configuration.md) | Optional | If query and calculation results are encrypted in Amazon S3, indicates the encryption option used (for example, <code>SSE_KMS</code> or <code>CSE_KMS</code>) and key information. |

## Example

```ruby
session_configuration = SessionConfiguration.new(
  'ExecutionRole8',
  'WorkingDirectory2',
  176,
  EncryptionConfiguration.new(
    EncryptionOption1Enum::SSE_S3,
    'KmsKey6'
  )
)
```

