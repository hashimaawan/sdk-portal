
# Parameter Type 1 Enum

## Enumeration

`ParameterType1Enum`

## Fields

| Name |
|  --- |
| `Spread` |

## Example

```ts
import { ParameterType1Enum } from 'hetzner-cloud-apilib';

const parameterType1 = ParameterType1Enum.Spread;
```

