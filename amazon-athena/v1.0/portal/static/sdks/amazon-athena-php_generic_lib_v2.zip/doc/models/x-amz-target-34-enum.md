
# X Amz Target 34 Enum

## Enumeration

`XAmzTarget34Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTDATABASES` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget34Enum;

$xAmzTarget34 = XAmzTarget34Enum::ENUM_AMAZONATHENALISTDATABASES;
```

