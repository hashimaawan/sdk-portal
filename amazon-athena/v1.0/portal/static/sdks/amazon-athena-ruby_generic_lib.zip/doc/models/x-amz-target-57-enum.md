
# X Amz Target 57 Enum

## Enumeration

`XAmzTarget57Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```ruby
x_amz_target57 = XAmzTarget57Enum::ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA
```

