
# Parameters

*This model accepts additional fields of type string.*

## Structure

`Parameters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AdditionalProperties` | `string this[string key]` | Optional | **Constraints**: *Maximum Length*: `51200` |

## Example (as JSON)

```json
{
  "exampleAdditionalProperty": "Parameters_additionalProperties2"
}
```

