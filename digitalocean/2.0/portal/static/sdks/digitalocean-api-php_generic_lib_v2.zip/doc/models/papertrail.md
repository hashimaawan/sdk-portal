
# Papertrail

Papertrail configuration.

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Papertrail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `endpoint` | `string` | Required | Papertrail syslog endpoint. | getEndpoint(): string | setEndpoint(string endpoint): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\PapertrailBuilder;
use DigitalOceanApiLib\ApiHelper;

$papertrail = PapertrailBuilder::init(
    'https://mypapertrailendpoint.com'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

