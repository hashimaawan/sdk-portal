
# Protocol 6 Enum

Type of the health check

## Enumeration

`Protocol6Enum`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Protocol6Enum protocol6 = Protocol6Enum.Tcp;
```

