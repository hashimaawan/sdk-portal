
# Parameter Type

## Enumeration

`ParameterType`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```php
use HetznerCloudApiLib\Models\ParameterType;

$parameterType = ParameterType::UPLOADED;
```

