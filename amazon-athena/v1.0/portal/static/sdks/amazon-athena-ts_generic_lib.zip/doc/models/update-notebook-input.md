
# Update Notebook Input

## Structure

`UpdateNotebookInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `payload` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `10485760` |
| `type` | [`NotebookType2Enum`](../../doc/models/notebook-type-2-enum.md) | Required | - |
| `sessionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `clientRequestToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |

## Example

```ts
import { NotebookType2Enum, UpdateNotebookInput } from 'amazon-athenalib';

const updateNotebookInput: UpdateNotebookInput = {
  notebookId: 'NotebookId8',
  payload: 'Payload4',
  type: NotebookType2Enum.IPYNB,
  sessionId: 'SessionId0',
  clientRequestToken: 'ClientRequestToken2',
};
```

