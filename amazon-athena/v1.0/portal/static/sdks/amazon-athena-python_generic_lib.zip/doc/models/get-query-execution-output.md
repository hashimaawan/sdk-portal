
# Get Query Execution Output

## Structure

`GetQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution` | [`QueryExecution1`](../../doc/models/query-execution-1.md) | Optional | - |

## Example

```python
from amazonathena.models.acl_configuration_1 import AclConfiguration1
from amazonathena.models.encryption_configuration_2 import EncryptionConfiguration2
from amazonathena.models.encryption_option_1_enum import EncryptionOption1Enum
from amazonathena.models.get_query_execution_output import GetQueryExecutionOutput
from amazonathena.models.query_execution_1 import QueryExecution1
from amazonathena.models.result_configuration_1 import ResultConfiguration1
from amazonathena.models.result_reuse_by_age_configuration_2 import ResultReuseByAgeConfiguration2
from amazonathena.models.result_reuse_configuration_1 import ResultReuseConfiguration1
from amazonathena.models.s_3_acl_option_1_enum import S3AclOption1Enum
from amazonathena.models.statement_type_1_enum import StatementType1Enum

get_query_execution_output = GetQueryExecutionOutput(
    query_execution=QueryExecution1(
        query_execution_id='QueryExecutionId0',
        query='Query6',
        statement_type=StatementType1Enum.DDL,
        result_configuration=ResultConfiguration1(
            output_location='OutputLocation0',
            encryption_configuration=EncryptionConfiguration2(
                encryption_option=EncryptionOption1Enum.SSE_S3,
                kms_key='KmsKey6'
            ),
            expected_bucket_owner='ExpectedBucketOwner0',
            acl_configuration=AclConfiguration1(
                s_3_acl_option=S3AclOption1Enum.BUCKET_OWNER_FULL_CONTROL
            )
        ),
        result_reuse_configuration=ResultReuseConfiguration1(
            result_reuse_by_age_configuration=ResultReuseByAgeConfiguration2(
                enabled=False,
                max_age_in_minutes=26
            )
        )
    )
)
```

