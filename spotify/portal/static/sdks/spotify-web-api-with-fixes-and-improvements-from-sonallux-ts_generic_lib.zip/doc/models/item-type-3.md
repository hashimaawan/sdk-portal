
# Item Type 3

The ID type: either `artist` or `user`.

## Enumeration

`ItemType3`

## Fields

| Name |
|  --- |
| `Artist` |
| `User` |

## Example

```ts
import {
  ItemType3,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const itemType3 = ItemType3.Artist;
```

