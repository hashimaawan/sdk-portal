
# Remove from Resources Request

## Structure

`RemoveFromResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `remove_from` | [`Array[FirewallRemoveFromResources]`](../../doc/models/firewall-remove-from-resources.md) | Required | Resources the Firewall should be removed from |

## Example

```ruby
remove_from_resources_request = RemoveFromResourcesRequest.new(
  [
    FirewallRemoveFromResources.new(
      LabelSelector5.new(
        'selector8'
      ),
      Server9.new(
        14
      ),
      Type7Enum::SERVER
    )
  ]
)
```

