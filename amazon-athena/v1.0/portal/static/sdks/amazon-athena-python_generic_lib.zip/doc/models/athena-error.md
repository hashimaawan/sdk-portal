
# Athena Error

Provides information about an Athena query error. The <code>AthenaError</code> feature provides standardized error information to help you understand failed queries and take steps after a query failure occurs. <code>AthenaError</code> includes an <code>ErrorCategory</code> field that specifies whether the cause of the failed query is due to system error, user error, or other error.

*This model accepts additional fields of type Any.*

## Structure

`AthenaError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_category` | `int` | Optional | **Constraints**: `>= 1`, `<= 3` |
| `error_type` | `int` | Optional | **Constraints**: `>= 0`, `<= 9999` |
| `retryable` | `bool` | Optional | - |
| `error_message` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.athena_error import AthenaError

athena_error = AthenaError(
    error_category=3,
    error_type=96,
    retryable=False,
    error_message='ErrorMessage0',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

