# Vaults

Access 1Password Vaults

```php
$vaultsApi = $client->getVaultsApi();
```

## Class Name

`VaultsApi`

## Methods

* [Get Vaults](../../doc/controllers/vaults.md#get-vaults)
* [Get Vault by Id](../../doc/controllers/vaults.md#get-vault-by-id)


# Get Vaults

```php
function getVaults(?string $filter = null): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filter` | `?string` | Query, Optional | Filter the Vault collection based on Vault name using SCIM eq filter |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`Vault[]`](../../doc/models/vault.md).

## Example Usage

```php
$filter = 'name eq "Some Vault Name"';

$vaultsApi = $client->getVaultsApi();
$apiResponse = $vaultsApi->getVaults($filter);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'Vault[]:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Vault by Id

```php
function getVaultById(string $vaultUuid): ApiResponse
```

## Authentication

This endpoint requires [ConnectToken](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vaultUuid` | `string` | Template, Required | The UUID of the Vault to fetch Items from<br><br>**Constraints**: *Pattern*: `^[\da-z]{26}$` |

## Response Type

**200**: OK

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`Vault`](../../doc/models/vault.md).

## Example Usage

```php
$vaultUuid = 'vaultUuid2';

$vaultsApi = $client->getVaultsApi();
$apiResponse = $vaultsApi->getVaultById($vaultUuid);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'Vault:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid or missing token | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 403 | Unauthorized access | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 404 | Vault not found | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

