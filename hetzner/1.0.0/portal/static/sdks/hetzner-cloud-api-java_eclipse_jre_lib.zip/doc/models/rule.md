
# Rule

*This model accepts additional fields of type Object.*

## Structure

`Rule`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Description` | `String` | Optional | Description of the Rule<br><br>**Constraints**: *Maximum Length*: `255` | String getDescription() | setDescription(String description) |
| `DestinationIps` | `List<String>` | Optional | List of permitted IPv4/IPv6 addresses in CIDR notation. Use `0.0.0.0/0` to allow all IPv4 addresses and `::/0` to allow all IPv6 addresses. You can specify 100 CIDRs at most. | List<String> getDestinationIps() | setDestinationIps(List<String> destinationIps) |
| `Direction` | [`Direction`](../../doc/models/direction.md) | Required | Select traffic direction on which rule should be applied. Use `source_ips` for direction `in` and `destination_ips` for direction `out`. | Direction getDirection() | setDirection(Direction direction) |
| `Port` | `String` | Optional | Port or port range to which traffic will be allowed, only applicable for protocols TCP and UDP. A port range can be specified by separating two ports with a dash, e.g `1024-5000`. | String getPort() | setPort(String port) |
| `Protocol` | [`Protocol`](../../doc/models/protocol.md) | Required | Type of traffic to allow | Protocol getProtocol() | setProtocol(Protocol protocol) |
| `SourceIps` | `List<String>` | Optional | List of permitted IPv4/IPv6 addresses in CIDR notation. Use `0.0.0.0/0` to allow all IPv4 addresses and `::/0` to allow all IPv6 addresses. You can specify 100 CIDRs at most. | List<String> getSourceIps() | setSourceIps(List<String> sourceIps) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.Direction;
import cloud.hetzner.api.models.Protocol;
import cloud.hetzner.api.models.Rule;
import java.io.IOException;
import java.util.Arrays;

Rule rule = new Rule.Builder(
    Direction.IN,
    Protocol.ESP
)
.description("description0")
.destinationIps(Arrays.asList(
        "28.239.13.1/32",
        "28.239.14.0/24",
        "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128"
    ))
.port("80")
.sourceIps(Arrays.asList(
        "28.239.13.1/32",
        "28.239.14.0/24",
        "ff21:1eac:9a3b:ee58:5ca:990c:8bc9:c03b/128"
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

