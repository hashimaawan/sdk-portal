
# V2 Droplets Kernels Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DropletsKernelsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kernels` | [`(Kernel \| null)[] \| undefined`](../../doc/models/kernel.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2DropletsKernelsResponse } from 'digitalocean-apilib';

const v2DropletsKernelsResponse: V2DropletsKernelsResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  kernels: [
    {
      id: 16,
      name: 'name0',
      version: 'version6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

