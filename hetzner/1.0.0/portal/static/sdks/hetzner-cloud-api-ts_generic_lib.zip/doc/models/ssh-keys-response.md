
# Ssh Keys Response

*This model accepts additional fields of type unknown.*

## Structure

`SshKeysResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meta` | [`Meta \| undefined`](../../doc/models/meta.md) | Optional | - |
| `sshKeys` | [`SshKey[]`](../../doc/models/ssh-key.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SshKeysResponse } from 'hetzner-cloud-apilib';

const sshKeysResponse: SshKeysResponse = {
  sshKeys: [
    {
      created: '2016-01-30T23:55:00+00:00',
      fingerprint: 'b7:2f:30:a0:2f:6c:58:6c:21:04:58:61:ba:06:3b:2f',
      id: 42,
      labels: {
        'key0': 'labels4',
        'key1': 'labels5',
        'key2': 'labels6'
      },
      name: 'my-resource',
      publicKey: 'ssh-rsa AAAjjk76kgf...Xt',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  meta: {
    pagination: {
      lastPage: 77.7,
      nextPage: 209.18,
      page: 17.58,
      perPage: 13.34,
      previousPage: 50.02,
      totalEntries: 206.64,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

