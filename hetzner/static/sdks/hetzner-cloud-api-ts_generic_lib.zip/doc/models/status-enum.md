
# Status Enum

Status of the Action

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `Success` |
| `Running` |
| `Error` |

## Example

```ts
import { StatusEnum } from 'hetzner-cloud-apilib';

const status = StatusEnum.Error;
```

