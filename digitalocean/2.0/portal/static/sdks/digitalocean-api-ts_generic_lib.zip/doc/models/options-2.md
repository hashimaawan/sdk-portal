
# Options 2

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Options2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `availableRegions` | `string[] \| undefined` | Optional | - |
| `subscriptionTiers` | [`SubscriptionTier[] \| undefined`](../../doc/models/subscription-tier.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Options2 } from 'digitalocean-apilib';

const options2: Options2 = {
  availableRegions: [
    'nyc3'
  ],
  subscriptionTiers: [
    {
      allowStorageOverage: false,
      includedBandwidthBytes: BigInt(172),
      includedRepositories: 194,
      includedStorageBytes: BigInt(242),
      monthlyPriceInCents: 236,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      allowStorageOverage: false,
      includedBandwidthBytes: BigInt(172),
      includedRepositories: 194,
      includedStorageBytes: BigInt(242),
      monthlyPriceInCents: 236,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      allowStorageOverage: false,
      includedBandwidthBytes: BigInt(172),
      includedRepositories: 194,
      includedStorageBytes: BigInt(242),
      monthlyPriceInCents: 236,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

