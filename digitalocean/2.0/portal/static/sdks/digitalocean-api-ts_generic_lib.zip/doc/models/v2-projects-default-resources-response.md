
# V2 Projects Default Resources Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2ProjectsDefaultResourcesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resources` | [`Resources1[] \| undefined`](../../doc/models/resources-1.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  Status14,
  V2ProjectsDefaultResourcesResponse,
} from 'digitalocean-apilib';

const v2ProjectsDefaultResourcesResponse: V2ProjectsDefaultResourcesResponse = {
  meta: {
    total: 2,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  resources: [
    {
      assignedAt: '2018-09-28T19:26:37Z',
      links: {
        self: 'https://api.digitalocean.com/v2/droplets/13457723',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      status: Status14.Ok,
      urn: 'do:droplet:13457723',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      assignedAt: '2019-03-31T16:24:14Z',
      links: {
        self: 'https://api.digitalocean.com/v2/domains/example.com',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      status: Status14.Ok,
      urn: 'do:domain:example.com',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'https://api.digitalocean.com/v2/projects/4e1bfbc3-dc3e-41f2-a18f-1b4d7ba71679/resources?page=1',
      next: 'next2',
      additionalProperties: {
        'first': 'https: //api.digitalocean.com/v2/projects/4e1bfbc3-dc3e-41f2-a18f-1b4d7ba71679/resources?page=1'
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

