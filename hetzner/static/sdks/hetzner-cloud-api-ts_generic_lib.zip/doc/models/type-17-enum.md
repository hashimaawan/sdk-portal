
# Type 17 Enum

Floating IP type

## Enumeration

`Type17Enum`

## Fields

| Name |
|  --- |
| `Ipv4` |
| `Ipv6` |

## Example

```ts
import { Type17Enum } from 'hetzner-cloud-apilib';

const type17 = Type17Enum.Ipv4;
```

