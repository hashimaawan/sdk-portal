
# X Amz Target 25 Enum

## Enumeration

`XAmzTarget25Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget25 := models.XAmzTarget25Enum_ENUMAMAZONATHENAGETQUERYRUNTIMESTATISTICS

}
```

