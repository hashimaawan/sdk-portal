
# Query Runtime Statistics 2

## Structure

`QueryRuntimeStatistics2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `timeline` | [`QueryRuntimeStatisticsTimeline \| undefined`](../../doc/models/query-runtime-statistics-timeline.md) | Optional | Timeline statistics such as query queue time, planning time, execution time, service processing time, and total execution time. |
| `rows` | [`QueryRuntimeStatisticsRows \| undefined`](../../doc/models/query-runtime-statistics-rows.md) | Optional | Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query. |
| `outputStage` | [`OutputStage \| undefined`](../../doc/models/output-stage.md) | Optional | - |

## Example

```ts
import { QueryRuntimeStatistics2 } from 'amazon-athenalib';

const queryRuntimeStatistics2: QueryRuntimeStatistics2 = {
  timeline: {
    queryQueueTimeInMillis: 156,
    queryPlanningTimeInMillis: 82,
    engineExecutionTimeInMillis: 112,
    serviceProcessingTimeInMillis: 126,
    totalExecutionTimeInMillis: 106,
  },
  rows: {
    inputRows: 230,
    inputBytes: 250,
    outputBytes: 36,
    outputRows: 230,
  },
  outputStage: {
    stageId: 130,
    state: 'State0',
    outputBytes: 108,
    outputRows: 158,
    inputBytes: 190,
  },
};
```

