
# Get Query Runtime Statistics Input

## Structure

`GetQueryRuntimeStatisticsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { GetQueryRuntimeStatisticsInput } from 'amazon-athenalib';

const getQueryRuntimeStatisticsInput: GetQueryRuntimeStatisticsInput = {
  queryExecutionId: 'QueryExecutionId0',
};
```

