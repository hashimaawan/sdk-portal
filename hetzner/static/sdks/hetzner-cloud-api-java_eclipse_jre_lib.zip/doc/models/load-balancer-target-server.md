
# Load Balancer Target Server

Server where the traffic should be routed through

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server | int getId() | setId(int id) |

## Example

```java
import cloud.hetzner.api.models.LoadBalancerTargetServer;

LoadBalancerTargetServer loadBalancerTargetServer = new LoadBalancerTargetServer.Builder(
    80
)
.build();
```

