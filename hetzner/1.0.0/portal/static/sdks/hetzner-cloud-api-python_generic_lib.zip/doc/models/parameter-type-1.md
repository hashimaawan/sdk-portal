
# Parameter Type 1

## Enumeration

`ParameterType1`

## Fields

| Name |
|  --- |
| `SPREAD` |

## Example

```python
from hetznercloudapi.models.parameter_type_1 import ParameterType1

parameter_type_1 = ParameterType1.SPREAD
```

