
# Type 29

Type of the resource

## Enumeration

`Type29`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |
| `Ip` |

## Example

```ts
import { Type29 } from 'hetzner-cloud-apilib';

const type29 = Type29.Server;
```

