
# Type 6 Enum

Type of resource referenced

## Enumeration

`Type6Enum`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type6Enum type6 = Type6Enum.Server;
```

