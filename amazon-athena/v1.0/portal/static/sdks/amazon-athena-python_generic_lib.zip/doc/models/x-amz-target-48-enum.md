
# X Amz Target 48 Enum

## Enumeration

`XAmzTarget48Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTSESSION` |

## Example

```python
from amazonathena.models.x_amz_target_48_enum import XAmzTarget48Enum

x_amz_target_48 = XAmzTarget48Enum.ENUM_AMAZONATHENASTARTSESSION
```

