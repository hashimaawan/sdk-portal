
# M1 Click

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`M1Click`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `String` | Required | The slug identifier for the 1-Click application. |
| `type` | `String` | Required | The type of the 1-Click application. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
m1_click = M1Click.new(
  slug: 'monitoring',
  type: 'kubernetes',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

