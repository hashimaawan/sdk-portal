
# Volumes Actions Resize Request

## Structure

`VolumesActionsResizeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `size` | `Float` | Required | New Volume size in GB (must be greater than current size) |

## Example

```ruby
volumes_actions_resize_request = VolumesActionsResizeRequest.new(
  50
)
```

