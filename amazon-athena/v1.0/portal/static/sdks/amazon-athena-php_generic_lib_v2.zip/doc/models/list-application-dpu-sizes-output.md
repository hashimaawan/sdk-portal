
# List Application DPU Sizes Output

## Structure

`ListApplicationDPUSizesOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `applicationDPUSizes` | [`?(ApplicationDPUSizes[])`](../../doc/models/application-dpu-sizes.md) | Optional | - | getApplicationDPUSizes(): ?array | setApplicationDPUSizes(?array applicationDPUSizes): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListApplicationDPUSizesOutputBuilder;
use AmazonAthenaLib\Models\Builders\ApplicationDPUSizesBuilder;

$listApplicationDPUSizesOutput = ListApplicationDPUSizesOutputBuilder::init()
    ->applicationDPUSizes(
        [
            ApplicationDPUSizesBuilder::init()
                ->applicationRuntimeId('ApplicationRuntimeId0')
                ->supportedDPUSizes(
                    [
                        113,
                        114
                    ]
                )
                ->build(),
            ApplicationDPUSizesBuilder::init()
                ->applicationRuntimeId('ApplicationRuntimeId0')
                ->supportedDPUSizes(
                    [
                        113,
                        114
                    ]
                )
                ->build()
        ]
    )
    ->nextToken('NextToken0')
    ->build();
```

