
# X Amz Target 57

## Enumeration

`XAmzTarget57`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA` |

## Example

```ruby
x_amz_target57 = XAmzTarget57::ENUM_AMAZONATHENAUPDATENOTEBOOKMETADATA
```

