
# Type 17 Enum

Floating IP type

## Enumeration

`Type17Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_17_enum import Type17Enum

type_17 = Type17Enum.IPV4
```

