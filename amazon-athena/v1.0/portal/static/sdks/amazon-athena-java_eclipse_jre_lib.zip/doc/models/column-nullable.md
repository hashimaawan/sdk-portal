
# Column Nullable

## Enumeration

`ColumnNullable`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```java
import com.amazonaws.useast1.athena.models.ColumnNullable;

ColumnNullable columnNullable = ColumnNullable.NOT_NULL;
```

