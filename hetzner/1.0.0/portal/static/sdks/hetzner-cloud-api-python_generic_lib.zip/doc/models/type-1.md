
# Type 1

Choose between uploading a Certificate in PEM format or requesting a managed *Let's Encrypt* Certificate. If omitted defaults to `uploaded`.

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```python
from hetznercloudapi.models.type_1 import Type1

type_1 = Type1.UPLOADED
```

