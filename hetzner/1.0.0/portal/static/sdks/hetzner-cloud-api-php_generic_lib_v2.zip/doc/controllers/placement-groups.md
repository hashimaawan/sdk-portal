# Placement Groups

```php
$placementGroupsApi = $client->getPlacementGroupsApi();
```

## Class Name

`PlacementGroupsApi`

## Methods

* [Get All Placement Groups](../../doc/controllers/placement-groups.md#get-all-placement-groups)
* [Create a Placement Group](../../doc/controllers/placement-groups.md#create-a-placement-group)
* [Delete a Placement Group](../../doc/controllers/placement-groups.md#delete-a-placement-group)
* [Get a Placement Group](../../doc/controllers/placement-groups.md#get-a-placement-group)
* [Update a Placement Group](../../doc/controllers/placement-groups.md#update-a-placement-group)


# Get All Placement Groups

Returns all PlacementGroup objects.

```php
function getAllPlacementGroups(
    ?string $sort = null,
    ?string $name = null,
    ?string $labelSelector = null,
    ?string $type = null
): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`?string(Sort)`](../../doc/models/sort.md) | Query, Optional | Can be used multiple times. |
| `name` | `?string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `?string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |
| `type` | [`?string(ParameterType1)`](../../doc/models/parameter-type-1.md) | Query, Optional | Can be used multiple times. The response will only contain PlacementGroups matching the type. |

## Response Type

**200**: The `placement_groups` key contains an array of PlacementGroup objects

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`PlacementGroupsResponse`](../../doc/models/placement-groups-response.md).

## Example Usage

```php
$placementGroupsApi = $client->getPlacementGroupsApi();
$apiResponse = $placementGroupsApi->getAllPlacementGroups();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'PlacementGroupsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "placement_groups": [
    {
      "created": "2019-01-08T12:10:00+00:00",
      "id": 897,
      "labels": {
        "key": "value"
      },
      "name": "my Placement Group",
      "servers": [
        4711,
        4712
      ],
      "type": "spread"
    }
  ]
}
```


# Create a Placement Group

Creates a new PlacementGroup.

```php
function createAPlacementGroup(?CreatePlacementGroupRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`?CreatePlacementGroupRequest`](../../doc/models/create-placement-group-request.md) | Body, Optional | - |

## Response Type

**201**: The `PlacementGroup` key contains the PlacementGroup that was just created.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`CreatePlacementGroupResponse`](../../doc/models/create-placement-group-response.md).

## Example Usage

```php
$body = CreatePlacementGroupRequestBuilder::init(
    'my Placement Group'
)->build();

$placementGroupsApi = $client->getPlacementGroupsApi();
$apiResponse = $placementGroupsApi->createAPlacementGroup($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'CreatePlacementGroupResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [],
    "type": "spread"
  }
}
```


# Delete a Placement Group

Deletes a PlacementGroup.

```php
function deleteAPlacementGroup(int $id): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**204**: PlacementGroup deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```php
$id = 112;

$placementGroupsApi = $client->getPlacementGroupsApi();
$apiResponse = $placementGroupsApi->deleteAPlacementGroup($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'void:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Get a Placement Group

Gets a specific PlacementGroup object.

```php
function getAPlacementGroup(int $id): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |

## Response Type

**200**: The `placement_group` key contains a PlacementGroup object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`PlacementGroupResponse`](../../doc/models/placement-group-response.md).

## Example Usage

```php
$id = 112;

$placementGroupsApi = $client->getPlacementGroupsApi();
$apiResponse = $placementGroupsApi->getAPlacementGroup($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'PlacementGroupResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```


# Update a Placement Group

Updates the PlacementGroup properties.

Note that when updating labels, the PlacementGroup’s current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

Note: if the PlacementGroup object changes during the request, the response will be a “conflict” error.

```php
function updateAPlacementGroup(int $id, ?UpdatePlacementGroupRequest $body = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the resource |
| `body` | [`?UpdatePlacementGroupRequest`](../../doc/models/update-placement-group-request.md) | Body, Optional | - |

## Response Type

**200**: The `certificate` key contains the PlacementGroup that was just updated

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`PlacementGroupResponse`](../../doc/models/placement-group-response.md).

## Example Usage

```php
$id = 112;

$body = UpdatePlacementGroupRequestBuilder::init()
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('my Placement Group')
    ->build();

$placementGroupsApi = $client->getPlacementGroupsApi();
$apiResponse = $placementGroupsApi->updateAPlacementGroup(
    $id,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'PlacementGroupResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Example Response *(as JSON)*

```json
{
  "placement_group": {
    "created": "2019-01-08T12:10:00+00:00",
    "id": 897,
    "labels": {
      "key": "value"
    },
    "name": "my Placement Group",
    "servers": [
      4711,
      4712
    ],
    "type": "spread"
  }
}
```

