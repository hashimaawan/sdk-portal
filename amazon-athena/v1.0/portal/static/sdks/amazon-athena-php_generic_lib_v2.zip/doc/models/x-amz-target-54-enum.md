
# X Amz Target 54 Enum

## Enumeration

`XAmzTarget54Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEDATACATALOG` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget54Enum;

$xAmzTarget54 = XAmzTarget54Enum::ENUM_AMAZONATHENAUPDATEDATACATALOG;
```

