
# V2 Apps Response 2

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AppsResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_apps_response2 = V2AppsResponse2.new(
  id: '4f6c71e2-1e90-4762-9fee-6cc4a0a9f2cf',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

