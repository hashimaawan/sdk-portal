
# V2 Droplets Actions Request 2

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `image` | `Integer` | Optional | The ID of a backup of the current Droplet instance to restore from. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_droplets_actions_request2 = V2DropletsActionsRequest2.new(
  type: Type12::REBOOT,
  image: 12389723,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

