
# X Amz Target 49

## Enumeration

`XAmzTarget49`

## Fields

| Name |
|  --- |
| `EnumAmazonathenastopcalculationexecution` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget49 := models.XAmzTarget49_EnumAmazonathenastopcalculationexecution

}
```

