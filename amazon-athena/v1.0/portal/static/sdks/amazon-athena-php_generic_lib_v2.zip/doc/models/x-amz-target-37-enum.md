
# X Amz Target 37 Enum

## Enumeration

`XAmzTarget37Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNAMEDQUERIES` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget37Enum;

$xAmzTarget37 = XAmzTarget37Enum::ENUM_AMAZONATHENALISTNAMEDQUERIES;
```

