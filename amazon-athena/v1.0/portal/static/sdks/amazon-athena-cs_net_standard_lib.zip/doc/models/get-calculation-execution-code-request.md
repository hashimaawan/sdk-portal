
# Get Calculation Execution Code Request

*This model accepts additional fields of type object.*

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

GetCalculationExecutionCodeRequest getCalculationExecutionCodeRequest = new GetCalculationExecutionCodeRequest
{
    CalculationExecutionId = "CalculationExecutionId4",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

