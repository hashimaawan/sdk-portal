
# V2 Reserved Ips Actions Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2ReservedIpsActionsRequest`

## Inherits From

[`BaseType`](../../doc/models/base-type.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_id` | `int` | Required | The ID of the Droplet that the reserved IP will be assigned to. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.base_type import V2ReservedIpsActionsRequest

v_2_reserved_ips_actions_request = V2ReservedIpsActionsRequest(
    droplet_id=758604968,
    mtype='V2 Reserved Ips Actions Request',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

