
# Engine Version

The Athena engine version for running queries, or the PySpark engine version for running sessions.

## Structure

`EngineVersion`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selectedEngineVersion` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `effectiveEngineVersion` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```ts
import { EngineVersion } from 'amazon-athenalib';

const engineVersion: EngineVersion = {
  selectedEngineVersion: 'SelectedEngineVersion0',
  effectiveEngineVersion: 'EffectiveEngineVersion0',
};
```

