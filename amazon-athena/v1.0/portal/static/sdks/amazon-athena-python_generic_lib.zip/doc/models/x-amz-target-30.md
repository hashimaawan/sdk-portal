
# X Amz Target 30

## Enumeration

`XAmzTarget30`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAIMPORTNOTEBOOK` |

## Example

```python
from amazonathena.models.x_amz_target_30 import XAmzTarget30

x_amz_target_30 = XAmzTarget30.ENUM_AMAZONATHENAIMPORTNOTEBOOK
```

