
# Result Configuration 1

## Structure

`ResultConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `OutputLocation` | `*string` | Optional | - |
| `EncryptionConfiguration` | [`*models.EncryptionConfiguration2`](../../doc/models/encryption-configuration-2.md) | Optional | - |
| `ExpectedBucketOwner` | `*string` | Optional | **Constraints**: *Minimum Length*: `12`, *Maximum Length*: `12`, *Pattern*: `^[0-9]+$` |
| `AclConfiguration` | [`*models.AclConfiguration1`](../../doc/models/acl-configuration-1.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    resultConfiguration1 := models.ResultConfiguration1{
        OutputLocation:          models.ToPointer("OutputLocation4"),
        EncryptionConfiguration: models.ToPointer(models.EncryptionConfiguration2{
            EncryptionOption:     models.EncryptionOption1Enum_SSES3,
            KmsKey:               models.ToPointer("KmsKey6"),
        }),
        ExpectedBucketOwner:     models.ToPointer("ExpectedBucketOwner4"),
        AclConfiguration:        models.ToPointer(models.AclConfiguration1{
            S3AclOption:          models.S3AclOption1Enum_BUCKETOWNERFULLCONTROL,
        }),
    }

}
```

