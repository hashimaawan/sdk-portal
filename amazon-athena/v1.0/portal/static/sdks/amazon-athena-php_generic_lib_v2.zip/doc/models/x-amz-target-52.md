
# X Amz Target 52

## Enumeration

`XAmzTarget52`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATERMINATESESSION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget52;

$xAmzTarget52 = XAmzTarget52::ENUM_AMAZONATHENATERMINATESESSION;
```

