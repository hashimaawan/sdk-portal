
# Calculation Statistics

Contains statistics for a notebook calculation.

## Structure

`CalculationStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `Integer` | Optional | - |
| `progress` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
calculation_statistics = CalculationStatistics.new(
  242,
  'Progress6'
)
```

