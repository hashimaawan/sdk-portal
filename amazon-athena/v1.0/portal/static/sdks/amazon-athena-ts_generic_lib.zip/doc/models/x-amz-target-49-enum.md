
# X Amz Target 49 Enum

## Enumeration

`XAmzTarget49Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStopCalculationExecution` |

## Example

```ts
import { XAmzTarget49Enum } from 'amazon-athenalib';

const xAmzTarget49 = XAmzTarget49Enum.EnumAmazonAthenaStopCalculationExecution;
```

