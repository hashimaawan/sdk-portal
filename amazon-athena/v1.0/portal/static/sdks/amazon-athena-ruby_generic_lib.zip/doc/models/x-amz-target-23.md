
# X Amz Target 23

## Enumeration

`XAmzTarget23`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYEXECUTION` |

## Example

```ruby
x_amz_target23 = XAmzTarget23::ENUM_AMAZONATHENAGETQUERYEXECUTION
```

