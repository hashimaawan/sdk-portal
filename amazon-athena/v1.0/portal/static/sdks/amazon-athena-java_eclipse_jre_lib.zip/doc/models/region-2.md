
# Region 2

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```java
import com.amazonaws.useast1.athena.models.Region2;

Region2 region2 = Region2.CNNORTH1;
```

