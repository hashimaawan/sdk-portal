
# X Amz Target 3

## Enumeration

`XAmzTarget3`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEDATACATALOG` |

## Example

```python
from amazonathena.models.x_amz_target_3 import XAmzTarget3

x_amz_target_3 = XAmzTarget3.ENUM_AMAZONATHENACREATEDATACATALOG
```

