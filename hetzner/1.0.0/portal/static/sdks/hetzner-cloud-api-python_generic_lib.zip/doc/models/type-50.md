
# Type 50

Type of the Primary IP

## Enumeration

`Type50`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_50 import Type50

type_50 = Type50.IPV4
```

