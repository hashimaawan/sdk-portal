
# V2 Registry Garbage Collection Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `garbage_collection` | [`GarbageCollection`](../../doc/models/garbage-collection.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.garbage_collection import GarbageCollection
from digitaloceanapi.models.status_15 import Status15
from digitaloceanapi.models.v_2_registry_garbage_collection_response import V2RegistryGarbageCollectionResponse

v_2_registry_garbage_collection_response = V2RegistryGarbageCollectionResponse(
    garbage_collection=GarbageCollection(
        blobs_deleted=40,
        created_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
        freed_bytes=86,
        registry_name='registry_name6',
        status=Status15.SUCCEEDED,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

