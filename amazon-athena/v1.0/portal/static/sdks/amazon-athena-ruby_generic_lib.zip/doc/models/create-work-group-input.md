
# Create Work Group Input

## Structure

`CreateWorkGroupInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `configuration` | [`Configuration`](../../doc/models/configuration.md) | Optional | - |
| `description` | `String` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` |
| `tags` | [`Array[Tag]`](../../doc/models/tag.md) | Optional | - |

## Example

```ruby
create_work_group_input = CreateWorkGroupInput.new(
  'Name8',
  Configuration.new(
    ResultConfiguration1.new(
      'OutputLocation0',
      EncryptionConfiguration2.new(
        EncryptionOption1Enum::SSE_S3,
        'KmsKey6'
      ),
      'ExpectedBucketOwner0',
      AclConfiguration1.new(
        S3AclOption1Enum::BUCKET_OWNER_FULL_CONTROL
      )
    ),
    false,
    false,
    10000000,
    false,
    EngineVersion1.new,
    nil,
    nil,
    CustomerContentEncryptionConfiguration2.new
  ),
  'Description8',
  [
    Tag.new(
      'Key0',
      'Value6'
    )
  ]
)
```

