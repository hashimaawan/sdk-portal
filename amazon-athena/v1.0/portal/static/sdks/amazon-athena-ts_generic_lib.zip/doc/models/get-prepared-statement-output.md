
# Get Prepared Statement Output

## Structure

`GetPreparedStatementOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preparedStatement` | [`PreparedStatement1 \| undefined`](../../doc/models/prepared-statement-1.md) | Optional | - |

## Example

```ts
import { GetPreparedStatementOutput } from 'amazon-athenalib';

const getPreparedStatementOutput: GetPreparedStatementOutput = {
  preparedStatement: {
    statementName: 'StatementName4',
    queryStatement: 'QueryStatement8',
    workGroupName: 'WorkGroupName8',
    description: 'Description0',
    lastModifiedTime: '2016-03-13T12:52:32.123Z',
  },
};
```

