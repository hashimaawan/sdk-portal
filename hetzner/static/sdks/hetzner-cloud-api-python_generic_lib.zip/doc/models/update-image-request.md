
# Update Image Request

## Structure

`UpdateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Optional | New description of Image |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `mtype` | [`Type24Enum`](../../doc/models/type-24-enum.md) | Optional | Destination Image type to convert to |

## Example

```python
import jsonpickle

from hetznercloudapi.models.type_24_enum import Type24Enum
from hetznercloudapi.models.update_image_request import UpdateImageRequest

update_image_request = UpdateImageRequest(
    description='My new Image description',
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    mtype=Type24Enum.SNAPSHOT
)
```

