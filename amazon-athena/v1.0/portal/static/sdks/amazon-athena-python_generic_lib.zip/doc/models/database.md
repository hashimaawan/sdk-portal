
# Database

Contains metadata information for a database in a data catalog.

## Structure

`Database`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```python
from amazonathena.models.database import Database
from amazonathena.models.parameters import Parameters

database = Database(
    name='Name0',
    description='Description6',
    parameters=Parameters()
)
```

