
# Server

## Structure

`Server`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Resource |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Server server = new Server
{
    Id = 42,
};
```

