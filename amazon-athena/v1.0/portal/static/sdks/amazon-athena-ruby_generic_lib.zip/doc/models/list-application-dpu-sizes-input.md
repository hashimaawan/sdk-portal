
# List Application Dpu Sizes Input

*This model accepts additional fields of type Object.*

## Structure

`ListApplicationDpuSizesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
list_application_dpu_sizes_input = ListApplicationDpuSizesInput.new(
  max_results: 76,
  next_token: 'NextToken6',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

