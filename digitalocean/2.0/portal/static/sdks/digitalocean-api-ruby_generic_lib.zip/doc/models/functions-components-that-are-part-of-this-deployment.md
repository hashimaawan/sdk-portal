
# Functions Components that Are Part of This Deployment

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`FunctionsComponentsThatArePartOfThisDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | - |
| `namespace` | `String` | Optional | The namespace where the functions are deployed. |
| `source_commit_hash` | `String` | Optional | The commit hash of the repository that was used to build this functions component. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
functions_components_that_are_part_of_this_deployment = FunctionsComponentsThatArePartOfThisDeployment.new(
  name: 'my-functions-component',
  namespace: 'ap-b2a93513-8d9b-4223-9d61-5e7272c81c32',
  source_commit_hash: '54d4a727f457231062439895000d45437c7bb405',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

