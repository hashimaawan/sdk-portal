
# Playlists Followers Request

*This model accepts additional fields of type interface{}.*

## Structure

`PlaylistsFollowersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Public` | `*bool` | Optional | Defaults to `true`. If `true` the playlist will be included in user's public playlists, if `false` it will remain private. |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    playlistsFollowersRequest := models.PlaylistsFollowersRequest{
        Public:                models.ToPointer(false),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

