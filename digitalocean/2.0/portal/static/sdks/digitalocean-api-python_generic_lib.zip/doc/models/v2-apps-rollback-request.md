
# V2 Apps Rollback Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2AppsRollbackRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deployment_id` | `str` | Optional | The ID of the deployment to rollback to. |
| `skip_pin` | `bool` | Optional | Whether to skip pinning the rollback deployment. If false, the rollback deployment will be pinned and any new deployments including Auto Deploy on Push hooks will be disabled until the rollback is either manually committed or reverted via the CommitAppRollback or RevertAppRollback endpoints respectively. If true, the rollback will be immediately committed and the app will remain unpinned. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_apps_rollback_request import V2AppsRollbackRequest

v_2_apps_rollback_request = V2AppsRollbackRequest(
    deployment_id='3aa4d20e-5527-4c00-b496-601fbd22520a',
    skip_pin=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

