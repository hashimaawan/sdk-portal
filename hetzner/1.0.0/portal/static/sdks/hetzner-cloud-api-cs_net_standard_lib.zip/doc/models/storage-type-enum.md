
# Storage Type Enum

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageTypeEnum`

## Fields

| Name |
|  --- |
| `Local` |
| `Network` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

StorageTypeEnum storageType = StorageTypeEnum.Local;
```

