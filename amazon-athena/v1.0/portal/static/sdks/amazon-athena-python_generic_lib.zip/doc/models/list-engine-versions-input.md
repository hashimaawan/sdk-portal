
# List Engine Versions Input

*This model accepts additional fields of type Any.*

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `int` | Optional | **Constraints**: `>= 1`, `<= 10` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.list_engine_versions_input import ListEngineVersionsInput

list_engine_versions_input = ListEngineVersionsInput(
    next_token='NextToken0',
    max_results=10,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

