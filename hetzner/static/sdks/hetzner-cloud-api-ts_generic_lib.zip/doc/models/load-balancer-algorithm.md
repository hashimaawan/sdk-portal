
# Load Balancer Algorithm

Algorithm of the Load Balancer

## Structure

`LoadBalancerAlgorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```ts
import { LoadBalancerAlgorithm, Type28Enum } from 'hetzner-cloud-apilib';

const loadBalancerAlgorithm: LoadBalancerAlgorithm = {
  type: Type28Enum.RoundRobin,
};
```

