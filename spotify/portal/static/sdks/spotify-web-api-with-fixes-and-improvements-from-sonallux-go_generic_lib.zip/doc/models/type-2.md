
# Type 2

The object type: "track".

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `Track` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    type2 := models.Type2_Track

}
```

