
# Pending Change

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`PendingChange`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dropletId` | `?int` | Optional | - | getDropletId(): ?int | setDropletId(?int dropletId): void |
| `removing` | `?bool` | Optional | - | getRemoving(): ?bool | setRemoving(?bool removing): void |
| `status` | `?string` | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\PendingChangeBuilder;
use DigitalOceanApiLib\ApiHelper;

$pendingChange = PendingChangeBuilder::init()
    ->dropletId(8043964)
    ->removing(false)
    ->status('waiting')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

