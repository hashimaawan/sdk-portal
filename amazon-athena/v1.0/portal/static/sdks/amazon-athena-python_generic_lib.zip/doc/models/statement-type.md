
# Statement Type

## Enumeration

`StatementType`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```python
from amazonathena.models.statement_type import StatementType

statement_type = StatementType.DDL
```

