
# List Calculation Executions Request

## Structure

`ListCalculationExecutionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `stateFilter` | [`CalculationExecutionState3Enum \| undefined`](../../doc/models/calculation-execution-state-3-enum.md) | Optional | - |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```ts
import {
  CalculationExecutionState3Enum,
  ListCalculationExecutionsRequest,
} from 'amazon-athenalib';

const listCalculationExecutionsRequest: ListCalculationExecutionsRequest = {
  sessionId: 'SessionId2',
  stateFilter: CalculationExecutionState3Enum.QUEUED,
  maxResults: 100,
  nextToken: 'NextToken0',
};
```

