
# Update Volume Request

*This model accepts additional fields of type Any.*

## Structure

`UpdateVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Required | New Volume name |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.labels_2 import Labels2
from hetznercloudapi.models.update_volume_request import UpdateVolumeRequest

update_volume_request = UpdateVolumeRequest(
    name='database-storage',
    labels=Labels2(
        labelkey='labelkey4',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

