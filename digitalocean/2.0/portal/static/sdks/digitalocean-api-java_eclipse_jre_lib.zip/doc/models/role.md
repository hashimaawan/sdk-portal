
# Role

A string representing the database user's role. The value will be either
"primary" or "normal".

## Enumeration

`Role`

## Fields

| Name |
|  --- |
| `PRIMARY` |
| `NORMAL` |

## Example

```java
import com.digitalocean.api.models.Role;

Role role = Role.PRIMARY;
```

