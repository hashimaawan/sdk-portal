
# Data Catalog Type 3 Enum

Specifies the type of data catalog to update. Specify <code>LAMBDA</code> for a federated catalog, <code>HIVE</code> for an external hive metastore, or <code>GLUE</code> for an Glue Data Catalog.

## Enumeration

`DataCatalogType3Enum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```ts
import { DataCatalogType3Enum } from 'amazon-athenalib';

const dataCatalogType3 = DataCatalogType3Enum.LAMBDA;
```

