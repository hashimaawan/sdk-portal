# Metrics

```java
MetricsApi metricsApi = client.getMetricsApi();
```

## Class Name

`MetricsApi`


# Get Prometheus Metrics

See Prometheus documentation for a complete data model.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ApiResponse<String>> getPrometheusMetricsAsync()
```

## Response Type

**200**: Successfully returned Prometheus metrics

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type `String`.

## Example Usage

```java
metricsApi.getPrometheusMetricsAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

