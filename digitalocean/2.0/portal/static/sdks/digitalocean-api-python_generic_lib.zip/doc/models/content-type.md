
# Content Type

## Enumeration

`ContentType`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONYAML` |

## Example

```python
from digitaloceanapi.models.content_type import ContentType

content_type = ContentType.ENUM_APPLICATIONJSON
```

