
# Type 22

Type of the Image

## Enumeration

`Type22`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `APP` |
| `SNAPSHOT` |
| `BACKUP` |
| `TEMPORARY` |

## Example

```python
from hetznercloudapi.models.type_22 import Type22

type_22 = Type22.APP
```

