
# X Amz Target 39 Enum

## Enumeration

`XAmzTarget39Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget39Enum;

$xAmzTarget39 = XAmzTarget39Enum::ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS;
```

