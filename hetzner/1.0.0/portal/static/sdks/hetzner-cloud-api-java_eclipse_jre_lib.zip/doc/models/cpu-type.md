
# Cpu Type

Type of cpu

## Enumeration

`CpuType`

## Fields

| Name |
|  --- |
| `SHARED` |
| `DEDICATED` |

## Example

```java
import cloud.hetzner.api.models.CpuType;

CpuType cpuType = CpuType.SHARED;
```

