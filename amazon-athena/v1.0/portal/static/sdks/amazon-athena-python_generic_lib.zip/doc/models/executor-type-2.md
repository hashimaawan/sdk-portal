
# Executor Type 2

The type of executor used for the application (<code>COORDINATOR</code>, <code>GATEWAY</code>, or <code>WORKER</code>).

## Enumeration

`ExecutorType2`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```python
from amazonathena.models.executor_type_2 import ExecutorType2

executor_type_2 = ExecutorType2.GATEWAY
```

