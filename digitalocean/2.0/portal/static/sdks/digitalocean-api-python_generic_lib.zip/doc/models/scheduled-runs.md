
# Scheduled Runs

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`ScheduledRuns`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `last_run_at` | `str` | Optional | Indicates last run time. null value indicates trigger not run yet. |
| `next_run_at` | `str` | Optional | Indicates next run time. null value indicates trigger will not run. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.scheduled_runs import ScheduledRuns

scheduled_runs = ScheduledRuns(
    last_run_at='2022-11-11T04:16:45Z',
    next_run_at='2022-11-11T04:16:45Z',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

