
# Servers Actions Attach Iso Request

## Structure

`ServersActionsAttachIsoRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Iso` | `string` | Required | ID or name of ISO to attach to the Server as listed in GET `/isos` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    serversActionsAttachIsoRequest := models.ServersActionsAttachIsoRequest{
        Iso:                  "FreeBSD-11.0-RELEASE-amd64-dvd1",
    }

}
```

