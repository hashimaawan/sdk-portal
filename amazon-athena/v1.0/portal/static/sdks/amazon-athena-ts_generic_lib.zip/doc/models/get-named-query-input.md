
# Get Named Query Input

## Structure

`GetNamedQueryInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { GetNamedQueryInput } from 'amazon-athenalib';

const getNamedQueryInput: GetNamedQueryInput = {
  namedQueryId: 'NamedQueryId8',
};
```

