
# Result Reuse by Age Configuration 2

## Structure

`ResultReuseByAgeConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enabled` | `bool` | Required | - |
| `max_age_in_minutes` | `int` | Optional | **Constraints**: `>= 0`, `<= 10080` |

## Example

```python
from amazonathena.models.result_reuse_by_age_configuration_2 import ResultReuseByAgeConfiguration2

result_reuse_by_age_configuration_2 = ResultReuseByAgeConfiguration2(
    enabled=False,
    max_age_in_minutes=134
)
```

