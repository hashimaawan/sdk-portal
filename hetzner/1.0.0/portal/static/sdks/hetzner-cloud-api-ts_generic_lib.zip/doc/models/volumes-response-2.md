
# Volumes Response 2

*This model accepts additional fields of type unknown.*

## Structure

`VolumesResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `volume` | [`Volume1`](../../doc/models/volume-1.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Status113, VolumesResponse2 } from 'hetzner-cloud-apilib';

const volumesResponse2: VolumesResponse2 = {
  volume: {
    created: '2016-01-30T23:55:00+00:00',
    format: 'xfs',
    id: 42,
    labels: {
      'key0': 'labels8',
      'key1': 'labels9',
      'key2': 'labels0'
    },
    linuxDevice: '/dev/disk/by-id/scsi-0HC_Volume_4711',
    location: {
      city: 'Falkenstein',
      country: 'DE',
      description: 'Falkenstein DC Park 1',
      id: 1,
      latitude: 50.47612,
      longitude: 12.370071,
      name: 'fsn1',
      networkZone: 'eu-central',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    name: 'my-resource',
    protection: {
      mDelete: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    server: 12,
    size: 42,
    status: Status113.Available,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

