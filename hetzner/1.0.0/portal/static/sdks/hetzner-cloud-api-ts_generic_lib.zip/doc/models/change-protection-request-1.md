
# Change Protection Request 1

*This model accepts additional fields of type unknown.*

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean \| undefined` | Optional | If true, prevents the Network from being deleted |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChangeProtectionRequest1 } from 'hetzner-cloud-apilib';

const changeProtectionRequest1: ChangeProtectionRequest1 = {
  mDelete: true,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

