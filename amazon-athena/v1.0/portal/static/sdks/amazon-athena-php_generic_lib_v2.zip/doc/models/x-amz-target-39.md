
# X Amz Target 39

## Enumeration

`XAmzTarget39`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget39;

$xAmzTarget39 = XAmzTarget39::ENUM_AMAZONATHENALISTNOTEBOOKSESSIONS;
```

