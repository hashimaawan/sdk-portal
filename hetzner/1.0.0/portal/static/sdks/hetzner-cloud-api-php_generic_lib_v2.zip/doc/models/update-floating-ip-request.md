
# Update Floating IP Request

## Structure

`UpdateFloatingIPRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `description` | `?string` | Optional | New Description to set | getDescription(): ?string | setDescription(?string description): void |
| `labels` | `?array` | Optional | User-defined labels (key-value pairs) | getLabels(): ?array | setLabels(?array labels): void |
| `name` | `?string` | Optional | New unique name to set | getName(): ?string | setName(?string name): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\UpdateFloatingIPRequestBuilder;
use HetznerCloudAPILib\ApiHelper;

$updateFloatingIPRequest = UpdateFloatingIPRequestBuilder::init()
    ->description('Web Frontend')
    ->labels(ApiHelper::deserialize('{"labelkey":"value"}'))
    ->name('Web Frontend')
    ->build();
```

