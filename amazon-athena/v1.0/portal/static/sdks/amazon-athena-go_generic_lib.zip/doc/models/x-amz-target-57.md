
# X Amz Target 57

## Enumeration

`XAmzTarget57`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaupdatenotebookmetadata` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget57 := models.XAmzTarget57_EnumAmazonathenaupdatenotebookmetadata

}
```

