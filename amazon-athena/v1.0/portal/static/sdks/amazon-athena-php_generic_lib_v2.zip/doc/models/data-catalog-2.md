
# Data Catalog 2

## Structure

`DataCatalog2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getName(): string | setName(string name): void |
| `description` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getDescription(): ?string | setDescription(?string description): void |
| `type` | [`string(DataCatalogType1Enum)`](../../doc/models/data-catalog-type-1-enum.md) | Required | - | getType(): string | setType(string type): void |
| `parameters` | [`?Parameters`](../../doc/models/parameters.md) | Optional | - | getParameters(): ?Parameters | setParameters(?Parameters parameters): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DataCatalog2Builder;
use AmazonAthenaLib\Models\DataCatalogType1Enum;
use AmazonAthenaLib\Models\Builders\ParametersBuilder;

$dataCatalog2 = DataCatalog2Builder::init(
    'Name6',
    DataCatalogType1Enum::LAMBDA
)
    ->description('Description0')
    ->parameters(
        ParametersBuilder::init()->build()
    )->build();
```

