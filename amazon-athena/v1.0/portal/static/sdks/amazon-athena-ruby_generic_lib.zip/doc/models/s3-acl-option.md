
# S3 Acl Option

## Enumeration

`S3AclOption`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```ruby
s3_acl_option = S3AclOption::BUCKET_OWNER_FULL_CONTROL
```

