
# Error

Error message for the Action if error occurred, otherwise null

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string` | Required | Fixed machine readable code |
| `message` | `string` | Required | Humanized error message |

## Example

```ts
import { Error } from 'hetzner-cloud-apilib';

const error: Error = {
  code: 'action_failed',
  message: 'Action failed',
};
```

