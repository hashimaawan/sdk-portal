
# Renewal Enum

Status of the renewal process of the Certificate.

## Enumeration

`RenewalEnum`

## Fields

| Name |
|  --- |
| `SCHEDULED` |
| `PENDING` |
| `FAILED` |
| `UNAVAILABLE` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    renewal := models.RenewalEnum_FAILED

}
```

