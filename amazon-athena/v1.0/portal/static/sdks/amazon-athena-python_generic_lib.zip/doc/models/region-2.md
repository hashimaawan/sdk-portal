
# Region 2

## Enumeration

`Region2`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```python
from amazonathena.models.region_2 import Region2

region_2 = Region2.CNNORTH1
```

