
# X Amz Target 35 Enum

## Enumeration

`XAmzTarget35Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTENGINEVERSIONS` |

## Example

```ruby
x_amz_target35 = XAmzTarget35Enum::ENUM_AMAZONATHENALISTENGINEVERSIONS
```

