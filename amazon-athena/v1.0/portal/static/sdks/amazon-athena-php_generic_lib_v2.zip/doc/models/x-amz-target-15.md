
# X Amz Target 15

## Enumeration

`XAmzTarget15`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget15;

$xAmzTarget15 = XAmzTarget15::ENUM_AMAZONATHENAGETCALCULATIONEXECUTION;
```

