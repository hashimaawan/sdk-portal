
# Work Group State

## Enumeration

`WorkGroupState`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```java
import com.amazonaws.useast1.athena.models.WorkGroupState;

WorkGroupState workGroupState = WorkGroupState.ENABLED;
```

