
# X Amz Target 8

## Enumeration

`XAmzTarget8`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateWorkGroup` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget8 xAmzTarget8 = XAmzTarget8.EnumAmazonAthenaCreateWorkGroup;
```

