
# Stop Calculation Execution Request

## Structure

`StopCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | getCalculationExecutionId(): string | setCalculationExecutionId(string calculationExecutionId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\StopCalculationExecutionRequestBuilder;

$stopCalculationExecutionRequest = StopCalculationExecutionRequestBuilder::init(
    'CalculationExecutionId2'
)->build();
```

