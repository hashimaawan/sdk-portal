
# Row

The rows that make up a query result table.

## Structure

`Row`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Data` | [`[]models.Datum`](../../doc/models/datum.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    row := models.Row{
        Data:                 []models.Datum{
            models.Datum{
                VarCharValue:         models.ToPointer("VarCharValue8"),
            },
        },
    }

}
```

