
# Eligibility Reason

## Enumeration

`EligibilityReason`

## Fields

| Name |
|  --- |
| `OVERREPOSITORYLIMIT` |
| `OVERSTORAGELIMIT` |

## Example

```php
use DigitalOceanApiLib\Models\EligibilityReason;

$eligibilityReason = EligibilityReason::OVERREPOSITORYLIMIT;
```

