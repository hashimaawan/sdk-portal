
# Status

Status of the Action

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `RUNNING` |
| `ERROR` |

## Example

```java
import cloud.hetzner.api.models.Status;

Status status = Status.ERROR;
```

