
# Type 2

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `UserCreated` |
| `Personal` |
| `Everyone` |
| `Transfer` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

Type2 type2 = Type2.Everyone;
```

