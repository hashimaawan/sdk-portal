
# Environment

The environment of the project's resources.

## Enumeration

`Environment`

## Fields

| Name |
|  --- |
| `DEVELOPMENT` |
| `STAGING` |
| `PRODUCTION` |

## Example

```ruby
environment = Environment::STAGING
```

