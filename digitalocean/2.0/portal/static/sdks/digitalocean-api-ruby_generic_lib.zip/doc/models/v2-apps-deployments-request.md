
# V2 Apps Deployments Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AppsDeploymentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `force_build` | `TrueClass \| FalseClass` | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_apps_deployments_request = V2AppsDeploymentsRequest.new(
  force_build: true,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

