
# X Amz Target 52 Enum

## Enumeration

`XAmzTarget52Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATERMINATESESSION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget52Enum;

$xAmzTarget52 = XAmzTarget52Enum::ENUM_AMAZONATHENATERMINATESESSION;
```

