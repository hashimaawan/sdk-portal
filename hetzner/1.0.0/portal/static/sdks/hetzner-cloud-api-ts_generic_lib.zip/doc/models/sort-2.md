
# Sort 2

## Enumeration

`Sort2`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```ts
import { Sort2 } from 'hetzner-cloud-apilib';

const sort2 = Sort2.EnumCreatedasc;
```

