
# X Amz Target 25 Enum

## Enumeration

`XAmzTarget25Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```ruby
x_amz_target25 = XAmzTarget25Enum::ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS
```

