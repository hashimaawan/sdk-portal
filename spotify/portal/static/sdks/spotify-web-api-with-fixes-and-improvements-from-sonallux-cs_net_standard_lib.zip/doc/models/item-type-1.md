
# Item Type 1

The ID type: currently only `artist` is supported.

## Enumeration

`ItemType1`

## Fields

| Name |
|  --- |
| `Artist` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

ItemType1 itemType1 = ItemType1.Artist;
```

