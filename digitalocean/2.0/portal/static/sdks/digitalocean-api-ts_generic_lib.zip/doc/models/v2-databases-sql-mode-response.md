
# V2 Databases Sql Mode Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesSqlModeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sqlMode` | `string` | Required | A string specifying the configured SQL modes for the MySQL cluster. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2DatabasesSqlModeResponse } from 'digitalocean-apilib';

const v2DatabasesSqlModeResponse: V2DatabasesSqlModeResponse = {
  sqlMode: 'ANSI,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION,NO_ZERO_DATE,NO_ZERO_IN_DATE,STRICT_ALL_TABLES',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

