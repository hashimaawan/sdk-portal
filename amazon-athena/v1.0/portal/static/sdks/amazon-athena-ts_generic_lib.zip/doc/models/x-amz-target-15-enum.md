
# X Amz Target 15 Enum

## Enumeration

`XAmzTarget15Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecution` |

## Example

```ts
import { XAmzTarget15Enum } from 'amazon-athenalib';

const xAmzTarget15 = XAmzTarget15Enum.EnumAmazonAthenaGetCalculationExecution;
```

