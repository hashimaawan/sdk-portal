
# Type 6 Enum

Type of resource referenced

## Enumeration

`Type6Enum`

## Fields

| Name |
|  --- |
| `Server` |
| `LabelSelector` |

## Example

```ts
import { Type6Enum } from 'hetzner-cloud-apilib';

const type6 = Type6Enum.Server;
```

