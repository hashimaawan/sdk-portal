
# Untag Resource Input

## Structure

`UntagResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resourceARN` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `tagKeys` | `string[]` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```ts
import { UntagResourceInput } from 'amazon-athenalib';

const untagResourceInput: UntagResourceInput = {
  resourceARN: 'ResourceARN6',
  tagKeys: [
    'TagKeys1',
    'TagKeys2',
    'TagKeys3'
  ],
};
```

