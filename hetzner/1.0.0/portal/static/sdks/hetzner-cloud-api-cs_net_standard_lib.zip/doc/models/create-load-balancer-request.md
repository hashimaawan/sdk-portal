
# Create Load Balancer Request

## Structure

`CreateLoadBalancerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Algorithm` | [`LoadBalancerAlgorithm`](../../doc/models/load-balancer-algorithm.md) | Required | Algorithm of the Load Balancer |
| `Labels` | [`Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `LoadBalancerType` | `string` | Required | ID or name of the Load Balancer type this Load Balancer should be created with |
| `Location` | `string` | Optional | ID or name of Location to create Load Balancer in |
| `Name` | `string` | Required | Name of the Load Balancer |
| `Network` | `int?` | Optional | ID of the network the Load Balancer should be attached to on creation |
| `NetworkZone` | `string` | Optional | Name of network zone |
| `PublicInterface` | `bool?` | Optional | Enable or disable the public interface of the Load Balancer |
| `Services` | [`List<LoadBalancerService>`](../../doc/models/load-balancer-service.md) | Optional | Array of services |
| `Targets` | [`List<LoadBalancerTarget>`](../../doc/models/load-balancer-target.md) | Optional | Array of targets |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

CreateLoadBalancerRequest createLoadBalancerRequest = new CreateLoadBalancerRequest
{
    Algorithm = new LoadBalancerAlgorithm
    {
        Type = Type28Enum.RoundRobin,
    },
    LoadBalancerType = "lb11",
    Name = "Web Frontend",
    Labels = new Labels
    {
        Labelkey = "labelkey4",
    },
    Location = "location2",
    Network = 123,
    NetworkZone = "eu-central",
    PublicInterface = true,
};
```

