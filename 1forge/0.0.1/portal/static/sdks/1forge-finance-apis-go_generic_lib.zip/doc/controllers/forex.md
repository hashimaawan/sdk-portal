# Forex

```go
forexApi := client.ForexApi()
```

## Class Name

`ForexApi`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```go
GetQuotesForAllSymbols(
    ctx context.Context) (
    http.Response,
    error)
```

## Response Type

**200**: A list of quotes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

resp, err := forexApi.GetQuotesForAllSymbols(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```go
GetAListOfSymbolsForWhichWeProvideRealTimeQuotes(
    ctx context.Context) (
    models.ApiResponse[[]string],
    error)
```

## Response Type

**200**: A list of symbols

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type []string.

## Example Usage

```go
ctx := context.Background()

apiResponse, err := forexApi.GetAListOfSymbolsForWhichWeProvideRealTimeQuotes(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

