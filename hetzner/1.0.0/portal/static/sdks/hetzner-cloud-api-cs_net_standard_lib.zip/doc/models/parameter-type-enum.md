
# Parameter Type Enum

## Enumeration

`ParameterTypeEnum`

## Fields

| Name |
|  --- |
| `Uploaded` |
| `Managed` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ParameterTypeEnum parameterType = ParameterTypeEnum.Uploaded;
```

