
# List Data Catalogs Input

## Structure

`ListDataCatalogsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `maxResults` | `number \| undefined` | Optional | **Constraints**: `>= 2`, `<= 50` |

## Example

```ts
import { ListDataCatalogsInput } from 'amazon-athenalib';

const listDataCatalogsInput: ListDataCatalogsInput = {
  nextToken: 'NextToken8',
  maxResults: 50,
};
```

