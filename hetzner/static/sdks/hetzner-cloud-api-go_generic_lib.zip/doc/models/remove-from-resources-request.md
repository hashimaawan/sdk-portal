
# Remove from Resources Request

## Structure

`RemoveFromResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RemoveFrom` | [`[]models.FirewallRemoveFromResources`](../../doc/models/firewall-remove-from-resources.md) | Required | Resources the Firewall should be removed from |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    removeFromResourcesRequest := models.RemoveFromResourcesRequest{
        RemoveFrom:           []models.FirewallRemoveFromResources{
            models.FirewallRemoveFromResources{
                LabelSelector:        models.ToPointer(models.LabelSelector5{
                    Selector:             "selector8",
                }),
                Server:               models.ToPointer(models.Server9{
                    Id:                   14,
                }),
                Type:                 models.ToPointer(models.Type7Enum_SERVER),
            },
        },
    }

}
```

