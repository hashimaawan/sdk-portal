
# Type 6 Enum

Type of resource referenced

## Enumeration

`Type6Enum`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |

## Example

```php
use HetznerCloudAPILib\Models\Type6Enum;

$type6 = Type6Enum::SERVER;
```

