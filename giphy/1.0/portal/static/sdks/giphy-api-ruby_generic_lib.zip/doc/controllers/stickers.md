# Stickers

```ruby
stickers_controller = client.stickers
```

## Class Name

`StickersController`

## Methods

* [Random Sticker](../../doc/controllers/stickers.md#random-sticker)
* [Search Stickers](../../doc/controllers/stickers.md#search-stickers)
* [Translate Sticker](../../doc/controllers/stickers.md#translate-sticker)
* [Trending Stickers](../../doc/controllers/stickers.md#trending-stickers)


# Random Sticker

Returns a random GIF, limited by tag. Excluding the tag parameter will return a random GIF from the GIPHY catalog.

```ruby
def random_sticker(tag: nil,
                   rating: nil)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tag` | `String` | Query, Optional | Filters results by specified tag. |
| `rating` | `String` | Query, Optional | Filters results by specified rating. |

## Response Type

**200**

[`StickersRandomResponse`](../../doc/models/stickers-random-response.md)

## Example Usage

```ruby
result = stickers_controller.random_sticker
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `APIException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `APIException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `APIException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `APIException` |


# Search Stickers

Replicates the functionality and requirements of the classic GIPHY search, but returns animated stickers rather than GIFs.

```ruby
def search_stickers(q,
                    limit: 25,
                    offset: 0,
                    rating: nil,
                    lang: nil)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `q` | `String` | Query, Required | Search query term or prhase. |
| `limit` | `Integer` | Query, Optional | The maximum number of records to return.<br><br>**Default**: `25` |
| `offset` | `Integer` | Query, Optional | An optional results offset.<br><br>**Default**: `0` |
| `rating` | `String` | Query, Optional | Filters results by specified rating. |
| `lang` | `String` | Query, Optional | Specify default language for regional content; use a 2-letter ISO 639-1 language code. |

## Response Type

**200**: Search results

[`StickersSearchResponse`](../../doc/models/stickers-search-response.md)

## Example Usage

```ruby
q = 'q0'

limit = 25

offset = 0

result = stickers_controller.search_stickers(
  q,
  limit: limit,
  offset: offset
)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `APIException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `APIException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `APIException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `APIException` |


# Translate Sticker

The translate API draws on search, but uses the GIPHY `special sauce` to handle translating from one vocabulary to another. In this case, words and phrases to GIFs.

```ruby
def translate_sticker(s)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s` | `String` | Query, Required | Search term. |

## Response Type

**200**

[`StickersTranslateResponse`](../../doc/models/stickers-translate-response.md)

## Example Usage

```ruby
s = 's8'

result = stickers_controller.translate_sticker(s)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `APIException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `APIException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `APIException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `APIException` |


# Trending Stickers

Fetch Stickers currently trending online. Hand curated by the GIPHY editorial team. Returns 25 results by default.

```ruby
def trending_stickers(limit: 25,
                      offset: 0,
                      rating: nil)
```

## Authentication

This endpoint requires [api_key](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `Integer` | Query, Optional | The maximum number of records to return.<br><br>**Default**: `25` |
| `offset` | `Integer` | Query, Optional | An optional results offset.<br><br>**Default**: `0` |
| `rating` | `String` | Query, Optional | Filters results by specified rating. |

## Response Type

**200**

[`StickersTrendingResponse`](../../doc/models/stickers-trending-response.md)

## Example Usage

```ruby
limit = 25

offset = 0

result = stickers_controller.trending_stickers(
  limit: limit,
  offset: offset
)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Your request was formatted incorrectly or missing required parameters. | `APIException` |
| 403 | You weren't authorized to make your request; most likely this indicates an issue with your API Key. | `APIException` |
| 404 | The particular GIF you are requesting was not found. This occurs, for example, if you request a GIF by an id that does not exist. | `APIException` |
| 429 | Your API Key is making too many requests. Read about [requesting a Production Key](https://developers.giphy.com/docs/#access) to upgrade your API Key rate limits. | `APIException` |

