
# Start Session Response

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `State` | [`SessionState1Enum?`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

StartSessionResponse startSessionResponse = new StartSessionResponse
{
    SessionId = "SessionId4",
    State = SessionState1Enum.CREATING,
};
```

