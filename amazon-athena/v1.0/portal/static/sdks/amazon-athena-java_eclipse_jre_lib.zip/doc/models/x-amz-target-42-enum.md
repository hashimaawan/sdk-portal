
# X Amz Target 42 Enum

## Enumeration

`XAmzTarget42Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTSESSIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget42Enum;

XAmzTarget42Enum xAmzTarget42 = XAmzTarget42Enum.ENUM_AMAZONATHENALISTSESSIONS;
```

