
# Load Balancer Types Response

*This model accepts additional fields of type interface{}.*

## Structure

`LoadBalancerTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LoadBalancerTypes` | [`[]models.LoadBalancerType`](../../doc/models/load-balancer-type.md) | Required | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    loadBalancerTypesResponse := models.LoadBalancerTypesResponse{
        LoadBalancerTypes:     []models.LoadBalancerType{
            models.LoadBalancerType{
                Deprecated:              models.ToPointer("2016-01-30T23:50:00+00:00"),
                Description:             "LB11",
                Id:                      float64(1),
                MaxAssignedCertificates: float64(10),
                MaxConnections:          float64(20000),
                MaxServices:             float64(5),
                MaxTargets:              float64(25),
                Name:                    "lb11",
                Prices:                  []models.Price{
                    models.Price{
                        Location:              "fsn1",
                        PriceHourly:           models.PriceHourly{
                            Gross:                 "1.1900000000000000",
                            Net:                   "1.0000000000",
                            AdditionalProperties:  map[string]interface{}{
                                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                            },
                        },
                        PriceMonthly:          models.PriceMonthly{
                            Gross:                 "1.1900000000000000",
                            Net:                   "1.0000000000",
                            AdditionalProperties:  map[string]interface{}{
                                "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                            },
                        },
                        AdditionalProperties:  map[string]interface{}{
                            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                        },
                    },
                },
                AdditionalProperties:    map[string]interface{}{
                    "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
                },
            },
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

