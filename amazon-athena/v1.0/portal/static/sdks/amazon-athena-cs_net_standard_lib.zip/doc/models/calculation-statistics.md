
# Calculation Statistics

Contains statistics for a notebook calculation.

## Structure

`CalculationStatistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DpuExecutionInMillis` | `int?` | Optional | - |
| `Progress` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```csharp
using AmazonAthena.Standard.Models;

CalculationStatistics calculationStatistics = new CalculationStatistics
{
    DpuExecutionInMillis = 248,
    Progress = "Progress8",
};
```

