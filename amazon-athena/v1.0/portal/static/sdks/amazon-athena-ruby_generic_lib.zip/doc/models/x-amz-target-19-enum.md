
# X Amz Target 19 Enum

## Enumeration

`XAmzTarget19Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATABASE` |

## Example

```ruby
x_amz_target19 = XAmzTarget19Enum::ENUM_AMAZONATHENAGETDATABASE
```

