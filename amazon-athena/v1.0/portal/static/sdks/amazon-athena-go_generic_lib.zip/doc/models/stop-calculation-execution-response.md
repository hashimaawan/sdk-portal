
# Stop Calculation Execution Response

*This model accepts additional fields of type interface{}.*

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `State` | [`*models.CalculationExecutionState4`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    stopCalculationExecutionResponse := models.StopCalculationExecutionResponse{
        State:                 models.ToPointer(models.CalculationExecutionState4_Queued),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

