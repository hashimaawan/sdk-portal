# Server Types

```csharp
ServerTypesController serverTypesController = client.ServerTypesController;
```

## Class Name

`ServerTypesController`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```csharp
GetAllServerTypesAsync(
    string name = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

[`Task<Models.ServerTypesResponse>`](../../doc/models/server-types-response.md)

## Example Usage

```csharp
try
{
    ServerTypesResponse result = await serverTypesController.GetAllServerTypesAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a Server Type

Gets a specific Server type object.

```csharp
GetAServerTypeAsync(
    int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Server Type |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

[`Task<Models.ServerTypesResponse1>`](../../doc/models/server-types-response-1.md)

## Example Usage

```csharp
int id = 112;
try
{
    ServerTypesResponse1 result = await serverTypesController.GetAServerTypeAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

