
# Type 49 Enum

The type of the Primary IP

## Enumeration

`Type49Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```python
from hetznercloudapi.models.type_49_enum import Type49Enum

type_49 = Type49Enum.IPV4
```

