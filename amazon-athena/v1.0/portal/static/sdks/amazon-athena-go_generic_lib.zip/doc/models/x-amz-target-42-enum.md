
# X Amz Target 42 Enum

## Enumeration

`XAmzTarget42Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENALISTSESSIONS` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget42 := models.XAmzTarget42Enum_ENUMAMAZONATHENALISTSESSIONS

}
```

