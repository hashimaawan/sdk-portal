
# Servers Actions Enable Rescue Response

## Structure

`ServersActionsEnableRescueResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action`](../../doc/models/action.md) | Optional | - |
| `root_password` | `str` | Optional | Password that will be set for this Server once the Action succeeds |

## Example

```python
from hetznercloudapi.models.action import Action
from hetznercloudapi.models.error import Error
from hetznercloudapi.models.resource import Resource
from hetznercloudapi.models.servers_actions_enable_rescue_response import ServersActionsEnableRescueResponse
from hetznercloudapi.models.status_enum import StatusEnum

servers_actions_enable_rescue_response = ServersActionsEnableRescueResponse(
    action=Action(
        command='command6',
        error=Error(
            code='code2',
            message='message4'
        ),
        finished='finished0',
        id=238,
        progress=143.26,
        resources=[
            Resource(
                id=198,
                mtype='type0'
            ),
            Resource(
                id=198,
                mtype='type0'
            ),
            Resource(
                id=198,
                mtype='type0'
            )
        ],
        started='started8',
        status=StatusEnum.RUNNING
    ),
    root_password='zCWbFhnu950dUTko5f40'
)
```

