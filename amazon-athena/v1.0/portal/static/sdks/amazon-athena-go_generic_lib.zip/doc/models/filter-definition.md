
# Filter Definition

A string for searching notebook names.

## Structure

`FilterDefinition`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    filterDefinition := models.FilterDefinition{
        Name:                 models.ToPointer("Name2"),
    }

}
```

