
# Issuance

Status of the issuance process of the Certificate

## Enumeration

`Issuance`

## Fields

| Name |
|  --- |
| `PENDING` |
| `COMPLETED` |
| `FAILED` |

## Example

```ruby
issuance = Issuance::FAILED
```

