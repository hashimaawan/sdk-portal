
# Executors Summary

Contains summary information about an executor.

## Structure

`ExecutorsSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `executor_id` | `str` | Required | **Constraints**: *Maximum Length*: `100000`, *Pattern*: `.*` |
| `executor_type` | [`ExecutorType2Enum`](../../doc/models/executor-type-2-enum.md) | Optional | - |
| `start_date_time` | `int` | Optional | - |
| `termination_date_time` | `int` | Optional | - |
| `executor_state` | [`ExecutorState3Enum`](../../doc/models/executor-state-3-enum.md) | Optional | - |
| `executor_size` | `int` | Optional | - |

## Example

```python
from amazonathena.models.executor_state_3_enum import ExecutorState3Enum
from amazonathena.models.executor_type_2_enum import ExecutorType2Enum
from amazonathena.models.executors_summary import ExecutorsSummary

executors_summary = ExecutorsSummary(
    executor_id='ExecutorId2',
    executor_type=ExecutorType2Enum.GATEWAY,
    start_date_time=204,
    termination_date_time=160,
    executor_state=ExecutorState3Enum.CREATING,
    executor_size=118
)
```

