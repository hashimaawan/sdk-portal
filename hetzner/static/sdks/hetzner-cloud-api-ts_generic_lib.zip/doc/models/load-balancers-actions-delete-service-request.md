
# Load Balancers Actions Delete Service Request

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listenPort` | `number` | Required | The listen port of the service you want to delete |

## Example

```ts
import {
  LoadBalancersActionsDeleteServiceRequest,
} from 'hetzner-cloud-apilib';

const loadBalancersActionsDeleteServiceRequest: LoadBalancersActionsDeleteServiceRequest = {
  listenPort: 4711,
};
```

