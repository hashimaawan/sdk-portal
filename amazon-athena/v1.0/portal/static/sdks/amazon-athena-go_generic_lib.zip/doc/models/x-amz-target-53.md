
# X Amz Target 53

## Enumeration

`XAmzTarget53`

## Fields

| Name |
|  --- |
| `EnumAmazonathenauntagresource` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget53 := models.XAmzTarget53_EnumAmazonathenauntagresource

}
```

