
# Data Catalog

<p>Contains information about a data catalog in an Amazon Web Services account.</p> <note> <p>In the Athena console, data catalogs are listed as "data sources" on the <b>Data sources</b> page under the <b>Data source name</b> column.</p> </note>


## Structure

`DataCatalog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `type` | [`DataCatalogType1Enum`](../../doc/models/data-catalog-type-1-enum.md) | Required | - |
| `parameters` | [`Parameters \| undefined`](../../doc/models/parameters.md) | Optional | - |

## Example

```ts
import { DataCatalog, DataCatalogType1Enum } from 'amazon-athenalib';

const dataCatalog: DataCatalog = {
  name: 'Name6',
  type: DataCatalogType1Enum.GLUE,
  description: 'Description0',
  parameters: {},
};
```

