
# S3 Acl Option

## Enumeration

`S3AclOption`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```java
import com.amazonaws.useast1.athena.models.S3AclOption;

S3AclOption s3AclOption = S3AclOption.BUCKET_OWNER_FULL_CONTROL;
```

