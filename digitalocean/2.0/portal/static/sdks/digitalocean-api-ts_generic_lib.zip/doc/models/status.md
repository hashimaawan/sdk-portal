
# Status

This value is one of "active", "warning" or "locked".

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `Active` |
| `Warning` |
| `Locked` |

## Example

```ts
import { Status } from 'digitalocean-apilib';

const status = Status.Locked;
```

