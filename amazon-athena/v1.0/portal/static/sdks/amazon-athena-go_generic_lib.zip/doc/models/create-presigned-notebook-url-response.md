
# Create Presigned Notebook Url Response

## Structure

`CreatePresignedNotebookUrlResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NotebookUrl` | `string` | Required | - |
| `AuthToken` | `string` | Required | **Constraints**: *Maximum Length*: `2048` |
| `AuthTokenExpirationTime` | `int` | Required | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    createPresignedNotebookUrlResponse := models.CreatePresignedNotebookUrlResponse{
        NotebookUrl:             "NotebookUrl0",
        AuthToken:               "AuthToken4",
        AuthTokenExpirationTime: 240,
    }

}
```

