
# List Calculation Executions Response

## Structure

`ListCalculationExecutionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `*string` | Optional | **Constraints**: *Maximum Length*: `2048` |
| `Calculations` | [`[]models.CalculationSummary`](../../doc/models/calculation-summary.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` |

## Example

```go
package main

import (
    "log"
    "time"
    "amazonathena/models"
)

func main() {
    parseTime := func(layout, value string, errCallback func(error)) time.Time {
        dateTime, err := time.Parse(layout, value)
        if err != nil {
            errCallback(err) 
       }
        return dateTime
    }
    listCalculationExecutionsResponse := models.ListCalculationExecutionsResponse{
        NextToken:            models.ToPointer("NextToken8"),
        Calculations:         []models.CalculationSummary{
            models.CalculationSummary{
                CalculationExecutionId: models.ToPointer("CalculationExecutionId0"),
                Description:            models.ToPointer("Description2"),
                Status:                 models.ToPointer(models.Status1{
                    SubmissionDateTime:   models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
                    CompletionDateTime:   models.ToPointer(parseTime(time.RFC3339, "2016-03-13T12:52:32.123Z", func(err error) { log.Fatalln(err) })),
                    State:                models.ToPointer(models.CalculationExecutionState1Enum_CANCELING),
                    StateChangeReason:    models.ToPointer("StateChangeReason8"),
                }),
            },
        },
    }

}
```

