
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.Production`** |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| FurkotAuthAccessCodeCredentials | [`FurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |
| FurkotAuthImplicitCredentials | [`FurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

## Code-Based Initialization

```csharp
using FurkotTrips.Standard;
using FurkotTrips.Standard.Authentication;
using FurkotTrips.Standard.Models;
using System.Collections.Generic;

namespace ConsoleApp;

FurkotTripsClient client = new FurkotTripsClient.Builder()
    .FurkotAuthAccessCodeCredentials(
        new FurkotAuthAccessCodeModel.Builder(
            "OAuthClientId",
            "OAuthClientSecret",
            "OAuthRedirectUri"
        )
        .OAuthScopes(
            new List<OAuthScopeFurkotAuthAccessCodeEnum>
            {
                OAuthScopeFurkotAuthAccessCodeEnum.Readtrips,
            })
        .Build())
    .FurkotAuthImplicitCredentials(
        new FurkotAuthImplicitModel.Builder(
            "OAuthClientId",
            "OAuthRedirectUri"
        )
        .OAuthScopes(
            new List<OAuthScopeFurkotAuthImplicitEnum>
            {
                OAuthScopeFurkotAuthImplicitEnum.Readtrips,
            })
        .Build())
    .HttpClientConfig(httpClientConfig =>
        httpClientConfig.Timeout(TimeSpan.FromSeconds(100)))
    .Environment(FurkotTrips.Standard.Environment.Production)
    .Build();
```

## Configuration-Based Initialization

```csharp
using FurkotTrips.Standard;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp;

// Build the IConfiguration using .NET conventions (JSON, environment, etc.)
var configuration = new ConfigurationBuilder()
    .AddJsonFile("config.json")
    .AddEnvironmentVariables() // [optional] read environment variables
    .Build();

// Instantiate your SDK and configure it from IConfiguration
var client = FurkotTripsClient
    .FromConfiguration(configuration.GetSection("FurkotTrips"));
```

See the [Configuration-Based Initialization](../doc/configuration-based-initialization.md) section for details.

## Furkot TripsClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| APIController | Gets APIController controller. |
| OAuthAuthorizationController | Gets OAuthAuthorizationController controller. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| FurkotAuthAccessCodeCredentials | Gets the credentials to use with FurkotAuthAccessCode. | [`IFurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) |
| FurkotAuthImplicitCredentials | Gets the credentials to use with FurkotAuthImplicit. | [`IFurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the Furkot TripsClient using the values provided for the builder. | `Builder` |

## Furkot TripsClient Builder Class

Class to build instances of Furkot TripsClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `FurkotAuthAccessCodeCredentials(Action<FurkotAuthAccessCodeModel.Builder> action)` | Sets credentials for FurkotAuthAccessCode. | `Builder` |
| `FurkotAuthImplicitCredentials(Action<FurkotAuthImplicitModel.Builder> action)` | Sets credentials for FurkotAuthImplicit. | `Builder` |

