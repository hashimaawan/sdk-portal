
# Query Execution 1

*This model accepts additional fields of type unknown.*

## Structure

`QueryExecution1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `query` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `statementType` | [`StatementType1 \| undefined`](../../doc/models/statement-type-1.md) | Optional | - |
| `resultConfiguration` | [`ResultConfiguration1 \| undefined`](../../doc/models/result-configuration-1.md) | Optional | - |
| `resultReuseConfiguration` | [`ResultReuseConfiguration1 \| undefined`](../../doc/models/result-reuse-configuration-1.md) | Optional | - |
| `queryExecutionContext` | [`QueryExecutionContext1 \| undefined`](../../doc/models/query-execution-context-1.md) | Optional | - |
| `status` | [`Status \| undefined`](../../doc/models/status.md) | Optional | - |
| `statistics` | [`Statistics \| undefined`](../../doc/models/statistics.md) | Optional | - |
| `workGroup` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `engineVersion` | [`EngineVersion1 \| undefined`](../../doc/models/engine-version-1.md) | Optional | - |
| `executionParameters` | `string[] \| undefined` | Optional | **Constraints**: *Minimum Items*: `1`, *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `substatementType` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  EncryptionOption1,
  QueryExecution1,
  S3AclOption1,
  StatementType1,
} from 'amazon-athenalib';

const queryExecution1: QueryExecution1 = {
  queryExecutionId: 'QueryExecutionId6',
  query: 'Query0',
  statementType: StatementType1.Utility,
  resultConfiguration: {
    outputLocation: 'OutputLocation0',
    encryptionConfiguration: {
      encryptionOption: EncryptionOption1.SseS3,
      kmsKey: 'KmsKey6',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    expectedBucketOwner: 'ExpectedBucketOwner0',
    aclConfiguration: {
      s3AclOption: S3AclOption1.BucketOwnerFullControl,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  resultReuseConfiguration: {
    resultReuseByAgeConfiguration: {
      enabled: false,
      maxAgeInMinutes: 26,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

