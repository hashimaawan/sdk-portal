
# V2 Images Actions Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2ImagesActionsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type15)`](../../doc/models/type-15.md) | Required | The action to be taken on the image. Can be either `convert` or `transfer`. | getType(): string | setType(string type): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2ImagesActionsRequestBuilder;
use DigitalOceanApiLib\Models\Type15;
use DigitalOceanApiLib\ApiHelper;

$v2ImagesActionsRequest = V2ImagesActionsRequestBuilder::init(
    Type15::CONVERT
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

