
# Update Server Request

## Structure

`UpdateServerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New name to set |

## Example

```ruby
update_server_request = UpdateServerRequest.new(
  { 'labelkey' => 'value' },
  'my-server'
)
```

