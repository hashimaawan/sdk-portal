
# X Amz Target 30

## Enumeration

`XAmzTarget30`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaImportNotebook` |

## Example

```ts
import { XAmzTarget30 } from 'amazon-athenalib';

const xAmzTarget30 = XAmzTarget30.EnumAmazonAthenaImportNotebook;
```

