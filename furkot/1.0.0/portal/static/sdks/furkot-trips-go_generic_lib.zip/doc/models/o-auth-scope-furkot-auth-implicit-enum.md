
# O Auth Scope Furkot Auth Implicit Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthImplicitEnum`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list users trips info |

## Example

```go
package main

import (
    "furkottrips/models"
)

func main() {
    oAuthScopeFurkotAuthImplicit := models.OAuthScopeFurkotAuthImplicitEnum_READTRIPS

}
```

