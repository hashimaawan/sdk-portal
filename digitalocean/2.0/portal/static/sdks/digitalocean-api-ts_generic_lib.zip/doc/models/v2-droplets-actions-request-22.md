
# V2 Droplets Actions Request 22

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest22`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type12`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. |
| `image` | [`V2DropletsActionsRequest22Image \| undefined`](../../doc/models/containers/v2-droplets-actions-request-22-image.md) | Optional | This is a container for one-of cases. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Type12, V2DropletsActionsRequest22 } from 'digitalocean-apilib';

const v2DropletsActionsRequest22: V2DropletsActionsRequest22 = {
  type: Type12.Reboot,
  image: 'ubuntu-20-04-x64',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

