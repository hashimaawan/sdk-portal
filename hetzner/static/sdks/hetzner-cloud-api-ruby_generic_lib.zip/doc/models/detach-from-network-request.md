
# Detach from Network Request

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `Integer` | Required | ID of an existing network to detach the Server from |

## Example

```ruby
detach_from_network_request = DetachFromNetworkRequest.new(
  4711
)
```

