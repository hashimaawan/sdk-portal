
# State 1

A string indicating the current status of the node.

## Enumeration

`State1`

## Fields

| Name |
|  --- |
| `PROVISIONING` |
| `RUNNING` |
| `DRAINING` |
| `DELETING` |

## Example

```python
from digitaloceanapi.models.state_1 import State1

state_1 = State1.PROVISIONING
```

