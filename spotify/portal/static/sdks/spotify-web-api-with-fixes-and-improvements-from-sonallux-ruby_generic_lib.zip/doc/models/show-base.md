
# Show Base

*This model accepts additional fields of type Object.*

## Structure

`ShowBase`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `available_markets` | `Array[String]` | Required | A list of the countries in which the show can be played, identified by their [ISO 3166-1 alpha-2](http://en.wikipedia.org/wiki/ISO_3166-1_alpha-2) code. |
| `copyrights` | [`Array[CopyrightObject]`](../../doc/models/copyright-object.md) | Required | The copyright statements of the show. |
| `description` | `String` | Required | A description of the show. HTML tags are stripped away from this field, use `html_description` field in case HTML tags are needed. |
| `html_description` | `String` | Required | A description of the show. This field may contain HTML tags. |
| `explicit` | `TrueClass \| FalseClass` | Required | Whether or not the show has explicit content (true = yes it does; false = no it does not OR unknown). |
| `external_urls` | [`ExternalUrlObject`](../../doc/models/external-url-object.md) | Required | External URLs for this show. |
| `href` | `String` | Required | A link to the Web API endpoint providing full details of the show. |
| `id` | `String` | Required | The [Spotify ID](/documentation/web-api/concepts/spotify-uris-ids) for the show. |
| `images` | [`Array[ImageObject]`](../../doc/models/image-object.md) | Required | The cover art for the show in various sizes, widest first. |
| `is_externally_hosted` | `TrueClass \| FalseClass` | Required | True if all of the shows episodes are hosted outside of Spotify's CDN. This field might be `null` in some cases. |
| `languages` | `Array[String]` | Required | A list of the languages used in the show, identified by their [ISO 639](https://en.wikipedia.org/wiki/ISO_639) code. |
| `media_type` | `String` | Required | The media type of the show. |
| `name` | `String` | Required | The name of the episode. |
| `publisher` | `String` | Required | The publisher of the show. |
| `type` | `String` | Required, Constant | The object type.<br><br>**Value**: `'show'` |
| `uri` | `String` | Required | The [Spotify URI](/documentation/web-api/concepts/spotify-uris-ids) for the show. |
| `total_episodes` | `Integer` | Required | The total number of episodes in the show. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
show_base = ShowBase.new(
  available_markets: [
    'available_markets0',
    'available_markets1',
    'available_markets2'
  ],
  copyrights: [
    CopyrightObject.new(
      text: 'text2',
      type: 'type2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  description: 'description6',
  html_description: 'html_description6',
  explicit: false,
  external_urls: ExternalUrlObject.new(
    spotify: 'spotify6',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  href: 'href8',
  id: 'id6',
  images: [
    ImageObject.new(
      url: 'https://i.scdn.co/image/ab67616d00001e02ff9ca10b55ce82ae553c8228\n',
      height: 300,
      width: 300,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  is_externally_hosted: false,
  languages: [
    'languages3',
    'languages4',
    'languages5'
  ],
  media_type: 'media_type4',
  name: 'name6',
  publisher: 'publisher4',
  type: 'show',
  uri: 'uri0',
  total_episodes: 6,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

