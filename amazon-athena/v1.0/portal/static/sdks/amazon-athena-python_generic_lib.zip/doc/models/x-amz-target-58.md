
# X Amz Target 58

## Enumeration

`XAmzTarget58`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_58 import XAmzTarget58

x_amz_target_58 = XAmzTarget58.ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT
```

