
# Primary Ip

## Structure

`PrimaryIp`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Prices` | [`List<Price8>`](../../doc/models/price-8.md) | Required | Primary IP type costs per Location | List<Price8> getPrices() | setPrices(List<Price8> prices) |
| `Type` | [`Type49Enum`](../../doc/models/type-49-enum.md) | Required | The type of the Primary IP | Type49Enum getType() | setType(Type49Enum type) |

## Example

```java
import cloud.hetzner.api.models.Price8;
import cloud.hetzner.api.models.PriceHourly7;
import cloud.hetzner.api.models.PriceMonthly9;
import cloud.hetzner.api.models.PrimaryIp;
import cloud.hetzner.api.models.Type49Enum;
import java.util.Arrays;

PrimaryIp primaryIp = new PrimaryIp.Builder(
    Arrays.asList(
        new Price8.Builder(
            "fsn1",
            new PriceHourly7.Builder(
                "1.1900000000000000",
                "1.0000000000"
            )
            .build(),
            new PriceMonthly9.Builder(
                "1.1900000000000000",
                "1.0000000000"
            )
            .build()
        )
        .build()
    ),
    Type49Enum.IPV4
)
.build();
```

