
# Get Database Input

## Structure

`GetDatabaseInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `catalogName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `databaseName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```ts
import { GetDatabaseInput } from 'amazon-athenalib';

const getDatabaseInput: GetDatabaseInput = {
  catalogName: 'CatalogName2',
  databaseName: 'DatabaseName2',
};
```

