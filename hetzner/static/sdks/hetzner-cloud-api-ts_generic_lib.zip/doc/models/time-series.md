
# Time Series

## Structure

`TimeSeries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `values` | [`TimeSeriesValues[]`](../../doc/models/containers/time-series-values.md) | Required | This is 2d Array of a container for one-of cases. |

## Example

```ts
import { TimeSeries } from 'hetzner-cloud-apilib';

const timeSeries: TimeSeries = {
  values: [
    null,
    null
  ],
};
```

