
# Get Data Catalog Input

## Structure

`GetDataCatalogInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getName(): string | setName(string name): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetDataCatalogInputBuilder;

$getDataCatalogInput = GetDataCatalogInputBuilder::init(
    'Name6'
)->build();
```

