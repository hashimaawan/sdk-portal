
# Executor Type Enum

## Enumeration

`ExecutorTypeEnum`

## Fields

| Name |
|  --- |
| `COORDINATOR` |
| `GATEWAY` |
| `WORKER` |

## Example

```ruby
executor_type = ExecutorTypeEnum::WORKER
```

