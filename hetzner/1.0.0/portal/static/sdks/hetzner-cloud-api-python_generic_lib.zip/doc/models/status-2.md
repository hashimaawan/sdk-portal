
# Status 2

Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates

*This model accepts additional fields of type Any.*

## Structure

`Status2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`Error2`](../../doc/models/error-2.md) | Optional | If issuance or renewal reports `failed`, this property contains information about what happened |
| `issuance` | [`Issuance`](../../doc/models/issuance.md) | Optional | Status of the issuance process of the Certificate |
| `renewal` | [`Renewal`](../../doc/models/renewal.md) | Optional | Status of the renewal process of the Certificate. |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.issuance import Issuance
from hetznercloudapi.models.renewal import Renewal
from hetznercloudapi.models.status_2 import Status2

status_2 = Status2(
    error=None,
    issuance=Issuance.PENDING,
    renewal=Renewal.SCHEDULED,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

