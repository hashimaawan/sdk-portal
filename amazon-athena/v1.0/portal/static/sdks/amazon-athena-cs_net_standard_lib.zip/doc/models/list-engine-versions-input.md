
# List Engine Versions Input

## Structure

`ListEngineVersionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 10` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ListEngineVersionsInput listEngineVersionsInput = new ListEngineVersionsInput
{
    NextToken = "NextToken6",
    MaxResults = 10,
};
```

