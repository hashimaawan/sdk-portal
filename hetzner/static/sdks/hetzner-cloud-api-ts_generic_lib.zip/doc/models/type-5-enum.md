
# Type 5 Enum

Type of resource referenced

## Enumeration

`Type5Enum`

## Fields

| Name |
|  --- |
| `Server` |

## Example

```ts
import { Type5Enum } from 'hetzner-cloud-apilib';

const type5 = Type5Enum.Server;
```

