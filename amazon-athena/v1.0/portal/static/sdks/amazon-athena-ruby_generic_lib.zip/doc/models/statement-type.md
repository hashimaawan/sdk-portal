
# Statement Type

## Enumeration

`StatementType`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```ruby
statement_type = StatementType::DDL
```

