
# X Amz Target 1 Enum

## Enumeration

`XAmzTarget1Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target1 = XAmzTarget1Enum::ENUM_AMAZONATHENABATCHGETPREPAREDSTATEMENT
```

