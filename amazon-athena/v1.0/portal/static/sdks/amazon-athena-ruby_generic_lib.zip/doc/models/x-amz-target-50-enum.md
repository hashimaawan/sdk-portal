
# X Amz Target 50 Enum

## Enumeration

`XAmzTarget50Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPQUERYEXECUTION` |

## Example

```ruby
x_amz_target50 = XAmzTarget50Enum::ENUM_AMAZONATHENASTOPQUERYEXECUTION
```

