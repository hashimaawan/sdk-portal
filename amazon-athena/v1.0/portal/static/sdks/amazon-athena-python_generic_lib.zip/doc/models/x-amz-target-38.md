
# X Amz Target 38

## Enumeration

`XAmzTarget38`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTNOTEBOOKMETADATA` |

## Example

```python
from amazonathena.models.x_amz_target_38 import XAmzTarget38

x_amz_target_38 = XAmzTarget38.ENUM_AMAZONATHENALISTNOTEBOOKMETADATA
```

