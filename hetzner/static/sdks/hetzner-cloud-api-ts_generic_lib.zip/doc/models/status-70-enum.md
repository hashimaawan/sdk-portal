
# Status 70 Enum

## Enumeration

`Status70Enum`

## Fields

| Name |
|  --- |
| `Initializing` |
| `Starting` |
| `Running` |
| `Stopping` |
| `Off` |
| `Deleting` |
| `Rebuilding` |
| `Migrating` |
| `Unknown` |

## Example

```ts
import { Status70Enum } from 'hetzner-cloud-apilib';

const status70 = Status70Enum.Migrating;
```

