
# Start Query Execution Output

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```python
from amazonathena.models.start_query_execution_output import StartQueryExecutionOutput

start_query_execution_output = StartQueryExecutionOutput(
    query_execution_id='QueryExecutionId8'
)
```

