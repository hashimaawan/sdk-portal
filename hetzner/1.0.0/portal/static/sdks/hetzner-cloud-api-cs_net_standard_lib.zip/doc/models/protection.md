
# Protection

Protection configuration for the Resource

## Structure

`Protection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool` | Required | If true, prevents the Resource from being deleted |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Protection protection = new Protection
{
    Delete = false,
};
```

