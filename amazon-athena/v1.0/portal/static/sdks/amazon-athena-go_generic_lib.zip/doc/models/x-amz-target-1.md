
# X Amz Target 1

## Enumeration

`XAmzTarget1`

## Fields

| Name |
|  --- |
| `EnumAmazonathenabatchgetpreparedstatement` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget1 := models.XAmzTarget1_EnumAmazonathenabatchgetpreparedstatement

}
```

