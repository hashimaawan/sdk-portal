
# Type 1 Enum

Choose between uploading a Certificate in PEM format or requesting a managed *Let's Encrypt* Certificate. If omitted defaults to `uploaded`.

## Enumeration

`Type1Enum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```java
import cloud.hetzner.api.models.Type1Enum;

Type1Enum type1 = Type1Enum.UPLOADED;
```

