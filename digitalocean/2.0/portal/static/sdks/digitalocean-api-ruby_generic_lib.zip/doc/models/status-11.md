
# Status 11

An object containing a `state` attribute whose value is set to a string indicating the current status of the cluster.

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Status11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | An optional message providing additional information about the current cluster state. |
| `state` | [`State2`](../../doc/models/state-2.md) | Optional | A string indicating the current status of the cluster. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
status11 = Status11.new(
  message: 'provisioning',
  state: State2::PROVISIONING,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

