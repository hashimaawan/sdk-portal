
# Section 1

For files that are in a section, this field describes the section.

*This model accepts additional fields of type Object.*

## Structure

`Section1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | - | String getId() | setId(String id) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import java.io.IOException;
import local.m1password.ApiHelper;
import local.m1password.models.Section1;

Section1 section1 = new Section1.Builder()
    .id("id2")
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

