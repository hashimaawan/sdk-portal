
# X Amz Target 58

## Enumeration

`XAmzTarget58`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget58;

XAmzTarget58 xAmzTarget58 = XAmzTarget58.ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT;
```

