
# Status 73 Enum

Status of the Server

## Enumeration

`Status73Enum`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `INITIALIZING` |
| `STARTING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `MIGRATING` |
| `REBUILDING` |
| `UNKNOWN` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    status73 := models.Status73Enum_STARTING

}
```

