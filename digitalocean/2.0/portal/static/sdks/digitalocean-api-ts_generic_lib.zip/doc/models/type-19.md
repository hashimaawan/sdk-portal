
# Type 19

The type of health check to perform.

## Enumeration

`Type19`

## Fields

| Name |
|  --- |
| `Ping` |
| `Http` |
| `Https` |

## Example

```ts
import { Type19 } from 'digitalocean-apilib';

const type19 = Type19.Http;
```

