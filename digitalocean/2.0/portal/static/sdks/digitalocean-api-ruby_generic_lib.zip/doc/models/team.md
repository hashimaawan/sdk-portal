
# Team

When authorized in a team context, includes information about the current team.

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Team`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | The name for the current team. |
| `uuid` | `String` | Optional | The unique universal identifier for the current team. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
team = Team.new(
  name: 'My Team',
  uuid: '5df3e3004a17e242b7c20ca6c9fc25b701a47ece',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

