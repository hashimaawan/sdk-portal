
# Change Protection Request 1

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Delete` | `bool?` | Optional | If true, prevents the Network from being deleted |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

ChangeProtectionRequest1 changeProtectionRequest1 = new ChangeProtectionRequest1
{
    Delete = true,
};
```

