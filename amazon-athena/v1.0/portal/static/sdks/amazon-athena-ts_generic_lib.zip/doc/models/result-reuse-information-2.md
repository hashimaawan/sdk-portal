
# Result Reuse Information 2

*This model accepts additional fields of type unknown.*

## Structure

`ResultReuseInformation2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reusedPreviousResult` | `boolean` | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ResultReuseInformation2 } from 'amazon-athenalib';

const resultReuseInformation2: ResultReuseInformation2 = {
  reusedPreviousResult: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

