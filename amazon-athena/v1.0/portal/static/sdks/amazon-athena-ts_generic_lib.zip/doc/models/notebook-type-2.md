
# Notebook Type 2

The notebook content type. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType2`

## Fields

| Name |
|  --- |
| `Ipynb` |

## Example

```ts
import { NotebookType2 } from 'amazon-athenalib';

const notebookType2 = NotebookType2.Ipynb;
```

