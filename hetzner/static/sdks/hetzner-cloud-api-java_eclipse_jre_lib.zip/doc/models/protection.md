
# Protection

Protection configuration for the Resource

## Structure

`Protection`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Delete` | `boolean` | Required | If true, prevents the Resource from being deleted | boolean getDelete() | setDelete(boolean delete) |

## Example

```java
import cloud.hetzner.api.models.Protection;

Protection protection = new Protection.Builder(
    false
)
.build();
```

