
# List Executors Request

## Structure

`ListExecutorsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `ExecutorStateFilter` | [`*models.ExecutorState1Enum`](../../doc/models/executor-state-1-enum.md) | Optional | - |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `*string` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listExecutorsRequest := models.ListExecutorsRequest{
        SessionId:            "SessionId0",
        ExecutorStateFilter:  models.ToPointer(models.ExecutorState1Enum_CREATING),
        MaxResults:           models.ToPointer(100),
        NextToken:            models.ToPointer("NextToken8"),
    }

}
```

