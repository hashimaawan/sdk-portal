
# Type 21 Enum

## Enumeration

`Type21Enum`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `SNAPSHOT` |
| `BACKUP` |
| `APP` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type21 := models.Type21Enum_BACKUP

}
```

