
# Label Selector 5

Configuration for type label_selector, required if type is `label_selector`

*This model accepts additional fields of type interface{}.*

## Structure

`LabelSelector5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Selector` | `string` | Required | Label selector |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    labelSelector5 := models.LabelSelector5{
        Selector:              "env=prod",
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

