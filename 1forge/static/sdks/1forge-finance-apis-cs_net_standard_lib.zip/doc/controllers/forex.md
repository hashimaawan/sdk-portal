# Forex

```csharp
ForexController forexController = client.ForexController;
```

## Class Name

`ForexController`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```csharp
GetQuotesForAllSymbolsAsync()
```

## Response Type

**200**: A list of quotes

`Task`

## Example Usage

```csharp
try
{
    await forexController.GetQuotesForAllSymbolsAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```csharp
GetAListOfSymbolsForWhichWeProvideRealTimeQuotesAsync()
```

## Response Type

**200**: A list of symbols

`Task<List<string>>`

## Example Usage

```csharp
try
{
    List<string> result = await forexController.GetAListOfSymbolsForWhichWeProvideRealTimeQuotesAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

