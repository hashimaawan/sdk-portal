
# V2 Cdn Endpoints Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `endpoints` | [`Array[Endpoint]`](../../doc/models/endpoint.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_cdn_endpoints_response = V2CdnEndpointsResponse.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  endpoints: [
    Endpoint.new(
      origin: 'static-images.nyc3.digitaloceanspaces.com',
      certificate_id: '892071a0-bb95-49bc-8021-3afd67a210bf',
      created_at: DateTimeHelper.from_rfc3339('2018-07-19T15:04:16Z'),
      custom_domain: 'static.example.com',
      endpoint: 'static-images.nyc3.cdn.digitaloceanspaces.com',
      id: '19f06b6a-3ace-4315-b086-499a0e521b76',
      ttl: Ttl::ENUM_3600,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

