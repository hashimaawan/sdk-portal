
# Start Query Execution Output

## Structure

`StartQueryExecutionOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ruby
start_query_execution_output = StartQueryExecutionOutput.new(
  'QueryExecutionId8'
)
```

