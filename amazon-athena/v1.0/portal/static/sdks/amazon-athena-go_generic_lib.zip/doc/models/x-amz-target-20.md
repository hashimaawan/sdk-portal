
# X Amz Target 20

## Enumeration

`XAmzTarget20`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetnamedquery` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget20 := models.XAmzTarget20_EnumAmazonathenagetnamedquery

}
```

