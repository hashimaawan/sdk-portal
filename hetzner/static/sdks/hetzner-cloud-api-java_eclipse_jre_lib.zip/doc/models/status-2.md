
# Status 2

Current status of a type `managed` Certificate, always *null* for type `uploaded` Certificates

## Structure

`Status2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | [`Error2`](../../doc/models/error-2.md) | Optional | If issuance or renewal reports `failed`, this property contains information about what happened | Error2 getError() | setError(Error2 error) |
| `Issuance` | [`IssuanceEnum`](../../doc/models/issuance-enum.md) | Optional | Status of the issuance process of the Certificate | IssuanceEnum getIssuance() | setIssuance(IssuanceEnum issuance) |
| `Renewal` | [`RenewalEnum`](../../doc/models/renewal-enum.md) | Optional | Status of the renewal process of the Certificate. | RenewalEnum getRenewal() | setRenewal(RenewalEnum renewal) |

## Example

```java
import cloud.hetzner.api.models.IssuanceEnum;
import cloud.hetzner.api.models.RenewalEnum;
import cloud.hetzner.api.models.Status2;

Status2 status2 = new Status2.Builder()
    .error(null)
    .issuance(IssuanceEnum.COMPLETED)
    .renewal(RenewalEnum.SCHEDULED)
    .build();
```

