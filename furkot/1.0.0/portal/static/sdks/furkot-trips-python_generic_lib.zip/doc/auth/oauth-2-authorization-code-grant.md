
# OAuth 2 Authorization Code Grant



Documentation for accessing and setting credentials for furkot_auth_access_code.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| OAuthClientId | `str` | OAuth 2 Client ID | `oauth_client_id` |
| OAuthClientSecret | `str` | OAuth 2 Client Secret | `oauth_client_secret` |
| OAuthRedirectUri | `str` | OAuth 2 Redirection endpoint or Callback Uri | `oauth_redirect_uri` |
| OAuthToken | `OauthToken` | Object for storing information about the OAuth token | `oauth_token` |
| OAuthScopes | `List[OauthScopeFurkotAuthAccessCode]` | List of scopes that apply to the OAuth token | `oauth_scopes` |



**Note:** Auth credentials can be set using `FurkotAuthAccessCodeCredentials` object, passed in as named parameter `furkot_auth_access_code_credentials` in the client initialization.

## Usage Example

### 1\. Client Initialization

You must initialize the client with *OAuth 2.0 Authorization Code Grant* credentials as shown in the following code snippet.

```python
from furkottrips.furkottrips_client import FurkottripsClient
from furkottrips.http.auth.furkot_auth_access_code import FurkotAuthAccessCodeCredentials
from furkottrips.models.oauth_scope_furkot_auth_access_code import OauthScopeFurkotAuthAccessCode

client = FurkottripsClient(
    furkot_auth_access_code_credentials=FurkotAuthAccessCodeCredentials(
        oauth_client_id='OAuthClientId',
        oauth_client_secret='OAuthClientSecret',
        oauth_redirect_uri='OAuthRedirectUri',
        oauth_scopes=[
            OauthScopeFurkotAuthAccessCode.READTRIPS
        ]
    )
)
```



Your application must obtain user authorization before it can execute an endpoint call in case this SDK chooses to use *OAuth 2.0 Authorization Code Grant*. This authorization includes the following steps

### 2\. Obtain user consent

To obtain user's consent, you must redirect the user to the authorization page.The `get_authorization_url()` method creates the URL to the authorization page. You must have initialized the client with scopes for which you need permission to access.

```python
auth_url = client.furkot_auth_access_code.get_authorization_url()
```

### 3\. Handle the OAuth server response

Once the user responds to the consent request, the OAuth 2.0 server responds to your application's access request by redirecting the user to the redirect URI specified set in `Configuration`.

If the user approves the request, the authorization code will be sent as the `code` query string:

```
https://example.com/oauth/callback?code=XXXXXXXXXXXXXXXXXXXXXXXXX
```

If the user does not approve the request, the response contains an `error` query string:

```
https://example.com/oauth/callback?error=access_denied
```

### 4\. Authorize the client using the code

After the server receives the code, it can exchange this for an *access token*. The access token is an object containing information for authorizing client requests and refreshing the token itself.

```python
try:
    token = client.furkot_auth_access_code.fetch_token('code')
    furkot_auth_access_code_credentials = client.config.furkot_auth_access_code_credentials.clone_with(oauth_token=token)
    config = client.config.clone_with(furkot_auth_access_code_credentials=furkot_auth_access_code_credentials)
    client = FurkottripsClient(config=config)
except OauthProviderException as ex:
    # handle exception
    pass
except ApiException as ex:
    # handle exception
    pass
```

### Scopes

Scopes enable your application to only request access to the resources it needs while enabling users to control the amount of access they grant to your application. Available scopes are defined in the [`OauthScopeFurkotAuthAccessCode`](../../doc/models/oauth-scope-furkot-auth-access-code.md) enumeration.

| Scope Name | Description |
|  --- | --- |
| `READTRIPS` | list trips and stops info |

### Refreshing the token

An access token may expire after sometime. To extend its lifetime, you must refresh the token.

```python
if client.furkot_auth_access_code.is_token_expired():
    try:
        token = client.furkot_auth_access_code.refresh_token()
        furkot_auth_access_code_credentials = client.config.furkot_auth_access_code_credentials.clone_with(oauth_token=token)
        config = client.config.clone_with(furkot_auth_access_code_credentials=furkot_auth_access_code_credentials)
        client = FurkottripsClient(config=config)
    except OauthProviderException as ex:
       # handle exception
       pass
```

If a token expires, an exception will be thrown before the next endpoint call requiring authentication.

### Storing an access token for reuse

It is recommended that you store the access token for reuse.

```python
# store token
save_token_to_database(client.config.furkot_auth_access_code_credentials.oauth_token)
```

### Creating a client from a stored token

To authorize a client using a stored access token, just set the access token in Configuration along with the other configuration parameters before creating the client:

```python
client = FurkottripsClient(
    furkot_auth_access_code_credentials=FurkotAuthAccessCodeCredentials(
        oauth_token=load_token_from_database()
    )
)
```

### Complete example



```python
from furkottrips.furkottrips_client import FurkottripsClient
from furkottrips.http.auth.furkot_auth_access_code import FurkotAuthAccessCodeCredentials
from furkottrips.models.oauth_scope_furkot_auth_access_code import OauthScopeFurkotAuthAccessCode
from furkottrips.exceptions.oauth_provider_exception import OauthProviderException

client = FurkottripsClient(
    furkot_auth_access_code_credentials=FurkotAuthAccessCodeCredentials(
        oauth_client_id='OAuthClientId',
        oauth_client_secret='OAuthClientSecret',
        oauth_redirect_uri='OAuthRedirectUri',
        oauth_scopes=[
            OauthScopeFurkotAuthAccessCode.READTRIPS
        ]
    )
)
# function for storing token to database
def save_token_to_database(token):
    # code to save the token to database
    pass

# function for loading token from database
def load_token_from_database():
    # load token from database and return it (return None if no token exists)
    pass

# obtain access token, needed for client to be authorized
previous_token = load_token_from_database()
if previous_token:
    # restore previous access token
    furkot_auth_access_code_credentials = client.config.furkot_auth_access_code_credentials.clone_with(oauth_token=previous_token)
    config = client.config.clone_with(furkot_auth_access_code_credentials=furkot_auth_access_code_credentials)
    client = FurkottripsClient(config=config)
else:
    # redirect user to a page that handles authorization
    pass

# the client is now authorized and you can use controllers to make endpoint calls
```


