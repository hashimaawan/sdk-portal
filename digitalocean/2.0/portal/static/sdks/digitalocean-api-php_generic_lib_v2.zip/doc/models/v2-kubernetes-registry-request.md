
# V2 Kubernetes Registry Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2KubernetesRegistryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clusterUuids` | `?(string[])` | Optional | An array containing the UUIDs of Kubernetes clusters. | getClusterUuids(): ?array | setClusterUuids(?array clusterUuids): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2KubernetesRegistryRequestBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2KubernetesRegistryRequest = V2KubernetesRegistryRequestBuilder::init()
    ->clusterUuids(
        [
            'bd5f5959-5e1e-4205-a714-a914373942af',
            '50c2f44c-011d-493e-aee5-361a4a0d1844'
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

