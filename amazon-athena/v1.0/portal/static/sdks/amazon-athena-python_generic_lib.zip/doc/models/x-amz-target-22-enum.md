
# X Amz Target 22 Enum

## Enumeration

`XAmzTarget22Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_22_enum import XAmzTarget22Enum

x_amz_target_22 = XAmzTarget22Enum.ENUM_AMAZONATHENAGETPREPAREDSTATEMENT
```

