
# Server 16

Configuration for type Server, required if type is `server`

## Structure

`Server16`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `double` | Required | ID of the Server | double getId() | setId(double id) |

## Example

```java
import cloud.hetzner.api.models.Server16;

Server16 server16 = new Server16.Builder(
    80D
)
.build();
```

