
# X Amz Target 36 Enum

## Enumeration

`XAmzTarget36Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTEXECUTORS` |

## Example

```ruby
x_amz_target36 = XAmzTarget36Enum::ENUM_AMAZONATHENALISTEXECUTORS
```

