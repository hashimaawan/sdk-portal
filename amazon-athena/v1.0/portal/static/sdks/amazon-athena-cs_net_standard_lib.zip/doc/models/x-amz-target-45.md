
# X Amz Target 45

## Enumeration

`XAmzTarget45`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListWorkGroups` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget45 xAmzTarget45 = XAmzTarget45.EnumAmazonAthenaListWorkGroups;
```

