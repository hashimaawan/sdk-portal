
# Direction Enum

Select traffic direction on which rule should be applied. Use `source_ips` for direction `in` and `destination_ips` for direction `out`.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `IN` |
| `OUT` |

## Example

```php
use HetznerCloudAPILib\Models\DirectionEnum;

$direction = DirectionEnum::IN;
```

