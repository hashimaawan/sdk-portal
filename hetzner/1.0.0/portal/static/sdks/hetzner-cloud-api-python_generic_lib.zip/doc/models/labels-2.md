
# Labels 2

User-defined labels (key-value pairs)

*This model accepts additional fields of type Any.*

## Structure

`Labels2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labelkey` | `str` | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.labels_2 import Labels2

labels_2 = Labels2(
    labelkey='value',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

