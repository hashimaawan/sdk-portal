
# Load Balancer Target Server

Server where the traffic should be routed through

*This model accepts additional fields of type Object.*

## Structure

`LoadBalancerTargetServer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server | int getId() | setId(int id) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import cloud.hetzner.api.ApiHelper;
import cloud.hetzner.api.models.LoadBalancerTargetServer;
import java.io.IOException;

LoadBalancerTargetServer loadBalancerTargetServer = new LoadBalancerTargetServer.Builder(
    80
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

