
# Server

## Structure

`Server`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Resource |

## Example

```ts
import { Server } from 'hetzner-cloud-apilib';

const server: Server = {
  id: 42,
};
```

