# Image Actions

```csharp
ImageActionsController imageActionsController = client.ImageActionsController;
```

## Class Name

`ImageActionsController`

## Methods

* [Get All Actions for an Image](../../doc/controllers/image-actions.md#get-all-actions-for-an-image)
* [Change Image Protection](../../doc/controllers/image-actions.md#change-image-protection)
* [Get an Action for an Image](../../doc/controllers/image-actions.md#get-an-action-for-an-image)


# Get All Actions for an Image

Returns all Action objects for an Image. You can sort the results by using the `sort` URI parameter, and filter them with the `status` parameter.

```csharp
GetAllActionsForAnImageAsync(
    int id,
    Models.ParameterSortEnum? sort = null,
    Models.ParameterStatusEnum? status = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `sort` | [`ParameterSortEnum?`](../../doc/models/parameter-sort-enum.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatusEnum?`](../../doc/models/parameter-status-enum.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

[`Task<Models.ActionsResponse>`](../../doc/models/actions-response.md)

## Example Usage

```csharp
int id = 112;
try
{
    ActionsResponse result = await imageActionsController.GetAllActionsForAnImageAsync(id);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "actions": [
    {
      "command": "change_protection",
      "error": {
        "code": "action_failed",
        "message": "Action failed"
      },
      "finished": "2016-01-30T23:56:00+00:00",
      "id": 13,
      "progress": 100,
      "resources": [
        {
          "id": 4711,
          "type": "image"
        }
      ],
      "started": "2016-01-30T23:55:00+00:00",
      "status": "success"
    }
  ]
}
```


# Change Image Protection

Changes the protection configuration of the Image. Can only be used on snapshots.

```csharp
ChangeImageProtectionAsync(
    int id,
    Models.ImagesActionsChangeProtectionRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `body` | [`ImagesActionsChangeProtectionRequest`](../../doc/models/images-actions-change-protection-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`Task<Models.ActionResponse>`](../../doc/models/action-response.md)

## Example Usage

```csharp
int id = 112;
ImagesActionsChangeProtectionRequest body = new ImagesActionsChangeProtectionRequest
{
    Delete = true,
};

try
{
    ActionResponse result = await imageActionsController.ChangeImageProtectionAsync(
        id,
        body
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "image"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Get an Action for an Image

Returns a specific Action for an Image.

```csharp
GetAnActionForAnImageAsync(
    int id,
    int actionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `actionId` | `int` | Template, Required | ID of the Action |

## Response Type

**200**: The `action` key contains the Image Action

[`Task<Models.ActionResponse>`](../../doc/models/action-response.md)

## Example Usage

```csharp
int id = 112;
int actionId = 224;
try
{
    ActionResponse result = await imageActionsController.GetAnActionForAnImageAsync(
        id,
        actionId
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "image"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```

