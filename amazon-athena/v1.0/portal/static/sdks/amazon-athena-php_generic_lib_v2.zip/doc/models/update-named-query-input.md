
# Update Named Query Input

## Structure

`UpdateNamedQueryInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `namedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getNamedQueryId(): string | setNamedQueryId(string namedQueryId): void |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` | getName(): string | setName(string name): void |
| `description` | `?string` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024` | getDescription(): ?string | setDescription(?string description): void |
| `queryString` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` | getQueryString(): string | setQueryString(string queryString): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\UpdateNamedQueryInputBuilder;

$updateNamedQueryInput = UpdateNamedQueryInputBuilder::init(
    'NamedQueryId8',
    'Name4',
    'QueryString6'
)
    ->description('Description2')
    ->build();
```

