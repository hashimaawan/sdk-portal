
# Server 9

Configuration for type server, required if type is `server`

## Structure

`Server9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Server |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Server9 server9 = new Server9
{
    Id = 216,
};
```

