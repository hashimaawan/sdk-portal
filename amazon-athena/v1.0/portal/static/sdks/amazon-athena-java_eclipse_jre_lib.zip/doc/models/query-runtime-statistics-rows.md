
# Query Runtime Statistics Rows

Statistics such as input rows and bytes read by the query, rows and bytes output by the query, and the number of rows written by the query.

## Structure

`QueryRuntimeStatisticsRows`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `InputRows` | `Integer` | Optional | - | Integer getInputRows() | setInputRows(Integer inputRows) |
| `InputBytes` | `Integer` | Optional | - | Integer getInputBytes() | setInputBytes(Integer inputBytes) |
| `OutputBytes` | `Integer` | Optional | - | Integer getOutputBytes() | setOutputBytes(Integer outputBytes) |
| `OutputRows` | `Integer` | Optional | - | Integer getOutputRows() | setOutputRows(Integer outputRows) |

## Example

```java
import com.amazonaws.useast1.athena.models.QueryRuntimeStatisticsRows;

QueryRuntimeStatisticsRows queryRuntimeStatisticsRows = new QueryRuntimeStatisticsRows.Builder()
    .inputRows(234)
    .inputBytes(254)
    .outputBytes(40)
    .outputRows(226)
    .build();
```

