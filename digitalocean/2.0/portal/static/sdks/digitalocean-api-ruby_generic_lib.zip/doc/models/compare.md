
# Compare

## Enumeration

`Compare`

## Fields

| Name |
|  --- |
| `GREATERTHAN` |
| `LESSTHAN` |

## Example

```ruby
compare = Compare::GREATERTHAN
```

