
# Start Calculation Execution Response

*This model accepts additional fields of type interface{}.*

## Structure

`StartCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `State` | [`*models.CalculationExecutionState4`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    startCalculationExecutionResponse := models.StartCalculationExecutionResponse{
        CalculationExecutionId: models.ToPointer("CalculationExecutionId0"),
        State:                  models.ToPointer(models.CalculationExecutionState4_Canceling),
        AdditionalProperties:   map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

