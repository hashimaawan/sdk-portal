
# Image 3

The cost of Image per GB/month

## Structure

`Image3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pricePerGbMonth` | [`PricePerGbMonth`](../../doc/models/price-per-gb-month.md) | Required | - | getPricePerGbMonth(): PricePerGbMonth | setPricePerGbMonth(PricePerGbMonth pricePerGbMonth): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\Image3Builder;
use HetznerCloudAPILib\Models\Builders\PricePerGbMonthBuilder;

$image3 = Image3Builder::init(
    PricePerGbMonthBuilder::init(
        '1.1900000000000000',
        '1.0000000000'
    )->build()
)->build();
```

