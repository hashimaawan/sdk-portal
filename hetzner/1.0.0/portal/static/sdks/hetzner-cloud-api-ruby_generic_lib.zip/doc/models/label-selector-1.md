
# Label Selector 1

Configuration for type LabelSelector, required if type is `label_selector`

*This model accepts additional fields of type Object.*

## Structure

`LabelSelector1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selector` | `String` | Required | Label selector |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
label_selector1 = LabelSelector1.new(
  selector: 'selector2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

