
# Work Group State 2 Enum

The workgroup state that will be updated for the given workgroup.

## Enumeration

`WorkGroupState2Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ruby
work_group_state2 = WorkGroupState2Enum::ENABLED
```

