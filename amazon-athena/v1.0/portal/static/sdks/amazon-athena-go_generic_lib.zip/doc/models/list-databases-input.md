
# List Databases Input

## Structure

`ListDatabasesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listDatabasesInput := models.ListDatabasesInput{
        CatalogName:          "CatalogName4",
        NextToken:            models.ToPointer("NextToken0"),
        MaxResults:           models.ToPointer(50),
    }

}
```

