
# Result Reuse Configuration

Specifies the query result reuse behavior for the query.

## Structure

`ResultReuseConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result_reuse_by_age_configuration` | [`ResultReuseByAgeConfiguration2`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |

## Example

```ruby
result_reuse_configuration = ResultReuseConfiguration.new(
  ResultReuseByAgeConfiguration2.new(
    false,
    26
  )
)
```

