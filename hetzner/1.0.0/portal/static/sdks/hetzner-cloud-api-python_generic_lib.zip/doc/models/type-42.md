
# Type 42

Type of Subnetwork

## Enumeration

`Type42`

## Fields

| Name |
|  --- |
| `CLOUD` |
| `SERVER` |
| `VSWITCH` |

## Example

```python
from hetznercloudapi.models.type_42 import Type42

type_42 = Type42.CLOUD
```

