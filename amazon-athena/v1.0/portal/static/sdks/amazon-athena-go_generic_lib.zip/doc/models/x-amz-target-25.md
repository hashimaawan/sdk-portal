
# X Amz Target 25

## Enumeration

`XAmzTarget25`

## Fields

| Name |
|  --- |
| `EnumAmazonathenagetqueryruntimestatistics` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget25 := models.XAmzTarget25_EnumAmazonathenagetqueryruntimestatistics

}
```

