# Actions

Actions show the results and progress of asynchronous requests to the API.

```python
actions_api = client.actions
```

## Class Name

`ActionsApi`

## Methods

* [Get All Actions](../../doc/controllers/actions.md#get-all-actions)
* [Get an Action](../../doc/controllers/actions.md#get-an-action)


# Get All Actions

Returns all Action objects. You can `sort` the results by using the sort URI parameter, and filter them with the `status` parameter.

```python
def get_all_actions(self,
                   id=None,
                   sort=None,
                   status=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Query, Optional | Can be used multiple times, the response will contain only Actions with specified IDs |
| `sort` | [`ParameterSort`](../../doc/models/parameter-sort.md) | Query, Optional | Can be used multiple times. |
| `status` | [`ParameterStatus`](../../doc/models/parameter-status.md) | Query, Optional | Can be used multiple times, the response will contain only Actions with specified statuses |

## Response Type

**200**: The `actions` key contains a list of Actions

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ActionsResponse`](../../doc/models/actions-response.md).

## Example Usage

```python
result = actions_api.get_all_actions()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Get an Action

Returns a specific Action object.

```python
def get_an_action(self,
                 id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Resource |

## Response Type

**200**: The `action` key in the reply has this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`ActionResponse`](../../doc/models/action-response.md).

## Example Usage

```python
id = 112

result = actions_api.get_an_action(id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

