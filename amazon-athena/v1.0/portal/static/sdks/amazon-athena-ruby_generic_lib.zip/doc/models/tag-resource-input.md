
# Tag Resource Input

## Structure

`TagResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resource_arn` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `tags` | [`Array[Tag]`](../../doc/models/tag.md) | Required | - |

## Example

```ruby
tag_resource_input = TagResourceInput.new(
  'ResourceARN0',
  [
    Tag.new(
      'Key0',
      'Value6'
    )
  ]
)
```

