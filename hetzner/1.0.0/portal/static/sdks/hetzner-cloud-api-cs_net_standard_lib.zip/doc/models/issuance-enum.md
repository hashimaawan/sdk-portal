
# Issuance Enum

Status of the issuance process of the Certificate

## Enumeration

`IssuanceEnum`

## Fields

| Name |
|  --- |
| `Pending` |
| `Completed` |
| `Failed` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

IssuanceEnum issuance = IssuanceEnum.Failed;
```

