
# Executors Summary

Contains summary information about an executor.

## Structure

`ExecutorsSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `executorId` | `string` | Required | **Constraints**: *Maximum Length*: `100000`, *Pattern*: `.*` | getExecutorId(): string | setExecutorId(string executorId): void |
| `executorType` | [`?string(ExecutorType2Enum)`](../../doc/models/executor-type-2-enum.md) | Optional | - | getExecutorType(): ?string | setExecutorType(?string executorType): void |
| `startDateTime` | `?int` | Optional | - | getStartDateTime(): ?int | setStartDateTime(?int startDateTime): void |
| `terminationDateTime` | `?int` | Optional | - | getTerminationDateTime(): ?int | setTerminationDateTime(?int terminationDateTime): void |
| `executorState` | [`?string(ExecutorState3Enum)`](../../doc/models/executor-state-3-enum.md) | Optional | - | getExecutorState(): ?string | setExecutorState(?string executorState): void |
| `executorSize` | `?int` | Optional | - | getExecutorSize(): ?int | setExecutorSize(?int executorSize): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ExecutorsSummaryBuilder;
use AmazonAthenaLib\Models\ExecutorType2Enum;
use AmazonAthenaLib\Models\ExecutorState3Enum;

$executorsSummary = ExecutorsSummaryBuilder::init(
    'ExecutorId8'
)
    ->executorType(ExecutorType2Enum::WORKER)
    ->startDateTime(52)
    ->terminationDateTime(56)
    ->executorState(ExecutorState3Enum::CREATING)
    ->executorSize(222)
    ->build();
```

