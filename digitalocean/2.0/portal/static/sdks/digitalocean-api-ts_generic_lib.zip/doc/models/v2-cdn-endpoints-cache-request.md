
# V2 Cdn Endpoints Cache Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsCacheRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `files` | `string[]` | Required | An array of strings containing the path to the content to be purged from the CDN cache. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2CdnEndpointsCacheRequest } from 'digitalocean-apilib';

const v2CdnEndpointsCacheRequest: V2CdnEndpointsCacheRequest = {
  files: [
    'path/to/image.png',
    'path/to/css/*'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

