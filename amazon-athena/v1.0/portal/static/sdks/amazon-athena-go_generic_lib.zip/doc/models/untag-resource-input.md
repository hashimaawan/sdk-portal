
# Untag Resource Input

*This model accepts additional fields of type interface{}.*

## Structure

`UntagResourceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResourceArn` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1011` |
| `TagKeys` | `[]string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    untagResourceInput := models.UntagResourceInput{
        ResourceArn:           "ResourceARN6",
        TagKeys:               []string{
            "TagKeys1",
            "TagKeys2",
            "TagKeys3",
        },
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

