
# Server 11

*This model accepts additional fields of type unknown.*

## Structure

`Server11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Server |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Server11 } from 'hetzner-cloud-apilib';

const server11: Server11 = {
  id: 85,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

