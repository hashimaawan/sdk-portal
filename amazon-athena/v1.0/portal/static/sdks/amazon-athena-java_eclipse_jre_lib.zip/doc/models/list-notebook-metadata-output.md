
# List Notebook Metadata Output

*This model accepts additional fields of type Object.*

## Structure

`ListNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NextToken` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getNextToken() | setNextToken(String nextToken) |
| `NotebookMetadataList` | [`List<NotebookMetadata>`](../../doc/models/notebook-metadata.md) | Optional | - | List<NotebookMetadata> getNotebookMetadataList() | setNotebookMetadataList(List<NotebookMetadata> notebookMetadataList) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.amazonaws.useast1.athena.ApiHelper;
import com.amazonaws.useast1.athena.DateTimeHelper;
import com.amazonaws.useast1.athena.models.ListNotebookMetadataOutput;
import com.amazonaws.useast1.athena.models.NotebookMetadata;
import com.amazonaws.useast1.athena.models.NotebookType1;
import java.io.IOException;
import java.util.Arrays;

ListNotebookMetadataOutput listNotebookMetadataOutput = new ListNotebookMetadataOutput.Builder()
    .nextToken("NextToken2")
    .notebookMetadataList(Arrays.asList(
        new NotebookMetadata.Builder()
            .notebookId("NotebookId4")
            .name("Name4")
            .workGroup("WorkGroup6")
            .creationTime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
            .type(NotebookType1.IPYNB)
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    ))
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

