
# Get Named Query Output

## Structure

`GetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQuery` | [`*models.NamedQuery1`](../../doc/models/named-query-1.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getNamedQueryOutput := models.GetNamedQueryOutput{
        NamedQuery:           models.ToPointer(models.NamedQuery1{
            Name:                 "Name0",
            Description:          models.ToPointer("Description6"),
            Database:             "Database8",
            QueryString:          "QueryString2",
            NamedQueryId:         models.ToPointer("NamedQueryId2"),
            WorkGroup:            models.ToPointer("WorkGroup2"),
        }),
    }

}
```

