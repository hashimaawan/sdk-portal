
# Status 113 Enum

Current status of the Volume

## Enumeration

`Status113Enum`

## Fields

| Name |
|  --- |
| `CREATING` |
| `AVAILABLE` |

## Example

```php
use HetznerCloudAPILib\Models\Status113Enum;

$status113 = Status113Enum::CREATING;
```

