
# Terminate Session Response

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`SessionState1Enum \| undefined`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```ts
import {
  SessionState1Enum,
  TerminateSessionResponse,
} from 'amazon-athenalib';

const terminateSessionResponse: TerminateSessionResponse = {
  state: SessionState1Enum.CREATING,
};
```

