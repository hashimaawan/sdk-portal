
# Created From

Information about the Server the Image was created from

## Structure

`CreatedFrom`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | ID of the Server the Image was created from |
| `name` | `String` | Required | Server name at the time the Image was created |

## Example

```ruby
created_from = CreatedFrom.new(
  1,
  'Server'
)
```

