
# V2 Apps Regions Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2AppsRegionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `regions` | [`GeographicalInformationAboutAnAppOrigin[] \| undefined`](../../doc/models/geographical-information-about-an-app-origin.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2AppsRegionsResponse } from 'digitalocean-apilib';

const v2AppsRegionsResponse: V2AppsRegionsResponse = {
  regions: [
    {
      continent: 'continent2',
      dataCenters: [
        'data_centers9'
      ],
      mDefault: false,
      disabled: false,
      flag: 'flag4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

