
# X Amz Target 2

## Enumeration

`XAmzTarget2`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaBatchGetQueryExecution` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget2 xAmzTarget2 = XAmzTarget2.EnumAmazonAthenaBatchGetQueryExecution;
```

