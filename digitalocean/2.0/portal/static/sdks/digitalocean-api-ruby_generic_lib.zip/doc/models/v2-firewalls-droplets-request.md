
# V2 Firewalls Droplets Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FirewallsDropletsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `droplet_ids` | `Array[Integer]` | Required | An array containing the IDs of the Droplets to be removed from the firewall. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_firewalls_droplets_request = V2FirewallsDropletsRequest.new(
  droplet_ids: [
    49696269
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

