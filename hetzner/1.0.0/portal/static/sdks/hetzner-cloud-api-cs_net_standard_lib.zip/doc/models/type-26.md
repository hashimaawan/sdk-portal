
# Type 26

Type of the ISO

## Enumeration

`Type26`

## Fields

| Name |
|  --- |
| `Public` |
| `Private` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Type26 type26 = Type26.Public;
```

