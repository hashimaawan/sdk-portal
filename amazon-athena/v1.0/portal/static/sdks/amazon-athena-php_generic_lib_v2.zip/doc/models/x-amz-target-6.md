
# X Amz Target 6

## Enumeration

`XAmzTarget6`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget6;

$xAmzTarget6 = XAmzTarget6::ENUM_AMAZONATHENACREATEPREPAREDSTATEMENT;
```

