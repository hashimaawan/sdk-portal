# Pricing

Returns prices for resources.

```ruby
pricing_api = client.pricing
```

## Class Name

`PricingApi`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```ruby
def get_all_prices
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PricingResponse`](../../doc/models/pricing-response.md).

## Example Usage

```ruby
result = pricing_api.get_all_prices

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

