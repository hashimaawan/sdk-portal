
# X Amz Target 30 Enum

## Enumeration

`XAmzTarget30Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAIMPORTNOTEBOOK` |

## Example

```ruby
x_amz_target30 = XAmzTarget30Enum::ENUM_AMAZONATHENAIMPORTNOTEBOOK
```

