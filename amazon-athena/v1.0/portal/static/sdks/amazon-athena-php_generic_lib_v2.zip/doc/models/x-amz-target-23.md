
# X Amz Target 23

## Enumeration

`XAmzTarget23`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget23;

$xAmzTarget23 = XAmzTarget23::ENUM_AMAZONATHENAGETQUERYEXECUTION;
```

