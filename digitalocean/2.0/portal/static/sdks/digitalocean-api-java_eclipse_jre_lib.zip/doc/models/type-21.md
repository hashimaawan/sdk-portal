
# Type 21

The volume action to initiate.

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `ATTACH` |
| `DETACH` |
| `RESIZE` |

## Example

```java
import com.digitalocean.api.models.Type21;

Type21 type21 = Type21.DETACH;
```

