
# Server Types

The Server types the Datacenter can handle

## Structure

`ServerTypes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Available` | `List<double>` | Required | IDs of Server types that are supported and for which the Datacenter has enough resources left |
| `AvailableForMigration` | `List<double>` | Required | IDs of Server types that are supported and for which the Datacenter has enough resources left |
| `Supported` | `List<double>` | Required | IDs of Server types that are supported in the Datacenter |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;
using System.Collections.Generic;

ServerTypes serverTypes = new ServerTypes
{
    Available = new List<double>
    {
        1,
        2,
        3,
    },
    AvailableForMigration = new List<double>
    {
        1,
        2,
        3,
    },
    Supported = new List<double>
    {
        1,
        2,
        3,
    },
};
```

