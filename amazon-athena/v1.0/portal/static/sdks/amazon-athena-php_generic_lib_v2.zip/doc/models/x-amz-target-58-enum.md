
# X Amz Target 58 Enum

## Enumeration

`XAmzTarget58Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget58Enum;

$xAmzTarget58 = XAmzTarget58Enum::ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT;
```

