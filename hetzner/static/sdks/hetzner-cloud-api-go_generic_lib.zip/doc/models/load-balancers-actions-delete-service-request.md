
# Load Balancers Actions Delete Service Request

## Structure

`LoadBalancersActionsDeleteServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ListenPort` | `float64` | Required | The listen port of the service you want to delete |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    loadBalancersActionsDeleteServiceRequest := models.LoadBalancersActionsDeleteServiceRequest{
        ListenPort:           float64(4711),
    }

}
```

