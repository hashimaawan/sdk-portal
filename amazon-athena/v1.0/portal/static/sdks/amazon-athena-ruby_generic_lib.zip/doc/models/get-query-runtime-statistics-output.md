
# Get Query Runtime Statistics Output

## Structure

`GetQueryRuntimeStatisticsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_runtime_statistics` | [`QueryRuntimeStatistics2`](../../doc/models/query-runtime-statistics-2.md) | Optional | - |

## Example

```ruby
get_query_runtime_statistics_output = GetQueryRuntimeStatisticsOutput.new(
  QueryRuntimeStatistics2.new(
    QueryRuntimeStatisticsTimeline.new(
      156,
      82,
      112,
      126,
      106
    ),
    QueryRuntimeStatisticsRows.new(
      230,
      250,
      36,
      230
    ),
    OutputStage.new(
      130,
      'State0',
      108,
      158,
      190,
      nil,
      nil,
      QueryStagePlan.new(
        nil,
        nil,
        [],
        []
      ),
      []
    )
  )
)
```

