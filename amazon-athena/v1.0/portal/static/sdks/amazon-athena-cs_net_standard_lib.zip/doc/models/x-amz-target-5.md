
# X Amz Target 5

## Enumeration

`XAmzTarget5`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateNotebook` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget5 xAmzTarget5 = XAmzTarget5.EnumAmazonAthenaCreateNotebook;
```

