
# Statistics 1

*This model accepts additional fields of type Object.*

## Structure

`Statistics1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `Integer` | Optional | - |
| `progress` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
statistics1 = Statistics1.new(
  dpu_execution_in_millis: 148,
  progress: 'Progress4',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

