
# Price Hourly 6

Hourly costs for a Load Balancer type in this network zone

## Structure

`PriceHourly6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gross` | `string` | Required | Price with VAT added |
| `net` | `string` | Required | Price without VAT |

## Example

```ts
import { PriceHourly6 } from 'hetzner-cloud-apilib';

const priceHourly6: PriceHourly6 = {
  gross: '1.1900000000000000',
  net: '1.0000000000',
};
```

