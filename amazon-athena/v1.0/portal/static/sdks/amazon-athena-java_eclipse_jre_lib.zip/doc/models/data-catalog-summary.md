
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CatalogName` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | String getCatalogName() | setCatalogName(String catalogName) |
| `Type` | [`DataCatalogType2Enum`](../../doc/models/data-catalog-type-2-enum.md) | Optional | - | DataCatalogType2Enum getType() | setType(DataCatalogType2Enum type) |

## Example

```java
import com.amazonaws.useast1.athena.models.DataCatalogSummary;
import com.amazonaws.useast1.athena.models.DataCatalogType2Enum;

DataCatalogSummary dataCatalogSummary = new DataCatalogSummary.Builder()
    .catalogName("CatalogName2")
    .type(DataCatalogType2Enum.HIVE)
    .build();
```

