
# V2 Firewalls Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FirewallsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewalls` | [`Array[Firewall]`](../../doc/models/firewall.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_firewalls_response = V2FirewallsResponse.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  firewalls: [
    Firewall.new(
      created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      droplet_ids: [
        57
      ],
      id: 'id0',
      name: 'name0',
      pending_changes: [
        nil,
        PendingChange.new,
        PendingChange.new
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Firewall.new(
      created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      droplet_ids: [
        57
      ],
      id: 'id0',
      name: 'name0',
      pending_changes: [
        nil,
        PendingChange.new,
        PendingChange.new
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

