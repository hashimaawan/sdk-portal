
# Result Reuse Information

Contains information about whether the result of a previous query was reused.

## Structure

`ResultReuseInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReusedPreviousResult` | `boolean` | Required | - | boolean getReusedPreviousResult() | setReusedPreviousResult(boolean reusedPreviousResult) |

## Example

```java
import com.amazonaws.useast1.athena.models.ResultReuseInformation;

ResultReuseInformation resultReuseInformation = new ResultReuseInformation.Builder(
    false
)
.build();
```

