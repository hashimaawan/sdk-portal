
# V2 Monitoring Alerts Request

*This model accepts additional fields of type Object.*

## Structure

`V2MonitoringAlertsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Alerts` | [`Alerts`](../../doc/models/alerts.md) | Required | - | Alerts getAlerts() | setAlerts(Alerts alerts) |
| `Compare` | [`Compare`](../../doc/models/compare.md) | Required | - | Compare getCompare() | setCompare(Compare compare) |
| `Description` | `String` | Required | - | String getDescription() | setDescription(String description) |
| `Enabled` | `boolean` | Required | - | boolean getEnabled() | setEnabled(boolean enabled) |
| `Entities` | `List<String>` | Required | - | List<String> getEntities() | setEntities(List<String> entities) |
| `Tags` | `List<String>` | Required | - | List<String> getTags() | setTags(List<String> tags) |
| `Type` | [`Type17`](../../doc/models/type-17.md) | Required | - | Type17 getType() | setType(Type17 type) |
| `Value` | `double` | Required | - | double getValue() | setValue(double value) |
| `Window` | [`Window1`](../../doc/models/window-1.md) | Required | - | Window1 getWindow() | setWindow(Window1 window) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Alerts;
import com.digitalocean.api.models.Compare;
import com.digitalocean.api.models.Slack;
import com.digitalocean.api.models.Type17;
import com.digitalocean.api.models.V2MonitoringAlertsRequest;
import com.digitalocean.api.models.Window1;
import java.io.IOException;
import java.util.Arrays;

V2MonitoringAlertsRequest v2MonitoringAlertsRequest = new V2MonitoringAlertsRequest.Builder(
    new Alerts.Builder(
        Arrays.asList(
            "bob@exmaple.com"
        ),
        Arrays.asList(
            new Slack.Builder(
                "Production Alerts",
                "https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ"
            )
            .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
        )
    )
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build(),
    Compare.GREATERTHAN,
    "CPU Alert",
    true,
    Arrays.asList(
        "192018292"
    ),
    Arrays.asList(
        "droplet_tag"
    ),
    Type17.ENUM_V1INSIGHTSDROPLETCPU,
    80D,
    Window1.ENUM_5M
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

