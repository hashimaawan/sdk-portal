
# Work Group State Enum

## Enumeration

`WorkGroupStateEnum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ts
import { WorkGroupStateEnum } from 'amazon-athenalib';

const workGroupState = WorkGroupStateEnum.ENABLED;
```

