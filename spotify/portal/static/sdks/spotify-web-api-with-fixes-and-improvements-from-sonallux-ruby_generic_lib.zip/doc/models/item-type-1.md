
# Item Type 1

The ID type: currently only `artist` is supported.

## Enumeration

`ItemType1`

## Fields

| Name |
|  --- |
| `ARTIST` |

## Example

```ruby
item_type1 = ItemType1::ARTIST
```

