
# X Amz Target 8

## Enumeration

`XAmzTarget8`

## Fields

| Name |
|  --- |
| `EnumAmazonathenacreateworkgroup` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget8 := models.XAmzTarget8_EnumAmazonathenacreateworkgroup

}
```

