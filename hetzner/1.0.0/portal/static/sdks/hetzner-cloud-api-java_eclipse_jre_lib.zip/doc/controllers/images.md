# Images

Images are blueprints for your VM disks. They can be of different types:

### System Images

Distribution Images maintained by us, e.g. “Ubuntu 20.04”

### Snapshot Images

Maintained by you, for example “Ubuntu 20.04 with my own settings”. These are billed per GB per month.

### Backup Images

Daily Backups of your Server. Will automatically be created for Servers which have backups enabled (`POST /servers/{id}/actions/enable_backup`)

Bound to exactly one Server. If you delete the Server, you also delete all backups bound to it. You may convert backup Images to snapshot Images to keep them.

These are billed at 20% of your instance price for 7 backup slots.

### App Images

Prebuild images with specific software configurations, e.g. “Wordpress”. All app images are created by us.

```java
ImagesApi imagesApi = client.getImagesApi();
```

## Class Name

`ImagesApi`

## Methods

* [Get All Images](../../doc/controllers/images.md#get-all-images)
* [Delete an Image](../../doc/controllers/images.md#delete-an-image)
* [Get an Image](../../doc/controllers/images.md#get-an-image)
* [Update an Image](../../doc/controllers/images.md#update-an-image)


# Get All Images

Returns all Image objects. You can select specific Image types only and sort the results by using URI parameters.

```java
CompletableFuture<ApiResponse<ImagesResponse>> getAllImagesAsync(
    final Sort sort,
    final Type21 type,
    final Status23 status,
    final String boundTo,
    final Boolean includeDeprecated,
    final String name,
    final String labelSelector)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`Sort`](../../doc/models/sort.md) | Query, Optional | Can be used multiple times. |
| `type` | [`Type21`](../../doc/models/type-21.md) | Query, Optional | Can be used multiple times. |
| `status` | [`Status23`](../../doc/models/status-23.md) | Query, Optional | Can be used multiple times. The response will only contain Images matching the status. |
| `boundTo` | `String` | Query, Optional | Can be used multiple times. Server ID linked to the Image. Only available for Images of type `backup` |
| `includeDeprecated` | `Boolean` | Query, Optional | Can be used multiple times. |
| `name` | `String` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `String` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `images` key in the reply contains an array of Image objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`ImagesResponse`](../../doc/models/images-response.md).

## Example Usage

```java
imagesApi.getAllImagesAsync(null, null, null, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Delete an Image

Deletes an Image. Only Images of type `snapshot` and `backup` can be deleted.

```java
CompletableFuture<ApiResponse<Void>> deleteAnImageAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |

## Response Type

**204**: Image deleted

`void`

## Example Usage

```java
int id = 112;

imagesApi.deleteAnImageAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get an Image

Returns a specific Image object.

```java
CompletableFuture<ApiResponse<ImagesResponse1>> getAnImageAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |

## Response Type

**200**: The `image` key in the reply contains an Image object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`ImagesResponse1`](../../doc/models/images-response-1.md).

## Example Usage

```java
int id = 112;

imagesApi.getAnImageAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Update an Image

Updates the Image. You may change the description, convert a Backup Image to a Snapshot Image or change the Image labels. Only Images of type `snapshot` and `backup` can be updated.

Note that when updating labels, the current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```java
CompletableFuture<ApiResponse<ImagesResponse1>> updateAnImageAsync(
    final int id,
    final UpdateImageRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `body` | [`UpdateImageRequest`](../../doc/models/update-image-request.md) | Body, Optional | - |

## Response Type

**200**: The image key in the reply contains the modified Image object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`ImagesResponse1`](../../doc/models/images-response-1.md).

## Example Usage

```java
int id = 112;
UpdateImageRequest body = new UpdateImageRequest.Builder()
    .description("My new Image description")
    .labels(ApiHelper.deserialize("{\"labelkey\":\"value\"}"))
    .build();

imagesApi.updateAnImageAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "image": {
    "bound_to": null,
    "build_id": "c313fe40383af26094a5a92026054320ab55abc7",
    "created": "2016-01-30T23:50:00+00:00",
    "created_from": {
      "id": 1,
      "name": "Server"
    },
    "deleted": null,
    "deprecated": "2018-02-28T00:00:00+00:00",
    "description": "My new Image description",
    "disk_size": 10,
    "id": 4711,
    "image_size": 2.3,
    "labels": {
      "labelkey": "value"
    },
    "name": null,
    "os_flavor": "ubuntu",
    "os_version": "20.04",
    "protection": {
      "delete": false
    },
    "rapid_deploy": false,
    "status": "available",
    "type": "snapshot"
  }
}
```

