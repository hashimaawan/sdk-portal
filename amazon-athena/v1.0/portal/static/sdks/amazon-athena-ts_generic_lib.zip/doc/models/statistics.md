
# Statistics

*This model accepts additional fields of type unknown.*

## Structure

`Statistics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `engineExecutionTimeInMillis` | `number \| undefined` | Optional | - |
| `dataScannedInBytes` | `number \| undefined` | Optional | - |
| `dataManifestLocation` | `string \| undefined` | Optional | - |
| `totalExecutionTimeInMillis` | `number \| undefined` | Optional | - |
| `queryQueueTimeInMillis` | `number \| undefined` | Optional | - |
| `queryPlanningTimeInMillis` | `number \| undefined` | Optional | - |
| `serviceProcessingTimeInMillis` | `number \| undefined` | Optional | - |
| `resultReuseInformation` | [`ResultReuseInformation2 \| undefined`](../../doc/models/result-reuse-information-2.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Statistics } from 'amazon-athenalib';

const statistics: Statistics = {
  engineExecutionTimeInMillis: 72,
  dataScannedInBytes: 60,
  dataManifestLocation: 'DataManifestLocation0',
  totalExecutionTimeInMillis: 146,
  queryQueueTimeInMillis: 116,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

