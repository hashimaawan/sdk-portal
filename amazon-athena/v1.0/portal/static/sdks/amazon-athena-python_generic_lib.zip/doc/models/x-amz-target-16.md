
# X Amz Target 16

## Enumeration

`XAmzTarget16`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE` |

## Example

```python
from amazonathena.models.x_amz_target_16 import XAmzTarget16

x_amz_target_16 = XAmzTarget16.ENUM_AMAZONATHENAGETCALCULATIONEXECUTIONCODE
```

