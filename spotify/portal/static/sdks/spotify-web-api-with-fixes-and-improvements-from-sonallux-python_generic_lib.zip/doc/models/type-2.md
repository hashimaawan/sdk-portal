
# Type 2

The object type: "track".

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `TRACK` |

## Example

```python
from spotifywebapiwithfixesandimprovementsfromsonallux.models.type_2 import Type2

type_2 = Type2.TRACK
```

