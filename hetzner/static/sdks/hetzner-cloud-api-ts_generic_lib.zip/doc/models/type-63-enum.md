
# Type 63 Enum

Type of Image to create (default: `snapshot`)

## Enumeration

`Type63Enum`

## Fields

| Name |
|  --- |
| `Snapshot` |
| `Backup` |

## Example

```ts
import { Type63Enum } from 'hetzner-cloud-apilib';

const type63 = Type63Enum.Snapshot;
```

