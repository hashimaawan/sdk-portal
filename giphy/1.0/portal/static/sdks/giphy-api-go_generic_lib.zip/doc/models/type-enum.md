
# Type Enum

Type of the gif. By default, this is almost always gif

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `GIF` |

## Example

```go
package main

import (
    "giphyapi/models"
)

func main() {
    mType := models.TypeEnum_GIF

}
```

