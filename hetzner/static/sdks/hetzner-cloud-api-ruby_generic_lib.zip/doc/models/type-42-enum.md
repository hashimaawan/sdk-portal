
# Type 42 Enum

Type of Subnetwork

## Enumeration

`Type42Enum`

## Fields

| Name |
|  --- |
| `CLOUD` |
| `SERVER` |
| `VSWITCH` |

## Example

```ruby
type42 = Type42Enum::CLOUD
```

