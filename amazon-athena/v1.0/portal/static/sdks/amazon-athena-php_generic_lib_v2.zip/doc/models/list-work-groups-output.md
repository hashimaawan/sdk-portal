
# List Work Groups Output

## Structure

`ListWorkGroupsOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `workGroups` | [`?(WorkGroupSummary[])`](../../doc/models/work-group-summary.md) | Optional | **Constraints**: *Minimum Items*: `0`, *Maximum Items*: `50` | getWorkGroups(): ?array | setWorkGroups(?array workGroups): void |
| `nextToken` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | getNextToken(): ?string | setNextToken(?string nextToken): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ListWorkGroupsOutputBuilder;
use AmazonAthenaLib\Models\Builders\WorkGroupSummaryBuilder;
use AmazonAthenaLib\Models\WorkGroupState1Enum;
use AmazonAthenaLib\Utils\DateTimeHelper;
use AmazonAthenaLib\Models\Builders\EngineVersion1Builder;

$listWorkGroupsOutput = ListWorkGroupsOutputBuilder::init()
    ->workGroups(
        [
            WorkGroupSummaryBuilder::init()
                ->name('Name4')
                ->state(WorkGroupState1Enum::ENABLED)
                ->description('Description0')
                ->creationTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->engineVersion(
                    EngineVersion1Builder::init()
                        ->selectedEngineVersion('SelectedEngineVersion4')
                        ->effectiveEngineVersion('EffectiveEngineVersion6')
                        ->build()
                )
                ->build(),
            WorkGroupSummaryBuilder::init()
                ->name('Name4')
                ->state(WorkGroupState1Enum::ENABLED)
                ->description('Description0')
                ->creationTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->engineVersion(
                    EngineVersion1Builder::init()
                        ->selectedEngineVersion('SelectedEngineVersion4')
                        ->effectiveEngineVersion('EffectiveEngineVersion6')
                        ->build()
                )
                ->build(),
            WorkGroupSummaryBuilder::init()
                ->name('Name4')
                ->state(WorkGroupState1Enum::ENABLED)
                ->description('Description0')
                ->creationTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                ->engineVersion(
                    EngineVersion1Builder::init()
                        ->selectedEngineVersion('SelectedEngineVersion4')
                        ->effectiveEngineVersion('EffectiveEngineVersion6')
                        ->build()
                )
                ->build()
        ]
    )
    ->nextToken('NextToken2')
    ->build();
```

