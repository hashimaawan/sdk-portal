
# Type 21

## Enumeration

`Type21`

## Fields

| Name |
|  --- |
| `System` |
| `Snapshot` |
| `Backup` |
| `App` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type21 := models.Type21_Backup

}
```

