
# Statistics 3

## Structure

`Statistics3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpuExecutionInMillis` | `number \| undefined` | Optional | - |

## Example

```ts
import { Statistics3 } from 'amazon-athenalib';

const statistics3: Statistics3 = {
  dpuExecutionInMillis: 130,
};
```

