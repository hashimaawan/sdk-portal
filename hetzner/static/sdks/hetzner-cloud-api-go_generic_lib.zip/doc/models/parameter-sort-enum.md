
# Parameter Sort Enum

## Enumeration

`ParameterSortEnum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUMIDASC` |
| `ENUMIDDESC` |
| `COMMAND` |
| `ENUMCOMMANDASC` |
| `ENUMCOMMANDDESC` |
| `STATUS` |
| `ENUMSTATUSASC` |
| `ENUMSTATUSDESC` |
| `PROGRESS` |
| `ENUMPROGRESSASC` |
| `ENUMPROGRESSDESC` |
| `STARTED` |
| `ENUMSTARTEDASC` |
| `ENUMSTARTEDDESC` |
| `FINISHED` |
| `ENUMFINISHEDASC` |
| `ENUMFINISHEDDESC` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    parameterSort := models.ParameterSortEnum_ENUMSTATUSDESC

}
```

