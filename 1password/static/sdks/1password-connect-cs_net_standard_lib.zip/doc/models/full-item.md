
# Full Item

*This model accepts additional fields of type object.*

## Structure

`FullItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Category` | [`Category`](../../doc/models/category.md) | Required | - |
| `CreatedAt` | `DateTime?` | Optional, Read-only | - |
| `Favorite` | `bool?` | Optional | **Default**: `false` |
| `Id` | `string` | Optional | **Constraints**: *Pattern*: `^[\da-z]{26}$` |
| `LastEditedBy` | `string` | Optional, Read-only | - |
| `State` | [`State?`](../../doc/models/state.md) | Optional, Read-only | - |
| `Tags` | `List<string>` | Optional | - |
| `Title` | `string` | Optional | - |
| `UpdatedAt` | `DateTime?` | Optional, Read-only | - |
| `Urls` | [`List<Url>`](../../doc/models/url.md) | Optional | - |
| `Vault` | [`Vault1`](../../doc/models/vault-1.md) | Required | - |
| `Version` | `int?` | Optional | - |
| `Fields` | [`List<Field>`](../../doc/models/field.md) | Optional | - |
| `Files` | [`List<File>`](../../doc/models/file.md) | Optional | - |
| `Sections` | [`List<Section2>`](../../doc/models/section-2.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using M1PasswordConnect.Standard.Models;
using M1PasswordConnect.Standard.Utilities;
using System.Collections.Generic;
using System.Globalization;

FullItem fullItem = new FullItem
{
    Category = Category.Membership,
    Vault = new Vault1
    {
        Id = "id6",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    CreatedAt = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    Favorite = false,
    Id = "id0",
    LastEditedBy = "lastEditedBy6",
    State = State.Archived,
    Urls = new List<Url>
    {
        new Url
        {
            Href = "https://example.com",
            Primary = true,
        },
        new Url
        {
            Href = "https://example.org",
        },
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

