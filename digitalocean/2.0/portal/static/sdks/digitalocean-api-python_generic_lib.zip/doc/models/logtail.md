
# Logtail

Logtail configuration.

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`Logtail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `str` | Optional | Logtail token. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.logtail import Logtail

logtail = Logtail(
    token='abcdefghijklmnopqrstuvwxyz0123456789',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

