
# Load Balancer Algorithm

Algorithm of the Load Balancer

## Structure

`LoadBalancerAlgorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Type28Enum`](../../doc/models/type-28-enum.md) | Required | Type of the algorithm |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LoadBalancerAlgorithm loadBalancerAlgorithm = new LoadBalancerAlgorithm
{
    Type = Type28Enum.RoundRobin,
};
```

