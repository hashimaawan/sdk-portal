
# Sort 2

## Enumeration

`Sort2`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```csharp
using HetznerCloudApi.Standard.Models;

Sort2 sort2 = Sort2.EnumCreatedasc;
```

