
# Status 73 Enum

Status of the Server

## Enumeration

`Status73Enum`

## Fields

| Name |
|  --- |
| `RUNNING` |
| `INITIALIZING` |
| `STARTING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `MIGRATING` |
| `REBUILDING` |
| `UNKNOWN` |

## Example

```ruby
status73 = Status73Enum::STARTING
```

