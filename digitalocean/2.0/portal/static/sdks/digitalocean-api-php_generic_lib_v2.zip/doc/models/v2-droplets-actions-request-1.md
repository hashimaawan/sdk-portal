
# V2 Droplets Actions Request 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DropletsActionsRequest1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`string(Type12)`](../../doc/models/type-12.md) | Required | The type of action to initiate for the Droplet. | getType(): string | setType(string type): void |
| `name` | `?string` | Optional | The name to give the new snapshot of the Droplet. | getName(): ?string | setName(?string name): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DropletsActionsRequest1Builder;
use DigitalOceanApiLib\Models\Type12;
use DigitalOceanApiLib\ApiHelper;

$v2DropletsActionsRequest1 = V2DropletsActionsRequest1Builder::init(
    Type12::REBOOT
)
    ->name('Nifty New Snapshot')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

