
# Start Session Response

*This model accepts additional fields of type unknown.*

## Structure

`StartSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `state` | [`SessionState1 \| undefined`](../../doc/models/session-state-1.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { SessionState1, StartSessionResponse } from 'amazon-athenalib';

const startSessionResponse: StartSessionResponse = {
  sessionId: 'SessionId4',
  state: SessionState1.Creating,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

