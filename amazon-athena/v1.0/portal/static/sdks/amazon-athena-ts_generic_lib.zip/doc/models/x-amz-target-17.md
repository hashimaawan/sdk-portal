
# X Amz Target 17

## Enumeration

`XAmzTarget17`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecutionStatus` |

## Example

```ts
import { XAmzTarget17 } from 'amazon-athenalib';

const xAmzTarget17 = XAmzTarget17.EnumAmazonAthenaGetCalculationExecutionStatus;
```

