
# Statistics 1

## Structure

`Statistics1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dpu_execution_in_millis` | `Integer` | Optional | - |
| `progress` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
statistics1 = Statistics1.new(
  148,
  'Progress4'
)
```

