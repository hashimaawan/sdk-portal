
# Album Type

The type of the album.

## Enumeration

`AlbumType`

## Fields

| Name |
|  --- |
| `Album` |
| `Single` |
| `Compilation` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    albumType := models.AlbumType_Compilation

}
```

