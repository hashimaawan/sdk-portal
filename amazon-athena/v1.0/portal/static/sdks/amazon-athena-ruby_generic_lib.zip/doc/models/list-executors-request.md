
# List Executors Request

## Structure

`ListExecutorsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `executor_state_filter` | [`ExecutorState1Enum`](../../doc/models/executor-state-1-enum.md) | Optional | - |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `next_token` | `String` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```ruby
list_executors_request = ListExecutorsRequest.new(
  'SessionId6',
  ExecutorState1Enum::REGISTERED,
  100,
  'NextToken2'
)
```

