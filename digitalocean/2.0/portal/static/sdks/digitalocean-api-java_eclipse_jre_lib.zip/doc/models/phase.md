
# Phase

## Enumeration

`Phase`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `PENDING_BUILD` |
| `BUILDING` |
| `PENDING_DEPLOY` |
| `DEPLOYING` |
| `ACTIVE` |
| `SUPERSEDED` |
| `ERROR` |
| `CANCELED` |

## Example

```java
import com.digitalocean.api.models.Phase;

Phase phase = Phase.BUILDING;
```

