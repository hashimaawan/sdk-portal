
# V2 Registry Request

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2RegistryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | A globally unique name for the container registry. Must be lowercase and be composed only of numbers, letters and `-`, up to a limit of 63 characters.<br><br>**Constraints**: *Maximum Length*: `63`, *Pattern*: `^[a-z0-9-]{1,63}$` |
| `region` | [`Region6`](../../doc/models/region-6.md) | Optional | Slug of the region where registry data is stored. When not provided, a region will be selected. |
| `subscription_tier_slug` | [`SubscriptionTierSlug`](../../doc/models/subscription-tier-slug.md) | Required | The slug of the subscription tier to sign up for. Valid values can be retrieved using the options endpoint. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.region_6 import Region6
from digitaloceanapi.models.subscription_tier_slug import SubscriptionTierSlug
from digitaloceanapi.models.v_2_registry_request import V2RegistryRequest

v_2_registry_request = V2RegistryRequest(
    name='example',
    subscription_tier_slug=SubscriptionTierSlug.BASIC,
    region=Region6.FRA1,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

