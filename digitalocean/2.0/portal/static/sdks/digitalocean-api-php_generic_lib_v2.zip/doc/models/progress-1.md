
# Progress 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Progress1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `steps` | [`?(array[])`](../../doc/models/object.md) | Optional | - | getSteps(): ?array | setSteps(?array steps): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Progress1Builder;
use DigitalOceanApiLib\ApiHelper;

$progress1 = Progress1Builder::init()
    ->steps(
        [
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
            ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

