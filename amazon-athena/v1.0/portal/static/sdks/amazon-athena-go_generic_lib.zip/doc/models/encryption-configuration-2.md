
# Encryption Configuration 2

*This model accepts additional fields of type interface{}.*

## Structure

`EncryptionConfiguration2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EncryptionOption` | [`models.EncryptionOption1`](../../doc/models/encryption-option-1.md) | Required | - |
| `KmsKey` | `*string` | Optional | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    encryptionConfiguration2 := models.EncryptionConfiguration2{
        EncryptionOption:      models.EncryptionOption1_SseS3,
        KmsKey:                models.ToPointer("KmsKey2"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

