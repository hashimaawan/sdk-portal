
# List Application DPU Sizes Input

## Structure

`ListApplicationDPUSizesInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```csharp
using AmazonAthena.Standard.Models;

ListApplicationDPUSizesInput listApplicationDPUSizesInput = new ListApplicationDPUSizesInput
{
    MaxResults = 100,
    NextToken = "NextToken8",
};
```

