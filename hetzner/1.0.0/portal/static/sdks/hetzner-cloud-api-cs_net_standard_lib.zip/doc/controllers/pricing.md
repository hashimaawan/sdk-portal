# Pricing

Returns prices for resources.

```csharp
PricingApi pricingApi = client.PricingApi;
```

## Class Name

`PricingApi`


# Get All Prices

Returns prices for all resources available on the platform. VAT and currency of the Project owner are used for calculations.

Both net and gross prices are included in the response.

```csharp
GetAllPricesAsync()
```

## Response Type

**200**: The `pricing` key in the reply contains an pricing object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.PricingResponse](../../doc/models/pricing-response.md).

## Example Usage

```csharp
try
{
    ApiResponse<PricingResponse> result = await pricingApi.GetAllPricesAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
}
```

