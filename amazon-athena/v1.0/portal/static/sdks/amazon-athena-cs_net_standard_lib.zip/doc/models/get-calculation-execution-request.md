
# Get Calculation Execution Request

*This model accepts additional fields of type object.*

## Structure

`GetCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

GetCalculationExecutionRequest getCalculationExecutionRequest = new GetCalculationExecutionRequest
{
    CalculationExecutionId = "CalculationExecutionId2",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

