
# Work Group State 1 Enum

The state of the workgroup.

## Enumeration

`WorkGroupState1Enum`

## Fields

| Name |
|  --- |
| `ENABLED` |
| `DISABLED` |

## Example

```ts
import { WorkGroupState1Enum } from 'amazon-athenalib';

const workGroupState1 = WorkGroupState1Enum.ENABLED;
```

