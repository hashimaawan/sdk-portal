
# Os Flavor Enum

Flavor of operating system contained in the Image

## Enumeration

`OsFlavorEnum`

## Fields

| Name |
|  --- |
| `UBUNTU` |
| `CENTOS` |
| `DEBIAN` |
| `FEDORA` |
| `UNKNOWN` |

## Example

```php
use HetznerCloudAPILib\Models\OsFlavorEnum;

$osFlavor = OsFlavorEnum::DEBIAN;
```

