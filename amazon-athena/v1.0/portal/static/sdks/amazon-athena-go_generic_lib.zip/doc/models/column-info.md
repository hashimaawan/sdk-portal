
# Column Info

Information about the columns in a query execution result.

## Structure

`ColumnInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `*string` | Optional | - |
| `SchemaName` | `*string` | Optional | - |
| `TableName` | `*string` | Optional | - |
| `Name` | `string` | Required | - |
| `Label` | `*string` | Optional | - |
| `Type` | `string` | Required | - |
| `Precision` | `*int` | Optional | - |
| `Scale` | `*int` | Optional | - |
| `Nullable` | [`*models.ColumnNullable2Enum`](../../doc/models/column-nullable-2-enum.md) | Optional | - |
| `CaseSensitive` | `*bool` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    columnInfo := models.ColumnInfo{
        CatalogName:          models.ToPointer("CatalogName2"),
        SchemaName:           models.ToPointer("SchemaName2"),
        TableName:            models.ToPointer("TableName4"),
        Name:                 "Name8",
        Label:                models.ToPointer("Label6"),
        Type:                 "Type8",
        Precision:            models.ToPointer(196),
    }

}
```

