
# List Prepared Statements Input

## Structure

`ListPreparedStatementsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `work_group` | `String` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `max_results` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 50` |

## Example

```ruby
list_prepared_statements_input = ListPreparedStatementsInput.new(
  'WorkGroup2',
  'NextToken0',
  50
)
```

