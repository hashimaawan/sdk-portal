
# V2 Certificates Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2CertificatesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `certificates` | [`Certificate[] \| undefined`](../../doc/models/certificate.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2CertificatesResponse } from 'digitalocean-apilib';

const v2CertificatesResponse: V2CertificatesResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  certificates: [
    {
      createdAt: '2016-03-13T12:52:32.123Z',
      dnsNames: [
        'dns_names6'
      ],
      id: '000019c8-0000-0000-0000-000000000000',
      name: 'name0',
      notAfter: '2016-03-13T12:52:32.123Z',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      createdAt: '2016-03-13T12:52:32.123Z',
      dnsNames: [
        'dns_names6'
      ],
      id: '000019c8-0000-0000-0000-000000000000',
      name: 'name0',
      notAfter: '2016-03-13T12:52:32.123Z',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      createdAt: '2016-03-13T12:52:32.123Z',
      dnsNames: [
        'dns_names6'
      ],
      id: '000019c8-0000-0000-0000-000000000000',
      name: 'name0',
      notAfter: '2016-03-13T12:52:32.123Z',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

