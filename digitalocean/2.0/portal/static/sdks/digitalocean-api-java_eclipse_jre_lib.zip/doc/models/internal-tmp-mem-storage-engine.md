
# Internal Tmp Mem Storage Engine

The storage engine for in-memory internal temporary tables.

## Enumeration

`InternalTmpMemStorageEngine`

## Fields

| Name |
|  --- |
| `TEMPTABLE` |
| `MEMORY` |

## Example

```java
import com.digitalocean.api.models.InternalTmpMemStorageEngine;

InternalTmpMemStorageEngine internalTmpMemStorageEngine = InternalTmpMemStorageEngine.TEMPTABLE;
```

