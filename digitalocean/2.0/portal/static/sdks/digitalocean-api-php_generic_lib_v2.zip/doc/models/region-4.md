
# Region 4

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Region4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | A DigitalOcean region where Kubernetes is available. | getName(): ?string | setName(?string name): void |
| `slug` | `?string` | Optional | The identifier for a region for use when creating a new cluster. | getSlug(): ?string | setSlug(?string slug): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Region4Builder;
use DigitalOceanApiLib\ApiHelper;

$region4 = Region4Builder::init()
    ->name('New York 3')
    ->slug('nyc3')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

