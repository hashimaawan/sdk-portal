
# Get Calculation Execution Code Response

*This model accepts additional fields of type interface{}.*

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CodeBlock` | `*string` | Optional | **Constraints**: *Maximum Length*: `68000` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    getCalculationExecutionCodeResponse := models.GetCalculationExecutionCodeResponse{
        CodeBlock:             models.ToPointer("CodeBlock4"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

