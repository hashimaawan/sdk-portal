
# Stickers Random Response

## Structure

`StickersRandomResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Data` | [`Gif`](../../doc/models/gif.md) | Optional | - | Gif getData() | setData(Gif data) |
| `Meta` | [`Meta`](../../doc/models/meta.md) | Optional | The Meta Object contains basic information regarding the request, whether it was successful, and the response given by the API.  Check `responses` to see a description of types of response codes the API might give you under different cirumstances. | Meta getMeta() | setMeta(Meta meta) |

## Example

```java
import com.giphy.api.DateTimeHelper;
import com.giphy.api.models.Gif;
import com.giphy.api.models.Meta;
import com.giphy.api.models.StickersRandomResponse;
import java.util.Arrays;

StickersRandomResponse stickersRandomResponse = new StickersRandomResponse.Builder()
    .data(new Gif.Builder()
        .bitlyUrl("bitly_url0")
        .contentUrl("content_url4")
        .createDatetime(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .embdedUrl("embded_url8")
        .featuredTags(Arrays.asList(
            "featured_tags0"
        ))
        .build())
    .meta(new Meta.Builder()
        .msg("msg8")
        .responseId("response_id0")
        .status(98)
        .build())
    .build();
```

