
# V2 Firewalls Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FirewallsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firewalls` | [`Firewall[] \| undefined`](../../doc/models/firewall.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FirewallsResponse } from 'digitalocean-apilib';

const v2FirewallsResponse: V2FirewallsResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  firewalls: [
    {
      createdAt: '2016-03-13T12:52:32.123Z',
      dropletIds: [
        57
      ],
      id: 'id0',
      name: 'name0',
      pendingChanges: [
        {},
        {
        },
        {
        }
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

