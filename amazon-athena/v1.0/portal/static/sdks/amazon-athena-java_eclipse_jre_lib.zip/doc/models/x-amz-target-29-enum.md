
# X Amz Target 29 Enum

## Enumeration

`XAmzTarget29Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETWORKGROUP` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget29Enum;

XAmzTarget29Enum xAmzTarget29 = XAmzTarget29Enum.ENUM_AMAZONATHENAGETWORKGROUP;
```

