
# Track Commit Timestamp

Record commit time of transactions.

## Enumeration

`TrackCommitTimestamp`

## Fields

| Name |
|  --- |
| `OFF` |
| `ON` |

## Example

```python
from digitaloceanapi.models.track_commit_timestamp import TrackCommitTimestamp

track_commit_timestamp = TrackCommitTimestamp.OFF
```

