
# Remove from Resources Request

## Structure

`RemoveFromResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `removeFrom` | [`FirewallRemoveFromResources[]`](../../doc/models/firewall-remove-from-resources.md) | Required | Resources the Firewall should be removed from |

## Example

```ts
import { RemoveFromResourcesRequest, Type7Enum } from 'hetzner-cloud-apilib';

const removeFromResourcesRequest: RemoveFromResourcesRequest = {
  removeFrom: [
    {
      labelSelector: {
        selector: 'selector8',
      },
      server: {
        id: 14,
      },
      type: Type7Enum.Server,
    }
  ],
};
```

