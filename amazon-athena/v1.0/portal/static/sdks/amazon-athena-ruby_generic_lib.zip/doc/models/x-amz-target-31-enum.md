
# X Amz Target 31 Enum

## Enumeration

`XAmzTarget31Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES` |

## Example

```ruby
x_amz_target31 = XAmzTarget31Enum::ENUM_AMAZONATHENALISTAPPLICATIONDPUSIZES
```

