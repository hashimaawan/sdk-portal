
# X Amz Target 54

## Enumeration

`XAmzTarget54`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEDATACATALOG` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget54;

$xAmzTarget54 = XAmzTarget54::ENUM_AMAZONATHENAUPDATEDATACATALOG;
```

