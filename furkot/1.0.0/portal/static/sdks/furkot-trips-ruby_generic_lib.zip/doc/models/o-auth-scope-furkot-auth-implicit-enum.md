
# O Auth Scope Furkot Auth Implicit Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeFurkotAuthImplicitEnum`

## Fields

| Name | Description |
|  --- | --- |
| `READTRIPS` | list users trips info |

## Example

```ruby
o_auth_scope_furkot_auth_implicit = OAuthScopeFurkotAuthImplicitEnum::READTRIPS
```

