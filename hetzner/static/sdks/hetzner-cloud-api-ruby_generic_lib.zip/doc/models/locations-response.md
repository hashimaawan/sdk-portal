
# Locations Response

## Structure

`LocationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `locations` | [`Array[Location]`](../../doc/models/location.md) | Required | - |

## Example

```ruby
locations_response = LocationsResponse.new(
  [
    Location.new(
      'Falkenstein',
      'DE',
      'Falkenstein DC Park 1',
      1,
      50.47612,
      12.370071,
      'fsn1',
      'eu-central'
    )
  ]
)
```

