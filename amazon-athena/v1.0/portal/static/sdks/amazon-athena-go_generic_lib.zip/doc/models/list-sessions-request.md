
# List Sessions Request

## Structure

`ListSessionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WorkGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `StateFilter` | [`*models.SessionState3Enum`](../../doc/models/session-state-3-enum.md) | Optional | - |
| `MaxResults` | `*int` | Optional | **Constraints**: `>= 1`, `<= 100` |
| `NextToken` | `*string` | Optional | **Constraints**: *Maximum Length*: `2048` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    listSessionsRequest := models.ListSessionsRequest{
        WorkGroup:            "WorkGroup8",
        StateFilter:          models.ToPointer(models.SessionState3Enum_CREATING),
        MaxResults:           models.ToPointer(100),
        NextToken:            models.ToPointer("NextToken6"),
    }

}
```

