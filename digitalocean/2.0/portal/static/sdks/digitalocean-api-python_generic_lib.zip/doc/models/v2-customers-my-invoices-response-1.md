
# V2 Customers My Invoices Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2CustomersMyInvoicesResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `invoice_items` | [`List[InvoiceItem]`](../../doc/models/invoice-item.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.invoice_item import InvoiceItem
from digitaloceanapi.models.links import Links
from digitaloceanapi.models.meta import Meta
from digitaloceanapi.models.pages import Pages
from digitaloceanapi.models.v_2_customers_my_invoices_response_1 import V2CustomersMyInvoicesResponse1

v_2_customers_my_invoices_response_1 = V2CustomersMyInvoicesResponse1(
    meta=Meta(
        total=6,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    invoice_items=[
        InvoiceItem(
            amount='12.34',
            description='a56e086a317d8410c8b4cfd1f4dc9f82',
            duration='744',
            duration_unit='Hours',
            end_time='2020-02-01T00:00:00Z',
            group_description='my-doks-cluster',
            product='Kubernetes Clusters',
            resource_uuid='711157cb-37c8-4817-b371-44fa3504a39c',
            start_time='2020-01-01T00:00:00Z',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        InvoiceItem(
            amount='34.45',
            description='Spaces ($5/mo 250GB storage & 1TB bandwidth)',
            duration='744',
            duration_unit='Hours',
            end_time='2020-02-01T00:00:00Z',
            product='Spaces Subscription',
            start_time='2020-01-01T00:00:00Z',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    links=Links(
        pages=Pages(
            last='https://api.digitalocean.com/v2/customers/my/invoices/22737513-0ea7-4206-8ceb-98a575af7681?page=3&per_page=2',
            next='https://api.digitalocean.com/v2/customers/my/invoices/22737513-0ea7-4206-8ceb-98a575af7681?page=2&per_page=2',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

