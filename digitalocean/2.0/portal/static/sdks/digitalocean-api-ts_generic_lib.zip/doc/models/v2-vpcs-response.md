
# V2 Vpcs Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2VpcsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpcs` | [`Vpc[] \| undefined`](../../doc/models/vpc.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2VpcsResponse } from 'digitalocean-apilib';

const v2VpcsResponse: V2VpcsResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  vpcs: [
    {
      description: 'description8',
      name: 'name2',
      ipRange: 'ip_range4',
      region: 'region8',
      mDefault: false,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

