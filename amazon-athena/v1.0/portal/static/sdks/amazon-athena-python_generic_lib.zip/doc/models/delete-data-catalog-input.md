
# Delete Data Catalog Input

## Structure

`DeleteDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```python
from amazonathena.models.delete_data_catalog_input import DeleteDataCatalogInput

delete_data_catalog_input = DeleteDataCatalogInput(
    name='Name2'
)
```

