
# X Amz Target 25

## Enumeration

`XAmzTarget25`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget25;

$xAmzTarget25 = XAmzTarget25::ENUM_AMAZONATHENAGETQUERYRUNTIMESTATISTICS;
```

