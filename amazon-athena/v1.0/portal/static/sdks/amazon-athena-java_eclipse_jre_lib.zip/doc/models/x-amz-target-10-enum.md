
# X Amz Target 10 Enum

## Enumeration

`XAmzTarget10Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETENAMEDQUERY` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget10Enum;

XAmzTarget10Enum xAmzTarget10 = XAmzTarget10Enum.ENUM_AMAZONATHENADELETENAMEDQUERY;
```

