
# Type 51

Primary IP type

## Enumeration

`Type51`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```java
import cloud.hetzner.api.models.Type51;

Type51 type51 = Type51.IPV4;
```

