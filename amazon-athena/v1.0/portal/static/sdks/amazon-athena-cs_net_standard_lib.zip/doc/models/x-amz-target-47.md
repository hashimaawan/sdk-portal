
# X Amz Target 47

## Enumeration

`XAmzTarget47`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartQueryExecution` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget47 xAmzTarget47 = XAmzTarget47.EnumAmazonAthenaStartQueryExecution;
```

