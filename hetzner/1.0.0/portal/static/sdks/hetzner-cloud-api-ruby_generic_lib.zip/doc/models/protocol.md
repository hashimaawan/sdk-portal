
# Protocol

Type of traffic to allow

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |
| `ESP` |
| `GRE` |

## Example

```ruby
protocol = Protocol::ESP
```

