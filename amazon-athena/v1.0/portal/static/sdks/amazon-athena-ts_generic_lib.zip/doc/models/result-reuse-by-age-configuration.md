
# Result Reuse by Age Configuration

Specifies whether previous query results are reused, and if so, their maximum age.

*This model accepts additional fields of type unknown.*

## Structure

`ResultReuseByAgeConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enabled` | `boolean` | Required | - |
| `maxAgeInMinutes` | `number \| undefined` | Optional | **Constraints**: `>= 0`, `<= 10080` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ResultReuseByAgeConfiguration } from 'amazon-athenalib';

const resultReuseByAgeConfiguration: ResultReuseByAgeConfiguration = {
  enabled: false,
  maxAgeInMinutes: 134,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

