
# Type

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `Item` |
| `Vault` |

## Example

```ts
import { Type } from 'm-1-password-connectlib';

const type = Type.Item;
```

