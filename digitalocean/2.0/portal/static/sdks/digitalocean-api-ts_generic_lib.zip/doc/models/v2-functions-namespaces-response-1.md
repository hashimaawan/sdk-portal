
# V2 Functions Namespaces Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace` | [`Namespace \| undefined`](../../doc/models/namespace.md) | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FunctionsNamespacesResponse1 } from 'digitalocean-apilib';

const v2FunctionsNamespacesResponse1: V2FunctionsNamespacesResponse1 = {
  namespace: {
    apiHost: 'api_host2',
    createdAt: 'created_at0',
    key: 'key2',
    label: 'label2',
    namespace: 'namespace0',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

