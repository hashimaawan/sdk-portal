
# Type 29

Type of the resource

## Enumeration

`Type29`

## Fields

| Name |
|  --- |
| `SERVER` |
| `LABEL_SELECTOR` |
| `IP` |

## Example

```java
import cloud.hetzner.api.models.Type29;

Type29 type29 = Type29.SERVER;
```

