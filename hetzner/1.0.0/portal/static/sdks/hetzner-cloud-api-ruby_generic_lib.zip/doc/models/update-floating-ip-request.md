
# Update Floating Ip Request

*This model accepts additional fields of type Object.*

## Structure

`UpdateFloatingIpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `String` | Optional | New Description to set |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New unique name to set |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
update_floating_ip_request = UpdateFloatingIpRequest.new(
  description: 'Web Frontend',
  labels: { 'labelkey' => 'value' },
  name: 'Web Frontend',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

