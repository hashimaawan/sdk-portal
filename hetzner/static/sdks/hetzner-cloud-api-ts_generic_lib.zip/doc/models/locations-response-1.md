
# Locations Response 1

## Structure

`LocationsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `location` | [`Location`](../../doc/models/location.md) | Required | - |

## Example

```ts
import { LocationsResponse1 } from 'hetzner-cloud-apilib';

const locationsResponse1: LocationsResponse1 = {
  location: {
    city: 'Falkenstein',
    country: 'DE',
    description: 'Falkenstein DC Park 1',
    id: 1,
    latitude: 50.47612,
    longitude: 12.370071,
    name: 'fsn1',
    networkZone: 'eu-central',
  },
};
```

