
# V2 Databases Users Response 1

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesUsersResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user` | [`User`](../../doc/models/user.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  AuthPlugin,
  Role,
  V2DatabasesUsersResponse1,
} from 'digitalocean-apilib';

const v2DatabasesUsersResponse1: V2DatabasesUsersResponse1 = {
  user: {
    name: 'app-01',
    mysqlSettings: {
      authPlugin: AuthPlugin.MysqlNativePassword,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    password: 'jge5lfxtzhx42iff',
    role: Role.Normal,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

