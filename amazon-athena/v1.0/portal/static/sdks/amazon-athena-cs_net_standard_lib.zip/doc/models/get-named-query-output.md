
# Get Named Query Output

*This model accepts additional fields of type object.*

## Structure

`GetNamedQueryOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQuery` | [`NamedQuery1`](../../doc/models/named-query-1.md) | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

GetNamedQueryOutput getNamedQueryOutput = new GetNamedQueryOutput
{
    NamedQuery = new NamedQuery1
    {
        Name = "Name0",
        Database = "Database8",
        QueryString = "QueryString2",
        Description = "Description6",
        NamedQueryId = "NamedQueryId2",
        WorkGroup = "WorkGroup2",
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

