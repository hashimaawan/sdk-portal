
# Get Calculation Execution Status Request

## Structure

`GetCalculationExecutionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```ts
import { GetCalculationExecutionStatusRequest } from 'amazon-athenalib';

const getCalculationExecutionStatusRequest: GetCalculationExecutionStatusRequest = {
  calculationExecutionId: 'CalculationExecutionId8',
};
```

