
# Album Type

The type of the album.

## Enumeration

`AlbumType`

## Fields

| Name |
|  --- |
| `Album` |
| `Single` |
| `Compilation` |

## Example

```ts
import {
  AlbumType,
} from 'spotify-web-api-with-fixes-and-improvements-from-sonalluxlib';

const albumType = AlbumType.Compilation;
```

