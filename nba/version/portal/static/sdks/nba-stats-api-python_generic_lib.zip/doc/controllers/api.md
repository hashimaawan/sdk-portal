# API

```python
client_controller = client.client
```

## Class Name

`APIController`

## Methods

* [Allstarballotpredictor GET](../../doc/controllers/api.md#allstarballotpredictor-get)
* [Boxscore GET](../../doc/controllers/api.md#boxscore-get)
* [Boxscoreadvanced GET](../../doc/controllers/api.md#boxscoreadvanced-get)
* [Boxscoreadvancedv 2 GET](../../doc/controllers/api.md#boxscoreadvancedv-2-get)
* [Boxscorefourfactors GET](../../doc/controllers/api.md#boxscorefourfactors-get)
* [Boxscorefourfactorsv 2 GET](../../doc/controllers/api.md#boxscorefourfactorsv-2-get)
* [Boxscoremisc GET](../../doc/controllers/api.md#boxscoremisc-get)
* [Boxscoremiscv 2 GET](../../doc/controllers/api.md#boxscoremiscv-2-get)
* [Boxscoreplayertrackv 2 GET](../../doc/controllers/api.md#boxscoreplayertrackv-2-get)
* [Boxscorescoring GET](../../doc/controllers/api.md#boxscorescoring-get)
* [Boxscorescoringv 2 GET](../../doc/controllers/api.md#boxscorescoringv-2-get)
* [Boxscoresummaryv 2 GET](../../doc/controllers/api.md#boxscoresummaryv-2-get)
* [Boxscoretraditionalv 2 GET](../../doc/controllers/api.md#boxscoretraditionalv-2-get)
* [Boxscoreusage GET](../../doc/controllers/api.md#boxscoreusage-get)
* [Boxscoreusagev 2 GET](../../doc/controllers/api.md#boxscoreusagev-2-get)
* [Common Team Years GET](../../doc/controllers/api.md#common-team-years-get)
* [Commonallplayers GET](../../doc/controllers/api.md#commonallplayers-get)
* [Commonplayerinfo GET](../../doc/controllers/api.md#commonplayerinfo-get)
* [Commonplayoffseries GET](../../doc/controllers/api.md#commonplayoffseries-get)
* [Commonteamroster GET](../../doc/controllers/api.md#commonteamroster-get)
* [Draftcombinedrillresults GET](../../doc/controllers/api.md#draftcombinedrillresults-get)
* [Draftcombinenonstationaryshooting GET](../../doc/controllers/api.md#draftcombinenonstationaryshooting-get)
* [Draftcombineplayeranthro GET](../../doc/controllers/api.md#draftcombineplayeranthro-get)
* [Draftcombinespotshooting GET](../../doc/controllers/api.md#draftcombinespotshooting-get)
* [Draftcombinestats GET](../../doc/controllers/api.md#draftcombinestats-get)
* [Drafthistory GET](../../doc/controllers/api.md#drafthistory-get)
* [Franchisehistory GET](../../doc/controllers/api.md#franchisehistory-get)
* [Homepageleaders GET](../../doc/controllers/api.md#homepageleaders-get)
* [Homepagev 2 GET](../../doc/controllers/api.md#homepagev-2-get)
* [Leaderstiles GET](../../doc/controllers/api.md#leaderstiles-get)
* [Leaguedashlineups GET](../../doc/controllers/api.md#leaguedashlineups-get)
* [Leaguedashplayerbiostats GET](../../doc/controllers/api.md#leaguedashplayerbiostats-get)
* [Leaguedashplayerclutch GET](../../doc/controllers/api.md#leaguedashplayerclutch-get)
* [Leaguedashplayerptshot GET](../../doc/controllers/api.md#leaguedashplayerptshot-get)
* [Leaguedashplayershotlocations GET](../../doc/controllers/api.md#leaguedashplayershotlocations-get)
* [Leaguedashplayerstats GET](../../doc/controllers/api.md#leaguedashplayerstats-get)
* [Leaguedashptdefend GET](../../doc/controllers/api.md#leaguedashptdefend-get)
* [Leaguedashptteamdefend GET](../../doc/controllers/api.md#leaguedashptteamdefend-get)
* [Leaguedashteamclutch GET](../../doc/controllers/api.md#leaguedashteamclutch-get)
* [Leaguedashteamptshot GET](../../doc/controllers/api.md#leaguedashteamptshot-get)
* [Leaguedashteamshotlocations GET](../../doc/controllers/api.md#leaguedashteamshotlocations-get)
* [Leaguedashteamstats GET](../../doc/controllers/api.md#leaguedashteamstats-get)
* [Leagueleaders GET](../../doc/controllers/api.md#leagueleaders-get)
* [Playbyplay GET](../../doc/controllers/api.md#playbyplay-get)
* [Playbyplayv 2 GET](../../doc/controllers/api.md#playbyplayv-2-get)
* [Playercareerstats GET](../../doc/controllers/api.md#playercareerstats-get)
* [Playercompare GET](../../doc/controllers/api.md#playercompare-get)
* [Playerdashboardbyclutch GET](../../doc/controllers/api.md#playerdashboardbyclutch-get)
* [Playerdashboardbygamesplits GET](../../doc/controllers/api.md#playerdashboardbygamesplits-get)
* [Playerdashboardbygeneralsplits GET](../../doc/controllers/api.md#playerdashboardbygeneralsplits-get)
* [Playerdashboardbylastngames GET](../../doc/controllers/api.md#playerdashboardbylastngames-get)
* [Playerdashboardbyopponent GET](../../doc/controllers/api.md#playerdashboardbyopponent-get)
* [Playerdashboardbyshootingsplits GET](../../doc/controllers/api.md#playerdashboardbyshootingsplits-get)
* [Playerdashboardbyteamperformance GET](../../doc/controllers/api.md#playerdashboardbyteamperformance-get)
* [Playerdashboardbyyearoveryear GET](../../doc/controllers/api.md#playerdashboardbyyearoveryear-get)
* [Playerdashptpass GET](../../doc/controllers/api.md#playerdashptpass-get)
* [Playerdashptreb GET](../../doc/controllers/api.md#playerdashptreb-get)
* [Playerdashptreboundlogs GET](../../doc/controllers/api.md#playerdashptreboundlogs-get)
* [Playerdashptshotdefend GET](../../doc/controllers/api.md#playerdashptshotdefend-get)
* [Playerdashptshotlog GET](../../doc/controllers/api.md#playerdashptshotlog-get)
* [Playerdashptshots GET](../../doc/controllers/api.md#playerdashptshots-get)
* [Playergamelog GET](../../doc/controllers/api.md#playergamelog-get)
* [Playerprofile GET](../../doc/controllers/api.md#playerprofile-get)
* [Playerprofilev 2 GET](../../doc/controllers/api.md#playerprofilev-2-get)
* [Playersvsplayers GET](../../doc/controllers/api.md#playersvsplayers-get)
* [Playervsplayer GET](../../doc/controllers/api.md#playervsplayer-get)
* [Playoffpicture GET](../../doc/controllers/api.md#playoffpicture-get)
* [Scoreboard GET](../../doc/controllers/api.md#scoreboard-get)
* [Scoreboard V2 GET](../../doc/controllers/api.md#scoreboard-v2-get)
* [Shotchartdetail GET](../../doc/controllers/api.md#shotchartdetail-get)
* [Shotchartlineupdetail GET](../../doc/controllers/api.md#shotchartlineupdetail-get)
* [Teamdashboardbyclutch GET](../../doc/controllers/api.md#teamdashboardbyclutch-get)
* [Teamdashboardbygamesplits GET](../../doc/controllers/api.md#teamdashboardbygamesplits-get)
* [Teamdashboardbygeneralsplits GET](../../doc/controllers/api.md#teamdashboardbygeneralsplits-get)
* [Teamdashboardbylastngames GET](../../doc/controllers/api.md#teamdashboardbylastngames-get)
* [Teamdashboardbyopponent GET](../../doc/controllers/api.md#teamdashboardbyopponent-get)
* [Teamdashboardbyshootingsplits GET](../../doc/controllers/api.md#teamdashboardbyshootingsplits-get)
* [Teamdashboardbyteamperformance GET](../../doc/controllers/api.md#teamdashboardbyteamperformance-get)
* [Teamdashboardbyyearoveryear GET](../../doc/controllers/api.md#teamdashboardbyyearoveryear-get)
* [Teamdashlineups GET](../../doc/controllers/api.md#teamdashlineups-get)
* [Teamdashptpass GET](../../doc/controllers/api.md#teamdashptpass-get)
* [Teamdashptreb GET](../../doc/controllers/api.md#teamdashptreb-get)
* [Teamdashptshots GET](../../doc/controllers/api.md#teamdashptshots-get)
* [Teamgamelog GET](../../doc/controllers/api.md#teamgamelog-get)
* [Teaminfocommon GET](../../doc/controllers/api.md#teaminfocommon-get)
* [Teamplayerdashboard GET](../../doc/controllers/api.md#teamplayerdashboard-get)
* [Teamplayeronoffdetails GET](../../doc/controllers/api.md#teamplayeronoffdetails-get)
* [Teamplayeronoffsummary GET](../../doc/controllers/api.md#teamplayeronoffsummary-get)
* [Teamvsplayer GET](../../doc/controllers/api.md#teamvsplayer-get)
* [Teamyearbyyearstats GET](../../doc/controllers/api.md#teamyearbyyearstats-get)
* [Video Status GET](../../doc/controllers/api.md#video-status-get)


# Allstarballotpredictor GET

```python
def allstarballotpredictor_get(self,
                              west_player_1,
                              west_player_2,
                              west_player_3,
                              west_player_4,
                              west_player_5,
                              east_player_1,
                              east_player_2,
                              east_player_3,
                              east_player_4,
                              east_player_5,
                              point_cap=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `west_player_1` | `str` | Query, Required | - |
| `west_player_2` | `str` | Query, Required | - |
| `west_player_3` | `str` | Query, Required | - |
| `west_player_4` | `str` | Query, Required | - |
| `west_player_5` | `str` | Query, Required | - |
| `east_player_1` | `str` | Query, Required | - |
| `east_player_2` | `str` | Query, Required | - |
| `east_player_3` | `str` | Query, Required | - |
| `east_player_4` | `str` | Query, Required | - |
| `east_player_5` | `str` | Query, Required | - |
| `point_cap` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
west_player_1 = 'WestPlayer10'

west_player_2 = 'WestPlayer24'

west_player_3 = 'WestPlayer32'

west_player_4 = 'WestPlayer48'

west_player_5 = 'WestPlayer56'

east_player_1 = 'EastPlayer18'

east_player_2 = 'EastPlayer26'

east_player_3 = 'EastPlayer32'

east_player_4 = 'EastPlayer44'

east_player_5 = 'EastPlayer54'

client_controller.allstarballotpredictor_get(
    west_player_1,
    west_player_2,
    west_player_3,
    west_player_4,
    west_player_5,
    east_player_1,
    east_player_2,
    east_player_3,
    east_player_4,
    east_player_5
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscore GET

```python
def boxscore_get(self,
                game_id=None,
                start_period=None,
                end_period=None,
                start_range=None,
                end_range=None,
                range_type=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Optional | - |
| `start_period` | `str` | Query, Optional | - |
| `end_period` | `str` | Query, Optional | - |
| `start_range` | `str` | Query, Optional | - |
| `end_range` | `str` | Query, Optional | - |
| `range_type` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
client_controller.boxscore_get()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreadvanced GET

```python
def boxscoreadvanced_get(self,
                        game_id=None,
                        start_period=None,
                        end_period=None,
                        start_range=None,
                        end_range=None,
                        range_type=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Optional | - |
| `start_period` | `str` | Query, Optional | - |
| `end_period` | `str` | Query, Optional | - |
| `start_range` | `str` | Query, Optional | - |
| `end_range` | `str` | Query, Optional | - |
| `range_type` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
client_controller.boxscoreadvanced_get()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreadvancedv 2 GET

```python
def boxscoreadvancedv_2_get(self,
                           game_id,
                           start_period,
                           end_period,
                           start_range,
                           end_range,
                           range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |
| `start_period` | `str` | Query, Required | - |
| `end_period` | `str` | Query, Required | - |
| `start_range` | `str` | Query, Required | - |
| `end_range` | `str` | Query, Required | - |
| `range_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscoreadvancedv_2_get(
    game_id,
    start_period,
    end_period,
    start_range,
    end_range,
    range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscorefourfactors GET

```python
def boxscorefourfactors_get(self,
                           game_id=None,
                           start_period=None,
                           end_period=None,
                           start_range=None,
                           end_range=None,
                           range_type=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Optional | - |
| `start_period` | `str` | Query, Optional | - |
| `end_period` | `str` | Query, Optional | - |
| `start_range` | `str` | Query, Optional | - |
| `end_range` | `str` | Query, Optional | - |
| `range_type` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
client_controller.boxscorefourfactors_get()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscorefourfactorsv 2 GET

```python
def boxscorefourfactorsv_2_get(self,
                              game_id,
                              start_period,
                              end_period,
                              start_range,
                              end_range,
                              range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |
| `start_period` | `str` | Query, Required | - |
| `end_period` | `str` | Query, Required | - |
| `start_range` | `str` | Query, Required | - |
| `end_range` | `str` | Query, Required | - |
| `range_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscorefourfactorsv_2_get(
    game_id,
    start_period,
    end_period,
    start_range,
    end_range,
    range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoremisc GET

```python
def boxscoremisc_get(self,
                    game_id=None,
                    start_period=None,
                    end_period=None,
                    start_range=None,
                    end_range=None,
                    range_type=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Optional | - |
| `start_period` | `str` | Query, Optional | - |
| `end_period` | `str` | Query, Optional | - |
| `start_range` | `str` | Query, Optional | - |
| `end_range` | `str` | Query, Optional | - |
| `range_type` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
client_controller.boxscoremisc_get()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoremiscv 2 GET

```python
def boxscoremiscv_2_get(self,
                       game_id,
                       start_period,
                       end_period,
                       start_range,
                       end_range,
                       range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |
| `start_period` | `str` | Query, Required | - |
| `end_period` | `str` | Query, Required | - |
| `start_range` | `str` | Query, Required | - |
| `end_range` | `str` | Query, Required | - |
| `range_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscoremiscv_2_get(
    game_id,
    start_period,
    end_period,
    start_range,
    end_range,
    range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreplayertrackv 2 GET

```python
def boxscoreplayertrackv_2_get(self,
                              game_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

client_controller.boxscoreplayertrackv_2_get(game_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscorescoring GET

```python
def boxscorescoring_get(self,
                       game_id=None,
                       start_period=None,
                       end_period=None,
                       start_range=None,
                       end_range=None,
                       range_type=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Optional | - |
| `start_period` | `str` | Query, Optional | - |
| `end_period` | `str` | Query, Optional | - |
| `start_range` | `str` | Query, Optional | - |
| `end_range` | `str` | Query, Optional | - |
| `range_type` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
client_controller.boxscorescoring_get()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscorescoringv 2 GET

```python
def boxscorescoringv_2_get(self,
                          game_id,
                          start_period,
                          end_period,
                          start_range,
                          end_range,
                          range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |
| `start_period` | `str` | Query, Required | - |
| `end_period` | `str` | Query, Required | - |
| `start_range` | `str` | Query, Required | - |
| `end_range` | `str` | Query, Required | - |
| `range_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscorescoringv_2_get(
    game_id,
    start_period,
    end_period,
    start_range,
    end_range,
    range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoresummaryv 2 GET

```python
def boxscoresummaryv_2_get(self,
                          game_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

client_controller.boxscoresummaryv_2_get(game_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoretraditionalv 2 GET

```python
def boxscoretraditionalv_2_get(self,
                              game_id,
                              start_period,
                              end_period,
                              start_range,
                              end_range,
                              range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |
| `start_period` | `str` | Query, Required | - |
| `end_period` | `str` | Query, Required | - |
| `start_range` | `str` | Query, Required | - |
| `end_range` | `str` | Query, Required | - |
| `range_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscoretraditionalv_2_get(
    game_id,
    start_period,
    end_period,
    start_range,
    end_range,
    range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreusage GET

```python
def boxscoreusage_get(self,
                     game_id=None,
                     start_period=None,
                     end_period=None,
                     start_range=None,
                     end_range=None,
                     range_type=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Optional | - |
| `start_period` | `str` | Query, Optional | - |
| `end_period` | `str` | Query, Optional | - |
| `start_range` | `str` | Query, Optional | - |
| `end_range` | `str` | Query, Optional | - |
| `range_type` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
client_controller.boxscoreusage_get()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Boxscoreusagev 2 GET

```python
def boxscoreusagev_2_get(self,
                        game_id,
                        start_period,
                        end_period,
                        start_range,
                        end_range,
                        range_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |
| `start_period` | `str` | Query, Required | - |
| `end_period` | `str` | Query, Required | - |
| `start_range` | `str` | Query, Required | - |
| `end_range` | `str` | Query, Required | - |
| `range_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

start_range = 'StartRange0'

end_range = 'EndRange2'

range_type = 'RangeType0'

client_controller.boxscoreusagev_2_get(
    game_id,
    start_period,
    end_period,
    start_range,
    end_range,
    range_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Common Team Years GET

```python
def common_team_years_get(self,
                         league_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

client_controller.common_team_years_get(league_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Commonallplayers GET

```python
def commonallplayers_get(self,
                        league_id,
                        season,
                        is_only_current_season)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `is_only_current_season` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season = 'Season0'

is_only_current_season = 'IsOnlyCurrentSeason6'

client_controller.commonallplayers_get(
    league_id,
    season,
    is_only_current_season
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Commonplayerinfo GET

```python
def commonplayerinfo_get(self,
                        player_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
player_id = 'PlayerID6'

client_controller.commonplayerinfo_get(player_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Commonplayoffseries GET

```python
def commonplayoffseries_get(self,
                           league_id,
                           season)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season = 'Season0'

client_controller.commonplayoffseries_get(
    league_id,
    season
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Commonteamroster GET

```python
def commonteamroster_get(self,
                        season,
                        team_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
season = 'Season0'

team_id = 'TeamID8'

client_controller.commonteamroster_get(
    season,
    team_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombinedrillresults GET

```python
def draftcombinedrillresults_get(self,
                                league_id,
                                season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season_year` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombinedrillresults_get(
    league_id,
    season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombinenonstationaryshooting GET

```python
def draftcombinenonstationaryshooting_get(self,
                                         league_id,
                                         season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season_year` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombinenonstationaryshooting_get(
    league_id,
    season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombineplayeranthro GET

```python
def draftcombineplayeranthro_get(self,
                                league_id,
                                season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season_year` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombineplayeranthro_get(
    league_id,
    season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombinespotshooting GET

```python
def draftcombinespotshooting_get(self,
                                league_id,
                                season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season_year` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombinespotshooting_get(
    league_id,
    season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Draftcombinestats GET

```python
def draftcombinestats_get(self,
                         league_id,
                         season_year)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season_year` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season_year = 'SeasonYear6'

client_controller.draftcombinestats_get(
    league_id,
    season_year
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Drafthistory GET

```python
def drafthistory_get(self,
                    league_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

client_controller.drafthistory_get(league_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Franchisehistory GET

```python
def franchisehistory_get(self,
                        league_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

client_controller.franchisehistory_get(league_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Homepageleaders GET

```python
def homepageleaders_get(self,
                       stat_category,
                       league_id,
                       season,
                       season_type,
                       player_or_team,
                       player_scope,
                       game_scope,
                       game=None,
                       player=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stat_category` | `str` | Query, Required | - |
| `league_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_or_team` | `str` | Query, Required | - |
| `player_scope` | `str` | Query, Required | - |
| `game_scope` | `str` | Query, Required | - |
| `game` | `str` | Query, Optional | - |
| `player` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
stat_category = 'StatCategory6'

league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

player_or_team = 'PlayerOrTeam8'

player_scope = 'PlayerScope2'

game_scope = 'GameScope0'

client_controller.homepageleaders_get(
    stat_category,
    league_id,
    season,
    season_type,
    player_or_team,
    player_scope,
    game_scope
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Homepagev 2 GET

```python
def homepagev_2_get(self,
                   stat_type,
                   league_id,
                   season,
                   season_type,
                   player_or_team,
                   player_scope,
                   game_scope,
                   game=None,
                   player=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stat_type` | `str` | Query, Required | - |
| `league_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_or_team` | `str` | Query, Required | - |
| `player_scope` | `str` | Query, Required | - |
| `game_scope` | `str` | Query, Required | - |
| `game` | `str` | Query, Optional | - |
| `player` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
stat_type = 'StatType8'

league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

player_or_team = 'PlayerOrTeam8'

player_scope = 'PlayerScope2'

game_scope = 'GameScope0'

client_controller.homepagev_2_get(
    stat_type,
    league_id,
    season,
    season_type,
    player_or_team,
    player_scope,
    game_scope
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaderstiles GET

```python
def leaderstiles_get(self,
                    stat,
                    league_id,
                    season,
                    season_type,
                    player_or_team,
                    player_scope,
                    game_scope,
                    game=None,
                    player=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `stat` | `str` | Query, Required | - |
| `league_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_or_team` | `str` | Query, Required | - |
| `player_scope` | `str` | Query, Required | - |
| `game_scope` | `str` | Query, Required | - |
| `game` | `str` | Query, Optional | - |
| `player` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
stat = 'Stat2'

league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

player_or_team = 'PlayerOrTeam8'

player_scope = 'PlayerScope2'

game_scope = 'GameScope0'

client_controller.leaderstiles_get(
    stat,
    league_id,
    season,
    season_type,
    player_or_team,
    player_scope,
    game_scope
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashlineups GET

```python
def leaguedashlineups_get(self,
                         group_quantity,
                         season_type,
                         measure_type,
                         per_mode,
                         plus_minus,
                         pace_adjust,
                         rank,
                         season,
                         outcome,
                         location,
                         month,
                         season_segment,
                         date_from,
                         date_to,
                         opponent_team_id,
                         vs_conference,
                         vs_division,
                         game_segment,
                         period,
                         last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `group_quantity` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
group_quantity = 'GroupQuantity0'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashlineups_get(
    group_quantity,
    season_type,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayerbiostats GET

```python
def leaguedashplayerbiostats_get(self,
                                per_mode,
                                league_id,
                                season,
                                season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `league_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.leaguedashplayerbiostats_get(
    per_mode,
    league_id,
    season,
    season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayerclutch GET

```python
def leaguedashplayerclutch_get(self,
                              clutch_time,
                              ahead_behind,
                              point_diff,
                              game_scope,
                              player_experience,
                              player_position,
                              starter_bench,
                              measure_type,
                              per_mode,
                              plus_minus,
                              pace_adjust,
                              rank,
                              season,
                              season_type,
                              outcome,
                              location,
                              month,
                              season_segment,
                              date_from,
                              date_to,
                              opponent_team_id,
                              vs_conference,
                              vs_division,
                              game_segment,
                              period,
                              last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clutch_time` | `str` | Query, Required | - |
| `ahead_behind` | `str` | Query, Required | - |
| `point_diff` | `str` | Query, Required | - |
| `game_scope` | `str` | Query, Required | - |
| `player_experience` | `str` | Query, Required | - |
| `player_position` | `str` | Query, Required | - |
| `starter_bench` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
clutch_time = 'ClutchTime4'

ahead_behind = 'AheadBehind8'

point_diff = 'PointDiff6'

game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashplayerclutch_get(
    clutch_time,
    ahead_behind,
    point_diff,
    game_scope,
    player_experience,
    player_position,
    starter_bench,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayerptshot GET

```python
def leaguedashplayerptshot_get(self,
                              league_id,
                              per_mode,
                              season,
                              season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.leaguedashplayerptshot_get(
    league_id,
    per_mode,
    season,
    season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayershotlocations GET

```python
def leaguedashplayershotlocations_get(self,
                                     measure_type,
                                     per_mode,
                                     plus_minus,
                                     pace_adjust,
                                     rank,
                                     season,
                                     season_type,
                                     outcome,
                                     location,
                                     month,
                                     season_segment,
                                     date_from,
                                     date_to,
                                     opponent_team_id,
                                     vs_conference,
                                     vs_division,
                                     game_segment,
                                     period,
                                     last_n_games,
                                     distance_range,
                                     game_scope,
                                     player_experience,
                                     player_position,
                                     starter_bench)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |
| `distance_range` | `str` | Query, Required | - |
| `game_scope` | `str` | Query, Required | - |
| `player_experience` | `str` | Query, Required | - |
| `player_position` | `str` | Query, Required | - |
| `starter_bench` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

distance_range = 'DistanceRange6'

game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

client_controller.leaguedashplayershotlocations_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games,
    distance_range,
    game_scope,
    player_experience,
    player_position,
    starter_bench
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashplayerstats GET

```python
def leaguedashplayerstats_get(self,
                             game_scope,
                             player_experience,
                             player_position,
                             starter_bench,
                             measure_type,
                             per_mode,
                             plus_minus,
                             pace_adjust,
                             rank,
                             season,
                             season_type,
                             outcome,
                             location,
                             month,
                             season_segment,
                             date_from,
                             date_to,
                             opponent_team_id,
                             vs_conference,
                             vs_division,
                             game_segment,
                             period,
                             last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_scope` | `str` | Query, Required | - |
| `player_experience` | `str` | Query, Required | - |
| `player_position` | `str` | Query, Required | - |
| `starter_bench` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashplayerstats_get(
    game_scope,
    player_experience,
    player_position,
    starter_bench,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashptdefend GET

```python
def leaguedashptdefend_get(self,
                          league_id,
                          per_mode,
                          season,
                          season_type,
                          defense_category)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `defense_category` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

defense_category = 'DefenseCategory0'

client_controller.leaguedashptdefend_get(
    league_id,
    per_mode,
    season,
    season_type,
    defense_category
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashptteamdefend GET

```python
def leaguedashptteamdefend_get(self,
                              league_id,
                              per_mode,
                              season,
                              season_type,
                              defense_category)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `defense_category` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

defense_category = 'DefenseCategory0'

client_controller.leaguedashptteamdefend_get(
    league_id,
    per_mode,
    season,
    season_type,
    defense_category
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashteamclutch GET

```python
def leaguedashteamclutch_get(self,
                            clutch_time,
                            ahead_behind,
                            point_diff,
                            game_scope,
                            player_experience,
                            player_position,
                            starter_bench,
                            measure_type,
                            per_mode,
                            plus_minus,
                            pace_adjust,
                            rank,
                            season,
                            season_type,
                            outcome,
                            location,
                            month,
                            season_segment,
                            date_from,
                            date_to,
                            opponent_team_id,
                            vs_conference,
                            vs_division,
                            game_segment,
                            period,
                            last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clutch_time` | `str` | Query, Required | - |
| `ahead_behind` | `str` | Query, Required | - |
| `point_diff` | `str` | Query, Required | - |
| `game_scope` | `str` | Query, Required | - |
| `player_experience` | `str` | Query, Required | - |
| `player_position` | `str` | Query, Required | - |
| `starter_bench` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
clutch_time = 'ClutchTime4'

ahead_behind = 'AheadBehind8'

point_diff = 'PointDiff6'

game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashteamclutch_get(
    clutch_time,
    ahead_behind,
    point_diff,
    game_scope,
    player_experience,
    player_position,
    starter_bench,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashteamptshot GET

```python
def leaguedashteamptshot_get(self,
                            league_id,
                            per_mode,
                            season,
                            season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.leaguedashteamptshot_get(
    league_id,
    per_mode,
    season,
    season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashteamshotlocations GET

```python
def leaguedashteamshotlocations_get(self,
                                   measure_type,
                                   per_mode,
                                   plus_minus,
                                   pace_adjust,
                                   rank,
                                   season,
                                   season_type,
                                   outcome,
                                   location,
                                   month,
                                   season_segment,
                                   date_from,
                                   date_to,
                                   opponent_team_id,
                                   vs_conference,
                                   vs_division,
                                   game_segment,
                                   period,
                                   last_n_games,
                                   distance_range,
                                   game_scope,
                                   player_experience,
                                   player_position,
                                   starter_bench)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |
| `distance_range` | `str` | Query, Required | - |
| `game_scope` | `str` | Query, Required | - |
| `player_experience` | `str` | Query, Required | - |
| `player_position` | `str` | Query, Required | - |
| `starter_bench` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

distance_range = 'DistanceRange6'

game_scope = 'GameScope0'

player_experience = 'PlayerExperience4'

player_position = 'PlayerPosition8'

starter_bench = 'StarterBench0'

client_controller.leaguedashteamshotlocations_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games,
    distance_range,
    game_scope,
    player_experience,
    player_position,
    starter_bench
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leaguedashteamstats GET

```python
def leaguedashteamstats_get(self,
                           measure_type,
                           per_mode,
                           plus_minus,
                           pace_adjust,
                           rank,
                           season,
                           season_type,
                           outcome,
                           location,
                           month,
                           season_segment,
                           date_from,
                           date_to,
                           opponent_team_id,
                           vs_conference,
                           vs_division,
                           game_segment,
                           period,
                           last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.leaguedashteamstats_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Leagueleaders GET

```python
def leagueleaders_get(self,
                     league_id,
                     per_mode,
                     season,
                     season_type,
                     scope,
                     stat_category=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `scope` | `str` | Query, Required | - |
| `stat_category` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

scope = 'Scope0'

client_controller.leagueleaders_get(
    league_id,
    per_mode,
    season,
    season_type,
    scope
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playbyplay GET

```python
def playbyplay_get(self,
                  game_id,
                  start_period,
                  end_period)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |
| `start_period` | `str` | Query, Required | - |
| `end_period` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

client_controller.playbyplay_get(
    game_id,
    start_period,
    end_period
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playbyplayv 2 GET

```python
def playbyplayv_2_get(self,
                     game_id,
                     start_period,
                     end_period)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_id` | `str` | Query, Required | - |
| `start_period` | `str` | Query, Required | - |
| `end_period` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_id = 'GameID8'

start_period = 'StartPeriod4'

end_period = 'EndPeriod0'

client_controller.playbyplayv_2_get(
    game_id,
    start_period,
    end_period
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playercareerstats GET

```python
def playercareerstats_get(self,
                         per_mode,
                         player_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

player_id = 'PlayerID6'

client_controller.playercareerstats_get(
    per_mode,
    player_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playercompare GET

```python
def playercompare_get(self,
                     player_id_list,
                     vs_player_id_list,
                     season_type,
                     measure_type,
                     per_mode,
                     plus_minus,
                     pace_adjust,
                     rank,
                     season,
                     outcome,
                     location,
                     month,
                     season_segment,
                     date_from,
                     date_to,
                     opponent_team_id,
                     vs_conference,
                     vs_division,
                     game_segment,
                     period,
                     last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_id_list` | `str` | Query, Required | - |
| `vs_player_id_list` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
player_id_list = 'PlayerIDList4'

vs_player_id_list = 'VsPlayerIDList2'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playercompare_get(
    player_id_list,
    vs_player_id_list,
    season_type,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyclutch GET

```python
def playerdashboardbyclutch_get(self,
                               measure_type,
                               per_mode,
                               plus_minus,
                               pace_adjust,
                               rank,
                               season,
                               season_type,
                               player_id,
                               outcome,
                               location,
                               month,
                               season_segment,
                               date_from,
                               date_to,
                               opponent_team_id,
                               vs_conference,
                               vs_division,
                               game_segment,
                               period,
                               last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyclutch_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    player_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbygamesplits GET

```python
def playerdashboardbygamesplits_get(self,
                                   measure_type,
                                   per_mode,
                                   plus_minus,
                                   pace_adjust,
                                   rank,
                                   season,
                                   season_type,
                                   player_id,
                                   outcome,
                                   location,
                                   month,
                                   season_segment,
                                   date_from,
                                   date_to,
                                   opponent_team_id,
                                   vs_conference,
                                   vs_division,
                                   game_segment,
                                   period,
                                   last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbygamesplits_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    player_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbygeneralsplits GET

```python
def playerdashboardbygeneralsplits_get(self,
                                      measure_type,
                                      per_mode,
                                      plus_minus,
                                      pace_adjust,
                                      rank,
                                      season,
                                      season_type,
                                      player_id,
                                      outcome,
                                      location,
                                      month,
                                      season_segment,
                                      date_from,
                                      date_to,
                                      opponent_team_id,
                                      vs_conference,
                                      vs_division,
                                      game_segment,
                                      period,
                                      last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbygeneralsplits_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    player_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbylastngames GET

```python
def playerdashboardbylastngames_get(self,
                                   measure_type,
                                   per_mode,
                                   plus_minus,
                                   pace_adjust,
                                   rank,
                                   season,
                                   season_type,
                                   player_id,
                                   outcome,
                                   location,
                                   month,
                                   season_segment,
                                   date_from,
                                   date_to,
                                   opponent_team_id,
                                   vs_conference,
                                   vs_division,
                                   game_segment,
                                   period,
                                   last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbylastngames_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    player_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyopponent GET

```python
def playerdashboardbyopponent_get(self,
                                 measure_type,
                                 per_mode,
                                 plus_minus,
                                 pace_adjust,
                                 rank,
                                 season,
                                 season_type,
                                 player_id,
                                 outcome,
                                 location,
                                 month,
                                 season_segment,
                                 date_from,
                                 date_to,
                                 opponent_team_id,
                                 vs_conference,
                                 vs_division,
                                 game_segment,
                                 period,
                                 last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyopponent_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    player_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyshootingsplits GET

```python
def playerdashboardbyshootingsplits_get(self,
                                       measure_type,
                                       per_mode,
                                       plus_minus,
                                       pace_adjust,
                                       rank,
                                       season,
                                       season_type,
                                       player_id,
                                       outcome,
                                       location,
                                       month,
                                       season_segment,
                                       date_from,
                                       date_to,
                                       opponent_team_id,
                                       vs_conference,
                                       vs_division,
                                       game_segment,
                                       period,
                                       last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyshootingsplits_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    player_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyteamperformance GET

```python
def playerdashboardbyteamperformance_get(self,
                                        measure_type,
                                        per_mode,
                                        plus_minus,
                                        pace_adjust,
                                        rank,
                                        season,
                                        season_type,
                                        player_id,
                                        outcome,
                                        location,
                                        month,
                                        season_segment,
                                        date_from,
                                        date_to,
                                        opponent_team_id,
                                        vs_conference,
                                        vs_division,
                                        game_segment,
                                        period,
                                        last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyteamperformance_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    player_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashboardbyyearoveryear GET

```python
def playerdashboardbyyearoveryear_get(self,
                                     measure_type,
                                     per_mode,
                                     plus_minus,
                                     pace_adjust,
                                     rank,
                                     season,
                                     season_type,
                                     player_id,
                                     outcome,
                                     location,
                                     month,
                                     season_segment,
                                     date_from,
                                     date_to,
                                     opponent_team_id,
                                     vs_conference,
                                     vs_division,
                                     game_segment,
                                     period,
                                     last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashboardbyyearoveryear_get(
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    player_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptpass GET

```python
def playerdashptpass_get(self,
                        per_mode,
                        season,
                        season_type,
                        player_id,
                        team_id,
                        outcome,
                        location,
                        month,
                        season_segment,
                        date_from,
                        date_to,
                        opponent_team_id,
                        vs_conference,
                        vs_division,
                        last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

last_n_games = 'LastNGames4'

client_controller.playerdashptpass_get(
    per_mode,
    season,
    season_type,
    player_id,
    team_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptreb GET

```python
def playerdashptreb_get(self,
                       per_mode,
                       season,
                       season_type,
                       player_id,
                       team_id,
                       outcome,
                       location,
                       month,
                       season_segment,
                       date_from,
                       date_to,
                       opponent_team_id,
                       vs_conference,
                       vs_division,
                       game_segment,
                       period,
                       last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashptreb_get(
    per_mode,
    season,
    season_type,
    player_id,
    team_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptreboundlogs GET

```python
def playerdashptreboundlogs_get(self,
                               season=None,
                               season_type=None,
                               player_id=None,
                               team_id=None,
                               outcome=None,
                               location=None,
                               month=None,
                               season_segment=None,
                               date_from=None,
                               date_to=None,
                               opponent_team_id=None,
                               vs_conference=None,
                               vs_division=None,
                               game_segment=None,
                               period=None,
                               last_n_games=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `str` | Query, Optional | - |
| `season_type` | `str` | Query, Optional | - |
| `player_id` | `str` | Query, Optional | - |
| `team_id` | `str` | Query, Optional | - |
| `outcome` | `str` | Query, Optional | - |
| `location` | `str` | Query, Optional | - |
| `month` | `str` | Query, Optional | - |
| `season_segment` | `str` | Query, Optional | - |
| `date_from` | `str` | Query, Optional | - |
| `date_to` | `str` | Query, Optional | - |
| `opponent_team_id` | `str` | Query, Optional | - |
| `vs_conference` | `str` | Query, Optional | - |
| `vs_division` | `str` | Query, Optional | - |
| `game_segment` | `str` | Query, Optional | - |
| `period` | `str` | Query, Optional | - |
| `last_n_games` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
client_controller.playerdashptreboundlogs_get()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptshotdefend GET

```python
def playerdashptshotdefend_get(self,
                              per_mode,
                              season,
                              season_type,
                              player_id,
                              team_id,
                              outcome,
                              location,
                              month,
                              season_segment,
                              date_from,
                              date_to,
                              opponent_team_id,
                              vs_conference,
                              vs_division,
                              game_segment,
                              period,
                              last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashptshotdefend_get(
    per_mode,
    season,
    season_type,
    player_id,
    team_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptshotlog GET

```python
def playerdashptshotlog_get(self,
                           league_id=None,
                           season=None,
                           season_type=None,
                           player_id=None,
                           team_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Optional | - |
| `season` | `str` | Query, Optional | - |
| `season_type` | `str` | Query, Optional | - |
| `player_id` | `str` | Query, Optional | - |
| `team_id` | `str` | Query, Optional | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
client_controller.playerdashptshotlog_get()
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerdashptshots GET

```python
def playerdashptshots_get(self,
                         per_mode,
                         season,
                         season_type,
                         player_id,
                         team_id,
                         outcome,
                         location,
                         month,
                         season_segment,
                         date_from,
                         date_to,
                         opponent_team_id,
                         vs_conference,
                         vs_division,
                         game_segment,
                         period,
                         last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

player_id = 'PlayerID6'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playerdashptshots_get(
    per_mode,
    season,
    season_type,
    player_id,
    team_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playergamelog GET

```python
def playergamelog_get(self,
                     player_id,
                     season,
                     season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
player_id = 'PlayerID6'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.playergamelog_get(
    player_id,
    season,
    season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerprofile GET

```python
def playerprofile_get(self,
                     league_id,
                     player_id,
                     season,
                     season_type,
                     graph_start_season,
                     graph_end_season,
                     graph_stat)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `graph_start_season` | `str` | Query, Required | - |
| `graph_end_season` | `str` | Query, Required | - |
| `graph_stat` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

player_id = 'PlayerID6'

season = 'Season0'

season_type = 'SeasonType8'

graph_start_season = 'GraphStartSeason2'

graph_end_season = 'GraphEndSeason6'

graph_stat = 'GraphStat0'

client_controller.playerprofile_get(
    league_id,
    player_id,
    season,
    season_type,
    graph_start_season,
    graph_end_season,
    graph_stat
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playerprofilev 2 GET

```python
def playerprofilev_2_get(self,
                        per_mode,
                        player_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

player_id = 'PlayerID6'

client_controller.playerprofilev_2_get(
    per_mode,
    player_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playersvsplayers GET

```python
def playersvsplayers_get(self,
                        player_team_id,
                        player_id_1,
                        player_id_2,
                        player_id_3,
                        player_id_4,
                        player_id_5,
                        vs_team_id,
                        vs_player_id_1,
                        vs_player_id_2,
                        vs_player_id_3,
                        vs_player_id_4,
                        vs_player_id_5,
                        season_type,
                        measure_type,
                        per_mode,
                        plus_minus,
                        pace_adjust,
                        rank,
                        season,
                        outcome,
                        location,
                        month,
                        season_segment,
                        date_from,
                        date_to,
                        opponent_team_id,
                        vs_conference,
                        vs_division,
                        game_segment,
                        period,
                        last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_team_id` | `str` | Query, Required | - |
| `player_id_1` | `str` | Query, Required | - |
| `player_id_2` | `str` | Query, Required | - |
| `player_id_3` | `str` | Query, Required | - |
| `player_id_4` | `str` | Query, Required | - |
| `player_id_5` | `str` | Query, Required | - |
| `vs_team_id` | `str` | Query, Required | - |
| `vs_player_id_1` | `str` | Query, Required | - |
| `vs_player_id_2` | `str` | Query, Required | - |
| `vs_player_id_3` | `str` | Query, Required | - |
| `vs_player_id_4` | `str` | Query, Required | - |
| `vs_player_id_5` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
player_team_id = 'PlayerTeamID4'

player_id_1 = 'PlayerID18'

player_id_2 = 'PlayerID24'

player_id_3 = 'PlayerID32'

player_id_4 = 'PlayerID44'

player_id_5 = 'PlayerID54'

vs_team_id = 'VsTeamID8'

vs_player_id_1 = 'VsPlayerID12'

vs_player_id_2 = 'VsPlayerID28'

vs_player_id_3 = 'VsPlayerID38'

vs_player_id_4 = 'VsPlayerID46'

vs_player_id_5 = 'VsPlayerID56'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playersvsplayers_get(
    player_team_id,
    player_id_1,
    player_id_2,
    player_id_3,
    player_id_4,
    player_id_5,
    vs_team_id,
    vs_player_id_1,
    vs_player_id_2,
    vs_player_id_3,
    vs_player_id_4,
    vs_player_id_5,
    season_type,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playervsplayer GET

```python
def playervsplayer_get(self,
                      player_id,
                      vs_player_id,
                      season_type,
                      measure_type,
                      per_mode,
                      plus_minus,
                      pace_adjust,
                      rank,
                      season,
                      outcome,
                      location,
                      month,
                      season_segment,
                      date_from,
                      date_to,
                      opponent_team_id,
                      vs_conference,
                      vs_division,
                      game_segment,
                      period,
                      last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `player_id` | `str` | Query, Required | - |
| `vs_player_id` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
player_id = 'PlayerID6'

vs_player_id = 'VsPlayerID8'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.playervsplayer_get(
    player_id,
    vs_player_id,
    season_type,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Playoffpicture GET

```python
def playoffpicture_get(self,
                      league_id,
                      season_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season_id = 'SeasonID6'

client_controller.playoffpicture_get(
    league_id,
    season_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Scoreboard GET

```python
def scoreboard_get(self,
                  game_date,
                  league_id,
                  day_offset)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_date` | `str` | Query, Required | - |
| `league_id` | `str` | Query, Required | - |
| `day_offset` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_date = 'GameDate8'

league_id = 'LeagueID4'

day_offset = 'DayOffset6'

client_controller.scoreboard_get(
    game_date,
    league_id,
    day_offset
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Scoreboard V2 GET

```python
def scoreboard_v_2_get(self,
                      game_date,
                      league_id,
                      day_offset)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `game_date` | `str` | Query, Required | - |
| `league_id` | `str` | Query, Required | - |
| `day_offset` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
game_date = 'GameDate8'

league_id = 'LeagueID4'

day_offset = 'DayOffset6'

client_controller.scoreboard_v_2_get(
    game_date,
    league_id,
    day_offset
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Shotchartdetail GET

```python
def shotchartdetail_get(self,
                       season_type,
                       team_id,
                       player_id,
                       game_id,
                       outcome,
                       location,
                       month,
                       season_segment,
                       date_from,
                       date_to,
                       opponent_team_id,
                       vs_conference,
                       vs_division,
                       position,
                       rookie_year,
                       game_segment,
                       period,
                       last_n_games,
                       context_measure)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season_type` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `player_id` | `str` | Query, Required | - |
| `game_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `position` | `str` | Query, Required | - |
| `rookie_year` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |
| `context_measure` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
season_type = 'SeasonType8'

team_id = 'TeamID8'

player_id = 'PlayerID6'

game_id = 'GameID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

position = 'Position8'

rookie_year = 'RookieYear8'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

context_measure = 'ContextMeasure2'

client_controller.shotchartdetail_get(
    season_type,
    team_id,
    player_id,
    game_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    position,
    rookie_year,
    game_segment,
    period,
    last_n_games,
    context_measure
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Shotchartlineupdetail GET

```python
def shotchartlineupdetail_get(self,
                             league_id,
                             season,
                             season_type,
                             team_id,
                             outcome,
                             location,
                             month,
                             season_segment,
                             date_from,
                             date_to,
                             opponent_team_id,
                             vs_conference,
                             vs_division,
                             game_segment,
                             period,
                             last_n_games,
                             game_id,
                             group_id,
                             context_measure,
                             context_filter)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |
| `game_id` | `str` | Query, Required | - |
| `group_id` | `str` | Query, Required | - |
| `context_measure` | `str` | Query, Required | - |
| `context_filter` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season = 'Season0'

season_type = 'SeasonType8'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

game_id = 'GameID8'

group_id = 'GROUP_ID6'

context_measure = 'ContextMeasure2'

context_filter = 'ContextFilter6'

client_controller.shotchartlineupdetail_get(
    league_id,
    season,
    season_type,
    team_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games,
    game_id,
    group_id,
    context_measure,
    context_filter
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyclutch GET

```python
def teamdashboardbyclutch_get(self,
                             team_id,
                             measure_type,
                             per_mode,
                             plus_minus,
                             pace_adjust,
                             rank,
                             season,
                             season_type,
                             outcome,
                             location,
                             month,
                             season_segment,
                             date_from,
                             date_to,
                             opponent_team_id,
                             vs_conference,
                             vs_division,
                             game_segment,
                             period,
                             last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyclutch_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbygamesplits GET

```python
def teamdashboardbygamesplits_get(self,
                                 team_id,
                                 measure_type,
                                 per_mode,
                                 plus_minus,
                                 pace_adjust,
                                 rank,
                                 season,
                                 season_type,
                                 outcome,
                                 location,
                                 month,
                                 season_segment,
                                 date_from,
                                 date_to,
                                 opponent_team_id,
                                 vs_conference,
                                 vs_division,
                                 game_segment,
                                 period,
                                 last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbygamesplits_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbygeneralsplits GET

```python
def teamdashboardbygeneralsplits_get(self,
                                    season_type,
                                    team_id,
                                    measure_type,
                                    per_mode,
                                    plus_minus,
                                    pace_adjust,
                                    rank,
                                    season,
                                    outcome,
                                    location,
                                    month,
                                    season_segment,
                                    date_from,
                                    date_to,
                                    opponent_team_id,
                                    vs_conference,
                                    vs_division,
                                    game_segment,
                                    period,
                                    last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season_type` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
season_type = 'SeasonType8'

team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbygeneralsplits_get(
    season_type,
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbylastngames GET

```python
def teamdashboardbylastngames_get(self,
                                 team_id,
                                 measure_type,
                                 per_mode,
                                 plus_minus,
                                 pace_adjust,
                                 rank,
                                 season,
                                 season_type,
                                 outcome,
                                 location,
                                 month,
                                 season_segment,
                                 date_from,
                                 date_to,
                                 opponent_team_id,
                                 vs_conference,
                                 vs_division,
                                 game_segment,
                                 period,
                                 last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbylastngames_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyopponent GET

```python
def teamdashboardbyopponent_get(self,
                               team_id,
                               measure_type,
                               per_mode,
                               plus_minus,
                               pace_adjust,
                               rank,
                               season,
                               season_type,
                               outcome,
                               location,
                               month,
                               season_segment,
                               date_from,
                               date_to,
                               opponent_team_id,
                               vs_conference,
                               vs_division,
                               game_segment,
                               period,
                               last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyopponent_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyshootingsplits GET

```python
def teamdashboardbyshootingsplits_get(self,
                                     team_id,
                                     measure_type,
                                     per_mode,
                                     plus_minus,
                                     pace_adjust,
                                     rank,
                                     season,
                                     season_type,
                                     outcome,
                                     location,
                                     month,
                                     season_segment,
                                     date_from,
                                     date_to,
                                     opponent_team_id,
                                     vs_conference,
                                     vs_division,
                                     game_segment,
                                     period,
                                     last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyshootingsplits_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyteamperformance GET

```python
def teamdashboardbyteamperformance_get(self,
                                      team_id,
                                      measure_type,
                                      per_mode,
                                      plus_minus,
                                      pace_adjust,
                                      rank,
                                      season,
                                      season_type,
                                      outcome,
                                      location,
                                      month,
                                      season_segment,
                                      date_from,
                                      date_to,
                                      opponent_team_id,
                                      vs_conference,
                                      vs_division,
                                      game_segment,
                                      period,
                                      last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyteamperformance_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashboardbyyearoveryear GET

```python
def teamdashboardbyyearoveryear_get(self,
                                   team_id,
                                   measure_type,
                                   per_mode,
                                   plus_minus,
                                   pace_adjust,
                                   rank,
                                   season,
                                   season_type,
                                   outcome,
                                   location,
                                   month,
                                   season_segment,
                                   date_from,
                                   date_to,
                                   opponent_team_id,
                                   vs_conference,
                                   vs_division,
                                   game_segment,
                                   period,
                                   last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashboardbyyearoveryear_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashlineups GET

```python
def teamdashlineups_get(self,
                       group_quantity,
                       game_id,
                       season_type,
                       team_id,
                       measure_type,
                       per_mode,
                       plus_minus,
                       pace_adjust,
                       rank,
                       season,
                       outcome,
                       location,
                       month,
                       season_segment,
                       date_from,
                       date_to,
                       opponent_team_id,
                       vs_conference,
                       vs_division,
                       game_segment,
                       period,
                       last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `group_quantity` | `str` | Query, Required | - |
| `game_id` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
group_quantity = 'GroupQuantity0'

game_id = 'GameID8'

season_type = 'SeasonType8'

team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashlineups_get(
    group_quantity,
    game_id,
    season_type,
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashptpass GET

```python
def teamdashptpass_get(self,
                      per_mode,
                      season,
                      season_type,
                      team_id,
                      outcome,
                      location,
                      month,
                      season_segment,
                      date_from,
                      date_to,
                      opponent_team_id,
                      vs_conference,
                      vs_division,
                      last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

last_n_games = 'LastNGames4'

client_controller.teamdashptpass_get(
    per_mode,
    season,
    season_type,
    team_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashptreb GET

```python
def teamdashptreb_get(self,
                     per_mode,
                     season,
                     season_type,
                     team_id,
                     outcome,
                     location,
                     month,
                     season_segment,
                     date_from,
                     date_to,
                     opponent_team_id,
                     vs_conference,
                     vs_division,
                     game_segment,
                     period,
                     last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashptreb_get(
    per_mode,
    season,
    season_type,
    team_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamdashptshots GET

```python
def teamdashptshots_get(self,
                       per_mode,
                       season,
                       season_type,
                       team_id,
                       outcome,
                       location,
                       month,
                       season_segment,
                       date_from,
                       date_to,
                       opponent_team_id,
                       vs_conference,
                       vs_division,
                       game_segment,
                       period,
                       last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_mode` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
per_mode = 'PerMode6'

season = 'Season0'

season_type = 'SeasonType8'

team_id = 'TeamID8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamdashptshots_get(
    per_mode,
    season,
    season_type,
    team_id,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamgamelog GET

```python
def teamgamelog_get(self,
                   team_id,
                   season,
                   season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

season = 'Season0'

season_type = 'SeasonType8'

client_controller.teamgamelog_get(
    team_id,
    season,
    season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teaminfocommon GET

```python
def teaminfocommon_get(self,
                      season,
                      team_id,
                      league_id,
                      season_type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `league_id` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
season = 'Season0'

team_id = 'TeamID8'

league_id = 'LeagueID4'

season_type = 'SeasonType8'

client_controller.teaminfocommon_get(
    season,
    team_id,
    league_id,
    season_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamplayerdashboard GET

```python
def teamplayerdashboard_get(self,
                           season_type,
                           team_id,
                           measure_type,
                           per_mode,
                           plus_minus,
                           pace_adjust,
                           rank,
                           season,
                           outcome,
                           location,
                           month,
                           season_segment,
                           date_from,
                           date_to,
                           opponent_team_id,
                           vs_conference,
                           vs_division,
                           game_segment,
                           period,
                           last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `season_type` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
season_type = 'SeasonType8'

team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamplayerdashboard_get(
    season_type,
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamplayeronoffdetails GET

```python
def teamplayeronoffdetails_get(self,
                              team_id,
                              measure_type,
                              per_mode,
                              plus_minus,
                              pace_adjust,
                              rank,
                              season,
                              season_type,
                              outcome,
                              location,
                              month,
                              season_segment,
                              date_from,
                              date_to,
                              opponent_team_id,
                              vs_conference,
                              vs_division,
                              game_segment,
                              period,
                              last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamplayeronoffdetails_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamplayeronoffsummary GET

```python
def teamplayeronoffsummary_get(self,
                              team_id,
                              measure_type,
                              per_mode,
                              plus_minus,
                              pace_adjust,
                              rank,
                              season,
                              season_type,
                              outcome,
                              location,
                              month,
                              season_segment,
                              date_from,
                              date_to,
                              opponent_team_id,
                              vs_conference,
                              vs_division,
                              game_segment,
                              period,
                              last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

season_type = 'SeasonType8'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamplayeronoffsummary_get(
    team_id,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    season_type,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamvsplayer GET

```python
def teamvsplayer_get(self,
                    team_id,
                    vs_player_id,
                    season_type,
                    measure_type,
                    per_mode,
                    plus_minus,
                    pace_adjust,
                    rank,
                    season,
                    outcome,
                    location,
                    month,
                    season_segment,
                    date_from,
                    date_to,
                    opponent_team_id,
                    vs_conference,
                    vs_division,
                    game_segment,
                    period,
                    last_n_games)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `team_id` | `str` | Query, Required | - |
| `vs_player_id` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `measure_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `plus_minus` | `str` | Query, Required | - |
| `pace_adjust` | `str` | Query, Required | - |
| `rank` | `str` | Query, Required | - |
| `season` | `str` | Query, Required | - |
| `outcome` | `str` | Query, Required | - |
| `location` | `str` | Query, Required | - |
| `month` | `str` | Query, Required | - |
| `season_segment` | `str` | Query, Required | - |
| `date_from` | `str` | Query, Required | - |
| `date_to` | `str` | Query, Required | - |
| `opponent_team_id` | `str` | Query, Required | - |
| `vs_conference` | `str` | Query, Required | - |
| `vs_division` | `str` | Query, Required | - |
| `game_segment` | `str` | Query, Required | - |
| `period` | `str` | Query, Required | - |
| `last_n_games` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
team_id = 'TeamID8'

vs_player_id = 'VsPlayerID8'

season_type = 'SeasonType8'

measure_type = 'MeasureType8'

per_mode = 'PerMode6'

plus_minus = 'PlusMinus0'

pace_adjust = 'PaceAdjust2'

rank = 'Rank2'

season = 'Season0'

outcome = 'Outcome4'

location = 'Location4'

month = 'Month0'

season_segment = 'SeasonSegment8'

date_from = 'DateFrom6'

date_to = 'DateTo0'

opponent_team_id = 'OpponentTeamID6'

vs_conference = 'VsConference6'

vs_division = 'VsDivision6'

game_segment = 'GameSegment6'

period = 'Period2'

last_n_games = 'LastNGames4'

client_controller.teamvsplayer_get(
    team_id,
    vs_player_id,
    season_type,
    measure_type,
    per_mode,
    plus_minus,
    pace_adjust,
    rank,
    season,
    outcome,
    location,
    month,
    season_segment,
    date_from,
    date_to,
    opponent_team_id,
    vs_conference,
    vs_division,
    game_segment,
    period,
    last_n_games
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Teamyearbyyearstats GET

```python
def teamyearbyyearstats_get(self,
                           league_id,
                           season_type,
                           per_mode,
                           team_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `season_type` | `str` | Query, Required | - |
| `per_mode` | `str` | Query, Required | - |
| `team_id` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

season_type = 'SeasonType8'

per_mode = 'PerMode6'

team_id = 'TeamID8'

client_controller.teamyearbyyearstats_get(
    league_id,
    season_type,
    per_mode,
    team_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |


# Video Status GET

```python
def video_status_get(self,
                    league_id,
                    game_date)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `league_id` | `str` | Query, Required | - |
| `game_date` | `str` | Query, Required | - |

## Response Type

**200**: 200 OK

`void`

## Example Usage

```python
league_id = 'LeagueID4'

game_date = 'GameDate8'

client_controller.video_status_get(
    league_id,
    game_date
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request - bad parameters | `APIException` |
| 404 | 'No HTTP resource was found that matches the request URI' - possible deprecated endpoint | `APIException` |

