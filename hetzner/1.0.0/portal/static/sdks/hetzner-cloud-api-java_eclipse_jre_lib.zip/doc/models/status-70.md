
# Status 70

## Enumeration

`Status70`

## Fields

| Name |
|  --- |
| `INITIALIZING` |
| `STARTING` |
| `RUNNING` |
| `STOPPING` |
| `OFF` |
| `DELETING` |
| `REBUILDING` |
| `MIGRATING` |
| `UNKNOWN` |

## Example

```java
import cloud.hetzner.api.models.Status70;

Status70 status70 = Status70.MIGRATING;
```

