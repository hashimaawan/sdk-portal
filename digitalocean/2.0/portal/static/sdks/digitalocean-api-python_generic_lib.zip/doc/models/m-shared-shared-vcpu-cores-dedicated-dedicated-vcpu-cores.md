
# M Shared Shared Vcpu Cores Dedicated Dedicated Vcpu Cores

## Enumeration

`MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `SHARED` |
| `DEDICATED` |

## Example

```python
from digitaloceanapi.models.m_shared_shared_vcpu_cores_dedicated_dedicated_vcpu_cores import MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores

m_shared_shared_v_cpu_cores_dedicated_dedicated_v_cpu_cores = MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores.SHARED
```

