
# Notebook Metadata

Contains metadata for notebook, including the notebook name, ID, workgroup, and time created.

## Structure

`NotebookMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebook_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` |
| `name` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `work_group` | `str` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `creation_time` | `datetime` | Optional | - |
| `mtype` | [`NotebookType1Enum`](../../doc/models/notebook-type-1-enum.md) | Optional | - |
| `last_modified_time` | `datetime` | Optional | - |

## Example

```python
import dateutil.parser

from amazonathena.models.notebook_metadata import NotebookMetadata
from amazonathena.models.notebook_type_1_enum import NotebookType1Enum

notebook_metadata = NotebookMetadata(
    notebook_id='NotebookId4',
    name='Name4',
    work_group='WorkGroup6',
    creation_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
    mtype=NotebookType1Enum.IPYNB
)
```

