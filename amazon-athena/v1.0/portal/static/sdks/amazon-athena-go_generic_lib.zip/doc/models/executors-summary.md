
# Executors Summary

Contains summary information about an executor.

## Structure

`ExecutorsSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ExecutorId` | `string` | Required | **Constraints**: *Maximum Length*: `100000`, *Pattern*: `.*` |
| `ExecutorType` | [`*models.ExecutorType2Enum`](../../doc/models/executor-type-2-enum.md) | Optional | - |
| `StartDateTime` | `*int` | Optional | - |
| `TerminationDateTime` | `*int` | Optional | - |
| `ExecutorState` | [`*models.ExecutorState3Enum`](../../doc/models/executor-state-3-enum.md) | Optional | - |
| `ExecutorSize` | `*int` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    executorsSummary := models.ExecutorsSummary{
        ExecutorId:           "ExecutorId8",
        ExecutorType:         models.ToPointer(models.ExecutorType2Enum_WORKER),
        StartDateTime:        models.ToPointer(52),
        TerminationDateTime:  models.ToPointer(56),
        ExecutorState:        models.ToPointer(models.ExecutorState3Enum_CREATING),
        ExecutorSize:         models.ToPointer(222),
    }

}
```

