
# Applied to Resource

*This model accepts additional fields of type Any.*

## Structure

`AppliedToResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `server` | [`Server`](../../doc/models/server.md) | Optional | - |
| `mtype` | [`Type5`](../../doc/models/type-5.md) | Optional | Type of resource referenced |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.applied_to_resource import AppliedToResource
from hetznercloudapi.models.server import Server
from hetznercloudapi.models.type_5 import Type5

applied_to_resource = AppliedToResource(
    server=Server(
        id=14,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    mtype=Type5.SERVER,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

