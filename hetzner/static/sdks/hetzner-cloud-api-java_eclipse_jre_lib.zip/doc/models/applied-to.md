
# Applied To

## Structure

`AppliedTo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AppliedToResources` | [`List<AppliedToResource>`](../../doc/models/applied-to-resource.md) | Optional | - | List<AppliedToResource> getAppliedToResources() | setAppliedToResources(List<AppliedToResource> appliedToResources) |
| `LabelSelector` | [`LabelSelector`](../../doc/models/label-selector.md) | Optional | - | LabelSelector getLabelSelector() | setLabelSelector(LabelSelector labelSelector) |
| `Server` | [`Server`](../../doc/models/server.md) | Optional | - | Server getServer() | setServer(Server server) |
| `Type` | [`Type6Enum`](../../doc/models/type-6-enum.md) | Required | Type of resource referenced | Type6Enum getType() | setType(Type6Enum type) |

## Example

```java
import cloud.hetzner.api.models.AppliedTo;
import cloud.hetzner.api.models.AppliedToResource;
import cloud.hetzner.api.models.LabelSelector;
import cloud.hetzner.api.models.Server;
import cloud.hetzner.api.models.Type5Enum;
import cloud.hetzner.api.models.Type6Enum;
import java.util.Arrays;

AppliedTo appliedTo = new AppliedTo.Builder(
    Type6Enum.SERVER
)
.appliedToResources(Arrays.asList(
        new AppliedToResource.Builder()
            .server(new Server.Builder(
                14
            )
            .build())
            .type(Type5Enum.SERVER)
            .build(),
        new AppliedToResource.Builder()
            .server(new Server.Builder(
                14
            )
            .build())
            .type(Type5Enum.SERVER)
            .build()
    ))
.labelSelector(new LabelSelector.Builder(
        "selector8"
    )
    .build())
.server(new Server.Builder(
        14
    )
    .build())
.build();
```

