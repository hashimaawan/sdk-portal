
# S3 Acl Option 1 Enum

The Amazon S3 canned ACL that Athena should specify when storing query results. Currently the only supported canned ACL is <code>BUCKET_OWNER_FULL_CONTROL</code>. If a query runs in a workgroup and the workgroup overrides client-side settings, then the Amazon S3 canned ACL specified in the workgroup's settings is used for all queries that run in the workgroup. For more information about Amazon S3 canned ACLs, see <a href="https://docs.aws.amazon.com/AmazonS3/latest/userguide/acl-overview.html#canned-acl">Canned ACL</a> in the <i>Amazon S3 User Guide</i>.

## Enumeration

`S3AclOption1Enum`

## Fields

| Name |
|  --- |
| `BUCKET_OWNER_FULL_CONTROL` |

## Example

```python
from amazonathena.models.s_3_acl_option_1_enum import S3AclOption1Enum

s_3_acl_option_1 = S3AclOption1Enum.BUCKET_OWNER_FULL_CONTROL
```

