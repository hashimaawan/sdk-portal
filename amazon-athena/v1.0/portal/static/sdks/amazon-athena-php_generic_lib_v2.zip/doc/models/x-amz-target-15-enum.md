
# X Amz Target 15 Enum

## Enumeration

`XAmzTarget15Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget15Enum;

$xAmzTarget15 = XAmzTarget15Enum::ENUM_AMAZONATHENAGETCALCULATIONEXECUTION;
```

