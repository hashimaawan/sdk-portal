
# Statistics 1

## Structure

`Statistics1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DpuExecutionInMillis` | `Integer` | Optional | - | Integer getDpuExecutionInMillis() | setDpuExecutionInMillis(Integer dpuExecutionInMillis) |
| `Progress` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getProgress() | setProgress(String progress) |

## Example

```java
import com.amazonaws.useast1.athena.models.Statistics1;

Statistics1 statistics1 = new Statistics1.Builder()
    .dpuExecutionInMillis(148)
    .progress("Progress4")
    .build();
```

