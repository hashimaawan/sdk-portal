
# Output Stage

## Structure

`OutputStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StageId` | `*int` | Optional | - |
| `State` | `*string` | Optional | - |
| `OutputBytes` | `*int` | Optional | - |
| `OutputRows` | `*int` | Optional | - |
| `InputBytes` | `*int` | Optional | - |
| `InputRows` | `*int` | Optional | - |
| `ExecutionTime` | `*int` | Optional | - |
| `QueryStagePlan` | [`*models.QueryStagePlan`](../../doc/models/query-stage-plan.md) | Optional | - |
| `SubStages` | [`[]models.QueryStage`](../../doc/models/query-stage.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    outputStage := models.OutputStage{
        StageId:              models.ToPointer(26),
        State:                models.ToPointer("State4"),
        OutputBytes:          models.ToPointer(212),
        OutputRows:           models.ToPointer(54),
        InputBytes:           models.ToPointer(170),
    }

}
```

