
# Update Volume Request

## Structure

`UpdateVolumeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2 \| undefined`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `string` | Required | New Volume name |

## Example

```ts
import { UpdateVolumeRequest } from 'hetzner-cloud-apilib';

const updateVolumeRequest: UpdateVolumeRequest = {
  name: 'database-storage',
  labels: {
    labelkey: 'labelkey4',
  },
};
```

