
# Get Work Group Input

*This model accepts additional fields of type array.*

## Structure

`GetWorkGroupInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `workGroup` | `string` | Required | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` | getWorkGroup(): string | setWorkGroup(string workGroup): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetWorkGroupInputBuilder;
use AmazonAthenaLib\ApiHelper;

$getWorkGroupInput = GetWorkGroupInputBuilder::init(
    'WorkGroup8'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

