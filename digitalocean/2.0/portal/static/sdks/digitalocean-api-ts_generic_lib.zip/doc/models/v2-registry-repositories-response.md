
# V2 Registry Repositories Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2RegistryRepositoriesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `repositories` | [`Repository[] \| undefined`](../../doc/models/repository.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2RegistryRepositoriesResponse } from 'digitalocean-apilib';

const v2RegistryRepositoriesResponse: V2RegistryRepositoriesResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  repositories: [
    {
      latestTag: {
        compressedSizeBytes: 2803255,
        manifestDigest: 'sha256:cb8a924afdf0229ef7515d9e5b3024e23b3eb03ddbba287f4a19c6ac90b8d221',
        registryName: 'example',
        repository: 'repo-1',
        sizeBytes: 5861888,
        tag: 'latest',
        updatedAt: '2020-04-09T23:54:25Z',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      name: 'repo-1',
      registryName: 'example',
      tagCount: 1,
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

