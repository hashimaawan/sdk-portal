
# X Amz Target 18 Enum

## Enumeration

`XAmzTarget18Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETDATACATALOG` |

## Example

```python
from amazonathena.models.x_amz_target_18_enum import XAmzTarget18Enum

x_amz_target_18 = XAmzTarget18Enum.ENUM_AMAZONATHENAGETDATACATALOG
```

