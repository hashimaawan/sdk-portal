# Server Types

```php
$serverTypesApi = $client->getServerTypesApi();
```

## Class Name

`ServerTypesApi`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```php
function getAllServerTypes(?string $name = null): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `?string` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ServerTypesResponse`](../../doc/models/server-types-response.md).

## Example Usage

```php
$serverTypesApi = $client->getServerTypesApi();
$apiResponse = $serverTypesApi->getAllServerTypes();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ServerTypesResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```


# Get a Server Type

Gets a specific Server type object.

```php
function getAServerType(int $id): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Server Type |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`ServerTypesResponse1`](../../doc/models/server-types-response-1.md).

## Example Usage

```php
$id = 112;

$serverTypesApi = $client->getServerTypesApi();
$apiResponse = $serverTypesApi->getAServerType($id);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'ServerTypesResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

