
# Worker Components that Are Part of This Deployment

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`WorkerComponentsThatArePartOfThisDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | - |
| `sourceCommitHash` | `string \| undefined` | Optional | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import {
  WorkerComponentsThatArePartOfThisDeployment,
} from 'digitalocean-apilib';

const workerComponentsThatArePartOfThisDeployment: WorkerComponentsThatArePartOfThisDeployment = {
  name: 'queue-runner',
  sourceCommitHash: '54d4a727f457231062439895000d45437c7bb405',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

