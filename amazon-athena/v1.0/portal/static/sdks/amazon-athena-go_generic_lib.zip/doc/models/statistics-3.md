
# Statistics 3

## Structure

`Statistics3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DpuExecutionInMillis` | `*int` | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    statistics3 := models.Statistics3{
        DpuExecutionInMillis: models.ToPointer(130),
    }

}
```

