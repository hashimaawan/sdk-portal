
# List Tags for Resource Output

## Structure

`ListTagsForResourceOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tags` | [`Tag[] \| undefined`](../../doc/models/tag.md) | Optional | - |
| `nextToken` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ts
import { ListTagsForResourceOutput } from 'amazon-athenalib';

const listTagsForResourceOutput: ListTagsForResourceOutput = {
  tags: [
    {
      key: 'Key0',
      value: 'Value6',
    },
    {
      key: 'Key0',
      value: 'Value6',
    },
    {
      key: 'Key0',
      value: 'Value6',
    }
  ],
  nextToken: 'NextToken4',
};
```

