
# Role

A string representing the database user's role. The value will be either
"primary" or "normal".

## Enumeration

`Role`

## Fields

| Name |
|  --- |
| `Primary` |
| `Normal` |

## Example

```ts
import { Role } from 'digitalocean-apilib';

const role = Role.Primary;
```

