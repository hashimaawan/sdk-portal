
# Pages 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Pages1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `first` | `?string` | Optional | URI of the first page of the results. | getFirst(): ?string | setFirst(?string first): void |
| `prev` | `?string` | Optional | URI of the previous page of the results. | getPrev(): ?string | setPrev(?string prev): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Pages1Builder;
use DigitalOceanApiLib\ApiHelper;

$pages1 = Pages1Builder::init()
    ->first('https://api.digitalocean.com/v2/images?page=1')
    ->prev('https://api.digitalocean.com/v2/images?page=1')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

