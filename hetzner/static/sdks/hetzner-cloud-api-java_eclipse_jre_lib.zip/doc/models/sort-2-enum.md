
# Sort 2 Enum

## Enumeration

`Sort2Enum`

## Fields

| Name |
|  --- |
| `ID` |
| `ENUM_IDASC` |
| `ENUM_IDDESC` |
| `CREATED` |
| `ENUM_CREATEDASC` |
| `ENUM_CREATEDDESC` |

## Example

```java
import cloud.hetzner.api.models.Sort2Enum;

Sort2Enum sort2 = Sort2Enum.ENUM_CREATEDASC;
```

