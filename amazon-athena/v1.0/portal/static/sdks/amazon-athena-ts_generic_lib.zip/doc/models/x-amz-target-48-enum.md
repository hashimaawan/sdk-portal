
# X Amz Target 48 Enum

## Enumeration

`XAmzTarget48Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaStartSession` |

## Example

```ts
import { XAmzTarget48Enum } from 'amazon-athenalib';

const xAmzTarget48 = XAmzTarget48Enum.EnumAmazonAthenaStartSession;
```

