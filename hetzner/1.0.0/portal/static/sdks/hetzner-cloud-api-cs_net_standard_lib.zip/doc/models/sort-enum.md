
# Sort Enum

## Enumeration

`SortEnum`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |
| `Created` |
| `EnumCreatedasc` |
| `EnumCreateddesc` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

SortEnum sort = SortEnum.EnumIdasc;
```

