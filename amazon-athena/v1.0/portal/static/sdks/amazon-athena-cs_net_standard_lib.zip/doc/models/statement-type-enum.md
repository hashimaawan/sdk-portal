
# Statement Type Enum

## Enumeration

`StatementTypeEnum`

## Fields

| Name |
|  --- |
| `DDL` |
| `DML` |
| `UTILITY` |

## Example

```csharp
using AmazonAthena.Standard.Models;

StatementTypeEnum statementType = StatementTypeEnum.DDL;
```

