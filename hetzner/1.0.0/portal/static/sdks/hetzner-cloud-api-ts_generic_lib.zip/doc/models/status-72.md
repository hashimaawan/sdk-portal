
# Status 72

Status of the Firewall on the Server

## Enumeration

`Status72`

## Fields

| Name |
|  --- |
| `Applied` |
| `Pending` |

## Example

```ts
import { Status72 } from 'hetzner-cloud-apilib';

const status72 = Status72.Applied;
```

