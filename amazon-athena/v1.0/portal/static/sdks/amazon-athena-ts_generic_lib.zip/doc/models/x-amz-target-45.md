
# X Amz Target 45

## Enumeration

`XAmzTarget45`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListWorkGroups` |

## Example

```ts
import { XAmzTarget45 } from 'amazon-athenalib';

const xAmzTarget45 = XAmzTarget45.EnumAmazonAthenaListWorkGroups;
```

