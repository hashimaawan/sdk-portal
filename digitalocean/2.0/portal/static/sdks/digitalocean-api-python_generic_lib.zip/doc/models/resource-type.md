
# Resource Type

## Enumeration

`ResourceType`

## Fields

| Name |
|  --- |
| `DROPLET` |
| `VOLUME` |

## Example

```python
from digitaloceanapi.models.resource_type import ResourceType

resource_type = ResourceType.DROPLET
```

