
# Get Data Catalog Input

*This model accepts additional fields of type unknown.*

## Structure

`GetDataCatalogInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetDataCatalogInput } from 'amazon-athenalib';

const getDataCatalogInput: GetDataCatalogInput = {
  name: 'Name6',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

