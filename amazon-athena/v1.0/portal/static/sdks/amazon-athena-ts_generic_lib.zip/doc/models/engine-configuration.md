
# Engine Configuration

Contains data processing unit (DPU) configuration settings and parameter mappings for a notebook engine.

## Structure

`EngineConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `coordinatorDpuSize` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `maxConcurrentDpus` | `number` | Required | **Constraints**: `>= 2`, `<= 5000` |
| `defaultExecutorDpuSize` | `number \| undefined` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `additionalConfigs` | [`AdditionalConfigs \| undefined`](../../doc/models/additional-configs.md) | Optional | - |

## Example

```ts
import { EngineConfiguration } from 'amazon-athenalib';

const engineConfiguration: EngineConfiguration = {
  maxConcurrentDpus: 194,
  coordinatorDpuSize: 1,
  defaultExecutorDpuSize: 1,
  additionalConfigs: {},
};
```

