
# Query Stage

Stage statistics such as input and output rows and bytes, execution time and stage state. This information also includes substages and the query stage plan.

## Structure

`QueryStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StageId` | `*int` | Optional | - |
| `State` | `*string` | Optional | - |
| `OutputBytes` | `*int` | Optional | - |
| `OutputRows` | `*int` | Optional | - |
| `InputBytes` | `*int` | Optional | - |
| `InputRows` | `*int` | Optional | - |
| `ExecutionTime` | `*int` | Optional | - |
| `QueryStagePlan` | [`*models.QueryStagePlan`](../../doc/models/query-stage-plan.md) | Optional | - |
| `SubStages` | [`[]models.QueryStage`](../../doc/models/query-stage.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    queryStage := models.QueryStage{
        StageId:              models.ToPointer(118),
        State:                models.ToPointer("State0"),
        OutputBytes:          models.ToPointer(120),
        OutputRows:           models.ToPointer(146),
        InputBytes:           models.ToPointer(178),
    }

}
```

