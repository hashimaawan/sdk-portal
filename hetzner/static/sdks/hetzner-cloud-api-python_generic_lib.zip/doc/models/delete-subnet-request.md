
# Delete Subnet Request

## Structure

`DeleteSubnetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip_range` | `str` | Required | IP range of subnet to delete |

## Example

```python
from hetznercloudapi.models.delete_subnet_request import DeleteSubnetRequest

delete_subnet_request = DeleteSubnetRequest(
    ip_range='10.0.1.0/24'
)
```

