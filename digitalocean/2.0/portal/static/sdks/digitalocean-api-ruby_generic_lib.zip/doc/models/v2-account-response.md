
# V2 Account Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2AccountResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account` | [`Account`](../../doc/models/account.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_account_response = V2AccountResponse.new(
  account: Account.new(
    droplet_limit: 248,
    email: 'email6',
    email_verified: false,
    floating_ip_limit: 164,
    status: Status::WARNING,
    status_message: 'status_message8',
    uuid: 'uuid6',
    team: Team.new(
      name: 'name0',
      uuid: 'uuid6',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

