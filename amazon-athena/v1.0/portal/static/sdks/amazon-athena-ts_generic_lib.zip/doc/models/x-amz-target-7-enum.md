
# X Amz Target 7 Enum

## Enumeration

`XAmzTarget7Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreatePresignedNotebookUrl` |

## Example

```ts
import { XAmzTarget7Enum } from 'amazon-athenalib';

const xAmzTarget7 = XAmzTarget7Enum.EnumAmazonAthenaCreatePresignedNotebookUrl;
```

