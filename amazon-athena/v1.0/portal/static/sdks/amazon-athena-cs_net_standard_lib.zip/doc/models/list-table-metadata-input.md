
# List Table Metadata Input

*This model accepts additional fields of type object.*

## Structure

`ListTableMetadataInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CatalogName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `DatabaseName` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `Expression` | `string` | Optional | **Constraints**: *Minimum Length*: `0`, *Maximum Length*: `256` |
| `NextToken` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `MaxResults` | `int?` | Optional | **Constraints**: `>= 1`, `<= 50` |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;
using AmazonAthena.Standard.Utilities;

ListTableMetadataInput listTableMetadataInput = new ListTableMetadataInput
{
    CatalogName = "CatalogName2",
    DatabaseName = "DatabaseName2",
    Expression = "Expression0",
    NextToken = "NextToken8",
    MaxResults = 50,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

