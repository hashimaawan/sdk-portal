
# X Amz Target 22 Enum

## Enumeration

`XAmzTarget22Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetPreparedStatement` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget22Enum xAmzTarget22 = XAmzTarget22Enum.EnumAmazonAthenaGetPreparedStatement;
```

