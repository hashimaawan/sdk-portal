
# X Amz Target 4 Enum

## Enumeration

`XAmzTarget4Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaCreateNamedQuery` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget4Enum xAmzTarget4 = XAmzTarget4Enum.EnumAmazonAthenaCreateNamedQuery;
```

