
# Item Type 2

The ID type.

## Enumeration

`ItemType2`

## Fields

| Name |
|  --- |
| `ARTIST` |
| `USER` |

## Example

```ruby
item_type2 = ItemType2::ARTIST
```

