
# Image

## Structure

`Image`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Frames` | `string` | Optional | The number of frames in this GIF. |
| `Height` | `string` | Optional | The height of this GIF in pixels. |
| `Mp4` | `string` | Optional | The URL for this GIF in .MP4 format. |
| `Mp4Size` | `string` | Optional | The size in bytes of the .MP4 file corresponding to this GIF. |
| `Size` | `string` | Optional | The size of this GIF in bytes. |
| `Url` | `string` | Optional | The publicly-accessible direct URL for this GIF. |
| `Webp` | `string` | Optional | The URL for this GIF in .webp format. |
| `WebpSize` | `string` | Optional | The size in bytes of the .webp file corresponding to this GIF. |
| `Width` | `string` | Optional | The width of this GIF in pixels. |

## Example

```csharp
using GiphyAPI.Standard.Models;

Image image = new Image
{
    Frames = "15",
    Height = "200",
    Mp4 = "https://media1.giphy.com/media/cZ7rmKfFYOvYI/giphy.mp4",
    Mp4Size = "25123",
    Size = "32381",
    Url = "https://media1.giphy.com/media/cZ7rmKfFYOvYI/200.gif",
    Webp = "https://media1.giphy.com/media/cZ7rmKfFYOvYI/giphy.webp",
    WebpSize = "12321",
    Width = "320",
};
```

