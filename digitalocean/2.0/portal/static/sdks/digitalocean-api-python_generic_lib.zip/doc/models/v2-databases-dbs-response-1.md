
# V2 Databases Dbs Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2DatabasesDbsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `db` | [`Db`](../../doc/models/db.md) | Required | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.db import Db
from digitaloceanapi.models.v_2_databases_dbs_response_1 import V2DatabasesDbsResponse1

v_2_databases_dbs_response_1 = V2DatabasesDbsResponse1(
    db=Db(
        name='alpha',
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

