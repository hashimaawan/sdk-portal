
# Role

A string representing the database user's role. The value will be either
"primary" or "normal".

## Enumeration

`Role`

## Fields

| Name |
|  --- |
| `PRIMARY` |
| `NORMAL` |

## Example

```ruby
role = Role::PRIMARY
```

