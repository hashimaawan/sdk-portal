
# Type 2

- GENERAL: A plain-text environment variable
- SECRET: A secret encrypted environment variable

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `GENERAL` |
| `SECRET` |

## Example

```python
from digitaloceanapi.models.type_2 import Type2

type_2 = Type2.GENERAL
```

