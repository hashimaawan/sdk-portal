
# X Amz Target 35 Enum

## Enumeration

`XAmzTarget35Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTENGINEVERSIONS` |

## Example

```java
import com.amazonaws.useast1.athena.models.XAmzTarget35Enum;

XAmzTarget35Enum xAmzTarget35 = XAmzTarget35Enum.ENUM_AMAZONATHENALISTENGINEVERSIONS;
```

