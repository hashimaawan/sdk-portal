
# Result Set Metadata

The metadata that describes the column structure and data types of a table of query results. To return a <code>ResultSetMetadata</code> object, use <a>GetQueryResults</a>.

## Structure

`ResultSetMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ColumnInfo` | [`[]models.ColumnInfo`](../../doc/models/column-info.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    resultSetMetadata := models.ResultSetMetadata{
        ColumnInfo:           []models.ColumnInfo{
            models.ColumnInfo{
                CatalogName:          models.ToPointer("CatalogName0"),
                SchemaName:           models.ToPointer("SchemaName0"),
                TableName:            models.ToPointer("TableName2"),
                Name:                 "Name6",
                Label:                models.ToPointer("Label4"),
                Type:                 "Type6",
                Precision:            models.ToPointer(48),
            },
            models.ColumnInfo{
                CatalogName:          models.ToPointer("CatalogName0"),
                SchemaName:           models.ToPointer("SchemaName0"),
                TableName:            models.ToPointer("TableName2"),
                Name:                 "Name6",
                Label:                models.ToPointer("Label4"),
                Type:                 "Type6",
                Precision:            models.ToPointer(48),
            },
        },
    }

}
```

