
# Protocol

The type of traffic to be allowed. This may be one of `tcp`, `udp`, or `icmp`.

## Enumeration

`Protocol`

## Fields

| Name |
|  --- |
| `TCP` |
| `UDP` |
| `ICMP` |

## Example

```php
use DigitalOceanApiLib\Models\Protocol;

$protocol = Protocol::TCP;
```

