
# V2 Functions Namespaces Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespace` | [`Namespace`](../../doc/models/namespace.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_functions_namespaces_response1 = V2FunctionsNamespacesResponse1.new(
  namespace: Namespace.new(
    api_host: 'api_host2',
    created_at: 'created_at0',
    key: 'key2',
    label: 'label2',
    namespace: 'namespace0',
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

