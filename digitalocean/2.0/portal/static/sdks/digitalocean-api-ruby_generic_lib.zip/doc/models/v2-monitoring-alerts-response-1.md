
# V2 Monitoring Alerts Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2MonitoringAlertsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `policy` | [`Policy`](../../doc/models/policy.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_monitoring_alerts_response1 = V2MonitoringAlertsResponse1.new(
  policy: Policy.new(
    alerts: Alerts.new(
      email: [
        'email2',
        'email3'
      ],
      slack: [
        Slack.new(
          channel: 'channel6',
          url: 'url2',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        Slack.new(
          channel: 'channel6',
          url: 'url2',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        ),
        Slack.new(
          channel: 'channel6',
          url: 'url2',
          additional_properties: {
            'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
          }
        )
      ],
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    compare: Compare::GREATERTHAN,
    description: 'description4',
    enabled: false,
    entities: [
      'entities9'
    ],
    tags: [
      'tags9',
      'tags0',
      'tags1'
    ],
    type: Type17::ENUM_V1INSIGHTSDROPLETDISK_READ,
    uuid: 'uuid0',
    value: 149.36,
    window: Window1::ENUM_30M,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

