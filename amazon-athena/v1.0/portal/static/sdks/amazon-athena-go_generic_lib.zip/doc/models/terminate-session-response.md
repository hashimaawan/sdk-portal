
# Terminate Session Response

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `State` | [`*models.SessionState1Enum`](../../doc/models/session-state-1-enum.md) | Optional | - |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    terminateSessionResponse := models.TerminateSessionResponse{
        State:                models.ToPointer(models.SessionState1Enum_CREATING),
    }

}
```

