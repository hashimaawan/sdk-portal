
# Query Execution

Information about a single instance of a query execution.

## Structure

`QueryExecution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `query` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `262144` |
| `statement_type` | [`StatementType1Enum`](../../doc/models/statement-type-1-enum.md) | Optional | - |
| `result_configuration` | [`ResultConfiguration1`](../../doc/models/result-configuration-1.md) | Optional | - |
| `result_reuse_configuration` | [`ResultReuseConfiguration1`](../../doc/models/result-reuse-configuration-1.md) | Optional | - |
| `query_execution_context` | [`QueryExecutionContext1`](../../doc/models/query-execution-context-1.md) | Optional | - |
| `status` | [`Status`](../../doc/models/status.md) | Optional | - |
| `statistics` | [`Statistics`](../../doc/models/statistics.md) | Optional | - |
| `work_group` | `str` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `engine_version` | [`EngineVersion1`](../../doc/models/engine-version-1.md) | Optional | - |
| `execution_parameters` | `List[str]` | Optional | **Constraints**: *Minimum Items*: `1`, *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `substatement_type` | `str` | Optional | - |

## Example

```python
from amazonathena.models.acl_configuration_1 import AclConfiguration1
from amazonathena.models.encryption_configuration_2 import EncryptionConfiguration2
from amazonathena.models.encryption_option_1_enum import EncryptionOption1Enum
from amazonathena.models.query_execution import QueryExecution
from amazonathena.models.result_configuration_1 import ResultConfiguration1
from amazonathena.models.result_reuse_by_age_configuration_2 import ResultReuseByAgeConfiguration2
from amazonathena.models.result_reuse_configuration_1 import ResultReuseConfiguration1
from amazonathena.models.s_3_acl_option_1_enum import S3AclOption1Enum
from amazonathena.models.statement_type_1_enum import StatementType1Enum

query_execution = QueryExecution(
    query_execution_id='QueryExecutionId8',
    query='Query8',
    statement_type=StatementType1Enum.DDL,
    result_configuration=ResultConfiguration1(
        output_location='OutputLocation0',
        encryption_configuration=EncryptionConfiguration2(
            encryption_option=EncryptionOption1Enum.SSE_S3,
            kms_key='KmsKey6'
        ),
        expected_bucket_owner='ExpectedBucketOwner0',
        acl_configuration=AclConfiguration1(
            s_3_acl_option=S3AclOption1Enum.BUCKET_OWNER_FULL_CONTROL
        )
    ),
    result_reuse_configuration=ResultReuseConfiguration1(
        result_reuse_by_age_configuration=ResultReuseByAgeConfiguration2(
            enabled=False,
            max_age_in_minutes=26
        )
    )
)
```

