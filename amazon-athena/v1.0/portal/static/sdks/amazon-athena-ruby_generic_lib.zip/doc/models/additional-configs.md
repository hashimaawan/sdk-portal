
# Additional Configs

*This model accepts additional fields of type String.*

## Structure

`AdditionalConfigs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `additional_properties` | `Hash[String, String]` | Optional | **Constraints**: *Maximum Length*: `51200` |

## Example (as JSON)

```json
{
  "exampleAdditionalProperty": "AdditionalConfigs_additionalProperties5"
}
```

