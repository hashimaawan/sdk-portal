
# Type 39 Enum

Algorithm of the Load Balancer

## Enumeration

`Type39Enum`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```java
import cloud.hetzner.api.models.Type39Enum;

Type39Enum type39 = Type39Enum.ROUND_ROBIN;
```

