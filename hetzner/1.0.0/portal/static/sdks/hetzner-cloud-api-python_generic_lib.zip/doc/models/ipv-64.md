
# Ipv 64

IPv6 network assigned to this Server and its reverse DNS entry

*This model accepts additional fields of type Any.*

## Structure

`Ipv64`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `blocked` | `bool` | Required | If the IP is blocked by our anti abuse dept |
| `dns_ptr` | [`List[DnsPtr8]`](../../doc/models/dns-ptr-8.md) | Required | Reverse DNS PTR entries for the IPv6 addresses of this Server, `null` by default |
| `id` | `int` | Optional | ID of the Resource |
| `ip` | `str` | Required | IP address (v6) of this Server |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.dns_ptr_8 import DnsPtr8
from hetznercloudapi.models.ipv_64 import Ipv64

ipv_64 = Ipv64(
    blocked=False,
    dns_ptr=[
        DnsPtr8(
            dns_ptr='server.example.com',
            ip='2001:db8::1',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    ip='2001:db8::/64',
    id=42,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

