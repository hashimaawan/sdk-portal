
# Time Series Values

## Class Name

`TimeSeriesValues`

## Cases

| Type | Factory Method |
|  --- | --- |
| `double` | TimeSeriesValues.fromPrecision(double precision) |
| `String` | TimeSeriesValues.fromString(String string) |

## double

### Initialization Code

#### Example

```java
TimeSeriesValues.fromPrecision(
        0D
    )
```

## String

### Initialization Code

#### Example

```java
TimeSeriesValues.fromString(
        "String0"
    )
```

