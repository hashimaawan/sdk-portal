
# Labels

User-defined labels (key-value pairs)

## Structure

`Labels`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labelkey` | `str` | Optional | New label |

## Example

```python
from hetznercloudapi.models.labels import Labels

labels = Labels(
    labelkey='value'
)
```

