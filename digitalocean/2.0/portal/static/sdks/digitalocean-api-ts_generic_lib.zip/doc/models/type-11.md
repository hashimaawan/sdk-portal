
# Type 11

The type of the IPv6 network interface.

**Note**: IPv6 private  networking is not currently supported.

## Enumeration

`Type11`

## Fields

| Name |
|  --- |
| `Public` |

## Example

```ts
import { Type11 } from 'digitalocean-apilib';

const type11 = Type11.Public;
```

