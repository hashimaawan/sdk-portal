
# Issuance

Status of the issuance process of the Certificate

## Enumeration

`Issuance`

## Fields

| Name |
|  --- |
| `PENDING` |
| `COMPLETED` |
| `FAILED` |

## Example

```java
import cloud.hetzner.api.models.Issuance;

Issuance issuance = Issuance.FAILED;
```

