# Metrics

```ruby
metrics_api = client.metrics
```

## Class Name

`MetricsApi`


# Get Prometheus Metrics

See Prometheus documentation for a complete data model.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def get_prometheus_metrics
```

## Response Type

**200**: Successfully returned Prometheus metrics

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type `String`.

## Example Usage

```ruby
result = metrics_api.get_prometheus_metrics

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

