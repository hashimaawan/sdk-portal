
# Ssh Keys Request 1

*This model accepts additional fields of type Any.*

## Structure

`SshKeysRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Optional | New name Name to set |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from hetznercloudapi.models.ssh_keys_request_1 import SshKeysRequest1

ssh_keys_request_1 = SshKeysRequest1(
    labels=jsonpickle.decode('{"labelkey":"value"}'),
    name='My ssh key',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

