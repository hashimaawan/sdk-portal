
# V2 Vpcs Response 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2VpcsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpc` | [`Vpc`](../../doc/models/vpc.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_vpcs_response1 = V2VpcsResponse1.new(
  vpc: Vpc.new(
    description: 'description8',
    name: 'name2',
    ip_range: 'ip_range4',
    region: 'region8',
    default: false,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

