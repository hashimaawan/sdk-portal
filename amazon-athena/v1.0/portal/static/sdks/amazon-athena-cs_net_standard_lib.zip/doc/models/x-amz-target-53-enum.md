
# X Amz Target 53 Enum

## Enumeration

`XAmzTarget53Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaUntagResource` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget53Enum xAmzTarget53 = XAmzTarget53Enum.EnumAmazonAthenaUntagResource;
```

