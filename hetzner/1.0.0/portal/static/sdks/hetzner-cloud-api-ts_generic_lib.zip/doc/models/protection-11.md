
# Protection 11

Protection configuration for the Network

*This model accepts additional fields of type unknown.*

## Structure

`Protection11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mDelete` | `boolean` | Required | If true, prevents the Network from being deleted |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Protection11 } from 'hetzner-cloud-apilib';

const protection11: Protection11 = {
  mDelete: false,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

