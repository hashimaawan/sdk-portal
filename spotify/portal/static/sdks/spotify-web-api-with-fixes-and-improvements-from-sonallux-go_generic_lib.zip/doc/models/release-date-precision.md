
# Release Date Precision

The precision with which `release_date` value is known.

## Enumeration

`ReleaseDatePrecision`

## Fields

| Name |
|  --- |
| `Year` |
| `Month` |
| `Day` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    releaseDatePrecision := models.ReleaseDatePrecision_Year

}
```

