
# User

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`User`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mysql_settings` | [`MysqlSettings`](../../doc/models/mysql-settings.md) | Optional | - |
| `name` | `str` | Required | The name of a database user. |
| `password` | `str` | Optional, Read-only | A randomly generated password for the database user. |
| `role` | [`Role`](../../doc/models/role.md) | Optional, Read-only | A string representing the database user's role. The value will be either<br>"primary" or "normal". |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.auth_plugin import AuthPlugin
from digitaloceanapi.models.mysql_settings import MysqlSettings
from digitaloceanapi.models.role import Role
from digitaloceanapi.models.user import User

user = User(
    name='app-01',
    mysql_settings=MysqlSettings(
        auth_plugin=AuthPlugin.MYSQL_NATIVE_PASSWORD,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    password='jge5lfxtzhx42iff',
    role=Role.NORMAL,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

