
# Type 5

The object type.

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `AudioFeatures` |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;

Type5 type5 = Type5.AudioFeatures;
```

