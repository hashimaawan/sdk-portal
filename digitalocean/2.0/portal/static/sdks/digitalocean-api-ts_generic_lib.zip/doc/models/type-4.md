
# Type 4

A string representing the type of the certificate. The value will be `custom` for a user-uploaded certificate or `lets_encrypt` for one automatically generated with Let's Encrypt.

## Enumeration

`Type4`

## Fields

| Name |
|  --- |
| `Custom` |
| `LetsEncrypt` |

## Example

```ts
import { Type4 } from 'digitalocean-apilib';

const type4 = Type4.Custom;
```

