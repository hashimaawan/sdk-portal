
# List Named Queries Output

*This model accepts additional fields of type interface{}.*

## Structure

`ListNamedQueriesOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NamedQueryIds` | `[]string` | Optional | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `NextToken` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    listNamedQueriesOutput := models.ListNamedQueriesOutput{
        NamedQueryIds:         []string{
            "NamedQueryIds5",
            "NamedQueryIds4",
            "NamedQueryIds3",
        },
        NextToken:             models.ToPointer("NextToken2"),
        AdditionalProperties:  map[string]interface{}{
            "exampleAdditionalProperty": interface{}("[key1, val1][key2, val2]"),
        },
    }

}
```

