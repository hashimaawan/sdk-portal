# Images

Images are blueprints for your VM disks. They can be of different types:

### System Images

Distribution Images maintained by us, e.g. “Ubuntu 20.04”

### Snapshot Images

Maintained by you, for example “Ubuntu 20.04 with my own settings”. These are billed per GB per month.

### Backup Images

Daily Backups of your Server. Will automatically be created for Servers which have backups enabled (`POST /servers/{id}/actions/enable_backup`)

Bound to exactly one Server. If you delete the Server, you also delete all backups bound to it. You may convert backup Images to snapshot Images to keep them.

These are billed at 20% of your instance price for 7 backup slots.

### App Images

Prebuild images with specific software configurations, e.g. “Wordpress”. All app images are created by us.

```go
imagesApi := client.ImagesApi()
```

## Class Name

`ImagesApi`

## Methods

* [Get All Images](../../doc/controllers/images.md#get-all-images)
* [Delete an Image](../../doc/controllers/images.md#delete-an-image)
* [Get an Image](../../doc/controllers/images.md#get-an-image)
* [Update an Image](../../doc/controllers/images.md#update-an-image)


# Get All Images

Returns all Image objects. You can select specific Image types only and sort the results by using URI parameters.

```go
GetAllImages(
    ctx context.Context,
    sort *models.Sort,
    mType *models.Type21,
    status *models.Status23,
    boundTo *string,
    includeDeprecated *bool,
    name *string,
    labelSelector *string) (
    models.ApiResponse[models.ImagesResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sort` | [`*models.Sort`](../../doc/models/sort.md) | Query, Optional | Can be used multiple times. |
| `mType` | [`*models.Type21`](../../doc/models/type-21.md) | Query, Optional | Can be used multiple times. |
| `status` | [`*models.Status23`](../../doc/models/status-23.md) | Query, Optional | Can be used multiple times. The response will only contain Images matching the status. |
| `boundTo` | `*string` | Query, Optional | Can be used multiple times. Server ID linked to the Image. Only available for Images of type `backup` |
| `includeDeprecated` | `*bool` | Query, Optional | Can be used multiple times. |
| `name` | `*string` | Query, Optional | Can be used to filter resources by their name. The response will only contain the resources matching the specified name |
| `labelSelector` | `*string` | Query, Optional | Can be used to filter resources by labels. The response will only contain resources matching the label selector. |

## Response Type

**200**: The `images` key in the reply contains an array of Image objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ImagesResponse](../../doc/models/images-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := imagesApi.GetAllImages(ctx, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Delete an Image

Deletes an Image. Only Images of type `snapshot` and `backup` can be deleted.

```go
DeleteAnImage(
    ctx context.Context,
    id int) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |

## Response Type

**204**: Image deleted

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

id := 112

resp, err := imagesApi.DeleteAnImage(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```


# Get an Image

Returns a specific Image object.

```go
GetAnImage(
    ctx context.Context,
    id int) (
    models.ApiResponse[models.ImagesResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |

## Response Type

**200**: The `image` key in the reply contains an Image object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ImagesResponse1](../../doc/models/images-response-1.md).

## Example Usage

```go
ctx := context.Background()

id := 112

apiResponse, err := imagesApi.GetAnImage(ctx, id)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Update an Image

Updates the Image. You may change the description, convert a Backup Image to a Snapshot Image or change the Image labels. Only Images of type `snapshot` and `backup` can be updated.

Note that when updating labels, the current set of labels will be replaced with the labels provided in the request body. So, for example, if you want to add a new label, you have to provide all existing labels plus the new label in the request body.

```go
UpdateAnImage(
    ctx context.Context,
    id int,
    body *models.UpdateImageRequest) (
    models.ApiResponse[models.ImagesResponse1],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Image |
| `body` | [`*models.UpdateImageRequest`](../../doc/models/update-image-request.md) | Body, Optional | - |

## Response Type

**200**: The image key in the reply contains the modified Image object

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ImagesResponse1](../../doc/models/images-response-1.md).

## Example Usage

```go
ctx := context.Background()

id := 112

body := models.UpdateImageRequest{
    Description:           models.ToPointer("My new Image description"),
    Labels:                models.ToPointer(interface{}("[labelkey, value]")),
}

apiResponse, err := imagesApi.UpdateAnImage(ctx, id, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "image": {
    "bound_to": null,
    "build_id": "c313fe40383af26094a5a92026054320ab55abc7",
    "created": "2016-01-30T23:50:00+00:00",
    "created_from": {
      "id": 1,
      "name": "Server"
    },
    "deleted": null,
    "deprecated": "2018-02-28T00:00:00+00:00",
    "description": "My new Image description",
    "disk_size": 10,
    "id": 4711,
    "image_size": 2.3,
    "labels": {
      "labelkey": "value"
    },
    "name": null,
    "os_flavor": "ubuntu",
    "os_version": "20.04",
    "protection": {
      "delete": false
    },
    "rapid_deploy": false,
    "status": "available",
    "type": "snapshot"
  }
}
```

