
# Images Response 1

## Structure

`ImagesResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image` | [`Image`](../../doc/models/image.md) | Optional | - |

## Example

```ruby
images_response1 = ImagesResponse1.new(
  Image.new(
    186,
    'created6',
    CreatedFrom.new(
      60,
      'name6'
    ),
    'deleted4',
    'deprecated8',
    'description6',
    244.18,
    128,
    141.34,
    {
      'key0': 'labels4'
    },
    'name6',
    OsFlavorEnum::DEBIAN,
    'os_version4',
    Protection.new(
      false
    ),
    Status24Enum::UNAVAILABLE,
    Type22Enum::APP,
    false
  )
)
```

