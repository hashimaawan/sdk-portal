
# Change Ip Range Request

*This model accepts additional fields of type unknown.*

## Structure

`ChangeIpRangeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ipRange` | `string` | Required | The new prefix for the whole Network |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { ChangeIpRangeRequest } from 'hetzner-cloud-apilib';

const changeIpRangeRequest: ChangeIpRangeRequest = {
  ipRange: '10.0.0.0/12',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

