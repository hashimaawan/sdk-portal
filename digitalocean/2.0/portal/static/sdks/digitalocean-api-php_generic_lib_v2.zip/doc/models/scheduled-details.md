
# Scheduled Details

Trigger details for SCHEDULED type, where body is optional.

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`ScheduledDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `body` | [`?Body`](../../doc/models/body.md) | Optional | Optional data to be sent to function while triggering the function. | getBody(): ?Body | setBody(?Body body): void |
| `cron` | `string` | Required | valid cron expression string which is required for SCHEDULED type triggers. | getCron(): string | setCron(string cron): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\ScheduledDetailsBuilder;
use DigitalOceanApiLib\Models\Builders\BodyBuilder;
use DigitalOceanApiLib\ApiHelper;

$scheduledDetails = ScheduledDetailsBuilder::init(
    '* * * * *'
)
    ->body(
        BodyBuilder::init()
            ->name('name6')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

