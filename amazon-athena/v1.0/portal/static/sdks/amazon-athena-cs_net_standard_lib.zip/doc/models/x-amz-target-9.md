
# X Amz Target 9

## Enumeration

`XAmzTarget9`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaDeleteDataCatalog` |

## Example

```csharp
using AmazonAthena.Standard.Models;

XAmzTarget9 xAmzTarget9 = XAmzTarget9.EnumAmazonAthenaDeleteDataCatalog;
```

