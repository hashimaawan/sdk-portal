
# List Table Metadata Output

*This model accepts additional fields of type Any.*

## Structure

`ListTableMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `table_metadata_list` | [`List[TableMetadata]`](../../doc/models/table-metadata.md) | Optional | - |
| `next_token` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from amazonathena.models.column import Column
from amazonathena.models.list_table_metadata_output import ListTableMetadataOutput
from amazonathena.models.table_metadata import TableMetadata

list_table_metadata_output = ListTableMetadataOutput(
    table_metadata_list=[
        TableMetadata(
            name='Name2',
            create_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            last_access_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            table_type='TableType2',
            columns=[
                Column(
                    name='Name0',
                    mtype='Type0',
                    comment='Comment4',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            partition_keys=[
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        TableMetadata(
            name='Name2',
            create_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            last_access_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            table_type='TableType2',
            columns=[
                Column(
                    name='Name0',
                    mtype='Type0',
                    comment='Comment4',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            partition_keys=[
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        TableMetadata(
            name='Name2',
            create_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            last_access_time=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            table_type='TableType2',
            columns=[
                Column(
                    name='Name0',
                    mtype='Type0',
                    comment='Comment4',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            partition_keys=[
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                ),
                Column(
                    name='Name6',
                    mtype='Type6',
                    comment='Comment0',
                    additional_properties={
                        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
                    }
                )
            ],
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    next_token='NextToken8',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

