
# Assign Primary IP Request

## Structure

`AssignPrimaryIPRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `assignee_id` | `Integer` | Required | ID of a resource of type `assignee_type` |
| `assignee_type` | `String` | Required, Constant | Type of resource assigning the Primary IP to<br><br>**Value**: `'server'` |

## Example

```ruby
assign_primary_ip_request = AssignPrimaryIPRequest.new(
  4711,
  'server'
)
```

