
# M Shared Shared Vcpu Cores Dedicated Dedicated Vcpu Cores

## Enumeration

`MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `SHARED` |
| `DEDICATED` |

## Example

```ruby
m_shared_shared_v_cpu_cores_dedicated_dedicated_v_cpu_cores = MSharedSharedVcpuCoresDedicatedDedicatedVcpuCores::SHARED
```

