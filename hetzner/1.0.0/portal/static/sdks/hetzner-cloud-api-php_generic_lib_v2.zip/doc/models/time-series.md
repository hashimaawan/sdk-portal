
# Time Series

## Structure

`TimeSeries`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `values` | array<array<float\|string>> | Required | This is 2d Array of a container for one-of cases. | getValues(): array | setValues(array values): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\TimeSeriesBuilder;

$timeSeries = TimeSeriesBuilder::init(
    [
        [
            138.94,
            138.95
        ],
        [
            138.94,
            138.95
        ]
    ]
)->build();
```

