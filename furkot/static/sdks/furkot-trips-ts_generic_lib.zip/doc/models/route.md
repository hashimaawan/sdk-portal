
# Route

route leading to the stop

## Structure

`Route`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `distance` | `bigint \| undefined` | Optional | route distance in meters |
| `duration` | `bigint \| undefined` | Optional | route duration in seconds |
| `mode` | [`ModeEnum \| undefined`](../../doc/models/mode-enum.md) | Optional | travel mode |
| `polyline` | `string \| undefined` | Optional | route path compatible with Google polyline encoding algorithm |

## Example

```ts
import { ModeEnum, Route } from 'furkot-tripslib';

const route: Route = {
  distance: BigInt(134),
  duration: BigInt(168),
  mode: ModeEnum.Car,
  polyline: 'polyline0',
};
```

