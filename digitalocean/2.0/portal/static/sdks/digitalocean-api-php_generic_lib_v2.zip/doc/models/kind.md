
# Kind

- UNSPECIFIED: Default job type, will auto-complete to POST_DEPLOY kind.
- PRE_DEPLOY: Indicates a job that runs before an app deployment.
- POST_DEPLOY: Indicates a job that runs after an app deployment.
- FAILED_DEPLOY: Indicates a job that runs after a component fails to deploy.

## Enumeration

`Kind`

## Fields

| Name |
|  --- |
| `UNSPECIFIED` |
| `PRE_DEPLOY` |
| `POST_DEPLOY` |
| `FAILED_DEPLOY` |

## Example

```php
use DigitalOceanApiLib\Models\Kind;

$kind = Kind::POST_DEPLOY;
```

