
# Dns Ptr

## Structure

`DnsPtr`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DnsPtr` | `String` | Required | DNS pointer for the specific IP address | String getDnsPtr() | setDnsPtr(String dnsPtr) |
| `Ip` | `String` | Required | Single IPv4 or IPv6 address | String getIp() | setIp(String ip) |

## Example

```java
import cloud.hetzner.api.models.DnsPtr;

DnsPtr dnsPtr = new DnsPtr.Builder(
    "server.example.com",
    "2001:db8::1"
)
.build();
```

