# Primary IP Actions

```java
PrimaryIPActionsController primaryIPActionsController = client.getPrimaryIPActionsController();
```

## Class Name

`PrimaryIPActionsController`

## Methods

* [Assign a Primary IP to a Resource](../../doc/controllers/primary-ip-actions.md#assign-a-primary-ip-to-a-resource)
* [Change Reverse DNS Entry for a Primary IP](../../doc/controllers/primary-ip-actions.md#change-reverse-dns-entry-for-a-primary-ip)
* [Change Primary IP Protection](../../doc/controllers/primary-ip-actions.md#change-primary-ip-protection)
* [Unassign a Primary IP from a Resource](../../doc/controllers/primary-ip-actions.md#unassign-a-primary-ip-from-a-resource)


# Assign a Primary IP to a Resource

Assigns a Primary IP to a Server.

A Server can only have one Primary IP of type `ipv4` and one of type `ipv6` assigned. If you need more IPs use Floating IPs.

The Server must be powered off (status `off`) in order for this operation to succeed.

#### Call specific error codes

| Code                          | Description                                                   |
|------------------------------ |-------------------------------------------------------------- |
| `server_not_stopped`          | The server is running, but needs to be powered off            |
| `primary_ip_already_assigned` | Primary ip is already assigned to a different server          |
| `server_has_ipv4`             | The server already has an ipv4 address                        |
| `server_has_ipv6`             | The server already has an ipv6 address                        |

```java
CompletableFuture<ActionResponse> assignAPrimaryIPToAResourceAsync(
    final int id,
    final AssignPrimaryIPRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Primary IP |
| `body` | [`AssignPrimaryIPRequest`](../../doc/models/assign-primary-ip-request.md) | Body, Optional | - |

## Response Type

**201**: The `action` key in the reply contains an Action object with this structure

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
AssignPrimaryIPRequest body = new AssignPrimaryIPRequest.Builder(
    4711,
    "server"
)
.build();

primaryIPActionsController.assignAPrimaryIPToAResourceAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "assign_primary_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "primary_ip"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```


# Change Reverse DNS Entry for a Primary IP

Changes the hostname that will appear when getting the hostname belonging to this Primary IP.

```java
CompletableFuture<ActionResponse> changeReverseDNSEntryForAPrimaryIPAsync(
    final int id,
    final ChangeDNSPTRRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Primary IP |
| `body` | [`ChangeDNSPTRRequest`](../../doc/models/change-dnsptr-request.md) | Body, Optional | Select the IP address for which to change the DNS entry by passing `ip`. For a Primary IP of type `ipv4` this must exactly match the IP address of the Primary IP. For a Primary IP of type `ipv6` this must be a single IP within the IPv6 /64 range that belongs to this Primary IP.<br><br>The target hostname is set by passing `dns_ptr`. |

## Response Type

**201**: The `action` key contains the `change_dns_ptr` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
ChangeDNSPTRRequest body = new ChangeDNSPTRRequest.Builder(
    "server02.example.com",
    "1.2.3.4"
)
.build();

primaryIPActionsController.changeReverseDNSEntryForAPrimaryIPAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_dns_ptr",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "primary_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Change Primary IP Protection

Changes the protection configuration of a Primary IP.

A Primary IP can only be delete protected if its `auto_delete` property is set to `false`.

```java
CompletableFuture<ActionResponse> changePrimaryIPProtectionAsync(
    final int id,
    final ChangeProtectionRequest2 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Primary IP |
| `body` | [`ChangeProtectionRequest2`](../../doc/models/change-protection-request-2.md) | Body, Optional | - |

## Response Type

**201**: The `action` key contains the `change_protection` Action

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;
ChangeProtectionRequest2 body = new ChangeProtectionRequest2.Builder()
    .delete(true)
    .build();

primaryIPActionsController.changePrimaryIPProtectionAsync(id, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "change_protection",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": "2016-01-30T23:56:00+00:00",
    "id": 13,
    "progress": 100,
    "resources": [
      {
        "id": 4711,
        "type": "primary_ip"
      }
    ],
    "started": "2016-01-30T23:55:00+00:00",
    "status": "success"
  }
}
```


# Unassign a Primary IP from a Resource

Unassigns a Primary IP from a Server.

The Server must be powered off (status `off`) in order for this operation to succeed.

Note that only Servers that have at least one network interface (public or private) attached can be powered on.

#### Call specific error codes

| Code                              | Description                                                   |
|---------------------------------- |-------------------------------------------------------------- |
| `server_not_stopped`              | The server is running, but needs to be powered off            |
| `server_is_load_balancer_target`  | The server ipv4 address is a loadbalancer target              |

```java
CompletableFuture<ActionResponse> unassignAPrimaryIPFromAResourceAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of the Primary IP |

## Response Type

**201**: The `action` key in the reply contains an Action object with this structure

[`ActionResponse`](../../doc/models/action-response.md)

## Example Usage

```java
int id = 112;

primaryIPActionsController.unassignAPrimaryIPFromAResourceAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "action": {
    "command": "unassign_primary_ip",
    "error": {
      "code": "action_failed",
      "message": "Action failed"
    },
    "finished": null,
    "id": 13,
    "progress": 0,
    "resources": [
      {
        "id": 42,
        "type": "server"
      },
      {
        "id": 4711,
        "type": "primary_ip"
      }
    ],
    "started": "2016-01-30T23:50:00+00:00",
    "status": "running"
  }
}
```

