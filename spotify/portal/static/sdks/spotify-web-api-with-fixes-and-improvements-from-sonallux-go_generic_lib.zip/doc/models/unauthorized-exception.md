
# Unauthorized Exception

*This model accepts additional fields of type interface{}.*

## Structure

`UnauthorizedException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`models.ErrorObject`](../../doc/models/error-object.md) | Required | - |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example

```go
if err != nil {
    switch typedErr := err.(type) {
    case *errors.UnauthorizedException:
        log.Fatalln(typedErr)
    default:
        log.Fatalln(err)
    }
}
```

