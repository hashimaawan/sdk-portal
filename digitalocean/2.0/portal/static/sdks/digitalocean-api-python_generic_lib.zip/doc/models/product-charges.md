
# Product Charges

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`ProductCharges`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `str` | Optional | Total amount charged |
| `items` | [`List[Item]`](../../doc/models/item.md) | Optional | List of amount, and grouped aggregates by resource type. |
| `name` | `str` | Optional | Description of usage charges |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.item import Item
from digitaloceanapi.models.product_charges import ProductCharges

product_charges = ProductCharges(
    amount='12.34',
    items=[
        Item(
            amount='10.00',
            count='1',
            name='Spaces Subscription',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        ),
        Item(
            amount='2.34',
            count='1',
            name='Database Clusters',
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    name='Product usage charges',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

