
# Type 22

Type of the Image

## Enumeration

`Type22`

## Fields

| Name |
|  --- |
| `SYSTEM` |
| `APP` |
| `SNAPSHOT` |
| `BACKUP` |
| `TEMPORARY` |

## Example

```java
import cloud.hetzner.api.models.Type22;

Type22 type22 = Type22.TEMPORARY;
```

