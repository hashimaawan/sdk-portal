
# List Query Executions Output

## Structure

`ListQueryExecutionsOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_ids` | `Array[String]` | Optional | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```ruby
list_query_executions_output = ListQueryExecutionsOutput.new(
  [
    'QueryExecutionIds3',
    'QueryExecutionIds4'
  ],
  'NextToken6'
)
```

