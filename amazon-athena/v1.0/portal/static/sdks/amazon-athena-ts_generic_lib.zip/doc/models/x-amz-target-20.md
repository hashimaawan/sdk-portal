
# X Amz Target 20

## Enumeration

`XAmzTarget20`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetNamedQuery` |

## Example

```ts
import { XAmzTarget20 } from 'amazon-athenalib';

const xAmzTarget20 = XAmzTarget20.EnumAmazonAthenaGetNamedQuery;
```

