
# V2 Firewalls Rules Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2FirewallsRulesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `inboundRules` | [`?(InboundRule[])`](../../doc/models/inbound-rule.md) | Required | - | getInboundRules(): ?array | setInboundRules(?array inboundRules): void |
| `outboundRules` | [`?(OutboundRule[])`](../../doc/models/outbound-rule.md) | Required | - | getOutboundRules(): ?array | setOutboundRules(?array outboundRules): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2FirewallsRulesRequestBuilder;
use DigitalOceanApiLib\Models\Builders\InboundRuleBuilder;
use DigitalOceanApiLib\Models\Protocol;
use DigitalOceanApiLib\Models\Builders\SourcesBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Builders\OutboundRuleBuilder;
use DigitalOceanApiLib\Models\Builders\DestinationsBuilder;

$v2FirewallsRulesRequest = V2FirewallsRulesRequestBuilder::init()
    ->inboundRules(
        [
            InboundRuleBuilder::init(
                '8000',
                Protocol::TCP,
                SourcesBuilder::init()
                    ->addresses(
                        [
                            '1.2.3.4',
                            '18.0.0.0/8'
                        ]
                    )
                    ->dropletIds(
                        [
                            8043964
                        ]
                    )
                    ->kubernetesIds(
                        [
                            '41b74c5d-9bd0-5555-5555-a57c495b81a3'
                        ]
                    )
                    ->loadBalancerUids(
                        [
                            '4de7ac8b-495b-4884-9a69-1050c6793cd6'
                        ]
                    )
                    ->tags(
                        [
                            'tags1',
                            'tags2',
                            'tags3'
                        ]
                    )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->outboundRules(
        [
            OutboundRuleBuilder::init(
                '8000',
                Protocol::TCP,
                DestinationsBuilder::init()
                    ->addresses(
                        [
                            '1.2.3.4',
                            '18.0.0.0/8'
                        ]
                    )
                    ->dropletIds(
                        [
                            8043964
                        ]
                    )
                    ->kubernetesIds(
                        [
                            '41b74c5d-9bd0-5555-5555-a57c495b81a3'
                        ]
                    )
                    ->loadBalancerUids(
                        [
                            '4de7ac8b-495b-4884-9a69-1050c6793cd6'
                        ]
                    )
                    ->tags(
                        [
                            'tags7',
                            'tags8',
                            'tags9'
                        ]
                    )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

