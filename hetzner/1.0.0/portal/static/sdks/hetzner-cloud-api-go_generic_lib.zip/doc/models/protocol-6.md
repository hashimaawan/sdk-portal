
# Protocol 6

Type of the health check

## Enumeration

`Protocol6`

## Fields

| Name |
|  --- |
| `Tcp` |
| `Http` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    protocol6 := models.Protocol6_Tcp

}
```

