
# Query Execution State Enum

## Enumeration

`QueryExecutionStateEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `FAILED` |
| `CANCELLED` |

## Example

```php
use AmazonAthenaLib\Models\QueryExecutionStateEnum;

$queryExecutionState = QueryExecutionStateEnum::CANCELLED;
```

