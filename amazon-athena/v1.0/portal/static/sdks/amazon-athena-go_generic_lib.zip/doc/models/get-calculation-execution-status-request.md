
# Get Calculation Execution Status Request

## Structure

`GetCalculationExecutionStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CalculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getCalculationExecutionStatusRequest := models.GetCalculationExecutionStatusRequest{
        CalculationExecutionId: "CalculationExecutionId8",
    }

}
```

