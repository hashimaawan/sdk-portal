
# Query Stage Plan

*This model accepts additional fields of type unknown.*

## Structure

`QueryStagePlan`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | - |
| `identifier` | `string \| undefined` | Optional | - |
| `children` | [`QueryStagePlanNode[] \| undefined`](../../doc/models/query-stage-plan-node.md) | Optional | - |
| `remoteSources` | `string[] \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { QueryStagePlan } from 'amazon-athenalib';

const queryStagePlan: QueryStagePlan = {
  name: 'Name0',
  identifier: 'Identifier6',
  children: [
    {
      name: 'Name6',
      identifier: 'Identifier2',
      children: [
        {
        }
      ],
      remoteSources: [
        'RemoteSources4',
        'RemoteSources5',
        'RemoteSources6'
      ],
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  remoteSources: [
    'RemoteSources8',
    'RemoteSources9',
    'RemoteSources0'
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

