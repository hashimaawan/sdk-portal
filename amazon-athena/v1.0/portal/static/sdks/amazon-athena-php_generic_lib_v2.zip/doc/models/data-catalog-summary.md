
# Data Catalog Summary

The summary information for the data catalog, which includes its name and type.

## Structure

`DataCatalogSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `catalogName` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` | getCatalogName(): ?string | setCatalogName(?string catalogName): void |
| `type` | [`?string(DataCatalogType2Enum)`](../../doc/models/data-catalog-type-2-enum.md) | Optional | - | getType(): ?string | setType(?string type): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DataCatalogSummaryBuilder;
use AmazonAthenaLib\Models\DataCatalogType2Enum;

$dataCatalogSummary = DataCatalogSummaryBuilder::init()
    ->catalogName('CatalogName2')
    ->type(DataCatalogType2Enum::HIVE)
    ->build();
```

