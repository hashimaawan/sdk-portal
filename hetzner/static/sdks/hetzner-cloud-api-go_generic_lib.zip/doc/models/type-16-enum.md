
# Type 16 Enum

Type of the Floating IP

## Enumeration

`Type16Enum`

## Fields

| Name |
|  --- |
| `IPV4` |
| `IPV6` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type16 := models.Type16Enum_IPV4

}
```

