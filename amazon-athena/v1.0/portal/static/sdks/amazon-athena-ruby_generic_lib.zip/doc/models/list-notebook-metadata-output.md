
# List Notebook Metadata Output

*This model accepts additional fields of type Object.*

## Structure

`ListNotebookMetadataOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_token` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `notebook_metadata_list` | [`Array[NotebookMetadata]`](../../doc/models/notebook-metadata.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
list_notebook_metadata_output = ListNotebookMetadataOutput.new(
  next_token: 'NextToken8',
  notebook_metadata_list: [
    NotebookMetadata.new(
      notebook_id: 'NotebookId4',
      name: 'Name4',
      work_group: 'WorkGroup6',
      creation_time: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
      type: NotebookType1::IPYNB,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

