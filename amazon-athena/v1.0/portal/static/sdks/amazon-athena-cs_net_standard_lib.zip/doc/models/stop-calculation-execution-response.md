
# Stop Calculation Execution Response

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `State` | [`CalculationExecutionState4Enum?`](../../doc/models/calculation-execution-state-4-enum.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

StopCalculationExecutionResponse stopCalculationExecutionResponse = new StopCalculationExecutionResponse
{
    State = CalculationExecutionState4Enum.QUEUED,
};
```

