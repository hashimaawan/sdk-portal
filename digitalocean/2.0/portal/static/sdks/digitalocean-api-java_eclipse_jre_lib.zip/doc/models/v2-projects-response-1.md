
# V2 Projects Response 1

*This model accepts additional fields of type Object.*

## Structure

`V2ProjectsResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Project` | [`Project`](../../doc/models/project.md) | Optional | - | Project getProject() | setProject(Project project) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.DateTimeHelper;
import com.digitalocean.api.models.Environment;
import com.digitalocean.api.models.Project;
import com.digitalocean.api.models.V2ProjectsResponse1;
import java.io.IOException;
import java.util.UUID;

V2ProjectsResponse1 v2ProjectsResponse1 = new V2ProjectsResponse1.Builder()
    .project(new Project.Builder()
        .createdAt(DateTimeHelper.fromRfc8601DateTime("2016-03-13T12:52:32.123Z"))
        .description("description4")
        .environment(Environment.DEVELOPMENT)
        .id(UUID.fromString("000026e4-0000-0000-0000-000000000000"))
        .name("name6")
    .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build())
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
    .build();
```

