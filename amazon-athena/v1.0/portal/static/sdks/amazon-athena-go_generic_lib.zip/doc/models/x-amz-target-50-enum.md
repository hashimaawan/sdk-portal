
# X Amz Target 50 Enum

## Enumeration

`XAmzTarget50Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENASTOPQUERYEXECUTION` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget50 := models.XAmzTarget50Enum_ENUMAMAZONATHENASTOPQUERYEXECUTION

}
```

