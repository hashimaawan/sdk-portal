
# Batch Get Query Execution Input

Contains an array of query execution IDs.

## Structure

`BatchGetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_ids` | `List[str]` | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```python
from amazonathena.models.batch_get_query_execution_input import BatchGetQueryExecutionInput

batch_get_query_execution_input = BatchGetQueryExecutionInput(
    query_execution_ids=[
        'QueryExecutionIds7'
    ]
)
```

