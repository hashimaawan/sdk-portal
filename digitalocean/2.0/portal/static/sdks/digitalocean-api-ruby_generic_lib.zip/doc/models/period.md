
# Period

Period of time the threshold must be exceeded to trigger the alert.

## Enumeration

`Period`

## Fields

| Name |
|  --- |
| `ENUM_2M` |
| `ENUM_3M` |
| `ENUM_5M` |
| `ENUM_10M` |
| `ENUM_15M` |
| `ENUM_30M` |
| `ENUM_1H` |

## Example

```ruby
period = Period::ENUM_5M
```

