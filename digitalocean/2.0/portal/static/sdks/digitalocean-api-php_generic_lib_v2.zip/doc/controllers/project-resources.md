# Project Resources

```php
$projectResourcesApi = $client->getProjectResourcesApi();
```

## Class Name

`ProjectResourcesApi`

## Methods

* [Projects List Resources Default](../../doc/controllers/project-resources.md#projects-list-resources-default)
* [Projects Assign Resources Default](../../doc/controllers/project-resources.md#projects-assign-resources-default)
* [Projects List Resources](../../doc/controllers/project-resources.md#projects-list-resources)
* [Projects Assign Resources](../../doc/controllers/project-resources.md#projects-assign-resources)


# Projects List Resources Default

To list all your resources in your default project, send a GET request to `/v2/projects/default/resources`.

```php
function projectsListResourcesDefault(): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse`](../../doc/models/v2-projects-default-resources-response.md).

## Example Usage

```php
$projectResourcesApi = $client->getProjectResourcesApi();
$apiResponse = $projectResourcesApi->projectsListResourcesDefault();

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2ProjectsDefaultResourcesResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects Assign Resources Default

To assign resources to your default project, send a POST request to `/v2/projects/default/resources`.

```php
function projectsAssignResourcesDefault(V2ProjectsDefaultResourcesRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2ProjectsDefaultResourcesRequest`](../../doc/models/v2-projects-default-resources-request.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse1`](../../doc/models/v2-projects-default-resources-response-1.md).

## Example Usage

```php
$body = V2ProjectsDefaultResourcesRequestBuilder::init()
    ->resources(
        [
            'do:droplet:13457723',
            'do:domain:example.com'
        ]
    )
    ->build();

$projectResourcesApi = $client->getProjectResourcesApi();
$apiResponse = $projectResourcesApi->projectsAssignResourcesDefault($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2ProjectsDefaultResourcesResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects List Resources

To list all your resources in a project, send a GET request to `/v2/projects/$PROJECT_ID/resources`.

```php
function projectsListResources(string $projectId, ?int $perPage = 20, ?int $page = 1): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `projectId` | `string` | Template, Required | A unique identifier for a project. |
| `perPage` | `?int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `?int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse`](../../doc/models/v2-projects-default-resources-response.md).

## Example Usage

```php
$projectId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$perPage = 2;

$page = 1;

$projectResourcesApi = $client->getProjectResourcesApi();
$apiResponse = $projectResourcesApi->projectsListResources(
    $projectId,
    $perPage,
    $page
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2ProjectsDefaultResourcesResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Projects Assign Resources

To assign resources to a project, send a POST request to `/v2/projects/$PROJECT_ID/resources`.

```php
function projectsAssignResources(string $projectId, V2ProjectsDefaultResourcesRequest $body): ApiResponse
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `projectId` | `string` | Template, Required | A unique identifier for a project. |
| `body` | [`V2ProjectsDefaultResourcesRequest`](../../doc/models/v2-projects-default-resources-request.md) | Body, Required | - |

## Response Type

**200**: The response will be a JSON object with a key called `resources`. The value of this will be an object with the standard resource attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`V2ProjectsDefaultResourcesResponse1`](../../doc/models/v2-projects-default-resources-response-1.md).

## Example Usage

```php
$projectId = '4de7ac8b-495b-4884-9a69-1050c6793cd6';

$body = V2ProjectsDefaultResourcesRequestBuilder::init()
    ->resources(
        [
            'do:droplet:13457723',
            'do:domain:example.com'
        ]
    )
    ->build();

$projectResourcesApi = $client->getProjectResourcesApi();
$apiResponse = $projectResourcesApi->projectsAssignResources(
    $projectId,
    $body
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'V2ProjectsDefaultResourcesResponse1:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

