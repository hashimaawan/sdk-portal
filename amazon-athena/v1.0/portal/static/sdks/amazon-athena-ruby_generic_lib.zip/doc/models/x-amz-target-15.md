
# X Amz Target 15

## Enumeration

`XAmzTarget15`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETCALCULATIONEXECUTION` |

## Example

```ruby
x_amz_target15 = XAmzTarget15::ENUM_AMAZONATHENAGETCALCULATIONEXECUTION
```

