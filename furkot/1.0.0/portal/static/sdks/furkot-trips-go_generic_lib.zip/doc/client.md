
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](../README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| furkotAuthAccessCodeCredentials | [`FurkotAuthAccessCodeCredentials`](auth/oauth-2-authorization-code-grant.md) | The Credentials Setter for OAuth 2 Authorization Code Grant |
| furkotAuthImplicitCredentials | [`FurkotAuthImplicitCredentials`](auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

```go
package main

import (
    "furkottrips"
    "furkottrips/models"
)

func main() {
    client := furkottrips.NewClient(
    furkottrips.CreateConfiguration(
            furkottrips.WithHttpConfiguration(
                furkottrips.CreateHttpConfiguration(
                    furkottrips.WithTimeout(0),
                ),
            ),
            furkottrips.WithEnvironment(furkottrips.PRODUCTION),
            furkottrips.WithFurkotAuthAccessCodeCredentials(
                furkottrips.NewFurkotAuthAccessCodeCredentials(
                    "OAuthClientId",
                    "OAuthClientSecret",
                    "OAuthRedirectUri",
                ).
                WithOAuthScopes([]models.OAuthScopeFurkotAuthAccessCodeEnum{
        models.OAuthScopeFurkotAuthAccessCodeEnum_READTRIPS,
    }),
            ),
            furkottrips.WithFurkotAuthImplicitCredentials(
                furkottrips.NewFurkotAuthImplicitCredentials(
                    "OAuthClientId",
                    "OAuthRedirectUri",
                ).
                WithOAuthScopes([]models.OAuthScopeFurkotAuthImplicitEnum{
        models.OAuthScopeFurkotAuthImplicitEnum_READTRIPS,
    }),
            ),
        ),
    )
}
```

## Furkot Trips Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| APIController() | Gets APIController |
| OAuthAuthorizationController() | Gets OAuthAuthorizationController |

