
# Warning

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Warning`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `code` | [`?string(Code)`](../../doc/models/code.md) | Optional | A code identifier that represents the failing condition.<br><br>Failing conditions:<br><br>- `incompatible_phase` - indicates that the deployment's phase is not suitable for rollback.<br>- `incompatible_result` - indicates that the deployment's result is not suitable for rollback.<br>- `exceeded_revision_limit` - indicates that the app has exceeded the rollback revision limits for its tier.<br>- `app_pinned` - indicates that there is already a rollback in progress and the app is pinned.<br>- `database_config_conflict` - indicates that the deployment's database config is different than the current config.<br>- `region_conflict` - indicates that the deployment's region differs from the current app region.<br><br>Warning conditions:<br><br>- `static_site_requires_rebuild` - indicates that the deployment contains at least one static site that will require a rebuild.<br>- `image_source_missing_digest` - indicates that the deployment contains at least one component with an image source that is missing a digest. | getCode(): ?string | setCode(?string code): void |
| `components` | `?(string[])` | Optional | - | getComponents(): ?array | setComponents(?array components): void |
| `message` | `?string` | Optional | A human-readable message describing the failing condition. | getMessage(): ?string | setMessage(?string message): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\WarningBuilder;
use DigitalOceanApiLib\Models\Code;
use DigitalOceanApiLib\ApiHelper;

$warning = WarningBuilder::init()
    ->code(Code::EXCEEDED_REVISION_LIMIT)
    ->components(
        [
            'www'
        ]
    )
    ->message('the deployment is past the maximum historical revision limit of 0 for the "starter" app tier')
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

