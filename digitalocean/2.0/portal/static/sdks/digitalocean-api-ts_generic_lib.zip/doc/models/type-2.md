
# Type 2

- GENERAL: A plain-text environment variable
- SECRET: A secret encrypted environment variable

## Enumeration

`Type2`

## Fields

| Name |
|  --- |
| `General` |
| `Secret` |

## Example

```ts
import { Type2 } from 'digitalocean-apilib';

const type2 = Type2.General;
```

