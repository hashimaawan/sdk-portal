
# Price

## Structure

`Price`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `location` | `string` | Required | Name of the Location the price is for | getLocation(): string | setLocation(string location): void |
| `priceHourly` | [`PriceHourly`](../../doc/models/price-hourly.md) | Required | Hourly costs for a Resource in this Location | getPriceHourly(): PriceHourly | setPriceHourly(PriceHourly priceHourly): void |
| `priceMonthly` | [`PriceMonthly`](../../doc/models/price-monthly.md) | Required | Monthly costs for a Resource in this Location | getPriceMonthly(): PriceMonthly | setPriceMonthly(PriceMonthly priceMonthly): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\PriceBuilder;
use HetznerCloudAPILib\Models\Builders\PriceHourlyBuilder;
use HetznerCloudAPILib\Models\Builders\PriceMonthlyBuilder;

$price = PriceBuilder::init(
    'fsn1',
    PriceHourlyBuilder::init(
        '1.1900000000000000',
        '1.0000000000'
    )->build(),
    PriceMonthlyBuilder::init(
        '1.1900000000000000',
        '1.0000000000'
    )->build()
)->build();
```

