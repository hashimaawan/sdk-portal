
# X Amz Target

## Enumeration

`XAmzTarget`

## Fields

| Name |
|  --- |
| `EnumAmazonathenabatchgetnamedquery` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget := models.XAmzTarget_EnumAmazonathenabatchgetnamedquery

}
```

