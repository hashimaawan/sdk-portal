
# Type 20

The type of alert.

## Enumeration

`Type20`

## Fields

| Name |
|  --- |
| `LATENCY` |
| `DOWN` |
| `DOWN_GLOBAL` |
| `SSL_EXPIRY` |

## Example

```python
from digitaloceanapi.models.type_20 import Type20

type_20 = Type20.LATENCY
```

