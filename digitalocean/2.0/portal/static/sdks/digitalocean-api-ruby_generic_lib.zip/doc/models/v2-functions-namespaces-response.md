
# V2 Functions Namespaces Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2FunctionsNamespacesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `namespaces` | [`Array[Namespace]`](../../doc/models/namespace.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_functions_namespaces_response = V2FunctionsNamespacesResponse.new(
  namespaces: [
    Namespace.new(
      api_host: 'api_host8',
      created_at: 'created_at0',
      key: 'key2',
      label: 'label2',
      namespace: 'namespace0',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

