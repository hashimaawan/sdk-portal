
# V2 Uptime Checks Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2UptimeChecksResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checks` | [`Array[Check]`](../../doc/models/check.md) | Optional | - |
| `links` | [`Links`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_uptime_checks_response = V2UptimeChecksResponse.new(
  meta: Meta.new(
    total: 1,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  checks: [
    Check.new(
      id: '00000820-0000-0000-0000-000000000000',
      enabled: false,
      name: 'name0',
      regions: [
        Region8::US_WEST,
        Region8::EU_WEST,
        Region8::SE_ASIA
      ],
      target: 'target2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    Check.new(
      id: '00000820-0000-0000-0000-000000000000',
      enabled: false,
      name: 'name0',
      regions: [
        Region8::US_WEST,
        Region8::EU_WEST,
        Region8::SE_ASIA
      ],
      target: 'target2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  links: Links.new(
    pages: Pages.new(
      last: 'last6',
      mnext: 'next2',
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

