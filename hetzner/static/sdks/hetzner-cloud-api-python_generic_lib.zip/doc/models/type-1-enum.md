
# Type 1 Enum

Choose between uploading a Certificate in PEM format or requesting a managed *Let's Encrypt* Certificate. If omitted defaults to `uploaded`.

## Enumeration

`Type1Enum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```python
from hetznercloudapi.models.type_1_enum import Type1Enum

type_1 = Type1Enum.UPLOADED
```

