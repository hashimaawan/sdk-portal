
# Service Components that Are Part of This Deployment

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`ServiceComponentsThatArePartOfThisDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | - |
| `source_commit_hash` | `String` | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
service_components_that_are_part_of_this_deployment = ServiceComponentsThatArePartOfThisDeployment.new(
  name: 'web',
  source_commit_hash: '54d4a727f457231062439895000d45437c7bb405',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

