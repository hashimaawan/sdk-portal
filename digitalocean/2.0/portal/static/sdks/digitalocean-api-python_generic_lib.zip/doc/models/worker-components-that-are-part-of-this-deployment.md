
# Worker Components that Are Part of This Deployment

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`WorkerComponentsThatArePartOfThisDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | - |
| `source_commit_hash` | `str` | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.worker_components_that_are_part_of_this_deployment import WorkerComponentsThatArePartOfThisDeployment

worker_components_that_are_part_of_this_deployment = WorkerComponentsThatArePartOfThisDeployment(
    name='queue-runner',
    source_commit_hash='54d4a727f457231062439895000d45437c7bb405',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

