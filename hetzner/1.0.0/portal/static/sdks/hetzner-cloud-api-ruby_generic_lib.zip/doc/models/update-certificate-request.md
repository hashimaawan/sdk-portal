
# Update Certificate Request

*This model accepts additional fields of type Object.*

## Structure

`UpdateCertificateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Object` | Optional | User-defined labels (key-value pairs) |
| `name` | `String` | Optional | New Certificate name |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
update_certificate_request = UpdateCertificateRequest.new(
  labels: { 'labelkey' => 'value' },
  name: 'my website cert',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

