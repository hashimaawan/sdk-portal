
# Get Query Runtime Statistics Input

## Structure

`GetQueryRuntimeStatisticsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `query_execution_id` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ruby
get_query_runtime_statistics_input = GetQueryRuntimeStatisticsInput.new(
  'QueryExecutionId0'
)
```

