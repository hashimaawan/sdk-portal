
# Price Hourly 7

Hourly costs for a Primary IP type in this Location

## Structure

`PriceHourly7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    priceHourly7 := models.PriceHourly7{
        Gross:                "1.1900000000000000",
        Net:                  "1.0000000000",
    }

}
```

