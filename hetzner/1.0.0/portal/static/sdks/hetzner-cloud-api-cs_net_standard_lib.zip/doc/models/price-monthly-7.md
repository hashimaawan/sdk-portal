
# Price Monthly 7

Monthly costs for a Floating IP type in this Location

## Structure

`PriceMonthly7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Gross` | `string` | Required | Price with VAT added |
| `Net` | `string` | Required | Price without VAT |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

PriceMonthly7 priceMonthly7 = new PriceMonthly7
{
    Gross = "1.1900000000000000",
    Net = "1.0000000000",
};
```

