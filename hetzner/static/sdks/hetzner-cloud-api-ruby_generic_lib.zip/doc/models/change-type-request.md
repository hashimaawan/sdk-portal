
# Change Type Request

## Structure

`ChangeTypeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `load_balancer_type` | `String` | Required | ID or name of Load Balancer type the Load Balancer should migrate to |

## Example

```ruby
change_type_request = ChangeTypeRequest.new(
  'lb21'
)
```

