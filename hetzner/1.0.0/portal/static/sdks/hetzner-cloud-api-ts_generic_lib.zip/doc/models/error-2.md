
# Error 2

If issuance or renewal reports `failed`, this property contains information about what happened

*This model accepts additional fields of type unknown.*

## Structure

`Error2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Error2 } from 'hetzner-cloud-apilib';

const error2: Error2 = {
  code: 'code2',
  message: 'message4',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

