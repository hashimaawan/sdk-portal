
# Policy

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Policy`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alerts` | [`Alerts`](../../doc/models/alerts.md) | Required | - |
| `compare` | [`Compare`](../../doc/models/compare.md) | Required | - |
| `description` | `String` | Required | - |
| `enabled` | `TrueClass \| FalseClass` | Required | - |
| `entities` | `Array[String]` | Required | - |
| `tags` | `Array[String]` | Required | - |
| `type` | [`Type17`](../../doc/models/type-17.md) | Required | - |
| `uuid` | `String` | Required | - |
| `value` | `Float` | Required | - |
| `window` | [`Window1`](../../doc/models/window-1.md) | Required | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
policy = Policy.new(
  alerts: Alerts.new(
    email: [
      'bob@exmaple.com'
    ],
    slack: [
      Slack.new(
        channel: 'Production Alerts',
        url: 'https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ',
        additional_properties: {
          'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
        }
      )
    ],
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  compare: Compare::GREATERTHAN,
  description: 'CPU Alert',
  enabled: true,
  entities: [
    '192018292'
  ],
  tags: [
    'droplet_tag'
  ],
  type: Type17::ENUM_V1INSIGHTSDROPLETCPU,
  uuid: '78b3da62-27e5-49ba-ac70-5db0b5935c64',
  value: 80,
  window: Window1::ENUM_5M,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

