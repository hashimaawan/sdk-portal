
# Direction

## Enumeration

`Direction`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```python
from digitaloceanapi.models.direction import Direction

direction = Direction.INBOUND
```

