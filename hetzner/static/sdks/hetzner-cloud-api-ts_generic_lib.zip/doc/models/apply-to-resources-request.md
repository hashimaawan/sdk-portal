
# Apply to Resources Request

## Structure

`ApplyToResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `applyTo` | [`FirewallApplyToResources[]`](../../doc/models/firewall-apply-to-resources.md) | Required | Resources the Firewall should be applied to |

## Example

```ts
import { ApplyToResourcesRequest, Type7Enum } from 'hetzner-cloud-apilib';

const applyToResourcesRequest: ApplyToResourcesRequest = {
  applyTo: [
    {
      labelSelector: {
        selector: 'selector8',
      },
      server: {
        id: 14,
      },
      type: Type7Enum.Server,
    }
  ],
};
```

