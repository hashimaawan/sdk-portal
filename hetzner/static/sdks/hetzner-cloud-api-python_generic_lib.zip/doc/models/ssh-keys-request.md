
# Ssh Keys Request

## Structure

`SshKeysRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | `Any` | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Required | Name of the SSH key |
| `public_key` | `str` | Required | Public key |

## Example

```python
import jsonpickle

from hetznercloudapi.models.ssh_keys_request import SshKeysRequest

ssh_keys_request = SshKeysRequest(
    name='My ssh key',
    public_key='ssh-rsa AAAjjk76kgf...Xt',
    labels=jsonpickle.decode('{"key1":"val1","key2":"val2"}')
)
```

