
# Stop Calculation Execution Request

## Structure

`StopCalculationExecutionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `calculation_execution_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |

## Example

```python
from amazonathena.models.stop_calculation_execution_request import StopCalculationExecutionRequest

stop_calculation_execution_request = StopCalculationExecutionRequest(
    calculation_execution_id='CalculationExecutionId2'
)
```

