
# X Amz Target 54

## Enumeration

`XAmzTarget54`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEDATACATALOG` |

## Example

```ruby
x_amz_target54 = XAmzTarget54::ENUM_AMAZONATHENAUPDATEDATACATALOG
```

