
# Internal Tmp Mem Storage Engine

The storage engine for in-memory internal temporary tables.

## Enumeration

`InternalTmpMemStorageEngine`

## Fields

| Name |
|  --- |
| `TEMPTABLE` |
| `MEMORY` |

## Example

```python
from digitaloceanapi.models.internal_tmp_mem_storage_engine import InternalTmpMemStorageEngine

internal_tmp_mem_storage_engine = InternalTmpMemStorageEngine.TEMPTABLE
```

