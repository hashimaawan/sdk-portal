# API

```go
aPIController := client.APIController()
```

## Class Name

`APIController`

## Methods

* [Batch Get Named Query](../../doc/controllers/api.md#batch-get-named-query)
* [Batch Get Prepared Statement](../../doc/controllers/api.md#batch-get-prepared-statement)
* [Batch Get Query Execution](../../doc/controllers/api.md#batch-get-query-execution)
* [Create Data Catalog](../../doc/controllers/api.md#create-data-catalog)
* [Create Named Query](../../doc/controllers/api.md#create-named-query)
* [Create Notebook](../../doc/controllers/api.md#create-notebook)
* [Create Prepared Statement](../../doc/controllers/api.md#create-prepared-statement)
* [Create Presigned Notebook Url](../../doc/controllers/api.md#create-presigned-notebook-url)
* [Create Work Group](../../doc/controllers/api.md#create-work-group)
* [Delete Data Catalog](../../doc/controllers/api.md#delete-data-catalog)
* [Delete Named Query](../../doc/controllers/api.md#delete-named-query)
* [Delete Notebook](../../doc/controllers/api.md#delete-notebook)
* [Delete Prepared Statement](../../doc/controllers/api.md#delete-prepared-statement)
* [Delete Work Group](../../doc/controllers/api.md#delete-work-group)
* [Export Notebook](../../doc/controllers/api.md#export-notebook)
* [Get Calculation Execution](../../doc/controllers/api.md#get-calculation-execution)
* [Get Calculation Execution Code](../../doc/controllers/api.md#get-calculation-execution-code)
* [Get Calculation Execution Status](../../doc/controllers/api.md#get-calculation-execution-status)
* [Get Data Catalog](../../doc/controllers/api.md#get-data-catalog)
* [Get Database](../../doc/controllers/api.md#get-database)
* [Get Named Query](../../doc/controllers/api.md#get-named-query)
* [Get Notebook Metadata](../../doc/controllers/api.md#get-notebook-metadata)
* [Get Prepared Statement](../../doc/controllers/api.md#get-prepared-statement)
* [Get Query Execution](../../doc/controllers/api.md#get-query-execution)
* [Get Query Results](../../doc/controllers/api.md#get-query-results)
* [Get Query Runtime Statistics](../../doc/controllers/api.md#get-query-runtime-statistics)
* [Get Session](../../doc/controllers/api.md#get-session)
* [Get Session Status](../../doc/controllers/api.md#get-session-status)
* [Get Table Metadata](../../doc/controllers/api.md#get-table-metadata)
* [Get Work Group](../../doc/controllers/api.md#get-work-group)
* [Import Notebook](../../doc/controllers/api.md#import-notebook)
* [List Application DPU Sizes](../../doc/controllers/api.md#list-application-dpu-sizes)
* [List Calculation Executions](../../doc/controllers/api.md#list-calculation-executions)
* [List Data Catalogs](../../doc/controllers/api.md#list-data-catalogs)
* [List Databases](../../doc/controllers/api.md#list-databases)
* [List Engine Versions](../../doc/controllers/api.md#list-engine-versions)
* [List Executors](../../doc/controllers/api.md#list-executors)
* [List Named Queries](../../doc/controllers/api.md#list-named-queries)
* [List Notebook Metadata](../../doc/controllers/api.md#list-notebook-metadata)
* [List Notebook Sessions](../../doc/controllers/api.md#list-notebook-sessions)
* [List Prepared Statements](../../doc/controllers/api.md#list-prepared-statements)
* [List Query Executions](../../doc/controllers/api.md#list-query-executions)
* [List Sessions](../../doc/controllers/api.md#list-sessions)
* [List Table Metadata](../../doc/controllers/api.md#list-table-metadata)
* [List Tags for Resource](../../doc/controllers/api.md#list-tags-for-resource)
* [List Work Groups](../../doc/controllers/api.md#list-work-groups)
* [Start Calculation Execution](../../doc/controllers/api.md#start-calculation-execution)
* [Start Query Execution](../../doc/controllers/api.md#start-query-execution)
* [Start Session](../../doc/controllers/api.md#start-session)
* [Stop Calculation Execution](../../doc/controllers/api.md#stop-calculation-execution)
* [Stop Query Execution](../../doc/controllers/api.md#stop-query-execution)
* [Tag Resource](../../doc/controllers/api.md#tag-resource)
* [Terminate Session](../../doc/controllers/api.md#terminate-session)
* [Untag Resource](../../doc/controllers/api.md#untag-resource)
* [Update Data Catalog](../../doc/controllers/api.md#update-data-catalog)
* [Update Named Query](../../doc/controllers/api.md#update-named-query)
* [Update Notebook](../../doc/controllers/api.md#update-notebook)
* [Update Notebook Metadata](../../doc/controllers/api.md#update-notebook-metadata)
* [Update Prepared Statement](../../doc/controllers/api.md#update-prepared-statement)
* [Update Work Group](../../doc/controllers/api.md#update-work-group)


# Batch Get Named Query

Returns the details of a single named query or a list of up to 50 queries, which you provide as an array of query ID strings. Requires you to have access to the workgroup in which the queries were saved. Use <a>ListNamedQueriesInput</a> to get the list of named query IDs in the specified workgroup. If information could not be retrieved for a submitted query ID, information about the query ID submitted is listed under <a>UnprocessedNamedQueryId</a>. Named queries differ from executed queries. Use <a>BatchGetQueryExecutionInput</a> to get details about each unique query execution, and <a>ListQueryExecutionsInput</a> to get a list of query execution IDs.

```go
BatchGetNamedQuery(
    ctx context.Context,
    xAmzTarget models.XAmzTargetEnum,
    body models.BatchGetNamedQueryInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.BatchGetNamedQueryOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTargetEnum`](../../doc/models/x-amz-target-enum.md) | Header, Required | - |
| `body` | [`models.BatchGetNamedQueryInput`](../../doc/models/batch-get-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.BatchGetNamedQueryOutput](../../doc/models/batch-get-named-query-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTargetEnum_ENUMAMAZONATHENABATCHGETNAMEDQUERY

body := models.BatchGetNamedQueryInput{
    NamedQueryIds:        []string{
        "NamedQueryIds9",
    },
}

apiResponse, err := aPIController.BatchGetNamedQuery(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Batch Get Prepared Statement

Returns the details of a single prepared statement or a list of up to 256 prepared statements for the array of prepared statement names that you provide. Requires you to have access to the workgroup to which the prepared statements belong. If a prepared statement cannot be retrieved for the name specified, the statement is listed in <code>UnprocessedPreparedStatementNames</code>.

```go
BatchGetPreparedStatement(
    ctx context.Context,
    xAmzTarget models.XAmzTarget1Enum,
    body models.BatchGetPreparedStatementInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.BatchGetPreparedStatementOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget1Enum`](../../doc/models/x-amz-target-1-enum.md) | Header, Required | - |
| `body` | [`models.BatchGetPreparedStatementInput`](../../doc/models/batch-get-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.BatchGetPreparedStatementOutput](../../doc/models/batch-get-prepared-statement-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget1Enum_ENUMAMAZONATHENABATCHGETPREPAREDSTATEMENT

body := models.BatchGetPreparedStatementInput{
    PreparedStatementNames: []string{
        "PreparedStatementNames0",
        "PreparedStatementNames1",
        "PreparedStatementNames2",
    },
    WorkGroup:              "WorkGroup8",
}

apiResponse, err := aPIController.BatchGetPreparedStatement(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Batch Get Query Execution

Returns the details of a single query execution or a list of up to 50 query executions, which you provide as an array of query execution ID strings. Requires you to have access to the workgroup in which the queries ran. To get a list of query execution IDs, use <a>ListQueryExecutionsInput$WorkGroup</a>. Query executions differ from named (saved) queries. Use <a>BatchGetNamedQueryInput</a> to get details about named queries.

```go
BatchGetQueryExecution(
    ctx context.Context,
    xAmzTarget models.XAmzTarget2Enum,
    body models.BatchGetQueryExecutionInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.BatchGetQueryExecutionOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget2Enum`](../../doc/models/x-amz-target-2-enum.md) | Header, Required | - |
| `body` | [`models.BatchGetQueryExecutionInput`](../../doc/models/batch-get-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.BatchGetQueryExecutionOutput](../../doc/models/batch-get-query-execution-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget2Enum_ENUMAMAZONATHENABATCHGETQUERYEXECUTION

body := models.BatchGetQueryExecutionInput{
    QueryExecutionIds:    []string{
        "QueryExecutionIds3",
    },
}

apiResponse, err := aPIController.BatchGetQueryExecution(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Create Data Catalog

Creates (registers) a data catalog with the specified name and properties. Catalogs created are visible to all users of the same Amazon Web Services account.

```go
CreateDataCatalog(
    ctx context.Context,
    xAmzTarget models.XAmzTarget3Enum,
    body models.CreateDataCatalogInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget3Enum`](../../doc/models/x-amz-target-3-enum.md) | Header, Required | - |
| `body` | [`models.CreateDataCatalogInput`](../../doc/models/create-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget3Enum_ENUMAMAZONATHENACREATEDATACATALOG

body := models.CreateDataCatalogInput{
    Name:                 "Name6",
    Type:                 models.DataCatalogType1Enum_HIVE,
}

apiResponse, err := aPIController.CreateDataCatalog(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Create Named Query

<p>Creates a named query in the specified workgroup. Requires that you have access to the workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```go
CreateNamedQuery(
    ctx context.Context,
    xAmzTarget models.XAmzTarget4Enum,
    body models.CreateNamedQueryInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.CreateNamedQueryOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget4Enum`](../../doc/models/x-amz-target-4-enum.md) | Header, Required | - |
| `body` | [`models.CreateNamedQueryInput`](../../doc/models/create-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CreateNamedQueryOutput](../../doc/models/create-named-query-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget4Enum_ENUMAMAZONATHENACREATENAMEDQUERY

body := models.CreateNamedQueryInput{
    Name:                 "Name6",
    Database:             "Database4",
    QueryString:          "QueryString8",
}

apiResponse, err := aPIController.CreateNamedQuery(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Create Notebook

Creates an empty <code>ipynb</code> file in the specified Apache Spark enabled workgroup. Throws an error if a file in the workgroup with the same name already exists.

```go
CreateNotebook(
    ctx context.Context,
    xAmzTarget models.XAmzTarget5Enum,
    body models.CreateNotebookInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.CreateNotebookOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget5Enum`](../../doc/models/x-amz-target-5-enum.md) | Header, Required | - |
| `body` | [`models.CreateNotebookInput`](../../doc/models/create-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CreateNotebookOutput](../../doc/models/create-notebook-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget5Enum_ENUMAMAZONATHENACREATENOTEBOOK

body := models.CreateNotebookInput{
    WorkGroup:            "WorkGroup8",
    Name:                 "Name6",
}

apiResponse, err := aPIController.CreateNotebook(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# Create Prepared Statement

Creates a prepared statement for use with SQL queries in Athena.

```go
CreatePreparedStatement(
    ctx context.Context,
    xAmzTarget models.XAmzTarget6Enum,
    body models.CreatePreparedStatementInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget6Enum`](../../doc/models/x-amz-target-6-enum.md) | Header, Required | - |
| `body` | [`models.CreatePreparedStatementInput`](../../doc/models/create-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget6Enum_ENUMAMAZONATHENACREATEPREPAREDSTATEMENT

body := models.CreatePreparedStatementInput{
    StatementName:        "StatementName4",
    WorkGroup:            "WorkGroup8",
    QueryStatement:       "QueryStatement8",
}

apiResponse, err := aPIController.CreatePreparedStatement(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Create Presigned Notebook Url

Gets an authentication token and the URL at which the notebook can be accessed. During programmatic access, <code>CreatePresignedNotebookUrl</code> must be called every 10 minutes to refresh the authentication token. For information about granting programmatic access, see <a href="https://docs.aws.amazon.com/athena/latest/ug/setting-up.html#setting-up-grant-programmatic-access">Grant programmatic access</a>.

```go
CreatePresignedNotebookUrl(
    ctx context.Context,
    xAmzTarget models.XAmzTarget7Enum,
    body models.CreatePresignedNotebookUrlRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.CreatePresignedNotebookUrlResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget7Enum`](../../doc/models/x-amz-target-7-enum.md) | Header, Required | - |
| `body` | [`models.CreatePresignedNotebookUrlRequest`](../../doc/models/create-presigned-notebook-url-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CreatePresignedNotebookUrlResponse](../../doc/models/create-presigned-notebook-url-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget7Enum_ENUMAMAZONATHENACREATEPRESIGNEDNOTEBOOKURL

body := models.CreatePresignedNotebookUrlRequest{
    SessionId:            "SessionId2",
}

apiResponse, err := aPIController.CreatePresignedNotebookUrl(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Create Work Group

Creates a workgroup with the specified name. A workgroup can be an Apache Spark enabled workgroup or an Athena SQL workgroup.

```go
CreateWorkGroup(
    ctx context.Context,
    xAmzTarget models.XAmzTarget8Enum,
    body models.CreateWorkGroupInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget8Enum`](../../doc/models/x-amz-target-8-enum.md) | Header, Required | - |
| `body` | [`models.CreateWorkGroupInput`](../../doc/models/create-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget8Enum_ENUMAMAZONATHENACREATEWORKGROUP

body := models.CreateWorkGroupInput{
    Name:                 "Name6",
}

apiResponse, err := aPIController.CreateWorkGroup(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Delete Data Catalog

Deletes a data catalog.

```go
DeleteDataCatalog(
    ctx context.Context,
    xAmzTarget models.XAmzTarget9Enum,
    body models.DeleteDataCatalogInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget9Enum`](../../doc/models/x-amz-target-9-enum.md) | Header, Required | - |
| `body` | [`models.DeleteDataCatalogInput`](../../doc/models/delete-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget9Enum_ENUMAMAZONATHENADELETEDATACATALOG

body := models.DeleteDataCatalogInput{
    Name:                 "Name6",
}

apiResponse, err := aPIController.DeleteDataCatalog(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Delete Named Query

<p>Deletes the named query if you have access to the workgroup in which the query was saved.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```go
DeleteNamedQuery(
    ctx context.Context,
    xAmzTarget models.XAmzTarget10Enum,
    body models.DeleteNamedQueryInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget10Enum`](../../doc/models/x-amz-target-10-enum.md) | Header, Required | - |
| `body` | [`models.DeleteNamedQueryInput`](../../doc/models/delete-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget10Enum_ENUMAMAZONATHENADELETENAMEDQUERY

body := models.DeleteNamedQueryInput{
    NamedQueryId:         "NamedQueryId6",
}

apiResponse, err := aPIController.DeleteNamedQuery(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Delete Notebook

Deletes the specified notebook.

```go
DeleteNotebook(
    ctx context.Context,
    xAmzTarget models.XAmzTarget11Enum,
    body models.DeleteNotebookInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget11Enum`](../../doc/models/x-amz-target-11-enum.md) | Header, Required | - |
| `body` | [`models.DeleteNotebookInput`](../../doc/models/delete-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget11Enum_ENUMAMAZONATHENADELETENOTEBOOK

body := models.DeleteNotebookInput{
    NotebookId:           "NotebookId6",
}

apiResponse, err := aPIController.DeleteNotebook(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# Delete Prepared Statement

Deletes the prepared statement with the specified name from the specified workgroup.

```go
DeletePreparedStatement(
    ctx context.Context,
    xAmzTarget models.XAmzTarget12Enum,
    body models.DeletePreparedStatementInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget12Enum`](../../doc/models/x-amz-target-12-enum.md) | Header, Required | - |
| `body` | [`models.DeletePreparedStatementInput`](../../doc/models/delete-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget12Enum_ENUMAMAZONATHENADELETEPREPAREDSTATEMENT

body := models.DeletePreparedStatementInput{
    StatementName:        "StatementName4",
    WorkGroup:            "WorkGroup8",
}

apiResponse, err := aPIController.DeletePreparedStatement(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Delete Work Group

Deletes the workgroup with the specified name. The primary workgroup cannot be deleted.

```go
DeleteWorkGroup(
    ctx context.Context,
    xAmzTarget models.XAmzTarget13Enum,
    body models.DeleteWorkGroupInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget13Enum`](../../doc/models/x-amz-target-13-enum.md) | Header, Required | - |
| `body` | [`models.DeleteWorkGroupInput`](../../doc/models/delete-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget13Enum_ENUMAMAZONATHENADELETEWORKGROUP

body := models.DeleteWorkGroupInput{
    WorkGroup:             "WorkGroup8",
}

apiResponse, err := aPIController.DeleteWorkGroup(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Export Notebook

Exports the specified notebook and its metadata.

```go
ExportNotebook(
    ctx context.Context,
    xAmzTarget models.XAmzTarget14Enum,
    body models.ExportNotebookInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.ExportNotebookOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget14Enum`](../../doc/models/x-amz-target-14-enum.md) | Header, Required | - |
| `body` | [`models.ExportNotebookInput`](../../doc/models/export-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ExportNotebookOutput](../../doc/models/export-notebook-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget14Enum_ENUMAMAZONATHENAEXPORTNOTEBOOK

body := models.ExportNotebookInput{
    NotebookId:           "NotebookId6",
}

apiResponse, err := aPIController.ExportNotebook(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# Get Calculation Execution

Describes a previously submitted calculation execution.

```go
GetCalculationExecution(
    ctx context.Context,
    xAmzTarget models.XAmzTarget15Enum,
    body models.GetCalculationExecutionRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetCalculationExecutionResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget15Enum`](../../doc/models/x-amz-target-15-enum.md) | Header, Required | - |
| `body` | [`models.GetCalculationExecutionRequest`](../../doc/models/get-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetCalculationExecutionResponse](../../doc/models/get-calculation-execution-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget15Enum_ENUMAMAZONATHENAGETCALCULATIONEXECUTION

body := models.GetCalculationExecutionRequest{
    CalculationExecutionId: "CalculationExecutionId8",
}

apiResponse, err := aPIController.GetCalculationExecution(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Get Calculation Execution Code

Retrieves the unencrypted code that was executed for the calculation.

```go
GetCalculationExecutionCode(
    ctx context.Context,
    xAmzTarget models.XAmzTarget16Enum,
    body models.GetCalculationExecutionCodeRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetCalculationExecutionCodeResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget16Enum`](../../doc/models/x-amz-target-16-enum.md) | Header, Required | - |
| `body` | [`models.GetCalculationExecutionCodeRequest`](../../doc/models/get-calculation-execution-code-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetCalculationExecutionCodeResponse](../../doc/models/get-calculation-execution-code-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget16Enum_ENUMAMAZONATHENAGETCALCULATIONEXECUTIONCODE

body := models.GetCalculationExecutionCodeRequest{
    CalculationExecutionId: "CalculationExecutionId8",
}

apiResponse, err := aPIController.GetCalculationExecutionCode(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Get Calculation Execution Status

Gets the status of a current calculation.

```go
GetCalculationExecutionStatus(
    ctx context.Context,
    xAmzTarget models.XAmzTarget17Enum,
    body models.GetCalculationExecutionStatusRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetCalculationExecutionStatusResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget17Enum`](../../doc/models/x-amz-target-17-enum.md) | Header, Required | - |
| `body` | [`models.GetCalculationExecutionStatusRequest`](../../doc/models/get-calculation-execution-status-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetCalculationExecutionStatusResponse](../../doc/models/get-calculation-execution-status-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget17Enum_ENUMAMAZONATHENAGETCALCULATIONEXECUTIONSTATUS

body := models.GetCalculationExecutionStatusRequest{
    CalculationExecutionId: "CalculationExecutionId8",
}

apiResponse, err := aPIController.GetCalculationExecutionStatus(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Get Data Catalog

Returns the specified data catalog.

```go
GetDataCatalog(
    ctx context.Context,
    xAmzTarget models.XAmzTarget18Enum,
    body models.GetDataCatalogInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetDataCatalogOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget18Enum`](../../doc/models/x-amz-target-18-enum.md) | Header, Required | - |
| `body` | [`models.GetDataCatalogInput`](../../doc/models/get-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetDataCatalogOutput](../../doc/models/get-data-catalog-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget18Enum_ENUMAMAZONATHENAGETDATACATALOG

body := models.GetDataCatalogInput{
    Name:                 "Name6",
}

apiResponse, err := aPIController.GetDataCatalog(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Get Database

Returns a database object for the specified database and data catalog.

```go
GetDatabase(
    ctx context.Context,
    xAmzTarget models.XAmzTarget19Enum,
    body models.GetDatabaseInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetDatabaseOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget19Enum`](../../doc/models/x-amz-target-19-enum.md) | Header, Required | - |
| `body` | [`models.GetDatabaseInput`](../../doc/models/get-database-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetDatabaseOutput](../../doc/models/get-database-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget19Enum_ENUMAMAZONATHENAGETDATABASE

body := models.GetDatabaseInput{
    CatalogName:          "CatalogName0",
    DatabaseName:         "DatabaseName0",
}

apiResponse, err := aPIController.GetDatabase(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | MetadataException | `ApiError` |


# Get Named Query

Returns information about a single query. Requires that you have access to the workgroup in which the query was saved.

```go
GetNamedQuery(
    ctx context.Context,
    xAmzTarget models.XAmzTarget20Enum,
    body models.GetNamedQueryInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetNamedQueryOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget20Enum`](../../doc/models/x-amz-target-20-enum.md) | Header, Required | - |
| `body` | [`models.GetNamedQueryInput`](../../doc/models/get-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetNamedQueryOutput](../../doc/models/get-named-query-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget20Enum_ENUMAMAZONATHENAGETNAMEDQUERY

body := models.GetNamedQueryInput{
    NamedQueryId:         "NamedQueryId6",
}

apiResponse, err := aPIController.GetNamedQuery(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Get Notebook Metadata

Retrieves notebook metadata for the specified notebook ID.

```go
GetNotebookMetadata(
    ctx context.Context,
    xAmzTarget models.XAmzTarget21Enum,
    body models.GetNotebookMetadataInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetNotebookMetadataOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget21Enum`](../../doc/models/x-amz-target-21-enum.md) | Header, Required | - |
| `body` | [`models.GetNotebookMetadataInput`](../../doc/models/get-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetNotebookMetadataOutput](../../doc/models/get-notebook-metadata-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget21Enum_ENUMAMAZONATHENAGETNOTEBOOKMETADATA

body := models.GetNotebookMetadataInput{
    NotebookId:           "NotebookId6",
}

apiResponse, err := aPIController.GetNotebookMetadata(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# Get Prepared Statement

Retrieves the prepared statement with the specified name from the specified workgroup.

```go
GetPreparedStatement(
    ctx context.Context,
    xAmzTarget models.XAmzTarget22Enum,
    body models.GetPreparedStatementInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetPreparedStatementOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget22Enum`](../../doc/models/x-amz-target-22-enum.md) | Header, Required | - |
| `body` | [`models.GetPreparedStatementInput`](../../doc/models/get-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetPreparedStatementOutput](../../doc/models/get-prepared-statement-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget22Enum_ENUMAMAZONATHENAGETPREPAREDSTATEMENT

body := models.GetPreparedStatementInput{
    StatementName:        "StatementName4",
    WorkGroup:            "WorkGroup8",
}

apiResponse, err := aPIController.GetPreparedStatement(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Get Query Execution

Returns information about a single execution of a query if you have access to the workgroup in which the query ran. Each time a query executes, information about the query execution is saved with a unique ID.

```go
GetQueryExecution(
    ctx context.Context,
    xAmzTarget models.XAmzTarget23Enum,
    body models.GetQueryExecutionInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetQueryExecutionOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget23Enum`](../../doc/models/x-amz-target-23-enum.md) | Header, Required | - |
| `body` | [`models.GetQueryExecutionInput`](../../doc/models/get-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetQueryExecutionOutput](../../doc/models/get-query-execution-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget23Enum_ENUMAMAZONATHENAGETQUERYEXECUTION

body := models.GetQueryExecutionInput{
    QueryExecutionId:     "QueryExecutionId0",
}

apiResponse, err := aPIController.GetQueryExecution(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Get Query Results

<p>Streams the results of a single query execution specified by <code>QueryExecutionId</code> from the Athena query results location in Amazon S3. For more information, see <a href="https://docs.aws.amazon.com/athena/latest/ug/querying.html">Working with query results, recent queries, and output files</a> in the <i>Amazon Athena User Guide</i>. This request does not execute the query but returns results. Use <a>StartQueryExecution</a> to run a query.</p> <p>To stream query results successfully, the IAM principal with permission to call <code>GetQueryResults</code> also must have permissions to the Amazon S3 <code>GetObject</code> action for the Athena query results location.</p> <important> <p>IAM principals with permission to the Amazon S3 <code>GetObject</code> action for the query results location are able to retrieve query results from Amazon S3 even if permission to the <code>GetQueryResults</code> action is denied. To restrict user or role access, ensure that Amazon S3 permissions to the Athena query location are denied.</p> </important>


```go
GetQueryResults(
    ctx context.Context,
    xAmzTarget models.XAmzTarget24Enum,
    body models.GetQueryResultsInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.GetQueryResultsOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget24Enum`](../../doc/models/x-amz-target-24-enum.md) | Header, Required | - |
| `body` | [`models.GetQueryResultsInput`](../../doc/models/get-query-results-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetQueryResultsOutput](../../doc/models/get-query-results-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget24Enum_ENUMAMAZONATHENAGETQUERYRESULTS

body := models.GetQueryResultsInput{
    QueryExecutionId:     "QueryExecutionId0",
}

apiResponse, err := aPIController.GetQueryResults(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# Get Query Runtime Statistics

Returns query execution runtime statistics related to a single execution of a query if you have access to the workgroup in which the query ran. Query execution runtime statistics are returned only when <a>QueryExecutionStatus$State</a> is in a SUCCEEDED or FAILED state. Stage-level input and output row count and data size statistics are not shown when a query has row-level filters defined in Lake Formation.

```go
GetQueryRuntimeStatistics(
    ctx context.Context,
    xAmzTarget models.XAmzTarget25Enum,
    body models.GetQueryRuntimeStatisticsInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetQueryRuntimeStatisticsOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget25Enum`](../../doc/models/x-amz-target-25-enum.md) | Header, Required | - |
| `body` | [`models.GetQueryRuntimeStatisticsInput`](../../doc/models/get-query-runtime-statistics-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetQueryRuntimeStatisticsOutput](../../doc/models/get-query-runtime-statistics-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget25Enum_ENUMAMAZONATHENAGETQUERYRUNTIMESTATISTICS

body := models.GetQueryRuntimeStatisticsInput{
    QueryExecutionId:     "QueryExecutionId0",
}

apiResponse, err := aPIController.GetQueryRuntimeStatistics(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Get Session

Gets the full details of a previously created session, including the session status and configuration.

```go
GetSession(
    ctx context.Context,
    xAmzTarget models.XAmzTarget26Enum,
    body models.GetSessionRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetSessionResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget26Enum`](../../doc/models/x-amz-target-26-enum.md) | Header, Required | - |
| `body` | [`models.GetSessionRequest`](../../doc/models/get-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetSessionResponse](../../doc/models/get-session-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget26Enum_ENUMAMAZONATHENAGETSESSION

body := models.GetSessionRequest{
    SessionId:            "SessionId2",
}

apiResponse, err := aPIController.GetSession(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Get Session Status

Gets the current status of a session.

```go
GetSessionStatus(
    ctx context.Context,
    xAmzTarget models.XAmzTarget27Enum,
    body models.GetSessionStatusRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetSessionStatusResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget27Enum`](../../doc/models/x-amz-target-27-enum.md) | Header, Required | - |
| `body` | [`models.GetSessionStatusRequest`](../../doc/models/get-session-status-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetSessionStatusResponse](../../doc/models/get-session-status-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget27Enum_ENUMAMAZONATHENAGETSESSIONSTATUS

body := models.GetSessionStatusRequest{
    SessionId:            "SessionId2",
}

apiResponse, err := aPIController.GetSessionStatus(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Get Table Metadata

Returns table metadata for the specified catalog, database, and table.

```go
GetTableMetadata(
    ctx context.Context,
    xAmzTarget models.XAmzTarget28Enum,
    body models.GetTableMetadataInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetTableMetadataOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget28Enum`](../../doc/models/x-amz-target-28-enum.md) | Header, Required | - |
| `body` | [`models.GetTableMetadataInput`](../../doc/models/get-table-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetTableMetadataOutput](../../doc/models/get-table-metadata-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget28Enum_ENUMAMAZONATHENAGETTABLEMETADATA

body := models.GetTableMetadataInput{
    CatalogName:          "CatalogName0",
    DatabaseName:         "DatabaseName0",
    TableName:            "TableName2",
}

apiResponse, err := aPIController.GetTableMetadata(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | MetadataException | `ApiError` |


# Get Work Group

Returns information about the workgroup with the specified name.

```go
GetWorkGroup(
    ctx context.Context,
    xAmzTarget models.XAmzTarget29Enum,
    body models.GetWorkGroupInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.GetWorkGroupOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget29Enum`](../../doc/models/x-amz-target-29-enum.md) | Header, Required | - |
| `body` | [`models.GetWorkGroupInput`](../../doc/models/get-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GetWorkGroupOutput](../../doc/models/get-work-group-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget29Enum_ENUMAMAZONATHENAGETWORKGROUP

body := models.GetWorkGroupInput{
    WorkGroup:            "WorkGroup8",
}

apiResponse, err := aPIController.GetWorkGroup(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Import Notebook

Imports a single <code>ipynb</code> file to a Spark enabled workgroup. The maximum file size that can be imported is 10 megabytes. If an <code>ipynb</code> file with the same name already exists in the workgroup, throws an error.

```go
ImportNotebook(
    ctx context.Context,
    xAmzTarget models.XAmzTarget30Enum,
    body models.ImportNotebookInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.ImportNotebookOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget30Enum`](../../doc/models/x-amz-target-30-enum.md) | Header, Required | - |
| `body` | [`models.ImportNotebookInput`](../../doc/models/import-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ImportNotebookOutput](../../doc/models/import-notebook-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget30Enum_ENUMAMAZONATHENAIMPORTNOTEBOOK

body := models.ImportNotebookInput{
    WorkGroup:            "WorkGroup8",
    Name:                 "Name6",
    Payload:              "Payload2",
    Type:                 models.NotebookType2Enum_IPYNB,
}

apiResponse, err := aPIController.ImportNotebook(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# List Application DPU Sizes

Returns the supported DPU sizes for the supported application runtimes (for example, <code>Athena notebook version 1</code>).

```go
ListApplicationDPUSizes(
    ctx context.Context,
    xAmzTarget models.XAmzTarget31Enum,
    body models.ListApplicationDPUSizesInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListApplicationDPUSizesOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget31Enum`](../../doc/models/x-amz-target-31-enum.md) | Header, Required | - |
| `body` | [`models.ListApplicationDPUSizesInput`](../../doc/models/list-application-dpu-sizes-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListApplicationDPUSizesOutput](../../doc/models/list-application-dpu-sizes-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget31Enum_ENUMAMAZONATHENALISTAPPLICATIONDPUSIZES

body := models.ListApplicationDPUSizesInput{
}

apiResponse, err := aPIController.ListApplicationDPUSizes(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# List Calculation Executions

Lists the calculations that have been submitted to a session in descending order. Newer calculations are listed first; older calculations are listed later.

```go
ListCalculationExecutions(
    ctx context.Context,
    xAmzTarget models.XAmzTarget32Enum,
    body models.ListCalculationExecutionsRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListCalculationExecutionsResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget32Enum`](../../doc/models/x-amz-target-32-enum.md) | Header, Required | - |
| `body` | [`models.ListCalculationExecutionsRequest`](../../doc/models/list-calculation-executions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListCalculationExecutionsResponse](../../doc/models/list-calculation-executions-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget32Enum_ENUMAMAZONATHENALISTCALCULATIONEXECUTIONS

body := models.ListCalculationExecutionsRequest{
    SessionId:            "SessionId2",
}

apiResponse, err := aPIController.ListCalculationExecutions(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# List Data Catalogs

<p>Lists the data catalogs in the current Amazon Web Services account.</p> <note> <p>In the Athena console, data catalogs are listed as "data sources" on the <b>Data sources</b> page under the <b>Data source name</b> column.</p> </note>


```go
ListDataCatalogs(
    ctx context.Context,
    xAmzTarget models.XAmzTarget33Enum,
    body models.ListDataCatalogsInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListDataCatalogsOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget33Enum`](../../doc/models/x-amz-target-33-enum.md) | Header, Required | - |
| `body` | [`models.ListDataCatalogsInput`](../../doc/models/list-data-catalogs-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListDataCatalogsOutput](../../doc/models/list-data-catalogs-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget33Enum_ENUMAMAZONATHENALISTDATACATALOGS

body := models.ListDataCatalogsInput{
}

apiResponse, err := aPIController.ListDataCatalogs(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# List Databases

Lists the databases in the specified data catalog.

```go
ListDatabases(
    ctx context.Context,
    xAmzTarget models.XAmzTarget34Enum,
    body models.ListDatabasesInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListDatabasesOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget34Enum`](../../doc/models/x-amz-target-34-enum.md) | Header, Required | - |
| `body` | [`models.ListDatabasesInput`](../../doc/models/list-databases-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListDatabasesOutput](../../doc/models/list-databases-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget34Enum_ENUMAMAZONATHENALISTDATABASES

body := models.ListDatabasesInput{
    CatalogName:          "CatalogName0",
}

apiResponse, err := aPIController.ListDatabases(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | MetadataException | `ApiError` |


# List Engine Versions

Returns a list of engine versions that are available to choose from, including the Auto option.

```go
ListEngineVersions(
    ctx context.Context,
    xAmzTarget models.XAmzTarget35Enum,
    body models.ListEngineVersionsInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListEngineVersionsOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget35Enum`](../../doc/models/x-amz-target-35-enum.md) | Header, Required | - |
| `body` | [`models.ListEngineVersionsInput`](../../doc/models/list-engine-versions-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListEngineVersionsOutput](../../doc/models/list-engine-versions-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget35Enum_ENUMAMAZONATHENALISTENGINEVERSIONS

body := models.ListEngineVersionsInput{
}

apiResponse, err := aPIController.ListEngineVersions(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# List Executors

Lists, in descending order, the executors that joined a session. Newer executors are listed first; older executors are listed later. The result can be optionally filtered by state.

```go
ListExecutors(
    ctx context.Context,
    xAmzTarget models.XAmzTarget36Enum,
    body models.ListExecutorsRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListExecutorsResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget36Enum`](../../doc/models/x-amz-target-36-enum.md) | Header, Required | - |
| `body` | [`models.ListExecutorsRequest`](../../doc/models/list-executors-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListExecutorsResponse](../../doc/models/list-executors-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget36Enum_ENUMAMAZONATHENALISTEXECUTORS

body := models.ListExecutorsRequest{
    SessionId:            "SessionId2",
}

apiResponse, err := aPIController.ListExecutors(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# List Named Queries

<p>Provides a list of available query IDs only for queries saved in the specified workgroup. Requires that you have access to the specified workgroup. If a workgroup is not specified, lists the saved queries for the primary workgroup.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```go
ListNamedQueries(
    ctx context.Context,
    xAmzTarget models.XAmzTarget37Enum,
    body models.ListNamedQueriesInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListNamedQueriesOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget37Enum`](../../doc/models/x-amz-target-37-enum.md) | Header, Required | - |
| `body` | [`models.ListNamedQueriesInput`](../../doc/models/list-named-queries-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListNamedQueriesOutput](../../doc/models/list-named-queries-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget37Enum_ENUMAMAZONATHENALISTNAMEDQUERIES

body := models.ListNamedQueriesInput{
}

apiResponse, err := aPIController.ListNamedQueries(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# List Notebook Metadata

Displays the notebook files for the specified workgroup in paginated format.

```go
ListNotebookMetadata(
    ctx context.Context,
    xAmzTarget models.XAmzTarget38Enum,
    body models.ListNotebookMetadataInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.ListNotebookMetadataOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget38Enum`](../../doc/models/x-amz-target-38-enum.md) | Header, Required | - |
| `body` | [`models.ListNotebookMetadataInput`](../../doc/models/list-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListNotebookMetadataOutput](../../doc/models/list-notebook-metadata-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget38Enum_ENUMAMAZONATHENALISTNOTEBOOKMETADATA

body := models.ListNotebookMetadataInput{
    WorkGroup:            "WorkGroup8",
}

apiResponse, err := aPIController.ListNotebookMetadata(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# List Notebook Sessions

Lists, in descending order, the sessions that have been created in a notebook that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code> or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```go
ListNotebookSessions(
    ctx context.Context,
    xAmzTarget models.XAmzTarget39Enum,
    body models.ListNotebookSessionsRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.ListNotebookSessionsResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget39Enum`](../../doc/models/x-amz-target-39-enum.md) | Header, Required | - |
| `body` | [`models.ListNotebookSessionsRequest`](../../doc/models/list-notebook-sessions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListNotebookSessionsResponse](../../doc/models/list-notebook-sessions-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget39Enum_ENUMAMAZONATHENALISTNOTEBOOKSESSIONS

body := models.ListNotebookSessionsRequest{
    NotebookId:           "NotebookId6",
}

apiResponse, err := aPIController.ListNotebookSessions(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# List Prepared Statements

Lists the prepared statements in the specified workgroup.

```go
ListPreparedStatements(
    ctx context.Context,
    xAmzTarget models.XAmzTarget40Enum,
    body models.ListPreparedStatementsInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListPreparedStatementsOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget40Enum`](../../doc/models/x-amz-target-40-enum.md) | Header, Required | - |
| `body` | [`models.ListPreparedStatementsInput`](../../doc/models/list-prepared-statements-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListPreparedStatementsOutput](../../doc/models/list-prepared-statements-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget40Enum_ENUMAMAZONATHENALISTPREPAREDSTATEMENTS

body := models.ListPreparedStatementsInput{
    WorkGroup:            "WorkGroup8",
}

apiResponse, err := aPIController.ListPreparedStatements(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# List Query Executions

<p>Provides a list of available query execution IDs for the queries in the specified workgroup. If a workgroup is not specified, returns a list of query execution IDs for the primary workgroup. Requires you to have access to the workgroup in which the queries ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```go
ListQueryExecutions(
    ctx context.Context,
    xAmzTarget models.XAmzTarget41Enum,
    body models.ListQueryExecutionsInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListQueryExecutionsOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget41Enum`](../../doc/models/x-amz-target-41-enum.md) | Header, Required | - |
| `body` | [`models.ListQueryExecutionsInput`](../../doc/models/list-query-executions-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListQueryExecutionsOutput](../../doc/models/list-query-executions-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget41Enum_ENUMAMAZONATHENALISTQUERYEXECUTIONS

body := models.ListQueryExecutionsInput{
}

apiResponse, err := aPIController.ListQueryExecutions(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# List Sessions

Lists the sessions in a workgroup that are in an active state like <code>CREATING</code>, <code>CREATED</code>, <code>IDLE</code>, or <code>BUSY</code>. Newer sessions are listed first; older sessions are listed later.

```go
ListSessions(
    ctx context.Context,
    xAmzTarget models.XAmzTarget42Enum,
    body models.ListSessionsRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListSessionsResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget42Enum`](../../doc/models/x-amz-target-42-enum.md) | Header, Required | - |
| `body` | [`models.ListSessionsRequest`](../../doc/models/list-sessions-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListSessionsResponse](../../doc/models/list-sessions-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget42Enum_ENUMAMAZONATHENALISTSESSIONS

body := models.ListSessionsRequest{
    WorkGroup:            "WorkGroup8",
}

apiResponse, err := aPIController.ListSessions(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# List Table Metadata

Lists the metadata for the tables in the specified data catalog database.

```go
ListTableMetadata(
    ctx context.Context,
    xAmzTarget models.XAmzTarget43Enum,
    body models.ListTableMetadataInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListTableMetadataOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget43Enum`](../../doc/models/x-amz-target-43-enum.md) | Header, Required | - |
| `body` | [`models.ListTableMetadataInput`](../../doc/models/list-table-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListTableMetadataOutput](../../doc/models/list-table-metadata-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget43Enum_ENUMAMAZONATHENALISTTABLEMETADATA

body := models.ListTableMetadataInput{
    CatalogName:          "CatalogName0",
    DatabaseName:         "DatabaseName0",
}

apiResponse, err := aPIController.ListTableMetadata(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | MetadataException | `ApiError` |


# List Tags for Resource

Lists the tags associated with an Athena workgroup or data catalog resource.

```go
ListTagsForResource(
    ctx context.Context,
    xAmzTarget models.XAmzTarget44Enum,
    body models.ListTagsForResourceInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListTagsForResourceOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget44Enum`](../../doc/models/x-amz-target-44-enum.md) | Header, Required | - |
| `body` | [`models.ListTagsForResourceInput`](../../doc/models/list-tags-for-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListTagsForResourceOutput](../../doc/models/list-tags-for-resource-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget44Enum_ENUMAMAZONATHENALISTTAGSFORRESOURCE

body := models.ListTagsForResourceInput{
    ResourceARN:          "ResourceARN4",
}

apiResponse, err := aPIController.ListTagsForResource(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# List Work Groups

Lists available workgroups for the account.

```go
ListWorkGroups(
    ctx context.Context,
    xAmzTarget models.XAmzTarget45Enum,
    body models.ListWorkGroupsInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string,
    maxResults *string,
    nextToken *string) (
    models.ApiResponse[models.ListWorkGroupsOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget45Enum`](../../doc/models/x-amz-target-45-enum.md) | Header, Required | - |
| `body` | [`models.ListWorkGroupsInput`](../../doc/models/list-work-groups-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |
| `maxResults` | `*string` | Query, Optional | Pagination limit |
| `nextToken` | `*string` | Query, Optional | Pagination token |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ListWorkGroupsOutput](../../doc/models/list-work-groups-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget45Enum_ENUMAMAZONATHENALISTWORKGROUPS

body := models.ListWorkGroupsInput{
}

apiResponse, err := aPIController.ListWorkGroups(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Start Calculation Execution

Submits calculations for execution within a session. You can supply the code to run as an inline code block within the request.

```go
StartCalculationExecution(
    ctx context.Context,
    xAmzTarget models.XAmzTarget46Enum,
    body models.StartCalculationExecutionRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.StartCalculationExecutionResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget46Enum`](../../doc/models/x-amz-target-46-enum.md) | Header, Required | - |
| `body` | [`models.StartCalculationExecutionRequest`](../../doc/models/start-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.StartCalculationExecutionResponse](../../doc/models/start-calculation-execution-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget46Enum_ENUMAMAZONATHENASTARTCALCULATIONEXECUTION

body := models.StartCalculationExecutionRequest{
    SessionId:                "SessionId2",
}

apiResponse, err := aPIController.StartCalculationExecution(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Start Query Execution

Runs the SQL query statements contained in the <code>Query</code>. Requires you to have access to the workgroup in which the query ran. Running queries against an external catalog requires <a>GetDataCatalog</a> permission to the catalog. For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.

```go
StartQueryExecution(
    ctx context.Context,
    xAmzTarget models.XAmzTarget47Enum,
    body models.StartQueryExecutionInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.StartQueryExecutionOutput],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget47Enum`](../../doc/models/x-amz-target-47-enum.md) | Header, Required | - |
| `body` | [`models.StartQueryExecutionInput`](../../doc/models/start-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.StartQueryExecutionOutput](../../doc/models/start-query-execution-output.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget47Enum_ENUMAMAZONATHENASTARTQUERYEXECUTION

body := models.StartQueryExecutionInput{
    QueryString:              "QueryString8",
}

apiResponse, err := aPIController.StartQueryExecution(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# Start Session

Creates a session for running calculations within a workgroup. The session is ready when it reaches an <code>IDLE</code> state.

```go
StartSession(
    ctx context.Context,
    xAmzTarget models.XAmzTarget48Enum,
    body models.StartSessionRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.StartSessionResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget48Enum`](../../doc/models/x-amz-target-48-enum.md) | Header, Required | - |
| `body` | [`models.StartSessionRequest`](../../doc/models/start-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.StartSessionResponse](../../doc/models/start-session-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget48Enum_ENUMAMAZONATHENASTARTSESSION

body := models.StartSessionRequest{
    WorkGroup:                   "WorkGroup8",
    EngineConfiguration:         models.EngineConfiguration1{
        MaxConcurrentDpus:      94,
    },
}

apiResponse, err := aPIController.StartSession(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |
| 483 | SessionAlreadyExistsException | `ApiError` |
| 484 | TooManyRequestsException | `ApiError` |


# Stop Calculation Execution

<p>Requests the cancellation of a calculation. A <code>StopCalculationExecution</code> call on a calculation that is already in a terminal state (for example, <code>STOPPED</code>, <code>FAILED</code>, or <code>COMPLETED</code>) succeeds but has no effect.</p> <note> <p>Cancelling a calculation is done on a best effort basis. If a calculation cannot be cancelled, you can be charged for its completion. If you are concerned about being charged for a calculation that cannot be cancelled, consider terminating the session in which the calculation is running.</p> </note>


```go
StopCalculationExecution(
    ctx context.Context,
    xAmzTarget models.XAmzTarget49Enum,
    body models.StopCalculationExecutionRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.StopCalculationExecutionResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget49Enum`](../../doc/models/x-amz-target-49-enum.md) | Header, Required | - |
| `body` | [`models.StopCalculationExecutionRequest`](../../doc/models/stop-calculation-execution-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.StopCalculationExecutionResponse](../../doc/models/stop-calculation-execution-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget49Enum_ENUMAMAZONATHENASTOPCALCULATIONEXECUTION

body := models.StopCalculationExecutionRequest{
    CalculationExecutionId: "CalculationExecutionId8",
}

apiResponse, err := aPIController.StopCalculationExecution(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Stop Query Execution

<p>Stops a query execution. Requires you to have access to the workgroup in which the query ran.</p> <p>For code samples using the Amazon Web Services SDK for Java, see <a href="http://docs.aws.amazon.com/athena/latest/ug/code-samples.html">Examples and Code Samples</a> in the <i>Amazon Athena User Guide</i>.</p>


```go
StopQueryExecution(
    ctx context.Context,
    xAmzTarget models.XAmzTarget50Enum,
    body models.StopQueryExecutionInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget50Enum`](../../doc/models/x-amz-target-50-enum.md) | Header, Required | - |
| `body` | [`models.StopQueryExecutionInput`](../../doc/models/stop-query-execution-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget50Enum_ENUMAMAZONATHENASTOPQUERYEXECUTION

body := models.StopQueryExecutionInput{
    QueryExecutionId:     "QueryExecutionId0",
}

apiResponse, err := aPIController.StopQueryExecution(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Tag Resource

Adds one or more tags to an Athena resource. A tag is a label that you assign to a resource. In Athena, a resource can be a workgroup or data catalog. Each tag consists of a key and an optional value, both of which you define. For example, you can use tags to categorize Athena workgroups or data catalogs by purpose, owner, or environment. Use a consistent set of tag keys to make it easier to search and filter workgroups or data catalogs in your account. For best practices, see <a href="https://docs.aws.amazon.com/whitepapers/latest/tagging-best-practices/tagging-best-practices.html">Tagging Best Practices</a>. Tag keys can be from 1 to 128 UTF-8 Unicode characters, and tag values can be from 0 to 256 UTF-8 Unicode characters. Tags can use letters and numbers representable in UTF-8, and the following characters: + - = . _ : / @. Tag keys and values are case-sensitive. Tag keys must be unique per resource. If you specify more than one tag, separate them by commas.

```go
TagResource(
    ctx context.Context,
    xAmzTarget models.XAmzTarget51Enum,
    body models.TagResourceInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget51Enum`](../../doc/models/x-amz-target-51-enum.md) | Header, Required | - |
| `body` | [`models.TagResourceInput`](../../doc/models/tag-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget51Enum_ENUMAMAZONATHENATAGRESOURCE

body := models.TagResourceInput{
    ResourceARN:          "ResourceARN4",
    Tags:                 []models.Tag{
        models.Tag{
        },
    },
}

apiResponse, err := aPIController.TagResource(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Terminate Session

Terminates an active session. A <code>TerminateSession</code> call on a session that is already inactive (for example, in a <code>FAILED</code>, <code>TERMINATED</code> or <code>TERMINATING</code> state) succeeds but has no effect. Calculations running in the session when <code>TerminateSession</code> is called are forcefully stopped, but may display as <code>FAILED</code> instead of <code>STOPPED</code>.

```go
TerminateSession(
    ctx context.Context,
    xAmzTarget models.XAmzTarget52Enum,
    body models.TerminateSessionRequest,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[models.TerminateSessionResponse],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget52Enum`](../../doc/models/x-amz-target-52-enum.md) | Header, Required | - |
| `body` | [`models.TerminateSessionRequest`](../../doc/models/terminate-session-request.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.TerminateSessionResponse](../../doc/models/terminate-session-response.md).

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget52Enum_ENUMAMAZONATHENATERMINATESESSION

body := models.TerminateSessionRequest{
    SessionId:            "SessionId2",
}

apiResponse, err := aPIController.TerminateSession(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Untag Resource

Removes one or more tags from a data catalog or workgroup resource.

```go
UntagResource(
    ctx context.Context,
    xAmzTarget models.XAmzTarget53Enum,
    body models.UntagResourceInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget53Enum`](../../doc/models/x-amz-target-53-enum.md) | Header, Required | - |
| `body` | [`models.UntagResourceInput`](../../doc/models/untag-resource-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget53Enum_ENUMAMAZONATHENAUNTAGRESOURCE

body := models.UntagResourceInput{
    ResourceARN:          "ResourceARN4",
    TagKeys:              []string{
        "TagKeys9",
        "TagKeys0",
    },
}

apiResponse, err := aPIController.UntagResource(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Update Data Catalog

Updates the data catalog that has the specified name.

```go
UpdateDataCatalog(
    ctx context.Context,
    xAmzTarget models.XAmzTarget54Enum,
    body models.UpdateDataCatalogInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget54Enum`](../../doc/models/x-amz-target-54-enum.md) | Header, Required | - |
| `body` | [`models.UpdateDataCatalogInput`](../../doc/models/update-data-catalog-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget54Enum_ENUMAMAZONATHENAUPDATEDATACATALOG

body := models.UpdateDataCatalogInput{
    Name:                 "Name6",
    Type:                 models.DataCatalogType3Enum_HIVE,
}

apiResponse, err := aPIController.UpdateDataCatalog(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Update Named Query

Updates a <a>NamedQuery</a> object. The database or workgroup cannot be updated.

```go
UpdateNamedQuery(
    ctx context.Context,
    xAmzTarget models.XAmzTarget55Enum,
    body models.UpdateNamedQueryInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget55Enum`](../../doc/models/x-amz-target-55-enum.md) | Header, Required | - |
| `body` | [`models.UpdateNamedQueryInput`](../../doc/models/update-named-query-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget55Enum_ENUMAMAZONATHENAUPDATENAMEDQUERY

body := models.UpdateNamedQueryInput{
    NamedQueryId:         "NamedQueryId6",
    Name:                 "Name6",
    QueryString:          "QueryString8",
}

apiResponse, err := aPIController.UpdateNamedQuery(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |


# Update Notebook

Updates the contents of a Spark notebook.

```go
UpdateNotebook(
    ctx context.Context,
    xAmzTarget models.XAmzTarget56Enum,
    body models.UpdateNotebookInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget56Enum`](../../doc/models/x-amz-target-56-enum.md) | Header, Required | - |
| `body` | [`models.UpdateNotebookInput`](../../doc/models/update-notebook-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget56Enum_ENUMAMAZONATHENAUPDATENOTEBOOK

body := models.UpdateNotebookInput{
    NotebookId:           "NotebookId6",
    Payload:              "Payload2",
    Type:                 models.NotebookType2Enum_IPYNB,
}

apiResponse, err := aPIController.UpdateNotebook(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# Update Notebook Metadata

Updates the metadata for a notebook.

```go
UpdateNotebookMetadata(
    ctx context.Context,
    xAmzTarget models.XAmzTarget57Enum,
    body models.UpdateNotebookMetadataInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget57Enum`](../../doc/models/x-amz-target-57-enum.md) | Header, Required | - |
| `body` | [`models.UpdateNotebookMetadataInput`](../../doc/models/update-notebook-metadata-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget57Enum_ENUMAMAZONATHENAUPDATENOTEBOOKMETADATA

body := models.UpdateNotebookMetadataInput{
    NotebookId:           "NotebookId6",
    Name:                 "Name6",
}

apiResponse, err := aPIController.UpdateNotebookMetadata(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | TooManyRequestsException | `ApiError` |


# Update Prepared Statement

Updates a prepared statement.

```go
UpdatePreparedStatement(
    ctx context.Context,
    xAmzTarget models.XAmzTarget58Enum,
    body models.UpdatePreparedStatementInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget58Enum`](../../doc/models/x-amz-target-58-enum.md) | Header, Required | - |
| `body` | [`models.UpdatePreparedStatementInput`](../../doc/models/update-prepared-statement-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget58Enum_ENUMAMAZONATHENAUPDATEPREPAREDSTATEMENT

body := models.UpdatePreparedStatementInput{
    StatementName:        "StatementName4",
    WorkGroup:            "WorkGroup8",
    QueryStatement:       "QueryStatement8",
}

apiResponse, err := aPIController.UpdatePreparedStatement(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |
| 482 | ResourceNotFoundException | `ApiError` |


# Update Work Group

Updates the workgroup with the specified name. The workgroup's name cannot be changed. Only <code>ConfigurationUpdates</code> can be specified.

```go
UpdateWorkGroup(
    ctx context.Context,
    xAmzTarget models.XAmzTarget59Enum,
    body models.UpdateWorkGroupInput,
    xAmzContentSha256 *string,
    xAmzDate *string,
    xAmzAlgorithm *string,
    xAmzCredential *string,
    xAmzSecurityToken *string,
    xAmzSignature *string,
    xAmzSignedHeaders *string) (
    models.ApiResponse[interface{}],
    error)
```

## Authentication

This endpoint requires [hmac](../../doc/auth/custom-header-signature.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xAmzTarget` | [`models.XAmzTarget59Enum`](../../doc/models/x-amz-target-59-enum.md) | Header, Required | - |
| `body` | [`models.UpdateWorkGroupInput`](../../doc/models/update-work-group-input.md) | Body, Required | - |
| `xAmzContentSha256` | `*string` | Header, Optional | - |
| `xAmzDate` | `*string` | Header, Optional | - |
| `xAmzAlgorithm` | `*string` | Header, Optional | - |
| `xAmzCredential` | `*string` | Header, Optional | - |
| `xAmzSecurityToken` | `*string` | Header, Optional | - |
| `xAmzSignature` | `*string` | Header, Optional | - |
| `xAmzSignedHeaders` | `*string` | Header, Optional | - |

## Response Type

**200**: Success

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xAmzTarget := models.XAmzTarget59Enum_ENUMAMAZONATHENAUPDATEWORKGROUP

body := models.UpdateWorkGroupInput{
    WorkGroup:            "WorkGroup8",
}

apiResponse, err := aPIController.UpdateWorkGroup(ctx, xAmzTarget, body, nil, nil, nil, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 480 | InternalServerException | `ApiError` |
| 481 | InvalidRequestException | `ApiError` |

