
# Instance Size Slug

The instance size to use for this component. Default: `basic-xxs`

## Enumeration

`InstanceSizeSlug`

## Fields

| Name |
|  --- |
| `BASICXXS` |
| `BASICXS` |
| `BASICS` |
| `BASICM` |
| `PROFESSIONALXS` |
| `PROFESSIONALS` |
| `PROFESSIONALM` |
| `PROFESSIONAL1L` |
| `PROFESSIONALL` |
| `PROFESSIONALXL` |

## Example

```python
from digitaloceanapi.models.instance_size_slug import InstanceSizeSlug

instance_size_slug = InstanceSizeSlug.PROFESSIONALXS
```

