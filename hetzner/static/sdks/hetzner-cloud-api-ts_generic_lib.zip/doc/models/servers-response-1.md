
# Servers Response 1

## Structure

`ServersResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`Action \| undefined`](../../doc/models/action.md) | Optional | - |

## Example

```ts
import { ServersResponse1, StatusEnum } from 'hetzner-cloud-apilib';

const serversResponse1: ServersResponse1 = {
  action: {
    command: 'command6',
    error: {
      code: 'code2',
      message: 'message4',
    },
    finished: 'finished0',
    id: 238,
    progress: 143.26,
    resources: [
      {
        id: 198,
        type: 'type0',
      },
      {
        id: 198,
        type: 'type0',
      },
      {
        id: 198,
        type: 'type0',
      }
    ],
    started: 'started8',
    status: StatusEnum.Running,
  },
};
```

