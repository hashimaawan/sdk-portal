
# Floating Ips Actions Response

## Structure

`FloatingIpsActionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `actions` | [`Action[]`](../../doc/models/action.md) | Required | - |

## Example

```ts
import { FloatingIpsActionsResponse, StatusEnum } from 'hetzner-cloud-apilib';

const floatingIpsActionsResponse: FloatingIpsActionsResponse = {
  actions: [
    {
      command: 'start_server',
      error: {
        code: 'action_failed',
        message: 'Action failed',
      },
      finished: '2016-01-30T23:55:00+00:00',
      id: 42,
      progress: 100,
      resources: [
        {
          id: 42,
          type: 'server',
        }
      ],
      started: '2016-01-30T23:55:00+00:00',
      status: StatusEnum.Success,
    }
  ],
};
```

