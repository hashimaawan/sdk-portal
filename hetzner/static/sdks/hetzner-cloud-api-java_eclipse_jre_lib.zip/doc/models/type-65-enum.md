
# Type 65 Enum

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65Enum`

## Fields

| Name |
|  --- |
| `LINUX64` |
| `LINUX32` |

## Example

```java
import cloud.hetzner.api.models.Type65Enum;

Type65Enum type65 = Type65Enum.LINUX64;
```

