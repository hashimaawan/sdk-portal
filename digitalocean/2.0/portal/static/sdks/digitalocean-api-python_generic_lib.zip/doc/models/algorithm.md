
# Algorithm

This field has been deprecated. You can no longer specify an algorithm for load balancers.

## Enumeration

`Algorithm`

## Fields

| Name |
|  --- |
| `ROUND_ROBIN` |
| `LEAST_CONNECTIONS` |

## Example

```python
from digitaloceanapi.models.algorithm import Algorithm

algorithm = Algorithm.ROUND_ROBIN
```

