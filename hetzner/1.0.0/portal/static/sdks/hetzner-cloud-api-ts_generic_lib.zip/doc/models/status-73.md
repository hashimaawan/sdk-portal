
# Status 73

Status of the Server

## Enumeration

`Status73`

## Fields

| Name |
|  --- |
| `Running` |
| `Initializing` |
| `Starting` |
| `Stopping` |
| `Off` |
| `Deleting` |
| `Migrating` |
| `Rebuilding` |
| `Unknown` |

## Example

```ts
import { Status73 } from 'hetzner-cloud-apilib';

const status73 = Status73.Starting;
```

