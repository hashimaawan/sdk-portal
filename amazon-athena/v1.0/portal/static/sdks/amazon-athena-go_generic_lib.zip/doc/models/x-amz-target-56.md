
# X Amz Target 56

## Enumeration

`XAmzTarget56`

## Fields

| Name |
|  --- |
| `EnumAmazonathenaupdatenotebook` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget56 := models.XAmzTarget56_EnumAmazonathenaupdatenotebook

}
```

