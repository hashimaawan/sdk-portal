
# Cpu Type

Type of cpu

## Enumeration

`CpuType`

## Fields

| Name |
|  --- |
| `Shared` |
| `Dedicated` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    cpuType := models.CpuType_Shared

}
```

