
# Engine Configuration 1

## Structure

`EngineConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `coordinator_dpu_size` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `max_concurrent_dpus` | `Integer` | Required | **Constraints**: `>= 2`, `<= 5000` |
| `default_executor_dpu_size` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 1` |
| `additional_configs` | [`AdditionalConfigs`](../../doc/models/additional-configs.md) | Optional | - |

## Example

```ruby
engine_configuration1 = EngineConfiguration1.new(
  96,
  1,
  1,
  AdditionalConfigs.new
)
```

