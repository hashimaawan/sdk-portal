
# Load Balancers Actions Detach from Network Request

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `Float` | Required | ID of an existing network to detach the Load Balancer from |

## Example

```ruby
load_balancers_actions_detach_from_network_request = LoadBalancersActionsDetachFromNetworkRequest.new(
  4711
)
```

