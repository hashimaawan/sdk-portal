
# X Amz Target 8

## Enumeration

`XAmzTarget8`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENACREATEWORKGROUP` |

## Example

```ruby
x_amz_target8 = XAmzTarget8::ENUM_AMAZONATHENACREATEWORKGROUP
```

