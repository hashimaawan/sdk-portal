
# Type 5 Enum

Type of resource referenced

## Enumeration

`Type5Enum`

## Fields

| Name |
|  --- |
| `SERVER` |

## Example

```python
from hetznercloudapi.models.type_5_enum import Type5Enum

type_5 = Type5Enum.SERVER
```

