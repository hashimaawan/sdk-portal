
# Data Catalog Type 2

The data catalog type.

## Enumeration

`DataCatalogType2`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```php
use AmazonAthenaLib\Models\DataCatalogType2;

$dataCatalogType2 = DataCatalogType2::LAMBDA;
```

