
# X Amz Target 48

## Enumeration

`XAmzTarget48`

## Fields

| Name |
|  --- |
| `EnumAmazonathenastartsession` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    xAmzTarget48 := models.XAmzTarget48_EnumAmazonathenastartsession

}
```

