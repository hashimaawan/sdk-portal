
# Export Notebook Input

## Structure

`ExportNotebookInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` | getNotebookId(): string | setNotebookId(string notebookId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\ExportNotebookInputBuilder;

$exportNotebookInput = ExportNotebookInputBuilder::init(
    'NotebookId2'
)->build();
```

