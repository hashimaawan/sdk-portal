
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `int` | Required | ID of the Resource | int getId() | setId(int id) |
| `Type` | `String` | Required | Type of resource referenced | String getType() | setType(String type) |

## Example

```java
import cloud.hetzner.api.models.Resource;

Resource resource = new Resource.Builder(
    42,
    "server"
)
.build();
```

