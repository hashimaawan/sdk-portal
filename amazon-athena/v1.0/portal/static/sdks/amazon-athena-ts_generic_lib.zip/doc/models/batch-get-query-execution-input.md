
# Batch Get Query Execution Input

Contains an array of query execution IDs.

## Structure

`BatchGetQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `queryExecutionIds` | `string[]` | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `50`, *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```ts
import { BatchGetQueryExecutionInput } from 'amazon-athenalib';

const batchGetQueryExecutionInput: BatchGetQueryExecutionInput = {
  queryExecutionIds: [
    'QueryExecutionIds7',
    'QueryExecutionIds8',
    'QueryExecutionIds9'
  ],
};
```

