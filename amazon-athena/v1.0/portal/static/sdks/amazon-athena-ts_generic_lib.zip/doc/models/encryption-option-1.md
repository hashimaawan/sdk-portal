
# Encryption Option 1

<p>Indicates whether Amazon S3 server-side encryption with Amazon S3-managed keys (<code>SSE_S3</code>), server-side encryption with KMS-managed keys (<code>SSE_KMS</code>), or client-side encryption with KMS-managed keys (<code>CSE_KMS</code>) is used.</p> <p>If a query runs in a workgroup and the workgroup overrides client-side settings, then the workgroup's setting for encryption is used. It specifies whether query results must be encrypted, for all queries that run in this workgroup. </p>


## Enumeration

`EncryptionOption1`

## Fields

| Name |
|  --- |
| `SseS3` |
| `SseKms` |
| `CseKms` |

## Example

```ts
import { EncryptionOption1 } from 'amazon-athenalib';

const encryptionOption1 = EncryptionOption1.CseKms;
```

