
# Data Catalog Type Enum

## Enumeration

`DataCatalogTypeEnum`

## Fields

| Name |
|  --- |
| `LAMBDA` |
| `GLUE` |
| `HIVE` |

## Example

```java
import com.amazonaws.useast1.athena.models.DataCatalogTypeEnum;

DataCatalogTypeEnum dataCatalogType = DataCatalogTypeEnum.HIVE;
```

