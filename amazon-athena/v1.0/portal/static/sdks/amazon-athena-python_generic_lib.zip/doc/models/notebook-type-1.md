
# Notebook Type 1

The type of notebook. Currently, the only valid type is <code>IPYNB</code>.

## Enumeration

`NotebookType1`

## Fields

| Name |
|  --- |
| `IPYNB` |

## Example

```python
from amazonathena.models.notebook_type_1 import NotebookType1

notebook_type_1 = NotebookType1.IPYNB
```

