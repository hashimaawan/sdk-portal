
# V2 Databases Config Request

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`V2DatabasesConfigRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `config` | [Config](../../doc/models/config.md)\|[Config](../../doc/models/config.md)1\|[Config](../../doc/models/config.md)2\|null | Optional | This is a container for any-of cases. | getConfig(): | setConfig( config): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\V2DatabasesConfigRequestBuilder;
use DigitalOceanApiLib\Models\Builders\ConfigBuilder;
use DigitalOceanApiLib\ApiHelper;

$v2DatabasesConfigRequest = V2DatabasesConfigRequestBuilder::init()
    ->config(
        ConfigBuilder::init()
            ->backupHour(23)
            ->backupMinute(59)
            ->binlogRetentionPeriod(600)
            ->connectTimeout(196)
            ->defaultTimeZone('default_time_zone8')
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

