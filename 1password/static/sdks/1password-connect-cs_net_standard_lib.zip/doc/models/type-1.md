
# Type 1

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `MString` |
| `Email` |
| `Concealed` |
| `Url` |
| `Totp` |
| `Date` |
| `MonthYear` |
| `Menu` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

Type1 type1 = Type1.Concealed;
```

