
# Engine 1

A slug representing the database engine used for the cluster. The possible values are: "pg" for PostgreSQL, "mysql" for MySQL, "redis" for Redis, and "mongodb" for MongoDB.

## Enumeration

`Engine1`

## Fields

| Name |
|  --- |
| `PG` |
| `MYSQL` |
| `REDIS` |
| `MONGODB` |

## Example

```php
use DigitalOceanApiLib\Models\Engine1;

$engine1 = Engine1::REDIS;
```

