
# Column Nullable 2

Indicates the column's nullable status.

## Enumeration

`ColumnNullable2`

## Fields

| Name |
|  --- |
| `NOT_NULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```php
use AmazonAthenaLib\Models\ColumnNullable2;

$columnNullable2 = ColumnNullable2::NOT_NULL;
```

