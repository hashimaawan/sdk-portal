
# Application DPU Sizes

Contains the application runtime IDs and their supported DPU sizes.

## Structure

`ApplicationDPUSizes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `application_runtime_id` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `supported_dpu_sizes` | `Array[Integer]` | Optional | - |

## Example

```ruby
application_dpu_sizes = ApplicationDPUSizes.new(
  'ApplicationRuntimeId8',
  [
    137
  ]
)
```

