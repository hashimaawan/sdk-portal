
# V2 Kubernetes Clusters Node Pools Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2KubernetesClustersNodePoolsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `node_pools` | [`Array[NodePool]`](../../doc/models/node-pool.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_kubernetes_clusters_node_pools_response = V2KubernetesClustersNodePoolsResponse.new(
  node_pools: [
    NodePool.new(
      size: 'size6',
      count: 206,
      name: 'name4',
      auto_scale: false,
      id: '000013be-0000-0000-0000-000000000000',
      labels: { 'key1' => 'val1', 'key2' => 'val2' },
      max_nodes: 118,
      min_nodes: 54,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    ),
    NodePool.new(
      size: 'size6',
      count: 206,
      name: 'name4',
      auto_scale: false,
      id: '000013be-0000-0000-0000-000000000000',
      labels: { 'key1' => 'val1', 'key2' => 'val2' },
      max_nodes: 118,
      min_nodes: 54,
      additional_properties: {
        'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
      }
    )
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

