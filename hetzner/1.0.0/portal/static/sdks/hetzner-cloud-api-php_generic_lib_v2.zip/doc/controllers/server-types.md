# Server Types

```php
$serverTypesController = $client->getServerTypesController();
```

## Class Name

`ServerTypesController`

## Methods

* [Get All Server Types](../../doc/controllers/server-types.md#get-all-server-types)
* [Get a Server Type](../../doc/controllers/server-types.md#get-a-server-type)


# Get All Server Types

Gets all Server type objects.

```php
function getAllServerTypes(?string $name = null): ServerTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `?string` | Query, Optional | Can be used to filter Server types by their name. The response will only contain the Server type matching the specified name. |

## Response Type

**200**: The `server_types` key in the reply contains an array of Server type objects with this structure

[`ServerTypesResponse`](../../doc/models/server-types-response.md)

## Example Usage

```php
$serverTypesController = $client->getServerTypesController();

try {
    $result = $serverTypesController->getAllServerTypes();
    echo 'ServerTypesResponse:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```


# Get a Server Type

Gets a specific Server type object.

```php
function getAServerType(int $id): ServerTypesResponse1
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Server Type |

## Response Type

**200**: The `server_type` key in the reply contains a Server type object with this structure

[`ServerTypesResponse1`](../../doc/models/server-types-response-1.md)

## Example Usage

```php
$id = 112;

$serverTypesController = $client->getServerTypesController();

try {
    $result = $serverTypesController->getAServerType($id);
    echo 'ServerTypesResponse1:';
    var_dump($result);
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

