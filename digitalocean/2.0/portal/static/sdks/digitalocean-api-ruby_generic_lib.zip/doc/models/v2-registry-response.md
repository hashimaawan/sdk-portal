
# V2 Registry Response

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2RegistryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registry` | [`Registry`](../../doc/models/registry.md) | Optional | - |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_registry_response = V2RegistryResponse.new(
  registry: Registry.new(
    created_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    name: 'name2',
    region: 'region8',
    storage_usage_bytes: 50,
    storage_usage_bytes_updated_at: DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z'),
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

