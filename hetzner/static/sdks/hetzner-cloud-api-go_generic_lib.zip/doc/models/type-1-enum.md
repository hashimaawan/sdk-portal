
# Type 1 Enum

Choose between uploading a Certificate in PEM format or requesting a managed *Let's Encrypt* Certificate. If omitted defaults to `uploaded`.

## Enumeration

`Type1Enum`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    type1 := models.Type1Enum_UPLOADED

}
```

