
# X Amz Target 21 Enum

## Enumeration

`XAmzTarget21Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```ruby
x_amz_target21 = XAmzTarget21Enum::ENUM_AMAZONATHENAGETNOTEBOOKMETADATA
```

