
# Type 15

The action to be taken on the image. Can be either `convert` or `transfer`.

## Enumeration

`Type15`

## Fields

| Name |
|  --- |
| `CONVERT` |
| `TRANSFER` |

## Example

```python
from digitaloceanapi.models.type_15 import Type15

type_15 = Type15.CONVERT
```

