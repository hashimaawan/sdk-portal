
# Engine Configuration

Contains data processing unit (DPU) configuration settings and parameter mappings for a notebook engine.

## Structure

`EngineConfiguration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CoordinatorDpuSize` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 1` | Integer getCoordinatorDpuSize() | setCoordinatorDpuSize(Integer coordinatorDpuSize) |
| `MaxConcurrentDpus` | `int` | Required | **Constraints**: `>= 2`, `<= 5000` | int getMaxConcurrentDpus() | setMaxConcurrentDpus(int maxConcurrentDpus) |
| `DefaultExecutorDpuSize` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 1` | Integer getDefaultExecutorDpuSize() | setDefaultExecutorDpuSize(Integer defaultExecutorDpuSize) |
| `AdditionalConfigs` | [`AdditionalConfigs`](../../doc/models/additional-configs.md) | Optional | - | AdditionalConfigs getAdditionalConfigs() | setAdditionalConfigs(AdditionalConfigs additionalConfigs) |

## Example

```java
import com.amazonaws.useast1.athena.models.AdditionalConfigs;
import com.amazonaws.useast1.athena.models.EngineConfiguration;

EngineConfiguration engineConfiguration = new EngineConfiguration.Builder(
    194
)
.coordinatorDpuSize(1)
.defaultExecutorDpuSize(1)
.additionalConfigs(new AdditionalConfigs.Builder()
        .build())
.build();
```

