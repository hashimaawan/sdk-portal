
# Get Data Catalog Output

## Structure

`GetDataCatalogOutput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `data_catalog` | [`DataCatalog2`](../../doc/models/data-catalog-2.md) | Optional | - |

## Example

```ruby
get_data_catalog_output = GetDataCatalogOutput.new(
  DataCatalog2.new(
    'Name4',
    DataCatalogType1Enum::GLUE,
    'Description2',
    Parameters.new
  )
)
```

