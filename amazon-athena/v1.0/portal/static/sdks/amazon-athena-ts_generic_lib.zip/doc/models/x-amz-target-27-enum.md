
# X Amz Target 27 Enum

## Enumeration

`XAmzTarget27Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetSessionStatus` |

## Example

```ts
import { XAmzTarget27Enum } from 'amazon-athenalib';

const xAmzTarget27 = XAmzTarget27Enum.EnumAmazonAthenaGetSessionStatus;
```

