
# Alerts

*This model accepts additional fields of type Object.*

## Structure

`Alerts`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Email` | `List<String>` | Required | An email to notify on an alert trigger. | List<String> getEmail() | setEmail(List<String> email) |
| `Slack` | [`List<Slack>`](../../doc/models/slack.md) | Required | Slack integration details. | List<Slack> getSlack() | setSlack(List<Slack> slack) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import com.digitalocean.api.ApiHelper;
import com.digitalocean.api.models.Alerts;
import com.digitalocean.api.models.Slack;
import java.io.IOException;
import java.util.Arrays;

Alerts alerts = new Alerts.Builder(
    Arrays.asList(
        "bob@exmaple.com"
    ),
    Arrays.asList(
        new Slack.Builder(
            "Production Alerts",
            "https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

