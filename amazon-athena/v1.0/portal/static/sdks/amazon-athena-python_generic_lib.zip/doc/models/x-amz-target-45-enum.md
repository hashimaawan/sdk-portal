
# X Amz Target 45 Enum

## Enumeration

`XAmzTarget45Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTWORKGROUPS` |

## Example

```python
from amazonathena.models.x_amz_target_45_enum import XAmzTarget45Enum

x_amz_target_45 = XAmzTarget45Enum.ENUM_AMAZONATHENALISTWORKGROUPS
```

