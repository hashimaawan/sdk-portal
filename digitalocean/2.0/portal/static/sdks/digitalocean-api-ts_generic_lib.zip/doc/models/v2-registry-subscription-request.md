
# V2 Registry Subscription Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2RegistrySubscriptionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tierSlug` | [`TierSlug \| undefined`](../../doc/models/tier-slug.md) | Optional | The slug of the subscription tier to sign up for. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { TierSlug, V2RegistrySubscriptionRequest } from 'digitalocean-apilib';

const v2RegistrySubscriptionRequest: V2RegistrySubscriptionRequest = {
  tierSlug: TierSlug.Basic,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

