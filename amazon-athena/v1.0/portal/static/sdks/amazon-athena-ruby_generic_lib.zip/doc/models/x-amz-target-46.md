
# X Amz Target 46

## Enumeration

`XAmzTarget46`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION` |

## Example

```ruby
x_amz_target46 = XAmzTarget46::ENUM_AMAZONATHENASTARTCALCULATIONEXECUTION
```

