
# List Application DPU Sizes Input

## Structure

`ListApplicationDPUSizesInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MaxResults` | `Integer` | Optional | **Constraints**: `>= 1`, `<= 100` | Integer getMaxResults() | setMaxResults(Integer maxResults) |
| `NextToken` | `String` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` | String getNextToken() | setNextToken(String nextToken) |

## Example

```java
import com.amazonaws.useast1.athena.models.ListApplicationDPUSizesInput;

ListApplicationDPUSizesInput listApplicationDPUSizesInput = new ListApplicationDPUSizesInput.Builder()
    .maxResults(100)
    .nextToken("NextToken8")
    .build();
```

