
# Table Metadata

Contains metadata for a table.

*This model accepts additional fields of type unknown.*

## Structure

`TableMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `createTime` | `string \| undefined` | Optional | - |
| `lastAccessTime` | `string \| undefined` | Optional | - |
| `tableType` | `string \| undefined` | Optional | **Constraints**: *Maximum Length*: `255` |
| `columns` | [`Column[] \| undefined`](../../doc/models/column.md) | Optional | - |
| `partitionKeys` | [`Column[] \| undefined`](../../doc/models/column.md) | Optional | - |
| `parameters` | [`Parameters \| undefined`](../../doc/models/parameters.md) | Optional | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { TableMetadata } from 'amazon-athenalib';

const tableMetadata: TableMetadata = {
  name: 'Name0',
  createTime: '2016-03-13T12:52:32.123Z',
  lastAccessTime: '2016-03-13T12:52:32.123Z',
  tableType: 'TableType4',
  columns: [
    {
      name: 'Name0',
      type: 'Type0',
      comment: 'Comment4',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  partitionKeys: [
    {
      name: 'Name6',
      type: 'Type6',
      comment: 'Comment0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      name: 'Name6',
      type: 'Type6',
      comment: 'Comment0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    {
      name: 'Name6',
      type: 'Type6',
      comment: 'Comment0',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

