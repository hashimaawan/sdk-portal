
# Playlist Snapshot Id

*This model accepts additional fields of type object.*

## Structure

`PlaylistSnapshotId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SnapshotId` | `string` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Models;
using SpotifyWebApiWithFixesAndImprovementsFromSonallux.Standard.Utilities;

PlaylistSnapshotId playlistSnapshotId = new PlaylistSnapshotId
{
    SnapshotId = "abc",
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

