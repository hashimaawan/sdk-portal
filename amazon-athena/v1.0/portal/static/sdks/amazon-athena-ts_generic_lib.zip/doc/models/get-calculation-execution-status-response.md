
# Get Calculation Execution Status Response

## Structure

`GetCalculationExecutionStatusResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`Status1 \| undefined`](../../doc/models/status-1.md) | Optional | - |
| `statistics` | [`Statistics1 \| undefined`](../../doc/models/statistics-1.md) | Optional | - |

## Example

```ts
import {
  CalculationExecutionState1Enum,
  GetCalculationExecutionStatusResponse,
} from 'amazon-athenalib';

const getCalculationExecutionStatusResponse: GetCalculationExecutionStatusResponse = {
  status: {
    submissionDateTime: '2016-03-13T12:52:32.123Z',
    completionDateTime: '2016-03-13T12:52:32.123Z',
    state: CalculationExecutionState1Enum.CANCELING,
    stateChangeReason: 'StateChangeReason8',
  },
  statistics: {
    dpuExecutionInMillis: 164,
    progress: 'Progress6',
  },
};
```

