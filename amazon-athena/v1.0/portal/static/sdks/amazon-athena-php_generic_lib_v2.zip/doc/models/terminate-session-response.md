
# Terminate Session Response

## Structure

`TerminateSessionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `state` | [`?string(SessionState1Enum)`](../../doc/models/session-state-1-enum.md) | Optional | - | getState(): ?string | setState(?string state): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\TerminateSessionResponseBuilder;
use AmazonAthenaLib\Models\SessionState1Enum;

$terminateSessionResponse = TerminateSessionResponseBuilder::init()
    ->state(SessionState1Enum::CREATING)
    ->build();
```

