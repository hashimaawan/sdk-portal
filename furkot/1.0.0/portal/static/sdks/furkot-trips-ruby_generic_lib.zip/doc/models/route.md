
# Route

route leading to the stop

*This model accepts additional fields of type Object.*

## Structure

`Route`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `distance` | `Integer` | Optional | route distance in meters |
| `duration` | `Integer` | Optional | route duration in seconds |
| `mode` | [`Mode`](../../doc/models/mode.md) | Optional | travel mode |
| `polyline` | `String` | Optional | route path compatible with Google polyline encoding algorithm |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
route = Route.new(
  distance: 134,
  duration: 168,
  mode: Mode::CAR,
  polyline: 'polyline0',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

