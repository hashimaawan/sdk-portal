
# Taint

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Taint`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `effect` | [`Effect \| undefined`](../../doc/models/effect.md) | Optional | How the node reacts to pods that it won't tolerate. Available effect values are `NoSchedule`, `PreferNoSchedule`, and `NoExecute`. |
| `key` | `string \| undefined` | Optional | An arbitrary string. The `key` and `value` fields of the `taint` object form a key-value pair. For example, if the value of the `key` field is "special" and the value of the `value` field is "gpu", the key value pair would be `special=gpu`. |
| `value` | `string \| undefined` | Optional | An arbitrary string. The `key` and `value` fields of the `taint` object form a key-value pair. For example, if the value of the `key` field is "special" and the value of the `value` field is "gpu", the key value pair would be `special=gpu`. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Effect, Taint } from 'digitalocean-apilib';

const taint: Taint = {
  effect: Effect.NoSchedule,
  key: 'priority',
  value: 'high',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

