
# Server Types Response

## Structure

`ServerTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `serverTypes` | [`ServerTypes7[]`](../../doc/models/server-types-7.md) | Required | - |

## Example

```ts
import {
  CpuTypeEnum,
  ServerTypesResponse,
  StorageTypeEnum,
} from 'hetzner-cloud-apilib';

const serverTypesResponse: ServerTypesResponse = {
  serverTypes: [
    {
      cores: 1,
      cpuType: CpuTypeEnum.Shared,
      deprecated: false,
      description: 'CX11',
      disk: 24,
      id: 1,
      memory: 1,
      name: 'cx11',
      prices: [
        {
          location: 'fsn1',
          priceHourly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
          },
          priceMonthly: {
            gross: '1.1900000000000000',
            net: '1.0000000000',
          },
        }
      ],
      storageType: StorageTypeEnum.Local,
    }
  ],
};
```

