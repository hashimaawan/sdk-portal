# Load Balancer Types

```java
LoadBalancerTypesApi loadBalancerTypesApi = client.getLoadBalancerTypesApi();
```

## Class Name

`LoadBalancerTypesApi`

## Methods

* [Get All Load Balancer Types](../../doc/controllers/load-balancer-types.md#get-all-load-balancer-types)
* [Get a Load Balancer Type](../../doc/controllers/load-balancer-types.md#get-a-load-balancer-type)


# Get All Load Balancer Types

Gets all Load Balancer type objects.

```java
CompletableFuture<ApiResponse<LoadBalancerTypesResponse>> getAllLoadBalancerTypesAsync(
    final String name)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Query, Optional | Can be used to filter Load Balancer types by their name. The response will only contain the Load Balancer type matching the specified name. |

## Response Type

**200**: The `load_balancer_types` key in the reply contains an array of Load Balancer type objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`LoadBalancerTypesResponse`](../../doc/models/load-balancer-types-response.md).

## Example Usage

```java
loadBalancerTypesApi.getAllLoadBalancerTypesAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get a Load Balancer Type

Gets a specific Load Balancer type object.

```java
CompletableFuture<ApiResponse<LoadBalancerTypesResponse1>> getALoadBalancerTypeAsync(
    final int id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Load Balancer type |

## Response Type

**200**: The `load_balancer_type` key in the reply contains a Load Balancer type object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`LoadBalancerTypesResponse1`](../../doc/models/load-balancer-types-response-1.md).

## Example Usage

```java
int id = 112;

loadBalancerTypesApi.getALoadBalancerTypeAsync(id).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

