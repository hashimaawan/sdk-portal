
# Server 11

## Structure

`Server11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Server |

## Example

```ts
import { Server11 } from 'hetzner-cloud-apilib';

const server11: Server11 = {
  id: 85,
};
```

