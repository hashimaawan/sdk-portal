
# Type 42 Enum

Type of Subnetwork

## Enumeration

`Type42Enum`

## Fields

| Name |
|  --- |
| `Cloud` |
| `Server` |
| `Vswitch` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type42Enum type42 = Type42Enum.Cloud;
```

