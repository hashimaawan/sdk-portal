
# Type 39

Algorithm of the Load Balancer

## Enumeration

`Type39`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    type39 := models.Type39_RoundRobin

}
```

