
# Filters

## Structure

`Filters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `*string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    filters := models.Filters{
        Name:                 models.ToPointer("Name0"),
    }

}
```

