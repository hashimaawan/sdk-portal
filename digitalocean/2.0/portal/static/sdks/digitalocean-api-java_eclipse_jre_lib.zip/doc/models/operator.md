
# Operator

## Enumeration

`Operator`

## Fields

| Name |
|  --- |
| `UNSPECIFIED_OPERATOR` |
| `GREATER_THAN` |
| `LESS_THAN` |

## Example

```java
import com.digitalocean.api.models.Operator;

Operator operator = Operator.LESS_THAN;
```

