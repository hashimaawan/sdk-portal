
# Type 28 Enum

Type of the algorithm

## Enumeration

`Type28Enum`

## Fields

| Name |
|  --- |
| `RoundRobin` |
| `LeastConnections` |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

Type28Enum type28 = Type28Enum.RoundRobin;
```

