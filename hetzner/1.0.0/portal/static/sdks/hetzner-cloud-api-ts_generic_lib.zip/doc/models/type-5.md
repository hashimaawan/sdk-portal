
# Type 5

Type of resource referenced

## Enumeration

`Type5`

## Fields

| Name |
|  --- |
| `Server` |

## Example

```ts
import { Type5 } from 'hetzner-cloud-apilib';

const type5 = Type5.Server;
```

