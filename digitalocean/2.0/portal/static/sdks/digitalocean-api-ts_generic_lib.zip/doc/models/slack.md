
# Slack

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Slack`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `channel` | `string` | Required | Slack channel to notify of an alert trigger. |
| `url` | `string` | Required | Slack Webhook URL. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Slack } from 'digitalocean-apilib';

const slack: Slack = {
  channel: 'Production Alerts',
  url: 'https://hooks.slack.com/services/T1234567/AAAAAAAA/ZZZZZZ',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

