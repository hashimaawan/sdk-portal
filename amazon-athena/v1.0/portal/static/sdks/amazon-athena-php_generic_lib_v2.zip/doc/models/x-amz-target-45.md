
# X Amz Target 45

## Enumeration

`XAmzTarget45`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENALISTWORKGROUPS` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget45;

$xAmzTarget45 = XAmzTarget45::ENUM_AMAZONATHENALISTWORKGROUPS;
```

