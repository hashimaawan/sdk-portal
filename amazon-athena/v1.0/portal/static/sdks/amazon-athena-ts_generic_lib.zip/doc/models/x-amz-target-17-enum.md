
# X Amz Target 17 Enum

## Enumeration

`XAmzTarget17Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetCalculationExecutionStatus` |

## Example

```ts
import { XAmzTarget17Enum } from 'amazon-athenalib';

const xAmzTarget17 = XAmzTarget17Enum.EnumAmazonAthenaGetCalculationExecutionStatus;
```

