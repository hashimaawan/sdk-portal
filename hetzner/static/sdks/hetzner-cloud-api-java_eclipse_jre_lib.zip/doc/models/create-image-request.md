
# Create Image Request

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Description` | `String` | Optional | Description of the Image, will be auto-generated if not set | String getDescription() | setDescription(String description) |
| `Labels` | [`Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) | Labels getLabels() | setLabels(Labels labels) |
| `Type` | [`Type63Enum`](../../doc/models/type-63-enum.md) | Optional | Type of Image to create (default: `snapshot`) | Type63Enum getType() | setType(Type63Enum type) |

## Example

```java
import cloud.hetzner.api.models.CreateImageRequest;
import cloud.hetzner.api.models.Labels;
import cloud.hetzner.api.models.Type63Enum;

CreateImageRequest createImageRequest = new CreateImageRequest.Builder()
    .description("my image")
    .labels(new Labels.Builder()
        .labelkey("labelkey4")
        .build())
    .type(Type63Enum.SNAPSHOT)
    .build();
```

