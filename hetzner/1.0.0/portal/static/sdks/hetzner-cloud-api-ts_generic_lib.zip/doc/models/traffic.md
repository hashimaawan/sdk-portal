
# Traffic

The cost of additional traffic per TB

*This model accepts additional fields of type unknown.*

## Structure

`Traffic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pricePerTb` | [`PricePerTb`](../../doc/models/price-per-tb.md) | Required | - |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Traffic } from 'hetzner-cloud-apilib';

const traffic: Traffic = {
  pricePerTb: {
    gross: '1.1900000000000000',
    net: '1.0000000000',
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

