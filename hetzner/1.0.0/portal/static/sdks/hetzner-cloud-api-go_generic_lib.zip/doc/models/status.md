
# Status

Status of the Action

## Enumeration

`Status`

## Fields

| Name |
|  --- |
| `Success` |
| `Running` |
| `EnumError` |

## Example

```go
package main

import (
    "hetznerCloudApi/models"
)

func main() {
    status := models.Status_EnumError

}
```

