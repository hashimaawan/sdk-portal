
# Acl Configuration 1

## Structure

`AclConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `s3AclOption` | [`S3AclOption1Enum`](../../doc/models/s3-acl-option-1-enum.md) | Required | - |

## Example

```ts
import { AclConfiguration1, S3AclOption1Enum } from 'amazon-athenalib';

const aclConfiguration1: AclConfiguration1 = {
  s3AclOption: S3AclOption1Enum.BUCKETOWNERFULLCONTROL,
};
```

