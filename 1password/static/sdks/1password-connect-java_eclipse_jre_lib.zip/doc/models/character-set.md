
# Character Set

## Enumeration

`CharacterSet`

## Fields

| Name |
|  --- |
| `LETTERS` |
| `DIGITS` |
| `SYMBOLS` |

## Example

```java
import local.m1password.models.CharacterSet;

CharacterSet characterSet = CharacterSet.DIGITS;
```

