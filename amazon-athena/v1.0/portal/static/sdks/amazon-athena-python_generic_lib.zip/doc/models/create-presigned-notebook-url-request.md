
# Create Presigned Notebook Url Request

## Structure

`CreatePresignedNotebookUrlRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |

## Example

```python
from amazonathena.models.create_presigned_notebook_url_request import CreatePresignedNotebookUrlRequest

create_presigned_notebook_url_request = CreatePresignedNotebookUrlRequest(
    session_id='SessionId4'
)
```

