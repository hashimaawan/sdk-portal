
# Get Calculation Execution Code Response

## Structure

`GetCalculationExecutionCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CodeBlock` | `*string` | Optional | **Constraints**: *Maximum Length*: `68000` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    getCalculationExecutionCodeResponse := models.GetCalculationExecutionCodeResponse{
        CodeBlock:            models.ToPointer("CodeBlock4"),
    }

}
```

