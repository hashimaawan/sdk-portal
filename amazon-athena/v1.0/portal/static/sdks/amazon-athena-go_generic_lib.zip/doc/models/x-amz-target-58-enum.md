
# X Amz Target 58 Enum

## Enumeration

`XAmzTarget58Enum`

## Fields

| Name |
|  --- |
| `ENUMAMAZONATHENAUPDATEPREPAREDSTATEMENT` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    xAmzTarget58 := models.XAmzTarget58Enum_ENUMAMAZONATHENAUPDATEPREPAREDSTATEMENT

}
```

