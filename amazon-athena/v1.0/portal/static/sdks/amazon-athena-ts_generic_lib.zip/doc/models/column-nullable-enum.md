
# Column Nullable Enum

## Enumeration

`ColumnNullableEnum`

## Fields

| Name |
|  --- |
| `NOTNULL` |
| `NULLABLE` |
| `UNKNOWN` |

## Example

```ts
import { ColumnNullableEnum } from 'amazon-athenalib';

const columnNullable = ColumnNullableEnum.NOTNULL;
```

