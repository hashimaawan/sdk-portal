
# X Amz Target 58 Enum

## Enumeration

`XAmzTarget58Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT` |

## Example

```python
from amazonathena.models.x_amz_target_58_enum import XAmzTarget58Enum

x_amz_target_58 = XAmzTarget58Enum.ENUM_AMAZONATHENAUPDATEPREPAREDSTATEMENT
```

