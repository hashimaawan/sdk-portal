
# Type 65 Enum

Type of rescue system to boot (default: `linux64`)

## Enumeration

`Type65Enum`

## Fields

| Name |
|  --- |
| `Linux64` |
| `Linux32` |

## Example

```ts
import { Type65Enum } from 'hetzner-cloud-apilib';

const type65 = Type65Enum.Linux64;
```

