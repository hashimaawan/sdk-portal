
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| timeout | `int` | Timeout for API calls in seconds.<br>*Default*: `30` |
| enableRetries | `bool` | Whether to enable retries and backoff feature.<br>*Default*: `false` |
| numberOfRetries | `int` | The number of retries to make.<br>*Default*: `0` |
| retryInterval | `float` | The retry time interval between the endpoint calls.<br>*Default*: `1` |
| backOffFactor | `float` | Exponential backoff factor to increase interval between retries.<br>*Default*: `2` |
| maximumRetryWaitTime | `int` | The maximum wait time in seconds for overall retrying requests.<br>*Default*: `0` |
| retryOnTimeout | `bool` | Whether to retry on request timeout.<br>*Default*: `true` |
| httpStatusCodesToRetry | `array` | Http status codes to retry against.<br>*Default*: `408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524` |
| httpMethodsToRetry | `array` | Http methods to retry against.<br>*Default*: `'GET', 'PUT', 'GET', 'PUT'` |
| loggingConfiguration | [`LoggingConfigurationBuilder`](../doc/logging-configuration-builder.md) | Represents the logging configurations for API calls |
| proxyConfiguration | [`ProxyConfigurationBuilder`](../doc/proxy-configuration-builder.md) | Represents the proxy configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```php
use DigitalOceanApiLib\Logging\LoggingConfigurationBuilder;
use DigitalOceanApiLib\Logging\RequestLoggingConfigurationBuilder;
use DigitalOceanApiLib\Logging\ResponseLoggingConfigurationBuilder;
use Psr\Log\LogLevel;
use DigitalOceanApiLib\Authentication\BearerAuthCredentialsBuilder;
use DigitalOceanApiLib\DigitalOceanApiClientBuilder;

$client = DigitalOceanApiClientBuilder::init()
    ->bearerAuthCredentials(
        BearerAuthCredentialsBuilder::init(
            'AccessToken'
        )
    )
    ->loggingConfiguration(
        LoggingConfigurationBuilder::init()
            ->level(LogLevel::INFO)
            ->requestConfiguration(RequestLoggingConfigurationBuilder::init()->body(true))
            ->responseConfiguration(ResponseLoggingConfigurationBuilder::init()->headers(true))
    )
    ->build();
```

## DigitalOcean API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| getM1ClickApplicationsApi() | Gets M1ClickApplicationsApi |
| getAccountApi() | Gets AccountApi |
| getActionsApi() | Gets ActionsApi |
| getAppsApi() | Gets AppsApi |
| getBillingApi() | Gets BillingApi |
| getBlockStorageApi() | Gets BlockStorageApi |
| getBlockStorageActionsApi() | Gets BlockStorageActionsApi |
| getCdnEndpointsApi() | Gets CdnEndpointsApi |
| getCertificatesApi() | Gets CertificatesApi |
| getContainerRegistryApi() | Gets ContainerRegistryApi |
| getDatabasesApi() | Gets DatabasesApi |
| getDomainRecordsApi() | Gets DomainRecordsApi |
| getDomainsApi() | Gets DomainsApi |
| getDropletActionsApi() | Gets DropletActionsApi |
| getDropletsApi() | Gets DropletsApi |
| getFirewallsApi() | Gets FirewallsApi |
| getFloatingIpActionsApi() | Gets FloatingIpActionsApi |
| getFloatingIPsApi() | Gets FloatingIPsApi |
| getFunctionsApi() | Gets FunctionsApi |
| getImageActionsApi() | Gets ImageActionsApi |
| getImagesApi() | Gets ImagesApi |
| getKubernetesApi() | Gets KubernetesApi |
| getLoadBalancersApi() | Gets LoadBalancersApi |
| getMonitoringApi() | Gets MonitoringApi |
| getProjectResourcesApi() | Gets ProjectResourcesApi |
| getProjectsApi() | Gets ProjectsApi |
| getRegionsApi() | Gets RegionsApi |
| getReservedIpActionsApi() | Gets ReservedIpActionsApi |
| getReservedIPsApi() | Gets ReservedIPsApi |
| getSizesApi() | Gets SizesApi |
| getSnapshotsApi() | Gets SnapshotsApi |
| getSshKeysApi() | Gets SshKeysApi |
| getTagsApi() | Gets TagsApi |
| getUptimeApi() | Gets UptimeApi |
| getVpCsApi() | Gets VpCsApi |

