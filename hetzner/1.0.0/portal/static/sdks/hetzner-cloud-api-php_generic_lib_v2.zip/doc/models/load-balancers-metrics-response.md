
# Load Balancers Metrics Response

*This model accepts additional fields of type array.*

## Structure

`LoadBalancersMetricsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `metrics` | [`Metrics`](../../doc/models/metrics.md) | Required | - | getMetrics(): Metrics | setMetrics(Metrics metrics): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\LoadBalancersMetricsResponseBuilder;
use HetznerCloudApiLib\Models\Builders\MetricsBuilder;
use HetznerCloudApiLib\Models\Builders\TimeSeriesBuilder;
use HetznerCloudApiLib\ApiHelper;

$loadBalancersMetricsResponse = LoadBalancersMetricsResponseBuilder::init(
    MetricsBuilder::init(
        '2017-01-01T23:00:00+00:00',
        '2017-01-01T00:00:00+00:00',
        60,
        [
            'name_of_timeseries' => TimeSeriesBuilder::init(
                [
                    [
                        1435781470.622,
                        '42'
                    ],
                    [
                        1435781471.622,
                        '43'
                    ]
                ]
            )
                ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                ->build()
        ]
    )
        ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
        ->build()
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

