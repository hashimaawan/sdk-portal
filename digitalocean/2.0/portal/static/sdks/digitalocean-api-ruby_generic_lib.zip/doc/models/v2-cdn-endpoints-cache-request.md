
# V2 Cdn Endpoints Cache Request

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`V2CdnEndpointsCacheRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `files` | `Array[String]` | Required | An array of strings containing the path to the content to be purged from the CDN cache. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
v2_cdn_endpoints_cache_request = V2CdnEndpointsCacheRequest.new(
  files: [
    'path/to/image.png',
    'path/to/css/*'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

