
# Result

## Enumeration

`Result`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `DENY` |

## Example

```java
import local.m1password.models.Result;

Result result = Result.SUCCESS;
```

