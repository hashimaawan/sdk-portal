
# Result Reuse by Age Configuration

Specifies whether previous query results are reused, and if so, their maximum age.

## Structure

`ResultReuseByAgeConfiguration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Enabled` | `boolean` | Required | - | boolean getEnabled() | setEnabled(boolean enabled) |
| `MaxAgeInMinutes` | `Integer` | Optional | **Constraints**: `>= 0`, `<= 10080` | Integer getMaxAgeInMinutes() | setMaxAgeInMinutes(Integer maxAgeInMinutes) |

## Example

```java
import com.amazonaws.useast1.athena.models.ResultReuseByAgeConfiguration;

ResultReuseByAgeConfiguration resultReuseByAgeConfiguration = new ResultReuseByAgeConfiguration.Builder(
    false
)
.maxAgeInMinutes(134)
.build();
```

