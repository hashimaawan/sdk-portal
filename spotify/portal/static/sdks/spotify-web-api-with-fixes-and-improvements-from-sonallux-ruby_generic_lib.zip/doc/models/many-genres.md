
# Many Genres

*This model accepts additional fields of type Object.*

## Structure

`ManyGenres`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `genres` | `Array[String]` | Required | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
many_genres = ManyGenres.new(
  genres: [
    'alternative',
    'samba'
  ],
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

