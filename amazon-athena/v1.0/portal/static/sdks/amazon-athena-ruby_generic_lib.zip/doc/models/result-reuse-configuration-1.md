
# Result Reuse Configuration 1

*This model accepts additional fields of type Object.*

## Structure

`ResultReuseConfiguration1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result_reuse_by_age_configuration` | [`ResultReuseByAgeConfiguration2`](../../doc/models/result-reuse-by-age-configuration-2.md) | Optional | - |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
result_reuse_configuration1 = ResultReuseConfiguration1.new(
  result_reuse_by_age_configuration: ResultReuseByAgeConfiguration2.new(
    enabled: false,
    max_age_in_minutes: 26,
    additional_properties: {
      'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
    }
  ),
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

