
# Detach from Network Request

*This model accepts additional fields of type unknown.*

## Structure

`DetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `network` | `number` | Required | ID of an existing network to detach the Server from |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { DetachFromNetworkRequest } from 'hetzner-cloud-apilib';

const detachFromNetworkRequest: DetachFromNetworkRequest = {
  network: 4711,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

