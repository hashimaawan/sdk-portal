
# V2 Images Actions Request 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2ImagesActionsRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type15`](../../doc/models/type-15.md) | Required | The action to be taken on the image. Can be either `convert` or `transfer`. |
| `region` | [`Region2`](../../doc/models/region-2.md) | Required | The slug identifier for the region where the resource will initially be  available. |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.region_2 import Region2
from digitaloceanapi.models.type_15 import Type15
from digitaloceanapi.models.v_2_images_actions_request_1 import V2ImagesActionsRequest1

v_2_images_actions_request_1 = V2ImagesActionsRequest1(
    mtype=Type15.CONVERT,
    region=Region2.NYC3,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

