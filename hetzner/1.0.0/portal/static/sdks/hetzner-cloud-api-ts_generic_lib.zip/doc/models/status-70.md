
# Status 70

## Enumeration

`Status70`

## Fields

| Name |
|  --- |
| `Initializing` |
| `Starting` |
| `Running` |
| `Stopping` |
| `Off` |
| `Deleting` |
| `Rebuilding` |
| `Migrating` |
| `Unknown` |

## Example

```ts
import { Status70 } from 'hetzner-cloud-apilib';

const status70 = Status70.Migrating;
```

