
# Images Actions Change Protection Request

## Structure

`ImagesActionsChangeProtectionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Delete` | `Boolean` | Optional | If true, prevents the snapshot from being deleted | Boolean getDelete() | setDelete(Boolean delete) |

## Example

```java
import cloud.hetzner.api.models.ImagesActionsChangeProtectionRequest;

ImagesActionsChangeProtectionRequest imagesActionsChangeProtectionRequest = new ImagesActionsChangeProtectionRequest.Builder()
    .delete(true)
    .build();
```

