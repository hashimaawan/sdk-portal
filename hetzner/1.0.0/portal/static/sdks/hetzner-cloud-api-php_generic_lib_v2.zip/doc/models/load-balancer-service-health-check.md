
# Load Balancer Service Health Check

Service health check

## Structure

`LoadBalancerServiceHealthCheck`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `http` | [`?Http`](../../doc/models/http.md) | Optional | Additional configuration for protocol http | getHttp(): ?Http | setHttp(?Http http): void |
| `interval` | `int` | Required | Time interval in seconds health checks are performed | getInterval(): int | setInterval(int interval): void |
| `port` | `int` | Required | Port the health check will be performed on | getPort(): int | setPort(int port): void |
| `protocol` | [`string(Protocol6Enum)`](../../doc/models/protocol-6-enum.md) | Required | Type of the health check | getProtocol(): string | setProtocol(string protocol): void |
| `retries` | `int` | Required | Unsuccessful retries needed until a target is considered unhealthy; an unhealthy target needs the same number of successful retries to become healthy again | getRetries(): int | setRetries(int retries): void |
| `timeout` | `int` | Required | Time in seconds after an attempt is considered a timeout | getTimeout(): int | setTimeout(int timeout): void |

## Example

```php
use HetznerCloudAPILib\Models\Builders\LoadBalancerServiceHealthCheckBuilder;
use HetznerCloudAPILib\Models\Protocol6Enum;
use HetznerCloudAPILib\Models\Builders\HttpBuilder;

$loadBalancerServiceHealthCheck = LoadBalancerServiceHealthCheckBuilder::init(
    15,
    4711,
    Protocol6Enum::HTTP,
    3,
    10
)
    ->http(
        HttpBuilder::init(
            'path2'
        )
            ->domain('domain4')
            ->response('response8')
            ->statusCodes(
                [
                    'status_codes0',
                    'status_codes1',
                    'status_codes2'
                ]
            )
            ->tls(false)
            ->build()
    )
    ->build();
```

