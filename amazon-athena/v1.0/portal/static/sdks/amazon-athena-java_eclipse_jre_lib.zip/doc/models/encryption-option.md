
# Encryption Option

## Enumeration

`EncryptionOption`

## Fields

| Name |
|  --- |
| `SSE_S3` |
| `SSE_KMS` |
| `CSE_KMS` |

## Example

```java
import com.amazonaws.useast1.athena.models.EncryptionOption;

EncryptionOption encryptionOption = EncryptionOption.SSE_S3;
```

