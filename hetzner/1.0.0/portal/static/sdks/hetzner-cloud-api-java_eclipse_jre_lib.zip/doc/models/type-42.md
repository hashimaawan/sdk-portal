
# Type 42

Type of Subnetwork

## Enumeration

`Type42`

## Fields

| Name |
|  --- |
| `CLOUD` |
| `SERVER` |
| `VSWITCH` |

## Example

```java
import cloud.hetzner.api.models.Type42;

Type42 type42 = Type42.CLOUD;
```

