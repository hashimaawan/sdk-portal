
# Type Enum

Type of the gif. By default, this is almost always gif

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `GIF` |

## Example

```php
use GiphyAPILib\Models\TypeEnum;

$type = TypeEnum::GIF;
```

