
# Type 13

Describes the kind of image. It may be one of `snapshot` or `backup`. This specifies whether an image is a user-generated Droplet snapshot or automatically created Droplet backup.

## Enumeration

`Type13`

## Fields

| Name |
|  --- |
| `Snapshot` |
| `Backup` |

## Example

```ts
import { Type13 } from 'digitalocean-apilib';

const type13 = Type13.Snapshot;
```

