
# Pages

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`Pages`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `last` | `string \| undefined` | Optional | URI of the last page of the results. |
| `next` | `string \| undefined` | Optional | URI of the next page of the results. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { Pages } from 'digitalocean-apilib';

const pages: Pages = {
  last: 'https://api.digitalocean.com/v2/images?page=2',
  next: 'https://api.digitalocean.com/v2/images?page=2',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

