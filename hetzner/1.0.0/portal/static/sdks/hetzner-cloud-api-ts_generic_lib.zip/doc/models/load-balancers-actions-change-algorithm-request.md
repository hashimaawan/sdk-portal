
# Load Balancers Actions Change Algorithm Request

*This model accepts additional fields of type unknown.*

## Structure

`LoadBalancersActionsChangeAlgorithmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type39`](../../doc/models/type-39.md) | Required | Algorithm of the Load Balancer |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import {
  LoadBalancersActionsChangeAlgorithmRequest,
  Type39,
} from 'hetzner-cloud-apilib';

const loadBalancersActionsChangeAlgorithmRequest: LoadBalancersActionsChangeAlgorithmRequest = {
  type: Type39.RoundRobin,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

