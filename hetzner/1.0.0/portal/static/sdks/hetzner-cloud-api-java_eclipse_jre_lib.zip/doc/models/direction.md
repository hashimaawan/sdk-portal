
# Direction

Select traffic direction on which rule should be applied. Use `source_ips` for direction `in` and `destination_ips` for direction `out`.

## Enumeration

`Direction`

## Fields

| Name |
|  --- |
| `IN` |
| `OUT` |

## Example

```java
import cloud.hetzner.api.models.Direction;

Direction direction = Direction.IN;
```

