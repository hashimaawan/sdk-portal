
# V2 Floating Ips Response

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2FloatingIpsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `floatingIps` | [`FloatingIp1[] \| undefined`](../../doc/models/floating-ip-1.md) | Optional | - |
| `links` | [`Links \| undefined`](../../doc/models/links.md) | Optional | - |
| `meta` | [`Meta`](../../doc/models/meta.md) | Required | - |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2FloatingIpsResponse } from 'digitalocean-apilib';

const v2FloatingIpsResponse: V2FloatingIpsResponse = {
  meta: {
    total: 1,
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  floatingIps: [
    {
      droplet: null,
      ip: '45.55.96.47',
      locked: false,
      projectId: '746c6152-2fa2-11ed-92d3-27aaa54e4988',
      region: {
        available: true,
        features: [
          'private_networking',
          'backups',
          'ipv6',
          'metadata',
          'install_agent',
          'storage',
          'image_transfer'
        ],
        name: 'New York 3',
        sizes: [
          's-1vcpu-1gb',
          's-1vcpu-2gb',
          's-1vcpu-3gb',
          's-2vcpu-2gb',
          's-3vcpu-1gb',
          's-2vcpu-4gb',
          's-4vcpu-8gb',
          's-6vcpu-16gb',
          's-8vcpu-32gb',
          's-12vcpu-48gb',
          's-16vcpu-64gb',
          's-20vcpu-96gb',
          's-24vcpu-128gb',
          's-32vcpu-192g'
        ],
        slug: 'nyc3',
        additionalProperties: {
          'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
        },
      },
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    }
  ],
  links: {
    pages: {
      last: 'last6',
      next: 'next2',
      additionalProperties: {
        'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
      },
    },
    additionalProperties: {
      'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
    },
  },
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

