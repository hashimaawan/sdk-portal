
# X Amz Target 2 Enum

## Enumeration

`XAmzTarget2Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget2Enum;

$xAmzTarget2 = XAmzTarget2Enum::ENUM_AMAZONATHENABATCHGETQUERYEXECUTION;
```

