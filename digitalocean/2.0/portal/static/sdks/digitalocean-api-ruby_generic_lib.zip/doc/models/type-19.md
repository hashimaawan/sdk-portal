
# Type 19

The type of health check to perform.

## Enumeration

`Type19`

## Fields

| Name |
|  --- |
| `PING` |
| `HTTP` |
| `HTTPS` |

## Example

```ruby
type19 = Type19::HTTP
```

