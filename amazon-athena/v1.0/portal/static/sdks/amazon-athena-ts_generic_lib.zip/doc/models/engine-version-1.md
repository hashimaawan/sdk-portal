
# Engine Version 1

## Structure

`EngineVersion1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `selectedEngineVersion` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `effectiveEngineVersion` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |

## Example

```ts
import { EngineVersion1 } from 'amazon-athenalib';

const engineVersion1: EngineVersion1 = {
  selectedEngineVersion: 'SelectedEngineVersion2',
  effectiveEngineVersion: 'EffectiveEngineVersion8',
};
```

