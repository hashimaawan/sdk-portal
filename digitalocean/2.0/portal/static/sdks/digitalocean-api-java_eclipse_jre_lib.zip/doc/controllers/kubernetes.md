# Kubernetes

[DigitalOcean Kubernetes](https://www.digitalocean.com/docs/kubernetes/)
allows you to quickly deploy scalable and secure Kubernetes clusters. By
sending requests to the `/v2/kubernetes/clusters` endpoint, you can list,
create, or delete clusters as well as scale node pools up and down,
recycle individual nodes, and retrieve the kubeconfig file for use with
a cluster.

```java
KubernetesApi kubernetesApi = client.getKubernetesApi();
```

## Class Name

`KubernetesApi`

## Methods

* [Kubernetes List Clusters](../../doc/controllers/kubernetes.md#kubernetes-list-clusters)
* [Kubernetes Create Cluster](../../doc/controllers/kubernetes.md#kubernetes-create-cluster)
* [Kubernetes Delete Cluster](../../doc/controllers/kubernetes.md#kubernetes-delete-cluster)
* [Kubernetes Get Cluster](../../doc/controllers/kubernetes.md#kubernetes-get-cluster)
* [Kubernetes Update Cluster](../../doc/controllers/kubernetes.md#kubernetes-update-cluster)
* [Kubernetes Get Cluster Lint Results](../../doc/controllers/kubernetes.md#kubernetes-get-cluster-lint-results)
* [Kubernetes Run Cluster Lint](../../doc/controllers/kubernetes.md#kubernetes-run-cluster-lint)
* [Kubernetes Get Credentials](../../doc/controllers/kubernetes.md#kubernetes-get-credentials)
* [Kubernetes List Associated Resources](../../doc/controllers/kubernetes.md#kubernetes-list-associated-resources)
* [Kubernetes Destroy Associated Resources Dangerous](../../doc/controllers/kubernetes.md#kubernetes-destroy-associated-resources-dangerous)
* [Kubernetes Destroy Associated Resources Selective](../../doc/controllers/kubernetes.md#kubernetes-destroy-associated-resources-selective)
* [Kubernetes Get Kubeconfig](../../doc/controllers/kubernetes.md#kubernetes-get-kubeconfig)
* [Kubernetes List Node Pools](../../doc/controllers/kubernetes.md#kubernetes-list-node-pools)
* [Kubernetes Add Node Pool](../../doc/controllers/kubernetes.md#kubernetes-add-node-pool)
* [Kubernetes Delete Node Pool](../../doc/controllers/kubernetes.md#kubernetes-delete-node-pool)
* [Kubernetes Get Node Pool](../../doc/controllers/kubernetes.md#kubernetes-get-node-pool)
* [Kubernetes Update Node Pool](../../doc/controllers/kubernetes.md#kubernetes-update-node-pool)
* [Kubernetes Delete Node](../../doc/controllers/kubernetes.md#kubernetes-delete-node)
* [Kubernetes Recycle Node Pool](../../doc/controllers/kubernetes.md#kubernetes-recycle-node-pool)
* [Kubernetes Upgrade Cluster](../../doc/controllers/kubernetes.md#kubernetes-upgrade-cluster)
* [Kubernetes Get Available Upgrades](../../doc/controllers/kubernetes.md#kubernetes-get-available-upgrades)
* [Kubernetes Get Cluster User](../../doc/controllers/kubernetes.md#kubernetes-get-cluster-user)
* [Kubernetes List Options](../../doc/controllers/kubernetes.md#kubernetes-list-options)
* [Kubernetes Remove Registry](../../doc/controllers/kubernetes.md#kubernetes-remove-registry)
* [Kubernetes Add Registry](../../doc/controllers/kubernetes.md#kubernetes-add-registry)


# Kubernetes List Clusters

To list all of the Kubernetes clusters on your account, send a GET request
to `/v2/kubernetes/clusters`.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersResponse>> kubernetesListClustersAsync(
    final Integer perPage,
    final Integer page)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `perPage` | `Integer` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `Integer` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The response will be a JSON object with a key called `kubernetes_clusters`.
This will be set to an array of objects, each of which will contain the
standard Kubernetes cluster attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersResponse`](../../doc/models/v2-kubernetes-clusters-response.md).

## Example Usage

```java
Integer perPage = 2;
Integer page = 1;

kubernetesApi.kubernetesListClustersAsync(perPage, page).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "kubernetes_clusters": [
    {
      "auto_upgrade": false,
      "cluster_subnet": "10.244.0.0/16",
      "created_at": "2018-11-15T16:00:11Z",
      "endpoint": "https://bd5f5959-5e1e-4205-a714-a914373942af.k8s.ondigitalocean.com",
      "ha": false,
      "id": "bd5f5959-5e1e-4205-a714-a914373942af",
      "ipv4": "68.183.121.157",
      "maintenance_policy": {
        "day": "any",
        "duration": "4h0m0s",
        "start_time": "00:00"
      },
      "name": "prod-cluster-01",
      "node_pools": [
        {
          "auto_scale": false,
          "count": 3,
          "id": "cdda885e-7663-40c8-bc74-3a036c66545d",
          "labels": null,
          "max_nodes": 0,
          "min_nodes": 0,
          "name": "frontend-pool",
          "nodes": [
            {
              "created_at": "2018-11-15T16:00:11Z",
              "droplet_id": "205545370",
              "id": "478247f8-b1bb-4f7a-8db9-2a5f8d4b8f8f",
              "name": "adoring-newton-3niq",
              "status": {
                "state": "provisioning"
              },
              "updated_at": "2018-11-15T16:00:11Z"
            },
            {
              "created_at": "2018-11-15T16:00:11Z",
              "droplet_id": "205545371",
              "id": "ad12e744-c2a9-473d-8aa9-be5680500eb1",
              "name": "adoring-newton-3nim",
              "status": {
                "state": "provisioning"
              },
              "updated_at": "2018-11-15T16:00:11Z"
            },
            {
              "created_at": "2018-11-15T16:00:11Z",
              "droplet_id": "205545372",
              "id": "e46e8d07-f58f-4ff1-9737-97246364400e",
              "name": "adoring-newton-3ni7",
              "status": {
                "state": "provisioning"
              },
              "updated_at": "2018-11-15T16:00:11Z"
            }
          ],
          "size": "s-1vcpu-2gb",
          "tags": [
            "production",
            "web-team",
            "k8s",
            "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
            "k8s:worker"
          ],
          "taints": []
        },
        {
          "auto_scale": true,
          "count": 2,
          "id": "f49f4379-7e7f-4af5-aeb6-0354bd840778",
          "labels": {
            "priority": "high",
            "service": "backend"
          },
          "max_nodes": 5,
          "min_nodes": 2,
          "name": "backend-pool",
          "nodes": [
            {
              "created_at": "2018-11-15T16:00:11Z",
              "droplet_id": "205545373",
              "id": "3385619f-8ec3-42ba-bb23-8d21b8ba7518",
              "name": "affectionate-nightingale-3nif",
              "status": {
                "state": "provisioning"
              },
              "updated_at": "2018-11-15T16:00:11Z"
            },
            {
              "created_at": "2018-11-15T16:00:11Z",
              "droplet_id": "205545374",
              "id": "4b8f60ff-ba06-4523-a6a4-b8148244c7e6",
              "name": "affectionate-nightingale-3niy",
              "status": {
                "state": "provisioning"
              },
              "updated_at": "2018-11-15T16:00:11Z"
            }
          ],
          "size": "g-4vcpu-16gb",
          "tags": [
            "production",
            "web-team",
            "k8s",
            "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
            "k8s:worker"
          ],
          "taints": []
        }
      ],
      "region": "nyc1",
      "registry_enabled": false,
      "service_subnet": "10.245.0.0/16",
      "status": {
        "message": "provisioning",
        "state": "provisioning"
      },
      "surge_upgrade": false,
      "tags": [
        "production",
        "web-team",
        "k8s",
        "k8s:bd5f5959-5e1e-4205-a714-a914373942af"
      ],
      "updated_at": "2018-11-15T16:00:11Z",
      "version": "1.18.6-do.0",
      "vpc_uuid": "c33931f2-a26a-4e61-b85c-4e95a2ec431b"
    }
  ],
  "meta": {
    "total": 1
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Create Cluster

To create a new Kubernetes cluster, send a POST request to
`/v2/kubernetes/clusters`. The request must contain at least one node pool
with at least one worker.

The request may contain a maintenance window policy describing a time period
when disruptive maintenance tasks may be carried out. Omitting the policy
implies that a window will be chosen automatically. See
[here](https://www.digitalocean.com/docs/kubernetes/how-to/upgrade-cluster/)
for details.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersResponse1>> kubernetesCreateClusterAsync(
    final KubernetesCluster body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`KubernetesCluster`](../../doc/models/kubernetes-cluster.md) | Body, Required | - |

## Response Type

**201**: The response will be a JSON object with a key called `kubernetes_cluster`. The
value of this will be an object containing the standard attributes of a
Kubernetes cluster.

The IP address and cluster API server endpoint will not be available until the
cluster has finished provisioning. The initial value of the cluster's
`status.state` attribute will be `provisioning`. When the cluster is ready,
this will transition to `running`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersResponse1`](../../doc/models/v2-kubernetes-clusters-response-1.md).

## Example Usage

```java
KubernetesCluster body = new KubernetesCluster.Builder(
    "prod-cluster-01",
    Arrays.asList(
        new NodePool.Builder(
            "s-1vcpu-2gb",
            3,
            "worker-pool"
        )
        .build()
    ),
    "nyc1",
    "1.18.6-do.0"
)
.build();

kubernetesApi.kubernetesCreateClusterAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "kubernetes_cluster": {
    "auto_upgrade": false,
    "cluster_subnet": "10.244.0.0/16",
    "created_at": "2018-11-15T16:00:11Z",
    "endpoint": "",
    "ha": false,
    "id": "bd5f5959-5e1e-4205-a714-a914373942af",
    "ipv4": "",
    "maintenance_policy": {
      "day": "any",
      "duration": "4h0m0s",
      "start_time": "00:00"
    },
    "name": "prod-cluster-01",
    "node_pools": [
      {
        "auto_scale": false,
        "count": 3,
        "id": "cdda885e-7663-40c8-bc74-3a036c66545d",
        "labels": null,
        "max_nodes": 0,
        "min_nodes": 0,
        "name": "worker-pool",
        "nodes": [
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "",
            "id": "478247f8-b1bb-4f7a-8db9-2a5f8d4b8f8f",
            "name": "",
            "status": {
              "state": "provisioning"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          },
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "",
            "id": "ad12e744-c2a9-473d-8aa9-be5680500eb1",
            "name": "",
            "status": {
              "state": "provisioning"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          },
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "",
            "id": "e46e8d07-f58f-4ff1-9737-97246364400e",
            "name": "",
            "status": {
              "state": "provisioning"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          }
        ],
        "size": "s-1vcpu-2gb",
        "tags": [
          "k8s",
          "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
          "k8s:worker"
        ],
        "taints": []
      }
    ],
    "region": "nyc1",
    "registry_enabled": false,
    "service_subnet": "10.245.0.0/16",
    "status": {
      "message": "provisioning",
      "state": "provisioning"
    },
    "surge_upgrade": false,
    "tags": [
      "k8s",
      "k8s:bd5f5959-5e1e-4205-a714-a914373942af"
    ],
    "updated_at": "2018-11-15T16:00:11Z",
    "version": "1.18.6-do.0",
    "vpc_uuid": "c33931f2-a26a-4e61-b85c-4e95a2ec431b"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Delete Cluster

To delete a Kubernetes cluster and all services deployed to it, send a DELETE
request to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID`.

A 204 status code with no body will be returned in response to a successful
request.

```java
CompletableFuture<ApiResponse<Void>> kubernetesDeleteClusterAsync(
    final UUID clusterId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");

kubernetesApi.kubernetesDeleteClusterAsync(clusterId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Get Cluster

To show information about an existing Kubernetes cluster, send a GET request
to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID`.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersResponse1>> kubernetesGetClusterAsync(
    final UUID clusterId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |

## Response Type

**200**: The response will be a JSON object with a key called `kubernetes_cluster`. The
value of this will be an object containing the standard attributes of a
Kubernetes cluster.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersResponse1`](../../doc/models/v2-kubernetes-clusters-response-1.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");

kubernetesApi.kubernetesGetClusterAsync(clusterId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "kubernetes_cluster": {
    "auto_upgrade": false,
    "cluster_subnet": "10.244.0.0/16",
    "created_at": "2018-11-15T16:00:11Z",
    "endpoint": "https://bd5f5959-5e1e-4205-a714-a914373942af.k8s.ondigitalocean.com",
    "ha": false,
    "id": "bd5f5959-5e1e-4205-a714-a914373942af",
    "ipv4": "68.183.121.157",
    "maintenance_policy": {
      "day": "any",
      "duration": "4h0m0s",
      "start_time": "00:00"
    },
    "name": "prod-cluster-01",
    "node_pools": [
      {
        "auto_scale": false,
        "count": 3,
        "id": "cdda885e-7663-40c8-bc74-3a036c66545d",
        "labels": null,
        "max_nodes": 0,
        "min_nodes": 0,
        "name": "frontend-pool",
        "nodes": [
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545370",
            "id": "478247f8-b1bb-4f7a-8db9-2a5f8d4b8f8f",
            "name": "adoring-newton-3niq",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          },
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545371",
            "id": "ad12e744-c2a9-473d-8aa9-be5680500eb1",
            "name": "adoring-newton-3nim",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          },
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545372",
            "id": "e46e8d07-f58f-4ff1-9737-97246364400e",
            "name": "adoring-newton-3ni7",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          }
        ],
        "size": "s-1vcpu-2gb",
        "tags": [
          "production",
          "web-team",
          "k8s",
          "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
          "k8s:worker"
        ],
        "taints": []
      },
      {
        "auto_scale": true,
        "count": 2,
        "id": "f49f4379-7e7f-4af5-aeb6-0354bd840778",
        "labels": {
          "priority": "high",
          "service": "backend"
        },
        "max_nodes": 5,
        "min_nodes": 2,
        "name": "backend-pool",
        "nodes": [
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545373",
            "id": "3385619f-8ec3-42ba-bb23-8d21b8ba7518",
            "name": "affectionate-nightingale-3nif",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          },
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545374",
            "id": "4b8f60ff-ba06-4523-a6a4-b8148244c7e6",
            "name": "affectionate-nightingale-3niy",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          }
        ],
        "size": "g-4vcpu-16gb",
        "tags": [
          "production",
          "web-team",
          "k8s",
          "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
          "k8s:worker"
        ],
        "taints": []
      }
    ],
    "region": "nyc1",
    "registry_enabled": false,
    "service_subnet": "10.245.0.0/16",
    "status": {
      "state": "running"
    },
    "surge_upgrade": false,
    "tags": [
      "production",
      "web-team",
      "k8s",
      "k8s:bd5f5959-5e1e-4205-a714-a914373942af"
    ],
    "updated_at": "2018-11-15T16:00:11Z",
    "version": "1.18.6-do.0",
    "vpc_uuid": "c33931f2-a26a-4e61-b85c-4e95a2ec431b"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Update Cluster

To update a Kubernetes cluster, send a PUT request to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID` and specify one or more of the
attributes below.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersResponse1>> kubernetesUpdateClusterAsync(
    final UUID clusterId,
    final V2KubernetesClustersRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `body` | [`V2KubernetesClustersRequest`](../../doc/models/v2-kubernetes-clusters-request.md) | Body, Required | - |

## Response Type

**202**: The response will be a JSON object with a key called `kubernetes_cluster`. The
value of this will be an object containing the standard attributes of a
Kubernetes cluster.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersResponse1`](../../doc/models/v2-kubernetes-clusters-response-1.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
V2KubernetesClustersRequest body = new V2KubernetesClustersRequest.Builder(
    "prod-cluster-01"
)
.autoUpgrade(true)
.ha(true)
.surgeUpgrade(true)
.tags(Arrays.asList(
        "k8s",
        "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
        "production",
        "web-team"
    ))
.build();

kubernetesApi.kubernetesUpdateClusterAsync(clusterId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "kubernetes_cluster": {
    "auto_upgrade": true,
    "cluster_subnet": "10.244.0.0/16",
    "created_at": "2018-11-15T16:00:11Z",
    "endpoint": "https://bd5f5959-5e1e-4205-a714-a914373942af.k8s.ondigitalocean.com",
    "ha": false,
    "id": "bd5f5959-5e1e-4205-a714-a914373942af",
    "ipv4": "68.183.121.157",
    "maintenance_policy": {
      "day": "any",
      "duration": "4h0m0s",
      "start_time": "00:00"
    },
    "name": "prod-cluster-01",
    "node_pools": [
      {
        "auto_scale": false,
        "count": 3,
        "id": "cdda885e-7663-40c8-bc74-3a036c66545d",
        "labels": null,
        "max_nodes": 0,
        "min_nodes": 0,
        "name": "frontend-pool",
        "nodes": [
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545370",
            "id": "478247f8-b1bb-4f7a-8db9-2a5f8d4b8f8f",
            "name": "adoring-newton-3niq",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          },
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545371",
            "id": "ad12e744-c2a9-473d-8aa9-be5680500eb1",
            "name": "adoring-newton-3nim",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          },
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545372",
            "id": "e46e8d07-f58f-4ff1-9737-97246364400e",
            "name": "adoring-newton-3ni7",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          }
        ],
        "size": "s-1vcpu-2gb",
        "tags": [
          "production",
          "web-team",
          "k8s",
          "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
          "k8s:worker"
        ],
        "taints": []
      },
      {
        "auto_scale": true,
        "count": 2,
        "id": "f49f4379-7e7f-4af5-aeb6-0354bd840778",
        "labels": {
          "priority": "high",
          "service": "backend"
        },
        "max_nodes": 5,
        "min_nodes": 2,
        "name": "backend-pool",
        "nodes": [
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545373",
            "id": "3385619f-8ec3-42ba-bb23-8d21b8ba7518",
            "name": "affectionate-nightingale-3nif",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          },
          {
            "created_at": "2018-11-15T16:00:11Z",
            "droplet_id": "205545374",
            "id": "4b8f60ff-ba06-4523-a6a4-b8148244c7e6",
            "name": "affectionate-nightingale-3niy",
            "status": {
              "state": "running"
            },
            "updated_at": "2018-11-15T16:00:11Z"
          }
        ],
        "size": "g-4vcpu-16gb",
        "tags": [
          "production",
          "web-team",
          "k8s",
          "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
          "k8s:worker"
        ],
        "taints": []
      }
    ],
    "region": "nyc1",
    "registry_enabled": false,
    "service_subnet": "10.245.0.0/16",
    "status": {
      "state": "running"
    },
    "surge_upgrade": true,
    "tags": [
      "production",
      "web-team",
      "k8s",
      "k8s:bd5f5959-5e1e-4205-a714-a914373942af"
    ],
    "updated_at": "2018-11-15T16:00:11Z",
    "version": "1.18.6-do.0",
    "vpc_uuid": "c33931f2-a26a-4e61-b85c-4e95a2ec431b"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Get Cluster Lint Results

To request clusterlint diagnostics for your cluster, send a GET request to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/clusterlint`. If the `run_id` query
parameter is provided, then the diagnostics for the specific run is fetched.
By default, the latest results are shown.

To find out how to address clusterlint feedback, please refer to
[the clusterlint check documentation](https://github.com/digitalocean/clusterlint/blob/master/checks.md).

```java
CompletableFuture<ApiResponse<V2KubernetesClustersClusterlintResponse>> kubernetesGetClusterLintResultsAsync(
    final UUID clusterId,
    final UUID runId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `runId` | `UUID` | Query, Optional | Specifies the clusterlint run whose results will be retrieved. |

## Response Type

**200**: The response is a JSON object which contains the diagnostics on Kubernetes
objects in the cluster. Each diagnostic will contain some metadata information
about the object and feedback for users to act upon.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersClusterlintResponse`](../../doc/models/v2-kubernetes-clusters-clusterlint-response.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
UUID runId = UUID.fromString("50c2f44c-011d-493e-aee5-361a4a0d1844");

kubernetesApi.kubernetesGetClusterLintResultsAsync(clusterId, runId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Run Cluster Lint

Clusterlint helps operators conform to Kubernetes best practices around
resources, security and reliability to avoid common problems while operating
or upgrading the clusters.

To request a clusterlint run on your cluster, send a POST request to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/clusterlint`. This will run all
checks present in the `doks` group by default, if a request body is not
specified. Optionally specify the below attributes.

For information about the available checks, please refer to
[the clusterlint check documentation](https://github.com/digitalocean/clusterlint/blob/master/checks.md).

```java
CompletableFuture<ApiResponse<V2KubernetesClustersClusterlintResponse1>> kubernetesRunClusterLintAsync(
    final UUID clusterId,
    final V2KubernetesClustersClusterlintRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `body` | [`V2KubernetesClustersClusterlintRequest`](../../doc/models/v2-kubernetes-clusters-clusterlint-request.md) | Body, Optional | - |

## Response Type

**202**: The response is a JSON object with a key called `run_id` that you can later use to fetch the run results.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersClusterlintResponse1`](../../doc/models/v2-kubernetes-clusters-clusterlint-response-1.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
V2KubernetesClustersClusterlintRequest body = new V2KubernetesClustersClusterlintRequest.Builder()
    .excludeChecks(Arrays.asList(
        "default-namespace"
    ))
    .excludeGroups(Arrays.asList(
        "workload-health"
    ))
    .includeChecks(Arrays.asList(
        "bare-pods",
        "resource-requirements"
    ))
    .includeGroups(Arrays.asList(
        "basic",
        "doks",
        "security"
    ))
    .build();

kubernetesApi.kubernetesRunClusterLintAsync(clusterId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Get Credentials

This endpoint returns a JSON object . It can be used to programmatically
construct Kubernetes clients which cannot parse kubeconfig files.

The resulting JSON object contains token-based authentication for clusters
supporting it, and certificate-based authentication otherwise. For a list of
supported versions and more information, see "[How to Connect to a DigitalOcean
Kubernetes Cluster with kubectl](https://www.digitalocean.com/docs/kubernetes/how-to/connect-with-kubectl/)".

To retrieve credentials for accessing a Kubernetes cluster, send a GET
request to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/credentials`.

Clusters supporting token-based authentication may define an expiration by
passing a duration in seconds as a query parameter to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/kubeconfig?expiry_seconds=$DURATION_IN_SECONDS`.
If not set or 0, then the token will have a 7 day expiry. The query parameter
has no impact in certificate-based authentication.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersCredentialsResponse>> kubernetesGetCredentialsAsync(
    final UUID clusterId,
    final Integer expirySeconds)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `expirySeconds` | `Integer` | Query, Optional | The duration in seconds that the returned Kubernetes credentials will be valid. If not set or 0, the credentials will have a 7 day expiry.<br><br>**Default**: `0`<br><br>**Constraints**: `>= 0` |

## Response Type

**200**: A JSON object containing credentials for a cluster.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersCredentialsResponse`](../../doc/models/v2-kubernetes-clusters-credentials-response.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
Integer expirySeconds = 300;

kubernetesApi.kubernetesGetCredentialsAsync(clusterId, expirySeconds).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes List Associated Resources

To list the associated billable resources that can be destroyed along with a cluster, send a GET request to the `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/destroy_with_associated_resources` endpoint.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersDestroyWithAssociatedResourcesResponse>> kubernetesListAssociatedResourcesAsync(
    final UUID clusterId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |

## Response Type

**200**: The response will be a JSON object containing `load_balancers`, `volumes`, and `volume_snapshots` keys. Each will be set to an array of objects containing the standard attributes for associated resources.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersDestroyWithAssociatedResourcesResponse`](../../doc/models/v2-kubernetes-clusters-destroy-with-associated-resources-response.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");

kubernetesApi.kubernetesListAssociatedResourcesAsync(clusterId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Destroy Associated Resources Dangerous

To delete a Kubernetes cluster with all of its associated resources, send a
DELETE request to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/destroy_with_associated_resources/dangerous`.
A 204 status code with no body will be returned in response to a successful request.

```java
CompletableFuture<ApiResponse<Void>> kubernetesDestroyAssociatedResourcesDangerousAsync(
    final UUID clusterId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");

kubernetesApi.kubernetesDestroyAssociatedResourcesDangerousAsync(clusterId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Destroy Associated Resources Selective

To delete a Kubernetes cluster along with a subset of its associated resources,
send a DELETE request to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/destroy_with_associated_resources/selective`.

The JSON body of the request should include `load_balancers`, `volumes`, or
`volume_snapshots` keys each set to an array of IDs for the associated
resources to be destroyed.

The IDs can be found by querying the cluster's associated resources endpoint.
Any associated resource not included in the request will remain and continue
to accrue changes on your account.

```java
CompletableFuture<ApiResponse<Void>> kubernetesDestroyAssociatedResourcesSelectiveAsync(
    final UUID clusterId,
    final V2KubernetesClustersDestroyWithAssociatedResourcesSelectiveRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `body` | [`V2KubernetesClustersDestroyWithAssociatedResourcesSelectiveRequest`](../../doc/models/v2-kubernetes-clusters-destroy-with-associated-resources-selective-request.md) | Body, Required | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
V2KubernetesClustersDestroyWithAssociatedResourcesSelectiveRequest body = new V2KubernetesClustersDestroyWithAssociatedResourcesSelectiveRequest.Builder()
    .loadBalancers(Arrays.asList(
        "4de7ac8b-495b-4884-9a69-1050c6793cd6"
    ))
    .volumeSnapshots(Arrays.asList(
        "edb0478d-7436-11ea-86e6-0a58ac144b91"
    ))
    .volumes(Arrays.asList(
        "ba49449a-7435-11ea-b89e-0a58ac14480f"
    ))
    .build();

kubernetesApi.kubernetesDestroyAssociatedResourcesSelectiveAsync(clusterId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Get Kubeconfig

This endpoint returns a kubeconfig file in YAML format. It can be used to
connect to and administer the cluster using the Kubernetes command line tool,
`kubectl`, or other programs supporting kubeconfig files (e.g., client libraries).

The resulting kubeconfig file uses token-based authentication for clusters
supporting it, and certificate-based authentication otherwise. For a list of
supported versions and more information, see "[How to Connect to a DigitalOcean
Kubernetes Cluster with kubectl](https://www.digitalocean.com/docs/kubernetes/how-to/connect-with-kubectl/)".

To retrieve a kubeconfig file for use with a Kubernetes cluster, send a GET
request to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/kubeconfig`.

Clusters supporting token-based authentication may define an expiration by
passing a duration in seconds as a query parameter to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/kubeconfig?expiry_seconds=$DURATION_IN_SECONDS`.
If not set or 0, then the token will have a 7 day expiry. The query parameter
has no impact in certificate-based authentication.

```java
CompletableFuture<ApiResponse<DynamicResponse>> kubernetesGetKubeconfigAsync(
    final UUID clusterId,
    final Integer expirySeconds)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `expirySeconds` | `Integer` | Query, Optional | The duration in seconds that the returned Kubernetes credentials will be valid. If not set or 0, the credentials will have a 7 day expiry.<br><br>**Default**: `0`<br><br>**Constraints**: `>= 0` |

## Response Type

**200**: A kubeconfig file for the cluster in YAML format.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type `DynamicResponse`.

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
Integer expirySeconds = 300;

kubernetesApi.kubernetesGetKubeconfigAsync(clusterId, expirySeconds).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes List Node Pools

To list all of the node pools in a Kubernetes clusters, send a GET request to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/node_pools`.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersNodePoolsResponse>> kubernetesListNodePoolsAsync(
    final UUID clusterId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |

## Response Type

**200**: The response will be a JSON object with a key called `node_pools`. This will
be set to an array of objects, each of which will contain the standard node
pool attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersNodePoolsResponse`](../../doc/models/v2-kubernetes-clusters-node-pools-response.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");

kubernetesApi.kubernetesListNodePoolsAsync(clusterId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "node_pools": [
    {
      "auto_scale": false,
      "count": 3,
      "id": "cdda885e-7663-40c8-bc74-3a036c66545d",
      "labels": null,
      "max_nodes": 0,
      "min_nodes": 0,
      "name": "frontend-pool",
      "nodes": [
        {
          "created_at": "2018-11-15T16:00:11Z",
          "droplet_id": "205545370",
          "id": "478247f8-b1bb-4f7a-8db9-2a5f8d4b8f8f",
          "name": "adoring-newton-3niq",
          "status": {
            "state": "running"
          },
          "updated_at": "2018-11-15T16:00:11Z"
        },
        {
          "created_at": "2018-11-15T16:00:11Z",
          "droplet_id": "205545371",
          "id": "ad12e744-c2a9-473d-8aa9-be5680500eb1",
          "name": "adoring-newton-3nim",
          "status": {
            "state": "running"
          },
          "updated_at": "2018-11-15T16:00:11Z"
        },
        {
          "created_at": "2018-11-15T16:00:11Z",
          "droplet_id": "205545372",
          "id": "e46e8d07-f58f-4ff1-9737-97246364400e",
          "name": "adoring-newton-3ni7",
          "status": {
            "state": "running"
          },
          "updated_at": "2018-11-15T16:00:11Z"
        }
      ],
      "size": "s-1vcpu-2gb",
      "tags": [
        "production",
        "web-team",
        "k8s",
        "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
        "k8s:worker"
      ]
    },
    {
      "auto_scale": true,
      "count": 2,
      "id": "f49f4379-7e7f-4af5-aeb6-0354bd840778",
      "labels": {
        "priority": "high",
        "service": "backend"
      },
      "max_nodes": 5,
      "min_nodes": 2,
      "name": "backend-pool",
      "nodes": [
        {
          "created_at": "2018-11-15T16:00:11Z",
          "droplet_id": "205545373",
          "id": "3385619f-8ec3-42ba-bb23-8d21b8ba7518",
          "name": "affectionate-nightingale-3nif",
          "status": {
            "state": "running"
          },
          "updated_at": "2018-11-15T16:00:11Z"
        },
        {
          "created_at": "2018-11-15T16:00:11Z",
          "droplet_id": "205545374",
          "id": "4b8f60ff-ba06-4523-a6a4-b8148244c7e6",
          "name": "affectionate-nightingale-3niy",
          "status": {
            "state": "running"
          },
          "updated_at": "2018-11-15T16:00:11Z"
        }
      ],
      "size": "g-4vcpu-16gb",
      "tags": [
        "production",
        "web-team",
        "k8s",
        "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
        "k8s:worker"
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Add Node Pool

To add an additional node pool to a Kubernetes clusters, send a POST request
to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/node_pools` with the following
attributes.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersNodePoolsResponse1>> kubernetesAddNodePoolAsync(
    final UUID clusterId,
    final NodePool body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `body` | [`NodePool`](../../doc/models/node-pool.md) | Body, Required | - |

## Response Type

**201**: The response will be a JSON object with a key called `node_pool`. The value of
this will be an object containing the standard attributes of a node pool.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersNodePoolsResponse1`](../../doc/models/v2-kubernetes-clusters-node-pools-response-1.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
NodePool body = new NodePool.Builder(
    "s-1vcpu-2gb",
    3,
    "new-pool"
)
.autoScale(true)
.maxNodes(6)
.minNodes(3)
.tags(Arrays.asList(
        "frontend"
    ))
.build();

kubernetesApi.kubernetesAddNodePoolAsync(clusterId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Delete Node Pool

To delete a node pool, send a DELETE request to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/node_pools/$NODE_POOL_ID`.

A 204 status code with no body will be returned in response to a successful
request. Nodes in the pool will subsequently be drained and deleted.

```java
CompletableFuture<ApiResponse<Void>> kubernetesDeleteNodePoolAsync(
    final UUID clusterId,
    final UUID nodePoolId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `nodePoolId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes node pool. |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
UUID nodePoolId = UUID.fromString("cdda885e-7663-40c8-bc74-3a036c66545d");

kubernetesApi.kubernetesDeleteNodePoolAsync(clusterId, nodePoolId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Get Node Pool

To show information about a specific node pool in a Kubernetes cluster, send
a GET request to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/node_pools/$NODE_POOL_ID`.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersNodePoolsResponse1>> kubernetesGetNodePoolAsync(
    final UUID clusterId,
    final UUID nodePoolId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `nodePoolId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes node pool. |

## Response Type

**200**: The response will be a JSON object with a key called `node_pool`. The value
of this will be an object containing the standard attributes of a node pool.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersNodePoolsResponse1`](../../doc/models/v2-kubernetes-clusters-node-pools-response-1.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
UUID nodePoolId = UUID.fromString("cdda885e-7663-40c8-bc74-3a036c66545d");

kubernetesApi.kubernetesGetNodePoolAsync(clusterId, nodePoolId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Update Node Pool

To update the name of a node pool, edit the tags applied to it, or adjust its
number of nodes, send a PUT request to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/node_pools/$NODE_POOL_ID` with the
following attributes.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersNodePoolsResponse1>> kubernetesUpdateNodePoolAsync(
    final UUID clusterId,
    final UUID nodePoolId,
    final V2KubernetesClustersNodePoolsRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `nodePoolId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes node pool. |
| `body` | [`V2KubernetesClustersNodePoolsRequest`](../../doc/models/v2-kubernetes-clusters-node-pools-request.md) | Body, Required | - |

## Response Type

**202**: The response will be a JSON object with a key called `node_pool`. The value of
this will be an object containing the standard attributes of a node pool.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersNodePoolsResponse1`](../../doc/models/v2-kubernetes-clusters-node-pools-response-1.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
UUID nodePoolId = UUID.fromString("cdda885e-7663-40c8-bc74-3a036c66545d");
V2KubernetesClustersNodePoolsRequest body = new V2KubernetesClustersNodePoolsRequest.Builder()
    .autoScale(true)
    .count(3)
    .maxNodes(6)
    .minNodes(3)
    .name("frontend-pool")
    .tags(Arrays.asList(
        "k8s",
        "k8s:bd5f5959-5e1e-4205-a714-a914373942af",
        "k8s-worker",
        "production",
        "web-team"
    ))
    .build();

kubernetesApi.kubernetesUpdateNodePoolAsync(clusterId, nodePoolId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Delete Node

To delete a single node in a pool, send a DELETE request to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/node_pools/$NODE_POOL_ID/nodes/$NODE_ID`.

Appending the `skip_drain=1` query parameter to the request causes node
draining to be skipped. Omitting the query parameter or setting its value to
`0` carries out draining prior to deletion.

Appending the `replace=1` query parameter to the request causes the node to
be replaced by a new one after deletion. Omitting the query parameter or
setting its value to `0` deletes without replacement.

```java
CompletableFuture<ApiResponse<Void>> kubernetesDeleteNodeAsync(
    final UUID clusterId,
    final UUID nodePoolId,
    final UUID nodeId,
    final Integer skipDrain,
    final Integer replace)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `nodePoolId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes node pool. |
| `nodeId` | `UUID` | Template, Required | A unique ID that can be used to reference a node in a Kubernetes node pool. |
| `skipDrain` | `Integer` | Query, Optional | Specifies whether or not to drain workloads from a node before it is deleted. Setting it to `1` causes node draining to be skipped. Omitting the query parameter or setting its value to `0` carries out draining prior to deletion.<br><br>**Default**: `0`<br><br>**Constraints**: `>= 0`, `<= 1` |
| `replace` | `Integer` | Query, Optional | Specifies whether or not to replace a node after it has been deleted. Setting it to `1` causes the node to be replaced by a new one after deletion. Omitting the query parameter or setting its value to `0` deletes without replacement.<br><br>**Default**: `0`<br><br>**Constraints**: `>= 0`, `<= 1` |

## Response Type

**202**: The does not indicate the success or failure of any operation, just that the request has been accepted for processing.

`void`

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
UUID nodePoolId = UUID.fromString("cdda885e-7663-40c8-bc74-3a036c66545d");
UUID nodeId = UUID.fromString("478247f8-b1bb-4f7a-8db9-2a5f8d4b8f8f");
Integer skipDrain = 1;
Integer replace = 1;

kubernetesApi.kubernetesDeleteNodeAsync(clusterId, nodePoolId, nodeId, skipDrain, replace).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Recycle Node Pool

**This endpoint is deprecated.**

The endpoint has been deprecated. Please use the DELETE
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/node_pools/$NODE_POOL_ID/nodes/$NODE_ID`
method instead.

```java
CompletableFuture<ApiResponse<Void>> kubernetesRecycleNodePoolAsync(
    final UUID clusterId,
    final UUID nodePoolId,
    final V2KubernetesClustersNodePoolsRecycleRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `nodePoolId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes node pool. |
| `body` | [`V2KubernetesClustersNodePoolsRecycleRequest`](../../doc/models/v2-kubernetes-clusters-node-pools-recycle-request.md) | Body, Required | - |

## Response Type

**202**: The does not indicate the success or failure of any operation, just that the request has been accepted for processing.

`void`

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
UUID nodePoolId = UUID.fromString("cdda885e-7663-40c8-bc74-3a036c66545d");
V2KubernetesClustersNodePoolsRecycleRequest body = new V2KubernetesClustersNodePoolsRecycleRequest.Builder()
    .nodes(Arrays.asList(
        "d8db5e1a-6103-43b5-a7b3-8a948210a9fc"
    ))
    .build();

kubernetesApi.kubernetesRecycleNodePoolAsync(clusterId, nodePoolId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Upgrade Cluster

To immediately upgrade a Kubernetes cluster to a newer patch release of
Kubernetes, send a POST request to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/upgrade`.
The body of the request must specify a version attribute.

Available upgrade versions for a cluster can be fetched from
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/upgrades`.

```java
CompletableFuture<ApiResponse<Void>> kubernetesUpgradeClusterAsync(
    final UUID clusterId,
    final V2KubernetesClustersUpgradeRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |
| `body` | [`V2KubernetesClustersUpgradeRequest`](../../doc/models/v2-kubernetes-clusters-upgrade-request.md) | Body, Required | - |

## Response Type

**202**: The does not indicate the success or failure of any operation, just that the request has been accepted for processing.

`void`

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");
V2KubernetesClustersUpgradeRequest body = new V2KubernetesClustersUpgradeRequest.Builder()
    .version("1.16.13-do.0")
    .build();

kubernetesApi.kubernetesUpgradeClusterAsync(clusterId, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Get Available Upgrades

To determine whether a cluster can be upgraded, and the versions to which it
can be upgraded, send a GET request to
`/v2/kubernetes/clusters/$K8S_CLUSTER_ID/upgrades`.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersUpgradesResponse>> kubernetesGetAvailableUpgradesAsync(
    final UUID clusterId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |

## Response Type

**200**: The response will be a JSON object with a key called
`available_upgrade_versions`. The value of this will be an array of objects,
representing the upgrade versions currently available for this cluster.

If the cluster is up-to-date (i.e. there are no upgrades currently available)
`available_upgrade_versions` will be `null`.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersUpgradesResponse`](../../doc/models/v2-kubernetes-clusters-upgrades-response.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");

kubernetesApi.kubernetesGetAvailableUpgradesAsync(clusterId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Get Cluster User

To show information the user associated with a Kubernetes cluster, send a GET
request to `/v2/kubernetes/clusters/$K8S_CLUSTER_ID/user`.

```java
CompletableFuture<ApiResponse<V2KubernetesClustersUserResponse>> kubernetesGetClusterUserAsync(
    final UUID clusterId)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `clusterId` | `UUID` | Template, Required | A unique ID that can be used to reference a Kubernetes cluster. |

## Response Type

**200**: The response will be a JSON object with a key called `kubernetes_cluster_user`
containing the username and in-cluster groups that it belongs to.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesClustersUserResponse`](../../doc/models/v2-kubernetes-clusters-user-response.md).

## Example Usage

```java
UUID clusterId = UUID.fromString("bd5f5959-5e1e-4205-a714-a914373942af");

kubernetesApi.kubernetesGetClusterUserAsync(clusterId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes List Options

To list the versions of Kubernetes available for use, the regions that support Kubernetes, and the available node sizes, send a GET request to `/v2/kubernetes/options`.

```java
CompletableFuture<ApiResponse<V2KubernetesOptionsResponse>> kubernetesListOptionsAsync()
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Response Type

**200**: The response will be a JSON object with a key called `options` which contains
`regions`, `versions`, and `sizes` objects listing the available options and
the matching slugs for use when creating a new cluster.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`V2KubernetesOptionsResponse`](../../doc/models/v2-kubernetes-options-response.md).

## Example Usage

```java
kubernetesApi.kubernetesListOptionsAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "options": {
    "regions": [
      {
        "name": "New York 1",
        "slug": "nyc1"
      },
      {
        "name": "Singapore 1",
        "slug": "sgp1"
      },
      {
        "name": "London 1",
        "slug": "lon1"
      },
      {
        "name": "New York 3",
        "slug": "nyc3"
      },
      {
        "name": "Amsterdam 3",
        "slug": "ams3"
      },
      {
        "name": "Frankfurt 1",
        "slug": "fra1"
      },
      {
        "name": "Toronto 1",
        "slug": "tor1"
      },
      {
        "name": "San Francisco 2",
        "slug": "sfo2"
      },
      {
        "name": "Bangalore 1",
        "slug": "blr1"
      },
      {
        "name": "San Francisco 3",
        "slug": "sfo3"
      }
    ],
    "sizes": [
      {
        "name": "s-1vcpu-2gb",
        "slug": "s-1vcpu-2gb"
      },
      {
        "name": "s-2vcpu-2gb",
        "slug": "s-2vcpu-2gb"
      },
      {
        "name": "s-1vcpu-3gb",
        "slug": "s-1vcpu-3gb"
      },
      {
        "name": "s-2vcpu-4gb",
        "slug": "s-2vcpu-4gb"
      },
      {
        "name": "s-4vcpu-8gb",
        "slug": "s-4vcpu-8gb"
      },
      {
        "name": "c-2-4GiB",
        "slug": "c-2"
      },
      {
        "name": "g-2vcpu-8gb",
        "slug": "g-2vcpu-8gb"
      },
      {
        "name": "gd-2vcpu-8gb",
        "slug": "gd-2vcpu-8gb"
      },
      {
        "name": "s-8vcpu-16gb",
        "slug": "s-8vcpu-16gb"
      },
      {
        "name": "s-6vcpu-16gb",
        "slug": "s-6vcpu-16gb"
      },
      {
        "name": "c-4-8GiB",
        "slug": "c-4"
      },
      {
        "name": "m-2vcpu-16gb",
        "slug": "m-2vcpu-16gb"
      },
      {
        "name": "m3-2vcpu-16gb",
        "slug": "m3-2vcpu-16gb"
      },
      {
        "name": "g-4vcpu-16gb",
        "slug": "g-4vcpu-16gb"
      },
      {
        "name": "gd-4vcpu-16gb",
        "slug": "gd-4vcpu-16gb"
      },
      {
        "name": "m6-2vcpu-16gb",
        "slug": "m6-2vcpu-16gb"
      },
      {
        "name": "s-8vcpu-32gb",
        "slug": "s-8vcpu-32gb"
      },
      {
        "name": "c-8-16GiB",
        "slug": "c-8"
      },
      {
        "name": "m-4vcpu-32gb",
        "slug": "m-4vcpu-32gb"
      },
      {
        "name": "m3-4vcpu-32gb",
        "slug": "m3-4vcpu-32gb"
      },
      {
        "name": "g-8vcpu-32gb",
        "slug": "g-8vcpu-32gb"
      },
      {
        "name": "s-12vcpu-48gb",
        "slug": "s-12vcpu-48gb"
      },
      {
        "name": "gd-8vcpu-32gb",
        "slug": "gd-8vcpu-32gb"
      },
      {
        "name": "m6-4vcpu-32gb",
        "slug": "m6-4vcpu-32gb"
      },
      {
        "name": "s-16vcpu-64gb",
        "slug": "s-16vcpu-64gb"
      },
      {
        "name": "c-16",
        "slug": "c-16"
      },
      {
        "name": "m-8vcpu-64gb",
        "slug": "m-8vcpu-64gb"
      },
      {
        "name": "m3-8vcpu-64gb",
        "slug": "m3-8vcpu-64gb"
      },
      {
        "name": "g-16vcpu-64gb",
        "slug": "g-16vcpu-64gb"
      },
      {
        "name": "s-20vcpu-96gb",
        "slug": "s-20vcpu-96gb"
      },
      {
        "name": "gd-16vcpu-64gb",
        "slug": "gd-16vcpu-64gb"
      },
      {
        "name": "m6-8vcpu-64gb",
        "slug": "m6-8vcpu-64gb"
      },
      {
        "name": "s-24vcpu-128gb",
        "slug": "s-24vcpu-128gb"
      },
      {
        "name": "c-32-64GiB",
        "slug": "c-32"
      },
      {
        "name": "m-16vcpu-128gb",
        "slug": "m-16vcpu-128gb"
      },
      {
        "name": "m3-16vcpu-128gb",
        "slug": "m3-16vcpu-128gb"
      },
      {
        "name": "g-32vcpu-128gb",
        "slug": "g-32vcpu-128gb"
      },
      {
        "name": "s-32vcpu-192gb",
        "slug": "s-32vcpu-192gb"
      },
      {
        "name": "gd-32vcpu-128gb",
        "slug": "gd-32vcpu-128gb"
      },
      {
        "name": "m-24vcpu-192gb",
        "slug": "m-24vcpu-192gb"
      },
      {
        "name": "m6-16vcpu-128gb",
        "slug": "m6-16vcpu-128gb"
      },
      {
        "name": "g-40vcpu-160gb",
        "slug": "g-40vcpu-160gb"
      },
      {
        "name": "gd-40vcpu-160gb",
        "slug": "gd-40vcpu-160gb"
      },
      {
        "name": "m3-24vcpu-192gb",
        "slug": "m3-24vcpu-192gb"
      },
      {
        "name": "m-32vcpu-256gb",
        "slug": "m-32vcpu-256gb"
      },
      {
        "name": "m6-24vcpu-192gb",
        "slug": "m6-24vcpu-192gb"
      },
      {
        "name": "m3-32vcpu-256gb",
        "slug": "m3-32vcpu-256gb"
      },
      {
        "name": "m6-32vcpu-256gb",
        "slug": "m6-32vcpu-256gb"
      }
    ],
    "versions": [
      {
        "kubernetes_version": "1.18.8",
        "slug": "1.18.8-do.0",
        "supported_features": [
          "cluster-autoscaler",
          "docr-integration",
          "token-authentication"
        ]
      },
      {
        "kubernetes_version": "1.17.11",
        "slug": "1.17.11-do.0",
        "supported_features": [
          "cluster-autoscaler",
          "docr-integration",
          "token-authentication"
        ]
      },
      {
        "kubernetes_version": "1.16.14",
        "slug": "1.16.14-do.0",
        "supported_features": [
          "cluster-autoscaler",
          "docr-integration",
          "token-authentication"
        ]
      }
    ]
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Remove Registry

To remove the container registry from Kubernetes clusters, send a DELETE request to `/v2/kubernetes/registry`.

```java
CompletableFuture<ApiResponse<Void>> kubernetesRemoveRegistryAsync(
    final V2KubernetesRegistryRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2KubernetesRegistryRequest`](../../doc/models/v2-kubernetes-registry-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
V2KubernetesRegistryRequest body = new V2KubernetesRegistryRequest.Builder()
    .clusterUuids(Arrays.asList(
        "bd5f5959-5e1e-4205-a714-a914373942af",
        "50c2f44c-011d-493e-aee5-361a4a0d1844"
    ))
    .build();

kubernetesApi.kubernetesRemoveRegistryAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Kubernetes Add Registry

To integrate the container registry with Kubernetes clusters, send a POST request to `/v2/kubernetes/registry`.

```java
CompletableFuture<ApiResponse<Void>> kubernetesAddRegistryAsync(
    final V2KubernetesRegistryRequest body)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`V2KubernetesRegistryRequest`](../../doc/models/v2-kubernetes-registry-request.md) | Body, Optional | - |

## Response Type

**204**: The action was successful and the response body is empty.

`void`

## Example Usage

```java
V2KubernetesRegistryRequest body = new V2KubernetesRegistryRequest.Builder()
    .clusterUuids(Arrays.asList(
        "bd5f5959-5e1e-4205-a714-a914373942af",
        "50c2f44c-011d-493e-aee5-361a4a0d1844"
    ))
    .build();

kubernetesApi.kubernetesAddRegistryAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof V21Clicks401ErrorException) {
        V21Clicks401ErrorException v21Clicks401ErrorException = (V21Clicks401ErrorException) cause;
        v21Clicks401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

