
# Network

*This model accepts additional fields of type object.*

## Structure

`Network`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Created` | `string` | Required | Point in time when the Network was created (in ISO-8601 format) |
| `Id` | `int` | Required | ID of the Network |
| `IpRange` | `string` | Required | IPv4 prefix of the whole Network |
| `Labels` | `object` | Required | User-defined labels (key-value pairs) |
| `LoadBalancers` | `List<int>` | Optional | Array of IDs of Load Balancers attached to this Network |
| `Name` | `string` | Required | Name of the Network |
| `Protection` | [`Protection11`](../../doc/models/protection-11.md) | Required | Protection configuration for the Network |
| `Routes` | [`List<Route>`](../../doc/models/route.md) | Required | Array of routes set in this Network |
| `Servers` | `List<int>` | Required | Array of IDs of Servers attached to this Network |
| `Subnets` | [`List<Subnet>`](../../doc/models/subnet.md) | Required | Array subnets allocated in this Network |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using HetznerCloudApi.Standard.Models;
using HetznerCloudApi.Standard.Utilities;
using System.Collections.Generic;

Network network = new Network
{
    Created = "2016-01-30T23:50:00+00:00",
    Id = 4711,
    IpRange = "10.0.0.0/16",
    Labels = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    Name = "mynet",
    Protection = new Protection11
    {
        Delete = false,
        ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    },
    Routes = new List<Route>
    {
        new Route
        {
            Destination = "10.100.1.0/24",
            Gateway = "10.0.1.1",
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
    },
    Servers = new List<int>
    {
        42,
    },
    Subnets = new List<Subnet>
    {
        new Subnet
        {
            Gateway = "10.0.0.1",
            NetworkZone = "eu-central",
            Type = Type42.Cloud,
            IpRange = "10.0.1.0/24",
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
    },
    LoadBalancers = new List<int>
    {
        42,
    },
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

