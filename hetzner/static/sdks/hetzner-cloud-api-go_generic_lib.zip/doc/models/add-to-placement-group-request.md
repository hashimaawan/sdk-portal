
# Add to Placement Group Request

## Structure

`AddToPlacementGroupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PlacementGroup` | `int` | Required | ID of Placement Group the Server should be added to |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    addToPlacementGroupRequest := models.AddToPlacementGroupRequest{
        PlacementGroup:       1,
    }

}
```

