
# Stop Query Execution Input

## Structure

`StopQueryExecutionInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `QueryExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` |

## Example

```go
package main

import (
    "amazonathena/models"
)

func main() {
    stopQueryExecutionInput := models.StopQueryExecutionInput{
        QueryExecutionId:     "QueryExecutionId4",
    }

}
```

