
# Change Protection Request 1

## Structure

`ChangeProtectionRequest1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Delete` | `Boolean` | Optional | If true, prevents the Network from being deleted | Boolean getDelete() | setDelete(Boolean delete) |

## Example

```java
import cloud.hetzner.api.models.ChangeProtectionRequest1;

ChangeProtectionRequest1 changeProtectionRequest1 = new ChangeProtectionRequest1.Builder()
    .delete(true)
    .build();
```

