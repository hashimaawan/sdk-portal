
# Alerts 1

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`Alerts1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional, Read-only | A unique ID that can be used to identify and reference the alert. | getId(): ?string | setId(?string id): void |
| `comparison` | [`?string(Comparison)`](../../doc/models/comparison.md) | Optional | The comparison operator used against the alert's threshold. | getComparison(): ?string | setComparison(?string comparison): void |
| `name` | `?string` | Optional | A human-friendly display name. | getName(): ?string | setName(?string name): void |
| `notifications` | [`?Notifications`](../../doc/models/notifications.md) | Optional | The notification settings for a trigger alert. | getNotifications(): ?Notifications | setNotifications(?Notifications notifications): void |
| `period` | [`?string(Period)`](../../doc/models/period.md) | Optional | Period of time the threshold must be exceeded to trigger the alert. | getPeriod(): ?string | setPeriod(?string period): void |
| `threshold` | `?int` | Optional | The threshold at which the alert will enter a trigger state. The specific threshold is dependent on the alert type. | getThreshold(): ?int | setThreshold(?int threshold): void |
| `type` | [`?string(Type20)`](../../doc/models/type-20.md) | Optional | The type of alert. | getType(): ?string | setType(?string type): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\Alerts1Builder;
use DigitalOceanApiLib\Models\Comparison;
use DigitalOceanApiLib\Models\Builders\NotificationsBuilder;
use DigitalOceanApiLib\Models\Builders\SlackBuilder;
use DigitalOceanApiLib\ApiHelper;
use DigitalOceanApiLib\Models\Period;
use DigitalOceanApiLib\Models\Type20;

$alerts1 = Alerts1Builder::init()
    ->id('5a4981aa-9653-4bd1-bef5-d6bff52042e4')
    ->comparison(Comparison::GREATER_THAN)
    ->name('Landing page degraded performance')
    ->notifications(
        NotificationsBuilder::init(
            [
                'email4',
                'email3'
            ],
            [
                SlackBuilder::init(
                    'channel6',
                    'url2'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                SlackBuilder::init(
                    'channel6',
                    'url2'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build(),
                SlackBuilder::init(
                    'channel6',
                    'url2'
                )
                    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
                    ->build()
            ]
        )
            ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
            ->build()
    )
    ->period(Period::ENUM_2M)
    ->threshold(300)
    ->type(Type20::LATENCY)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

