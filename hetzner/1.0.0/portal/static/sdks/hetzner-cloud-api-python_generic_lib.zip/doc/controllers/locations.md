# Locations

Datacenters are organized by Locations. Datacenters in the same Location are connected with very low latency links.

```python
locations_api = client.locations
```

## Class Name

`LocationsApi`

## Methods

* [Get All Locations](../../doc/controllers/locations.md#get-all-locations)
* [Get a Location](../../doc/controllers/locations.md#get-a-location)


# Get All Locations

Returns all Location objects.

```python
def get_all_locations(self,
                     name=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Query, Optional | Can be used to filter Locations by their name. The response will only contain the Location matching the specified name. |

## Response Type

**200**: The `locations` key in the reply contains an array of Location objects with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`LocationsResponse`](../../doc/models/locations-response.md).

## Example Usage

```python
result = locations_api.get_all_locations()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Get a Location

Returns a specific Location object.

```python
def get_a_location(self,
                  id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | ID of Location |

## Response Type

**200**: The `location` key in the reply contains a Location object with this structure

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`LocationsResponse1`](../../doc/models/locations-response-1.md).

## Example Usage

```python
id = 112

result = locations_api.get_a_location(id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

