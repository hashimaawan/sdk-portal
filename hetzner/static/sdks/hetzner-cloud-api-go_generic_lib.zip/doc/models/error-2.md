
# Error 2

If issuance or renewal reports `failed`, this property contains information about what happened

## Structure

`Error2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `*string` | Optional | - |
| `Message` | `*string` | Optional | - |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    error2 := models.Error2{
        Code:                 models.ToPointer("code2"),
        Message:              models.ToPointer("message4"),
    }

}
```

