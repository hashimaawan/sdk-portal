
# Custom Query Parameter



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| api_key | `String` | - | `apiKey` | `getApiKey()` |



**Note:** Auth credentials can be set using `customQueryAuthenticationCredentials` in the client builder and accessed through `getCustomQueryAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```java
import com.giphy.api.GiphyApiClient;
import com.giphy.api.authentication.CustomQueryAuthenticationModel;

public class Program {
    public static void main(String[] args) {
        GiphyApiClient client = new GiphyApiClient.Builder()
            .customQueryAuthenticationCredentials(new CustomQueryAuthenticationModel.Builder(
                    "api_key"
                )
                .build())
            .build();
    }
}
```


