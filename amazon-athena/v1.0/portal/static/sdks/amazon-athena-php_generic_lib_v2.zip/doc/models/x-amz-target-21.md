
# X Amz Target 21

## Enumeration

`XAmzTarget21`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETNOTEBOOKMETADATA` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget21;

$xAmzTarget21 = XAmzTarget21::ENUM_AMAZONATHENAGETNOTEBOOKMETADATA;
```

