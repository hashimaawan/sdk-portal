
# X Amz Target 2 Enum

## Enumeration

`XAmzTarget2Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENABATCHGETQUERYEXECUTION` |

## Example

```python
from amazonathena.models.x_amz_target_2_enum import XAmzTarget2Enum

x_amz_target_2 = XAmzTarget2Enum.ENUM_AMAZONATHENABATCHGETQUERYEXECUTION
```

