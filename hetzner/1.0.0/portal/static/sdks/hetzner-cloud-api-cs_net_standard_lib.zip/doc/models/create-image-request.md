
# Create Image Request

## Structure

`CreateImageRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Optional | Description of the Image, will be auto-generated if not set |
| `Labels` | [`Labels`](../../doc/models/labels.md) | Optional | User-defined labels (key-value pairs) |
| `Type` | [`Type63Enum?`](../../doc/models/type-63-enum.md) | Optional | Type of Image to create (default: `snapshot`) |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

CreateImageRequest createImageRequest = new CreateImageRequest
{
    Description = "my image",
    Labels = new Labels
    {
        Labelkey = "labelkey4",
    },
    Type = Type63Enum.Snapshot,
};
```

