
# Get Session Response

## Structure

`GetSessionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `workGroup` | `string \| undefined` | Optional | **Constraints**: *Pattern*: `[a-zA-Z0-9._-]{1,128}` |
| `engineVersion` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `engineConfiguration` | [`EngineConfiguration1 \| undefined`](../../doc/models/engine-configuration-1.md) | Optional | - |
| `notebookVersion` | `string \| undefined` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `sessionConfiguration` | [`SessionConfiguration2 \| undefined`](../../doc/models/session-configuration-2.md) | Optional | - |
| `status` | [`Status3 \| undefined`](../../doc/models/status-3.md) | Optional | - |
| `statistics` | [`Statistics3 \| undefined`](../../doc/models/statistics-3.md) | Optional | - |

## Example

```ts
import { GetSessionResponse } from 'amazon-athenalib';

const getSessionResponse: GetSessionResponse = {
  sessionId: 'SessionId6',
  description: 'Description4',
  workGroup: 'WorkGroup4',
  engineVersion: 'EngineVersion8',
  engineConfiguration: {
    maxConcurrentDpus: 94,
    coordinatorDpuSize: 1,
    defaultExecutorDpuSize: 1,
    additionalConfigs: {},
  },
};
```

