
# State

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `Archived` |
| `Deleted` |

## Example

```csharp
using M1PasswordConnect.Standard.Models;

State state = State.Archived;
```

