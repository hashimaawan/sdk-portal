
# Server

*This model accepts additional fields of type unknown.*

## Structure

`Server`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number` | Required | ID of the Resource |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { Server } from 'hetzner-cloud-apilib';

const server: Server = {
  id: 42,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

