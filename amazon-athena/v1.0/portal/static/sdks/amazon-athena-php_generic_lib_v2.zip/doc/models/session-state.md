
# Session State

## Enumeration

`SessionState`

## Fields

| Name |
|  --- |
| `CREATING` |
| `CREATED` |
| `IDLE` |
| `BUSY` |
| `TERMINATING` |
| `TERMINATED` |
| `DEGRADED` |
| `FAILED` |

## Example

```php
use AmazonAthenaLib\Models\SessionState;

$sessionState = SessionState::TERMINATING;
```

