
# X Amz Target 22 Enum

## Enumeration

`XAmzTarget22Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAGETPREPAREDSTATEMENT` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget22Enum;

$xAmzTarget22 = XAmzTarget22Enum::ENUM_AMAZONATHENAGETPREPAREDSTATEMENT;
```

