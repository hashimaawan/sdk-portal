
# X Amz Target 14 Enum

## Enumeration

`XAmzTarget14Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENAEXPORTNOTEBOOK` |

## Example

```ruby
x_amz_target14 = XAmzTarget14Enum::ENUM_AMAZONATHENAEXPORTNOTEBOOK
```

