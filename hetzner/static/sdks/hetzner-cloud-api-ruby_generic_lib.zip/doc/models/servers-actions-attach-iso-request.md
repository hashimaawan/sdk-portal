
# Servers Actions Attach Iso Request

## Structure

`ServersActionsAttachIsoRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iso` | `String` | Required | ID or name of ISO to attach to the Server as listed in GET `/isos` |

## Example

```ruby
servers_actions_attach_iso_request = ServersActionsAttachIsoRequest.new(
  'FreeBSD-11.0-RELEASE-amd64-dvd1'
)
```

