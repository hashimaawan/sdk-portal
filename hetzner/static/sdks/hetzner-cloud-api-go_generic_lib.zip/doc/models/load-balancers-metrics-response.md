
# Load Balancers Metrics Response

## Structure

`LoadBalancersMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Metrics` | [`models.Metrics`](../../doc/models/metrics.md) | Required | - |

## Example

```go
package main

import (
    "hetznercloudapi/models"
)

func main() {
    loadBalancersMetricsResponse := models.LoadBalancersMetricsResponse{
        Metrics:              models.Metrics{
            End:                  "2017-01-01T23:00:00+00:00",
            Start:                "2017-01-01T00:00:00+00:00",
            Step:                 float64(60),
            TimeSeries:           map[string]models.TimeSeries{
                "name_of_timeseries": models.TimeSeries{
                    Values:               [][]models.TimeSeriesValues{
                        {
                            models.TimeSeriesValuesContainer.FromPrecision(float64(1435781470.622)),
                            models.TimeSeriesValuesContainer.FromString("42"),
                        },
                        {
                            models.TimeSeriesValuesContainer.FromPrecision(float64(1435781471.622)),
                            models.TimeSeriesValuesContainer.FromString("43"),
                        },
                    },
                },
            },
        },
    }

}
```

