
# Update Network Request

## Structure

`UpdateNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `labels` | [`Labels2`](../../doc/models/labels-2.md) | Optional | User-defined labels (key-value pairs) |
| `name` | `str` | Optional | New network name |

## Example

```python
from hetznercloudapi.models.labels_2 import Labels2
from hetznercloudapi.models.update_network_request import UpdateNetworkRequest

update_network_request = UpdateNetworkRequest(
    labels=Labels2(
        labelkey='labelkey4'
    ),
    name='new-name'
)
```

