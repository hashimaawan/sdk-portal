# Forex

```python
forex_controller = client.forex
```

## Class Name

`ForexController`

## Methods

* [Get Quotes for All Symbols](../../doc/controllers/forex.md#get-quotes-for-all-symbols)
* [Get a List of Symbols for Which We Provide Real-Time Quotes](../../doc/controllers/forex.md#get-a-list-of-symbols-for-which-we-provide-real-time-quotes)


# Get Quotes for All Symbols

Get quotes

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```python
def get_quotes_for_all_symbols(self)
```

## Response Type

**200**: A list of quotes

`void`

## Example Usage

```python
forex_controller.get_quotes_for_all_symbols()
```


# Get a List of Symbols for Which We Provide Real-Time Quotes

Symbol List

Find out more: [http://1forge.com/forex-data-api](http://1forge.com/forex-data-api)

```python
def get_a_list_of_symbols_for_which_we_provide_real_time_quotes(self)
```

## Response Type

**200**: A list of symbols

`List[str]`

## Example Usage

```python
result = forex_controller.get_a_list_of_symbols_for_which_we_provide_real_time_quotes()
print(result)
```

