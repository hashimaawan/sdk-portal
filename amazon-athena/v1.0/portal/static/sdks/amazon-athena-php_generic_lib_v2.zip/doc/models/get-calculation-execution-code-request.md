
# Get Calculation Execution Code Request

## Structure

`GetCalculationExecutionCodeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `calculationExecutionId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | getCalculationExecutionId(): string | setCalculationExecutionId(string calculationExecutionId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\GetCalculationExecutionCodeRequestBuilder;

$getCalculationExecutionCodeRequest = GetCalculationExecutionCodeRequestBuilder::init(
    'CalculationExecutionId4'
)->build();
```

