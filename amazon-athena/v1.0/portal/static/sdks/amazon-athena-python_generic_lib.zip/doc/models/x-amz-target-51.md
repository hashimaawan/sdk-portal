
# X Amz Target 51

## Enumeration

`XAmzTarget51`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENATAGRESOURCE` |

## Example

```python
from amazonathena.models.x_amz_target_51 import XAmzTarget51

x_amz_target_51 = XAmzTarget51.ENUM_AMAZONATHENATAGRESOURCE
```

