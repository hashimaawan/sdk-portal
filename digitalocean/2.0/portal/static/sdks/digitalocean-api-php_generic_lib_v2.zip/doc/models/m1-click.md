
# M1 Click

*This model accepts additional fields of type [array](../../doc/models/object.md).*

## Structure

`M1Click`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `slug` | `string` | Required | The slug identifier for the 1-Click application. | getSlug(): string | setSlug(string slug): void |
| `type` | `string` | Required | The type of the 1-Click application. | getType(): string | setType(string type): void |
| `additionalProperties` | [`array<string, array>`](../../doc/models/object.md) | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use DigitalOceanApiLib\Models\Builders\M1ClickBuilder;
use DigitalOceanApiLib\ApiHelper;

$m1Click = M1ClickBuilder::init(
    'monitoring',
    'kubernetes'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

