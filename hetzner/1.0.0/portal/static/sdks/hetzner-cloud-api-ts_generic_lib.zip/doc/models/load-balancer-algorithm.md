
# Load Balancer Algorithm

Algorithm of the Load Balancer

*This model accepts additional fields of type unknown.*

## Structure

`LoadBalancerAlgorithm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type28`](../../doc/models/type-28.md) | Required | Type of the algorithm |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { LoadBalancerAlgorithm, Type28 } from 'hetzner-cloud-apilib';

const loadBalancerAlgorithm: LoadBalancerAlgorithm = {
  type: Type28.RoundRobin,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

