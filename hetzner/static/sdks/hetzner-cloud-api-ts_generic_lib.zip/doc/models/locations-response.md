
# Locations Response

## Structure

`LocationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `locations` | [`Location[]`](../../doc/models/location.md) | Required | - |

## Example

```ts
import { LocationsResponse } from 'hetzner-cloud-apilib';

const locationsResponse: LocationsResponse = {
  locations: [
    {
      city: 'Falkenstein',
      country: 'DE',
      description: 'Falkenstein DC Park 1',
      id: 1,
      latitude: 50.47612,
      longitude: 12.370071,
      name: 'fsn1',
      networkZone: 'eu-central',
    }
  ],
};
```

