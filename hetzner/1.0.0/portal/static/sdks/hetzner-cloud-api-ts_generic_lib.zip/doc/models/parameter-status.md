
# Parameter Status

## Enumeration

`ParameterStatus`

## Fields

| Name |
|  --- |
| `Running` |
| `Success` |
| `Error` |

## Example

```ts
import { ParameterStatus } from 'hetzner-cloud-apilib';

const parameterStatus = ParameterStatus.Error;
```

