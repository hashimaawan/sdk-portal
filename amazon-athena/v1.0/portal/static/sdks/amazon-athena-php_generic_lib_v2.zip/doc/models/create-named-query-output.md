
# Create Named Query Output

## Structure

`CreateNamedQueryOutput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `namedQueryId` | `?string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getNamedQueryId(): ?string | setNamedQueryId(?string namedQueryId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\CreateNamedQueryOutputBuilder;

$createNamedQueryOutput = CreateNamedQueryOutputBuilder::init()
    ->namedQueryId('NamedQueryId0')
    ->build();
```

