
# Type 1

Choose between uploading a Certificate in PEM format or requesting a managed *Let's Encrypt* Certificate. If omitted defaults to `uploaded`.

## Enumeration

`Type1`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```php
use HetznerCloudApiLib\Models\Type1;

$type1 = Type1::UPLOADED;
```

