
# Default Toast Compression

Specifies the default TOAST compression method for values of compressible columns (the default is lz4).

## Enumeration

`DefaultToastCompression`

## Fields

| Name |
|  --- |
| `LZ4` |
| `PGLZ` |

## Example

```python
from digitaloceanapi.models.default_toast_compression import DefaultToastCompression

default_toast_compression = DefaultToastCompression.LZ4
```

