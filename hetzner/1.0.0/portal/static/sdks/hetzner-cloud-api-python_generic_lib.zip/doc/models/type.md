
# Type

Type of the Certificate

## Enumeration

`Type`

## Fields

| Name |
|  --- |
| `UPLOADED` |
| `MANAGED` |

## Example

```python
from hetznercloudapi.models.mtype import Type

mtype = Type.UPLOADED
```

