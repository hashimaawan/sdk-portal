
# Type 41

## Enumeration

`Type41`

## Fields

| Name |
|  --- |
| `OpenConnections` |
| `ConnectionsPerSecond` |
| `RequestsPerSecond` |
| `Bandwidth` |

## Example

```ts
import { Type41 } from 'hetzner-cloud-apilib';

const type41 = Type41.RequestsPerSecond;
```

