
# Query Execution State

## Enumeration

`QueryExecutionState`

## Fields

| Name |
|  --- |
| `Queued` |
| `Running` |
| `Succeeded` |
| `Failed` |
| `Cancelled` |

## Example

```go
package main

import (
    "amazonAthena/models"
)

func main() {
    queryExecutionState := models.QueryExecutionState_Cancelled

}
```

