
# V2 Databases Pools Request

*This model accepts additional fields of type [unknown](../../doc/models/object.md).*

## Structure

`V2DatabasesPoolsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `db` | `string` | Required | The database for use with the connection pool. |
| `mode` | `string` | Required | The PGBouncer transaction mode for the connection pool. The allowed values are session, transaction, and statement. |
| `size` | `number` | Required | The desired size of the PGBouncer connection pool. The maximum allowed size is determined by the size of the cluster's primary node. 25 backend server connections are allowed for every 1GB of RAM. Three are reserved for maintenance. For example, a primary node with 1 GB of RAM allows for a maximum of 22 backend server connections while one with 4 GB would allow for 97. Note that these are shared across all connection pools in a cluster. |
| `user` | `string \| undefined` | Optional | The name of the user for use with the connection pool. When excluded, all sessions connect to the database as the inbound user. |
| `additionalProperties` | [`Record<string, unknown>`](../../doc/models/object.md) | Optional | - |

## Example

```ts
import { V2DatabasesPoolsRequest } from 'digitalocean-apilib';

const v2DatabasesPoolsRequest: V2DatabasesPoolsRequest = {
  db: 'defaultdb',
  mode: 'transaction',
  size: 10,
  user: 'doadmin',
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

