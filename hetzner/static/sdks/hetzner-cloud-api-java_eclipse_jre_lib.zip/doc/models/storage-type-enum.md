
# Storage Type Enum

Type of Server boot drive. Local has higher speed. Network has better availability.

## Enumeration

`StorageTypeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `NETWORK` |

## Example

```java
import cloud.hetzner.api.models.StorageTypeEnum;

StorageTypeEnum storageType = StorageTypeEnum.LOCAL;
```

