
# Database

Contains metadata information for a database in a data catalog.

## Structure

`Database`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128` |
| `Description` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `Parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |

## Example

```csharp
using AmazonAthena.Standard.Models;

Database database = new Database
{
    Name = "Name0",
    Description = "Description6",
    Parameters = new Parameters
    {
    },
};
```

