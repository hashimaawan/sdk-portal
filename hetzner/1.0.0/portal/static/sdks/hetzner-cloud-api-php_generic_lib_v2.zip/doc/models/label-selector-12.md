
# Label Selector 12

Configuration for label selector targets, required if type is `label_selector`

*This model accepts additional fields of type array.*

## Structure

`LabelSelector12`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `selector` | `string` | Required | Label selector | getSelector(): string | setSelector(string selector): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example

```php
use HetznerCloudApiLib\Models\Builders\LabelSelector12Builder;
use HetznerCloudApiLib\ApiHelper;

$labelSelector12 = LabelSelector12Builder::init(
    'env=prod'
)
    ->additionalProperty('exampleAdditionalProperty', ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'))
    ->build();
```

