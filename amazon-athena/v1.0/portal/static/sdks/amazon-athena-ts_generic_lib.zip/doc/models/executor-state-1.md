
# Executor State 1

<p>A filter for a specific executor state. A description of each state follows.</p> <p> <code>CREATING</code> - The executor is being started, including acquiring resources.</p> <p> <code>CREATED</code> - The executor has been started.</p> <p> <code>REGISTERED</code> - The executor has been registered.</p> <p> <code>TERMINATING</code> - The executor is in the process of shutting down.</p> <p> <code>TERMINATED</code> - The executor is no longer running.</p> <p> <code>FAILED</code> - Due to a failure, the executor is no longer running.</p>


## Enumeration

`ExecutorState1`

## Fields

| Name |
|  --- |
| `Creating` |
| `Created` |
| `Registered` |
| `Terminating` |
| `Terminated` |
| `Failed` |

## Example

```ts
import { ExecutorState1 } from 'amazon-athenalib';

const executorState1 = ExecutorState1.Creating;
```

