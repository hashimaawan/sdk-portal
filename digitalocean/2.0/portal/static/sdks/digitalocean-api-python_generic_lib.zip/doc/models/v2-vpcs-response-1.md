
# V2 Vpcs Response 1

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2VpcsResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vpc` | [`Vpc`](../../doc/models/vpc.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import jsonpickle

from digitaloceanapi.models.v_2_vpcs_response_1 import V2VpcsResponse1
from digitaloceanapi.models.vpc import Vpc

v_2_vpcs_response_1 = V2VpcsResponse1(
    vpc=Vpc(
        description='description8',
        name='name2',
        ip_range='ip_range4',
        region='region8',
        default=False,
        additional_properties={
            'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

