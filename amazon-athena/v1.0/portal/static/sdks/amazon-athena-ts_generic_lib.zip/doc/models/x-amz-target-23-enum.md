
# X Amz Target 23 Enum

## Enumeration

`XAmzTarget23Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaGetQueryExecution` |

## Example

```ts
import { XAmzTarget23Enum } from 'amazon-athenalib';

const xAmzTarget23 = XAmzTarget23Enum.EnumAmazonAthenaGetQueryExecution;
```

