
# X Amz Target 12 Enum

## Enumeration

`XAmzTarget12Enum`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT` |

## Example

```ruby
x_amz_target12 = XAmzTarget12Enum::ENUM_AMAZONATHENADELETEPREPAREDSTATEMENT
```

