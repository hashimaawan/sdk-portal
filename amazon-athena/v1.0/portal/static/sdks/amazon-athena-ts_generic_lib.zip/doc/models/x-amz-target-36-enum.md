
# X Amz Target 36 Enum

## Enumeration

`XAmzTarget36Enum`

## Fields

| Name |
|  --- |
| `EnumAmazonAthenaListExecutors` |

## Example

```ts
import { XAmzTarget36Enum } from 'amazon-athenalib';

const xAmzTarget36 = XAmzTarget36Enum.EnumAmazonAthenaListExecutors;
```

