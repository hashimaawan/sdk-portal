
# State 1

A string indicating the current status of the node.

## Enumeration

`State1`

## Fields

| Name |
|  --- |
| `PROVISIONING` |
| `RUNNING` |
| `DRAINING` |
| `DELETING` |

## Example

```php
use DigitalOceanApiLib\Models\State1;

$state1 = State1::DRAINING;
```

