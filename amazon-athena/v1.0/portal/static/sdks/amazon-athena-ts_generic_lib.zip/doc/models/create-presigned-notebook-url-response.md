
# Create Presigned Notebook Url Response

## Structure

`CreatePresignedNotebookUrlResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notebookUrl` | `string` | Required | - |
| `authToken` | `string` | Required | **Constraints**: *Maximum Length*: `2048` |
| `authTokenExpirationTime` | `number` | Required | - |

## Example

```ts
import { CreatePresignedNotebookUrlResponse } from 'amazon-athenalib';

const createPresignedNotebookUrlResponse: CreatePresignedNotebookUrlResponse = {
  notebookUrl: 'NotebookUrl0',
  authToken: 'AuthToken4',
  authTokenExpirationTime: 240,
};
```

