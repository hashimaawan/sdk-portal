
# V2 Registry Garbage Collections Response

*This model accepts additional fields of type [Any](../../doc/models/object.md).*

## Structure

`V2RegistryGarbageCollectionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `garbage_collections` | [`List[GarbageCollection]`](../../doc/models/garbage-collection.md) | Optional | - |
| `additional_properties` | [`Dict[str, Any]`](../../doc/models/object.md) | Optional | - |

## Example

```python
import dateutil.parser
import jsonpickle

from digitaloceanapi.models.garbage_collection import GarbageCollection
from digitaloceanapi.models.status_15 import Status15
from digitaloceanapi.models.v_2_registry_garbage_collections_response import V2RegistryGarbageCollectionsResponse

v_2_registry_garbage_collections_response = V2RegistryGarbageCollectionsResponse(
    garbage_collections=[
        GarbageCollection(
            blobs_deleted=26,
            created_at=dateutil.parser.parse('2016-03-13T12:52:32.123Z'),
            freed_bytes=100,
            registry_name='registry_name2',
            status=Status15.REQUESTED,
            additional_properties={
                'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
            }
        )
    ],
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

