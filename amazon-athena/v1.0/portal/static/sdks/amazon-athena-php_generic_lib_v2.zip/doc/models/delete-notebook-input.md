
# Delete Notebook Input

## Structure

`DeleteNotebookInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notebookId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36`, *Pattern*: `[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}` | getNotebookId(): string | setNotebookId(string notebookId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DeleteNotebookInputBuilder;

$deleteNotebookInput = DeleteNotebookInputBuilder::init(
    'NotebookId0'
)->build();
```

