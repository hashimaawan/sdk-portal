
# Get Calculation Execution Status Request

## Structure

`GetCalculationExecutionStatusRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CalculationExecutionId` | `String` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` | String getCalculationExecutionId() | setCalculationExecutionId(String calculationExecutionId) |

## Example

```java
import com.amazonaws.useast1.athena.models.GetCalculationExecutionStatusRequest;

GetCalculationExecutionStatusRequest getCalculationExecutionStatusRequest = new GetCalculationExecutionStatusRequest.Builder(
    "CalculationExecutionId8"
)
.build();
```

