
# Load Balancers Actions Detach from Network Request

## Structure

`LoadBalancersActionsDetachFromNetworkRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Network` | `double` | Required | ID of an existing network to detach the Load Balancer from |

## Example

```csharp
using HetznerCloudAPI.Standard.Models;

LoadBalancersActionsDetachFromNetworkRequest loadBalancersActionsDetachFromNetworkRequest = new LoadBalancersActionsDetachFromNetworkRequest
{
    Network = 4711,
};
```

