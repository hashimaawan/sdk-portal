
# Backup 1

*This model accepts additional fields of type [Object](../../doc/models/object.md).*

## Structure

`Backup1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | The unique identifier for the snapshot or backup. |
| `created_at` | `DateTime` | Required | A time value given in ISO8601 combined date and time format that represents when the snapshot was created. |
| `min_disk_size` | `Integer` | Required | The minimum size in GB required for a volume or Droplet to use this snapshot. |
| `name` | `String` | Required | A human-readable name for the snapshot. |
| `regions` | `Array[String]` | Required | An array of the regions that the snapshot is available in. The regions are represented by their identifying slug values. |
| `size_gigabytes` | `Float` | Required | The billable size of the snapshot in gigabytes. |
| `type` | [`Type13`](../../doc/models/type-13.md) | Required | Describes the kind of image. It may be one of `snapshot` or `backup`. This specifies whether an image is a user-generated Droplet snapshot or automatically created Droplet backup. |
| `additional_properties` | [`Hash[String, Object]`](../../doc/models/object.md) | Optional | - |

## Example

```ruby
backup1 = Backup1.new(
  id: 6372321,
  created_at: DateTimeHelper.from_rfc3339('2020-07-28T16:47:44Z'),
  min_disk_size: 25,
  name: 'web-01-1595954862243',
  regions: [
    'nyc3',
    'sfo3'
  ],
  size_gigabytes: 2.34,
  type: Type13::SNAPSHOT,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

