
# Item Type 1

The ID type: currently only `artist` is supported.

## Enumeration

`ItemType1`

## Fields

| Name |
|  --- |
| `Artist` |

## Example

```go
package main

import (
    "spotifyWebApiWithFixesAndImprovementsFromSonallux/models"
)

func main() {
    itemType1 := models.ItemType1_Artist

}
```

