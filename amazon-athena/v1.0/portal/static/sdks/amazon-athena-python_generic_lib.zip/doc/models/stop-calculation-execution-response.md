
# Stop Calculation Execution Response

*This model accepts additional fields of type Any.*

## Structure

`StopCalculationExecutionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `state` | [`CalculationExecutionState4`](../../doc/models/calculation-execution-state-4.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.calculation_execution_state_4 import CalculationExecutionState4
from amazonathena.models.stop_calculation_execution_response import StopCalculationExecutionResponse

stop_calculation_execution_response = StopCalculationExecutionResponse(
    state=CalculationExecutionState4.QUEUED,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

