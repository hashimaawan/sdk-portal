
# Delete Named Query Input

## Structure

`DeleteNamedQueryInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `namedQueryId` | `string` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `\S+` | getNamedQueryId(): string | setNamedQueryId(string namedQueryId): void |

## Example

```php
use AmazonAthenaLib\Models\Builders\DeleteNamedQueryInputBuilder;

$deleteNamedQueryInput = DeleteNamedQueryInputBuilder::init(
    'NamedQueryId4'
)->build();
```

