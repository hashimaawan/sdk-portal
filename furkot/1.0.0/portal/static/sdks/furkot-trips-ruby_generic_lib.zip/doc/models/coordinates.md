
# Coordinates

geographical coordinates of the stop

*This model accepts additional fields of type Object.*

## Structure

`Coordinates`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lat` | `Float` | Optional | latitude |
| `lon` | `Float` | Optional | longitude |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
coordinates = Coordinates.new(
  lat: 182.98,
  lon: 16.08,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

