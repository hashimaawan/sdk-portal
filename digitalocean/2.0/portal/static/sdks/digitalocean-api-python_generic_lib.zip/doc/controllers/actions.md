# Actions

Actions are records of events that have occurred on the resources in your account.
These can be things like rebooting a Droplet, or transferring an image to a new region.

An action object is created every time one of these actions is initiated. The action
object contains information about the current status of the action, start and complete
timestamps, and the associated resource type and ID.

Every action that creates an action object is available through this endpoint. Completed
actions are not removed from this list and are always available for querying.

**Note:** You can pass the following HTTP header with the request to have the API return
the `reserved_ips` stanza instead of the `floating_ips` stanza:

- `Accept: application/vnd.digitalocean.reserveip+json`

```python
actions_api = client.actions
```

## Class Name

`ActionsApi`

## Methods

* [Actions List](../../doc/controllers/actions.md#actions-list)
* [Actions Get](../../doc/controllers/actions.md#actions-get)


# Actions List

This will be the entire list of actions taken on your account, so it will be quite large. As with any large collection returned by the API, the results will be paginated with only 20 on each page by default.

```python
def actions_list(self,
                per_page=20,
                page=1)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `per_page` | `int` | Query, Optional | Number of items returned per page<br><br>**Default**: `20`<br><br>**Constraints**: `>= 1`, `<= 200` |
| `page` | `int` | Query, Optional | Which 'page' of paginated results to return.<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The results will be returned as a JSON object with an actions key.  This will be set to an array filled with action objects containing the standard action attributes

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ActionsResponse`](../../doc/models/v2-actions-response.md).

## Example Usage

```python
per_page = 2

page = 1

result = actions_api.actions_list(
    per_page=per_page,
    page=page
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |


# Actions Get

To retrieve a specific action object, send a GET request to `/v2/actions/$ACTION_ID`.

```python
def actions_get(self,
               action_id)
```

## Authentication

This endpoint requires [bearer_auth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action_id` | `int` | Template, Required | A unique numeric ID that can be used to identify and reference an action.<br><br>**Constraints**: `>= 1` |

## Response Type

**200**: The result will be a JSON object with an action key.  This will be set to an action object containing the standard action attributes.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`V2ActionsResponse1`](../../doc/models/v2-actions-response-1.md).

## Example Usage

```python
action_id = 36804636

result = actions_api.actions_get(action_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 404 | The resource was not found. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 429 | API Rate limit exceeded | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| 500 | Server error. | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |
| Default | Unexpected error | [`V21Clicks401ErrorException`](../../doc/models/v21-clicks-401-error-exception.md) |

