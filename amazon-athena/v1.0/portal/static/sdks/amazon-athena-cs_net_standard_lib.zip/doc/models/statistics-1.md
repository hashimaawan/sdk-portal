
# Statistics 1

## Structure

`Statistics1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DpuExecutionInMillis` | `int?` | Optional | - |
| `Progress` | `string` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |

## Example

```csharp
using AmazonAthena.Standard.Models;

Statistics1 statistics1 = new Statistics1
{
    DpuExecutionInMillis = 148,
    Progress = "Progress4",
};
```

