
# Data Catalog 2

*This model accepts additional fields of type Any.*

## Structure

`DataCatalog2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `256` |
| `description` | `str` | Optional | **Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1024` |
| `mtype` | [`DataCatalogType1`](../../doc/models/data-catalog-type-1.md) | Required | - |
| `parameters` | [`Parameters`](../../doc/models/parameters.md) | Optional | - |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from amazonathena.models.data_catalog_2 import DataCatalog2
from amazonathena.models.data_catalog_type_1 import DataCatalogType1
from amazonathena.models.parameters import Parameters

data_catalog_2 = DataCatalog2(
    name='Name2',
    mtype=DataCatalogType1.HIVE,
    description='Description4',
    parameters=Parameters(
        additional_properties={
            'exampleAdditionalProperty': 'Parameters_additionalProperties2'
        }
    ),
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

