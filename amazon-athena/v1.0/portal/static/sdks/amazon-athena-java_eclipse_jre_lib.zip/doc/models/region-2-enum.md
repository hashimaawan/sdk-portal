
# Region 2 Enum

## Enumeration

`Region2Enum`

## Fields

| Name |
|  --- |
| `CNNORTH1` |
| `CNNORTHWEST1` |

## Example

```java
import com.amazonaws.useast1.athena.models.Region2Enum;

Region2Enum region2 = Region2Enum.CNNORTH1;
```

