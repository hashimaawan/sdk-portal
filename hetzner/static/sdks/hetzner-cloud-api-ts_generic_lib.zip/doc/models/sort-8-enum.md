
# Sort 8 Enum

## Enumeration

`Sort8Enum`

## Fields

| Name |
|  --- |
| `Id` |
| `EnumIdasc` |
| `EnumIddesc` |
| `Name` |
| `EnumNameasc` |
| `EnumNamedesc` |

## Example

```ts
import { Sort8Enum } from 'hetzner-cloud-apilib';

const sort8 = Sort8Enum.EnumNameasc;
```

