
# State

A string representing the current state of the certificate. It may be `pending`, `verified`, or `error`.

## Enumeration

`State`

## Fields

| Name |
|  --- |
| `Pending` |
| `Verified` |
| `Error` |

## Example

```ts
import { State } from 'digitalocean-apilib';

const state = State.Error;
```

