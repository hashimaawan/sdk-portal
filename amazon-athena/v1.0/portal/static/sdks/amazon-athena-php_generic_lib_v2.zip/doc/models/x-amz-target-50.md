
# X Amz Target 50

## Enumeration

`XAmzTarget50`

## Fields

| Name |
|  --- |
| `ENUM_AMAZONATHENASTOPQUERYEXECUTION` |

## Example

```php
use AmazonAthenaLib\Models\XAmzTarget50;

$xAmzTarget50 = XAmzTarget50::ENUM_AMAZONATHENASTOPQUERYEXECUTION;
```

